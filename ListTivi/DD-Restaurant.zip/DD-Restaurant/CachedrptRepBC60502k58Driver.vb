﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020001CA RID: 458
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60502k58Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005E6D RID: 24173 RVA: 0x00010BB9 File Offset: 0x0000EDB9
		Public Sub New()
			CachedrptRepBC60502k58Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x1700232A RID: 9002
		' (get) Token: 0x06005E6E RID: 24174 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005E6F RID: 24175 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700232B RID: 9003
		' (get) Token: 0x06005E70 RID: 24176 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005E71 RID: 24177 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700232C RID: 9004
		' (get) Token: 0x06005E72 RID: 24178 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005E73 RID: 24179 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005E74 RID: 24180 RVA: 0x004DC4A0 File Offset: 0x004DA6A0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60502k58Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x06005E75 RID: 24181 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040027C2 RID: 10178
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
