﻿Imports System
Imports System.CodeDom.Compiler
Imports System.Collections
Imports System.ComponentModel
Imports System.ComponentModel.Design
Imports System.Data
Imports System.Diagnostics
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Runtime.Serialization
Imports System.Xml
Imports System.Xml.Schema
Imports System.Xml.Serialization
Imports Microsoft.VisualBasic.CompilerServices

Namespace prjIS_SalesPOS
	' Token: 0x02000010 RID: 16
	<GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")>
	<XmlRoot("dsReport")>
	<DesignerCategory("code")>
	<HelpKeyword("vs.data.DataSet")>
	<XmlSchemaProvider("GetTypedDataSetSchema")>
	<ToolboxItem(True)>
	<Serializable()>
	Public Class dsReport
		Inherits DataSet

		' Token: 0x06000211 RID: 529 RVA: 0x0001DDE8 File Offset: 0x0001BFE8
		<DebuggerNonUserCode()>
		Public Sub New()
			dsReport.__ENCList.Add(New WeakReference(Me))
			Me._schemaSerializationMode = SchemaSerializationMode.IncludeSchema
			Me.BeginInit()
			Me.InitClass()
			Dim collectionChangeEventHandler As CollectionChangeEventHandler = AddressOf Me.SchemaChanged
			AddHandler MyBase.Tables.CollectionChanged, collectionChangeEventHandler
			AddHandler MyBase.Relations.CollectionChanged, collectionChangeEventHandler
			Me.EndInit()
		End Sub

		' Token: 0x06000212 RID: 530 RVA: 0x0001DE54 File Offset: 0x0001C054
		<DebuggerNonUserCode()>
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context, False)
			dsReport.__ENCList.Add(New WeakReference(Me))
			Me._schemaSerializationMode = SchemaSerializationMode.IncludeSchema
			Dim flag As Boolean = Me.IsBinarySerialized(info, context)
			If flag Then
				Me.InitVars(False)
				Dim collectionChangeEventHandler As CollectionChangeEventHandler = AddressOf Me.SchemaChanged
				AddHandler Me.Tables.CollectionChanged, collectionChangeEventHandler
				AddHandler Me.Relations.CollectionChanged, collectionChangeEventHandler
			Else
				Dim text As String = Conversions.ToString(info.GetValue("XmlSchema", GetType(String)))
				flag = Me.DetermineSchemaSerializationMode(info, context) = SchemaSerializationMode.IncludeSchema
				If flag Then
					Dim dataSet As DataSet = New DataSet()
					dataSet.ReadXmlSchema(New XmlTextReader(New StringReader(text)))
					flag = dataSet.Tables("dtReport") IsNot Nothing
					If flag Then
						MyBase.Tables.Add(New dsReport.dtReportDataTable(dataSet.Tables("dtReport")))
					End If
					Me.DataSetName = dataSet.DataSetName
					Me.Prefix = dataSet.Prefix
					Me.[Namespace] = dataSet.[Namespace]
					Me.Locale = dataSet.Locale
					Me.CaseSensitive = dataSet.CaseSensitive
					Me.EnforceConstraints = dataSet.EnforceConstraints
					Me.Merge(dataSet, False, MissingSchemaAction.Add)
					Me.InitVars()
				Else
					Me.ReadXmlSchema(New XmlTextReader(New StringReader(text)))
				End If
				Me.GetSerializationData(info, context)
				Dim collectionChangeEventHandler2 As CollectionChangeEventHandler = AddressOf Me.SchemaChanged
				AddHandler MyBase.Tables.CollectionChanged, collectionChangeEventHandler2
				AddHandler Me.Relations.CollectionChanged, collectionChangeEventHandler2
			End If
		End Sub

		' Token: 0x170000E3 RID: 227
		' (get) Token: 0x06000213 RID: 531 RVA: 0x0001DFF8 File Offset: 0x0001C1F8
		<DebuggerNonUserCode()>
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Content)>
		Public ReadOnly Property dtReport As dsReport.dtReportDataTable
			Get
				Return Me.tabledtReport
			End Get
		End Property

		' Token: 0x170000E4 RID: 228
		' (get) Token: 0x06000214 RID: 532 RVA: 0x0001E010 File Offset: 0x0001C210
		' (set) Token: 0x06000215 RID: 533 RVA: 0x000023F1 File Offset: 0x000005F1
		<DebuggerNonUserCode()>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)>
		<Browsable(True)>
		Public Overrides Property SchemaSerializationMode As SchemaSerializationMode
			Get
				Return Me._schemaSerializationMode
			End Get
			Set(value As SchemaSerializationMode)
				Me._schemaSerializationMode = value
			End Set
		End Property

		' Token: 0x170000E5 RID: 229
		' (get) Token: 0x06000216 RID: 534 RVA: 0x0001D5A8 File Offset: 0x0001B7A8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<DebuggerNonUserCode()>
		Public ReadOnly Property Tables As DataTableCollection
			Get
				Return MyBase.Tables
			End Get
		End Property

		' Token: 0x170000E6 RID: 230
		' (get) Token: 0x06000217 RID: 535 RVA: 0x0001D5C0 File Offset: 0x0001B7C0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<DebuggerNonUserCode()>
		Public ReadOnly Property Relations As DataRelationCollection
			Get
				Return MyBase.Relations
			End Get
		End Property

		' Token: 0x06000218 RID: 536 RVA: 0x000023FC File Offset: 0x000005FC
		<DebuggerNonUserCode()>
		Protected Overrides Sub InitializeDerivedDataSet()
			Me.BeginInit()
			Me.InitClass()
			Me.EndInit()
		End Sub

		' Token: 0x06000219 RID: 537 RVA: 0x0001E028 File Offset: 0x0001C228
		<DebuggerNonUserCode()>
		Public Overrides Function Clone() As DataSet
			Dim dsReport As dsReport = CType(MyBase.Clone(), dsReport)
			dsReport.InitVars()
			dsReport.SchemaSerializationMode = Me.SchemaSerializationMode
			Return dsReport
		End Function

		' Token: 0x0600021A RID: 538 RVA: 0x0001D60C File Offset: 0x0001B80C
		<DebuggerNonUserCode()>
		Protected Overrides Function ShouldSerializeTables() As Boolean
			Return False
		End Function

		' Token: 0x0600021B RID: 539 RVA: 0x0001D60C File Offset: 0x0001B80C
		<DebuggerNonUserCode()>
		Protected Overrides Function ShouldSerializeRelations() As Boolean
			Return False
		End Function

		' Token: 0x0600021C RID: 540 RVA: 0x0001E05C File Offset: 0x0001C25C
		<DebuggerNonUserCode()>
		Protected Overrides Sub ReadXmlSerializable(reader As XmlReader)
			Dim flag As Boolean = Me.DetermineSchemaSerializationMode(reader) = SchemaSerializationMode.IncludeSchema
			If flag Then
				Me.Reset()
				Dim dataSet As DataSet = New DataSet()
				dataSet.ReadXml(reader)
				flag = dataSet.Tables("dtReport") IsNot Nothing
				If flag Then
					MyBase.Tables.Add(New dsReport.dtReportDataTable(dataSet.Tables("dtReport")))
				End If
				Me.DataSetName = dataSet.DataSetName
				Me.Prefix = dataSet.Prefix
				Me.[Namespace] = dataSet.[Namespace]
				Me.Locale = dataSet.Locale
				Me.CaseSensitive = dataSet.CaseSensitive
				Me.EnforceConstraints = dataSet.EnforceConstraints
				Me.Merge(dataSet, False, MissingSchemaAction.Add)
				Me.InitVars()
			Else
				Me.ReadXml(reader)
				Me.InitVars()
			End If
		End Sub

		' Token: 0x0600021D RID: 541 RVA: 0x0001D704 File Offset: 0x0001B904
		<DebuggerNonUserCode()>
		Protected Overrides Function GetSchemaSerializable() As XmlSchema
			Dim memoryStream As MemoryStream = New MemoryStream()
			Me.WriteXmlSchema(New XmlTextWriter(memoryStream, Nothing))
			memoryStream.Position = 0L
			Return XmlSchema.Read(New XmlTextReader(memoryStream), Nothing)
		End Function

		' Token: 0x0600021E RID: 542 RVA: 0x00002415 File Offset: 0x00000615
		<DebuggerNonUserCode()>
		Friend Sub InitVars()
			Me.InitVars(True)
		End Sub

		' Token: 0x0600021F RID: 543 RVA: 0x0001E140 File Offset: 0x0001C340
		<DebuggerNonUserCode()>
		Friend Sub InitVars(initTable As Boolean)
			Me.tabledtReport = CType(MyBase.Tables("dtReport"), dsReport.dtReportDataTable)
			If initTable Then
				Dim flag As Boolean = Me.tabledtReport IsNot Nothing
				If flag Then
					Me.tabledtReport.InitVars()
				End If
			End If
		End Sub

		' Token: 0x06000220 RID: 544 RVA: 0x0001E190 File Offset: 0x0001C390
		<DebuggerNonUserCode()>
		Private Sub InitClass()
			Me.DataSetName = "dsReport"
			Me.Prefix = ""
			Me.[Namespace] = "http://tempuri.org/dsReport.xsd"
			Me.EnforceConstraints = True
			Me.SchemaSerializationMode = SchemaSerializationMode.IncludeSchema
			Me.tabledtReport = New dsReport.dtReportDataTable()
			MyBase.Tables.Add(Me.tabledtReport)
		End Sub

		' Token: 0x06000221 RID: 545 RVA: 0x0001D60C File Offset: 0x0001B80C
		<DebuggerNonUserCode()>
		Private Function ShouldSerializedtReport() As Boolean
			Return False
		End Function

		' Token: 0x06000222 RID: 546 RVA: 0x0001E1F0 File Offset: 0x0001C3F0
		<DebuggerNonUserCode()>
		Private Sub SchemaChanged(sender As Object, e As CollectionChangeEventArgs)
			Dim flag As Boolean = e.Action = CollectionChangeAction.Remove
			If flag Then
				Me.InitVars()
			End If
		End Sub

		' Token: 0x06000223 RID: 547 RVA: 0x0001E214 File Offset: 0x0001C414
		<DebuggerNonUserCode()>
		Public Shared Function GetTypedDataSetSchema(xs As XmlSchemaSet) As XmlSchemaComplexType
			Dim dsReport As dsReport = New dsReport()
			Dim xmlSchemaComplexType As XmlSchemaComplexType = New XmlSchemaComplexType()
			Dim xmlSchemaSequence As XmlSchemaSequence = New XmlSchemaSequence()
			Dim xmlSchemaAny As XmlSchemaAny = New XmlSchemaAny()
			xmlSchemaAny.[Namespace] = dsReport.[Namespace]
			xmlSchemaSequence.Items.Add(xmlSchemaAny)
			xmlSchemaComplexType.Particle = xmlSchemaSequence
			Dim schemaSerializable As XmlSchema = dsReport.GetSchemaSerializable()
			Dim flag As Boolean = xs.Contains(schemaSerializable.TargetNamespace)
			If flag Then
				Dim memoryStream As MemoryStream = New MemoryStream()
				Dim memoryStream2 As MemoryStream = New MemoryStream()
				Try
					schemaSerializable.Write(memoryStream)
					For Each obj As Object In xs.Schemas(schemaSerializable.TargetNamespace)
						Dim xmlSchema As XmlSchema = CType(obj, XmlSchema)
						memoryStream2.SetLength(0L)
						xmlSchema.Write(memoryStream2)
						flag = memoryStream.Length = memoryStream2.Length
						If flag Then
							memoryStream.Position = 0L
							memoryStream2.Position = 0L
							While memoryStream.Position <> memoryStream.Length AndAlso memoryStream.ReadByte() = memoryStream2.ReadByte()
							End While
							flag = memoryStream.Position = memoryStream.Length
							If flag Then
								Return xmlSchemaComplexType
							End If
						End If
					Next
				Finally
					flag = memoryStream IsNot Nothing
					If flag Then
						memoryStream.Close()
					End If
					flag = memoryStream2 IsNot Nothing
					If flag Then
						memoryStream2.Close()
					End If
				End Try
			End If
			xs.Add(schemaSerializable)
			Return xmlSchemaComplexType
		End Function

		' Token: 0x040000F2 RID: 242
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040000F3 RID: 243
		Private tabledtReport As dsReport.dtReportDataTable

		' Token: 0x040000F4 RID: 244
		Private _schemaSerializationMode As SchemaSerializationMode

		' Token: 0x02000011 RID: 17
		' (Invoke) Token: 0x06000227 RID: 551
		Public Delegate Sub dtReportRowChangeEventHandler(sender As Object, e As dsReport.dtReportRowChangeEvent)

		' Token: 0x02000012 RID: 18
		<XmlSchemaProvider("GetTypedTableSchema")>
		<GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")>
		<Serializable()>
		Public Class dtReportDataTable
			Inherits DataTable
			Implements IEnumerable

			' Token: 0x06000229 RID: 553 RVA: 0x0000242E File Offset: 0x0000062E
			<DebuggerNonUserCode()>
			Public Sub New()
				dsReport.dtReportDataTable.__ENCList.Add(New WeakReference(Me))
				Me.TableName = "dtReport"
				Me.BeginInit()
				Me.InitClass()
				Me.EndInit()
			End Sub

			' Token: 0x0600022A RID: 554 RVA: 0x0001E3AC File Offset: 0x0001C5AC
			<DebuggerNonUserCode()>
			Friend Sub New(table As DataTable)
				dsReport.dtReportDataTable.__ENCList.Add(New WeakReference(Me))
				Me.TableName = table.TableName
				Dim flag As Boolean = table.CaseSensitive <> table.DataSet.CaseSensitive
				If flag Then
					Me.CaseSensitive = table.CaseSensitive
				End If
				flag = Operators.CompareString(table.Locale.ToString(), table.DataSet.Locale.ToString(), False) <> 0
				If flag Then
					Me.Locale = table.Locale
				End If
				flag = Operators.CompareString(table.[Namespace], table.DataSet.[Namespace], False) <> 0
				If flag Then
					Me.[Namespace] = table.[Namespace]
				End If
				Me.Prefix = table.Prefix
				Me.MinimumCapacity = table.MinimumCapacity
			End Sub

			' Token: 0x0600022B RID: 555 RVA: 0x0000246B File Offset: 0x0000066B
			<DebuggerNonUserCode()>
			Protected Sub New(info As SerializationInfo, context As StreamingContext)
				MyBase.New(info, context)
				dsReport.dtReportDataTable.__ENCList.Add(New WeakReference(Me))
				Me.InitVars()
			End Sub

			' Token: 0x170000E7 RID: 231
			' (get) Token: 0x0600022C RID: 556 RVA: 0x0001E48C File Offset: 0x0001C68C
			<DebuggerNonUserCode()>
			Public ReadOnly Property OBJIDColumn As DataColumn
				Get
					Return Me.columnOBJID
				End Get
			End Property

			' Token: 0x170000E8 RID: 232
			' (get) Token: 0x0600022D RID: 557 RVA: 0x0001D96C File Offset: 0x0001BB6C
			<Browsable(False)>
			<DebuggerNonUserCode()>
			Public ReadOnly Property Count As Integer
				Get
					Return Me.Rows.Count
				End Get
			End Property

			' Token: 0x170000E9 RID: 233
			<DebuggerNonUserCode()>
			Public ReadOnly Default Property Item(index As Integer) As dsReport.dtReportRow
				Get
					Return CType(Me.Rows(index), dsReport.dtReportRow)
				End Get
			End Property

			' Token: 0x14000005 RID: 5
			' (add) Token: 0x0600022F RID: 559 RVA: 0x00002490 File Offset: 0x00000690
			' (remove) Token: 0x06000230 RID: 560 RVA: 0x000024AA File Offset: 0x000006AA
			<DebuggerNonUserCode()>
			Public Event dtReportRowChanging As dsReport.dtReportRowChangeEventHandler

			' Token: 0x14000006 RID: 6
			' (add) Token: 0x06000231 RID: 561 RVA: 0x000024C4 File Offset: 0x000006C4
			' (remove) Token: 0x06000232 RID: 562 RVA: 0x000024DE File Offset: 0x000006DE
			<DebuggerNonUserCode()>
			Public Event dtReportRowChanged As dsReport.dtReportRowChangeEventHandler

			' Token: 0x14000007 RID: 7
			' (add) Token: 0x06000233 RID: 563 RVA: 0x000024F8 File Offset: 0x000006F8
			' (remove) Token: 0x06000234 RID: 564 RVA: 0x00002512 File Offset: 0x00000712
			<DebuggerNonUserCode()>
			Public Event dtReportRowDeleting As dsReport.dtReportRowChangeEventHandler

			' Token: 0x14000008 RID: 8
			' (add) Token: 0x06000235 RID: 565 RVA: 0x0000252C File Offset: 0x0000072C
			' (remove) Token: 0x06000236 RID: 566 RVA: 0x00002546 File Offset: 0x00000746
			<DebuggerNonUserCode()>
			Public Event dtReportRowDeleted As dsReport.dtReportRowChangeEventHandler

			' Token: 0x06000237 RID: 567 RVA: 0x00002309 File Offset: 0x00000509
			<DebuggerNonUserCode()>
			Public Sub AdddtReportRow(row As dsReport.dtReportRow)
				Me.Rows.Add(row)
			End Sub

			' Token: 0x06000238 RID: 568 RVA: 0x0001E4C8 File Offset: 0x0001C6C8
			<DebuggerNonUserCode()>
			Public Function AdddtReportRow(OBJID As String) As dsReport.dtReportRow
				Dim dtReportRow As dsReport.dtReportRow = CType(Me.NewRow(), dsReport.dtReportRow)
				Dim array As Object() = New Object() { OBJID }
				dtReportRow.ItemArray = array
				Me.Rows.Add(dtReportRow)
				Return dtReportRow
			End Function

			' Token: 0x06000239 RID: 569 RVA: 0x0001D9F0 File Offset: 0x0001BBF0
			<DebuggerNonUserCode()>
			Public Overridable Function GetEnumerator() As IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
				Return Me.Rows.GetEnumerator()
			End Function

			' Token: 0x0600023A RID: 570 RVA: 0x0001E50C File Offset: 0x0001C70C
			<DebuggerNonUserCode()>
			Public Overrides Function Clone() As DataTable
				Dim dtReportDataTable As dsReport.dtReportDataTable = CType(MyBase.Clone(), dsReport.dtReportDataTable)
				dtReportDataTable.InitVars()
				Return dtReportDataTable
			End Function

			' Token: 0x0600023B RID: 571 RVA: 0x0001E534 File Offset: 0x0001C734
			<DebuggerNonUserCode()>
			Protected Overrides Function CreateInstance() As DataTable
				Return New dsReport.dtReportDataTable()
			End Function

			' Token: 0x0600023C RID: 572 RVA: 0x00002560 File Offset: 0x00000760
			<DebuggerNonUserCode()>
			Friend Sub InitVars()
				Me.columnOBJID = MyBase.Columns("OBJID")
			End Sub

			' Token: 0x0600023D RID: 573 RVA: 0x0000257A File Offset: 0x0000077A
			<DebuggerNonUserCode()>
			Private Sub InitClass()
				Me.columnOBJID = New DataColumn("OBJID", GetType(String), Nothing, MappingType.Element)
				MyBase.Columns.Add(Me.columnOBJID)
			End Sub

			' Token: 0x0600023E RID: 574 RVA: 0x0001E54C File Offset: 0x0001C74C
			<DebuggerNonUserCode()>
			Public Function NewdtReportRow() As dsReport.dtReportRow
				Return CType(Me.NewRow(), dsReport.dtReportRow)
			End Function

			' Token: 0x0600023F RID: 575 RVA: 0x0001E56C File Offset: 0x0001C76C
			<DebuggerNonUserCode()>
			Protected Overrides Function NewRowFromBuilder(builder As DataRowBuilder) As DataRow
				Return New dsReport.dtReportRow(builder)
			End Function

			' Token: 0x06000240 RID: 576 RVA: 0x0001E584 File Offset: 0x0001C784
			<DebuggerNonUserCode()>
			Protected Overrides Function GetRowType() As Type
				Return GetType(dsReport.dtReportRow)
			End Function

			' Token: 0x06000241 RID: 577 RVA: 0x0001E5A0 File Offset: 0x0001C7A0
			<DebuggerNonUserCode()>
			Protected Overrides Sub OnRowChanged(e As DataRowChangeEventArgs)
				MyBase.OnRowChanged(e)
				Dim flag As Boolean = Me.dtReportRowChangedEvent IsNot Nothing
				If flag Then
					Dim dtReportRowChangeEventHandler As dsReport.dtReportRowChangeEventHandler = Me.dtReportRowChangedEvent
					flag = dtReportRowChangeEventHandler IsNot Nothing
					If flag Then
						dtReportRowChangeEventHandler(Me, New dsReport.dtReportRowChangeEvent(CType(e.Row, dsReport.dtReportRow), e.Action))
					End If
				End If
			End Sub

			' Token: 0x06000242 RID: 578 RVA: 0x0001E5F8 File Offset: 0x0001C7F8
			<DebuggerNonUserCode()>
			Protected Overrides Sub OnRowChanging(e As DataRowChangeEventArgs)
				MyBase.OnRowChanging(e)
				Dim flag As Boolean = Me.dtReportRowChangingEvent IsNot Nothing
				If flag Then
					Dim dtReportRowChangeEventHandler As dsReport.dtReportRowChangeEventHandler = Me.dtReportRowChangingEvent
					flag = dtReportRowChangeEventHandler IsNot Nothing
					If flag Then
						dtReportRowChangeEventHandler(Me, New dsReport.dtReportRowChangeEvent(CType(e.Row, dsReport.dtReportRow), e.Action))
					End If
				End If
			End Sub

			' Token: 0x06000243 RID: 579 RVA: 0x0001E650 File Offset: 0x0001C850
			<DebuggerNonUserCode()>
			Protected Overrides Sub OnRowDeleted(e As DataRowChangeEventArgs)
				MyBase.OnRowDeleted(e)
				Dim flag As Boolean = Me.dtReportRowDeletedEvent IsNot Nothing
				If flag Then
					Dim dtReportRowChangeEventHandler As dsReport.dtReportRowChangeEventHandler = Me.dtReportRowDeletedEvent
					flag = dtReportRowChangeEventHandler IsNot Nothing
					If flag Then
						dtReportRowChangeEventHandler(Me, New dsReport.dtReportRowChangeEvent(CType(e.Row, dsReport.dtReportRow), e.Action))
					End If
				End If
			End Sub

			' Token: 0x06000244 RID: 580 RVA: 0x0001E6A8 File Offset: 0x0001C8A8
			<DebuggerNonUserCode()>
			Protected Overrides Sub OnRowDeleting(e As DataRowChangeEventArgs)
				MyBase.OnRowDeleting(e)
				Dim flag As Boolean = Me.dtReportRowDeletingEvent IsNot Nothing
				If flag Then
					Dim dtReportRowChangeEventHandler As dsReport.dtReportRowChangeEventHandler = Me.dtReportRowDeletingEvent
					flag = dtReportRowChangeEventHandler IsNot Nothing
					If flag Then
						dtReportRowChangeEventHandler(Me, New dsReport.dtReportRowChangeEvent(CType(e.Row, dsReport.dtReportRow), e.Action))
					End If
				End If
			End Sub

			' Token: 0x06000245 RID: 581 RVA: 0x00002366 File Offset: 0x00000566
			<DebuggerNonUserCode()>
			Public Sub RemovedtReportRow(row As dsReport.dtReportRow)
				Me.Rows.Remove(row)
			End Sub

			' Token: 0x06000246 RID: 582 RVA: 0x0001E700 File Offset: 0x0001C900
			<DebuggerNonUserCode()>
			Public Shared Function GetTypedTableSchema(xs As XmlSchemaSet) As XmlSchemaComplexType
				Dim xmlSchemaComplexType As XmlSchemaComplexType = New XmlSchemaComplexType()
				Dim xmlSchemaSequence As XmlSchemaSequence = New XmlSchemaSequence()
				Dim dsReport As dsReport = New dsReport()
				Dim xmlSchemaAny As XmlSchemaAny = New XmlSchemaAny()
				xmlSchemaAny.[Namespace] = "http://www.w3.org/2001/XMLSchema"
				Dim xmlSchemaParticle As XmlSchemaParticle = xmlSchemaAny
				Dim num As Decimal = 0D
				xmlSchemaParticle.MinOccurs = num
				xmlSchemaAny.MaxOccurs = Decimal.MaxValue
				xmlSchemaAny.ProcessContents = XmlSchemaContentProcessing.Lax
				xmlSchemaSequence.Items.Add(xmlSchemaAny)
				Dim xmlSchemaAny2 As XmlSchemaAny = New XmlSchemaAny()
				xmlSchemaAny2.[Namespace] = "urn:schemas-microsoft-com:xml-diffgram-v1"
				Dim xmlSchemaParticle2 As XmlSchemaParticle = xmlSchemaAny2
				num = 1D
				xmlSchemaParticle2.MinOccurs = num
				xmlSchemaAny2.ProcessContents = XmlSchemaContentProcessing.Lax
				xmlSchemaSequence.Items.Add(xmlSchemaAny2)
				Dim xmlSchemaAttribute As XmlSchemaAttribute = New XmlSchemaAttribute()
				xmlSchemaAttribute.Name = "namespace"
				xmlSchemaAttribute.FixedValue = dsReport.[Namespace]
				xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute)
				Dim xmlSchemaAttribute2 As XmlSchemaAttribute = New XmlSchemaAttribute()
				xmlSchemaAttribute2.Name = "tableTypeName"
				xmlSchemaAttribute2.FixedValue = "dtReportDataTable"
				xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute2)
				xmlSchemaComplexType.Particle = xmlSchemaSequence
				Dim schemaSerializable As XmlSchema = dsReport.GetSchemaSerializable()
				Dim flag As Boolean = xs.Contains(schemaSerializable.TargetNamespace)
				If flag Then
					Dim memoryStream As MemoryStream = New MemoryStream()
					Dim memoryStream2 As MemoryStream = New MemoryStream()
					Try
						schemaSerializable.Write(memoryStream)
						For Each obj As Object In xs.Schemas(schemaSerializable.TargetNamespace)
							Dim xmlSchema As XmlSchema = CType(obj, XmlSchema)
							memoryStream2.SetLength(0L)
							xmlSchema.Write(memoryStream2)
							flag = memoryStream.Length = memoryStream2.Length
							If flag Then
								memoryStream.Position = 0L
								memoryStream2.Position = 0L
								While memoryStream.Position <> memoryStream.Length AndAlso memoryStream.ReadByte() = memoryStream2.ReadByte()
								End While
								flag = memoryStream.Position = memoryStream.Length
								If flag Then
									Return xmlSchemaComplexType
								End If
							End If
						Next
					Finally
						flag = memoryStream IsNot Nothing
						If flag Then
							memoryStream.Close()
						End If
						flag = memoryStream2 IsNot Nothing
						If flag Then
							memoryStream2.Close()
						End If
					End Try
				End If
				xs.Add(schemaSerializable)
				Return xmlSchemaComplexType
			End Function

			' Token: 0x040000F5 RID: 245
			Private Shared __ENCList As ArrayList = New ArrayList()

			' Token: 0x040000F6 RID: 246
			Private columnOBJID As DataColumn
		End Class

		' Token: 0x02000013 RID: 19
		<GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")>
		Public Class dtReportRow
			Inherits DataRow

			' Token: 0x06000247 RID: 583 RVA: 0x000025AC File Offset: 0x000007AC
			<DebuggerNonUserCode()>
			Friend Sub New(rb As DataRowBuilder)
				MyBase.New(rb)
				Me.tabledtReport = CType(Me.Table, dsReport.dtReportDataTable)
			End Sub

			' Token: 0x170000EA RID: 234
			' (get) Token: 0x06000248 RID: 584 RVA: 0x0001E974 File Offset: 0x0001CB74
			' (set) Token: 0x06000249 RID: 585 RVA: 0x000025C9 File Offset: 0x000007C9
			<DebuggerNonUserCode()>
			Public Property OBJID As String
				Get
					Dim text As String
					Try
						text = Conversions.ToString(Me(Me.tabledtReport.OBJIDColumn))
					Catch ex As InvalidCastException
						Throw New StrongTypingException("The value for column 'OBJID' in table 'dtReport' is DBNull.", ex)
					End Try
					Return text
				End Get
				Set(value As String)
					Me(Me.tabledtReport.OBJIDColumn) = value
				End Set
			End Property

			' Token: 0x0600024A RID: 586 RVA: 0x0001E9CC File Offset: 0x0001CBCC
			<DebuggerNonUserCode()>
			Public Function IsOBJIDNull() As Boolean
				Return Me.IsNull(Me.tabledtReport.OBJIDColumn)
			End Function

			' Token: 0x0600024B RID: 587 RVA: 0x000025E0 File Offset: 0x000007E0
			<DebuggerNonUserCode()>
			Public Sub SetOBJIDNull()
				Me(Me.tabledtReport.OBJIDColumn) = RuntimeHelpers.GetObjectValue(Convert.DBNull)
			End Sub

			' Token: 0x040000FB RID: 251
			Private tabledtReport As dsReport.dtReportDataTable
		End Class

		' Token: 0x02000014 RID: 20
		<GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")>
		Public Class dtReportRowChangeEvent
			Inherits EventArgs

			' Token: 0x0600024C RID: 588 RVA: 0x00002600 File Offset: 0x00000800
			<DebuggerNonUserCode()>
			Public Sub New(row As dsReport.dtReportRow, action As DataRowAction)
				Me.eventRow = row
				Me.eventAction = action
			End Sub

			' Token: 0x170000EB RID: 235
			' (get) Token: 0x0600024D RID: 589 RVA: 0x0001E9F0 File Offset: 0x0001CBF0
			<DebuggerNonUserCode()>
			Public ReadOnly Property Row As dsReport.dtReportRow
				Get
					Return Me.eventRow
				End Get
			End Property

			' Token: 0x170000EC RID: 236
			' (get) Token: 0x0600024E RID: 590 RVA: 0x0001EA08 File Offset: 0x0001CC08
			<DebuggerNonUserCode()>
			Public ReadOnly Property Action As DataRowAction
				Get
					Return Me.eventAction
				End Get
			End Property

			' Token: 0x040000FC RID: 252
			Private eventRow As dsReport.dtReportRow

			' Token: 0x040000FD RID: 253
			Private eventAction As DataRowAction
		End Class
	End Class
End Namespace
