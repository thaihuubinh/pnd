﻿Namespace prjIS_SalesPOS
	' Token: 0x02000026 RID: 38
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmcolorsetting
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060006F4 RID: 1780 RVA: 0x00052F3C File Offset: 0x0005113C
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060006F5 RID: 1781 RVA: 0x00052F74 File Offset: 0x00051174
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmcolorsetting))
			Me.btnok = New Global.System.Windows.Forms.Button()
			Me.Tblpanelcolor = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btncolor8 = New Global.System.Windows.Forms.Button()
			Me.btncolor22 = New Global.System.Windows.Forms.Button()
			Me.btncolor38 = New Global.System.Windows.Forms.Button()
			Me.btncolor39 = New Global.System.Windows.Forms.Button()
			Me.btncolor1 = New Global.System.Windows.Forms.Button()
			Me.btncolor40 = New Global.System.Windows.Forms.Button()
			Me.btncolor2 = New Global.System.Windows.Forms.Button()
			Me.btncolor33 = New Global.System.Windows.Forms.Button()
			Me.btncolor37 = New Global.System.Windows.Forms.Button()
			Me.btncolor3 = New Global.System.Windows.Forms.Button()
			Me.btncolor36 = New Global.System.Windows.Forms.Button()
			Me.btncolor5 = New Global.System.Windows.Forms.Button()
			Me.btncolor35 = New Global.System.Windows.Forms.Button()
			Me.btncolor6 = New Global.System.Windows.Forms.Button()
			Me.btncolor30 = New Global.System.Windows.Forms.Button()
			Me.btncolor31 = New Global.System.Windows.Forms.Button()
			Me.btncolor9 = New Global.System.Windows.Forms.Button()
			Me.btncolor32 = New Global.System.Windows.Forms.Button()
			Me.btncolor10 = New Global.System.Windows.Forms.Button()
			Me.btncolor29 = New Global.System.Windows.Forms.Button()
			Me.btncolor14 = New Global.System.Windows.Forms.Button()
			Me.btncolor28 = New Global.System.Windows.Forms.Button()
			Me.btncolor11 = New Global.System.Windows.Forms.Button()
			Me.btncolor27 = New Global.System.Windows.Forms.Button()
			Me.btncolor12 = New Global.System.Windows.Forms.Button()
			Me.btncolor26 = New Global.System.Windows.Forms.Button()
			Me.btncolor13 = New Global.System.Windows.Forms.Button()
			Me.btncolor25 = New Global.System.Windows.Forms.Button()
			Me.btncolor16 = New Global.System.Windows.Forms.Button()
			Me.btncolor15 = New Global.System.Windows.Forms.Button()
			Me.btncolor20 = New Global.System.Windows.Forms.Button()
			Me.btncolor17 = New Global.System.Windows.Forms.Button()
			Me.btncolor18 = New Global.System.Windows.Forms.Button()
			Me.btncolor21 = New Global.System.Windows.Forms.Button()
			Me.btncolor19 = New Global.System.Windows.Forms.Button()
			Me.btncolor34 = New Global.System.Windows.Forms.Button()
			Me.btncolor4 = New Global.System.Windows.Forms.Button()
			Me.btncolor23 = New Global.System.Windows.Forms.Button()
			Me.btncolor24 = New Global.System.Windows.Forms.Button()
			Me.btncolor7 = New Global.System.Windows.Forms.Button()
			Me.btncancel = New Global.System.Windows.Forms.Button()
			Me.ChkDefault = New Global.System.Windows.Forms.CheckBox()
			Me.grpApdung = New Global.System.Windows.Forms.GroupBox()
			Me.rdoAll = New Global.System.Windows.Forms.RadioButton()
			Me.rdoNhom = New Global.System.Windows.Forms.RadioButton()
			Me.rdoMon = New Global.System.Windows.Forms.RadioButton()
			Me.Tblpanelcolor.SuspendLayout()
			Me.grpApdung.SuspendLayout()
			Me.SuspendLayout()
			Me.btnok.BackColor = Global.System.Drawing.Color.Transparent
			Me.btnok.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.stripe
			Me.btnok.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnok.Font = New Global.System.Drawing.Font("Arial", 18F)
			Me.btnok.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnok.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Me.btnok.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim btnok As Global.System.Windows.Forms.Control = Me.btnok
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(241, 363)
			btnok.Location = point
			Me.btnok.Name = "btnok"
			Dim btnok2 As Global.System.Windows.Forms.Control = Me.btnok
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(114, 48)
			btnok2.Size = size
			Me.btnok.TabIndex = 47
			Me.btnok.Tag = "NC018R0003"
			Me.btnok.Text = "Chọn"
			Me.btnok.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnok.UseCompatibleTextRendering = True
			Me.btnok.UseVisualStyleBackColor = False
			Me.Tblpanelcolor.ColumnCount = 8
			Me.Tblpanelcolor.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 12.5F))
			Me.Tblpanelcolor.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 12.5F))
			Me.Tblpanelcolor.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 12.5F))
			Me.Tblpanelcolor.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 12.5F))
			Me.Tblpanelcolor.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 12.5F))
			Me.Tblpanelcolor.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 12.5F))
			Me.Tblpanelcolor.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 12.5F))
			Me.Tblpanelcolor.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 12.5F))
			Me.Tblpanelcolor.Controls.Add(Me.btncolor8, 6, 0)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor22, 5, 2)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor38, 5, 4)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor39, 7, 4)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor1, 0, 0)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor40, 6, 4)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor2, 1, 0)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor33, 0, 4)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor37, 4, 4)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor3, 2, 0)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor36, 3, 4)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor5, 4, 0)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor35, 1, 4)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor6, 5, 0)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor30, 5, 3)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor31, 7, 3)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor9, 0, 1)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor32, 6, 3)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor10, 1, 1)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor29, 4, 3)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor14, 5, 1)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor28, 3, 3)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor11, 2, 1)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor27, 2, 3)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor12, 3, 1)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor26, 1, 3)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor13, 4, 1)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor25, 0, 3)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor16, 6, 1)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor15, 7, 1)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor20, 3, 2)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor17, 0, 2)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor18, 1, 2)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor21, 4, 2)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor19, 2, 2)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor34, 2, 4)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor4, 3, 0)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor23, 7, 2)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor24, 6, 2)
			Me.Tblpanelcolor.Controls.Add(Me.btncolor7, 7, 0)
			Dim tblpanelcolor As Global.System.Windows.Forms.Control = Me.Tblpanelcolor
			point = New Global.System.Drawing.Point(3, 3)
			tblpanelcolor.Location = point
			Me.Tblpanelcolor.Name = "Tblpanelcolor"
			Me.Tblpanelcolor.RowCount = 5
			Me.Tblpanelcolor.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.Tblpanelcolor.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.Tblpanelcolor.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.Tblpanelcolor.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.Tblpanelcolor.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Dim tblpanelcolor2 As Global.System.Windows.Forms.Control = Me.Tblpanelcolor
			size = New Global.System.Drawing.Size(480, 295)
			tblpanelcolor2.Size = size
			Me.Tblpanelcolor.TabIndex = 50
			Me.btncolor8.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor8.BackColor = Global.System.Drawing.Color.FromArgb(51, 51, 153)
			Me.btncolor8.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor8.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor As Global.System.Windows.Forms.Control = Me.btncolor8
			point = New Global.System.Drawing.Point(363, 3)
			btncolor.Location = point
			Me.btncolor8.Name = "btncolor8"
			Dim btncolor2 As Global.System.Windows.Forms.Control = Me.btncolor8
			size = New Global.System.Drawing.Size(54, 53)
			btncolor2.Size = size
			Me.btncolor8.TabIndex = 81
			Me.btncolor8.UseVisualStyleBackColor = False
			Me.btncolor22.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor22.BackColor = Global.System.Drawing.Color.FromArgb(51, 102, 255)
			Me.btncolor22.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor22.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor3 As Global.System.Windows.Forms.Control = Me.btncolor22
			point = New Global.System.Drawing.Point(303, 121)
			btncolor3.Location = point
			Me.btncolor22.Name = "btncolor22"
			Dim btncolor4 As Global.System.Windows.Forms.Control = Me.btncolor22
			size = New Global.System.Drawing.Size(54, 53)
			btncolor4.Size = size
			Me.btncolor22.TabIndex = 80
			Me.btncolor22.UseVisualStyleBackColor = False
			Me.btncolor38.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor38.BackColor = Global.System.Drawing.Color.FromArgb(153, 204, 255)
			Me.btncolor38.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor38.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor5 As Global.System.Windows.Forms.Control = Me.btncolor38
			point = New Global.System.Drawing.Point(303, 239)
			btncolor5.Location = point
			Me.btncolor38.Name = "btncolor38"
			Dim btncolor6 As Global.System.Windows.Forms.Control = Me.btncolor38
			size = New Global.System.Drawing.Size(54, 53)
			btncolor6.Size = size
			Me.btncolor38.TabIndex = 79
			Me.btncolor38.UseVisualStyleBackColor = False
			Me.btncolor39.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor39.BackColor = Global.System.Drawing.Color.White
			Me.btncolor39.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor39.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor7 As Global.System.Windows.Forms.Control = Me.btncolor39
			point = New Global.System.Drawing.Point(423, 239)
			btncolor7.Location = point
			Me.btncolor39.Name = "btncolor39"
			Dim btncolor8 As Global.System.Windows.Forms.Control = Me.btncolor39
			size = New Global.System.Drawing.Size(54, 53)
			btncolor8.Size = size
			Me.btncolor39.TabIndex = 78
			Me.btncolor39.UseVisualStyleBackColor = False
			Me.btncolor1.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor1.BackColor = Global.System.Drawing.Color.Black
			Me.btncolor1.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor1.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor9 As Global.System.Windows.Forms.Control = Me.btncolor1
			point = New Global.System.Drawing.Point(3, 3)
			btncolor9.Location = point
			Me.btncolor1.Name = "btncolor1"
			Dim btncolor10 As Global.System.Windows.Forms.Control = Me.btncolor1
			size = New Global.System.Drawing.Size(54, 53)
			btncolor10.Size = size
			Me.btncolor1.TabIndex = 40
			Me.btncolor1.UseVisualStyleBackColor = False
			Me.btncolor40.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor40.BackColor = Global.System.Drawing.Color.FromArgb(204, 153, 255)
			Me.btncolor40.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor40.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor11 As Global.System.Windows.Forms.Control = Me.btncolor40
			point = New Global.System.Drawing.Point(363, 239)
			btncolor11.Location = point
			Me.btncolor40.Name = "btncolor40"
			Dim btncolor12 As Global.System.Windows.Forms.Control = Me.btncolor40
			size = New Global.System.Drawing.Size(54, 53)
			btncolor12.Size = size
			Me.btncolor40.TabIndex = 77
			Me.btncolor40.UseVisualStyleBackColor = False
			Me.btncolor2.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor2.BackColor = Global.System.Drawing.Color.FromArgb(153, 51, 0)
			Me.btncolor2.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor2.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor13 As Global.System.Windows.Forms.Control = Me.btncolor2
			point = New Global.System.Drawing.Point(63, 3)
			btncolor13.Location = point
			Me.btncolor2.Name = "btncolor2"
			Dim btncolor14 As Global.System.Windows.Forms.Control = Me.btncolor2
			size = New Global.System.Drawing.Size(54, 53)
			btncolor14.Size = size
			Me.btncolor2.TabIndex = 41
			Me.btncolor2.UseVisualStyleBackColor = False
			Me.btncolor33.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor33.BackColor = Global.System.Drawing.Color.FromArgb(255, 153, 204)
			Me.btncolor33.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor33.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor15 As Global.System.Windows.Forms.Control = Me.btncolor33
			point = New Global.System.Drawing.Point(3, 239)
			btncolor15.Location = point
			Me.btncolor33.Name = "btncolor33"
			Dim btncolor16 As Global.System.Windows.Forms.Control = Me.btncolor33
			size = New Global.System.Drawing.Size(54, 53)
			btncolor16.Size = size
			Me.btncolor33.TabIndex = 72
			Me.btncolor33.UseVisualStyleBackColor = False
			Me.btncolor37.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor37.BackColor = Global.System.Drawing.Color.FromArgb(204, 255, 255)
			Me.btncolor37.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor37.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor17 As Global.System.Windows.Forms.Control = Me.btncolor37
			point = New Global.System.Drawing.Point(243, 239)
			btncolor17.Location = point
			Me.btncolor37.Name = "btncolor37"
			Dim btncolor18 As Global.System.Windows.Forms.Control = Me.btncolor37
			size = New Global.System.Drawing.Size(54, 53)
			btncolor18.Size = size
			Me.btncolor37.TabIndex = 76
			Me.btncolor37.UseVisualStyleBackColor = False
			Me.btncolor3.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor3.BackColor = Global.System.Drawing.Color.FromArgb(51, 51, 0)
			Me.btncolor3.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor3.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor19 As Global.System.Windows.Forms.Control = Me.btncolor3
			point = New Global.System.Drawing.Point(123, 3)
			btncolor19.Location = point
			Me.btncolor3.Name = "btncolor3"
			Dim btncolor20 As Global.System.Windows.Forms.Control = Me.btncolor3
			size = New Global.System.Drawing.Size(54, 53)
			btncolor20.Size = size
			Me.btncolor3.TabIndex = 42
			Me.btncolor3.UseVisualStyleBackColor = False
			Me.btncolor36.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor36.BackColor = Global.System.Drawing.Color.FromArgb(204, 255, 204)
			Me.btncolor36.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor36.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor21 As Global.System.Windows.Forms.Control = Me.btncolor36
			point = New Global.System.Drawing.Point(183, 239)
			btncolor21.Location = point
			Me.btncolor36.Name = "btncolor36"
			Dim btncolor22 As Global.System.Windows.Forms.Control = Me.btncolor36
			size = New Global.System.Drawing.Size(54, 53)
			btncolor22.Size = size
			Me.btncolor36.TabIndex = 75
			Me.btncolor36.UseVisualStyleBackColor = False
			Me.btncolor5.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor5.BackColor = Global.System.Drawing.Color.FromArgb(0, 51, 102)
			Me.btncolor5.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor5.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor23 As Global.System.Windows.Forms.Control = Me.btncolor5
			point = New Global.System.Drawing.Point(243, 3)
			btncolor23.Location = point
			Me.btncolor5.Name = "btncolor5"
			Dim btncolor24 As Global.System.Windows.Forms.Control = Me.btncolor5
			size = New Global.System.Drawing.Size(54, 53)
			btncolor24.Size = size
			Me.btncolor5.TabIndex = 44
			Me.btncolor5.UseVisualStyleBackColor = False
			Me.btncolor35.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor35.BackColor = Global.System.Drawing.Color.FromArgb(255, 204, 153)
			Me.btncolor35.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor35.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor25 As Global.System.Windows.Forms.Control = Me.btncolor35
			point = New Global.System.Drawing.Point(63, 239)
			btncolor25.Location = point
			Me.btncolor35.Name = "btncolor35"
			Dim btncolor26 As Global.System.Windows.Forms.Control = Me.btncolor35
			size = New Global.System.Drawing.Size(54, 53)
			btncolor26.Size = size
			Me.btncolor35.TabIndex = 74
			Me.btncolor35.UseVisualStyleBackColor = False
			Me.btncolor6.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor6.BackColor = Global.System.Drawing.Color.Navy
			Me.btncolor6.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor6.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor27 As Global.System.Windows.Forms.Control = Me.btncolor6
			point = New Global.System.Drawing.Point(303, 3)
			btncolor27.Location = point
			Me.btncolor6.Name = "btncolor6"
			Dim btncolor28 As Global.System.Windows.Forms.Control = Me.btncolor6
			size = New Global.System.Drawing.Size(54, 53)
			btncolor28.Size = size
			Me.btncolor6.TabIndex = 47
			Me.btncolor6.UseVisualStyleBackColor = False
			Me.btncolor30.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor30.BackColor = Global.System.Drawing.Color.FromArgb(0, 204, 255)
			Me.btncolor30.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor30.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor29 As Global.System.Windows.Forms.Control = Me.btncolor30
			point = New Global.System.Drawing.Point(303, 180)
			btncolor29.Location = point
			Me.btncolor30.Name = "btncolor30"
			Dim btncolor30 As Global.System.Windows.Forms.Control = Me.btncolor30
			size = New Global.System.Drawing.Size(54, 53)
			btncolor30.Size = size
			Me.btncolor30.TabIndex = 71
			Me.btncolor30.UseVisualStyleBackColor = False
			Me.btncolor31.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor31.BackColor = Global.System.Drawing.Color.Silver
			Me.btncolor31.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor31.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor31 As Global.System.Windows.Forms.Control = Me.btncolor31
			point = New Global.System.Drawing.Point(423, 180)
			btncolor31.Location = point
			Me.btncolor31.Name = "btncolor31"
			Dim btncolor32 As Global.System.Windows.Forms.Control = Me.btncolor31
			size = New Global.System.Drawing.Size(54, 53)
			btncolor32.Size = size
			Me.btncolor31.TabIndex = 70
			Me.btncolor31.UseVisualStyleBackColor = False
			Me.btncolor9.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor9.BackColor = Global.System.Drawing.Color.Maroon
			Me.btncolor9.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor9.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor33 As Global.System.Windows.Forms.Control = Me.btncolor9
			point = New Global.System.Drawing.Point(3, 62)
			btncolor33.Location = point
			Me.btncolor9.Name = "btncolor9"
			Dim btncolor34 As Global.System.Windows.Forms.Control = Me.btncolor9
			size = New Global.System.Drawing.Size(54, 53)
			btncolor34.Size = size
			Me.btncolor9.TabIndex = 48
			Me.btncolor9.UseVisualStyleBackColor = False
			Me.btncolor32.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor32.BackColor = Global.System.Drawing.Color.FromArgb(153, 51, 102)
			Me.btncolor32.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor32.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor35 As Global.System.Windows.Forms.Control = Me.btncolor32
			point = New Global.System.Drawing.Point(363, 180)
			btncolor35.Location = point
			Me.btncolor32.Name = "btncolor32"
			Dim btncolor36 As Global.System.Windows.Forms.Control = Me.btncolor32
			size = New Global.System.Drawing.Size(54, 53)
			btncolor36.Size = size
			Me.btncolor32.TabIndex = 69
			Me.btncolor32.UseVisualStyleBackColor = False
			Me.btncolor10.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor10.BackColor = Global.System.Drawing.Color.FromArgb(255, 102, 0)
			Me.btncolor10.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor10.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor37 As Global.System.Windows.Forms.Control = Me.btncolor10
			point = New Global.System.Drawing.Point(63, 62)
			btncolor37.Location = point
			Me.btncolor10.Name = "btncolor10"
			Dim btncolor38 As Global.System.Windows.Forms.Control = Me.btncolor10
			size = New Global.System.Drawing.Size(54, 53)
			btncolor38.Size = size
			Me.btncolor10.TabIndex = 49
			Me.btncolor10.UseVisualStyleBackColor = False
			Me.btncolor29.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor29.BackColor = Global.System.Drawing.Color.Cyan
			Me.btncolor29.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor29.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor39 As Global.System.Windows.Forms.Control = Me.btncolor29
			point = New Global.System.Drawing.Point(243, 180)
			btncolor39.Location = point
			Me.btncolor29.Name = "btncolor29"
			Dim btncolor40 As Global.System.Windows.Forms.Control = Me.btncolor29
			size = New Global.System.Drawing.Size(54, 53)
			btncolor40.Size = size
			Me.btncolor29.TabIndex = 68
			Me.btncolor29.UseVisualStyleBackColor = False
			Me.btncolor14.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor14.BackColor = Global.System.Drawing.Color.Blue
			Me.btncolor14.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor14.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor41 As Global.System.Windows.Forms.Control = Me.btncolor14
			point = New Global.System.Drawing.Point(303, 62)
			btncolor41.Location = point
			Me.btncolor14.Name = "btncolor14"
			Dim btncolor42 As Global.System.Windows.Forms.Control = Me.btncolor14
			size = New Global.System.Drawing.Size(54, 53)
			btncolor42.Size = size
			Me.btncolor14.TabIndex = 55
			Me.btncolor14.UseVisualStyleBackColor = False
			Me.btncolor28.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor28.BackColor = Global.System.Drawing.Color.Lime
			Me.btncolor28.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor28.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor43 As Global.System.Windows.Forms.Control = Me.btncolor28
			point = New Global.System.Drawing.Point(183, 180)
			btncolor43.Location = point
			Me.btncolor28.Name = "btncolor28"
			Dim btncolor44 As Global.System.Windows.Forms.Control = Me.btncolor28
			size = New Global.System.Drawing.Size(54, 53)
			btncolor44.Size = size
			Me.btncolor28.TabIndex = 67
			Me.btncolor28.UseVisualStyleBackColor = False
			Me.btncolor11.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor11.BackColor = Global.System.Drawing.Color.Olive
			Me.btncolor11.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor11.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor45 As Global.System.Windows.Forms.Control = Me.btncolor11
			point = New Global.System.Drawing.Point(123, 62)
			btncolor45.Location = point
			Me.btncolor11.Name = "btncolor11"
			Dim btncolor46 As Global.System.Windows.Forms.Control = Me.btncolor11
			size = New Global.System.Drawing.Size(54, 53)
			btncolor46.Size = size
			Me.btncolor11.TabIndex = 50
			Me.btncolor11.UseVisualStyleBackColor = False
			Me.btncolor27.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor27.BackColor = Global.System.Drawing.Color.Yellow
			Me.btncolor27.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor27.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor47 As Global.System.Windows.Forms.Control = Me.btncolor27
			point = New Global.System.Drawing.Point(123, 180)
			btncolor47.Location = point
			Me.btncolor27.Name = "btncolor27"
			Dim btncolor48 As Global.System.Windows.Forms.Control = Me.btncolor27
			size = New Global.System.Drawing.Size(54, 53)
			btncolor48.Size = size
			Me.btncolor27.TabIndex = 66
			Me.btncolor27.UseVisualStyleBackColor = False
			Me.btncolor12.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor12.BackColor = Global.System.Drawing.Color.Green
			Me.btncolor12.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor12.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor49 As Global.System.Windows.Forms.Control = Me.btncolor12
			point = New Global.System.Drawing.Point(183, 62)
			btncolor49.Location = point
			Me.btncolor12.Name = "btncolor12"
			Dim btncolor50 As Global.System.Windows.Forms.Control = Me.btncolor12
			size = New Global.System.Drawing.Size(54, 53)
			btncolor50.Size = size
			Me.btncolor12.TabIndex = 51
			Me.btncolor12.UseVisualStyleBackColor = False
			Me.btncolor26.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor26.BackColor = Global.System.Drawing.Color.FromArgb(255, 204, 0)
			Me.btncolor26.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor26.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor51 As Global.System.Windows.Forms.Control = Me.btncolor26
			point = New Global.System.Drawing.Point(63, 180)
			btncolor51.Location = point
			Me.btncolor26.Name = "btncolor26"
			Dim btncolor52 As Global.System.Windows.Forms.Control = Me.btncolor26
			size = New Global.System.Drawing.Size(54, 53)
			btncolor52.Size = size
			Me.btncolor26.TabIndex = 65
			Me.btncolor26.UseVisualStyleBackColor = False
			Me.btncolor13.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor13.BackColor = Global.System.Drawing.Color.Teal
			Me.btncolor13.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor13.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor53 As Global.System.Windows.Forms.Control = Me.btncolor13
			point = New Global.System.Drawing.Point(243, 62)
			btncolor53.Location = point
			Me.btncolor13.Name = "btncolor13"
			Dim btncolor54 As Global.System.Windows.Forms.Control = Me.btncolor13
			size = New Global.System.Drawing.Size(54, 53)
			btncolor54.Size = size
			Me.btncolor13.TabIndex = 52
			Me.btncolor13.UseVisualStyleBackColor = False
			Me.btncolor25.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor25.BackColor = Global.System.Drawing.Color.Fuchsia
			Me.btncolor25.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor25.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor55 As Global.System.Windows.Forms.Control = Me.btncolor25
			point = New Global.System.Drawing.Point(3, 180)
			btncolor55.Location = point
			Me.btncolor25.Name = "btncolor25"
			Dim btncolor56 As Global.System.Windows.Forms.Control = Me.btncolor25
			size = New Global.System.Drawing.Size(54, 53)
			btncolor56.Size = size
			Me.btncolor25.TabIndex = 64
			Me.btncolor25.UseVisualStyleBackColor = False
			Me.btncolor16.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor16.BackColor = Global.System.Drawing.Color.FromArgb(102, 102, 153)
			Me.btncolor16.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor16.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor57 As Global.System.Windows.Forms.Control = Me.btncolor16
			point = New Global.System.Drawing.Point(363, 62)
			btncolor57.Location = point
			Me.btncolor16.Name = "btncolor16"
			Dim btncolor58 As Global.System.Windows.Forms.Control = Me.btncolor16
			size = New Global.System.Drawing.Size(54, 53)
			btncolor58.Size = size
			Me.btncolor16.TabIndex = 53
			Me.btncolor16.UseVisualStyleBackColor = False
			Me.btncolor15.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor15.BackColor = Global.System.Drawing.Color.Gray
			Me.btncolor15.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor15.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor59 As Global.System.Windows.Forms.Control = Me.btncolor15
			point = New Global.System.Drawing.Point(423, 62)
			btncolor59.Location = point
			Me.btncolor15.Name = "btncolor15"
			Dim btncolor60 As Global.System.Windows.Forms.Control = Me.btncolor15
			size = New Global.System.Drawing.Size(54, 53)
			btncolor60.Size = size
			Me.btncolor15.TabIndex = 54
			Me.btncolor15.UseVisualStyleBackColor = False
			Me.btncolor20.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor20.BackColor = Global.System.Drawing.Color.FromArgb(51, 153, 102)
			Me.btncolor20.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor20.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor61 As Global.System.Windows.Forms.Control = Me.btncolor20
			point = New Global.System.Drawing.Point(183, 121)
			btncolor61.Location = point
			Me.btncolor20.Name = "btncolor20"
			Dim btncolor62 As Global.System.Windows.Forms.Control = Me.btncolor20
			size = New Global.System.Drawing.Size(54, 53)
			btncolor62.Size = size
			Me.btncolor20.TabIndex = 59
			Me.btncolor20.UseVisualStyleBackColor = False
			Me.btncolor17.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor17.BackColor = Global.System.Drawing.Color.Red
			Me.btncolor17.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor17.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor63 As Global.System.Windows.Forms.Control = Me.btncolor17
			point = New Global.System.Drawing.Point(3, 121)
			btncolor63.Location = point
			Me.btncolor17.Name = "btncolor17"
			Dim btncolor64 As Global.System.Windows.Forms.Control = Me.btncolor17
			size = New Global.System.Drawing.Size(54, 53)
			btncolor64.Size = size
			Me.btncolor17.TabIndex = 56
			Me.btncolor17.UseVisualStyleBackColor = False
			Me.btncolor18.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor18.BackColor = Global.System.Drawing.Color.FromArgb(255, 153, 0)
			Me.btncolor18.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor18.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor65 As Global.System.Windows.Forms.Control = Me.btncolor18
			point = New Global.System.Drawing.Point(63, 121)
			btncolor65.Location = point
			Me.btncolor18.Name = "btncolor18"
			Dim btncolor66 As Global.System.Windows.Forms.Control = Me.btncolor18
			size = New Global.System.Drawing.Size(54, 53)
			btncolor66.Size = size
			Me.btncolor18.TabIndex = 57
			Me.btncolor18.UseVisualStyleBackColor = False
			Me.btncolor21.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor21.BackColor = Global.System.Drawing.Color.FromArgb(51, 204, 204)
			Me.btncolor21.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor21.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor67 As Global.System.Windows.Forms.Control = Me.btncolor21
			point = New Global.System.Drawing.Point(243, 121)
			btncolor67.Location = point
			Me.btncolor21.Name = "btncolor21"
			Dim btncolor68 As Global.System.Windows.Forms.Control = Me.btncolor21
			size = New Global.System.Drawing.Size(54, 53)
			btncolor68.Size = size
			Me.btncolor21.TabIndex = 60
			Me.btncolor21.UseVisualStyleBackColor = False
			Me.btncolor19.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor19.BackColor = Global.System.Drawing.Color.FromArgb(153, 204, 0)
			Me.btncolor19.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor19.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor69 As Global.System.Windows.Forms.Control = Me.btncolor19
			point = New Global.System.Drawing.Point(123, 121)
			btncolor69.Location = point
			Me.btncolor19.Name = "btncolor19"
			Dim btncolor70 As Global.System.Windows.Forms.Control = Me.btncolor19
			size = New Global.System.Drawing.Size(54, 53)
			btncolor70.Size = size
			Me.btncolor19.TabIndex = 58
			Me.btncolor19.UseVisualStyleBackColor = False
			Me.btncolor34.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor34.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 153)
			Me.btncolor34.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor34.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor71 As Global.System.Windows.Forms.Control = Me.btncolor34
			point = New Global.System.Drawing.Point(123, 239)
			btncolor71.Location = point
			Me.btncolor34.Name = "btncolor34"
			Dim btncolor72 As Global.System.Windows.Forms.Control = Me.btncolor34
			size = New Global.System.Drawing.Size(54, 53)
			btncolor72.Size = size
			Me.btncolor34.TabIndex = 73
			Me.btncolor34.UseVisualStyleBackColor = False
			Me.btncolor4.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor4.BackColor = Global.System.Drawing.Color.FromArgb(0, 51, 0)
			Me.btncolor4.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor4.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor73 As Global.System.Windows.Forms.Control = Me.btncolor4
			point = New Global.System.Drawing.Point(183, 3)
			btncolor73.Location = point
			Me.btncolor4.Name = "btncolor4"
			Dim btncolor74 As Global.System.Windows.Forms.Control = Me.btncolor4
			size = New Global.System.Drawing.Size(54, 53)
			btncolor74.Size = size
			Me.btncolor4.TabIndex = 43
			Me.btncolor4.UseVisualStyleBackColor = False
			Me.btncolor23.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor23.BackColor = Global.System.Drawing.Color.FromArgb(153, 153, 153)
			Me.btncolor23.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor23.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor75 As Global.System.Windows.Forms.Control = Me.btncolor23
			point = New Global.System.Drawing.Point(423, 121)
			btncolor75.Location = point
			Me.btncolor23.Name = "btncolor23"
			Dim btncolor76 As Global.System.Windows.Forms.Control = Me.btncolor23
			size = New Global.System.Drawing.Size(54, 53)
			btncolor76.Size = size
			Me.btncolor23.TabIndex = 62
			Me.btncolor23.UseVisualStyleBackColor = False
			Me.btncolor24.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor24.BackColor = Global.System.Drawing.Color.Purple
			Me.btncolor24.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor24.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor77 As Global.System.Windows.Forms.Control = Me.btncolor24
			point = New Global.System.Drawing.Point(363, 121)
			btncolor77.Location = point
			Me.btncolor24.Name = "btncolor24"
			Dim btncolor78 As Global.System.Windows.Forms.Control = Me.btncolor24
			size = New Global.System.Drawing.Size(54, 53)
			btncolor78.Size = size
			Me.btncolor24.TabIndex = 61
			Me.btncolor24.UseVisualStyleBackColor = False
			Me.btncolor7.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btncolor7.BackColor = Global.System.Drawing.Color.FromArgb(51, 51, 51)
			Me.btncolor7.Cursor = Global.System.Windows.Forms.Cursors.Hand
			Me.btncolor7.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btncolor79 As Global.System.Windows.Forms.Control = Me.btncolor7
			point = New Global.System.Drawing.Point(423, 3)
			btncolor79.Location = point
			Me.btncolor7.Name = "btncolor7"
			Dim btncolor80 As Global.System.Windows.Forms.Control = Me.btncolor7
			size = New Global.System.Drawing.Size(54, 53)
			btncolor80.Size = size
			Me.btncolor7.TabIndex = 46
			Me.btncolor7.UseVisualStyleBackColor = False
			Me.btncancel.BackColor = Global.System.Drawing.Color.Transparent
			Me.btncancel.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.stripe
			Me.btncancel.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btncancel.Font = New Global.System.Drawing.Font("Arial", 18F)
			Me.btncancel.ForeColor = Global.System.Drawing.Color.Blue
			Me.btncancel.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Dim btncancel As Global.System.Windows.Forms.Control = Me.btncancel
			point = New Global.System.Drawing.Point(369, 363)
			btncancel.Location = point
			Me.btncancel.Name = "btncancel"
			Dim btncancel2 As Global.System.Windows.Forms.Control = Me.btncancel
			size = New Global.System.Drawing.Size(114, 48)
			btncancel2.Size = size
			Me.btncancel.TabIndex = 51
			Me.btncancel.Tag = "NC018R0004"
			Me.btncancel.Text = "Thoát"
			Me.btncancel.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btncancel.UseCompatibleTextRendering = True
			Me.btncancel.UseVisualStyleBackColor = False
			Me.ChkDefault.Checked = True
			Me.ChkDefault.CheckState = Global.System.Windows.Forms.CheckState.Checked
			Me.ChkDefault.Font = New Global.System.Drawing.Font("Times New Roman", 18F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.ChkDefault.ForeColor = Global.System.Drawing.Color.Blue
			Dim chkDefault As Global.System.Windows.Forms.Control = Me.ChkDefault
			point = New Global.System.Drawing.Point(98, 377)
			chkDefault.Location = point
			Me.ChkDefault.Name = "ChkDefault"
			Dim chkDefault2 As Global.System.Windows.Forms.Control = Me.ChkDefault
			size = New Global.System.Drawing.Size(106, 22)
			chkDefault2.Size = size
			Me.ChkDefault.TabIndex = 52
			Me.ChkDefault.Text = "Chọn mặc định"
			Me.ChkDefault.UseVisualStyleBackColor = True
			Me.ChkDefault.Visible = False
			Me.grpApdung.Controls.Add(Me.rdoAll)
			Me.grpApdung.Controls.Add(Me.rdoNhom)
			Me.grpApdung.Controls.Add(Me.rdoMon)
			Me.grpApdung.Font = New Global.System.Drawing.Font("Arial", 9F)
			Me.grpApdung.ForeColor = Global.System.Drawing.Color.Blue
			Dim grpApdung As Global.System.Windows.Forms.Control = Me.grpApdung
			point = New Global.System.Drawing.Point(3, 301)
			grpApdung.Location = point
			Me.grpApdung.Name = "grpApdung"
			Dim grpApdung2 As Global.System.Windows.Forms.Control = Me.grpApdung
			size = New Global.System.Drawing.Size(480, 59)
			grpApdung2.Size = size
			Me.grpApdung.TabIndex = 53
			Me.grpApdung.TabStop = False
			Me.grpApdung.Tag = "NC009R0005"
			Me.grpApdung.Text = "Áp dụng cho"
			Me.grpApdung.Visible = False
			Me.rdoAll.BackColor = Global.System.Drawing.Color.FromArgb(192, 192, 255)
			Me.rdoAll.Font = New Global.System.Drawing.Font("Arial", 13F)
			Dim rdoAll As Global.System.Windows.Forms.Control = Me.rdoAll
			point = New Global.System.Drawing.Point(311, 17)
			rdoAll.Location = point
			Me.rdoAll.Name = "rdoAll"
			Dim rdoAll2 As Global.System.Windows.Forms.Control = Me.rdoAll
			size = New Global.System.Drawing.Size(122, 31)
			rdoAll2.Size = size
			Me.rdoAll.TabIndex = 0
			Me.rdoAll.Tag = "NC013R0008"
			Me.rdoAll.Text = "Tất cả"
			Me.rdoAll.UseVisualStyleBackColor = False
			Me.rdoNhom.BackColor = Global.System.Drawing.Color.FromArgb(192, 192, 255)
			Me.rdoNhom.Font = New Global.System.Drawing.Font("Arial", 13F)
			Dim rdoNhom As Global.System.Windows.Forms.Control = Me.rdoNhom
			point = New Global.System.Drawing.Point(180, 17)
			rdoNhom.Location = point
			Me.rdoNhom.Name = "rdoNhom"
			Dim rdoNhom2 As Global.System.Windows.Forms.Control = Me.rdoNhom
			size = New Global.System.Drawing.Size(122, 31)
			rdoNhom2.Size = size
			Me.rdoNhom.TabIndex = 0
			Me.rdoNhom.Tag = "NC013R0007"
			Me.rdoNhom.Text = "Nhóm"
			Me.rdoNhom.UseVisualStyleBackColor = False
			Me.rdoMon.BackColor = Global.System.Drawing.Color.FromArgb(192, 192, 255)
			Me.rdoMon.Checked = True
			Me.rdoMon.Font = New Global.System.Drawing.Font("Arial", 13F)
			Dim rdoMon As Global.System.Windows.Forms.Control = Me.rdoMon
			point = New Global.System.Drawing.Point(49, 17)
			rdoMon.Location = point
			Me.rdoMon.Name = "rdoMon"
			Dim rdoMon2 As Global.System.Windows.Forms.Control = Me.rdoMon
			size = New Global.System.Drawing.Size(122, 31)
			rdoMon2.Size = size
			Me.rdoMon.TabIndex = 0
			Me.rdoMon.TabStop = True
			Me.rdoMon.Tag = "NC013R0006"
			Me.rdoMon.Text = "Món"
			Me.rdoMon.UseVisualStyleBackColor = False
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			Me.BackColor = Global.System.Drawing.Color.White
			size = New Global.System.Drawing.Size(487, 412)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.ChkDefault)
			Me.Controls.Add(Me.btncancel)
			Me.Controls.Add(Me.Tblpanelcolor)
			Me.Controls.Add(Me.btnok)
			Me.Controls.Add(Me.grpApdung)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Me.ImeMode = Global.System.Windows.Forms.ImeMode.Hiragana
			Me.Name = "frmcolorsetting"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Color Setting"
			Me.Tblpanelcolor.ResumeLayout(False)
			Me.grpApdung.ResumeLayout(False)
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x04000309 RID: 777
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
