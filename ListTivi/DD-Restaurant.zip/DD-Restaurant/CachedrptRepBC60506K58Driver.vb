﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020001FE RID: 510
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60506K58Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600609F RID: 24735 RVA: 0x0001140D File Offset: 0x0000F60D
		Public Sub New()
			CachedrptRepBC60506K58Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002458 RID: 9304
		' (get) Token: 0x060060A0 RID: 24736 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060060A1 RID: 24737 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002459 RID: 9305
		' (get) Token: 0x060060A2 RID: 24738 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060060A3 RID: 24739 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700245A RID: 9306
		' (get) Token: 0x060060A4 RID: 24740 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060060A5 RID: 24741 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x060060A6 RID: 24742 RVA: 0x004DCB20 File Offset: 0x004DAD20
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60506K58Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x060060A7 RID: 24743 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040027F6 RID: 10230
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
