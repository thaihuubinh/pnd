﻿Imports System
Imports System.Collections
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Runtime.CompilerServices
Imports Microsoft.VisualBasic

Namespace prjIS_SalesPOS
	' Token: 0x0200000A RID: 10
	Public Class clsMyDataset
		Inherits DataSet

		' Token: 0x170000D8 RID: 216
		' (get) Token: 0x060001CB RID: 459 RVA: 0x0001D03C File Offset: 0x0001B23C
		' (set) Token: 0x060001CC RID: 460 RVA: 0x00002150 File Offset: 0x00000350
		Private Overridable Property mDa As SqlDataAdapter
			<DebuggerNonUserCode()>
			Get
				Return Me._mDa
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As SqlDataAdapter)
				Me._mDa = value
			End Set
		End Property

		' Token: 0x060001CD RID: 461 RVA: 0x0000215A File Offset: 0x0000035A
		Public Sub New()
			clsMyDataset.__ENCList.Add(New WeakReference(Me))
			Me.mCmdSQL = New SqlCommand()
			Me.mDa = New SqlDataAdapter()
		End Sub

		' Token: 0x060001CE RID: 462 RVA: 0x0001D054 File Offset: 0x0001B254
		Public Sub New(pStrConnect As String, psqlParProc As SqlParameter(), pStrProcRead As String, ByRef pintRetProcTable As Integer)
			clsMyDataset.__ENCList.Add(New WeakReference(Me))
			Me.mCmdSQL = New SqlCommand()
			Me.mDa = New SqlDataAdapter()
			Try
				pintRetProcTable = 0
				Me.mStrConnect = pStrConnect
				Me.mStrProcName = pStrProcRead
				Me.mParSQL = psqlParProc
				Dim flag As Boolean = Me.fRead_Proc()
				If flag Then
					pintRetProcTable = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(mdlVariable.gArrStrMess(2) + vbCrLf & "clsConnect - New" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060001CF RID: 463 RVA: 0x0001D10C File Offset: 0x0001B30C
		Private Function fRead_Proc() As Boolean
			' The following expression was wrapped in a checked-statement
			Dim flag As Boolean
			Try
				flag = False
				Dim flag2 As Boolean = True
				Dim flag3 As Boolean = Me.mCnSQL Is Nothing
				If flag3 Then
					Me.mCnSQL = New SqlConnection()
					Me.mCnSQL.ConnectionString = Me.mStrConnect + "; Connect Timeout=30000"
					Me.mCnSQL.Open()
					flag3 = Me.mCnSQL.State <> ConnectionState.Open
					If flag3 Then
						Interaction.MsgBox(mdlVariable.gArrStrMess(3) + vbCrLf & "clsConnect - fRead_Proc", MsgBoxStyle.Critical, Nothing)
						flag2 = False
					End If
				End If
				flag3 = flag2
				If flag3 Then
					Me.mCmdSQL.Connection = Me.mCnSQL
					Me.mCmdSQL.CommandType = CommandType.StoredProcedure
					Me.mCmdSQL.CommandText = Me.mStrProcName
					Me.mCmdSQL.CommandTimeout = 30000
					Dim num As Integer = 0
					Dim num2 As Integer = Information.UBound(Me.mParSQL, 1) - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						Me.mCmdSQL.Parameters.Add(Me.mParSQL(num3))
						num3 += 1
					End While
					Me.mDa = New SqlDataAdapter(Me.mCmdSQL)
					Me.mDa.Fill(Me)
					Me.mCnSQL.Close()
					flag = True
				End If
				Me.sSetNothing()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { mdlVariable.gArrStrMess(2), vbCrLf & "clsConnect - fRead_Proc: ", Me.mStrProcName, vbCrLf, ex.Message }), MsgBoxStyle.Critical, Nothing)
			Finally
				Me.sSetNothing()
			End Try
			Return flag
		End Function

		' Token: 0x060001D0 RID: 464 RVA: 0x0001D2F0 File Offset: 0x0001B4F0
		Private Sub sSetNothing()
			Try
				Me.mDa = Nothing
				Me.mCmdSQL = Nothing
				Me.mCnSQL = Nothing
			Catch ex As Exception
				Interaction.MsgBox(mdlVariable.gArrStrMess(1) + vbCrLf & "mdlFile - sSetNothing" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x040000DD RID: 221
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040000DE RID: 222
		Private mStrSQL As String

		' Token: 0x040000DF RID: 223
		Private mStrTable As String

		' Token: 0x040000E0 RID: 224
		Private mStrProcName As String

		' Token: 0x040000E1 RID: 225
		Private mStrConnect As String

		' Token: 0x040000E2 RID: 226
		Private mCmdSQL As SqlCommand

		' Token: 0x040000E3 RID: 227
		Private mParSQL As SqlParameter()

		' Token: 0x040000E4 RID: 228
		<AccessedThroughProperty("mDa")>
		Private _mDa As SqlDataAdapter

		' Token: 0x040000E5 RID: 229
		Private mCnSQL As SqlConnection
	End Class
End Namespace
