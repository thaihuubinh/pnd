﻿Namespace prjIS_SalesPOS
	' Token: 0x02000050 RID: 80
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMHHRES
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060017F1 RID: 6129 RVA: 0x0012931C File Offset: 0x0012751C
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060017F2 RID: 6130 RVA: 0x00129354 File Offset: 0x00127554
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMHHRES))
			Me.btnSelect = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.dgvData = New Global.System.Windows.Forms.DataGridView()
			Me.lblMANH = New Global.System.Windows.Forms.Label()
			Me.txtOBJIDNH = New Global.System.Windows.Forms.TextBox()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.btnSelect.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btnSelect.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Dim btnSelect As Global.System.Windows.Forms.Control = Me.btnSelect
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(12, 393)
			btnSelect.Location = point
			Me.btnSelect.Name = "btnSelect"
			Dim btnSelect2 As Global.System.Windows.Forms.Control = Me.btnSelect
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(107, 41)
			btnSelect2.Size = size
			Me.btnSelect.TabIndex = 2
			Me.btnSelect.Tag = "CR0013"
			Me.btnSelect.Text = "Chọn"
			Me.btnSelect.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSelect.UseVisualStyleBackColor = True
			Me.btnExit.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(575, 393)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 41)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 3
			Me.btnExit.Tag = "CR0003"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.dgvData.AllowUserToAddRows = False
			Me.dgvData.AllowUserToDeleteRows = False
			Me.dgvData.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvData.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvData.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvData As Global.System.Windows.Forms.Control = Me.dgvData
			point = New Global.System.Drawing.Point(0, 34)
			dgvData.Location = point
			Me.dgvData.Name = "dgvData"
			Me.dgvData.[ReadOnly] = True
			Dim dgvData2 As Global.System.Windows.Forms.Control = Me.dgvData
			size = New Global.System.Drawing.Size(694, 357)
			dgvData2.Size = size
			Me.dgvData.TabIndex = 1
			Me.lblMANH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMANH As Global.System.Windows.Forms.Control = Me.lblMANH
			point = New Global.System.Drawing.Point(1, 4)
			lblMANH.Location = point
			Me.lblMANH.Name = "lblMANH"
			Dim lblMANH2 As Global.System.Windows.Forms.Control = Me.lblMANH
			size = New Global.System.Drawing.Size(213, 21)
			lblMANH2.Size = size
			Me.lblMANH.TabIndex = 43
			Me.lblMANH.Tag = "CR0017"
			Me.lblMANH.Text = "Lọc theo mã/ tên hàng/ tên phụ"
			Me.txtOBJIDNH.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtOBJIDNH.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtOBJIDNH As Global.System.Windows.Forms.Control = Me.txtOBJIDNH
			point = New Global.System.Drawing.Point(228, 3)
			txtOBJIDNH.Location = point
			Me.txtOBJIDNH.Name = "txtOBJIDNH"
			Dim txtOBJIDNH2 As Global.System.Windows.Forms.Control = Me.txtOBJIDNH
			size = New Global.System.Drawing.Size(403, 26)
			txtOBJIDNH2.Size = size
			Me.txtOBJIDNH.TabIndex = 0
			Me.txtOBJIDNH.Tag = "0R0000"
			Me.btnKeyboard.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(634, 0)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(60, 33)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 99
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(694, 434)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.btnKeyboard)
			Me.Controls.Add(Me.btnExit)
			Me.Controls.Add(Me.btnSelect)
			Me.Controls.Add(Me.lblMANH)
			Me.Controls.Add(Me.txtOBJIDNH)
			Me.Controls.Add(Me.dgvData)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmDMHHRES"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Danh mục HH"
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x040009EC RID: 2540
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
