﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200004C RID: 76
	<DesignerGenerated()>
	Public Partial Class frmDMGIAKARA4
		Inherits Form

		' Token: 0x060014CA RID: 5322 RVA: 0x000FCF58 File Offset: 0x000FB158
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMBP2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMBP2_Load
			frmDMGIAKARA4.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mbytAllData = 0
			Me.mbtySingle = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000739 RID: 1849
		' (get) Token: 0x060014CD RID: 5325 RVA: 0x000FD770 File Offset: 0x000FB970
		' (set) Token: 0x060014CE RID: 5326 RVA: 0x00005175 File Offset: 0x00003375
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x1700073A RID: 1850
		' (get) Token: 0x060014CF RID: 5327 RVA: 0x000FD788 File Offset: 0x000FB988
		' (set) Token: 0x060014D0 RID: 5328 RVA: 0x000FD7A0 File Offset: 0x000FB9A0
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700073B RID: 1851
		' (get) Token: 0x060014D1 RID: 5329 RVA: 0x000FD80C File Offset: 0x000FBA0C
		' (set) Token: 0x060014D2 RID: 5330 RVA: 0x000FD824 File Offset: 0x000FBA24
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x1700073C RID: 1852
		' (get) Token: 0x060014D3 RID: 5331 RVA: 0x000FD890 File Offset: 0x000FBA90
		' (set) Token: 0x060014D4 RID: 5332 RVA: 0x000FD8A8 File Offset: 0x000FBAA8
		Friend Overridable Property btnThemAll As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnThemAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnThemAll IsNot Nothing
				If flag Then
					RemoveHandler Me._btnThemAll.Click, AddressOf Me.btnThemAll_Click
				End If
				Me._btnThemAll = value
				flag = Me._btnThemAll IsNot Nothing
				If flag Then
					AddHandler Me._btnThemAll.Click, AddressOf Me.btnThemAll_Click
				End If
			End Set
		End Property

		' Token: 0x1700073D RID: 1853
		' (get) Token: 0x060014D5 RID: 5333 RVA: 0x000FD914 File Offset: 0x000FBB14
		' (set) Token: 0x060014D6 RID: 5334 RVA: 0x000FD92C File Offset: 0x000FBB2C
		Friend Overridable Property btnThem1MH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnThem1MH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnThem1MH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnThem1MH.Click, AddressOf Me.btnThem1MH_Click
				End If
				Me._btnThem1MH = value
				flag = Me._btnThem1MH IsNot Nothing
				If flag Then
					AddHandler Me._btnThem1MH.Click, AddressOf Me.btnThem1MH_Click
				End If
			End Set
		End Property

		' Token: 0x1700073E RID: 1854
		' (get) Token: 0x060014D7 RID: 5335 RVA: 0x000FD998 File Offset: 0x000FBB98
		' (set) Token: 0x060014D8 RID: 5336 RVA: 0x000FD9B0 File Offset: 0x000FBBB0
		Friend Overridable Property btnGobo As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnGobo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnGobo IsNot Nothing
				If flag Then
					RemoveHandler Me._btnGobo.Click, AddressOf Me.btnGobo_Click
				End If
				Me._btnGobo = value
				flag = Me._btnGobo IsNot Nothing
				If flag Then
					AddHandler Me._btnGobo.Click, AddressOf Me.btnGobo_Click
				End If
			End Set
		End Property

		' Token: 0x1700073F RID: 1855
		' (get) Token: 0x060014D9 RID: 5337 RVA: 0x000FDA1C File Offset: 0x000FBC1C
		' (set) Token: 0x060014DA RID: 5338 RVA: 0x0000517F File Offset: 0x0000337F
		Friend Overridable Property lstHanghoaThemAll As ListBox
			<DebuggerNonUserCode()>
			Get
				Return Me._lstHanghoaThemAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Me._lstHanghoaThemAll = value
			End Set
		End Property

		' Token: 0x17000740 RID: 1856
		' (get) Token: 0x060014DB RID: 5339 RVA: 0x000FDA34 File Offset: 0x000FBC34
		' (set) Token: 0x060014DC RID: 5340 RVA: 0x00005189 File Offset: 0x00003389
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000741 RID: 1857
		' (get) Token: 0x060014DD RID: 5341 RVA: 0x000FDA4C File Offset: 0x000FBC4C
		' (set) Token: 0x060014DE RID: 5342 RVA: 0x00005193 File Offset: 0x00003393
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Me._mbdsSource = value
			End Set
		End Property

		' Token: 0x17000742 RID: 1858
		' (get) Token: 0x060014DF RID: 5343 RVA: 0x000FDA64 File Offset: 0x000FBC64
		' (set) Token: 0x060014E0 RID: 5344 RVA: 0x0000519D File Offset: 0x0000339D
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000743 RID: 1859
		' (get) Token: 0x060014E1 RID: 5345 RVA: 0x000FDA7C File Offset: 0x000FBC7C
		' (set) Token: 0x060014E2 RID: 5346 RVA: 0x000051A8 File Offset: 0x000033A8
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000744 RID: 1860
		' (get) Token: 0x060014E3 RID: 5347 RVA: 0x000FDA94 File Offset: 0x000FBC94
		' (set) Token: 0x060014E4 RID: 5348 RVA: 0x000051B3 File Offset: 0x000033B3
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x17000745 RID: 1861
		' (get) Token: 0x060014E5 RID: 5349 RVA: 0x000FDAAC File Offset: 0x000FBCAC
		' (set) Token: 0x060014E6 RID: 5350 RVA: 0x000051BE File Offset: 0x000033BE
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000746 RID: 1862
		' (get) Token: 0x060014E7 RID: 5351 RVA: 0x000FDAC4 File Offset: 0x000FBCC4
		' (set) Token: 0x060014E8 RID: 5352 RVA: 0x000051C9 File Offset: 0x000033C9
		Public Property pStrMAHHSALE As String
			Get
				Return Me.mStrMAHHSALE
			End Get
			Set(value As String)
				Me.mStrMAHHSALE = value
			End Set
		End Property

		' Token: 0x17000747 RID: 1863
		' (get) Token: 0x060014E9 RID: 5353 RVA: 0x000FDADC File Offset: 0x000FBCDC
		' (set) Token: 0x060014EA RID: 5354 RVA: 0x000051D4 File Offset: 0x000033D4
		Public Property pStrMAHHSUR As String
			Get
				Return Me.mStrMAHHSUR
			End Get
			Set(value As String)
				Me.mStrMAHHSUR = value
			End Set
		End Property

		' Token: 0x060014EB RID: 5355 RVA: 0x000FDAF4 File Offset: 0x000FBCF4
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060014EC RID: 5356 RVA: 0x000FDB80 File Offset: 0x000FBD80
		Private Sub frmDMBP2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014ED RID: 5357 RVA: 0x000FDC18 File Offset: 0x000FBE18
		Private Sub frmDMBP2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				Me.mbytFlag = 4
				Me.fGetData_4ListBox()
				Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMBAN")
				flag = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014EE RID: 5358 RVA: 0x000FDCFC File Offset: 0x000FBEFC
		Private Sub btnGobo_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytFlag = 3
				Me.fGetData_4ListBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnGobo_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060014EF RID: 5359 RVA: 0x000FDD90 File Offset: 0x000FBF90
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Me.sAdd()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014F0 RID: 5360 RVA: 0x000FDE30 File Offset: 0x000FC030
		Private Sub btnThemAll_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytFlag = 1
				Me.fGetData_4ListBox()
				Me.sAdd()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnThemAll_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060014F1 RID: 5361 RVA: 0x000FDEC8 File Offset: 0x000FC0C8
		Private Sub btnThem1MH_Click(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim frmSelectTable As frmSelectTable = New frmSelectTable()
				frmSelectTable.ShowDialog()
				Me.mstrMAHH = frmSelectTable.pstrTableSelect.ToString()
				Dim array2 As String() = Me.mstrMAHH.Split(New Char() { ","c })
				Dim flag As Boolean = Me.lstHanghoaThemAll.Items.Count = 0
				If flag Then
					Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMBAN")
					Me.mclsTBHHThemAll.Rows.Clear()
				End If
				flag = Me.mclsTBHHThemAll Is Nothing
				If Not flag Then
					array(0) = Me.mclsTBHHThemAll.Columns("OBJID")
					Me.mclsTBHHThemAll.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTBHHThemAll.Rows.Find(Me.mstrMAHH)
					flag = dataRow IsNot Nothing
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(12) + vbCrLf & vbCrLf, MsgBoxStyle.Critical, Nothing)
					Else
						Dim num As Integer = 0
						Dim num2 As Integer = array2.Length - 2
						Dim num3 As Integer = num
						While True
							Dim num4 As Integer = num3
							Dim num5 As Integer = num2
							If num4 > num5 Then
								Exit For
							End If
							Dim text As String = array2(num3)
							Me.mbytSuccess = Me.fAddNew(Me.mStrOBJID, Strings.Trim(text))
							Me.mbytFlag = 4
							Me.fGetData_4ListBox()
							Me.sRefesh_ListBox()
							num3 += 1
						End While
						frmSelectTable.Dispose()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnThem1MH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014F2 RID: 5362 RVA: 0x000FE0D8 File Offset: 0x000FC2D8
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 4
						Me.sDisplay_Moddelete()
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060014F3 RID: 5363 RVA: 0x000FE1A0 File Offset: 0x000FC3A0
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnSave.Enabled = True
				Me.btnExit.Enabled = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return b
		End Function

		' Token: 0x060014F4 RID: 5364 RVA: 0x000FE244 File Offset: 0x000FC444
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.lstHanghoaThemAll.SelectionMode = SelectionMode.MultiSimple
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060014F5 RID: 5365 RVA: 0x000FE2FC File Offset: 0x000FC4FC
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(5))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(6))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(7))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return b
		End Function

		' Token: 0x060014F6 RID: 5366 RVA: 0x000FE444 File Offset: 0x000FC644
		Private Sub sClear_Form()
			Try
				Me.mclsTBHHThemAll.Dispose()
				Me.mclsTemp.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060014F7 RID: 5367 RVA: 0x000FE4F0 File Offset: 0x000FC6F0
		Private Function fAddNew(strPara1 As String, strPara2 As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nchMAGIAKARA"
				array(0).Value = strPara1
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nchMABAN"
				array(1).Value = strPara2
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_DMGIAKARA_INSERT", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(8), MsgBoxStyle.Critical, Nothing)
						Me.btnExit.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(9), MsgBoxStyle.Critical, Nothing)
							Me.btnExit.Focus()
						Else
							flag2 = num = 3
							If Not flag2 Then
								flag2 = num = 4
								If flag2 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(11), MsgBoxStyle.Critical, Nothing)
									Me.btnExit.Focus()
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060014F8 RID: 5368 RVA: 0x000FE700 File Offset: 0x000FC900
		Private Function fModify(strPara1 As String, strPara2 As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nchMAGIAKARA"
				array(0).Value = strPara1
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nchMABAN"
				array(1).Value = strPara2
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMGIAKARA3_DELETE", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060014F9 RID: 5369 RVA: 0x000FE888 File Offset: 0x000FCA88
		Private Function fDELETE_ALL() As Object
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim obj As Object
			Try
				obj = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@int_Result"
				array(0).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMGIAKARA3_DELETE_ALL", flag)
				Dim num As Integer = Conversions.ToInteger(array(0).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					obj = 1
				End If
			Catch ex As Exception
				obj = False
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return obj
		End Function

		' Token: 0x060014FA RID: 5370 RVA: 0x000FE9BC File Offset: 0x000FCBBC
		Private Function fGetData_4ListBox() As Byte
			' The following expression was wrapped in a checked-statement
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = Me.mbytFlag = 1
				If flag Then
					Me.mclsTBHHThemAll = Nothing
					Dim flag2 As Boolean
					Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "SP_FRMDMGIAKARA_GET_DMBAN", flag2)
					Me.sRefesh_ListBox()
				Else
					flag = Me.mbytFlag = 4
					If flag Then
						Dim clsConnect As clsConnect = New clsConnect()
						Dim sqlCommand As SqlCommand = New SqlCommand()
						Dim array As SqlParameter() = New SqlParameter(1) {}
						array(0) = sqlCommand.CreateParameter()
						array(0).ParameterName = "@PNCHMAGIAKARA"
						array(0).Value = Strings.Trim(Me.mStrOBJID)
						Me.mclsTBHHThemAll = Nothing
						Dim num As Integer
						Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMGIAKARA3_GET_DATA", num)
						Me.sRefesh_ListBox()
					Else
						flag = Me.mbytFlag = 3
						If flag Then
							Dim flag3 As Boolean = False
							Dim num2 As Integer = 0
							Dim num3 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
							Dim num4 As Integer = num2
							While True
								Dim num5 As Integer = num4
								Dim num6 As Integer = num3
								If num5 > num6 Then
									GoTo IL_0114
								End If
								flag = Me.lstHanghoaThemAll.GetSelected(num4)
								If flag Then
									Exit For
								End If
								num4 += 1
							End While
							flag3 = True
							IL_0114:
							flag = flag3
							If flag Then
								Try
									Dim num7 As Integer = 0
									Dim num8 As Integer = 0
									Dim num9 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
									num4 = num8
									While True
										Dim num10 As Integer = num4
										Dim num6 As Integer = num9
										If num10 > num6 Then
											Exit For
										End If
										flag = Me.lstHanghoaThemAll.GetSelected(num4)
										If flag Then
											num7 += 1
										End If
										num4 += 1
									End While
									Dim array2 As DataRow() = New DataRow(num7 + 1 - 1) {}
									num7 = 0
									Dim num11 As Integer = 0
									Dim num12 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
									num4 = num11
									While True
										Dim num13 As Integer = num4
										Dim num6 As Integer = num12
										If num13 > num6 Then
											Exit For
										End If
										flag = Me.lstHanghoaThemAll.GetSelected(num4)
										If flag Then
											Dim dataRowView As DataRowView = CType(Me.lstHanghoaThemAll.Items(num4), DataRowView)
											Dim row As DataRow = dataRowView.Row
											array2(num7) = row
											num7 += 1
										End If
										num4 += 1
									End While
									Dim num14 As Integer = 0
									Dim num15 As Integer = Me.lstHanghoaThemAll.SelectedItems.Count - 1
									Dim num16 As Integer = num14
									While True
										Dim num17 As Integer = num16
										Dim num6 As Integer = num15
										If num17 > num6 Then
											Exit For
										End If
										Dim text As String = Conversions.ToString(NewLateBinding.LateIndexGet(Me.lstHanghoaThemAll.SelectedItems(num16), New Object() { "OBJID" }, Nothing))
										Me.fModify(Me.mStrOBJID, text)
										num16 += 1
									End While
									Dim num18 As Integer = 0
									Dim num19 As Integer = num7
									num4 = num18
									While True
										Dim num20 As Integer = num4
										Dim num6 As Integer = num19
										If num20 > num6 Then
											Exit For
										End If
										Me.mclsTBHHThemAll.Rows.Remove(array2(num4))
										num4 += 1
									End While
								Catch ex As Exception
								End Try
								Me.mbytFlag = 4
								Me.fGetData_4ListBox()
								Me.sRefesh_ListBox()
							Else
								Me.fDELETE_ALL()
								Me.lstHanghoaThemAll.DataSource = Nothing
							End If
						End If
					End If
				End If
				b = 1
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4ListBox ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060014FB RID: 5371 RVA: 0x000FED48 File Offset: 0x000FCF48
		Private Sub sRefesh_ListBox()
			Try
				Dim lstHanghoaThemAll As ListBox = Me.lstHanghoaThemAll
				lstHanghoaThemAll.DataSource = Me.mclsTBHHThemAll
				lstHanghoaThemAll.DisplayMember = "OBJNAME"
				lstHanghoaThemAll.ValueMember = "OBJID"
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sRefesh_ListBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060014FC RID: 5372 RVA: 0x000FEDFC File Offset: 0x000FCFFC
		Private Sub sAdd()
			' The following expression was wrapped in a checked-statement
			Try
				Dim num As Integer = 0
				Dim num2 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
				Dim num3 As Integer = num
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						Exit For
					End If
					Dim text As String = Conversions.ToString(NewLateBinding.LateIndexGet(Me.lstHanghoaThemAll.Items(num3), New Object() { "OBJID" }, Nothing))
					Me.mbytSuccess = Me.fAddNew(Me.mStrOBJID, Strings.Trim(text))
					num3 += 1
				End While
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sAdd ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060014FD RID: 5373 RVA: 0x000FEEF4 File Offset: 0x000FD0F4
		Private Function fGetNameHH(strMAHH As String) As String
			Dim array As DataColumn() = New DataColumn(0) {}
			Dim text As String = ""
			Try
				Me.mclsTemp = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
				array(0) = Me.mclsTemp.Columns("OBJID")
				Me.mclsTemp.PrimaryKey = array
				Dim dataRow As DataRow = Me.mclsTemp.Rows.Find(strMAHH)
				Dim text2 As String = dataRow("OBJNAME").ToString()
				text = text2
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetNameHH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return text
		End Function

		' Token: 0x060014FE RID: 5374 RVA: 0x000FEFF8 File Offset: 0x000FD1F8
		Private Sub sDisplay_Moddelete()
			Dim dataSet As DataSet = New DataSet()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADNKM"
				array(0).Value = Me.mStrOBJID
				Dim num As Integer
				dataSet = New clsMyDataset(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM4_GET_DATA", num)
				Dim flag As Boolean = Me.lstHanghoaThemAll.Items.Count = 0
				If flag Then
					Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
					Me.mclsTBHHThemAll.Rows.Clear()
				End If
				Dim num2 As Integer = dataSet.Tables(0).Rows.Count
				Dim array2 As String() = New String(num2 + 1 - 1) {}
				Dim num3 As Integer = 0
				Dim num4 As Integer = dataSet.Tables(0).Rows.Count - 1
				num2 = num3
				While True
					Dim num5 As Integer = num2
					Dim num6 As Integer = num4
					If num5 > num6 Then
						Exit For
					End If
					array2(num2) = Conversions.ToString(dataSet.Tables(0).Rows(num2)("MAHHSALE"))
					Dim text As String = array2(num2)
					Dim text2 As String = Me.fGetNameHH(Strings.Trim(text))
					Me.mclsTBHHThemAll.Rows.Add(New Object() { Strings.Trim(text), Strings.Trim(text2) })
					num2 += 1
				End While
				Me.sRefesh_ListBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sDisplay_Moddelete ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0400089D RID: 2205
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400089F RID: 2207
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x040008A0 RID: 2208
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040008A1 RID: 2209
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x040008A2 RID: 2210
		<AccessedThroughProperty("btnThemAll")>
		Private _btnThemAll As Button

		' Token: 0x040008A3 RID: 2211
		<AccessedThroughProperty("btnThem1MH")>
		Private _btnThem1MH As Button

		' Token: 0x040008A4 RID: 2212
		<AccessedThroughProperty("btnGobo")>
		Private _btnGobo As Button

		' Token: 0x040008A5 RID: 2213
		<AccessedThroughProperty("lstHanghoaThemAll")>
		Private _lstHanghoaThemAll As ListBox

		' Token: 0x040008A6 RID: 2214
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040008A7 RID: 2215
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040008A8 RID: 2216
		Private mArrStrFrmMess As String()

		' Token: 0x040008A9 RID: 2217
		Private mbytFormStatus As Byte

		' Token: 0x040008AA RID: 2218
		Private mbytSuccess As Byte

		' Token: 0x040008AB RID: 2219
		Private mStrFilter As String

		' Token: 0x040008AC RID: 2220
		Private mStrOBJID As String

		' Token: 0x040008AD RID: 2221
		Private mStrMAHHSALE As String

		' Token: 0x040008AE RID: 2222
		Private mStrMAHHSUR As String

		' Token: 0x040008AF RID: 2223
		Private mclsTBHHThemAll As clsConnect

		' Token: 0x040008B0 RID: 2224
		Private mclsTemp As clsConnect

		' Token: 0x040008B1 RID: 2225
		Private mbytFlag As Byte

		' Token: 0x040008B2 RID: 2226
		Private mstrMAHH As String

		' Token: 0x040008B3 RID: 2227
		Private mstrTENHH As String

		' Token: 0x040008B4 RID: 2228
		Private mbytAllData As Byte

		' Token: 0x040008B5 RID: 2229
		Private mbtySingle As Byte
	End Class
End Namespace
