﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000300 RID: 768
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepJornalSal
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600705F RID: 28767 RVA: 0x00013D5F File Offset: 0x00011F5F
		Public Sub New()
			CachedrptRepJornalSal.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002F0E RID: 12046
		' (get) Token: 0x06007060 RID: 28768 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06007061 RID: 28769 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002F0F RID: 12047
		' (get) Token: 0x06007062 RID: 28770 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06007063 RID: 28771 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002F10 RID: 12048
		' (get) Token: 0x06007064 RID: 28772 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06007065 RID: 28773 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06007066 RID: 28774 RVA: 0x004DF244 File Offset: 0x004DD444
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepJornalSal() With { .Site = Me.Site }
		End Function

		' Token: 0x06007067 RID: 28775 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028F8 RID: 10488
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
