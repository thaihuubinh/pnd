﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports System.Xml
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200002F RID: 47
	<DesignerGenerated()>
	Public Partial Class frmCustomer
		Inherits Form

		' Token: 0x06000965 RID: 2405 RVA: 0x0006E6BC File Offset: 0x0006C8BC
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmCustomer_Activated
			AddHandler MyBase.KeyPress, AddressOf Me.frmCustomer_KeyPress
			AddHandler MyBase.Load, AddressOf Me.frmCustomer_Load
			frmCustomer.__ENCList.Add(New WeakReference(Me))
			Me.mstrMa = ""
			Me.mstrTen = ""
			Me.mstrNHOMDV = ""
			Me.mstrDiachi = ""
			Me.mstrDienthoai = ""
			Me.mdblMucGiamGia = 0.0
			Me.mbdsSourceDMDV = New BindingSource()
			Me.mintPosDV = 0
			Me.mblnRightSelectDV = True
			Me.mintCount = 0
			Me.mintCountTruoc = 0
			Me.mblnClickSave = False
			Me.mblnAutoAdd_DMDV = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700037A RID: 890
		' (get) Token: 0x06000968 RID: 2408 RVA: 0x0006F2C8 File Offset: 0x0006D4C8
		' (set) Token: 0x06000969 RID: 2409 RVA: 0x0006F2E0 File Offset: 0x0006D4E0
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._Label1 IsNot Nothing
				If flag Then
					RemoveHandler Me._Label1.Click, AddressOf Me.Label1_Click
				End If
				Me._Label1 = value
				flag = Me._Label1 IsNot Nothing
				If flag Then
					AddHandler Me._Label1.Click, AddressOf Me.Label1_Click
				End If
			End Set
		End Property

		' Token: 0x1700037B RID: 891
		' (get) Token: 0x0600096A RID: 2410 RVA: 0x0006F34C File Offset: 0x0006D54C
		' (set) Token: 0x0600096B RID: 2411 RVA: 0x0006F364 File Offset: 0x0006D564
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._Label3 IsNot Nothing
				If flag Then
					RemoveHandler Me._Label3.Click, AddressOf Me.Label3_Click
				End If
				Me._Label3 = value
				flag = Me._Label3 IsNot Nothing
				If flag Then
					AddHandler Me._Label3.Click, AddressOf Me.Label3_Click
				End If
			End Set
		End Property

		' Token: 0x1700037C RID: 892
		' (get) Token: 0x0600096C RID: 2412 RVA: 0x0006F3D0 File Offset: 0x0006D5D0
		' (set) Token: 0x0600096D RID: 2413 RVA: 0x0006F3E8 File Offset: 0x0006D5E8
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700037D RID: 893
		' (get) Token: 0x0600096E RID: 2414 RVA: 0x0006F454 File Offset: 0x0006D654
		' (set) Token: 0x0600096F RID: 2415 RVA: 0x0006F46C File Offset: 0x0006D66C
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x1700037E RID: 894
		' (get) Token: 0x06000970 RID: 2416 RVA: 0x0006F4D8 File Offset: 0x0006D6D8
		' (set) Token: 0x06000971 RID: 2417 RVA: 0x0006F4F0 File Offset: 0x0006D6F0
		Friend Overridable Property btnKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKH.Click, AddressOf Me.btnKH_Click
				End If
				Me._btnKH = value
				flag = Me._btnKH IsNot Nothing
				If flag Then
					AddHandler Me._btnKH.Click, AddressOf Me.btnKH_Click
				End If
			End Set
		End Property

		' Token: 0x1700037F RID: 895
		' (get) Token: 0x06000972 RID: 2418 RVA: 0x0006F55C File Offset: 0x0006D75C
		' (set) Token: 0x06000973 RID: 2419 RVA: 0x0006F574 File Offset: 0x0006D774
		Friend Overridable Property txtMa As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMa
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMa IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMa.TextChanged, AddressOf Me.txtMa_TextChanged
					RemoveHandler Me._txtMa.KeyDown, AddressOf Me.txtMa_KeyDown
					RemoveHandler Me._txtMa.KeyPress, AddressOf Me.txtMa_KeyPress
				End If
				Me._txtMa = value
				flag = Me._txtMa IsNot Nothing
				If flag Then
					AddHandler Me._txtMa.TextChanged, AddressOf Me.txtMa_TextChanged
					AddHandler Me._txtMa.KeyDown, AddressOf Me.txtMa_KeyDown
					AddHandler Me._txtMa.KeyPress, AddressOf Me.txtMa_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000380 RID: 896
		' (get) Token: 0x06000974 RID: 2420 RVA: 0x0006F644 File Offset: 0x0006D844
		' (set) Token: 0x06000975 RID: 2421 RVA: 0x0006F65C File Offset: 0x0006D85C
		Friend Overridable Property tmrRight As Timer
			<DebuggerNonUserCode()>
			Get
				Return Me._tmrRight
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim flag As Boolean = Me._tmrRight IsNot Nothing
				If flag Then
					RemoveHandler Me._tmrRight.Tick, AddressOf Me.tmrRight_Tick
				End If
				Me._tmrRight = value
				flag = Me._tmrRight IsNot Nothing
				If flag Then
					AddHandler Me._tmrRight.Tick, AddressOf Me.tmrRight_Tick
				End If
			End Set
		End Property

		' Token: 0x17000381 RID: 897
		' (get) Token: 0x06000976 RID: 2422 RVA: 0x0006F6C8 File Offset: 0x0006D8C8
		' (set) Token: 0x06000977 RID: 2423 RVA: 0x0000388F File Offset: 0x00001A8F
		Friend Overridable Property ContextMenuStrip1 As ContextMenuStrip
			<DebuggerNonUserCode()>
			Get
				Return Me._ContextMenuStrip1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ContextMenuStrip)
				Me._ContextMenuStrip1 = value
			End Set
		End Property

		' Token: 0x17000382 RID: 898
		' (get) Token: 0x06000978 RID: 2424 RVA: 0x0006F6E0 File Offset: 0x0006D8E0
		' (set) Token: 0x06000979 RID: 2425 RVA: 0x00003899 File Offset: 0x00001A99
		Friend Overridable Property lblTitle As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTitle
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTitle = value
			End Set
		End Property

		' Token: 0x17000383 RID: 899
		' (get) Token: 0x0600097A RID: 2426 RVA: 0x0006F6F8 File Offset: 0x0006D8F8
		' (set) Token: 0x0600097B RID: 2427 RVA: 0x000038A3 File Offset: 0x00001AA3
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000384 RID: 900
		' (get) Token: 0x0600097C RID: 2428 RVA: 0x0006F710 File Offset: 0x0006D910
		' (set) Token: 0x0600097D RID: 2429 RVA: 0x0006F728 File Offset: 0x0006D928
		Friend Overridable Property dgvDMDV As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvDMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvDMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvDMDV.KeyDown, AddressOf Me.dgvDMDV_KeyDown
				End If
				Me._dgvDMDV = value
				flag = Me._dgvDMDV IsNot Nothing
				If flag Then
					AddHandler Me._dgvDMDV.KeyDown, AddressOf Me.dgvDMDV_KeyDown
				End If
			End Set
		End Property

		' Token: 0x17000385 RID: 901
		' (get) Token: 0x0600097E RID: 2430 RVA: 0x0006F794 File Offset: 0x0006D994
		' (set) Token: 0x0600097F RID: 2431 RVA: 0x000038AD File Offset: 0x00001AAD
		Friend Overridable Property txtTENDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENDV = value
			End Set
		End Property

		' Token: 0x06000980 RID: 2432
		Private Declare Ansi Function BlockInput Lib "user32" (fBlock As Long) As Long

		' Token: 0x17000386 RID: 902
		' (get) Token: 0x06000981 RID: 2433 RVA: 0x0006F7AC File Offset: 0x0006D9AC
		' (set) Token: 0x06000982 RID: 2434 RVA: 0x0006F7C4 File Offset: 0x0006D9C4
		Private Overridable Property mbdsSourceDMDV As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceDMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceDMDV.PositionChanged, AddressOf Me.mbdsSourceDMDV_PositionChanged
				End If
				Me._mbdsSourceDMDV = value
				flag = Me._mbdsSourceDMDV IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceDMDV.PositionChanged, AddressOf Me.mbdsSourceDMDV_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000387 RID: 903
		' (get) Token: 0x06000983 RID: 2435 RVA: 0x0006F830 File Offset: 0x0006DA30
		' (set) Token: 0x06000984 RID: 2436 RVA: 0x000038B7 File Offset: 0x00001AB7
		Public Property pdblMucGiamGia As Double
			Get
				Return Me.mdblMucGiamGia
			End Get
			Set(value As Double)
				Me.mdblMucGiamGia = value
			End Set
		End Property

		' Token: 0x17000388 RID: 904
		' (get) Token: 0x06000985 RID: 2437 RVA: 0x0006F848 File Offset: 0x0006DA48
		' (set) Token: 0x06000986 RID: 2438 RVA: 0x000038C2 File Offset: 0x00001AC2
		Public Property pstrDienthoai As String
			Get
				Return Me.mstrDienthoai
			End Get
			Set(value As String)
				Me.mstrDienthoai = value
			End Set
		End Property

		' Token: 0x17000389 RID: 905
		' (get) Token: 0x06000987 RID: 2439 RVA: 0x0006F860 File Offset: 0x0006DA60
		' (set) Token: 0x06000988 RID: 2440 RVA: 0x000038CD File Offset: 0x00001ACD
		Public Property pdtNgaySinh As DateTime
			Get
				Return Me.mdtNgaySinh
			End Get
			Set(value As DateTime)
				Me.mdtNgaySinh = value
			End Set
		End Property

		' Token: 0x1700038A RID: 906
		' (get) Token: 0x06000989 RID: 2441 RVA: 0x0006F878 File Offset: 0x0006DA78
		' (set) Token: 0x0600098A RID: 2442 RVA: 0x000038D8 File Offset: 0x00001AD8
		Public Property pstrDiachi As String
			Get
				Return Me.mstrDiachi
			End Get
			Set(value As String)
				Me.mstrDiachi = value
			End Set
		End Property

		' Token: 0x1700038B RID: 907
		' (get) Token: 0x0600098B RID: 2443 RVA: 0x0006F890 File Offset: 0x0006DA90
		Public ReadOnly Property pblnOK As Boolean
			Get
				Return Me.mblnOK
			End Get
		End Property

		' Token: 0x1700038C RID: 908
		' (get) Token: 0x0600098C RID: 2444 RVA: 0x0006F8A8 File Offset: 0x0006DAA8
		' (set) Token: 0x0600098D RID: 2445 RVA: 0x000038E3 File Offset: 0x00001AE3
		Public Property pstrTenDv As String
			Get
				Return Me.mstrTen
			End Get
			Set(value As String)
				Me.mstrTen = value
			End Set
		End Property

		' Token: 0x1700038D RID: 909
		' (get) Token: 0x0600098E RID: 2446 RVA: 0x0006F8C0 File Offset: 0x0006DAC0
		' (set) Token: 0x0600098F RID: 2447 RVA: 0x000038EE File Offset: 0x00001AEE
		Public Property pstrMadv As String
			Get
				Return Me.mstrMa
			End Get
			Set(value As String)
				Me.mstrMa = value
			End Set
		End Property

		' Token: 0x1700038E RID: 910
		' (get) Token: 0x06000990 RID: 2448 RVA: 0x0006F8D8 File Offset: 0x0006DAD8
		' (set) Token: 0x06000991 RID: 2449 RVA: 0x000038F9 File Offset: 0x00001AF9
		Public Property pstrMaNHOMdv As String
			Get
				Return Me.mstrNHOMDV
			End Get
			Set(value As String)
				Me.mstrNHOMDV = value
			End Set
		End Property

		' Token: 0x06000992 RID: 2450 RVA: 0x0006F8F0 File Offset: 0x0006DAF0
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMDV")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mblnAutoAdd_DMDV = xmlNode.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000993 RID: 2451 RVA: 0x0006F9EC File Offset: 0x0006DBEC
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = (Operators.CompareString(Me.txtMa.Text.Trim(), "", False) <> 0) And (Operators.CompareString(Me.txtTENDV.Text.Trim(), "", False) = 0)
			If flag Then
				Me.txtMa.Text = ""
				Me.mblnClickSave = True
				MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(6), Me.mArrStrFrmMess(7), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.CanhBao)
			Else
				flag = Operators.CompareString(Me.mstrMa.Trim(), "", False) = 0
				Dim flag2 As Boolean
				If flag Then
					flag2 = Me.fAddNew_DMDV() = 0
					If flag2 Then
						Me.txtMa.Focus()
						Return
					End If
				End If
				flag2 = Me.mstrMa.Trim().Length = 0
				If flag2 Then
					Dim text As String = Me.txtMa.Text.Trim()
					Me.txtMa.Text = ""
					Me.txtMa.Text = text
				End If
				flag2 = mdlVariable.gfrmSaleMode.pfCheckMixMatch_10(Me.mstrNHOMDV.Trim())
				If flag2 Then
					Dim frmInputText As frmInputText = New frmInputText()
					frmInputText.ShowDialog()
					flag2 = frmInputText.pblnOK
					If Not flag2 Then
						Return
					End If
					flag = Not Me.fCheckUserGroup_03(frmInputText.pstrMa.Trim())
					If flag Then
						Return
					End If
				End If
				Me.mblnOK = True
				mdlFile.gfWriteLogFile("Chọn khách hàng: " + Me.mstrMa.Trim() + "-" + Me.mstrTen.Trim())
				Me.Close()
			End If
		End Sub

		' Token: 0x06000994 RID: 2452 RVA: 0x00003904 File Offset: 0x00001B04
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Me.mblnOK = False
			mdlFile.gfWriteLogFile("Nhấn nút thoát form chọn khách hàng.")
			Me.Close()
		End Sub

		' Token: 0x06000995 RID: 2453 RVA: 0x00003921 File Offset: 0x00001B21
		Private Sub frmCustomer_Activated(sender As Object, e As EventArgs)
			Me.txtMa.Focus()
			Me.txtMa.[Select]()
		End Sub

		' Token: 0x06000996 RID: 2454 RVA: 0x0006FB94 File Offset: 0x0006DD94
		Private Sub frmCustomer_KeyPress(sender As Object, e As KeyPressEventArgs)
			Dim flag As Boolean = Strings.Asc(e.KeyChar) = 27
			Dim flag2 As Boolean
			If flag Then
				flag2 = Me.dgvDMDV.Visible
				If flag2 Then
					Me.dgvDMDV.Visible = False
					Me.Height = 187
					Me.Width = 463
					Me.Top = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Height) / 2.0 - CDbl(Me.Height) / 2.0))
					Me.Left = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Width) / 2.0 - CDbl(Me.Width) / 2.0))
					Me.txtMa.Focus()
				Else
					Me.mblnOK = False
					Me.Close()
				End If
			End If
			flag2 = Strings.Asc(e.KeyChar) = 13
			If flag2 Then
				flag = Me.dgvDMDV.Visible
				If Not flag Then
					flag2 = Me.mblnRightSelectDV
					If Not flag2 Then
						Me.btnSave_Click(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			End If
		End Sub

		' Token: 0x06000997 RID: 2455 RVA: 0x0006FCCC File Offset: 0x0006DECC
		Private Sub frmCustomer_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Me.sGetPara_From_SetparaXML()
				Me.fGetData_DMDV()
				Dim flag As Boolean = mdlUIForm.gfChek_RightSale("00024", False) = 0
				If flag Then
					Me.btnKH.Visible = False
					Me.mblnRightSelectDV = False
					Me.tmrRight.Enabled = True
					Me.tmrRight.Interval = 1200
					Me.txtMa.PasswordChar = "*"c
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - frmSplitTable_Load() " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000998 RID: 2456 RVA: 0x0006FDAC File Offset: 0x0006DFAC
		Private Sub txtMa_KeyDown(sender As Object, e As KeyEventArgs)
			Try
				Dim flag As Boolean = e.KeyCode = Keys.Down
				If flag Then
					Dim b As Byte = Me.f_GetData_4GridMADV()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADV_KeyDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000999 RID: 2457 RVA: 0x0006FE48 File Offset: 0x0006E048
		Private Sub txtMa_KeyPress(sender As Object, e As KeyPressEventArgs)
			Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
			If flag Then
				Me.btnSave_Click(RuntimeHelpers.GetObjectValue(sender), e)
			End If
		End Sub

		' Token: 0x0600099A RID: 2458 RVA: 0x0006FE7C File Offset: 0x0006E07C
		Private Sub txtMa_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMDV Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMDV.Columns("OBJID")
					Me.mclsTbDMDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMDV.Rows.Find(Strings.Trim(Me.txtMa.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENDV.Text = dataRow("OBJNAME").ToString()
						Me.mstrMa = dataRow("OBJID").ToString()
						Me.mstrTen = dataRow("OBJNAME").ToString()
						Me.mstrNHOMDV = dataRow("MANHOMDV").ToString()
						Me.mstrDiachi = dataRow("ADDRESS").ToString()
						Me.mstrDienthoai = dataRow("TEL").ToString()
						Me.mdtNgaySinh = Conversions.ToDate(dataRow("NGAYSINH").ToString())
						Me.mdblMucGiamGia = Conversion.Val(dataRow("MUCGIAMGIA").ToString())
					Else
						Dim text As String = Strings.Trim(Me.txtMa.Text)
						flag = mdlVariable.gblnLRemoveXChar
						If flag Then
							text = text.Trim().Replace("?", "").Replace(";", "")
						End If
						array(0) = Me.mclsTbDMDV.Columns("CARDCODE")
						Me.mclsTbDMDV.PrimaryKey = array
						dataRow = Me.mclsTbDMDV.Rows.Find(text)
						flag = dataRow IsNot Nothing
						If flag Then
							Me.txtTENDV.Text = dataRow("OBJNAME").ToString()
							Me.mstrMa = dataRow("OBJID").ToString()
							Me.mstrTen = dataRow("OBJNAME").ToString()
							Me.mstrNHOMDV = dataRow("MANHOMDV").ToString()
							Me.mstrDiachi = dataRow("ADDRESS").ToString()
							Me.mstrDienthoai = dataRow("TEL").ToString()
							Me.mdtNgaySinh = Conversions.ToDate(dataRow("NGAYSINH").ToString())
							Me.mdblMucGiamGia = Conversion.Val(dataRow("MUCGIAMGIA").ToString())
						Else
							Me.mstrMa = ""
							Me.mstrTen = ""
							Me.txtTENDV.Text = ""
							Me.mstrNHOMDV = ""
							Me.mstrDiachi = ""
							Me.mstrDienthoai = ""
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMa_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600099B RID: 2459 RVA: 0x00070208 File Offset: 0x0006E408
		Private Sub tmrRight_Tick(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.mblnRightSelectDV And Versioned.IsNumeric(Me.txtMa.Text.Trim()) And Not Me.mblnClickSave
			If flag Then
				Me.btnExit_Click(RuntimeHelpers.GetObjectValue(sender), e)
			End If
			Me.mblnClickSave = False
		End Sub

		' Token: 0x0600099C RID: 2460 RVA: 0x0007025C File Offset: 0x0006E45C
		Private Sub btnKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDV As frmDMDV1 = New frmDMDV1()
				mdlFile.gfWriteLogFile("Nhấn chọn mở danh mục khách hàng.")
				frmDMDV.pBytOpen_From_Menu = 7
				frmDMDV.pIntType = 1S
				frmDMDV.ShowDialog()
				Me.fGetData_DMDV()
				Me.txtMa.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJID, "", False) = 0, Me.txtMa.Text, frmDMDV.pStrOBJID))
				Me.txtTENDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJNAME, "", False) = 0, Me.txtTENDV.Text, frmDMDV.pStrOBJNAME))
				Me.mstrNHOMDV = frmDMDV.pStrMANHOMDV
				frmDMDV.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnSoGhe_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600099D RID: 2461 RVA: 0x0007038C File Offset: 0x0006E58C
		Private Sub dgvDMDV_KeyDown(sender As Object, e As KeyEventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim keyCode As Keys = e.KeyCode
				Dim flag As Boolean = keyCode = Keys.[Return]
				If flag Then
					Dim flag2 As Boolean = Me.mbdsSourceDMDV.Count > 0
					If flag2 Then
						Me.mstrMa = Conversions.ToString(Me.dgvDMDV("OBJID", Me.mintPosDV).Value)
						Me.mstrTen = Conversions.ToString(Me.dgvDMDV("OBJNAME", Me.mintPosDV).Value)
						Me.mstrNHOMDV = Conversions.ToString(Me.dgvDMDV("MANHOMDV", Me.mintPosDV).Value)
						Me.mstrDiachi = Conversions.ToString(Me.dgvDMDV("ADDRESS", Me.mintPosDV).Value)
						Me.mstrDienthoai = Conversions.ToString(Me.dgvDMDV("TEL", Me.mintPosDV).Value)
						Me.mdtNgaySinh = Conversions.ToDate(Me.dgvDMDV("NGAYSINH", Me.mintPosDV).Value)
						Me.mdblMucGiamGia = Conversions.ToDouble(Me.dgvDMDV("MUCGIAMGIA", Me.mintPosDV).Value)
					End If
					Me.mblnOK = True
					mdlFile.gfWriteLogFile("Chọn khách hàng: " + Me.mstrMa.Trim() + "-" + Me.mstrTen.Trim())
					Me.Close()
				Else
					Dim flag3 As Boolean
					If keyCode < Keys.D1 OrElse keyCode > Keys.D9 Then
						If keyCode < Keys.NumPad1 OrElse keyCode > Keys.NumPad9 Then
							flag3 = False
							GoTo IL_0196
						End If
					End If
					flag3 = True
					IL_0196:
					Dim flag2 As Boolean = flag3
					If flag2 Then
						Dim num As Integer = e.KeyCode - Keys.D0
						flag2 = num > 9
						If flag2 Then
							num -= 48
						End If
						flag2 = (Me.mbdsSourceDMDV.Count >= num) And (num > 0)
						If flag2 Then
							Me.mintPosDV = num - 1
							Me.mstrMa = Conversions.ToString(Me.dgvDMDV("OBJID", Me.mintPosDV).Value)
							Me.mstrTen = Conversions.ToString(Me.dgvDMDV("OBJNAME", Me.mintPosDV).Value)
							Me.mstrNHOMDV = Conversions.ToString(Me.dgvDMDV("MANHOMDV", Me.mintPosDV).Value)
							Me.mstrDiachi = Conversions.ToString(Me.dgvDMDV("ADDRESS", Me.mintPosDV).Value)
							Me.mstrDienthoai = Conversions.ToString(Me.dgvDMDV("TEL", Me.mintPosDV).Value)
							Me.mdtNgaySinh = Conversions.ToDate(Me.dgvDMDV("NGAYSINH", Me.mintPosDV).Value)
							Me.mdblMucGiamGia = Conversions.ToDouble(Me.dgvDMDV("MUCGIAMGIA", Me.mintPosDV).Value)
							Me.txtMa.Focus()
							Me.dgvDMDV.Visible = False
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvDMDV_KeyDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600099E RID: 2462 RVA: 0x0007073C File Offset: 0x0006E93C
		Private Sub mbdsSourceDMDV_PositionChanged(sender As Object, e As EventArgs)
			Try
				Me.mintPosDV = Me.mbdsSourceDMDV.Position
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceDMDV_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600099F RID: 2463 RVA: 0x0000393D File Offset: 0x00001B3D
		Protected Overrides Sub Finalize()
			MyBase.Finalize()
		End Sub

		' Token: 0x060009A0 RID: 2464 RVA: 0x000707E0 File Offset: 0x0006E9E0
		Private Function fChek_RightAddDMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim array As DataRow() = mdlVariable.gtbRights.[Select]("TRIM(OBJID) = '2070400000'")
				Dim flag As Boolean = array Is Nothing OrElse array.Length < 1
				If Not flag Then
					Dim text As String = array(0)("DRIGHT").ToString()
					flag = Operators.CompareString(Strings.Mid(text, 2, 1), "0", False) = 0
					If Not flag Then
						b = 1
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + vbCrLf & " fChek_RightAddDMDV " + ex.Message + vbCrLf, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060009A1 RID: 2465 RVA: 0x000708A4 File Offset: 0x0006EAA4
		Private Function fAddNew_DMDV() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(34) {}
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = Me.mblnAutoAdd_DMDV AndAlso Me.fChek_RightAddDMDV() > 0
				Dim flag2 As Boolean
				If flag Then
					flag2 = Operators.CompareString(Strings.Trim(Me.txtMa.Text), "", False) = 0 AndAlso Operators.CompareString(Strings.Trim(Me.txtTENDV.Text), "", False) = 0
					If flag2 Then
						Return 1
					End If
				Else
					flag2 = Operators.CompareString(Strings.Trim(Me.txtMa.Text), "", False) = 0 OrElse Operators.CompareString(Strings.Trim(Me.txtTENDV.Text), "", False) = 0
					If flag2 Then
						Return 1
					End If
				End If
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtMa.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtTENDV.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pvchBIRTHDAY"
				array(2).Value = ""
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchMANHOMDV"
				array(3).Value = ""
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnchMAKH"
				array(4).Value = mdlVariable.gStrStockCode.Trim()
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcDC"
				array(5).Value = ""
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcVAT"
				array(6).Value = ""
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnvcTEL"
				array(7).Value = ""
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnvcMOBI"
				array(8).Value = ""
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pnvcFAX"
				array(9).Value = ""
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pnvcEmail"
				array(10).Value = ""
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pnvcWeb"
				array(11).Value = ""
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pnvcLH"
				array(12).Value = ""
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pbitSUP"
				array(13).Value = 0
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitCUS"
				array(14).Value = 1
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pbitFOR"
				array(15).Value = 0
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pbitORG"
				array(16).Value = 0
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnvcTUOI"
				array(17).Value = "0"
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@ptniGIOITINH"
				array(18).Value = 0
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pnvcJOB"
				array(19).Value = ""
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = "-"
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMAUSERUP"
				array(22).Value = mdlVariable.gStrUser
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnvcUIMAGE"
				array(23).Value = ""
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnvcCAP"
				array(24).Value = ""
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnvcCHUCVU"
				array(25).Value = ""
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pmnyMUCGIAMGIA"
				array(26).Value = 0
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pnvcFINGER1"
				array(27).Value = ""
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pnvcFINGER2"
				array(28).Value = ""
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pnvcFINGER3"
				array(29).Value = ""
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnchCARDCODE"
				array(30).Value = Strings.Trim(Me.txtMa.Text)
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@pnvcNGAYNHANVIEC"
				array(31).Value = ""
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pnvcNGAYTHOIVIEC"
				array(32).Value = ""
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pnchMAUSERLK"
				array(33).Value = ""
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@int_Result"
				array(20).Direction = ParameterDirection.ReturnValue
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_INSERT_DMDV", num)
				Dim num2 As Integer = Conversions.ToInteger(array(20).Value)
				flag2 = (num2 = 0) Or (num2 = 1)
				If flag2 Then
					Me.fGetData_DMDV()
					flag2 = clsConnect.Rows.Count > 0
					If flag2 Then
						Me.txtMa.Text = clsConnect.Rows(0)("OBJID").ToString().Trim()
					End If
					b = 1
				Else
					Interaction.MsgBox(Me.mArrStrFrmMess(16), MsgBoxStyle.Critical, Nothing)
					Me.txtMa.Focus()
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew_DMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060009A2 RID: 2466 RVA: 0x000710C8 File Offset: 0x0006F2C8
		Private Function f_GetData_4GridMADV() As Byte
			' The following expression was wrapped in a checked-statement
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = Me.mclsTbDMDV Is Nothing
				If Not flag Then
					Me.Height = 500
					Me.Width = 800
					Me.Top = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Height) / 2.0 - CDbl(Me.Height) / 2.0))
					Me.Left = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Width) / 2.0 - CDbl(Me.Width) / 2.0))
					Me.dgvDMDV.Visible = True
					Me.dgvDMDV.DataSource = Nothing
					Me.dgvDMDV.ColumnHeadersVisible = True
					Me.dgvDMDV.MultiSelect = False
					Me.dgvDMDV.RowHeadersVisible = False
					Me.dgvDMDV.SelectionMode = DataGridViewSelectionMode.FullRowSelect
					Me.dgvDMDV.StandardTab = False
					Me.dgvDMDV.TabStop = False
					Me.dgvDMDV.AllowUserToAddRows = False
					Me.dgvDMDV.AllowUserToDeleteRows = False
					Me.dgvDMDV.AllowUserToOrderColumns = False
					Me.dgvDMDV.AllowUserToResizeRows = False
					Me.dgvDMDV.AllowDrop = False
					Me.dgvDMDV.RowTemplate.Height = 25
					Me.dgvDMDV.AlternatingRowsDefaultCellStyle.BackColor = mdlVariable.gobjcloOddRowGrid
					Dim text As String = Me.txtMa.Text.Trim()
					text = Conversions.ToString(NewLateBinding.LateGet(Nothing, GetType(Strings), "UCase", New Object() { RuntimeHelpers.GetObjectValue(Interaction.IIf(Operators.CompareString(Strings.Mid(text, 1, 1), "*", False) = 0, Strings.Mid(text, 2), text)) }, Nothing, Nothing, Nothing))
					Dim dataTable As DataTable = New DataTable()
					dataTable.Columns.Add("STT")
					dataTable.Columns.Add("OBJID")
					dataTable.Columns.Add("OBJNAME")
					dataTable.Columns.Add("ADDRESS")
					dataTable.Columns.Add("MOBILE")
					dataTable.Columns.Add("BIRTHDAY")
					dataTable.Columns.Add("MANHOMDV")
					dataTable.Columns.Add("TENNHOMDV")
					dataTable.Columns.Add("VATCODE")
					dataTable.Columns.Add("TEL")
					dataTable.Columns.Add("MUCGIAMGIA")
					dataTable.Columns.Add("NGAYSINH")
					flag = Me.mclsTbDMDV.Rows.Count > 0
					Dim flag3 As Boolean
					If flag Then
						Dim num As Integer = 0
						Dim num2 As Integer = Me.mclsTbDMDV.Rows.Count - 1
						Dim num3 As Integer = num
						While True
							Dim num4 As Integer = num3
							Dim num5 As Integer = num2
							If num4 > num5 Then
								Exit For
							End If
							Dim obj As Object = Nothing
							Dim typeFromHandle As Type = GetType(Strings)
							Dim text2 As String = "UCase"
							Dim array As Object() = New Object(0) {}
							Dim array2 As Object() = array
							Dim num6 As Integer = 0
							Dim dataRow As DataRow = Me.mclsTbDMDV.Rows(num3)
							Dim dataRow2 As DataRow = dataRow
							Dim text3 As String = "OBJID"
							array2(num6) = RuntimeHelpers.GetObjectValue(dataRow2(text3))
							Dim array3 As Object() = array
							Dim array4 As Object() = array3
							Dim array5 As String() = Nothing
							Dim array6 As Type() = Nothing
							Dim array7 As Boolean() = New Boolean() { True }
							Dim obj2 As Object = NewLateBinding.LateGet(obj, typeFromHandle, text2, array4, array5, array6, array7)
							If array7(0) Then
								dataRow(text3) = RuntimeHelpers.GetObjectValue(array3(0))
							End If
							If Strings.InStr(Conversions.ToString(obj2), text, CompareMethod.Binary) > 0 Then
								GoTo IL_0406
							End If
							Dim obj3 As Object = Nothing
							Dim typeFromHandle2 As Type = GetType(Strings)
							Dim text4 As String = "UCase"
							Dim array8 As Object() = New Object(0) {}
							Dim array9 As Object() = array8
							Dim num7 As Integer = 0
							Dim dataRow3 As DataRow = Me.mclsTbDMDV.Rows(num3)
							Dim dataRow4 As DataRow = dataRow3
							Dim text5 As String = "OBJNAME"
							array9(num7) = RuntimeHelpers.GetObjectValue(dataRow4(text5))
							Dim array10 As Object() = array8
							Dim array11 As Object() = array10
							Dim array12 As String() = Nothing
							Dim array13 As Type() = Nothing
							Dim array14 As Boolean() = New Boolean() { True }
							Dim obj4 As Object = NewLateBinding.LateGet(obj3, typeFromHandle2, text4, array11, array12, array13, array14)
							If array14(0) Then
								dataRow3(text5) = RuntimeHelpers.GetObjectValue(array10(0))
							End If
							If Strings.InStr(mdlPrintReceipt.gfRemove_signVie(Conversions.ToString(obj4)), text, CompareMethod.Binary) > 0 Then
								GoTo IL_0406
							End If
							Dim obj5 As Object = Nothing
							Dim typeFromHandle3 As Type = GetType(Strings)
							Dim text6 As String = "UCase"
							Dim array15 As Object() = New Object(0) {}
							Dim array16 As Object() = array15
							Dim num8 As Integer = 0
							Dim dataRow5 As DataRow = Me.mclsTbDMDV.Rows(num3)
							Dim dataRow6 As DataRow = dataRow5
							Dim text7 As String = "OBJNAME"
							array16(num8) = RuntimeHelpers.GetObjectValue(dataRow6(text7))
							Dim array17 As Object() = array15
							Dim array18 As Object() = array17
							Dim array19 As String() = Nothing
							Dim array20 As Type() = Nothing
							Dim array21 As Boolean() = New Boolean() { True }
							Dim obj6 As Object = NewLateBinding.LateGet(obj5, typeFromHandle3, text6, array18, array19, array20, array21)
							If array21(0) Then
								dataRow5(text7) = RuntimeHelpers.GetObjectValue(array17(0))
							End If
							If Strings.InStr(Conversions.ToString(obj6), text, CompareMethod.Binary) > 0 Then
								GoTo IL_0494
							End If
							Dim obj7 As Object = Nothing
							Dim typeFromHandle4 As Type = GetType(Strings)
							Dim text8 As String = "UCase"
							Dim array22 As Object() = New Object(0) {}
							Dim array23 As Object() = array22
							Dim num9 As Integer = 0
							Dim dataRow7 As DataRow = Me.mclsTbDMDV.Rows(num3)
							Dim dataRow8 As DataRow = dataRow7
							Dim text9 As String = "MOBILE"
							array23(num9) = RuntimeHelpers.GetObjectValue(dataRow8(text9))
							Dim array24 As Object() = array22
							Dim array25 As Object() = array24
							Dim array26 As String() = Nothing
							Dim array27 As Type() = Nothing
							Dim array28 As Boolean() = New Boolean() { True }
							Dim obj8 As Object = NewLateBinding.LateGet(obj7, typeFromHandle4, text8, array25, array26, array27, array28)
							If array28(0) Then
								dataRow7(text9) = RuntimeHelpers.GetObjectValue(array24(0))
							End If
							If Strings.InStr(Conversions.ToString(obj8), text, CompareMethod.Binary) > 0 Then
								GoTo IL_0525
							End If
							Dim flag2 As Boolean = False
							IL_0526:
							flag3 = flag2
							If flag3 Then
								dataTable.Rows.Add(New Object(-1) {})
								dataTable.Rows(dataTable.Rows.Count - 1)("STT") = dataTable.Rows.Count
								dataTable.Rows(dataTable.Rows.Count - 1)("OBJID") = Me.mclsTbDMDV.Rows(num3)("OBJID").ToString().Trim()
								dataTable.Rows(dataTable.Rows.Count - 1)("OBJNAME") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("OBJNAME"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("ADDRESS") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("ADDRESS"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("MOBILE") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("MOBILE"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("BIRTHDAY") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("BIRTHDAY"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("MANHOMDV") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("MANHOMDV"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("TENNHOMDV") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("TENNHOMDV"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("VATCODE") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("VATCODE"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("TEL") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("TEL"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("MUCGIAMGIA") = RuntimeHelpers.GetObjectValue(Me.mclsTbDMDV.Rows(num3)("MUCGIAMGIA"))
								dataTable.Rows(dataTable.Rows.Count - 1)("NGAYSINH") = RuntimeHelpers.GetObjectValue(Me.mclsTbDMDV.Rows(num3)("NGAYSINH"))
							End If
							num3 += 1
							Continue For
							IL_0525:
							flag2 = True
							GoTo IL_0526
							IL_0494:
							GoTo IL_0525
							IL_0406:
							GoTo IL_0494
						End While
					End If
					Me.mbdsSourceDMDV.DataSource = dataTable
					Me.dgvDMDV.DataSource = Me.mbdsSourceDMDV
					Me.dgvDMDV.Columns("MANHOMDV").Visible = False
					Me.dgvDMDV.Columns("VATCODE").Visible = False
					Me.dgvDMDV.Columns("TEL").Visible = False
					Me.dgvDMDV.Columns("MUCGIAMGIA").Visible = False
					Me.dgvDMDV.Columns("NGAYSINH").Visible = False
					Me.dgvDMDV.Columns("STT").Width = 35
					Me.dgvDMDV.Columns("STT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(9))
					Me.dgvDMDV.Columns("STT").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
					Me.dgvDMDV.Columns("OBJID").Width = 85
					Me.dgvDMDV.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(10))
					Me.dgvDMDV.Columns("OBJNAME").Width = Me.dgvDMDV.Width - 610
					Me.dgvDMDV.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(11))
					Me.dgvDMDV.Columns("ADDRESS").Width = 160
					Me.dgvDMDV.Columns("ADDRESS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(12))
					Me.dgvDMDV.Columns("MOBILE").Width = 105
					Me.dgvDMDV.Columns("MOBILE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(13))
					Me.dgvDMDV.Columns("BIRTHDAY").Width = 85
					Me.dgvDMDV.Columns("BIRTHDAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(14))
					Me.dgvDMDV.Columns("BIRTHDAY").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
					Me.dgvDMDV.Columns("TENNHOMDV").Width = 120
					Me.dgvDMDV.Columns("TENNHOMDV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(15))
					flag3 = dataTable.Rows.Count > 0
					If flag3 Then
						Me.dgvDMDV.Focus()
					End If
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - f_GetData_4GridMADV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060009A3 RID: 2467 RVA: 0x00071D1C File Offset: 0x0006FF1C
		Private Function fCheckUserGroup_03(strMaUser As String) As Boolean
			Dim flag3 As Boolean
			Try
				Dim array As SqlParameter() = New SqlParameter(1) {}
				array(0) = New SqlParameter("@pchrOBJID", strMaUser)
				Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
				Dim array2 As SqlParameter() = array
				Dim text As String = "SP_CHECK_UUSER_GROUP_01"
				Dim num As Integer = CInt(0S)
				Dim clsConnect As clsConnect = New clsConnect(gStrConISDANHMUC, array2, text, num)
				Dim flag As Boolean = clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
				If flag Then
					Dim flag2 As Boolean = Operators.CompareString(clsConnect.Rows(0)("MAGROUP").ToString().Trim(), "03", False) = 0
					If flag2 Then
						Return True
					End If
				End If
				flag3 = False
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fCheckUserGroup_01 " + ex.Message + vbCrLf, MsgBoxStyle.Critical, Nothing)
			End Try
			Return flag3
		End Function

		' Token: 0x060009A4 RID: 2468 RVA: 0x00071E00 File Offset: 0x00070000
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060009A5 RID: 2469 RVA: 0x00071EFC File Offset: 0x000700FC
		Private Function fGetData_DMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
				Dim text As String = "SP_FRMSAL011_GET_DMDV"
				Dim flag As Boolean = Nothing
				Me.mclsTbDMDV = New clsConnect(gStrConISDANHMUC, text, flag)
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060009A6 RID: 2470 RVA: 0x00071FBC File Offset: 0x000701BC
		Private Sub Label1_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.mblnRightSelectDV
			If Not flag Then
				Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
				frmKeyBoard.ShowDialog()
				Me.txtMa.Text = frmKeyBoard.pStrEnterText
			End If
		End Sub

		' Token: 0x060009A7 RID: 2471 RVA: 0x00071FFC File Offset: 0x000701FC
		Private Sub Label3_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.mblnRightSelectDV
			If Not flag Then
				Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
				frmKeyBoard.ShowDialog()
				Me.txtTENDV.Text = frmKeyBoard.pStrEnterText
			End If
		End Sub

		' Token: 0x0400041D RID: 1053
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400041F RID: 1055
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000420 RID: 1056
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x04000421 RID: 1057
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000422 RID: 1058
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000423 RID: 1059
		<AccessedThroughProperty("btnKH")>
		Private _btnKH As Button

		' Token: 0x04000424 RID: 1060
		<AccessedThroughProperty("txtMa")>
		Private _txtMa As TextBox

		' Token: 0x04000425 RID: 1061
		<AccessedThroughProperty("tmrRight")>
		Private _tmrRight As Timer

		' Token: 0x04000426 RID: 1062
		<AccessedThroughProperty("ContextMenuStrip1")>
		Private _ContextMenuStrip1 As ContextMenuStrip

		' Token: 0x04000427 RID: 1063
		<AccessedThroughProperty("lblTitle")>
		Private _lblTitle As Label

		' Token: 0x04000428 RID: 1064
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000429 RID: 1065
		<AccessedThroughProperty("dgvDMDV")>
		Private _dgvDMDV As DataGridView

		' Token: 0x0400042A RID: 1066
		<AccessedThroughProperty("txtTENDV")>
		Private _txtTENDV As TextBox

		' Token: 0x0400042B RID: 1067
		Private mstrMa As String

		' Token: 0x0400042C RID: 1068
		Private mstrTen As String

		' Token: 0x0400042D RID: 1069
		Private mstrNHOMDV As String

		' Token: 0x0400042E RID: 1070
		Private mstrDiachi As String

		' Token: 0x0400042F RID: 1071
		Private mstrDienthoai As String

		' Token: 0x04000430 RID: 1072
		Private mdtNgaySinh As DateTime

		' Token: 0x04000431 RID: 1073
		Private mdblMucGiamGia As Double

		' Token: 0x04000432 RID: 1074
		Private mblnOK As Boolean

		' Token: 0x04000433 RID: 1075
		Private mArrStrFrmMess As String()

		' Token: 0x04000434 RID: 1076
		Private mclsTbDMDV As clsConnect

		' Token: 0x04000435 RID: 1077
		<AccessedThroughProperty("mbdsSourceDMDV")>
		Private _mbdsSourceDMDV As BindingSource

		' Token: 0x04000436 RID: 1078
		Private mintPosDV As Integer

		' Token: 0x04000437 RID: 1079
		Private mblnRightSelectDV As Boolean

		' Token: 0x04000438 RID: 1080
		Private mintCount As Integer

		' Token: 0x04000439 RID: 1081
		Private mintCountTruoc As Integer

		' Token: 0x0400043A RID: 1082
		Private mblnClickSave As Boolean

		' Token: 0x0400043B RID: 1083
		Private mblnAutoAdd_DMDV As Boolean
	End Class
End Namespace
