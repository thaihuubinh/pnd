﻿Namespace prjIS_SalesPOS
	' Token: 0x02000028 RID: 40
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmConnecting
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600079C RID: 1948 RVA: 0x00059898 File Offset: 0x00057A98
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600079D RID: 1949 RVA: 0x000598D0 File Offset: 0x00057AD0
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.picLoad = New Global.System.Windows.Forms.PictureBox()
			CType(Me.picLoad, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.picLoad.Image = Global.prjIS_SalesPOS.My.Resources.Resources.loading_bar
			Dim picLoad As Global.System.Windows.Forms.Control = Me.picLoad
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(4, 1)
			picLoad.Location = point
			Me.picLoad.Name = "picLoad"
			Dim picLoad2 As Global.System.Windows.Forms.Control = Me.picLoad
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(100, 10)
			picLoad2.Size = size
			Me.picLoad.TabIndex = 13
			Me.picLoad.TabStop = False
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			Me.BackColor = Global.System.Drawing.Color.White
			size = New Global.System.Drawing.Size(108, 12)
			Me.ClientSize = size
			Me.Controls.Add(Me.picLoad)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Name = "frmConnecting"
			Me.Text = "frmConnecting"
			CType(Me.picLoad, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x04000356 RID: 854
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
