﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000208 RID: 520
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60510
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006109 RID: 24841 RVA: 0x000115A7 File Offset: 0x0000F7A7
		Public Sub New()
			CachedrptRepBC60510.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002490 RID: 9360
		' (get) Token: 0x0600610A RID: 24842 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x0600610B RID: 24843 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002491 RID: 9361
		' (get) Token: 0x0600610C RID: 24844 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x0600610D RID: 24845 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002492 RID: 9362
		' (get) Token: 0x0600610E RID: 24846 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x0600610F RID: 24847 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006110 RID: 24848 RVA: 0x004DCC60 File Offset: 0x004DAE60
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60510() With { .Site = Me.Site }
		End Function

		' Token: 0x06006111 RID: 24849 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002800 RID: 10240
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
