﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200016A RID: 362
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptDMMANHINH
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005A7A RID: 23162 RVA: 0x0000FC59 File Offset: 0x0000DE59
		Public Sub New()
			CachedrptDMMANHINH.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002117 RID: 8471
		' (get) Token: 0x06005A7B RID: 23163 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005A7C RID: 23164 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002118 RID: 8472
		' (get) Token: 0x06005A7D RID: 23165 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005A7E RID: 23166 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002119 RID: 8473
		' (get) Token: 0x06005A7F RID: 23167 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005A80 RID: 23168 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005A81 RID: 23169 RVA: 0x004DB8A0 File Offset: 0x004D9AA0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptDMMANHINH() With { .Site = Me.Site }
		End Function

		' Token: 0x06005A82 RID: 23170 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002762 RID: 10082
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
