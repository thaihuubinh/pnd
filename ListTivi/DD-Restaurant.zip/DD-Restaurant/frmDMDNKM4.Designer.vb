﻿Namespace prjIS_SalesPOS
	' Token: 0x02000040 RID: 64
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMDNKM4
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000F85 RID: 3973 RVA: 0x000B9008 File Offset: 0x000B7208
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000F86 RID: 3974 RVA: 0x000B9040 File Offset: 0x000B7240
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMDNKM4))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnThemAll = New Global.System.Windows.Forms.Button()
			Me.btnThem1MH = New Global.System.Windows.Forms.Button()
			Me.btnGobo = New Global.System.Windows.Forms.Button()
			Me.btnGoBoAll = New Global.System.Windows.Forms.Button()
			Me.lstHanghoaThemAll = New Global.System.Windows.Forms.ListBox()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(536, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 490)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 7
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnThemAll, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnThem1MH, 0, 2)
			Me.TableLayoutPanel1.Controls.Add(Me.btnGobo, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnGoBoAll, 0, 4)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 6
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 469)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 393)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 73)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 3)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(107, 72)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 4
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnThemAll.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim btnThemAll As Global.System.Windows.Forms.Control = Me.btnThemAll
			point = New Global.System.Drawing.Point(3, 81)
			btnThemAll.Location = point
			Me.btnThemAll.Name = "btnThemAll"
			Dim btnThemAll2 As Global.System.Windows.Forms.Control = Me.btnThemAll
			size = New Global.System.Drawing.Size(107, 72)
			btnThemAll2.Size = size
			Me.btnThemAll.TabIndex = 9
			Me.btnThemAll.Tag = "CR0015"
			Me.btnThemAll.Text = "Thêm tất cả"
			Me.btnThemAll.UseVisualStyleBackColor = True
			Me.btnThem1MH.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim btnThem1MH As Global.System.Windows.Forms.Control = Me.btnThem1MH
			point = New Global.System.Drawing.Point(3, 159)
			btnThem1MH.Location = point
			Me.btnThem1MH.Name = "btnThem1MH"
			Dim btnThem1MH2 As Global.System.Windows.Forms.Control = Me.btnThem1MH
			size = New Global.System.Drawing.Size(107, 72)
			btnThem1MH2.Size = size
			Me.btnThem1MH.TabIndex = 10
			Me.btnThem1MH.Tag = "CR0016"
			Me.btnThem1MH.Text = "Thêm 1 mặt hàng"
			Me.btnThem1MH.UseVisualStyleBackColor = True
			Me.btnGobo.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim btnGobo As Global.System.Windows.Forms.Control = Me.btnGobo
			point = New Global.System.Drawing.Point(3, 237)
			btnGobo.Location = point
			Me.btnGobo.Name = "btnGobo"
			Dim btnGobo2 As Global.System.Windows.Forms.Control = Me.btnGobo
			size = New Global.System.Drawing.Size(107, 72)
			btnGobo2.Size = size
			Me.btnGobo.TabIndex = 11
			Me.btnGobo.Tag = "CR0018"
			Me.btnGobo.Text = "Gỡ bỏ "
			Me.btnGobo.UseVisualStyleBackColor = True
			Dim btnGoBoAll As Global.System.Windows.Forms.Control = Me.btnGoBoAll
			point = New Global.System.Drawing.Point(3, 315)
			btnGoBoAll.Location = point
			Me.btnGoBoAll.Name = "btnGoBoAll"
			Dim btnGoBoAll2 As Global.System.Windows.Forms.Control = Me.btnGoBoAll
			size = New Global.System.Drawing.Size(107, 72)
			btnGoBoAll2.Size = size
			Me.btnGoBoAll.TabIndex = 11
			Me.btnGoBoAll.Tag = "CR0017"
			Me.btnGoBoAll.Text = "Gỡ bỏ hết"
			Me.btnGoBoAll.UseVisualStyleBackColor = True
			Me.lstHanghoaThemAll.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.lstHanghoaThemAll.FormattingEnabled = True
			Me.lstHanghoaThemAll.ItemHeight = 16
			Dim lstHanghoaThemAll As Global.System.Windows.Forms.Control = Me.lstHanghoaThemAll
			point = New Global.System.Drawing.Point(13, 13)
			lstHanghoaThemAll.Location = point
			Me.lstHanghoaThemAll.Name = "lstHanghoaThemAll"
			Dim lstHanghoaThemAll2 As Global.System.Windows.Forms.Control = Me.lstHanghoaThemAll
			size = New Global.System.Drawing.Size(517, 468)
			lstHanghoaThemAll2.Size = size
			Me.lstHanghoaThemAll.TabIndex = 13
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(655, 490)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.lstHanghoaThemAll)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMDNKM4"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Chi tiết khuyến mãi"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x0400068F RID: 1679
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
