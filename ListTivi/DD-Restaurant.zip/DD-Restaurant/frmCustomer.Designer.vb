﻿Namespace prjIS_SalesPOS
	' Token: 0x0200002F RID: 47
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCustomer
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000966 RID: 2406 RVA: 0x0006E7A4 File Offset: 0x0006C9A4
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000967 RID: 2407 RVA: 0x0006E7DC File Offset: 0x0006C9DC
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Global.System.ComponentModel.Container()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCustomer))
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnKH = New Global.System.Windows.Forms.Button()
			Me.txtMa = New Global.System.Windows.Forms.TextBox()
			Me.ContextMenuStrip1 = New Global.System.Windows.Forms.ContextMenuStrip(Me.components)
			Me.tmrRight = New Global.System.Windows.Forms.Timer(Me.components)
			Me.lblTitle = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.dgvDMDV = New Global.System.Windows.Forms.DataGridView()
			Me.txtTENDV = New Global.System.Windows.Forms.TextBox()
			CType(Me.dgvDMDV, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label1.ForeColor = Global.System.Drawing.Color.Black
			Me.Label1.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.Label1.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(12, 47)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(101, 34)
			label2.Size = size
			Me.Label1.TabIndex = 0
			Me.Label1.Tag = "CB0002"
			Me.Label1.Text = "Mã"
			Me.Label1.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.Label3.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label3.ForeColor = Global.System.Drawing.Color.Black
			Me.Label3.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.Label3.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(12, 93)
			label3.Location = point
			Me.Label3.Name = "Label3"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(101, 35)
			label4.Size = size
			Me.Label3.TabIndex = 0
			Me.Label3.Tag = "CB0003"
			Me.Label3.Text = "Tên"
			Me.Label3.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnExit.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(340, 140)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(111, 41)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 4
			Me.btnExit.Tag = "C00005"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = False
			Me.btnSave.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnSave.BackgroundImage = CType(componentResourceManager.GetObject("btnSave.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnSave.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnSave.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnSave.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Me.btnSave.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(22, 140)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(111, 41)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 3
			Me.btnSave.Tag = "C00004"
			Me.btnSave.Text = "Chọn"
			Me.btnSave.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = False
			Me.btnKH.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btnKH.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.None
			Me.btnKH.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnKH.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnKH.Image = CType(componentResourceManager.GetObject("btnKH.Image"), Global.System.Drawing.Image)
			Dim btnKH As Global.System.Windows.Forms.Control = Me.btnKH
			point = New Global.System.Drawing.Point(398, 41)
			btnKH.Location = point
			Me.btnKH.Name = "btnKH"
			Dim btnKH2 As Global.System.Windows.Forms.Control = Me.btnKH
			size = New Global.System.Drawing.Size(53, 45)
			btnKH2.Size = size
			Me.btnKH.TabIndex = 1
			Me.btnKH.Tag = ""
			Me.btnKH.UseVisualStyleBackColor = True
			Me.txtMa.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.txtMa.ContextMenuStrip = Me.ContextMenuStrip1
			Me.txtMa.Font = New Global.System.Drawing.Font("Arial", 20.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtMa As Global.System.Windows.Forms.Control = Me.txtMa
			point = New Global.System.Drawing.Point(116, 44)
			txtMa.Location = point
			Me.txtMa.Name = "txtMa"
			Dim txtMa2 As Global.System.Windows.Forms.Control = Me.txtMa
			size = New Global.System.Drawing.Size(276, 39)
			txtMa2.Size = size
			Me.txtMa.TabIndex = 0
			Me.txtMa.Tag = "N0020R0000"
			Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
			Dim contextMenuStrip As Global.System.Windows.Forms.Control = Me.ContextMenuStrip1
			size = New Global.System.Drawing.Size(61, 4)
			contextMenuStrip.Size = size
			Me.tmrRight.Interval = 40
			Me.lblTitle.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.lblTitle.BackColor = Global.System.Drawing.Color.Gray
			Me.lblTitle.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblTitle.ForeColor = Global.System.Drawing.Color.White
			Dim lblTitle As Global.System.Windows.Forms.Control = Me.lblTitle
			point = New Global.System.Drawing.Point(0, 1)
			lblTitle.Location = point
			Me.lblTitle.Name = "lblTitle"
			Dim lblTitle2 As Global.System.Windows.Forms.Control = Me.lblTitle
			size = New Global.System.Drawing.Size(463, 30)
			lblTitle2.Size = size
			Me.lblTitle.TabIndex = 5
			Me.lblTitle.Tag = "CB0008"
			Me.lblTitle.Text = "Chọn khách hàng"
			Me.lblTitle.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label2.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.Label2.BackColor = Global.System.Drawing.Color.Gray
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label2.ForeColor = Global.System.Drawing.Color.White
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(-5, 184)
			label5.Location = point
			Me.Label2.Name = "Label2"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(470, 5)
			label6.Size = size
			Me.Label2.TabIndex = 6
			Me.Label2.Tag = ""
			Me.Label2.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.dgvDMDV.AllowUserToAddRows = False
			Me.dgvDMDV.AllowUserToDeleteRows = False
			Me.dgvDMDV.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvDMDV.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.dgvDMDV.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvDMDV As Global.System.Windows.Forms.Control = Me.dgvDMDV
			point = New Global.System.Drawing.Point(2, 89)
			dgvDMDV.Location = point
			Me.dgvDMDV.Name = "dgvDMDV"
			Me.dgvDMDV.[ReadOnly] = True
			Dim dgvDMDV2 As Global.System.Windows.Forms.Control = Me.dgvDMDV
			size = New Global.System.Drawing.Size(460, 95)
			dgvDMDV2.Size = size
			Me.dgvDMDV.TabIndex = 101
			Me.dgvDMDV.Visible = False
			Me.txtTENDV.Font = New Global.System.Drawing.Font("Arial", 20.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtTENDV As Global.System.Windows.Forms.Control = Me.txtTENDV
			point = New Global.System.Drawing.Point(116, 89)
			txtTENDV.Location = point
			Me.txtTENDV.Name = "txtTENDV"
			Dim txtTENDV2 As Global.System.Windows.Forms.Control = Me.txtTENDV
			size = New Global.System.Drawing.Size(335, 39)
			txtTENDV2.Size = size
			Me.txtTENDV.TabIndex = 0
			Me.txtTENDV.Tag = "N0020R0000"
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			Me.BackColor = Global.System.Drawing.Color.FromArgb(224, 224, 224)
			size = New Global.System.Drawing.Size(463, 187)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.dgvDMDV)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.lblTitle)
			Me.Controls.Add(Me.txtMa)
			Me.Controls.Add(Me.btnKH)
			Me.Controls.Add(Me.txtTENDV)
			Me.Controls.Add(Me.btnExit)
			Me.Controls.Add(Me.btnSave)
			Me.Controls.Add(Me.Label3)
			Me.Controls.Add(Me.Label1)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Me.KeyPreview = True
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmCustomer"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "kh"
			CType(Me.dgvDMDV, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x0400041E RID: 1054
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
