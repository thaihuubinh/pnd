﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000068 RID: 104
	<DesignerGenerated()>
	Public Partial Class frmDMMT2
		Inherits Form

		' Token: 0x060020E7 RID: 8423 RVA: 0x00198128 File Offset: 0x00196328
		<DebuggerNonUserCode()>
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMMT2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMMT2_Load
			frmDMMT2.__ENCList.Add(New WeakReference(Me))
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000B48 RID: 2888
		' (get) Token: 0x060020EA RID: 8426 RVA: 0x00199050 File Offset: 0x00197250
		' (set) Token: 0x060020EB RID: 8427 RVA: 0x00006A83 File Offset: 0x00004C83
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000B49 RID: 2889
		' (get) Token: 0x060020EC RID: 8428 RVA: 0x00199068 File Offset: 0x00197268
		' (set) Token: 0x060020ED RID: 8429 RVA: 0x00199080 File Offset: 0x00197280
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000B4A RID: 2890
		' (get) Token: 0x060020EE RID: 8430 RVA: 0x001990EC File Offset: 0x001972EC
		' (set) Token: 0x060020EF RID: 8431 RVA: 0x00006A8D File Offset: 0x00004C8D
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x17000B4B RID: 2891
		' (get) Token: 0x060020F0 RID: 8432 RVA: 0x00199104 File Offset: 0x00197304
		' (set) Token: 0x060020F1 RID: 8433 RVA: 0x0019911C File Offset: 0x0019731C
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000B4C RID: 2892
		' (get) Token: 0x060020F2 RID: 8434 RVA: 0x00199188 File Offset: 0x00197388
		' (set) Token: 0x060020F3 RID: 8435 RVA: 0x001991A0 File Offset: 0x001973A0
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000B4D RID: 2893
		' (get) Token: 0x060020F4 RID: 8436 RVA: 0x0019920C File Offset: 0x0019740C
		' (set) Token: 0x060020F5 RID: 8437 RVA: 0x00199224 File Offset: 0x00197424
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000B4E RID: 2894
		' (get) Token: 0x060020F6 RID: 8438 RVA: 0x00199290 File Offset: 0x00197490
		' (set) Token: 0x060020F7 RID: 8439 RVA: 0x00006A97 File Offset: 0x00004C97
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000B4F RID: 2895
		' (get) Token: 0x060020F8 RID: 8440 RVA: 0x001992A8 File Offset: 0x001974A8
		' (set) Token: 0x060020F9 RID: 8441 RVA: 0x001992C0 File Offset: 0x001974C0
		Friend Overridable Property txtRate As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtRate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtRate IsNot Nothing
				If flag Then
					RemoveHandler Me._txtRate.KeyPress, AddressOf Me.txtRate_KeyPress
					RemoveHandler Me._txtRate.GotFocus, AddressOf Me.txtRate_GotFocus
				End If
				Me._txtRate = value
				flag = Me._txtRate IsNot Nothing
				If flag Then
					AddHandler Me._txtRate.KeyPress, AddressOf Me.txtRate_KeyPress
					AddHandler Me._txtRate.GotFocus, AddressOf Me.txtRate_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000B50 RID: 2896
		' (get) Token: 0x060020FA RID: 8442 RVA: 0x0019935C File Offset: 0x0019755C
		' (set) Token: 0x060020FB RID: 8443 RVA: 0x00006AA1 File Offset: 0x00004CA1
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000B51 RID: 2897
		' (get) Token: 0x060020FC RID: 8444 RVA: 0x00199374 File Offset: 0x00197574
		' (set) Token: 0x060020FD RID: 8445 RVA: 0x0019938C File Offset: 0x0019758C
		Friend Overridable Property cmbInclude As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbInclude
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbInclude IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbInclude.KeyPress, AddressOf Me.cmbInclude_KeyPress
					RemoveHandler Me._cmbInclude.GotFocus, AddressOf Me.cmbInclude_GotFocus
					RemoveHandler Me._cmbInclude.Click, AddressOf Me.cmbInclude_Click
				End If
				Me._cmbInclude = value
				flag = Me._cmbInclude IsNot Nothing
				If flag Then
					AddHandler Me._cmbInclude.KeyPress, AddressOf Me.cmbInclude_KeyPress
					AddHandler Me._cmbInclude.GotFocus, AddressOf Me.cmbInclude_GotFocus
					AddHandler Me._cmbInclude.Click, AddressOf Me.cmbInclude_Click
				End If
			End Set
		End Property

		' Token: 0x17000B52 RID: 2898
		' (get) Token: 0x060020FE RID: 8446 RVA: 0x0019945C File Offset: 0x0019765C
		' (set) Token: 0x060020FF RID: 8447 RVA: 0x00006AAB File Offset: 0x00004CAB
		Friend Overridable Property lblRate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblRate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblRate = value
			End Set
		End Property

		' Token: 0x17000B53 RID: 2899
		' (get) Token: 0x06002100 RID: 8448 RVA: 0x00199474 File Offset: 0x00197674
		' (set) Token: 0x06002101 RID: 8449 RVA: 0x00006AB5 File Offset: 0x00004CB5
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x17000B54 RID: 2900
		' (get) Token: 0x06002102 RID: 8450 RVA: 0x0019948C File Offset: 0x0019768C
		' (set) Token: 0x06002103 RID: 8451 RVA: 0x001994A4 File Offset: 0x001976A4
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000B55 RID: 2901
		' (get) Token: 0x06002104 RID: 8452 RVA: 0x00199540 File Offset: 0x00197740
		' (set) Token: 0x06002105 RID: 8453 RVA: 0x00199558 File Offset: 0x00197758
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000B56 RID: 2902
		' (get) Token: 0x06002106 RID: 8454 RVA: 0x001995F4 File Offset: 0x001977F4
		' (set) Token: 0x06002107 RID: 8455 RVA: 0x00006ABF File Offset: 0x00004CBF
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x17000B57 RID: 2903
		' (get) Token: 0x06002108 RID: 8456 RVA: 0x0019960C File Offset: 0x0019780C
		' (set) Token: 0x06002109 RID: 8457 RVA: 0x00006AC9 File Offset: 0x00004CC9
		Friend Overridable Property txtColor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtColor = value
			End Set
		End Property

		' Token: 0x17000B58 RID: 2904
		' (get) Token: 0x0600210A RID: 8458 RVA: 0x00199624 File Offset: 0x00197824
		' (set) Token: 0x0600210B RID: 8459 RVA: 0x00006AD3 File Offset: 0x00004CD3
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000B59 RID: 2905
		' (get) Token: 0x0600210C RID: 8460 RVA: 0x0019963C File Offset: 0x0019783C
		' (set) Token: 0x0600210D RID: 8461 RVA: 0x00199654 File Offset: 0x00197854
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x17000B5A RID: 2906
		' (get) Token: 0x0600210E RID: 8462 RVA: 0x001996C0 File Offset: 0x001978C0
		' (set) Token: 0x0600210F RID: 8463 RVA: 0x00006ADD File Offset: 0x00004CDD
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000B5B RID: 2907
		' (get) Token: 0x06002110 RID: 8464 RVA: 0x001996D8 File Offset: 0x001978D8
		' (set) Token: 0x06002111 RID: 8465 RVA: 0x00006AE8 File Offset: 0x00004CE8
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000B5C RID: 2908
		' (get) Token: 0x06002112 RID: 8466 RVA: 0x001996F0 File Offset: 0x001978F0
		' (set) Token: 0x06002113 RID: 8467 RVA: 0x00006AF3 File Offset: 0x00004CF3
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06002114 RID: 8468 RVA: 0x00199708 File Offset: 0x00197908
		Private Sub txtRate_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Dim flag2 As Boolean = Me.cmbInclude.Enabled
					If flag2 Then
						Me.cmbInclude.Focus()
					Else
						Me.btnDelete.Focus()
					End If
				Else
					Dim flag3 As Boolean
					If num < 48 OrElse num > 58 Then
						If num <> 8 Then
							flag3 = False
							GoTo IL_005D
						End If
					End If
					flag3 = True
					IL_005D:
					Dim flag2 As Boolean = flag3
					If Not flag2 Then
						e.Handled = True
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtRate_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002115 RID: 8469 RVA: 0x001997F8 File Offset: 0x001979F8
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtRate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002116 RID: 8470 RVA: 0x0019989C File Offset: 0x00197A9C
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002117 RID: 8471 RVA: 0x00199948 File Offset: 0x00197B48
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.btnExit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002118 RID: 8472 RVA: 0x001999F4 File Offset: 0x00197BF4
		Private Sub txtRate_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtRate.[ReadOnly]
				If [readOnly] Then
					Me.btnExit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtRate_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002119 RID: 8473 RVA: 0x00199AA0 File Offset: 0x00197CA0
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600211A RID: 8474 RVA: 0x00199B44 File Offset: 0x00197D44
		Private Sub frmDMMT2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitCombo()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMT2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600211B RID: 8475 RVA: 0x00199C04 File Offset: 0x00197E04
		Private Sub frmDMMT2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMT2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600211C RID: 8476 RVA: 0x00199CB0 File Offset: 0x00197EB0
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
						If flag Then
							Me.mbytSuccess = Me.fAddNew()
						Else
							flag = Me.mbytFormStatus = 3
							If flag Then
								Me.mbytSuccess = Me.fModify()
							End If
						End If
						flag = Me.mbytSuccess = 1
						If flag Then
							Me.Close()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600211D RID: 8477 RVA: 0x00199E3C File Offset: 0x0019803C
		Private Sub cmbInclude_Click(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.btnExit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbInclude_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600211E RID: 8478 RVA: 0x00199EDC File Offset: 0x001980DC
		Private Sub cmbInclude_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.btnExit.Focus()
				Else
					Me.cmbInclude.DroppedDown = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbInclude_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600211F RID: 8479 RVA: 0x00199F9C File Offset: 0x0019819C
		Private Sub cmbInclude_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim flag2 As Boolean = Me.mbytFormStatus = 5
					If flag2 Then
						Me.btnFilter.Focus()
					Else
						flag2 = Me.mbytFormStatus = 6
						If flag2 Then
							Me.btnFind.Focus()
						Else
							Me.btnSave.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbInclude_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002120 RID: 8480 RVA: 0x0019A088 File Offset: 0x00198288
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002121 RID: 8481 RVA: 0x0019A12C File Offset: 0x0019832C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				text2 = Strings.Trim(Me.txtRate.Text)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " RATE = "), text2), ""))
				End If
				flag = Me.cmbInclude.SelectedIndex <= 1
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " STS01 = "), Me.cmbInclude.SelectedIndex), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002122 RID: 8482 RVA: 0x0019A38C File Offset: 0x0019858C
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				text2 = Strings.Trim(Me.txtRate.Text)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " RATE = "), text2), ""))
				End If
				flag = Me.cmbInclude.SelectedIndex <= 1
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " STS01 = "), Me.cmbInclude.SelectedIndex), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002123 RID: 8483 RVA: 0x0019A5EC File Offset: 0x001987EC
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtRate.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.BackColor = Me.txtColor.BackColor
						Me.txtRate.BackColor = Me.txtColor.BackColor
						Me.cmbInclude.BackColor = Me.txtColor.BackColor
						Me.cmbInclude.DropDownStyle = ComboBoxStyle.DropDown
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002124 RID: 8484 RVA: 0x0019A780 File Offset: 0x00198980
		Private Function fInitCombo() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 5) Or (Me.mbytFormStatus = 6)
				If flag Then
					Dim array As String() = New String(3) {}
					array(0) = Me.mArrStrFrmMess(12)
					array(1) = Me.mArrStrFrmMess(11)
					array(2) = ""
					Me.cmbInclude.DataSource = array
					Me.cmbInclude.SelectedIndex = 2
				Else
					Dim array2 As String() = New String(2) {}
					array2(0) = Me.mArrStrFrmMess(12)
					array2(1) = Me.mArrStrFrmMess(11)
					Me.cmbInclude.DataSource = array2
					Me.cmbInclude.SelectedIndex = 0
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002125 RID: 8485 RVA: 0x0019A8D4 File Offset: 0x00198AD4
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002126 RID: 8486 RVA: 0x0019AA64 File Offset: 0x00198C64
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 2
				Me.txtOBJNAME.MaxLength = 20
				Me.txtRate.MaxLength = 3
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				Me.cmbInclude.DropDownStyle = ComboBoxStyle.DropDownList
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002127 RID: 8487 RVA: 0x0019AB50 File Offset: 0x00198D50
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002128 RID: 8488 RVA: 0x0019AD34 File Offset: 0x00198F34
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002129 RID: 8489 RVA: 0x0019ADD4 File Offset: 0x00198FD4
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@ptniRATE"
				array(2).Value = Strings.Trim(Me.txtRate.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pbitGIATHUE"
				array(3).Value = Me.cmbInclude.SelectedIndex
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@int_Result"
				array(4).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMT_INSERT_DMMT", flag)
				Dim num As Integer = Conversions.ToInteger(array(4).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600212A RID: 8490 RVA: 0x0019B03C File Offset: 0x0019923C
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@ptniRATE"
				array(2).Value = Strings.Trim(Me.txtRate.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pbitGIATHUE"
				array(3).Value = Me.cmbInclude.SelectedIndex
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@int_Result"
				array(4).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMT_UPDATE_DMMT", flag)
				Dim num As Integer = Conversions.ToInteger(array(4).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600212B RID: 8491 RVA: 0x0019B294 File Offset: 0x00199494
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMT_DEL_DMMT", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600212C RID: 8492 RVA: 0x0019B458 File Offset: 0x00199658
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x0600212D RID: 8493 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x04000D75 RID: 3445
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000D77 RID: 3447
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000D78 RID: 3448
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000D79 RID: 3449
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000D7A RID: 3450
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000D7B RID: 3451
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000D7C RID: 3452
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000D7D RID: 3453
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000D7E RID: 3454
		<AccessedThroughProperty("txtRate")>
		Private _txtRate As TextBox

		' Token: 0x04000D7F RID: 3455
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000D80 RID: 3456
		<AccessedThroughProperty("cmbInclude")>
		Private _cmbInclude As ComboBox

		' Token: 0x04000D81 RID: 3457
		<AccessedThroughProperty("lblRate")>
		Private _lblRate As Label

		' Token: 0x04000D82 RID: 3458
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000D83 RID: 3459
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000D84 RID: 3460
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000D85 RID: 3461
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000D86 RID: 3462
		<AccessedThroughProperty("txtColor")>
		Private _txtColor As TextBox

		' Token: 0x04000D87 RID: 3463
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000D88 RID: 3464
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000D89 RID: 3465
		Private mArrStrFrmMess As String()

		' Token: 0x04000D8A RID: 3466
		Private mbytFormStatus As Byte

		' Token: 0x04000D8B RID: 3467
		Private mbytSuccess As Byte

		' Token: 0x04000D8C RID: 3468
		Private mStrFilter As String
	End Class
End Namespace
