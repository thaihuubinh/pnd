﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x0200010F RID: 271
	Public Class crpKitchenTemNhaKhoa
		Inherits ReportClass

		' Token: 0x060056A7 RID: 22183 RVA: 0x0000EDC6 File Offset: 0x0000CFC6
		Public Sub New()
			crpKitchenTemNhaKhoa.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001F09 RID: 7945
		' (get) Token: 0x060056A8 RID: 22184 RVA: 0x004DAD48 File Offset: 0x004D8F48
		' (set) Token: 0x060056A9 RID: 22185 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crpKitchenTemNhaKhoa.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001F0A RID: 7946
		' (get) Token: 0x060056AA RID: 22186 RVA: 0x004DA738 File Offset: 0x004D8938
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsLogo As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001F0B RID: 7947
		' (get) Token: 0x060056AB RID: 22187 RVA: 0x004DA75C File Offset: 0x004D895C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property phsTieude1 As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001F0C RID: 7948
		' (get) Token: 0x060056AC RID: 22188 RVA: 0x004DA780 File Offset: 0x004D8980
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dsDVTTEN As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001F0D RID: 7949
		' (get) Token: 0x060056AD RID: 22189 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001F0E RID: 7950
		' (get) Token: 0x060056AE RID: 22190 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property sNgay2 As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001F0F RID: 7951
		' (get) Token: 0x060056AF RID: 22191 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x04002707 RID: 9991
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
