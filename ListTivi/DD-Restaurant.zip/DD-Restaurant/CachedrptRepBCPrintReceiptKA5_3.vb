﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002E8 RID: 744
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBCPrintReceiptKA5_3
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006E89 RID: 28297 RVA: 0x00013987 File Offset: 0x00011B87
		Public Sub New()
			CachedrptRepBCPrintReceiptKA5_3.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002DB0 RID: 11696
		' (get) Token: 0x06006E8A RID: 28298 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006E8B RID: 28299 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002DB1 RID: 11697
		' (get) Token: 0x06006E8C RID: 28300 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006E8D RID: 28301 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002DB2 RID: 11698
		' (get) Token: 0x06006E8E RID: 28302 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006E8F RID: 28303 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006E90 RID: 28304 RVA: 0x004DEF44 File Offset: 0x004DD144
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBCPrintReceiptKA5_3() With { .Site = Me.Site }
		End Function

		' Token: 0x06006E91 RID: 28305 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028E0 RID: 10464
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
