﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000168 RID: 360
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptDMLX
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005A65 RID: 23141 RVA: 0x0000FC07 File Offset: 0x0000DE07
		Public Sub New()
			CachedrptDMLX.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x1700210C RID: 8460
		' (get) Token: 0x06005A66 RID: 23142 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005A67 RID: 23143 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700210D RID: 8461
		' (get) Token: 0x06005A68 RID: 23144 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005A69 RID: 23145 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700210E RID: 8462
		' (get) Token: 0x06005A6A RID: 23146 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005A6B RID: 23147 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005A6C RID: 23148 RVA: 0x004DB860 File Offset: 0x004D9A60
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptDMLX() With { .Site = Me.Site }
		End Function

		' Token: 0x06005A6D RID: 23149 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002760 RID: 10080
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
