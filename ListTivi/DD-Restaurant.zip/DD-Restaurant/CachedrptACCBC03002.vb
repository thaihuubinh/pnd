﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200012A RID: 298
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptACCBC03002
		Inherits Component
		Implements ICachedReport

		' Token: 0x060057F9 RID: 22521 RVA: 0x0000F219 File Offset: 0x0000D419
		Public Sub New()
			CachedrptACCBC03002.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001FD6 RID: 8150
		' (get) Token: 0x060057FA RID: 22522 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060057FB RID: 22523 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17001FD7 RID: 8151
		' (get) Token: 0x060057FC RID: 22524 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060057FD RID: 22525 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17001FD8 RID: 8152
		' (get) Token: 0x060057FE RID: 22526 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060057FF RID: 22527 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005800 RID: 22528 RVA: 0x004DB0A0 File Offset: 0x004D92A0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptACCBC03002() With { .Site = Me.Site }
		End Function

		' Token: 0x06005801 RID: 22529 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002722 RID: 10018
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
