﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x02000117 RID: 279
	Public Class crpPhieuKiemMonK80
		Inherits ReportClass

		' Token: 0x06005716 RID: 22294 RVA: 0x0000EF0E File Offset: 0x0000D10E
		Public Sub New()
			crpPhieuKiemMonK80.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001F50 RID: 8016
		' (get) Token: 0x06005717 RID: 22295 RVA: 0x004DAE48 File Offset: 0x004D9048
		' (set) Token: 0x06005718 RID: 22296 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crpPhieuKiemMonK80.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001F51 RID: 8017
		' (get) Token: 0x06005719 RID: 22297 RVA: 0x004DA738 File Offset: 0x004D8938
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection5 As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001F52 RID: 8018
		' (get) Token: 0x0600571A RID: 22298 RVA: 0x004DA75C File Offset: 0x004D895C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportHeaderSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001F53 RID: 8019
		' (get) Token: 0x0600571B RID: 22299 RVA: 0x004DA780 File Offset: 0x004D8980
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsSOTT As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001F54 RID: 8020
		' (get) Token: 0x0600571C RID: 22300 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsSoKhach As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001F55 RID: 8021
		' (get) Token: 0x0600571D RID: 22301 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection11 As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001F56 RID: 8022
		' (get) Token: 0x0600571E RID: 22302 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection3 As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x17001F57 RID: 8023
		' (get) Token: 0x0600571F RID: 22303 RVA: 0x004DA810 File Offset: 0x004D8A10
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsTenBan As Section
			Get
				Return Me.ReportDefinition.Sections(6)
			End Get
		End Property

		' Token: 0x17001F58 RID: 8024
		' (get) Token: 0x06005720 RID: 22304 RVA: 0x004DA834 File Offset: 0x004D8A34
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection4 As Section
			Get
				Return Me.ReportDefinition.Sections(7)
			End Get
		End Property

		' Token: 0x17001F59 RID: 8025
		' (get) Token: 0x06005721 RID: 22305 RVA: 0x004DA858 File Offset: 0x004D8A58
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(8)
			End Get
		End Property

		' Token: 0x17001F5A RID: 8026
		' (get) Token: 0x06005722 RID: 22306 RVA: 0x004DA87C File Offset: 0x004D8A7C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsPHUCVU As Section
			Get
				Return Me.ReportDefinition.Sections(9)
			End Get
		End Property

		' Token: 0x17001F5B RID: 8027
		' (get) Token: 0x06005723 RID: 22307 RVA: 0x004DA8A0 File Offset: 0x004D8AA0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection6 As Section
			Get
				Return Me.ReportDefinition.Sections(10)
			End Get
		End Property

		' Token: 0x17001F5C RID: 8028
		' (get) Token: 0x06005724 RID: 22308 RVA: 0x004DA8C4 File Offset: 0x004D8AC4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection7 As Section
			Get
				Return Me.ReportDefinition.Sections(11)
			End Get
		End Property

		' Token: 0x17001F5D RID: 8029
		' (get) Token: 0x06005725 RID: 22309 RVA: 0x004DA8E8 File Offset: 0x004D8AE8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection8 As Section
			Get
				Return Me.ReportDefinition.Sections(12)
			End Get
		End Property

		' Token: 0x17001F5E RID: 8030
		' (get) Token: 0x06005726 RID: 22310 RVA: 0x004DA90C File Offset: 0x004D8B0C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportHeaderSection9 As Section
			Get
				Return Me.ReportDefinition.Sections(13)
			End Get
		End Property

		' Token: 0x17001F5F RID: 8031
		' (get) Token: 0x06005727 RID: 22311 RVA: 0x004DA930 File Offset: 0x004D8B30
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection10 As Section
			Get
				Return Me.ReportDefinition.Sections(14)
			End Get
		End Property

		' Token: 0x17001F60 RID: 8032
		' (get) Token: 0x06005728 RID: 22312 RVA: 0x004DA954 File Offset: 0x004D8B54
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section2 As Section
			Get
				Return Me.ReportDefinition.Sections(15)
			End Get
		End Property

		' Token: 0x17001F61 RID: 8033
		' (get) Token: 0x06005729 RID: 22313 RVA: 0x004DA978 File Offset: 0x004D8B78
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupHeaderSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(16)
			End Get
		End Property

		' Token: 0x17001F62 RID: 8034
		' (get) Token: 0x0600572A RID: 22314 RVA: 0x004DA99C File Offset: 0x004D8B9C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property GroupHeaderSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(17)
			End Get
		End Property

		' Token: 0x17001F63 RID: 8035
		' (get) Token: 0x0600572B RID: 22315 RVA: 0x004DA9C0 File Offset: 0x004D8BC0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Sec As Section
			Get
				Return Me.ReportDefinition.Sections(18)
			End Get
		End Property

		' Token: 0x17001F64 RID: 8036
		' (get) Token: 0x0600572C RID: 22316 RVA: 0x004DA9E4 File Offset: 0x004D8BE4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(19)
			End Get
		End Property

		' Token: 0x17001F65 RID: 8037
		' (get) Token: 0x0600572D RID: 22317 RVA: 0x004DAA08 File Offset: 0x004D8C08
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection7 As Section
			Get
				Return Me.ReportDefinition.Sections(20)
			End Get
		End Property

		' Token: 0x17001F66 RID: 8038
		' (get) Token: 0x0600572E RID: 22318 RVA: 0x004DAA2C File Offset: 0x004D8C2C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection4 As Section
			Get
				Return Me.ReportDefinition.Sections(21)
			End Get
		End Property

		' Token: 0x17001F67 RID: 8039
		' (get) Token: 0x0600572F RID: 22319 RVA: 0x004DAA50 File Offset: 0x004D8C50
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dst1 As Section
			Get
				Return Me.ReportDefinition.Sections(22)
			End Get
		End Property

		' Token: 0x17001F68 RID: 8040
		' (get) Token: 0x06005730 RID: 22320 RVA: 0x004DAA74 File Offset: 0x004D8C74
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection6 As Section
			Get
				Return Me.ReportDefinition.Sections(23)
			End Get
		End Property

		' Token: 0x17001F69 RID: 8041
		' (get) Token: 0x06005731 RID: 22321 RVA: 0x004DAA98 File Offset: 0x004D8C98
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(24)
			End Get
		End Property

		' Token: 0x17001F6A RID: 8042
		' (get) Token: 0x06005732 RID: 22322 RVA: 0x004DAABC File Offset: 0x004D8CBC
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection3 As Section
			Get
				Return Me.ReportDefinition.Sections(25)
			End Get
		End Property

		' Token: 0x17001F6B RID: 8043
		' (get) Token: 0x06005733 RID: 22323 RVA: 0x004DAAE0 File Offset: 0x004D8CE0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection5 As Section
			Get
				Return Me.ReportDefinition.Sections(26)
			End Get
		End Property

		' Token: 0x17001F6C RID: 8044
		' (get) Token: 0x06005734 RID: 22324 RVA: 0x004DAB04 File Offset: 0x004D8D04
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(27)
			End Get
		End Property

		' Token: 0x17001F6D RID: 8045
		' (get) Token: 0x06005735 RID: 22325 RVA: 0x004DAB28 File Offset: 0x004D8D28
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(28)
			End Get
		End Property

		' Token: 0x17001F6E RID: 8046
		' (get) Token: 0x06005736 RID: 22326 RVA: 0x004DAB4C File Offset: 0x004D8D4C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property secSumQty As Section
			Get
				Return Me.ReportDefinition.Sections(29)
			End Get
		End Property

		' Token: 0x17001F6F RID: 8047
		' (get) Token: 0x06005737 RID: 22327 RVA: 0x004DAB70 File Offset: 0x004D8D70
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(30)
			End Get
		End Property

		' Token: 0x17001F70 RID: 8048
		' (get) Token: 0x06005738 RID: 22328 RVA: 0x004DAB94 File Offset: 0x004D8D94
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section5F As Section
			Get
				Return Me.ReportDefinition.Sections(31)
			End Get
		End Property

		' Token: 0x0400270F RID: 9999
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
