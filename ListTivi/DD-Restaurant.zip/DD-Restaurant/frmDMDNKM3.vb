﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200003F RID: 63
	<DesignerGenerated()>
	Public Partial Class frmDMDNKM3
		Inherits Form

		' Token: 0x06000F10 RID: 3856 RVA: 0x000B3B0C File Offset: 0x000B1D0C
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMDNKM3_Activated
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMDNKM3_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMDNKM3_Load
			frmDMDNKM3.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSourceMas = New BindingSource()
			Me.mbdsSourceDel = New BindingSource()
			Me.mdgvMaster = New DataGridView()
			Me.mstrStockName = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000556 RID: 1366
		' (get) Token: 0x06000F13 RID: 3859 RVA: 0x000B5658 File Offset: 0x000B3858
		' (set) Token: 0x06000F14 RID: 3860 RVA: 0x00004614 File Offset: 0x00002814
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000557 RID: 1367
		' (get) Token: 0x06000F15 RID: 3861 RVA: 0x000B5670 File Offset: 0x000B3870
		' (set) Token: 0x06000F16 RID: 3862 RVA: 0x000B5688 File Offset: 0x000B3888
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000558 RID: 1368
		' (get) Token: 0x06000F17 RID: 3863 RVA: 0x000B56F4 File Offset: 0x000B38F4
		' (set) Token: 0x06000F18 RID: 3864 RVA: 0x000B570C File Offset: 0x000B390C
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000559 RID: 1369
		' (get) Token: 0x06000F19 RID: 3865 RVA: 0x000B5778 File Offset: 0x000B3978
		' (set) Token: 0x06000F1A RID: 3866 RVA: 0x000B5790 File Offset: 0x000B3990
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x1700055A RID: 1370
		' (get) Token: 0x06000F1B RID: 3867 RVA: 0x000B57FC File Offset: 0x000B39FC
		' (set) Token: 0x06000F1C RID: 3868 RVA: 0x0000461E File Offset: 0x0000281E
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x1700055B RID: 1371
		' (get) Token: 0x06000F1D RID: 3869 RVA: 0x000B5814 File Offset: 0x000B3A14
		' (set) Token: 0x06000F1E RID: 3870 RVA: 0x000B582C File Offset: 0x000B3A2C
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x1700055C RID: 1372
		' (get) Token: 0x06000F1F RID: 3871 RVA: 0x000B5898 File Offset: 0x000B3A98
		' (set) Token: 0x06000F20 RID: 3872 RVA: 0x000B58B0 File Offset: 0x000B3AB0
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x1700055D RID: 1373
		' (get) Token: 0x06000F21 RID: 3873 RVA: 0x000B591C File Offset: 0x000B3B1C
		' (set) Token: 0x06000F22 RID: 3874 RVA: 0x00004628 File Offset: 0x00002828
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x1700055E RID: 1374
		' (get) Token: 0x06000F23 RID: 3875 RVA: 0x000B5934 File Offset: 0x000B3B34
		' (set) Token: 0x06000F24 RID: 3876 RVA: 0x000B594C File Offset: 0x000B3B4C
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x1700055F RID: 1375
		' (get) Token: 0x06000F25 RID: 3877 RVA: 0x000B59B8 File Offset: 0x000B3BB8
		' (set) Token: 0x06000F26 RID: 3878 RVA: 0x000B59D0 File Offset: 0x000B3BD0
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x17000560 RID: 1376
		' (get) Token: 0x06000F27 RID: 3879 RVA: 0x000B5A3C File Offset: 0x000B3C3C
		' (set) Token: 0x06000F28 RID: 3880 RVA: 0x000B5A54 File Offset: 0x000B3C54
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000561 RID: 1377
		' (get) Token: 0x06000F29 RID: 3881 RVA: 0x000B5AC0 File Offset: 0x000B3CC0
		' (set) Token: 0x06000F2A RID: 3882 RVA: 0x00004632 File Offset: 0x00002832
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x17000562 RID: 1378
		' (get) Token: 0x06000F2B RID: 3883 RVA: 0x000B5AD8 File Offset: 0x000B3CD8
		' (set) Token: 0x06000F2C RID: 3884 RVA: 0x0000463C File Offset: 0x0000283C
		Friend Overridable Property lblFromTime As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFromTime = value
			End Set
		End Property

		' Token: 0x17000563 RID: 1379
		' (get) Token: 0x06000F2D RID: 3885 RVA: 0x000B5AF0 File Offset: 0x000B3CF0
		' (set) Token: 0x06000F2E RID: 3886 RVA: 0x00004646 File Offset: 0x00002846
		Friend Overridable Property lblTungay As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTungay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTungay = value
			End Set
		End Property

		' Token: 0x17000564 RID: 1380
		' (get) Token: 0x06000F2F RID: 3887 RVA: 0x000B5B08 File Offset: 0x000B3D08
		' (set) Token: 0x06000F30 RID: 3888 RVA: 0x00004650 File Offset: 0x00002850
		Friend Overridable Property lblTen As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTen
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTen = value
			End Set
		End Property

		' Token: 0x17000565 RID: 1381
		' (get) Token: 0x06000F31 RID: 3889 RVA: 0x000B5B20 File Offset: 0x000B3D20
		' (set) Token: 0x06000F32 RID: 3890 RVA: 0x0000465A File Offset: 0x0000285A
		Friend Overridable Property txtTen As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTen
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTen = value
			End Set
		End Property

		' Token: 0x17000566 RID: 1382
		' (get) Token: 0x06000F33 RID: 3891 RVA: 0x000B5B38 File Offset: 0x000B3D38
		' (set) Token: 0x06000F34 RID: 3892 RVA: 0x00004664 File Offset: 0x00002864
		Friend Overridable Property lblQty1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblQty1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblQty1 = value
			End Set
		End Property

		' Token: 0x17000567 RID: 1383
		' (get) Token: 0x06000F35 RID: 3893 RVA: 0x000B5B50 File Offset: 0x000B3D50
		' (set) Token: 0x06000F36 RID: 3894 RVA: 0x0000466E File Offset: 0x0000286E
		Friend Overridable Property txtQty1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtQty1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtQty1 = value
			End Set
		End Property

		' Token: 0x17000568 RID: 1384
		' (get) Token: 0x06000F37 RID: 3895 RVA: 0x000B5B68 File Offset: 0x000B3D68
		' (set) Token: 0x06000F38 RID: 3896 RVA: 0x000B5B80 File Offset: 0x000B3D80
		Friend Overridable Property btnPrintMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrintMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrintMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrintMas.Click, AddressOf Me.btnPrintMas_Click
				End If
				Me._btnPrintMas = value
				flag = Me._btnPrintMas IsNot Nothing
				If flag Then
					AddHandler Me._btnPrintMas.Click, AddressOf Me.btnPrintMas_Click
				End If
			End Set
		End Property

		' Token: 0x17000569 RID: 1385
		' (get) Token: 0x06000F39 RID: 3897 RVA: 0x000B5BEC File Offset: 0x000B3DEC
		' (set) Token: 0x06000F3A RID: 3898 RVA: 0x000B5C04 File Offset: 0x000B3E04
		Friend Overridable Property btnDelMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelMas.Click, AddressOf Me.btnDelMas_Click
				End If
				Me._btnDelMas = value
				flag = Me._btnDelMas IsNot Nothing
				If flag Then
					AddHandler Me._btnDelMas.Click, AddressOf Me.btnDelMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700056A RID: 1386
		' (get) Token: 0x06000F3B RID: 3899 RVA: 0x000B5C70 File Offset: 0x000B3E70
		' (set) Token: 0x06000F3C RID: 3900 RVA: 0x000B5C88 File Offset: 0x000B3E88
		Friend Overridable Property btnEditMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnEditMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnEditMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnEditMas.Click, AddressOf Me.btnEditMas_Click
				End If
				Me._btnEditMas = value
				flag = Me._btnEditMas IsNot Nothing
				If flag Then
					AddHandler Me._btnEditMas.Click, AddressOf Me.btnEditMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700056B RID: 1387
		' (get) Token: 0x06000F3D RID: 3901 RVA: 0x000B5CF4 File Offset: 0x000B3EF4
		' (set) Token: 0x06000F3E RID: 3902 RVA: 0x000B5D0C File Offset: 0x000B3F0C
		Friend Overridable Property btnFirstMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirstMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirstMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirstMas.Click, AddressOf Me.btnFirstMas_Click
				End If
				Me._btnFirstMas = value
				flag = Me._btnFirstMas IsNot Nothing
				If flag Then
					AddHandler Me._btnFirstMas.Click, AddressOf Me.btnFirstMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700056C RID: 1388
		' (get) Token: 0x06000F3F RID: 3903 RVA: 0x000B5D78 File Offset: 0x000B3F78
		' (set) Token: 0x06000F40 RID: 3904 RVA: 0x000B5D90 File Offset: 0x000B3F90
		Friend Overridable Property btnPreMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreMas.Click, AddressOf Me.btnPreMas_Click
				End If
				Me._btnPreMas = value
				flag = Me._btnPreMas IsNot Nothing
				If flag Then
					AddHandler Me._btnPreMas.Click, AddressOf Me.btnPreMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700056D RID: 1389
		' (get) Token: 0x06000F41 RID: 3905 RVA: 0x000B5DFC File Offset: 0x000B3FFC
		' (set) Token: 0x06000F42 RID: 3906 RVA: 0x000B5E14 File Offset: 0x000B4014
		Friend Overridable Property btnNextMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNextMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNextMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNextMas.Click, AddressOf Me.btnNextMas_Click
				End If
				Me._btnNextMas = value
				flag = Me._btnNextMas IsNot Nothing
				If flag Then
					AddHandler Me._btnNextMas.Click, AddressOf Me.btnNextMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700056E RID: 1390
		' (get) Token: 0x06000F43 RID: 3907 RVA: 0x000B5E80 File Offset: 0x000B4080
		' (set) Token: 0x06000F44 RID: 3908 RVA: 0x000B5E98 File Offset: 0x000B4098
		Friend Overridable Property btnLastMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLastMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLastMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLastMas.Click, AddressOf Me.btnLastMas_Click
				End If
				Me._btnLastMas = value
				flag = Me._btnLastMas IsNot Nothing
				If flag Then
					AddHandler Me._btnLastMas.Click, AddressOf Me.btnLastMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700056F RID: 1391
		' (get) Token: 0x06000F45 RID: 3909 RVA: 0x000B5F04 File Offset: 0x000B4104
		' (set) Token: 0x06000F46 RID: 3910 RVA: 0x00004678 File Offset: 0x00002878
		Friend Overridable Property lblQty2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblQty2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblQty2 = value
			End Set
		End Property

		' Token: 0x17000570 RID: 1392
		' (get) Token: 0x06000F47 RID: 3911 RVA: 0x000B5F1C File Offset: 0x000B411C
		' (set) Token: 0x06000F48 RID: 3912 RVA: 0x00004682 File Offset: 0x00002882
		Friend Overridable Property txtQty2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtQty2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtQty2 = value
			End Set
		End Property

		' Token: 0x17000571 RID: 1393
		' (get) Token: 0x06000F49 RID: 3913 RVA: 0x000B5F34 File Offset: 0x000B4134
		' (set) Token: 0x06000F4A RID: 3914 RVA: 0x0000468C File Offset: 0x0000288C
		Friend Overridable Property lblDengio As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDengio
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDengio = value
			End Set
		End Property

		' Token: 0x17000572 RID: 1394
		' (get) Token: 0x06000F4B RID: 3915 RVA: 0x000B5F4C File Offset: 0x000B414C
		' (set) Token: 0x06000F4C RID: 3916 RVA: 0x00004696 File Offset: 0x00002896
		Friend Overridable Property lblDenngay As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDenngay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDenngay = value
			End Set
		End Property

		' Token: 0x17000573 RID: 1395
		' (get) Token: 0x06000F4D RID: 3917 RVA: 0x000B5F64 File Offset: 0x000B4164
		' (set) Token: 0x06000F4E RID: 3918 RVA: 0x000046A0 File Offset: 0x000028A0
		Friend Overridable Property mtxFromDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxFromDate = value
			End Set
		End Property

		' Token: 0x17000574 RID: 1396
		' (get) Token: 0x06000F4F RID: 3919 RVA: 0x000B5F7C File Offset: 0x000B417C
		' (set) Token: 0x06000F50 RID: 3920 RVA: 0x000046AA File Offset: 0x000028AA
		Friend Overridable Property mtxToDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxToDate = value
			End Set
		End Property

		' Token: 0x17000575 RID: 1397
		' (get) Token: 0x06000F51 RID: 3921 RVA: 0x000B5F94 File Offset: 0x000B4194
		' (set) Token: 0x06000F52 RID: 3922 RVA: 0x000046B4 File Offset: 0x000028B4
		Friend Overridable Property mtxFromTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxFromTime = value
			End Set
		End Property

		' Token: 0x17000576 RID: 1398
		' (get) Token: 0x06000F53 RID: 3923 RVA: 0x000B5FAC File Offset: 0x000B41AC
		' (set) Token: 0x06000F54 RID: 3924 RVA: 0x000046BE File Offset: 0x000028BE
		Friend Overridable Property mtxToTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxToTime = value
			End Set
		End Property

		' Token: 0x17000577 RID: 1399
		' (get) Token: 0x06000F55 RID: 3925 RVA: 0x000B5FC4 File Offset: 0x000B41C4
		' (set) Token: 0x06000F56 RID: 3926 RVA: 0x000046C8 File Offset: 0x000028C8
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000578 RID: 1400
		' (get) Token: 0x06000F57 RID: 3927 RVA: 0x000B5FDC File Offset: 0x000B41DC
		' (set) Token: 0x06000F58 RID: 3928 RVA: 0x000B5FF4 File Offset: 0x000B41F4
		Private Overridable Property mbdsSourceMas As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceMas IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceMas.PositionChanged, AddressOf Me.mbdsSourceMas_PositionChanged
				End If
				Me._mbdsSourceMas = value
				flag = Me._mbdsSourceMas IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceMas.PositionChanged, AddressOf Me.mbdsSourceMas_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000579 RID: 1401
		' (get) Token: 0x06000F59 RID: 3929 RVA: 0x000B6060 File Offset: 0x000B4260
		' (set) Token: 0x06000F5A RID: 3930 RVA: 0x000B6078 File Offset: 0x000B4278
		Private Overridable Property mbdsSourceDel As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceDel IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceDel.PositionChanged, AddressOf Me.mbdsSourceDel_PositionChanged
				End If
				Me._mbdsSourceDel = value
				flag = Me._mbdsSourceDel IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceDel.PositionChanged, AddressOf Me.mbdsSourceDel_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x1700057A RID: 1402
		' (get) Token: 0x06000F5B RID: 3931 RVA: 0x000B60E4 File Offset: 0x000B42E4
		' (set) Token: 0x06000F5C RID: 3932 RVA: 0x000046D2 File Offset: 0x000028D2
		Public Property pdgvMaster As DataGridView
			Get
				Return Me.mdgvMaster
			End Get
			Set(value As DataGridView)
				Me.mdgvMaster = value
			End Set
		End Property

		' Token: 0x1700057B RID: 1403
		' (get) Token: 0x06000F5D RID: 3933 RVA: 0x000B60FC File Offset: 0x000B42FC
		' (set) Token: 0x06000F5E RID: 3934 RVA: 0x000046DD File Offset: 0x000028DD
		Public Property pbdsSource As BindingSource
			Get
				Return Me.mbdsSourceMas
			End Get
			Set(value As BindingSource)
				Me.mbdsSourceMas = value
			End Set
		End Property

		' Token: 0x1700057C RID: 1404
		' (get) Token: 0x06000F5F RID: 3935 RVA: 0x000B6114 File Offset: 0x000B4314
		' (set) Token: 0x06000F60 RID: 3936 RVA: 0x000046E9 File Offset: 0x000028E9
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x1700057D RID: 1405
		' (get) Token: 0x06000F61 RID: 3937 RVA: 0x000B612C File Offset: 0x000B432C
		' (set) Token: 0x06000F62 RID: 3938 RVA: 0x000046F4 File Offset: 0x000028F4
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06000F63 RID: 3939 RVA: 0x000B6144 File Offset: 0x000B4344
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F64 RID: 3940 RVA: 0x000B6214 File Offset: 0x000B4414
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceDel.Position
				Dim flag As Boolean = position < Me.mbdsSourceDel.Count - 1
				If flag Then
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					mbdsSourceDel.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F65 RID: 3941 RVA: 0x000B6304 File Offset: 0x000B4504
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceDel.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					mbdsSourceDel.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F66 RID: 3942 RVA: 0x000B63E8 File Offset: 0x000B45E8
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSourceDel.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F67 RID: 3943 RVA: 0x000B64AC File Offset: 0x000B46AC
		Private Sub btnLastMas_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSourceMas.Position = Me.mbdsSourceMas.Count - 1
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLastMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F68 RID: 3944 RVA: 0x000B6560 File Offset: 0x000B4760
		Private Sub btnNextMas_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceMas.Position
				Dim flag As Boolean = position < Me.mbdsSourceMas.Count - 1
				If flag Then
					Dim mbdsSourceMas As BindingSource = Me.mbdsSourceMas
					mbdsSourceMas.Position += 1
				End If
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNextMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F69 RID: 3945 RVA: 0x000B663C File Offset: 0x000B483C
		Private Sub btnPreMas_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceMas.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSourceMas As BindingSource = Me.mbdsSourceMas
					mbdsSourceMas.Position -= 1
				End If
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F6A RID: 3946 RVA: 0x000B670C File Offset: 0x000B490C
		Private Sub btnFirstMas_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSourceMas.Position = 0
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirstMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F6B RID: 3947 RVA: 0x000046FF File Offset: 0x000028FF
		Private Sub frmDMDNKM3_Activated(sender As Object, e As EventArgs)
			Me.fGetData_4Grid()
			Me.fShow_DatainText()
		End Sub

		' Token: 0x06000F6C RID: 3948 RVA: 0x000B67B4 File Offset: 0x000B49B4
		Private Sub frmDMDNKM3_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM3_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F6D RID: 3949 RVA: 0x000B684C File Offset: 0x000B4A4C
		Private Sub frmDMDNKM3_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mbdsSourceMas_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					b = Me.fShow_DatainText()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM3_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F6E RID: 3950 RVA: 0x000B6968 File Offset: 0x000B4B68
		Private Sub mbdsSourceDel_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSourceDel.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					Me.lblPosition.Text = (mbdsSourceDel.Position + 1).ToString() + " / " + mbdsSourceDel.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceDel_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F6F RID: 3951 RVA: 0x000B6A70 File Offset: 0x000B4C70
		Private Sub mbdsSourceMas_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSourceMas.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButtonMas(True)
				Else
					Dim b As Byte = Me.fDisableButtonMas(False)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceMas_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F70 RID: 3952 RVA: 0x000B6B2C File Offset: 0x000B4D2C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F71 RID: 3953 RVA: 0x000B6BC4 File Offset: 0x000B4DC4
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = Me.fAdd_frmDOCUMENT4()
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0
				If flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Find("KHOACHINH", text)
						Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F72 RID: 3954 RVA: 0x000B6CF8 File Offset: 0x000B4EF8
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Try
				Me.btnDelete_Click(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000F73 RID: 3955 RVA: 0x000B6D8C File Offset: 0x000B4F8C
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fDelete_frmDOCUMENT4()
				Dim flag As Boolean = b = 0
				If Not flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F74 RID: 3956 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnPrintMas_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06000F75 RID: 3957 RVA: 0x000B6E70 File Offset: 0x000B5070
		Private Sub btnDelMas_Click(sender As Object, e As EventArgs)
			Dim frmDMDNKM As frmDMDNKM2 = New frmDMDNKM2()
			Try
				Dim frmDMDNKM2 As frmDMDNKM2 = frmDMDNKM
				frmDMDNKM2.pbytFromStatus = 4
				frmDMDNKM2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMDNKM2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMDNKM2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("MAKH").Value, ""))
				frmDMDNKM2.pStrMANHOMDV = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("MANHOMDV").Value, ""))
				frmDMDNKM2.pStrHTKM = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("MAKM").Value, ""))
				frmDMDNKM2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMDNKM2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMDNKM2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMDNKM2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMDNKM2.txtQty1.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("SOLUONG1").Value, ""))
				frmDMDNKM2.txtQty2.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("SOLUONG2").Value, ""))
				frmDMDNKM2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
				frmDMDNKM2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
				frmDMDNKM.ShowDialog()
				Dim flag As Boolean = frmDMDNKM.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = mdlVariable.gfrmDMDNKM1.gfGetData_4Grid()
					flag = b <> 0
					If flag Then
						Me.fShow_DatainText()
					End If
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDNKM.Dispose()
			End Try
		End Sub

		' Token: 0x06000F76 RID: 3958 RVA: 0x000B743C File Offset: 0x000B563C
		Private Sub btnEditMas_Click(sender As Object, e As EventArgs)
			Dim frmDMDNKM As frmDMDNKM2 = New frmDMDNKM2()
			Try
				Dim frmDMDNKM2 As frmDMDNKM2 = frmDMDNKM
				frmDMDNKM2.pbytFromStatus = 3
				frmDMDNKM2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMDNKM2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMDNKM2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("MAKH").Value, ""))
				frmDMDNKM2.pStrMANHOMDV = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("MANHOMDV").Value, ""))
				frmDMDNKM2.pStrHTKM = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("MAKM").Value, ""))
				frmDMDNKM2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMDNKM2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMDNKM2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMDNKM2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMDNKM2.txtQty1.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("SOLUONG1").Value, ""))
				frmDMDNKM2.txtQty2.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("SOLUONG2").Value, ""))
				frmDMDNKM2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
				frmDMDNKM2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
				frmDMDNKM.ShowDialog()
				Dim flag As Boolean = frmDMDNKM.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = mdlVariable.gfrmDMDNKM1.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					Dim obj As Object = Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAKM").Value, "")
					flag = Conversions.ToBoolean(If((Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "02", False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "03", False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "11", False))), True, False))
					If flag Then
						Me.fDeleteDatail()
						flag = b <> 0
						If flag Then
							b = Me.fGetData_4Grid()
							flag = b = 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
							End If
						End If
					End If
					flag = b <> 0
					If flag Then
						Me.fShow_DatainText()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDNKM.Dispose()
			End Try
		End Sub

		' Token: 0x06000F77 RID: 3959 RVA: 0x000B7AD8 File Offset: 0x000B5CD8
		Private Function fModify_frmDOCUMENT4() As Byte
			Dim b As Byte
			Return b
		End Function

		' Token: 0x06000F78 RID: 3960 RVA: 0x000B7AE8 File Offset: 0x000B5CE8
		Private Function fDelete_frmDOCUMENT4() As Byte
			Dim frmDMDNKM As frmDMDNKM4 = New frmDMDNKM4()
			Dim frmDMDNKM2 As frmDMDNKM5 = New frmDMDNKM5()
			Dim b As Byte
			Try
				b = 0
				Dim text As String = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAKM").Value, ""))
				Dim text2 As String = text
				Dim flag As Boolean
				If Operators.CompareString(text2, "00", False) <> 0 AndAlso Operators.CompareString(text2, "04", False) <> 0 Then
					If Operators.CompareString(text2, "05", False) <> 0 Then
						If Operators.CompareString(text2, "08", False) <> 0 Then
							If Operators.CompareString(text2, "09", False) <> 0 Then
								If Operators.CompareString(text2, "12", False) <> 0 Then
									flag = False
									GoTo IL_00B0
								End If
							End If
						End If
					End If
				End If
				flag = True
				IL_00B0:
				Dim flag2 As Boolean = flag
				If flag2 Then
					frmDMDNKM.pbytFromStatus = 4
					frmDMDNKM.pStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
					frmDMDNKM.ShowDialog()
					flag2 = frmDMDNKM.pbytSuccess = 0
					If flag2 Then
						Return b
					End If
				Else
					flag2 = Operators.CompareString(text2, "01", False) = 0
					If flag2 Then
						frmDMDNKM2.pbytFromStatus = 4
						frmDMDNKM2.pStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
						frmDMDNKM2.ShowDialog()
						flag2 = frmDMDNKM.pbytSuccess = 0
						If flag2 Then
							Return b
						End If
					End If
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDelete_frmDOCUMENT4 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDNKM.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000F79 RID: 3961 RVA: 0x000B7D24 File Offset: 0x000B5F24
		Private Function fAdd_frmDOCUMENT4() As String
			Dim frmDMDNKM As frmDMDNKM4 = New frmDMDNKM4()
			Dim frmDMDNKM2 As frmDMDNKM5 = New frmDMDNKM5()
			Dim text As String = ""
			Try
				Dim text2 As String = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAKM").Value, ""))
				Dim text3 As String = text2
				Dim flag As Boolean
				If Operators.CompareString(text3, "00", False) <> 0 AndAlso Operators.CompareString(text3, "04", False) <> 0 Then
					If Operators.CompareString(text3, "05", False) <> 0 Then
						If Operators.CompareString(text3, "09", False) <> 0 Then
							If Operators.CompareString(text3, "12", False) <> 0 Then
								flag = False
								GoTo IL_00A2
							End If
						End If
					End If
				End If
				flag = True
				IL_00A2:
				Dim flag2 As Boolean = flag
				If flag2 Then
					frmDMDNKM.pbytFromStatus = 1
					frmDMDNKM.pStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
					frmDMDNKM.ShowDialog()
					flag2 = frmDMDNKM.pbytSuccess = 0
					If Not flag2 Then
						text = frmDMDNKM.pStrFilter
					End If
				Else
					flag2 = Operators.CompareString(text3, "01", False) = 0
					If flag2 Then
						frmDMDNKM2.pbytFromStatus = 1
						frmDMDNKM2.pStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
						frmDMDNKM2.ShowDialog()
						flag2 = frmDMDNKM2.pbytSuccess = 0
						If Not flag2 Then
							text = frmDMDNKM.pStrFilter
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAdd_frmDOCUMENT4 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDNKM.Dispose()
			End Try
			Return text
		End Function

		' Token: 0x06000F7A RID: 3962 RVA: 0x000B7F60 File Offset: 0x000B6160
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.Columns("MAHHSALE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("MAHHSALE").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("MAHHSALE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENHANGBAN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("TENHANGBAN").Width = 250
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENHANGBAN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MAHHSUR").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("MAHHSUR").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("MAHHSUR").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENHANGTANG").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("TENHANGTANG").Width = Me.Width - 490 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("TENHANGTANG").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MADNKM").Visible = False
				dgvData.Columns("KHOACHINH").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000F7B RID: 3963 RVA: 0x000B821C File Offset: 0x000B641C
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000F7C RID: 3964 RVA: 0x000B8324 File Offset: 0x000B6524
		Private Function fDisableButtonMas(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirstMas.Enabled = Not pblnDisable
				Me.btnLastMas.Enabled = Not pblnDisable
				Me.btnPreMas.Enabled = Not pblnDisable
				Me.btnNextMas.Enabled = Not pblnDisable
				Me.btnPrintMas.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButtonMas ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000F7D RID: 3965 RVA: 0x000B840C File Offset: 0x000B660C
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim b As Byte
			Try
				b = 0
				Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
				Dim text As String = "SP_FRMDMDNKM2_GET_DATA"
				Dim num As Integer
				Dim flag As Boolean = num <> 0
				Dim clsConnect2 As clsConnect = New clsConnect(gStrConISDANHMUC, text, flag)
				num = If((-If((flag > False), 1, 0)), 1, 0)
				clsConnect = clsConnect2
				Me.mbdsSourceDel.DataSource = clsConnect
				Me.dgvData.DataSource = Me.mbdsSourceDel
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000F7E RID: 3966 RVA: 0x000B84F4 File Offset: 0x000B66F4
		Private Function fShow_DatainText() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.txtTen.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJNAME").Value, ""))
				Me.mtxFromDate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("TUNGAY").Value, ""))
				Me.mtxToDate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("DENNGAY").Value, ""))
				Me.mtxFromTime.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("TUGIO").Value, ""))
				Me.mtxToTime.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("DENGIO").Value, ""))
				Me.txtQty1.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("SOLUONG1").Value, ""))
				Me.txtQty2.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("SOLUONG2").Value, ""))
				Dim obj As Object = Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAKM").Value, "")
				Dim flag As Boolean = Conversions.ToBoolean(If((Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "00", False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "01", False))), True, False))
				If flag Then
					Me.lblQty2.Visible = True
					Me.txtQty2.Visible = True
					Me.lblQty1.Tag = "CR0034"
					Me.lblQty2.Tag = "CR0035"
					Me.fInitCaption()
				Else
					flag = Operators.ConditionalCompareObjectEqual(obj, "02", False)
					If flag Then
						Me.lblQty2.Visible = True
						Me.txtQty2.Visible = True
						Me.lblQty1.Tag = "CR0038"
						Me.lblQty2.Tag = "CR0037"
						Me.fInitCaption()
					Else
						flag = Conversions.ToBoolean(If((Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "03", False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "11", False))), True, False))
						If flag Then
							Me.lblQty2.Visible = True
							Me.txtQty2.Visible = True
							Me.lblQty1.Tag = "CR0037"
							Me.lblQty2.Tag = "CR0036"
							Me.fInitCaption()
						Else
							flag = Conversions.ToBoolean(If((Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "04", False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "09", False))), True, False))
							If flag Then
								Me.lblQty1.Tag = "CR0036"
								Me.lblQty2.Visible = False
								Me.txtQty2.Visible = False
								Me.fInitCaption()
							Else
								flag = Operators.ConditionalCompareObjectEqual(obj, "05", False)
								If flag Then
									Me.lblQty1.Tag = "CR0037"
									Me.lblQty2.Visible = False
									Me.txtQty2.Visible = False
									Me.fInitCaption()
								End If
							End If
						End If
					End If
				End If
				Me.mbdsSourceDel.Filter = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("KHOACHINH ='", Me.mdgvMaster.CurrentRow.Cells("OBJID").Value), ""), "'"))
				mdlUIForm.gsSetCap_2Form(Me, String.Concat(New String() { Me.mArrStrFrmMess(2), " ", Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))), Me.mArrStrFrmMess(16), " [", Me.mstrStockName, "]" }))
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fShow_DatainText ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000F7F RID: 3967 RVA: 0x000B8A60 File Offset: 0x000B6C60
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.txtTen.[ReadOnly] = True
				Me.mtxFromDate.[ReadOnly] = True
				Me.mtxToDate.[ReadOnly] = True
				Me.mtxFromTime.[ReadOnly] = True
				Me.mtxToTime.[ReadOnly] = True
				Me.txtQty1.[ReadOnly] = True
				Me.txtQty2.[ReadOnly] = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000F80 RID: 3968 RVA: 0x000B8B70 File Offset: 0x000B6D70
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mstrStockName = Strings.Trim(mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMKH", "OBJID", Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAKH").Value, "")), "OBJNAME"))
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, String.Concat(New String() { Me.mArrStrFrmMess(2), " ", Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))), Me.mArrStrFrmMess(16), " [", Me.mstrStockName, "]" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000F81 RID: 3969 RVA: 0x000B8D60 File Offset: 0x000B6F60
		Private Function fDeleteDatail() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADNKM"
				array(0).Value = Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, "")
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_DEL_DETAIL", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000F82 RID: 3970 RVA: 0x000B8EEC File Offset: 0x000B70EC
		Private Sub sClear_Form()
			Try
				Me.mbdsSourceDel.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x04000660 RID: 1632
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000662 RID: 1634
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000663 RID: 1635
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000664 RID: 1636
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000665 RID: 1637
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000666 RID: 1638
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000667 RID: 1639
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000668 RID: 1640
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000669 RID: 1641
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x0400066A RID: 1642
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x0400066B RID: 1643
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x0400066C RID: 1644
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x0400066D RID: 1645
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x0400066E RID: 1646
		<AccessedThroughProperty("lblFromTime")>
		Private _lblFromTime As Label

		' Token: 0x0400066F RID: 1647
		<AccessedThroughProperty("lblTungay")>
		Private _lblTungay As Label

		' Token: 0x04000670 RID: 1648
		<AccessedThroughProperty("lblTen")>
		Private _lblTen As Label

		' Token: 0x04000671 RID: 1649
		<AccessedThroughProperty("txtTen")>
		Private _txtTen As TextBox

		' Token: 0x04000672 RID: 1650
		<AccessedThroughProperty("lblQty1")>
		Private _lblQty1 As Label

		' Token: 0x04000673 RID: 1651
		<AccessedThroughProperty("txtQty1")>
		Private _txtQty1 As TextBox

		' Token: 0x04000674 RID: 1652
		<AccessedThroughProperty("btnPrintMas")>
		Private _btnPrintMas As Button

		' Token: 0x04000675 RID: 1653
		<AccessedThroughProperty("btnDelMas")>
		Private _btnDelMas As Button

		' Token: 0x04000676 RID: 1654
		<AccessedThroughProperty("btnEditMas")>
		Private _btnEditMas As Button

		' Token: 0x04000677 RID: 1655
		<AccessedThroughProperty("btnFirstMas")>
		Private _btnFirstMas As Button

		' Token: 0x04000678 RID: 1656
		<AccessedThroughProperty("btnPreMas")>
		Private _btnPreMas As Button

		' Token: 0x04000679 RID: 1657
		<AccessedThroughProperty("btnNextMas")>
		Private _btnNextMas As Button

		' Token: 0x0400067A RID: 1658
		<AccessedThroughProperty("btnLastMas")>
		Private _btnLastMas As Button

		' Token: 0x0400067B RID: 1659
		<AccessedThroughProperty("lblQty2")>
		Private _lblQty2 As Label

		' Token: 0x0400067C RID: 1660
		<AccessedThroughProperty("txtQty2")>
		Private _txtQty2 As TextBox

		' Token: 0x0400067D RID: 1661
		<AccessedThroughProperty("lblDengio")>
		Private _lblDengio As Label

		' Token: 0x0400067E RID: 1662
		<AccessedThroughProperty("lblDenngay")>
		Private _lblDenngay As Label

		' Token: 0x0400067F RID: 1663
		<AccessedThroughProperty("mtxFromDate")>
		Private _mtxFromDate As MaskedTextBox

		' Token: 0x04000680 RID: 1664
		<AccessedThroughProperty("mtxToDate")>
		Private _mtxToDate As MaskedTextBox

		' Token: 0x04000681 RID: 1665
		<AccessedThroughProperty("mtxFromTime")>
		Private _mtxFromTime As MaskedTextBox

		' Token: 0x04000682 RID: 1666
		<AccessedThroughProperty("mtxToTime")>
		Private _mtxToTime As MaskedTextBox

		' Token: 0x04000683 RID: 1667
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000684 RID: 1668
		Private mArrStrFrmMess As String()

		' Token: 0x04000685 RID: 1669
		Private mStrOBJID As String

		' Token: 0x04000686 RID: 1670
		Private mStrMAKM As String

		' Token: 0x04000687 RID: 1671
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000688 RID: 1672
		<AccessedThroughProperty("mbdsSourceMas")>
		Private _mbdsSourceMas As BindingSource

		' Token: 0x04000689 RID: 1673
		<AccessedThroughProperty("mbdsSourceDel")>
		Private _mbdsSourceDel As BindingSource

		' Token: 0x0400068A RID: 1674
		Private mdgvMaster As DataGridView

		' Token: 0x0400068B RID: 1675
		Private marrDrFind As DataRow()

		' Token: 0x0400068C RID: 1676
		Private mintFindLastPos As Integer

		' Token: 0x0400068D RID: 1677
		Private mstrStockName As String
	End Class
End Namespace
