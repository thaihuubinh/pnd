﻿Namespace prjIS_SalesPOS
	' Token: 0x02000024 RID: 36
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmChangeTableStatus
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600068E RID: 1678 RVA: 0x0004DE28 File Offset: 0x0004C028
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600068F RID: 1679 RVA: 0x0004DE60 File Offset: 0x0004C060
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmChangeTableStatus))
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim dataGridViewCellStyle2 As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim dataGridViewCellStyle3 As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim dataGridViewCellStyle4 As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.TableLayoutPanel5 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnColor = New Global.System.Windows.Forms.Button()
			Me.btnSelect = New Global.System.Windows.Forms.Button()
			Me.lblColor = New Global.System.Windows.Forms.Label()
			Me.dtgStatus = New Global.System.Windows.Forms.DataGridView()
			Me.Column1 = New Global.System.Windows.Forms.DataGridViewTextBoxColumn()
			Me.Column2 = New Global.System.Windows.Forms.DataGridViewTextBoxColumn()
			Me.TableLayoutPanel5.SuspendLayout()
			CType(Me.dtgStatus, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.btnExit.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(321, 3)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(103, 38)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 3
			Me.btnExit.Tag = "C00002"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.UseVisualStyleBackColor = False
			Me.TableLayoutPanel5.ColumnCount = 4
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.Controls.Add(Me.btnColor, 0, 0)
			Me.TableLayoutPanel5.Controls.Add(Me.btnExit, 3, 0)
			Me.TableLayoutPanel5.Controls.Add(Me.btnSelect, 2, 0)
			Me.TableLayoutPanel5.Controls.Add(Me.lblColor, 1, 0)
			Me.TableLayoutPanel5.Dock = Global.System.Windows.Forms.DockStyle.Bottom
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel5
			point = New Global.System.Drawing.Point(0, 364)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
			Me.TableLayoutPanel5.RowCount = 1
			Me.TableLayoutPanel5.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel5
			size = New Global.System.Drawing.Size(427, 44)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel5.TabIndex = 5
			Me.btnColor.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnColor.BackgroundImage = CType(componentResourceManager.GetObject("btnColor.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnColor.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnColor.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnColor.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnColor.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnColor.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnColor As Global.System.Windows.Forms.Control = Me.btnColor
			point = New Global.System.Drawing.Point(3, 3)
			btnColor.Location = point
			Me.btnColor.Name = "btnColor"
			Dim btnColor2 As Global.System.Windows.Forms.Control = Me.btnColor
			size = New Global.System.Drawing.Size(100, 38)
			btnColor2.Size = size
			Me.btnColor.TabIndex = 4
			Me.btnColor.Tag = "C00010"
			Me.btnColor.Text = "Chọn màu"
			Me.btnColor.UseVisualStyleBackColor = False
			Me.btnSelect.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnSelect.BackgroundImage = CType(componentResourceManager.GetObject("btnSelect.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnSelect.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnSelect.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnSelect.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnSelect.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnSelect.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Me.btnSelect.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnSelect As Global.System.Windows.Forms.Control = Me.btnSelect
			point = New Global.System.Drawing.Point(215, 3)
			btnSelect.Location = point
			Me.btnSelect.Name = "btnSelect"
			Dim btnSelect2 As Global.System.Windows.Forms.Control = Me.btnSelect
			size = New Global.System.Drawing.Size(100, 38)
			btnSelect2.Size = size
			Me.btnSelect.TabIndex = 3
			Me.btnSelect.Tag = "C00001"
			Me.btnSelect.Text = "Chọn"
			Me.btnSelect.UseVisualStyleBackColor = False
			Me.lblColor.AutoSize = True
			Dim lblColor As Global.System.Windows.Forms.Control = Me.lblColor
			point = New Global.System.Drawing.Point(109, 0)
			lblColor.Location = point
			Me.lblColor.Name = "lblColor"
			Dim lblColor2 As Global.System.Windows.Forms.Control = Me.lblColor
			size = New Global.System.Drawing.Size(39, 13)
			lblColor2.Size = size
			Me.lblColor.TabIndex = 5
			Me.lblColor.Text = "Label1"
			Me.lblColor.Visible = False
			Me.dtgStatus.AllowUserToAddRows = False
			Me.dtgStatus.AllowUserToDeleteRows = False
			Me.dtgStatus.AllowUserToResizeRows = False
			dataGridViewCellStyle.BackColor = Global.System.Drawing.Color.White
			Me.dtgStatus.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle
			Me.dtgStatus.AutoSizeColumnsMode = Global.System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
			Me.dtgStatus.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle2.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
			dataGridViewCellStyle2.BackColor = Global.System.Drawing.Color.White
			dataGridViewCellStyle2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle2.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle2.SelectionBackColor = Global.System.Drawing.Color.Transparent
			dataGridViewCellStyle2.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle2.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dtgStatus.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2
			Me.dtgStatus.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dtgStatus.ColumnHeadersVisible = False
			Me.dtgStatus.Columns.AddRange(New Global.System.Windows.Forms.DataGridViewColumn() { Me.Column1, Me.Column2 })
			dataGridViewCellStyle3.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
			dataGridViewCellStyle3.BackColor = Global.System.Drawing.SystemColors.Window
			dataGridViewCellStyle3.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 8.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle3.ForeColor = Global.System.Drawing.SystemColors.ControlText
			dataGridViewCellStyle3.SelectionBackColor = Global.System.Drawing.Color.White
			dataGridViewCellStyle3.SelectionForeColor = Global.System.Drawing.Color.Red
			dataGridViewCellStyle3.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[False]
			Me.dtgStatus.DefaultCellStyle = dataGridViewCellStyle3
			Me.dtgStatus.Dock = Global.System.Windows.Forms.DockStyle.Top
			Me.dtgStatus.GridColor = Global.System.Drawing.Color.Black
			Dim dtgStatus As Global.System.Windows.Forms.Control = Me.dtgStatus
			point = New Global.System.Drawing.Point(0, 0)
			dtgStatus.Location = point
			Me.dtgStatus.MultiSelect = False
			Me.dtgStatus.Name = "dtgStatus"
			Me.dtgStatus.[ReadOnly] = True
			Me.dtgStatus.RowHeadersVisible = False
			dataGridViewCellStyle4.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle4.Font = New Global.System.Drawing.Font("Courier New", 20.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.dtgStatus.RowsDefaultCellStyle = dataGridViewCellStyle4
			Me.dtgStatus.RowTemplate.Height = 50
			Me.dtgStatus.ScrollBars = Global.System.Windows.Forms.ScrollBars.Vertical
			Me.dtgStatus.SelectionMode = Global.System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
			Dim dtgStatus2 As Global.System.Windows.Forms.Control = Me.dtgStatus
			size = New Global.System.Drawing.Size(427, 364)
			dtgStatus2.Size = size
			Me.dtgStatus.TabIndex = 4
			Me.Column1.FillWeight = 101.5228F
			Me.Column1.HeaderText = "Mã"
			Me.Column1.Name = "Column1"
			Me.Column1.[ReadOnly] = True
			Me.Column2.FillWeight = 98.47716F
			Me.Column2.HeaderText = "Tên hiển thị"
			Me.Column2.Name = "Column2"
			Me.Column2.[ReadOnly] = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(427, 408)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.TableLayoutPanel5)
			Me.Controls.Add(Me.dtgStatus)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Me.Name = "frmChangeTableStatus"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Change Table Status"
			Me.TableLayoutPanel5.ResumeLayout(False)
			Me.TableLayoutPanel5.PerformLayout()
			CType(Me.dtgStatus, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x040002D9 RID: 729
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
