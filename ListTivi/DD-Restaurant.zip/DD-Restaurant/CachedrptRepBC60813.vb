﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002D0 RID: 720
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60813
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006A61 RID: 27233 RVA: 0x000135AF File Offset: 0x000117AF
		Public Sub New()
			CachedrptRepBC60813.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002A00 RID: 10752
		' (get) Token: 0x06006A62 RID: 27234 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006A63 RID: 27235 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002A01 RID: 10753
		' (get) Token: 0x06006A64 RID: 27236 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006A65 RID: 27237 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002A02 RID: 10754
		' (get) Token: 0x06006A66 RID: 27238 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006A67 RID: 27239 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006A68 RID: 27240 RVA: 0x004DE560 File Offset: 0x004DC760
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60813() With { .Site = Me.Site }
		End Function

		' Token: 0x06006A69 RID: 27241 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028C8 RID: 10440
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
