﻿Namespace prjIS_SalesPOS
	' Token: 0x02000022 RID: 34
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmChangePass
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600063F RID: 1599 RVA: 0x0004AF10 File Offset: 0x00049110
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000640 RID: 1600 RVA: 0x0004AF48 File Offset: 0x00049148
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmChangePass))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.btnOK = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.lblOLDPASS = New Global.System.Windows.Forms.Label()
			Me.txtOLDPASS = New Global.System.Windows.Forms.TextBox()
			Me.lblNEWPASS1 = New Global.System.Windows.Forms.Label()
			Me.txtNEWPASS1 = New Global.System.Windows.Forms.TextBox()
			Me.lblNEWPASS2 = New Global.System.Windows.Forms.Label()
			Me.txtNEWPASS2 = New Global.System.Windows.Forms.TextBox()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.grpButton.SuspendLayout()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.btnKeyboard)
			Me.grpButton.Controls.Add(Me.btnOK)
			Me.grpButton.Controls.Add(Me.btnExit)
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(5, 117)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(647, 60)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 3
			Me.grpButton.TabStop = False
			Dim btnOK As Global.System.Windows.Forms.Control = Me.btnOK
			point = New Global.System.Drawing.Point(6, 14)
			btnOK.Location = point
			Me.btnOK.Name = "btnOK"
			Dim btnOK2 As Global.System.Windows.Forms.Control = Me.btnOK
			size = New Global.System.Drawing.Size(87, 42)
			btnOK2.Size = size
			Me.btnOK.TabIndex = 0
			Me.btnOK.Tag = "CR0005"
			Me.btnOK.Text = "Dong y"
			Me.btnOK.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnOK.UseVisualStyleBackColor = True
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(550, 14)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(80, 42)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 2
			Me.btnExit.Tag = "CR0006"
			Me.btnExit.Text = "&Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.lblOLDPASS.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOLDPASS As Global.System.Windows.Forms.Control = Me.lblOLDPASS
			point = New Global.System.Drawing.Point(12, 13)
			lblOLDPASS.Location = point
			Me.lblOLDPASS.Name = "lblOLDPASS"
			Dim lblOLDPASS2 As Global.System.Windows.Forms.Control = Me.lblOLDPASS
			size = New Global.System.Drawing.Size(154, 21)
			lblOLDPASS2.Size = size
			Me.lblOLDPASS.TabIndex = 12
			Me.lblOLDPASS.Tag = "CB0008"
			Me.lblOLDPASS.Text = "Mật mã cũ"
			Me.txtOLDPASS.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOLDPASS As Global.System.Windows.Forms.Control = Me.txtOLDPASS
			point = New Global.System.Drawing.Point(174, 12)
			txtOLDPASS.Location = point
			Me.txtOLDPASS.Name = "txtOLDPASS"
			Me.txtOLDPASS.PasswordChar = "*"c
			Dim txtOLDPASS2 As Global.System.Windows.Forms.Control = Me.txtOLDPASS
			size = New Global.System.Drawing.Size(469, 22)
			txtOLDPASS2.Size = size
			Me.txtOLDPASS.TabIndex = 0
			Me.txtOLDPASS.Tag = "0R0000"
			Me.lblNEWPASS1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblNEWPASS As Global.System.Windows.Forms.Control = Me.lblNEWPASS1
			point = New Global.System.Drawing.Point(12, 41)
			lblNEWPASS.Location = point
			Me.lblNEWPASS1.Name = "lblNEWPASS1"
			Dim lblNEWPASS2 As Global.System.Windows.Forms.Control = Me.lblNEWPASS1
			size = New Global.System.Drawing.Size(154, 21)
			lblNEWPASS2.Size = size
			Me.lblNEWPASS1.TabIndex = 14
			Me.lblNEWPASS1.Tag = "CB0010"
			Me.lblNEWPASS1.Text = "Mật mã mới"
			Me.txtNEWPASS1.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtNEWPASS As Global.System.Windows.Forms.Control = Me.txtNEWPASS1
			point = New Global.System.Drawing.Point(174, 40)
			txtNEWPASS.Location = point
			Me.txtNEWPASS1.Name = "txtNEWPASS1"
			Me.txtNEWPASS1.PasswordChar = "*"c
			Dim txtNEWPASS2 As Global.System.Windows.Forms.Control = Me.txtNEWPASS1
			size = New Global.System.Drawing.Size(469, 22)
			txtNEWPASS2.Size = size
			Me.txtNEWPASS1.TabIndex = 1
			Me.txtNEWPASS1.Tag = "0R0000"
			Me.lblNEWPASS2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblNEWPASS3 As Global.System.Windows.Forms.Control = Me.lblNEWPASS2
			point = New Global.System.Drawing.Point(12, 69)
			lblNEWPASS3.Location = point
			Me.lblNEWPASS2.Name = "lblNEWPASS2"
			Dim lblNEWPASS4 As Global.System.Windows.Forms.Control = Me.lblNEWPASS2
			size = New Global.System.Drawing.Size(154, 21)
			lblNEWPASS4.Size = size
			Me.lblNEWPASS2.TabIndex = 16
			Me.lblNEWPASS2.Tag = "CB0011"
			Me.lblNEWPASS2.Text = "Nhập lai Mật mã mới"
			Me.txtNEWPASS2.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtNEWPASS3 As Global.System.Windows.Forms.Control = Me.txtNEWPASS2
			point = New Global.System.Drawing.Point(174, 68)
			txtNEWPASS3.Location = point
			Me.txtNEWPASS2.Name = "txtNEWPASS2"
			Me.txtNEWPASS2.PasswordChar = "*"c
			Dim txtNEWPASS4 As Global.System.Windows.Forms.Control = Me.txtNEWPASS2
			size = New Global.System.Drawing.Size(469, 22)
			txtNEWPASS4.Size = size
			Me.txtNEWPASS2.TabIndex = 2
			Me.txtNEWPASS2.Tag = "0R0000"
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnKeyboard.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(266, 13)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(107, 43)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 125
			Me.btnKeyboard.Text = "Keyboard"
			Me.btnKeyboard.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(655, 180)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.lblNEWPASS2)
			Me.Controls.Add(Me.txtNEWPASS2)
			Me.Controls.Add(Me.lblNEWPASS1)
			Me.Controls.Add(Me.txtNEWPASS1)
			Me.Controls.Add(Me.lblOLDPASS)
			Me.Controls.Add(Me.txtOLDPASS)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmChangePass"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Doi mat mat"
			Me.grpButton.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x040002BA RID: 698
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
