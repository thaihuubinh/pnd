﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200005F RID: 95
	<DesignerGenerated()>
	Public Partial Class frmDMMAY1
		Inherits Form

		' Token: 0x06001C6F RID: 7279 RVA: 0x0015F920 File Offset: 0x0015DB20
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMMAY1_Activated
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMMAY1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMHHLIM1_Load
			frmDMMAY1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd = False
			Me.mBlnOK = False
			Me.mBlnMultiSel = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x170009B3 RID: 2483
		' (get) Token: 0x06001C72 RID: 7282 RVA: 0x0016115C File Offset: 0x0015F35C
		' (set) Token: 0x06001C73 RID: 7283 RVA: 0x0000602E File Offset: 0x0000422E
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x170009B4 RID: 2484
		' (get) Token: 0x06001C74 RID: 7284 RVA: 0x00161174 File Offset: 0x0015F374
		' (set) Token: 0x06001C75 RID: 7285 RVA: 0x0016118C File Offset: 0x0015F38C
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x170009B5 RID: 2485
		' (get) Token: 0x06001C76 RID: 7286 RVA: 0x001611F8 File Offset: 0x0015F3F8
		' (set) Token: 0x06001C77 RID: 7287 RVA: 0x00161210 File Offset: 0x0015F410
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170009B6 RID: 2486
		' (get) Token: 0x06001C78 RID: 7288 RVA: 0x0016127C File Offset: 0x0015F47C
		' (set) Token: 0x06001C79 RID: 7289 RVA: 0x00161294 File Offset: 0x0015F494
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x170009B7 RID: 2487
		' (get) Token: 0x06001C7A RID: 7290 RVA: 0x00161300 File Offset: 0x0015F500
		' (set) Token: 0x06001C7B RID: 7291 RVA: 0x00161318 File Offset: 0x0015F518
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x170009B8 RID: 2488
		' (get) Token: 0x06001C7C RID: 7292 RVA: 0x00161384 File Offset: 0x0015F584
		' (set) Token: 0x06001C7D RID: 7293 RVA: 0x0016139C File Offset: 0x0015F59C
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170009B9 RID: 2489
		' (get) Token: 0x06001C7E RID: 7294 RVA: 0x00161408 File Offset: 0x0015F608
		' (set) Token: 0x06001C7F RID: 7295 RVA: 0x00161420 File Offset: 0x0015F620
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x170009BA RID: 2490
		' (get) Token: 0x06001C80 RID: 7296 RVA: 0x0016148C File Offset: 0x0015F68C
		' (set) Token: 0x06001C81 RID: 7297 RVA: 0x001614A4 File Offset: 0x0015F6A4
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170009BB RID: 2491
		' (get) Token: 0x06001C82 RID: 7298 RVA: 0x00161510 File Offset: 0x0015F710
		' (set) Token: 0x06001C83 RID: 7299 RVA: 0x00006038 File Offset: 0x00004238
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x170009BC RID: 2492
		' (get) Token: 0x06001C84 RID: 7300 RVA: 0x00161528 File Offset: 0x0015F728
		' (set) Token: 0x06001C85 RID: 7301 RVA: 0x00161540 File Offset: 0x0015F740
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x170009BD RID: 2493
		' (get) Token: 0x06001C86 RID: 7302 RVA: 0x001615AC File Offset: 0x0015F7AC
		' (set) Token: 0x06001C87 RID: 7303 RVA: 0x001615C4 File Offset: 0x0015F7C4
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x170009BE RID: 2494
		' (get) Token: 0x06001C88 RID: 7304 RVA: 0x00161630 File Offset: 0x0015F830
		' (set) Token: 0x06001C89 RID: 7305 RVA: 0x00161648 File Offset: 0x0015F848
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170009BF RID: 2495
		' (get) Token: 0x06001C8A RID: 7306 RVA: 0x001616B4 File Offset: 0x0015F8B4
		' (set) Token: 0x06001C8B RID: 7307 RVA: 0x00006042 File Offset: 0x00004242
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170009C0 RID: 2496
		' (get) Token: 0x06001C8C RID: 7308 RVA: 0x001616CC File Offset: 0x0015F8CC
		' (set) Token: 0x06001C8D RID: 7309 RVA: 0x001616E4 File Offset: 0x0015F8E4
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x170009C1 RID: 2497
		' (get) Token: 0x06001C8E RID: 7310 RVA: 0x00161750 File Offset: 0x0015F950
		' (set) Token: 0x06001C8F RID: 7311 RVA: 0x00161768 File Offset: 0x0015F968
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x170009C2 RID: 2498
		' (get) Token: 0x06001C90 RID: 7312 RVA: 0x001617D4 File Offset: 0x0015F9D4
		' (set) Token: 0x06001C91 RID: 7313 RVA: 0x001617EC File Offset: 0x0015F9EC
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170009C3 RID: 2499
		' (get) Token: 0x06001C92 RID: 7314 RVA: 0x00161858 File Offset: 0x0015FA58
		' (set) Token: 0x06001C93 RID: 7315 RVA: 0x00161870 File Offset: 0x0015FA70
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x170009C4 RID: 2500
		' (get) Token: 0x06001C94 RID: 7316 RVA: 0x001618DC File Offset: 0x0015FADC
		' (set) Token: 0x06001C95 RID: 7317 RVA: 0x001618F4 File Offset: 0x0015FAF4
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x170009C5 RID: 2501
		' (get) Token: 0x06001C96 RID: 7318 RVA: 0x00161960 File Offset: 0x0015FB60
		' (set) Token: 0x06001C97 RID: 7319 RVA: 0x0000604C File Offset: 0x0000424C
		Friend Overridable Property lblMANH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMANH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMANH = value
			End Set
		End Property

		' Token: 0x170009C6 RID: 2502
		' (get) Token: 0x06001C98 RID: 7320 RVA: 0x00161978 File Offset: 0x0015FB78
		' (set) Token: 0x06001C99 RID: 7321 RVA: 0x00006056 File Offset: 0x00004256
		Friend Overridable Property txtOBJNAMEKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAMEKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAMEKH = value
			End Set
		End Property

		' Token: 0x170009C7 RID: 2503
		' (get) Token: 0x06001C9A RID: 7322 RVA: 0x00161990 File Offset: 0x0015FB90
		' (set) Token: 0x06001C9B RID: 7323 RVA: 0x001619A8 File Offset: 0x0015FBA8
		Friend Overridable Property btnSelectKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelectKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelectKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelectKH.Click, AddressOf Me.btnSelectKH_Click
				End If
				Me._btnSelectKH = value
				flag = Me._btnSelectKH IsNot Nothing
				If flag Then
					AddHandler Me._btnSelectKH.Click, AddressOf Me.btnSelectKH_Click
				End If
			End Set
		End Property

		' Token: 0x170009C8 RID: 2504
		' (get) Token: 0x06001C9C RID: 7324 RVA: 0x00161A14 File Offset: 0x0015FC14
		' (set) Token: 0x06001C9D RID: 7325 RVA: 0x00161A2C File Offset: 0x0015FC2C
		Friend Overridable Property txtOBJIDKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJIDKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJIDKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJIDKH.TextChanged, AddressOf Me.txtOBJIDKH_TextChanged
				End If
				Me._txtOBJIDKH = value
				flag = Me._txtOBJIDKH IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJIDKH.TextChanged, AddressOf Me.txtOBJIDKH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170009C9 RID: 2505
		' (get) Token: 0x06001C9E RID: 7326 RVA: 0x00161A98 File Offset: 0x0015FC98
		' (set) Token: 0x06001C9F RID: 7327 RVA: 0x00161AB0 File Offset: 0x0015FCB0
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170009CA RID: 2506
		' (get) Token: 0x06001CA0 RID: 7328 RVA: 0x00161B1C File Offset: 0x0015FD1C
		' (set) Token: 0x06001CA1 RID: 7329 RVA: 0x00006060 File Offset: 0x00004260
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170009CB RID: 2507
		' (get) Token: 0x06001CA2 RID: 7330 RVA: 0x00161B34 File Offset: 0x0015FD34
		' (set) Token: 0x06001CA3 RID: 7331 RVA: 0x00161B4C File Offset: 0x0015FD4C
		Friend Overridable Property btnCheckConnect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCheckConnect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCheckConnect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCheckConnect.Click, AddressOf Me.btnCheckConnect_Click
				End If
				Me._btnCheckConnect = value
				flag = Me._btnCheckConnect IsNot Nothing
				If flag Then
					AddHandler Me._btnCheckConnect.Click, AddressOf Me.btnCheckConnect_Click
				End If
			End Set
		End Property

		' Token: 0x170009CC RID: 2508
		' (get) Token: 0x06001CA4 RID: 7332 RVA: 0x00161BB8 File Offset: 0x0015FDB8
		' (set) Token: 0x06001CA5 RID: 7333 RVA: 0x00161BD0 File Offset: 0x0015FDD0
		Friend Overridable Property CheckBox1 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._CheckBox1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._CheckBox1 IsNot Nothing
				If flag Then
					RemoveHandler Me._CheckBox1.CheckedChanged, AddressOf Me.CheckBox1_CheckedChanged
				End If
				Me._CheckBox1 = value
				flag = Me._CheckBox1 IsNot Nothing
				If flag Then
					AddHandler Me._CheckBox1.CheckedChanged, AddressOf Me.CheckBox1_CheckedChanged
				End If
			End Set
		End Property

		' Token: 0x170009CD RID: 2509
		' (get) Token: 0x06001CA6 RID: 7334 RVA: 0x00161C3C File Offset: 0x0015FE3C
		' (set) Token: 0x06001CA7 RID: 7335 RVA: 0x00161C54 File Offset: 0x0015FE54
		Friend Overridable Property btnDelLog As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelLog
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelLog IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelLog.Click, AddressOf Me.btnDelLog_Click
				End If
				Me._btnDelLog = value
				flag = Me._btnDelLog IsNot Nothing
				If flag Then
					AddHandler Me._btnDelLog.Click, AddressOf Me.btnDelLog_Click
				End If
			End Set
		End Property

		' Token: 0x170009CE RID: 2510
		' (get) Token: 0x06001CA8 RID: 7336 RVA: 0x00161CC0 File Offset: 0x0015FEC0
		' (set) Token: 0x06001CA9 RID: 7337 RVA: 0x00161CD8 File Offset: 0x0015FED8
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170009CF RID: 2511
		' (get) Token: 0x06001CAA RID: 7338 RVA: 0x00161D44 File Offset: 0x0015FF44
		' (set) Token: 0x06001CAB RID: 7339 RVA: 0x0000606A File Offset: 0x0000426A
		Public Property pBlnMultiSel As Boolean
			Get
				Return Me.mBlnMultiSel
			End Get
			Set(value As Boolean)
				Me.mBlnMultiSel = value
			End Set
		End Property

		' Token: 0x170009D0 RID: 2512
		' (get) Token: 0x06001CAC RID: 7340 RVA: 0x00161D5C File Offset: 0x0015FF5C
		' (set) Token: 0x06001CAD RID: 7341 RVA: 0x00006075 File Offset: 0x00004275
		Public Property pBlnOK As Boolean
			Get
				Return Me.mBlnOK
			End Get
			Set(value As Boolean)
				Me.mBlnOK = value
			End Set
		End Property

		' Token: 0x170009D1 RID: 2513
		' (get) Token: 0x06001CAE RID: 7342 RVA: 0x00161D74 File Offset: 0x0015FF74
		' (set) Token: 0x06001CAF RID: 7343 RVA: 0x00006080 File Offset: 0x00004280
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x170009D2 RID: 2514
		' (get) Token: 0x06001CB0 RID: 7344 RVA: 0x00161D8C File Offset: 0x0015FF8C
		' (set) Token: 0x06001CB1 RID: 7345 RVA: 0x0000608B File Offset: 0x0000428B
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x170009D3 RID: 2515
		' (get) Token: 0x06001CB2 RID: 7346 RVA: 0x00161DA4 File Offset: 0x0015FFA4
		' (set) Token: 0x06001CB3 RID: 7347 RVA: 0x00006096 File Offset: 0x00004296
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06001CB4 RID: 7348 RVA: 0x00161DBC File Offset: 0x0015FFBC
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CB5 RID: 7349 RVA: 0x00161E8C File Offset: 0x0016008C
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CB6 RID: 7350 RVA: 0x00161F7C File Offset: 0x0016017C
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CB7 RID: 7351 RVA: 0x00162060 File Offset: 0x00160260
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CB8 RID: 7352 RVA: 0x00162124 File Offset: 0x00160324
		Private Sub btnSelectKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKH As frmDMKH1 = New frmDMKH1()
				frmDMKH.pBytOpen_From_Menu = 7
				frmDMKH.ShowDialog()
				Me.txtOBJIDKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJID, "", False) = 0, Me.txtOBJIDKH.Text, frmDMKH.pStrOBJID))
				Me.txtOBJNAMEKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJNAME, "", False) = 0, Me.txtOBJNAMEKH.Text, frmDMKH.pStrOBJNAME))
				frmDMKH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelectKH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CB9 RID: 7353 RVA: 0x00162248 File Offset: 0x00160448
		Private Sub txtOBJIDKH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKH Is Nothing
				If Not flag Then
					Me.btnCancelFilter.Visible = False
					array(0) = Me.mclsTbDMKH.Columns("OBJID")
					Me.mclsTbDMKH.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKH.Rows.Find(Strings.Trim(Me.txtOBJIDKH.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.btnFind.Enabled = False
						Me.txtOBJNAMEKH.Text = dataRow("objname").ToString()
						Me.mbdsSource.Filter = "MAKH like '" + Strings.Replace(Strings.Trim(Me.txtOBJIDKH.Text), "'", "''", 1, -1, CompareMethod.Binary) + "'"
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						Me.txtOBJNAMEKH.Text = ""
						Me.mbdsSource.RemoveFilter()
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJIDKH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CBA RID: 7354 RVA: 0x0016241C File Offset: 0x0016061C
		Private Sub frmDMMAY1_Activated(sender As Object, e As EventArgs)
			Try
				Me.txtOBJIDKH_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAY1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CBB RID: 7355 RVA: 0x001624BC File Offset: 0x001606BC
		Private Sub frmDMMAY1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAY1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CBC RID: 7356 RVA: 0x00162554 File Offset: 0x00160754
		Private Sub frmDMHHLIM1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Filter()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHHLIM1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CBD RID: 7357 RVA: 0x001626A0 File Offset: 0x001608A0
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CBE RID: 7358 RVA: 0x001627A8 File Offset: 0x001609A8
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.mBlnOK = False
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CBF RID: 7359 RVA: 0x00162848 File Offset: 0x00160A48
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMMAY As frmDMMAY2 = New frmDMMAY2()
			Try
				frmDMMAY.pbytFromStatus = 1
				Dim flag As Boolean = (Me.mbdsSource.Count > 0) And (Operators.CompareString(Strings.Trim(Me.txtOBJIDKH.Text), "", False) <> 0)
				If flag Then
					frmDMMAY.txtMAMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("objid").Value, ""))
				End If
				frmDMMAY.ShowDialog()
				flag = frmDMMAY.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMMAY.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAY.Dispose()
			End Try
		End Sub

		' Token: 0x06001CC0 RID: 7360 RVA: 0x00162A1C File Offset: 0x00160C1C
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMMAY As frmDMMAY2 = New frmDMMAY2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMMAY2 As frmDMMAY2 = frmDMMAY
				frmDMMAY2.pbytFromStatus = 2
				frmDMMAY2.txtMAMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMMAY2.txtTENMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMMAY2.txtMAKHO.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMMAY2.txtIP.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("IP").Value, ""))
				frmDMMAY2.txtServer.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SERVER").Value, ""))
				frmDMMAY2.txtGHICHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMMAY.ShowDialog()
				Dim flag As Boolean = frmDMMAY.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("objid", frmDMMAY.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAddDefault_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMMAY.Dispose()
			End Try
		End Sub

		' Token: 0x06001CC1 RID: 7361 RVA: 0x00162D1C File Offset: 0x00160F1C
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMMAY As frmDMMAY2 = New frmDMMAY2()
			Try
				Dim frmDMMAY2 As frmDMMAY2 = frmDMMAY
				frmDMMAY2.pbytFromStatus = 3
				frmDMMAY2.txtMAMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMMAY2.txtTENMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMMAY2.txtMAKHO.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMMAY2.txtIP.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("IP").Value, ""))
				frmDMMAY2.txtServer.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SERVER").Value, ""))
				frmDMMAY2.txtGHICHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMMAY2.txtMAMAY.[ReadOnly] = True
				frmDMMAY.ShowDialog()
				Dim flag As Boolean = frmDMMAY.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("objid", frmDMMAY.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAY.Dispose()
			End Try
		End Sub

		' Token: 0x06001CC2 RID: 7362 RVA: 0x00162FE4 File Offset: 0x001611E4
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMMAY As frmDMMAY2 = New frmDMMAY2()
			Try
				Dim frmDMMAY2 As frmDMMAY2 = frmDMMAY
				frmDMMAY2.pbytFromStatus = 4
				frmDMMAY2.txtMAMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("objid").Value, ""))
				frmDMMAY2.txtTENMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("objname").Value, ""))
				frmDMMAY2.txtMAKHO.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("makh").Value, ""))
				frmDMMAY2.txtIP.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("IP").Value, ""))
				frmDMMAY2.txtServer.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SERVER").Value, ""))
				frmDMMAY2.txtGHICHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("remark").Value, ""))
				frmDMMAY2.txtMAMAY.[ReadOnly] = True
				frmDMMAY.ShowDialog()
				Dim flag As Boolean = frmDMMAY.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAY.Dispose()
			End Try
		End Sub

		' Token: 0x06001CC3 RID: 7363 RVA: 0x0016328C File Offset: 0x0016148C
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMMAY As frmDMMAY2 = New frmDMMAY2()
			Try
				frmDMMAY.pbytFromStatus = 6
				frmDMMAY.ShowDialog()
				Dim flag As Boolean = frmDMMAY.pbytSuccess = 0
				If flag Then
					frmDMMAY.Dispose()
				Else
					Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Trim(Me.txtOBJIDKH.Text), "", False) <> 0, " AND MAKH ='" + Strings.Replace(Strings.Trim(Me.txtOBJIDKH.Text), "'", "''", 1, -1, CompareMethod.Binary) + "'", ""))
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMMAY.pStrFilter + text, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMMAY.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("objid", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("objid")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAY.Dispose()
			End Try
		End Sub

		' Token: 0x06001CC4 RID: 7364 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06001CC5 RID: 7365 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06001CC6 RID: 7366 RVA: 0x001634EC File Offset: 0x001616EC
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("objid", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("objid")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x06001CC7 RID: 7367 RVA: 0x00163668 File Offset: 0x00161868
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fPrintDMMAY(Strings.Trim(Me.txtOBJIDKH.Text))
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CC8 RID: 7368 RVA: 0x00163710 File Offset: 0x00161910
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = ""
				Dim flag As Boolean = Me.mBlnMultiSel
				If flag Then
					Try
						For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
							Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
							Dim flag2 As Boolean = Conversions.ToBoolean(dataGridViewRow.Cells("chkSelect").Value)
							If flag2 Then
								Me.mStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Me.mStrOBJID, dataGridViewRow.Cells("OBJID").Value), ";"))
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						Dim flag2 As Boolean = TypeOf enumerator Is IDisposable
						If flag2 Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
				Else
					Me.mStrOBJID = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
					Me.mStrOBJNAME = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJNAME").Value)
				End If
				Me.mBlnOK = True
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CC9 RID: 7369 RVA: 0x001638F8 File Offset: 0x00161AF8
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CCA RID: 7370 RVA: 0x001639A8 File Offset: 0x00161BA8
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("chkSelect").Width = 70
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 70
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJID").[ReadOnly] = True
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").[ReadOnly] = True
				dgvData.Columns("IP").HeaderText = Strings.Trim(Me.mArrStrFrmMess(29))
				dgvData.Columns("IP").Width = 140
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("IP").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("IP").[ReadOnly] = True
				dgvData.Columns("SERVER").HeaderText = Strings.Trim(Me.mArrStrFrmMess(30))
				dgvData.Columns("SERVER").Width = 140
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("SERVER").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SERVER").[ReadOnly] = True
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("REMARK").Width = Me.dgvData.Width - 850 - 5
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").[ReadOnly] = True
				dgvData.Columns("USERID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(33))
				dgvData.Columns("USERID").Width = 140
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("USERID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("USERID").[ReadOnly] = True
				dgvData.Columns("IP_LOG").HeaderText = Strings.Trim(Me.mArrStrFrmMess(34))
				dgvData.Columns("IP_LOG").Width = 140
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("IP_LOG").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("IP_LOG").[ReadOnly] = True
				dgvData.Columns("MAKH").Visible = False
				dgvData.Columns("TIME_LOG").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001CCB RID: 7371 RVA: 0x00163E7C File Offset: 0x0016207C
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001CCC RID: 7372 RVA: 0x00163FFC File Offset: 0x001621FC
		Private Function fGetData_4Filter() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKH = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = Me.mclsTbDMKH IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Filter ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001CCD RID: 7373 RVA: 0x001640B8 File Offset: 0x001622B8
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAY_GET_ALL_DATA_DMMAY", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.dgvData.Columns.Clear()
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					Dim dataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn = New DataGridViewCheckBoxColumn()
					dataGridViewCheckBoxColumn.[ReadOnly] = False
					dataGridViewCheckBoxColumn.Name = "chkSelect"
					dataGridViewCheckBoxColumn.HeaderText = Me.mArrStrFrmMess(32)
					Me.dgvData.Columns.Insert(0, dataGridViewCheckBoxColumn)
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001CCE RID: 7374 RVA: 0x00164214 File Offset: 0x00162414
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Me.txtOBJIDKH.Text = mdlVariable.gStrStockCode
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				Else
					Me.btnSelect.Visible = True
				End If
				flag = Operators.CompareString(mdlVariable.gStrStockCode, "", False) <> 0
				If flag Then
					Me.txtOBJIDKH.[ReadOnly] = True
					Me.txtOBJIDKH.BackColor = Me.txtOBJNAMEKH.BackColor
					Me.btnSelectKH.Enabled = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001CCF RID: 7375 RVA: 0x00164380 File Offset: 0x00162580
		Private Function fDelete_Login() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nchMAUSER"
				array(0).Value = ""
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nchMAMAY"
				array(1).Value = Me.dgvData.CurrentRow.Cells("OBJID").Value.ToString()
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@nchIP"
				array(2).Value = ""
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_MTB_UPDATE_DMMAY_LOGON", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001CD0 RID: 7376 RVA: 0x00164534 File Offset: 0x00162734
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001CD1 RID: 7377 RVA: 0x00164640 File Offset: 0x00162840
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mclsTbDMKH.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001CD2 RID: 7378 RVA: 0x001646F8 File Offset: 0x001628F8
		Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.CheckBox1.Checked
			If flag Then
				Try
					For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
						Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
						dataGridViewRow.Cells("chkSelect").Value = True
					Next
				Finally
					Dim enumerator As IEnumerator
					flag = TypeOf enumerator Is IDisposable
					If flag Then
						TryCast(enumerator, IDisposable).Dispose()
					End If
				End Try
			Else
				Try
					For Each obj2 As Object In CType(Me.dgvData.Rows, IEnumerable)
						Dim dataGridViewRow2 As DataGridViewRow = CType(obj2, DataGridViewRow)
						dataGridViewRow2.Cells("chkSelect").Value = False
					Next
				Finally
					Dim enumerator2 As IEnumerator
					flag = TypeOf enumerator2 Is IDisposable
					If flag Then
						TryCast(enumerator2, IDisposable).Dispose()
					End If
				End Try
			End If
		End Sub

		' Token: 0x06001CD3 RID: 7379 RVA: 0x00164810 File Offset: 0x00162A10
		Private Sub btnCheckConnect_Click(sender As Object, e As EventArgs)
			Dim frmCheckConnect As frmCheckConnect = New frmCheckConnect()
			frmCheckConnect.dgvCHECK.Rows.Clear()
			Try
				For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
					Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
					Dim flag As Boolean = Conversions.ToBoolean(dataGridViewRow.Cells("chkSelect").Value)
					If flag Then
						frmCheckConnect.dgvCHECK.Rows.Add(New Object() { RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("OBJID").Value), RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("OBJNAME").Value), RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("IP").Value), RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("SERVER").Value) })
					End If
				Next
			Finally
				Dim enumerator As IEnumerator
				Dim flag As Boolean = TypeOf enumerator Is IDisposable
				If flag Then
					TryCast(enumerator, IDisposable).Dispose()
				End If
			End Try
			frmCheckConnect.ShowDialog()
		End Sub

		' Token: 0x06001CD4 RID: 7380 RVA: 0x00164958 File Offset: 0x00162B58
		Private Sub btnDelLog_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.dgvData.SelectedRows.Count = 0
				If Not flag Then
					flag = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(36), Me.btnDelLog.Text, frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.Yes
					If flag Then
						Dim flag2 As Boolean = Me.fDelete_Login() = 1
						If flag2 Then
							Dim b As Byte = Me.fGetData_4Grid()
							flag2 = b = 0
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
							End If
							flag2 = b <> 0
							If flag2 Then
								b = Me.fInitGrid()
							End If
							flag2 = b <> 0
							If flag2 Then
								Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelLog_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001CD5 RID: 7381 RVA: 0x00164A8C File Offset: 0x00162C8C
		Private Function fPrintDMMAY(pstrMAKH As String) As Byte
			Dim rptDMmay As rptDMmay = New rptDMmay()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMmay, "")
				Dim text As String = "2080100000"
				mdlReport.gsSetOfficeReport(rptDMmay, text)
				mdlReport.gsSetFontReport(rptDMmay)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAKH"
				array(0).Value = pstrMAKH
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAY_GET_DATA_DMMAY", num)
				Dim num2 As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag As Boolean = num = 1
				If flag Then
					rptDMmay.SetDataSource(clsConnect)
					rptDMmay.DataDefinition.FormulaFields("fPluCode").Text = "{dtReport.OBJID}"
					rptDMmay.DataDefinition.FormulaFields("fPluName").Text = "{dtReport.OBJNAME}"
					rptDMmay.DataDefinition.FormulaFields("fGroupCode").Text = "{dtReport.MAKH}"
					rptDMmay.DataDefinition.FormulaFields("fMaxQty").Text = "{dtReport.REMARK}"
					rptDMmay.DataDefinition.FormulaFields("fStockName").Text = "{dtReport.TENKH}"
					mdlReport.gsSetTextReport(rptDMmay, "RPTDMmay")
					MyProject.Forms.frmReport.pSource = rptDMmay
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMmay.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMmay.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMmay.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMMAY " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMmay.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x04000BA3 RID: 2979
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000BA5 RID: 2981
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000BA6 RID: 2982
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000BA7 RID: 2983
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000BA8 RID: 2984
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000BA9 RID: 2985
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000BAA RID: 2986
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000BAB RID: 2987
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000BAC RID: 2988
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000BAD RID: 2989
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000BAE RID: 2990
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000BAF RID: 2991
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000BB0 RID: 2992
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000BB1 RID: 2993
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000BB2 RID: 2994
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000BB3 RID: 2995
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000BB4 RID: 2996
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000BB5 RID: 2997
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000BB6 RID: 2998
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000BB7 RID: 2999
		<AccessedThroughProperty("lblMANH")>
		Private _lblMANH As Label

		' Token: 0x04000BB8 RID: 3000
		<AccessedThroughProperty("txtOBJNAMEKH")>
		Private _txtOBJNAMEKH As TextBox

		' Token: 0x04000BB9 RID: 3001
		<AccessedThroughProperty("btnSelectKH")>
		Private _btnSelectKH As Button

		' Token: 0x04000BBA RID: 3002
		<AccessedThroughProperty("txtOBJIDKH")>
		Private _txtOBJIDKH As TextBox

		' Token: 0x04000BBB RID: 3003
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000BBC RID: 3004
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000BBD RID: 3005
		<AccessedThroughProperty("btnCheckConnect")>
		Private _btnCheckConnect As Button

		' Token: 0x04000BBE RID: 3006
		<AccessedThroughProperty("CheckBox1")>
		Private _CheckBox1 As CheckBox

		' Token: 0x04000BBF RID: 3007
		<AccessedThroughProperty("btnDelLog")>
		Private _btnDelLog As Button

		' Token: 0x04000BC0 RID: 3008
		Private mArrStrFrmMess As String()

		' Token: 0x04000BC1 RID: 3009
		Private mStrOBJID As String

		' Token: 0x04000BC2 RID: 3010
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000BC3 RID: 3011
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000BC4 RID: 3012
		Private marrDrFind As DataRow()

		' Token: 0x04000BC5 RID: 3013
		Private mintFindLastPos As Integer

		' Token: 0x04000BC6 RID: 3014
		Private mblnAutoAdd As Boolean

		' Token: 0x04000BC7 RID: 3015
		Private mbytLen_OBJID As Byte

		' Token: 0x04000BC8 RID: 3016
		Private mclsTbDMKH As clsConnect

		' Token: 0x04000BC9 RID: 3017
		Private mStrOBJNAME As String

		' Token: 0x04000BCA RID: 3018
		Private mBlnOK As Boolean

		' Token: 0x04000BCB RID: 3019
		Private mBlnMultiSel As Boolean
	End Class
End Namespace
