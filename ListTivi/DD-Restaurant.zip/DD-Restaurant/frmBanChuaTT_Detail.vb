﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200001B RID: 27
	<DesignerGenerated()>
	Public Partial Class frmBanChuaTT_Detail
		Inherits Form

		' Token: 0x06000401 RID: 1025 RVA: 0x00030750 File Offset: 0x0002E950
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmSAL023_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmSAL023_Load
			frmBanChuaTT_Detail.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSourceMas = New BindingSource()
			Me.mbdsSourceDel = New BindingSource()
			Me.mdgvMaster = New DataGridView()
			Me.mstrStockName = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700018E RID: 398
		' (get) Token: 0x06000404 RID: 1028 RVA: 0x00031A60 File Offset: 0x0002FC60
		' (set) Token: 0x06000405 RID: 1029 RVA: 0x00002B36 File Offset: 0x00000D36
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x1700018F RID: 399
		' (get) Token: 0x06000406 RID: 1030 RVA: 0x00031A78 File Offset: 0x0002FC78
		' (set) Token: 0x06000407 RID: 1031 RVA: 0x00031A90 File Offset: 0x0002FC90
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000190 RID: 400
		' (get) Token: 0x06000408 RID: 1032 RVA: 0x00031AFC File Offset: 0x0002FCFC
		' (set) Token: 0x06000409 RID: 1033 RVA: 0x00031B14 File Offset: 0x0002FD14
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000191 RID: 401
		' (get) Token: 0x0600040A RID: 1034 RVA: 0x00031B80 File Offset: 0x0002FD80
		' (set) Token: 0x0600040B RID: 1035 RVA: 0x00002B40 File Offset: 0x00000D40
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000192 RID: 402
		' (get) Token: 0x0600040C RID: 1036 RVA: 0x00031B98 File Offset: 0x0002FD98
		' (set) Token: 0x0600040D RID: 1037 RVA: 0x00031BB0 File Offset: 0x0002FDB0
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000193 RID: 403
		' (get) Token: 0x0600040E RID: 1038 RVA: 0x00031C1C File Offset: 0x0002FE1C
		' (set) Token: 0x0600040F RID: 1039 RVA: 0x00031C34 File Offset: 0x0002FE34
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x17000194 RID: 404
		' (get) Token: 0x06000410 RID: 1040 RVA: 0x00031CA0 File Offset: 0x0002FEA0
		' (set) Token: 0x06000411 RID: 1041 RVA: 0x00002B4A File Offset: 0x00000D4A
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x17000195 RID: 405
		' (get) Token: 0x06000412 RID: 1042 RVA: 0x00031CB8 File Offset: 0x0002FEB8
		' (set) Token: 0x06000413 RID: 1043 RVA: 0x00031CD0 File Offset: 0x0002FED0
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000196 RID: 406
		' (get) Token: 0x06000414 RID: 1044 RVA: 0x00031D3C File Offset: 0x0002FF3C
		' (set) Token: 0x06000415 RID: 1045 RVA: 0x00002B54 File Offset: 0x00000D54
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x17000197 RID: 407
		' (get) Token: 0x06000416 RID: 1046 RVA: 0x00031D54 File Offset: 0x0002FF54
		' (set) Token: 0x06000417 RID: 1047 RVA: 0x00002B5E File Offset: 0x00000D5E
		Friend Overridable Property lblMADV As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMADV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMADV = value
			End Set
		End Property

		' Token: 0x17000198 RID: 408
		' (get) Token: 0x06000418 RID: 1048 RVA: 0x00031D6C File Offset: 0x0002FF6C
		' (set) Token: 0x06000419 RID: 1049 RVA: 0x00002B68 File Offset: 0x00000D68
		Friend Overridable Property txtMADV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMADV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtMADV = value
			End Set
		End Property

		' Token: 0x17000199 RID: 409
		' (get) Token: 0x0600041A RID: 1050 RVA: 0x00031D84 File Offset: 0x0002FF84
		' (set) Token: 0x0600041B RID: 1051 RVA: 0x00002B72 File Offset: 0x00000D72
		Friend Overridable Property lblREMARK As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblREMARK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblREMARK = value
			End Set
		End Property

		' Token: 0x1700019A RID: 410
		' (get) Token: 0x0600041C RID: 1052 RVA: 0x00031D9C File Offset: 0x0002FF9C
		' (set) Token: 0x0600041D RID: 1053 RVA: 0x00002B7C File Offset: 0x00000D7C
		Friend Overridable Property txtREMARK As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtREMARK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtREMARK = value
			End Set
		End Property

		' Token: 0x1700019B RID: 411
		' (get) Token: 0x0600041E RID: 1054 RVA: 0x00031DB4 File Offset: 0x0002FFB4
		' (set) Token: 0x0600041F RID: 1055 RVA: 0x00031DCC File Offset: 0x0002FFCC
		Friend Overridable Property btnPrintMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrintMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrintMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrintMas.Click, AddressOf Me.btnPrintMas_Click
				End If
				Me._btnPrintMas = value
				flag = Me._btnPrintMas IsNot Nothing
				If flag Then
					AddHandler Me._btnPrintMas.Click, AddressOf Me.btnPrintMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700019C RID: 412
		' (get) Token: 0x06000420 RID: 1056 RVA: 0x00031E38 File Offset: 0x00030038
		' (set) Token: 0x06000421 RID: 1057 RVA: 0x00031E50 File Offset: 0x00030050
		Friend Overridable Property btnDelMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelMas.Click, AddressOf Me.btnDelMas_Click
				End If
				Me._btnDelMas = value
				flag = Me._btnDelMas IsNot Nothing
				If flag Then
					AddHandler Me._btnDelMas.Click, AddressOf Me.btnDelMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700019D RID: 413
		' (get) Token: 0x06000422 RID: 1058 RVA: 0x00031EBC File Offset: 0x000300BC
		' (set) Token: 0x06000423 RID: 1059 RVA: 0x00031ED4 File Offset: 0x000300D4
		Friend Overridable Property btnEditMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnEditMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnEditMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnEditMas.Click, AddressOf Me.btnEditMas_Click
				End If
				Me._btnEditMas = value
				flag = Me._btnEditMas IsNot Nothing
				If flag Then
					AddHandler Me._btnEditMas.Click, AddressOf Me.btnEditMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700019E RID: 414
		' (get) Token: 0x06000424 RID: 1060 RVA: 0x00031F40 File Offset: 0x00030140
		' (set) Token: 0x06000425 RID: 1061 RVA: 0x00031F58 File Offset: 0x00030158
		Friend Overridable Property btnFirstMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirstMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirstMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirstMas.Click, AddressOf Me.btnFirstMas_Click
				End If
				Me._btnFirstMas = value
				flag = Me._btnFirstMas IsNot Nothing
				If flag Then
					AddHandler Me._btnFirstMas.Click, AddressOf Me.btnFirstMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700019F RID: 415
		' (get) Token: 0x06000426 RID: 1062 RVA: 0x00031FC4 File Offset: 0x000301C4
		' (set) Token: 0x06000427 RID: 1063 RVA: 0x00031FDC File Offset: 0x000301DC
		Friend Overridable Property btnPreMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreMas.Click, AddressOf Me.btnPreMas_Click
				End If
				Me._btnPreMas = value
				flag = Me._btnPreMas IsNot Nothing
				If flag Then
					AddHandler Me._btnPreMas.Click, AddressOf Me.btnPreMas_Click
				End If
			End Set
		End Property

		' Token: 0x170001A0 RID: 416
		' (get) Token: 0x06000428 RID: 1064 RVA: 0x00032048 File Offset: 0x00030248
		' (set) Token: 0x06000429 RID: 1065 RVA: 0x00032060 File Offset: 0x00030260
		Friend Overridable Property btnNextMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNextMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNextMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNextMas.Click, AddressOf Me.btnNextMas_Click
				End If
				Me._btnNextMas = value
				flag = Me._btnNextMas IsNot Nothing
				If flag Then
					AddHandler Me._btnNextMas.Click, AddressOf Me.btnNextMas_Click
				End If
			End Set
		End Property

		' Token: 0x170001A1 RID: 417
		' (get) Token: 0x0600042A RID: 1066 RVA: 0x000320CC File Offset: 0x000302CC
		' (set) Token: 0x0600042B RID: 1067 RVA: 0x000320E4 File Offset: 0x000302E4
		Friend Overridable Property btnLastMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLastMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLastMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLastMas.Click, AddressOf Me.btnLastMas_Click
				End If
				Me._btnLastMas = value
				flag = Me._btnLastMas IsNot Nothing
				If flag Then
					AddHandler Me._btnLastMas.Click, AddressOf Me.btnLastMas_Click
				End If
			End Set
		End Property

		' Token: 0x170001A2 RID: 418
		' (get) Token: 0x0600042C RID: 1068 RVA: 0x00032150 File Offset: 0x00030350
		' (set) Token: 0x0600042D RID: 1069 RVA: 0x00002B86 File Offset: 0x00000D86
		Friend Overridable Property txtMAKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtMAKH = value
			End Set
		End Property

		' Token: 0x170001A3 RID: 419
		' (get) Token: 0x0600042E RID: 1070 RVA: 0x00032168 File Offset: 0x00030368
		' (set) Token: 0x0600042F RID: 1071 RVA: 0x00002B90 File Offset: 0x00000D90
		Friend Overridable Property lblMAKH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAKH = value
			End Set
		End Property

		' Token: 0x170001A4 RID: 420
		' (get) Token: 0x06000430 RID: 1072 RVA: 0x00032180 File Offset: 0x00030380
		' (set) Token: 0x06000431 RID: 1073 RVA: 0x00002B9A File Offset: 0x00000D9A
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170001A5 RID: 421
		' (get) Token: 0x06000432 RID: 1074 RVA: 0x00032198 File Offset: 0x00030398
		' (set) Token: 0x06000433 RID: 1075 RVA: 0x000321B0 File Offset: 0x000303B0
		Private Overridable Property mbdsSourceMas As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceMas IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceMas.PositionChanged, AddressOf Me.mbdsSourceMas_PositionChanged
				End If
				Me._mbdsSourceMas = value
				flag = Me._mbdsSourceMas IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceMas.PositionChanged, AddressOf Me.mbdsSourceMas_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170001A6 RID: 422
		' (get) Token: 0x06000434 RID: 1076 RVA: 0x0003221C File Offset: 0x0003041C
		' (set) Token: 0x06000435 RID: 1077 RVA: 0x00032234 File Offset: 0x00030434
		Private Overridable Property mbdsSourceDel As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceDel IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceDel.PositionChanged, AddressOf Me.mbdsSourceDel_PositionChanged
				End If
				Me._mbdsSourceDel = value
				flag = Me._mbdsSourceDel IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceDel.PositionChanged, AddressOf Me.mbdsSourceDel_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170001A7 RID: 423
		' (get) Token: 0x06000436 RID: 1078 RVA: 0x000322A0 File Offset: 0x000304A0
		' (set) Token: 0x06000437 RID: 1079 RVA: 0x00002BA4 File Offset: 0x00000DA4
		Public Property pdgvMaster As DataGridView
			Get
				Return Me.mdgvMaster
			End Get
			Set(value As DataGridView)
				Me.mdgvMaster = value
			End Set
		End Property

		' Token: 0x170001A8 RID: 424
		' (get) Token: 0x06000438 RID: 1080 RVA: 0x000322B8 File Offset: 0x000304B8
		' (set) Token: 0x06000439 RID: 1081 RVA: 0x00002BAF File Offset: 0x00000DAF
		Public Property pbdsSource As BindingSource
			Get
				Return Me.mbdsSourceMas
			End Get
			Set(value As BindingSource)
				Me.mbdsSourceMas = value
			End Set
		End Property

		' Token: 0x170001A9 RID: 425
		' (get) Token: 0x0600043A RID: 1082 RVA: 0x000322D0 File Offset: 0x000304D0
		' (set) Token: 0x0600043B RID: 1083 RVA: 0x00002BBB File Offset: 0x00000DBB
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x0600043C RID: 1084 RVA: 0x000322E8 File Offset: 0x000304E8
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600043D RID: 1085 RVA: 0x000323B8 File Offset: 0x000305B8
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceDel.Position
				Dim flag As Boolean = position < Me.mbdsSourceDel.Count - 1
				If flag Then
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					mbdsSourceDel.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600043E RID: 1086 RVA: 0x000324A8 File Offset: 0x000306A8
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceDel.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					mbdsSourceDel.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600043F RID: 1087 RVA: 0x0003258C File Offset: 0x0003078C
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSourceDel.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000440 RID: 1088 RVA: 0x00032650 File Offset: 0x00030850
		Private Sub btnLastMas_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSourceMas.Position = Me.mbdsSourceMas.Count - 1
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLastMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000441 RID: 1089 RVA: 0x00032704 File Offset: 0x00030904
		Private Sub btnNextMas_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceMas.Position
				Dim flag As Boolean = position < Me.mbdsSourceMas.Count - 1
				If flag Then
					Dim mbdsSourceMas As BindingSource = Me.mbdsSourceMas
					mbdsSourceMas.Position += 1
				End If
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNextMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000442 RID: 1090 RVA: 0x000327E0 File Offset: 0x000309E0
		Private Sub btnPreMas_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceMas.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSourceMas As BindingSource = Me.mbdsSourceMas
					mbdsSourceMas.Position -= 1
				End If
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000443 RID: 1091 RVA: 0x000328B0 File Offset: 0x00030AB0
		Private Sub btnFirstMas_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSourceMas.Position = 0
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirstMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000444 RID: 1092 RVA: 0x00032958 File Offset: 0x00030B58
		Private Sub frmSAL023_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmSAL023_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000445 RID: 1093 RVA: 0x000329F0 File Offset: 0x00030BF0
		Private Sub frmSAL023_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mbdsSourceMas_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					b = Me.fShow_DatainText()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmSAL023_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000446 RID: 1094 RVA: 0x00032B0C File Offset: 0x00030D0C
		Private Sub mbdsSourceDel_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSourceDel.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					Me.lblPosition.Text = (mbdsSourceDel.Position + 1).ToString() + " / " + mbdsSourceDel.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceDel_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000447 RID: 1095 RVA: 0x00032C14 File Offset: 0x00030E14
		Private Sub mbdsSourceMas_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSourceMas.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButtonMas(True)
				Else
					Dim b As Byte = Me.fDisableButtonMas(False)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceMas_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000448 RID: 1096 RVA: 0x00032CD0 File Offset: 0x00030ED0
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000449 RID: 1097 RVA: 0x00032D68 File Offset: 0x00030F68
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = mdlGeneral.gfCheck_Locked() = 1
				If Not flag Then
					Dim text As String = Me.fAdd_frmSAL024()
					flag = Operators.CompareString(text, "", False) <> 0
					If flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Find("KHOACHINH", text)
							Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
						Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600044A RID: 1098 RVA: 0x00032ED4 File Offset: 0x000310D4
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = mdlGeneral.gfCheck_Locked() = 1
				If Not flag Then
					Dim text As String = Conversions.ToString(Me.fModify_frmSAL024())
					flag = Operators.CompareString(text, "", False) = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600044B RID: 1099 RVA: 0x00032FCC File Offset: 0x000311CC
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = mdlGeneral.gfCheck_Locked() = 1
				If Not flag Then
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LCORRECT").Value)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(40), MsgBoxStyle.Critical, Nothing)
					Else
						Dim b As Byte = Me.fDelete_frmSAL024()
						flag = b = 0
						If Not flag Then
							b = Me.fGetData_4Grid()
							flag = b = 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
							End If
							flag = b <> 0
							If flag Then
								Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600044C RID: 1100 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnPrintMas_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x0600044D RID: 1101 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnDelMas_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x0600044E RID: 1102 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnEditMas_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x0600044F RID: 1103 RVA: 0x0003311C File Offset: 0x0003131C
		Private Function fModify_frmSAL024() As Byte
			Dim frmSAL As frmSAL024 = New frmSAL024()
			Dim b As Byte
			Try
				b = 0
				frmSAL.pbytFromStatus = 3
				Dim flag As Boolean = Me.dgvData.RowCount > 0
				If flag Then
					frmSAL.txtMAHH.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAHH").Value, ""))
					frmSAL.txtTENHH.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmSAL.txtMADVT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MADVT").Value, ""))
					frmSAL.txtQTY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SOLUONG").Value, ""))
					frmSAL.txtDONGIABAN.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DONGIA").Value, ""))
					frmSAL.txtAMT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("THANHTIEN").Value, ""))
					frmSAL.pStrOUTDATE = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("NGAYHETHAN").Value, ""))
					frmSAL.lblDVT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DVT").Value, ""))
					frmSAL.lblDVT2.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DVT").Value, ""))
					frmSAL.pStrDETNUM = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DETNUM").Value, ""))
					frmSAL.pStrREMARKJOU = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARKJOU").Value, ""))
					frmSAL.pStrQtyOrg = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SOLUONG").Value, ""))
				End If
				frmSAL.pStrDOCID = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("DOCID").Value, ""))
				frmSAL.pStrMADV = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MADV").Value, ""))
				frmSAL.pStrMAKH = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAKH").Value, ""))
				frmSAL.pStrMALH = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MALH").Value, ""))
				frmSAL.pStrMAMAY = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAMAY").Value, ""))
				frmSAL.ShowDialog()
				flag = frmSAL.pbytSuccess = 0
				If Not flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fModify_frmSAL024 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmSAL.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000450 RID: 1104 RVA: 0x000335C0 File Offset: 0x000317C0
		Private Function fDelete_frmSAL024() As Byte
			Dim frmSAL As frmSAL024 = New frmSAL024()
			Dim b As Byte
			Try
				b = 0
				frmSAL.pbytFromStatus = 4
				Dim flag As Boolean = Me.dgvData.RowCount > 0
				If flag Then
					Dim frmSAL2 As frmSAL024 = frmSAL
					frmSAL2.txtMAHH.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAHH").Value, ""))
					frmSAL2.txtTENHH.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmSAL2.txtMADVT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MADVT").Value, ""))
					frmSAL2.txtQTY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SOLUONG").Value, ""))
					frmSAL2.txtDONGIABAN.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DONGIA").Value, ""))
					frmSAL2.txtAMT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("THANHTIEN").Value, ""))
					frmSAL2.cmbOUTDATE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("NGAYHETHAN").Value, ""))
					frmSAL2.pStrOUTDATE = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("NGAYHETHAN").Value, ""))
					frmSAL2.lblDVT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DVT").Value, ""))
					frmSAL2.lblDVT2.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DVT").Value, ""))
					frmSAL2.pStrDETNUM = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DETNUM").Value, ""))
					frmSAL2.pStrREMARKJOU = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARKJOU").Value, ""))
				End If
				frmSAL.pStrDOCID = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("DOCID").Value, ""))
				frmSAL.pStrMADV = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MADV").Value, ""))
				frmSAL.pStrMAKH = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAKH").Value, ""))
				frmSAL.pStrMALH = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MALH").Value, ""))
				frmSAL.pStrMAMAY = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAMAY").Value, ""))
				frmSAL.ShowDialog()
				flag = frmSAL.pbytSuccess = 0
				If Not flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDelete_frmSAL024 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmSAL.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000451 RID: 1105 RVA: 0x00033A74 File Offset: 0x00031C74
		Private Function fAdd_frmSAL024() As String
			Dim frmSAL As frmSAL024 = New frmSAL024()
			Dim text As String = ""
			Try
				frmSAL.pbytFromStatus = 1
				Dim flag As Boolean = Me.dgvData.RowCount > 0
				If flag Then
					frmSAL.lblDVT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DVT").Value, ""))
					frmSAL.lblDVT2.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DVT").Value, ""))
				End If
				frmSAL.txtQTY.Text = "0"
				frmSAL.txtDONGIABAN.Text = "0"
				frmSAL.txtAMT.Text = "0"
				frmSAL.txtVTAX.Text = "0"
				frmSAL.txtDISC.Text = "0"
				frmSAL.pStrDOCID = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("DOCID").Value, ""))
				frmSAL.pStrMADV = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MADV").Value, ""))
				frmSAL.pStrMAKH = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAKH").Value, ""))
				frmSAL.pStrMALH = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MALH").Value, ""))
				frmSAL.pStrMAMAY = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAMAY").Value, ""))
				frmSAL.ShowDialog()
				flag = frmSAL.pbytSuccess = 0
				If Not flag Then
					text = frmSAL.pStrFilter
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAdd_frmSAL024 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmSAL.Dispose()
			End Try
			Return text
		End Function

		' Token: 0x06000452 RID: 1106 RVA: 0x00033D40 File Offset: 0x00031F40
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("MAHH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("MAHH").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("MAHH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("OBJNAME").Width = Me.Width - 700
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DVT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(21))
				dgvData.Columns("DVT").Width = 60
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("DVT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SOLUONG").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("SOLUONG").Width = 90
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("SOLUONG").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DONGIA").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("DONGIA").Width = 90
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("DONGIA").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("THANHTIEN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("THANHTIEN").Width = 140
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("THANHTIEN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NGAYHETHAN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(38))
				dgvData.Columns("NGAYHETHAN").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("NGAYHETHAN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LCORRECT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(39))
				dgvData.Columns("LCORRECT").Width = 92
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("LCORRECT").DefaultCellStyle = dataGridViewCellStyle
				Dim flag As Boolean = Not mdlVariable.gblnSTOCKDATE
				If flag Then
					dgvData.Columns("NGAYHETHAN").Visible = False
				End If
				dgvData.Columns("DOCID").Visible = False
				dgvData.Columns("OUTDATE").Visible = False
				dgvData.Columns("DETNUM").Visible = False
				dgvData.Columns("REMARK").Visible = False
				dgvData.Columns("MADVT").Visible = False
				dgvData.Columns("KHOACHINH").Visible = False
				dgvData.Columns("REMARKJOU").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000453 RID: 1107 RVA: 0x0003425C File Offset: 0x0003245C
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000454 RID: 1108 RVA: 0x00034344 File Offset: 0x00032544
		Private Function fDisableButtonMas(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirstMas.Enabled = Not pblnDisable
				Me.btnLastMas.Enabled = Not pblnDisable
				Me.btnPreMas.Enabled = Not pblnDisable
				Me.btnNextMas.Enabled = Not pblnDisable
				Me.btnPrintMas.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButtonMas ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000455 RID: 1109 RVA: 0x0003442C File Offset: 0x0003262C
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@intDecQty"
				array(0).Value = mdlVariable.gbytDECNUMQTY
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@intDecAmt"
				array(1).Value = mdlVariable.gbytDECNUMAMT
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMBANCHUATT_GET_DATA_DETAIL", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSourceDel.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSourceDel
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000456 RID: 1110 RVA: 0x00034598 File Offset: 0x00032798
		Private Function fShow_DatainText() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.txtMAKH.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("TENKH").Value, ""))
				Me.txtMADV.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("TENDV").Value, ""))
				Me.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("REMARK").Value, ""))
				Me.mbdsSourceDel.Filter = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("DOCID ='", Me.mdgvMaster.CurrentRow.Cells("DOCID").Value), ""), "'"))
				mdlUIForm.gsSetCap_2Form(Me, Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Me.mArrStrFrmMess(2) + " " + Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("SOCT").Value, ""))) + Me.mArrStrFrmMess(33) + " ", Me.mdgvMaster.CurrentRow.Cells("NGAYKT").Value), " - "), Me.mArrStrFrmMess(22)), " ["), Me.mstrStockName), "]")))
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fShow_DatainText ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000457 RID: 1111 RVA: 0x0003480C File Offset: 0x00032A0C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.txtMADV.[ReadOnly] = True
				Me.txtMAKH.[ReadOnly] = True
				Me.txtREMARK.[ReadOnly] = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000458 RID: 1112 RVA: 0x000348E8 File Offset: 0x00032AE8
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mstrStockName = Strings.Trim(mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMKH", "OBJID", mdlVariable.gStrStockCode, "OBJNAME"))
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Me.mArrStrFrmMess(2) + " " + Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("SOCT").Value, ""))) + Me.mArrStrFrmMess(33) + " ", Me.mdgvMaster.CurrentRow.Cells("NGAYKT").Value), " - "), Me.mArrStrFrmMess(22)), " ["), Me.mstrStockName), "]")))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "6070101000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000459 RID: 1113 RVA: 0x00034AF0 File Offset: 0x00032CF0
		Private Sub sClear_Form()
			Try
				Me.mbdsSourceDel.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x040001BF RID: 447
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040001C1 RID: 449
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x040001C2 RID: 450
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x040001C3 RID: 451
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x040001C4 RID: 452
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x040001C5 RID: 453
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x040001C6 RID: 454
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x040001C7 RID: 455
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x040001C8 RID: 456
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040001C9 RID: 457
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040001CA RID: 458
		<AccessedThroughProperty("lblMADV")>
		Private _lblMADV As Label

		' Token: 0x040001CB RID: 459
		<AccessedThroughProperty("txtMADV")>
		Private _txtMADV As TextBox

		' Token: 0x040001CC RID: 460
		<AccessedThroughProperty("lblREMARK")>
		Private _lblREMARK As Label

		' Token: 0x040001CD RID: 461
		<AccessedThroughProperty("txtREMARK")>
		Private _txtREMARK As TextBox

		' Token: 0x040001CE RID: 462
		<AccessedThroughProperty("btnPrintMas")>
		Private _btnPrintMas As Button

		' Token: 0x040001CF RID: 463
		<AccessedThroughProperty("btnDelMas")>
		Private _btnDelMas As Button

		' Token: 0x040001D0 RID: 464
		<AccessedThroughProperty("btnEditMas")>
		Private _btnEditMas As Button

		' Token: 0x040001D1 RID: 465
		<AccessedThroughProperty("btnFirstMas")>
		Private _btnFirstMas As Button

		' Token: 0x040001D2 RID: 466
		<AccessedThroughProperty("btnPreMas")>
		Private _btnPreMas As Button

		' Token: 0x040001D3 RID: 467
		<AccessedThroughProperty("btnNextMas")>
		Private _btnNextMas As Button

		' Token: 0x040001D4 RID: 468
		<AccessedThroughProperty("btnLastMas")>
		Private _btnLastMas As Button

		' Token: 0x040001D5 RID: 469
		<AccessedThroughProperty("txtMAKH")>
		Private _txtMAKH As TextBox

		' Token: 0x040001D6 RID: 470
		<AccessedThroughProperty("lblMAKH")>
		Private _lblMAKH As Label

		' Token: 0x040001D7 RID: 471
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040001D8 RID: 472
		Private mArrStrFrmMess As String()

		' Token: 0x040001D9 RID: 473
		Private mStrOBJID As String

		' Token: 0x040001DA RID: 474
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040001DB RID: 475
		<AccessedThroughProperty("mbdsSourceMas")>
		Private _mbdsSourceMas As BindingSource

		' Token: 0x040001DC RID: 476
		<AccessedThroughProperty("mbdsSourceDel")>
		Private _mbdsSourceDel As BindingSource

		' Token: 0x040001DD RID: 477
		Private mdgvMaster As DataGridView

		' Token: 0x040001DE RID: 478
		Private marrDrFind As DataRow()

		' Token: 0x040001DF RID: 479
		Private mintFindLastPos As Integer

		' Token: 0x040001E0 RID: 480
		Private mstrStockName As String
	End Class
End Namespace
