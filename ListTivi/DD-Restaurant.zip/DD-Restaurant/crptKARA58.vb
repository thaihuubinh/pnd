﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x0200011B RID: 283
	Public Class crptKARA58
		Inherits ReportClass

		' Token: 0x06005763 RID: 22371 RVA: 0x0000EFB2 File Offset: 0x0000D1B2
		Public Sub New()
			crptKARA58.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001F89 RID: 8073
		' (get) Token: 0x06005764 RID: 22372 RVA: 0x004DAEC8 File Offset: 0x004D90C8
		' (set) Token: 0x06005765 RID: 22373 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crptKARA58.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001F8A RID: 8074
		' (get) Token: 0x06005766 RID: 22374 RVA: 0x004DA738 File Offset: 0x004D8938
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section1 As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001F8B RID: 8075
		' (get) Token: 0x06005767 RID: 22375 RVA: 0x004DA75C File Offset: 0x004D895C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section2 As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001F8C RID: 8076
		' (get) Token: 0x06005768 RID: 22376 RVA: 0x004DA780 File Offset: 0x004D8980
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property phsDG As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001F8D RID: 8077
		' (get) Token: 0x06005769 RID: 22377 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section3 As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001F8E RID: 8078
		' (get) Token: 0x0600576A RID: 22378 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dsDG As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001F8F RID: 8079
		' (get) Token: 0x0600576B RID: 22379 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x17001F90 RID: 8080
		' (get) Token: 0x0600576C RID: 22380 RVA: 0x004DA810 File Offset: 0x004D8A10
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section4 As Section
			Get
				Return Me.ReportDefinition.Sections(6)
			End Get
		End Property

		' Token: 0x17001F91 RID: 8081
		' (get) Token: 0x0600576D RID: 22381 RVA: 0x004DA834 File Offset: 0x004D8A34
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(7)
			End Get
		End Property

		' Token: 0x04002713 RID: 10003
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
