﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200022A RID: 554
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60519k80_Sub
		Inherits Component
		Implements ICachedReport

		' Token: 0x060062A4 RID: 25252 RVA: 0x00011B19 File Offset: 0x0000FD19
		Public Sub New()
			CachedrptRepBC60519k80_Sub.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002581 RID: 9601
		' (get) Token: 0x060062A5 RID: 25253 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060062A6 RID: 25254 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002582 RID: 9602
		' (get) Token: 0x060062A7 RID: 25255 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060062A8 RID: 25256 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002583 RID: 9603
		' (get) Token: 0x060062A9 RID: 25257 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060062AA RID: 25258 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x060062AB RID: 25259 RVA: 0x004DD0A0 File Offset: 0x004DB2A0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60519k80_Sub() With { .Site = Me.Site }
		End Function

		' Token: 0x060062AC RID: 25260 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002822 RID: 10274
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
