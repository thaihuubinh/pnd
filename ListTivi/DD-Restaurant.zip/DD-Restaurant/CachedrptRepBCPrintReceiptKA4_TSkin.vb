﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002E2 RID: 738
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBCPrintReceiptKA4_TSkin
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006D89 RID: 28041 RVA: 0x00013891 File Offset: 0x00011A91
		Public Sub New()
			CachedrptRepBCPrintReceiptKA4_TSkin.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002CCE RID: 11470
		' (get) Token: 0x06006D8A RID: 28042 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006D8B RID: 28043 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002CCF RID: 11471
		' (get) Token: 0x06006D8C RID: 28044 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006D8D RID: 28045 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002CD0 RID: 11472
		' (get) Token: 0x06006D8E RID: 28046 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006D8F RID: 28047 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006D90 RID: 28048 RVA: 0x004DEE84 File Offset: 0x004DD084
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBCPrintReceiptKA4_TSkin() With { .Site = Me.Site }
		End Function

		' Token: 0x06006D91 RID: 28049 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028DA RID: 10458
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
