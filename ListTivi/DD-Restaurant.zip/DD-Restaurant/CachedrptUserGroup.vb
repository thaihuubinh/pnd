﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000358 RID: 856
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptUserGroup
		Inherits Component
		Implements ICachedReport

		' Token: 0x060073D4 RID: 29652 RVA: 0x00014B77 File Offset: 0x00012D77
		Public Sub New()
			CachedrptUserGroup.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170030CB RID: 12491
		' (get) Token: 0x060073D5 RID: 29653 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060073D6 RID: 29654 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170030CC RID: 12492
		' (get) Token: 0x060073D7 RID: 29655 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060073D8 RID: 29656 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170030CD RID: 12493
		' (get) Token: 0x060073D9 RID: 29657 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060073DA RID: 29658 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x060073DB RID: 29659 RVA: 0x004DFD44 File Offset: 0x004DDF44
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptUserGroup() With { .Site = Me.Site }
		End Function

		' Token: 0x060073DC RID: 29660 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002950 RID: 10576
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
