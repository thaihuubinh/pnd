﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020001E2 RID: 482
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60504k80Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005F71 RID: 24433 RVA: 0x00010F91 File Offset: 0x0000F191
		Public Sub New()
			CachedrptRepBC60504k80Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170023B6 RID: 9142
		' (get) Token: 0x06005F72 RID: 24434 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005F73 RID: 24435 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170023B7 RID: 9143
		' (get) Token: 0x06005F74 RID: 24436 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005F75 RID: 24437 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170023B8 RID: 9144
		' (get) Token: 0x06005F76 RID: 24438 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005F77 RID: 24439 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005F78 RID: 24440 RVA: 0x004DC7A0 File Offset: 0x004DA9A0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60504k80Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x06005F79 RID: 24441 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040027DA RID: 10202
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
