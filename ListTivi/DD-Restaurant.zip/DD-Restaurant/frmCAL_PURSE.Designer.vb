﻿Namespace prjIS_SalesPOS
	' Token: 0x0200001D RID: 29
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCAL_PURSE
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600047C RID: 1148 RVA: 0x00036514 File Offset: 0x00034714
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600047D RID: 1149 RVA: 0x0003654C File Offset: 0x0003474C
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCAL_PURSE))
			Me.lblSTARTDATE = New Global.System.Windows.Forms.Label()
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnOK = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.txtFromMonth = New Global.System.Windows.Forms.TextBox()
			Me.txtToMonth = New Global.System.Windows.Forms.TextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.txtToYear = New Global.System.Windows.Forms.TextBox()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.txtFromYear = New Global.System.Windows.Forms.TextBox()
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.grpNavigater = New Global.System.Windows.Forms.GroupBox()
			Me.btnFirst = New Global.System.Windows.Forms.Button()
			Me.btnPrevious = New Global.System.Windows.Forms.Button()
			Me.btnLast = New Global.System.Windows.Forms.Button()
			Me.btnNext = New Global.System.Windows.Forms.Button()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.grpNavigater.SuspendLayout()
			Me.SuspendLayout()
			Me.lblSTARTDATE.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblSTARTDATE As Global.System.Windows.Forms.Control = Me.lblSTARTDATE
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(49, 25)
			lblSTARTDATE.Location = point
			Me.lblSTARTDATE.Name = "lblSTARTDATE"
			Dim lblSTARTDATE2 As Global.System.Windows.Forms.Control = Me.lblSTARTDATE
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(103, 21)
			lblSTARTDATE2.Size = size
			Me.lblSTARTDATE.TabIndex = 5
			Me.lblSTARTDATE.Tag = "CB0002"
			Me.lblSTARTDATE.Text = "Tu thang"
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			point = New Global.System.Drawing.Point(575, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			size = New Global.System.Drawing.Size(119, 176)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 5
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 50F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnOK, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 1)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 2
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 50F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 50F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 155)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnOK.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnOK.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Dim btnOK As Global.System.Windows.Forms.Control = Me.btnOK
			point = New Global.System.Drawing.Point(3, 3)
			btnOK.Location = point
			Me.btnOK.Name = "btnOK"
			Dim btnOK2 As Global.System.Windows.Forms.Control = Me.btnOK
			size = New Global.System.Drawing.Size(107, 71)
			btnOK2.Size = size
			Me.btnOK.TabIndex = 0
			Me.btnOK.Tag = "CR0005"
			Me.btnOK.Text = "Đồng ý"
			Me.btnOK.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnOK.UseVisualStyleBackColor = True
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 80)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 72)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 2
			Me.btnExit.Tag = "CR0006"
			Me.btnExit.Text = "&Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.txtFromMonth.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.txtFromMonth.ForeColor = Global.System.Drawing.Color.Black
			Dim txtFromMonth As Global.System.Windows.Forms.Control = Me.txtFromMonth
			point = New Global.System.Drawing.Point(158, 24)
			txtFromMonth.Location = point
			Me.txtFromMonth.Name = "txtFromMonth"
			Dim txtFromMonth2 As Global.System.Windows.Forms.Control = Me.txtFromMonth
			size = New Global.System.Drawing.Size(138, 22)
			txtFromMonth2.Size = size
			Me.txtFromMonth.TabIndex = 0
			Me.txtFromMonth.Tag = "0R0000"
			Me.txtFromMonth.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.txtToMonth.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Dim txtToMonth As Global.System.Windows.Forms.Control = Me.txtToMonth
			point = New Global.System.Drawing.Point(158, 52)
			txtToMonth.Location = point
			Me.txtToMonth.Name = "txtToMonth"
			Dim txtToMonth2 As Global.System.Windows.Forms.Control = Me.txtToMonth
			size = New Global.System.Drawing.Size(138, 22)
			txtToMonth2.Size = size
			Me.txtToMonth.TabIndex = 2
			Me.txtToMonth.Tag = "0R0000"
			Me.txtToMonth.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(49, 53)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(103, 21)
			label2.Size = size
			Me.Label1.TabIndex = 7
			Me.Label1.Tag = "CB0003"
			Me.Label1.Text = "den thang"
			Me.txtToYear.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Dim txtToYear As Global.System.Windows.Forms.Control = Me.txtToYear
			point = New Global.System.Drawing.Point(374, 52)
			txtToYear.Location = point
			Me.txtToYear.Name = "txtToYear"
			Dim txtToYear2 As Global.System.Windows.Forms.Control = Me.txtToYear
			size = New Global.System.Drawing.Size(152, 22)
			txtToYear2.Size = size
			Me.txtToYear.TabIndex = 3
			Me.txtToYear.Tag = "0R0000"
			Me.txtToYear.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(299, 53)
			label3.Location = point
			Me.Label2.Name = "Label2"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(69, 21)
			label4.Size = size
			Me.Label2.TabIndex = 11
			Me.Label2.Tag = "CB0004"
			Me.Label2.Text = "nam"
			Me.txtFromYear.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Dim txtFromYear As Global.System.Windows.Forms.Control = Me.txtFromYear
			point = New Global.System.Drawing.Point(374, 24)
			txtFromYear.Location = point
			Me.txtFromYear.Name = "txtFromYear"
			Dim txtFromYear2 As Global.System.Windows.Forms.Control = Me.txtFromYear
			size = New Global.System.Drawing.Size(152, 22)
			txtFromYear2.Size = size
			Me.txtFromYear.TabIndex = 1
			Me.txtFromYear.Tag = "0R0000"
			Me.txtFromYear.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label3.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(299, 27)
			label5.Location = point
			Me.Label3.Name = "Label3"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(81, 21)
			label6.Size = size
			Me.Label3.TabIndex = 9
			Me.Label3.Tag = "CB0004"
			Me.Label3.Text = "nam"
			Me.grpNavigater.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom
			Me.grpNavigater.Controls.Add(Me.btnFirst)
			Me.grpNavigater.Controls.Add(Me.btnPrevious)
			Me.grpNavigater.Controls.Add(Me.btnLast)
			Me.grpNavigater.Controls.Add(Me.btnNext)
			Dim grpNavigater As Global.System.Windows.Forms.Control = Me.grpNavigater
			point = New Global.System.Drawing.Point(187, 103)
			grpNavigater.Location = point
			Me.grpNavigater.Name = "grpNavigater"
			Dim grpNavigater2 As Global.System.Windows.Forms.Control = Me.grpNavigater
			size = New Global.System.Drawing.Size(261, 61)
			grpNavigater2.Size = size
			Me.grpNavigater.TabIndex = 4
			Me.grpNavigater.TabStop = False
			Me.btnFirst.Image = Global.prjIS_SalesPOS.My.Resources.Resources.First
			Dim btnFirst As Global.System.Windows.Forms.Control = Me.btnFirst
			point = New Global.System.Drawing.Point(6, 14)
			btnFirst.Location = point
			Me.btnFirst.Name = "btnFirst"
			Dim btnFirst2 As Global.System.Windows.Forms.Control = Me.btnFirst
			size = New Global.System.Drawing.Size(40, 35)
			btnFirst2.Size = size
			Me.btnFirst.TabIndex = 2
			Me.btnFirst.UseVisualStyleBackColor = True
			Me.btnPrevious.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Previous
			Dim btnPrevious As Global.System.Windows.Forms.Control = Me.btnPrevious
			point = New Global.System.Drawing.Point(70, 14)
			btnPrevious.Location = point
			Me.btnPrevious.Name = "btnPrevious"
			Dim btnPrevious2 As Global.System.Windows.Forms.Control = Me.btnPrevious
			size = New Global.System.Drawing.Size(40, 35)
			btnPrevious2.Size = size
			Me.btnPrevious.TabIndex = 3
			Me.btnPrevious.UseVisualStyleBackColor = True
			Me.btnLast.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Last
			Dim btnLast As Global.System.Windows.Forms.Control = Me.btnLast
			point = New Global.System.Drawing.Point(216, 14)
			btnLast.Location = point
			Me.btnLast.Name = "btnLast"
			Dim btnLast2 As Global.System.Windows.Forms.Control = Me.btnLast
			size = New Global.System.Drawing.Size(40, 35)
			btnLast2.Size = size
			Me.btnLast.TabIndex = 5
			Me.btnLast.UseVisualStyleBackColor = True
			Me.btnNext.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Next
			Dim btnNext As Global.System.Windows.Forms.Control = Me.btnNext
			point = New Global.System.Drawing.Point(148, 14)
			btnNext.Location = point
			Me.btnNext.Name = "btnNext"
			Dim btnNext2 As Global.System.Windows.Forms.Control = Me.btnNext
			size = New Global.System.Drawing.Size(40, 35)
			btnNext2.Size = size
			Me.btnNext.TabIndex = 4
			Me.btnNext.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(694, 176)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.grpNavigater)
			Me.Controls.Add(Me.txtToYear)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.txtFromYear)
			Me.Controls.Add(Me.Label3)
			Me.Controls.Add(Me.txtToMonth)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.txtFromMonth)
			Me.Controls.Add(Me.grpButton)
			Me.Controls.Add(Me.lblSTARTDATE)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmCAL_PURSE"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Tinh gia von"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.grpNavigater.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x040001F0 RID: 496
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
