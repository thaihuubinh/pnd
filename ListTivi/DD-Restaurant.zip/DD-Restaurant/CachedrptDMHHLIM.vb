﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200015A RID: 346
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptDMHHLIM
		Inherits Component
		Implements ICachedReport

		' Token: 0x060059DE RID: 23006 RVA: 0x0000F9C9 File Offset: 0x0000DBC9
		Public Sub New()
			CachedrptDMHHLIM.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170020CB RID: 8395
		' (get) Token: 0x060059DF RID: 23007 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060059E0 RID: 23008 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170020CC RID: 8396
		' (get) Token: 0x060059E1 RID: 23009 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060059E2 RID: 23010 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170020CD RID: 8397
		' (get) Token: 0x060059E3 RID: 23011 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060059E4 RID: 23012 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x060059E5 RID: 23013 RVA: 0x004DB6A0 File Offset: 0x004D98A0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptDMHHLIM() With { .Site = Me.Site }
		End Function

		' Token: 0x060059E6 RID: 23014 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002752 RID: 10066
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
