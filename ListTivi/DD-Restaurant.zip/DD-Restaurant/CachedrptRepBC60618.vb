﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002A8 RID: 680
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60618
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006872 RID: 26738 RVA: 0x00012F47 File Offset: 0x00011147
		Public Sub New()
			CachedrptRepBC60618.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170028D9 RID: 10457
		' (get) Token: 0x06006873 RID: 26739 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006874 RID: 26740 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170028DA RID: 10458
		' (get) Token: 0x06006875 RID: 26741 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006876 RID: 26742 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170028DB RID: 10459
		' (get) Token: 0x06006877 RID: 26743 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006878 RID: 26744 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006879 RID: 26745 RVA: 0x004DE060 File Offset: 0x004DC260
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60618() With { .Site = Me.Site }
		End Function

		' Token: 0x0600687A RID: 26746 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028A0 RID: 10400
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
