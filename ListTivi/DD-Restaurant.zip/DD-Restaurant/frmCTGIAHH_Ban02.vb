﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200002A RID: 42
	<DesignerGenerated()>
	Public Partial Class frmCTGIAHH_Ban02
		Inherits Form

		' Token: 0x060007EB RID: 2027 RVA: 0x0005C7D0 File Offset: 0x0005A9D0
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDOCUMENT016_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDOCUMENT16_Load
			AddHandler MyBase.KeyPress, AddressOf Me.frmDOC016_KeyPress
			frmCTGIAHH_Ban02.__ENCList.Add(New WeakReference(Me))
			Me.mStrYYYYMM = ""
			Me.mStrXSOCT = ""
			Me.mStrVat = "0"
			Me.mbdsSourceDMHH = New BindingSource()
			Me.mintPos = 0
			Me.marrDblPrice = New Double(9) {}
			Me.mstrMADVT_HH = ""
			Me.mStrStartDate = ""
			Me.mStrLockDate = ""
			Me.mStrMaKH = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000302 RID: 770
		' (get) Token: 0x060007EE RID: 2030 RVA: 0x0005D824 File Offset: 0x0005BA24
		' (set) Token: 0x060007EF RID: 2031 RVA: 0x0000356B File Offset: 0x0000176B
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000303 RID: 771
		' (get) Token: 0x060007F0 RID: 2032 RVA: 0x0005D83C File Offset: 0x0005BA3C
		' (set) Token: 0x060007F1 RID: 2033 RVA: 0x00003575 File Offset: 0x00001775
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnFilter = value
			End Set
		End Property

		' Token: 0x17000304 RID: 772
		' (get) Token: 0x060007F2 RID: 2034 RVA: 0x0005D854 File Offset: 0x0005BA54
		' (set) Token: 0x060007F3 RID: 2035 RVA: 0x0005D86C File Offset: 0x0005BA6C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000305 RID: 773
		' (get) Token: 0x060007F4 RID: 2036 RVA: 0x0005D8D8 File Offset: 0x0005BAD8
		' (set) Token: 0x060007F5 RID: 2037 RVA: 0x0005D8F0 File Offset: 0x0005BAF0
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000306 RID: 774
		' (get) Token: 0x060007F6 RID: 2038 RVA: 0x0005D95C File Offset: 0x0005BB5C
		' (set) Token: 0x060007F7 RID: 2039 RVA: 0x0000357F File Offset: 0x0000177F
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnFind = value
			End Set
		End Property

		' Token: 0x17000307 RID: 775
		' (get) Token: 0x060007F8 RID: 2040 RVA: 0x0005D974 File Offset: 0x0005BB74
		' (set) Token: 0x060007F9 RID: 2041 RVA: 0x0005D98C File Offset: 0x0005BB8C
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000308 RID: 776
		' (get) Token: 0x060007FA RID: 2042 RVA: 0x0005D9F8 File Offset: 0x0005BBF8
		' (set) Token: 0x060007FB RID: 2043 RVA: 0x00003589 File Offset: 0x00001789
		Friend Overridable Property lblMAHH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAHH = value
			End Set
		End Property

		' Token: 0x17000309 RID: 777
		' (get) Token: 0x060007FC RID: 2044 RVA: 0x0005DA10 File Offset: 0x0005BC10
		' (set) Token: 0x060007FD RID: 2045 RVA: 0x00003593 File Offset: 0x00001793
		Friend Overridable Property lblWORKDATE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblWORKDATE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblWORKDATE = value
			End Set
		End Property

		' Token: 0x1700030A RID: 778
		' (get) Token: 0x060007FE RID: 2046 RVA: 0x0005DA28 File Offset: 0x0005BC28
		' (set) Token: 0x060007FF RID: 2047 RVA: 0x0005DA40 File Offset: 0x0005BC40
		Friend Overridable Property txtDONGIAMUA As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtDONGIAMUA
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtDONGIAMUA IsNot Nothing
				If flag Then
					RemoveHandler Me._txtDONGIAMUA.KeyPress, AddressOf Me.txtDONGIAMUA_KeyPress
					RemoveHandler Me._txtDONGIAMUA.GotFocus, AddressOf Me.txtDONGIAMUA_GotFocus
				End If
				Me._txtDONGIAMUA = value
				flag = Me._txtDONGIAMUA IsNot Nothing
				If flag Then
					AddHandler Me._txtDONGIAMUA.KeyPress, AddressOf Me.txtDONGIAMUA_KeyPress
					AddHandler Me._txtDONGIAMUA.GotFocus, AddressOf Me.txtDONGIAMUA_GotFocus
				End If
			End Set
		End Property

		' Token: 0x1700030B RID: 779
		' (get) Token: 0x06000800 RID: 2048 RVA: 0x0005DADC File Offset: 0x0005BCDC
		' (set) Token: 0x06000801 RID: 2049 RVA: 0x0000359D File Offset: 0x0000179D
		Friend Overridable Property lblMoneyUnit As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMoneyUnit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMoneyUnit = value
			End Set
		End Property

		' Token: 0x1700030C RID: 780
		' (get) Token: 0x06000802 RID: 2050 RVA: 0x0005DAF4 File Offset: 0x0005BCF4
		' (set) Token: 0x06000803 RID: 2051 RVA: 0x000035A7 File Offset: 0x000017A7
		Friend Overridable Property txtTENHH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENHH = value
			End Set
		End Property

		' Token: 0x1700030D RID: 781
		' (get) Token: 0x06000804 RID: 2052 RVA: 0x0005DB0C File Offset: 0x0005BD0C
		' (set) Token: 0x06000805 RID: 2053 RVA: 0x0005DB24 File Offset: 0x0005BD24
		Friend Overridable Property btnSelDMHH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelDMHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelDMHH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelDMHH.Click, AddressOf Me.btnSelDMHH_Click
				End If
				Me._btnSelDMHH = value
				flag = Me._btnSelDMHH IsNot Nothing
				If flag Then
					AddHandler Me._btnSelDMHH.Click, AddressOf Me.btnSelDMHH_Click
				End If
			End Set
		End Property

		' Token: 0x1700030E RID: 782
		' (get) Token: 0x06000806 RID: 2054 RVA: 0x0005DB90 File Offset: 0x0005BD90
		' (set) Token: 0x06000807 RID: 2055 RVA: 0x0005DBA8 File Offset: 0x0005BDA8
		Friend Overridable Property txtMAHH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAHH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAHH.TextChanged, AddressOf Me.txtMAHH_TextChanged
					RemoveHandler Me._txtMAHH.KeyPress, AddressOf Me.txtMAHH_KeyPress
					RemoveHandler Me._txtMAHH.KeyDown, AddressOf Me.txtMAHH_KeyDown
					RemoveHandler Me._txtMAHH.GotFocus, AddressOf Me.txtMAHH_GotFocus
				End If
				Me._txtMAHH = value
				flag = Me._txtMAHH IsNot Nothing
				If flag Then
					AddHandler Me._txtMAHH.TextChanged, AddressOf Me.txtMAHH_TextChanged
					AddHandler Me._txtMAHH.KeyPress, AddressOf Me.txtMAHH_KeyPress
					AddHandler Me._txtMAHH.KeyDown, AddressOf Me.txtMAHH_KeyDown
					AddHandler Me._txtMAHH.GotFocus, AddressOf Me.txtMAHH_GotFocus
				End If
			End Set
		End Property

		' Token: 0x1700030F RID: 783
		' (get) Token: 0x06000808 RID: 2056 RVA: 0x0005DCA8 File Offset: 0x0005BEA8
		' (set) Token: 0x06000809 RID: 2057 RVA: 0x000035B1 File Offset: 0x000017B1
		Friend Overridable Property lblDONGIA As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDONGIA
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDONGIA = value
			End Set
		End Property

		' Token: 0x17000310 RID: 784
		' (get) Token: 0x0600080A RID: 2058 RVA: 0x0005DCC0 File Offset: 0x0005BEC0
		' (set) Token: 0x0600080B RID: 2059 RVA: 0x000035BB File Offset: 0x000017BB
		Friend Overridable Property lblMark As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMark
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMark = value
			End Set
		End Property

		' Token: 0x17000311 RID: 785
		' (get) Token: 0x0600080C RID: 2060 RVA: 0x0005DCD8 File Offset: 0x0005BED8
		' (set) Token: 0x0600080D RID: 2061 RVA: 0x000035C5 File Offset: 0x000017C5
		Friend Overridable Property lblDVT2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDVT2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDVT2 = value
			End Set
		End Property

		' Token: 0x17000312 RID: 786
		' (get) Token: 0x0600080E RID: 2062 RVA: 0x0005DCF0 File Offset: 0x0005BEF0
		' (set) Token: 0x0600080F RID: 2063 RVA: 0x000035CF File Offset: 0x000017CF
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000313 RID: 787
		' (get) Token: 0x06000810 RID: 2064 RVA: 0x0005DD08 File Offset: 0x0005BF08
		' (set) Token: 0x06000811 RID: 2065 RVA: 0x0005DD20 File Offset: 0x0005BF20
		Friend Overridable Property dgvMAHH As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvMAHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvMAHH IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvMAHH.KeyDown, AddressOf Me.dgvMAHH_KeyDown
				End If
				Me._dgvMAHH = value
				flag = Me._dgvMAHH IsNot Nothing
				If flag Then
					AddHandler Me._dgvMAHH.KeyDown, AddressOf Me.dgvMAHH_KeyDown
				End If
			End Set
		End Property

		' Token: 0x17000314 RID: 788
		' (get) Token: 0x06000812 RID: 2066 RVA: 0x0005DD8C File Offset: 0x0005BF8C
		' (set) Token: 0x06000813 RID: 2067 RVA: 0x0005DDA4 File Offset: 0x0005BFA4
		Private Overridable Property mbdsSourceDMHH As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDMHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceDMHH IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceDMHH.PositionChanged, AddressOf Me.mbdsSourceDMHH_PositionChanged
				End If
				Me._mbdsSourceDMHH = value
				flag = Me._mbdsSourceDMHH IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceDMHH.PositionChanged, AddressOf Me.mbdsSourceDMHH_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000315 RID: 789
		' (get) Token: 0x06000814 RID: 2068 RVA: 0x0005DE10 File Offset: 0x0005C010
		' (set) Token: 0x06000815 RID: 2069 RVA: 0x000035D9 File Offset: 0x000017D9
		Public Property pdtNgayGio As String
			Get
				Return Conversions.ToString(Me.mdtNgayGio)
			End Get
			Set(value As String)
				Me.mdtNgayGio = Conversions.ToDate(value)
			End Set
		End Property

		' Token: 0x17000316 RID: 790
		' (get) Token: 0x06000816 RID: 2070 RVA: 0x0005DE30 File Offset: 0x0005C030
		' (set) Token: 0x06000817 RID: 2071 RVA: 0x000035E9 File Offset: 0x000017E9
		Public Property pIntSTT As String
			Get
				Return Conversions.ToString(Me.mIntSTT)
			End Get
			Set(value As String)
				Me.mIntSTT = Conversions.ToInteger(value)
			End Set
		End Property

		' Token: 0x17000317 RID: 791
		' (get) Token: 0x06000818 RID: 2072 RVA: 0x0005DE50 File Offset: 0x0005C050
		' (set) Token: 0x06000819 RID: 2073 RVA: 0x000035F9 File Offset: 0x000017F9
		Public Property pstrMaKH As String
			Get
				Return Me.mStrMaKH
			End Get
			Set(value As String)
				Me.mStrMaKH = value
			End Set
		End Property

		' Token: 0x17000318 RID: 792
		' (get) Token: 0x0600081A RID: 2074 RVA: 0x0005DE68 File Offset: 0x0005C068
		' (set) Token: 0x0600081B RID: 2075 RVA: 0x00003604 File Offset: 0x00001804
		Public Property pStrPerVAT As String
			Get
				Return Me.mStrVat
			End Get
			Set(value As String)
				Me.mStrVat = value
			End Set
		End Property

		' Token: 0x17000319 RID: 793
		' (get) Token: 0x0600081C RID: 2076 RVA: 0x0005DE80 File Offset: 0x0005C080
		' (set) Token: 0x0600081D RID: 2077 RVA: 0x0000360F File Offset: 0x0000180F
		Public Property pStrYYYYMM As String
			Get
				Return Me.mStrYYYYMM
			End Get
			Set(value As String)
				Me.mStrYYYYMM = value
			End Set
		End Property

		' Token: 0x1700031A RID: 794
		' (get) Token: 0x0600081E RID: 2078 RVA: 0x0005DE98 File Offset: 0x0005C098
		' (set) Token: 0x0600081F RID: 2079 RVA: 0x0000361A File Offset: 0x0000181A
		Public Property pStrXSoCT As String
			Get
				Return Me.mStrXSOCT
			End Get
			Set(value As String)
				Me.mStrXSOCT = value
			End Set
		End Property

		' Token: 0x1700031B RID: 795
		' (get) Token: 0x06000820 RID: 2080 RVA: 0x0005DEB0 File Offset: 0x0005C0B0
		' (set) Token: 0x06000821 RID: 2081 RVA: 0x00003625 File Offset: 0x00001825
		Public Property pBytHOAN_TRA As Byte
			Get
				Return Me.mBytHoan_Tra
			End Get
			Set(value As Byte)
				Me.mBytHoan_Tra = value
			End Set
		End Property

		' Token: 0x1700031C RID: 796
		' (get) Token: 0x06000822 RID: 2082 RVA: 0x0005DEC8 File Offset: 0x0005C0C8
		' (set) Token: 0x06000823 RID: 2083 RVA: 0x00003630 File Offset: 0x00001830
		Public Property pStrNGAYHETHAN As String
			Get
				Return Me.mStrNGAYHETHAN
			End Get
			Set(value As String)
				Me.mStrNGAYHETHAN = value
			End Set
		End Property

		' Token: 0x1700031D RID: 797
		' (get) Token: 0x06000824 RID: 2084 RVA: 0x0005DEE0 File Offset: 0x0005C0E0
		' (set) Token: 0x06000825 RID: 2085 RVA: 0x0000363B File Offset: 0x0000183B
		Public Property pStrDETNUM As String
			Get
				Return Me.mStrDETNUM
			End Get
			Set(value As String)
				Me.mStrDETNUM = value
			End Set
		End Property

		' Token: 0x1700031E RID: 798
		' (get) Token: 0x06000826 RID: 2086 RVA: 0x0005DEF8 File Offset: 0x0005C0F8
		' (set) Token: 0x06000827 RID: 2087 RVA: 0x00003646 File Offset: 0x00001846
		Public Property pStrMABAN As String
			Get
				Return Me.mStrMABAN
			End Get
			Set(value As String)
				Me.mStrMABAN = value
			End Set
		End Property

		' Token: 0x1700031F RID: 799
		' (get) Token: 0x06000828 RID: 2088 RVA: 0x0005DF10 File Offset: 0x0005C110
		' (set) Token: 0x06000829 RID: 2089 RVA: 0x00003651 File Offset: 0x00001851
		Public Property pStrDOCID As String
			Get
				Return Me.mStrDOCID
			End Get
			Set(value As String)
				Me.mStrDOCID = value
			End Set
		End Property

		' Token: 0x17000320 RID: 800
		' (get) Token: 0x0600082A RID: 2090 RVA: 0x0005DF28 File Offset: 0x0005C128
		' (set) Token: 0x0600082B RID: 2091 RVA: 0x0000365C File Offset: 0x0000185C
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000321 RID: 801
		' (get) Token: 0x0600082C RID: 2092 RVA: 0x0005DF40 File Offset: 0x0005C140
		' (set) Token: 0x0600082D RID: 2093 RVA: 0x00003667 File Offset: 0x00001867
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000322 RID: 802
		' (get) Token: 0x0600082E RID: 2094 RVA: 0x0005DF58 File Offset: 0x0005C158
		' (set) Token: 0x0600082F RID: 2095 RVA: 0x00003672 File Offset: 0x00001872
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06000830 RID: 2096 RVA: 0x0005DF70 File Offset: 0x0005C170
		Private Sub txtMAHH_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMAHH.[ReadOnly]
				If [readOnly] Then
					Me.txtDONGIAMUA.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAHH_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000831 RID: 2097 RVA: 0x0005E020 File Offset: 0x0005C220
		Private Sub txtMAHH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtDONGIAMUA.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAHH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000832 RID: 2098 RVA: 0x0005E0C4 File Offset: 0x0005C2C4
		Private Sub txtMAHH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMHH Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMHH.Columns("OBJID")
					Me.mclsTbDMHH.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMHH.Rows.Find(Strings.Trim(Me.txtMAHH.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENHH.Text = dataRow("OBJNAME").ToString() + "  " + dataRow("SUBOBJNAME").ToString()
						Me.lblDVT2.Text = dataRow("MADVT").ToString()
					Else
						Me.txtTENHH.Text = ""
						Me.txtDONGIAMUA.Text = "0"
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAHH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000833 RID: 2099 RVA: 0x0005E260 File Offset: 0x0005C460
		Private Sub txtDONGIAMUA_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtDONGIAMUA.[ReadOnly]
				If [readOnly] Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtDONGIAMUA_GotFocus", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000834 RID: 2100 RVA: 0x0005E310 File Offset: 0x0005C510
		Private Sub txtDONGIAMUA_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.btnSave.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtDONGIAMUA_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000835 RID: 2101 RVA: 0x0005E4AC File Offset: 0x0005C6AC
		Private Sub btnSelDMHH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMHH As frmDMHH1 = New frmDMHH1()
				frmDMHH.pBytOpen_From_Menu = 7
				frmDMHH.ShowDialog()
				Dim flag As Boolean = frmDMHH.pStrOBJID.Trim().Length = 0
				If Not flag Then
					Me.txtMAHH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMHH.pStrOBJID, "", False) = 0, Me.txtMAHH.Text, frmDMHH.pStrOBJID))
					Me.txtTENHH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMHH.pStrOBJNAME, "", False) = 0, Me.txtTENHH.Text, frmDMHH.pStrOBJNAME))
					Me.lblDVT2.Text = mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMDVT", "OBJID", frmDMHH.pStrDVT.Trim(), "OBJNAME")
					frmDMHH.Dispose()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelDMHH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000836 RID: 2102 RVA: 0x0005E638 File Offset: 0x0005C838
		Private Sub frmDOCUMENT016_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDOCUMENT016_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000837 RID: 2103 RVA: 0x0005E6E4 File Offset: 0x0005C8E4
		Private Sub frmDOCUMENT16_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4DMHH()
				End If
				Me.txtMAHH_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDOCUMENT16_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000838 RID: 2104 RVA: 0x0005E7B0 File Offset: 0x0005C9B0
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtMAHH.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(36), MsgBoxStyle.Critical, Nothing)
					Me.txtMAHH.Focus()
				Else
					flag = (Operators.CompareString(Strings.Trim(Me.txtMAHH.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENHH.Text), "", False) = 0)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(38), MsgBoxStyle.Critical, Nothing)
						Me.txtMAHH.Focus()
					Else
						flag = (Operators.CompareString(Strings.Trim(Me.txtDONGIAMUA.Text), "", False) <> 0) And Not Versioned.IsNumeric(Strings.Replace(Strings.Trim(Me.txtDONGIAMUA.Text), ",", "", 1, -1, CompareMethod.Binary))
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(33), MsgBoxStyle.Critical, Nothing)
							Me.txtDONGIAMUA.Focus()
						Else
							flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
							If flag Then
								Me.mbytSuccess = Me.gfAddNew()
							Else
								flag = Me.mbytFormStatus = 3
								If flag Then
									Me.mbytSuccess = Me.fModify()
								End If
							End If
							flag = Me.mbytSuccess = 1
							If flag Then
								Me.Close()
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000839 RID: 2105 RVA: 0x0005E9D4 File Offset: 0x0005CBD4
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600083A RID: 2106 RVA: 0x0005EA78 File Offset: 0x0005CC78
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600083B RID: 2107 RVA: 0x0005EB10 File Offset: 0x0005CD10
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtMAHH.[ReadOnly] = True
						Me.txtMAHH.BackColor = Me.txtTENHH.BackColor
						Me.btnSelDMHH.Enabled = False
						Me.txtDONGIAMUA.Focus()
					Case 4
						Me.txtMAHH.[ReadOnly] = True
						Me.txtMAHH.BackColor = Me.txtTENHH.BackColor
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600083C RID: 2108 RVA: 0x0005EC28 File Offset: 0x0005CE28
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnSave.Enabled = False
				Me.btnDelete.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtMAHH.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtMAHH.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600083D RID: 2109 RVA: 0x0005ED74 File Offset: 0x0005CF74
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.KeyPreview = True
				Me.txtMAHH.MaxLength = 15
				Me.txtDONGIAMUA.MaxLength = 40
				Me.txtDONGIAMUA.TextAlign = HorizontalAlignment.Right
				Me.txtTENHH.[ReadOnly] = True
				Me.txtMAHH.CharacterCasing = CharacterCasing.Upper
				Dim flag As Boolean = Conversion.Val(Me.mStrVat) = 0.0
				If flag Then
					Me.mStrVat = "0"
				End If
				Me.btnFilter.Visible = False
				Me.btnFind.Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600083E RID: 2110 RVA: 0x0005EE94 File Offset: 0x0005D094
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblMAHH.Tag = "CB0007"
				End If
				flag = Me.mBytHoan_Tra = 1
				If flag Then
					Me.lblDONGIA.Tag = "CR0045"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				Me.lblMoneyUnit.Text = mdlVariable.gStrMoneyUnit
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600083F RID: 2111 RVA: 0x0005F09C File Offset: 0x0005D29C
		Private Sub dgvMAHH_KeyDown(sender As Object, e As KeyEventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim keyCode As Keys = e.KeyCode
				Dim flag As Boolean = keyCode = Keys.[Return]
				If flag Then
					Dim flag2 As Boolean = Me.mbdsSourceDMHH.Count > 0
					If flag2 Then
						Me.txtMAHH.Text = Conversions.ToString(Me.dgvMAHH("OBJID", Me.mintPos).Value)
						Me.txtTENHH.Text = Me.dgvMAHH("OBJNAME", Me.mintPos).Value.ToString().Trim()
					End If
					Me.dgvMAHH.Visible = False
				Else
					Dim flag3 As Boolean
					If keyCode < Keys.D1 OrElse keyCode > Keys.D9 Then
						If keyCode < Keys.NumPad1 OrElse keyCode > Keys.NumPad9 Then
							flag3 = False
							GoTo IL_00BA
						End If
					End If
					flag3 = True
					IL_00BA:
					Dim flag2 As Boolean = flag3
					If flag2 Then
						Dim num As Integer = e.KeyCode - Keys.D0
						flag2 = num > 9
						If flag2 Then
							num -= 48
						End If
						flag2 = (Me.mbdsSourceDMHH.Count >= num) And (num > 0)
						If flag2 Then
							Me.mintPos = num - 1
							Me.txtMAHH.Text = Conversions.ToString(Me.dgvMAHH("OBJID", Me.mintPos).Value)
							Me.txtTENHH.Text = Me.dgvMAHH("OBJNAME", Me.mintPos).Value.ToString().Trim()
							Me.dgvMAHH.Visible = False
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvMAHH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000840 RID: 2112 RVA: 0x0005F2B4 File Offset: 0x0005D4B4
		Private Sub mbdsSourceDMHH_PositionChanged(sender As Object, e As EventArgs)
			Try
				Me.mintPos = Me.mbdsSourceDMHH.Position
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceDMHH_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000841 RID: 2113 RVA: 0x0005F358 File Offset: 0x0005D558
		Private Sub txtMAHH_KeyDown(sender As Object, e As KeyEventArgs)
			Try
				Dim flag As Boolean = e.KeyCode = Keys.Down
				If flag Then
					Dim b As Byte = Me.f_GetData_4GridMAHH()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAHH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000842 RID: 2114 RVA: 0x0005F3F4 File Offset: 0x0005D5F4
		Private Sub frmDOC016_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 27 AndAlso Me.dgvMAHH.Visible
				If flag Then
					Me.dgvMAHH.Visible = False
					Me.txtMAHH.Focus()
				Else
					flag = Strings.Asc(e.KeyChar) = 27
					If flag Then
						Me.Close()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDOC016_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000843 RID: 2115 RVA: 0x0005F4E0 File Offset: 0x0005D6E0
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMHH.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000844 RID: 2116 RVA: 0x0005F58C File Offset: 0x0005D78C
		Public Function gfAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMABAN"
				array(0).Value = Strings.Trim(Me.mStrMABAN)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHH"
				array(1).Value = Strings.Trim(Me.txtMAHH.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@mnyDONGIA"
				array(2).Value = Conversions.ToDouble("0" + Strings.Replace(Strings.Trim(Me.txtDONGIAMUA.Text), ",", "", 1, -1, CompareMethod.Binary))
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@int_Result"
				array(3).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCTGIAHH_BAN01_INSERT", flag)
				Dim num As Integer = Conversions.ToInteger(array(3).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							b = 1
							Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
							Me.txtMAHH.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000845 RID: 2117 RVA: 0x0005F7E0 File Offset: 0x0005D9E0
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMABAN"
				array(0).Value = Strings.Trim(Me.mStrMABAN)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHH"
				array(1).Value = Strings.Trim(Me.txtMAHH.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@mnyDONGIA"
				array(2).Value = Conversions.ToDouble("0" + Strings.Replace(Strings.Trim(Me.txtDONGIAMUA.Text), ",", "", 1, -1, CompareMethod.Binary))
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@int_Result"
				array(3).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCTGIAHH_BAN01_UPDATE", flag)
				Dim num As Integer = Conversions.ToInteger(array(3).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							b = 1
							Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
							Me.txtMAHH.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000846 RID: 2118 RVA: 0x0005FA3C File Offset: 0x0005DC3C
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMABAN"
				array(0).Value = Strings.Trim(Me.mStrMABAN)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHH"
				array(1).Value = Strings.Trim(Me.txtMAHH.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCTGIAHH_BAN01_DEL", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000847 RID: 2119 RVA: 0x0005FBF4 File Offset: 0x0005DDF4
		Private Function fGetData_4DMHH() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean
				Me.mclsTbDMHH = New clsConnect(mdlVariable.gStrConISDANHMUC, "SP_FRMSAL01_GET_DATA_DMHH", flag)
				Dim flag2 As Boolean = Me.mclsTbDMHH IsNot Nothing
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4DMHH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000848 RID: 2120 RVA: 0x0005FCB4 File Offset: 0x0005DEB4
		Private Function fGetData_4DMDVT() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMDVT = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMDVT")
				Dim flag As Boolean = Me.mclsTbDMHH IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4DMDVT ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000849 RID: 2121 RVA: 0x0005FD70 File Offset: 0x0005DF70
		Private Function f_GetData_4GridMAHH() As Byte
			' The following expression was wrapped in a checked-statement
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = Me.mclsTbDMHH Is Nothing
				If Not flag Then
					Me.dgvMAHH.Visible = True
					Me.dgvMAHH.DataSource = Nothing
					Me.dgvMAHH.ColumnHeadersVisible = True
					Me.dgvMAHH.MultiSelect = False
					Me.dgvMAHH.RowHeadersVisible = False
					Me.dgvMAHH.SelectionMode = DataGridViewSelectionMode.FullRowSelect
					Me.dgvMAHH.StandardTab = False
					Me.dgvMAHH.TabStop = False
					Dim text As String = Me.txtMAHH.Text.Trim()
					text = Conversions.ToString(NewLateBinding.LateGet(Nothing, GetType(Strings), "UCase", New Object() { RuntimeHelpers.GetObjectValue(Interaction.IIf(Operators.CompareString(Strings.Mid(text, 1, 1), "*", False) = 0, Strings.Mid(text, 2), text)) }, Nothing, Nothing, Nothing))
					Dim dataTable As DataTable = New DataTable()
					dataTable.Columns.Add("STT")
					dataTable.Columns.Add("OBJID")
					dataTable.Columns.Add("OBJNAME")
					dataTable.Columns.Add("PRICE1")
					dataTable.Columns.Add("MADVT")
					flag = Me.mclsTbDMHH.Rows.Count > 0
					Dim flag3 As Boolean
					If flag Then
						Dim num As Integer = 0
						Dim num2 As Integer = Me.mclsTbDMHH.Rows.Count - 1
						Dim num3 As Integer = num
						While True
							Dim num4 As Integer = num3
							Dim num5 As Integer = num2
							If num4 > num5 Then
								Exit For
							End If
							Dim flag2 As Boolean
							If Operators.CompareString(Strings.Mid(Me.txtMAHH.Text.Trim(), 1, 1), "*", False) = 0 Then
								Dim obj As Object = Nothing
								Dim typeFromHandle As Type = GetType(Strings)
								Dim text2 As String = "UCase"
								Dim array As Object() = New Object(0) {}
								Dim array2 As Object() = array
								Dim num6 As Integer = 0
								Dim dataRow As DataRow = Me.mclsTbDMHH.Rows(num3)
								Dim dataRow2 As DataRow = dataRow
								Dim text3 As String = "OBJID"
								array2(num6) = RuntimeHelpers.GetObjectValue(dataRow2(text3))
								Dim array3 As Object() = array
								Dim array4 As Object() = array3
								Dim array5 As String() = Nothing
								Dim array6 As Type() = Nothing
								Dim array7 As Boolean() = New Boolean() { True }
								Dim obj2 As Object = NewLateBinding.LateGet(obj, typeFromHandle, text2, array4, array5, array6, array7)
								If array7(0) Then
									dataRow(text3) = RuntimeHelpers.GetObjectValue(array3(0))
								End If
								If Strings.InStr(Conversions.ToString(obj2), text, CompareMethod.Binary) <= 0 Then
									Dim obj3 As Object = Nothing
									Dim typeFromHandle2 As Type = GetType(Strings)
									Dim text4 As String = "UCase"
									Dim array8 As Object() = New Object(0) {}
									Dim array9 As Object() = array8
									Dim num7 As Integer = 0
									Dim dataRow3 As DataRow = Me.mclsTbDMHH.Rows(num3)
									Dim dataRow4 As DataRow = dataRow3
									Dim text5 As String = "OBJNAME"
									array9(num7) = RuntimeHelpers.GetObjectValue(dataRow4(text5))
									Dim array10 As Object() = array8
									Dim array11 As Object() = array10
									Dim array12 As String() = Nothing
									Dim array13 As Type() = Nothing
									Dim array14 As Boolean() = New Boolean() { True }
									Dim obj4 As Object = NewLateBinding.LateGet(obj3, typeFromHandle2, text4, array11, array12, array13, array14)
									If array14(0) Then
										dataRow3(text5) = RuntimeHelpers.GetObjectValue(array10(0))
									End If
									If Strings.InStr(mdlPrintReceipt.gfRemove_signVie(Conversions.ToString(obj4)), text, CompareMethod.Binary) <= 0 Then
										Dim obj5 As Object = Nothing
										Dim typeFromHandle3 As Type = GetType(Strings)
										Dim text6 As String = "UCase"
										Dim array15 As Object() = New Object(0) {}
										Dim array16 As Object() = array15
										Dim num8 As Integer = 0
										Dim dataRow5 As DataRow = Me.mclsTbDMHH.Rows(num3)
										Dim dataRow6 As DataRow = dataRow5
										Dim text7 As String = "OBJNAME"
										array16(num8) = RuntimeHelpers.GetObjectValue(dataRow6(text7))
										Dim array17 As Object() = array15
										Dim array18 As Object() = array17
										Dim array19 As String() = Nothing
										Dim array20 As Type() = Nothing
										Dim array21 As Boolean() = New Boolean() { True }
										Dim obj6 As Object = NewLateBinding.LateGet(obj5, typeFromHandle3, text6, array18, array19, array20, array21)
										If array21(0) Then
											dataRow5(text7) = RuntimeHelpers.GetObjectValue(array17(0))
										End If
										If Strings.InStr(Conversions.ToString(obj6), text, CompareMethod.Binary) <= 0 Then
											GoTo IL_0349
										End If
									End If
								End If
								IL_034C:
								flag2 = True
								GoTo IL_034D
								GoTo IL_034C
							End If
							GoTo IL_0349
							IL_034D:
							flag3 = flag2
							If flag3 Then
								dataTable.Rows.Add(New Object(-1) {})
								dataTable.Rows(dataTable.Rows.Count - 1)("STT") = dataTable.Rows.Count
								dataTable.Rows(dataTable.Rows.Count - 1)("OBJID") = Operators.ConcatenateObject(Me.mclsTbDMHH.Rows(num3)("OBJID"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("OBJNAME") = Operators.ConcatenateObject(Me.mclsTbDMHH.Rows(num3)("OBJNAME"), "  " + Me.mclsTbDMHH.Rows(num3)("SUBOBJNAME").ToString().Trim())
								dataTable.Rows(dataTable.Rows.Count - 1)("PRICE1") = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.mclsTbDMHH.Rows(num3)("PRICE1")), CShort(mdlVariable.gbytDECNUM), ",")
								dataTable.Rows(dataTable.Rows.Count - 1)("MADVT") = Operators.ConcatenateObject(Me.mclsTbDMHH.Rows(num3)("MADVT"), "")
							End If
							Dim flag4 As Boolean
							If Operators.CompareString(Strings.Mid(Me.txtMAHH.Text.Trim(), 1, 1), "*", False) <> 0 Then
								Dim obj7 As Object = Nothing
								Dim typeFromHandle4 As Type = GetType(Strings)
								Dim text8 As String = "UCase"
								Dim array17 As Object() = New Object(0) {}
								Dim array22 As Object() = array17
								Dim num9 As Integer = 0
								Dim dataRow5 As DataRow = Me.mclsTbDMHH.Rows(num3)
								Dim dataRow7 As DataRow = dataRow5
								Dim text7 As String = "OBJID"
								array22(num9) = RuntimeHelpers.GetObjectValue(dataRow7(text7))
								Dim array15 As Object() = array17
								Dim array23 As Object() = array15
								Dim array24 As String() = Nothing
								Dim array25 As Type() = Nothing
								Dim array21 As Boolean() = New Boolean() { True }
								Dim obj8 As Object = NewLateBinding.LateGet(obj7, typeFromHandle4, text8, array23, array24, array25, array21)
								If array21(0) Then
									dataRow5(text7) = RuntimeHelpers.GetObjectValue(array15(0))
								End If
								If Operators.CompareString(Strings.Left(Conversions.ToString(obj8), text.Length), text, False) <> 0 Then
									Dim obj9 As Object = Nothing
									Dim typeFromHandle5 As Type = GetType(Strings)
									Dim text9 As String = "UCase"
									Dim array10 As Object() = New Object(0) {}
									Dim array26 As Object() = array10
									Dim num10 As Integer = 0
									Dim dataRow3 As DataRow = Me.mclsTbDMHH.Rows(num3)
									Dim dataRow8 As DataRow = dataRow3
									Dim text5 As String = "OBJNAME"
									array26(num10) = RuntimeHelpers.GetObjectValue(dataRow8(text5))
									Dim array8 As Object() = array10
									Dim array27 As Object() = array8
									Dim array28 As String() = Nothing
									Dim array29 As Type() = Nothing
									Dim array14 As Boolean() = New Boolean() { True }
									Dim obj10 As Object = NewLateBinding.LateGet(obj9, typeFromHandle5, text9, array27, array28, array29, array14)
									If array14(0) Then
										dataRow3(text5) = RuntimeHelpers.GetObjectValue(array8(0))
									End If
									If Operators.CompareString(Strings.Left(mdlPrintReceipt.gfRemove_signVie(Conversions.ToString(obj10)), text.Length), text, False) <> 0 Then
										Dim obj11 As Object = Nothing
										Dim typeFromHandle6 As Type = GetType(Strings)
										Dim text10 As String = "UCase"
										Dim array3 As Object() = New Object(0) {}
										Dim array30 As Object() = array3
										Dim num11 As Integer = 0
										Dim dataRow As DataRow = Me.mclsTbDMHH.Rows(num3)
										Dim dataRow9 As DataRow = dataRow
										Dim text3 As String = "OBJNAME"
										array30(num11) = RuntimeHelpers.GetObjectValue(dataRow9(text3))
										Dim array As Object() = array3
										Dim array31 As Object() = array
										Dim array32 As String() = Nothing
										Dim array33 As Type() = Nothing
										Dim array7 As Boolean() = New Boolean() { True }
										Dim obj12 As Object = NewLateBinding.LateGet(obj11, typeFromHandle6, text10, array31, array32, array33, array7)
										If array7(0) Then
											dataRow(text3) = RuntimeHelpers.GetObjectValue(array(0))
										End If
										If Operators.CompareString(Strings.Left(Conversions.ToString(obj12), text.Length), text, False) <> 0 Then
											GoTo IL_06E1
										End If
									End If
								End If
								IL_06E4:
								flag4 = True
								GoTo IL_06E5
								GoTo IL_06E4
							End If
							GoTo IL_06E1
							IL_06E5:
							flag3 = flag4
							If flag3 Then
								dataTable.Rows.Add(New Object(-1) {})
								dataTable.Rows(dataTable.Rows.Count - 1)("STT") = dataTable.Rows.Count
								dataTable.Rows(dataTable.Rows.Count - 1)("OBJID") = Operators.ConcatenateObject(Me.mclsTbDMHH.Rows(num3)("OBJID"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("OBJNAME") = Operators.ConcatenateObject(Me.mclsTbDMHH.Rows(num3)("OBJNAME"), "  " + Me.mclsTbDMHH.Rows(num3)("SUBOBJNAME").ToString().Trim())
								dataTable.Rows(dataTable.Rows.Count - 1)("PRICE1") = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.mclsTbDMHH.Rows(num3)("PRICE1")), CShort(mdlVariable.gbytDECNUM), ",")
								dataTable.Rows(dataTable.Rows.Count - 1)("MADVT") = Operators.ConcatenateObject(Me.mclsTbDMHH.Rows(num3)("MADVT"), "")
							End If
							num3 += 1
							Continue For
							IL_06E1:
							flag4 = False
							GoTo IL_06E5
							IL_0349:
							flag2 = False
							GoTo IL_034D
						End While
					End If
					Me.mbdsSourceDMHH.DataSource = dataTable
					Me.dgvMAHH.DataSource = Me.mbdsSourceDMHH
					Me.dgvMAHH.Columns("OBJID").Visible = False
					Me.dgvMAHH.Columns("STT").Width = 35
					Me.dgvMAHH.Columns("STT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(41))
					Me.dgvMAHH.Columns("OBJNAME").Width = Me.dgvMAHH.Width - 140
					Me.dgvMAHH.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
					Me.dgvMAHH.Columns("PRICE1").Width = 85
					Me.dgvMAHH.Columns("PRICE1").HeaderText = Strings.Trim(Me.mArrStrFrmMess(42))
					Me.dgvMAHH.Columns("MADVT").Visible = False
					flag3 = dataTable.Rows.Count > 0
					If flag3 Then
						Me.dgvMAHH.Focus()
					End If
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - f_GetData_4GridMAHH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x04000377 RID: 887
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000379 RID: 889
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x0400037A RID: 890
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x0400037B RID: 891
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x0400037C RID: 892
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x0400037D RID: 893
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x0400037E RID: 894
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x0400037F RID: 895
		<AccessedThroughProperty("lblMAHH")>
		Private _lblMAHH As Label

		' Token: 0x04000380 RID: 896
		<AccessedThroughProperty("lblWORKDATE")>
		Private _lblWORKDATE As Label

		' Token: 0x04000381 RID: 897
		<AccessedThroughProperty("txtDONGIAMUA")>
		Private _txtDONGIAMUA As TextBox

		' Token: 0x04000382 RID: 898
		<AccessedThroughProperty("lblMoneyUnit")>
		Private _lblMoneyUnit As Label

		' Token: 0x04000383 RID: 899
		<AccessedThroughProperty("txtTENHH")>
		Private _txtTENHH As TextBox

		' Token: 0x04000384 RID: 900
		<AccessedThroughProperty("btnSelDMHH")>
		Private _btnSelDMHH As Button

		' Token: 0x04000385 RID: 901
		<AccessedThroughProperty("txtMAHH")>
		Private _txtMAHH As TextBox

		' Token: 0x04000386 RID: 902
		<AccessedThroughProperty("lblDONGIA")>
		Private _lblDONGIA As Label

		' Token: 0x04000387 RID: 903
		<AccessedThroughProperty("lblMark")>
		Private _lblMark As Label

		' Token: 0x04000388 RID: 904
		<AccessedThroughProperty("lblDVT2")>
		Private _lblDVT2 As Label

		' Token: 0x04000389 RID: 905
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x0400038A RID: 906
		<AccessedThroughProperty("dgvMAHH")>
		Private _dgvMAHH As DataGridView

		' Token: 0x0400038B RID: 907
		Private mArrStrFrmMess As String()

		' Token: 0x0400038C RID: 908
		Private mbytFormStatus As Byte

		' Token: 0x0400038D RID: 909
		Private mbytSuccess As Byte

		' Token: 0x0400038E RID: 910
		Private mStrFilter As String

		' Token: 0x0400038F RID: 911
		Private mStrDOCID As String

		' Token: 0x04000390 RID: 912
		Private mStrMABAN As String

		' Token: 0x04000391 RID: 913
		Private mStrDETNUM As String

		' Token: 0x04000392 RID: 914
		Private mStrNGAYHETHAN As String

		' Token: 0x04000393 RID: 915
		Private mBytHoan_Tra As Byte

		' Token: 0x04000394 RID: 916
		Private mStrYYYYMM As String

		' Token: 0x04000395 RID: 917
		Private mStrXSOCT As String

		' Token: 0x04000396 RID: 918
		Private mStrVat As String

		' Token: 0x04000397 RID: 919
		Private mclsTbDMHH As clsConnect

		' Token: 0x04000398 RID: 920
		Private mclsTbDMDVT As clsConnect

		' Token: 0x04000399 RID: 921
		Private mclsTbDMSD As clsConnect

		' Token: 0x0400039A RID: 922
		<AccessedThroughProperty("mbdsSourceDMHH")>
		Private _mbdsSourceDMHH As BindingSource

		' Token: 0x0400039B RID: 923
		Private mintPos As Integer

		' Token: 0x0400039C RID: 924
		Private marrDblPrice As Double()

		' Token: 0x0400039D RID: 925
		Private mstrMADVT_HH As String

		' Token: 0x0400039E RID: 926
		Private mclsTbDMDM As clsConnect

		' Token: 0x0400039F RID: 927
		Private mStrStartDate As String

		' Token: 0x040003A0 RID: 928
		Private mStrLockDate As String

		' Token: 0x040003A1 RID: 929
		Private mStrMaKH As String

		' Token: 0x040003A2 RID: 930
		Private mIntSTT As Integer

		' Token: 0x040003A3 RID: 931
		Private mdtNgayGio As DateTime
	End Class
End Namespace
