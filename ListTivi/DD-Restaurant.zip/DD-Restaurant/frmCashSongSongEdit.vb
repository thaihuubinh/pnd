﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000020 RID: 32
	<DesignerGenerated()>
	Public Partial Class frmCashSongSongEdit
		Inherits Form

		' Token: 0x06000570 RID: 1392 RVA: 0x00043090 File Offset: 0x00041290
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmCashSongSongEdit_Load
			frmCashSongSongEdit.__ENCList.Add(New WeakReference(Me))
			Me.mstrSoCT = ""
			Me.mstrDateTime = ""
			Me.mstrMaDV = ""
			Me.mstrTenDV = ""
			Me.mstrMaDVT = ""
			Me.mstrMaHTTT99 = ""
			Me.mstrMaHTTT_1 = ""
			Me.mdblHTTT_1 = 0.0
			Me.mstrMaHTTT_2 = ""
			Me.mdblHTTT_2 = 0.0
			Me.mstrMaHTTT_3 = ""
			Me.mdblHTTT_3 = 0.0
			Me.mstrMaHTTT_4 = ""
			Me.mdblHTTT_4 = 0.0
			Me.mstrMaHTTT_5 = ""
			Me.mdblHTTT_5 = 0.0
			Me.mstrMaHTTT_6 = ""
			Me.mdblHTTT_6 = 0.0
			Me.mstrMaHTTT_7 = ""
			Me.mdblHTTT_7 = 0.0
			Me.mstrMaHTTT_8 = ""
			Me.mdblHTTT_8 = 0.0
			Me.mstrMaHTTT_9 = ""
			Me.mdblHTTT_9 = 0.0
			Me.mstrMaHTTT_10 = ""
			Me.mdblHTTT_10 = 0.0
			Me.mstrMaHTTT_11 = ""
			Me.mdblHTTT_11 = 0.0
			Me.mstrMaHTTT_12 = ""
			Me.mdblHTTT_12 = 0.0
			Me.mstrMaHTTT_13 = ""
			Me.mdblHTTT_13 = 0.0
			Me.mstrMaHTTT_14 = ""
			Me.mdblHTTT_14 = 0.0
			Me.mstrMaHTTT_JustOne = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000212 RID: 530
		' (get) Token: 0x06000573 RID: 1395 RVA: 0x000457C8 File Offset: 0x000439C8
		' (set) Token: 0x06000574 RID: 1396 RVA: 0x000457E0 File Offset: 0x000439E0
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000213 RID: 531
		' (get) Token: 0x06000575 RID: 1397 RVA: 0x0004584C File Offset: 0x00043A4C
		' (set) Token: 0x06000576 RID: 1398 RVA: 0x00002EB1 File Offset: 0x000010B1
		Friend Overridable Property TableLayoutPanel5 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel5 = value
			End Set
		End Property

		' Token: 0x17000214 RID: 532
		' (get) Token: 0x06000577 RID: 1399 RVA: 0x00045864 File Offset: 0x00043A64
		' (set) Token: 0x06000578 RID: 1400 RVA: 0x0004587C File Offset: 0x00043A7C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000215 RID: 533
		' (get) Token: 0x06000579 RID: 1401 RVA: 0x000458E8 File Offset: 0x00043AE8
		' (set) Token: 0x0600057A RID: 1402 RVA: 0x00002EBB File Offset: 0x000010BB
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000216 RID: 534
		' (get) Token: 0x0600057B RID: 1403 RVA: 0x00045900 File Offset: 0x00043B00
		' (set) Token: 0x0600057C RID: 1404 RVA: 0x00002EC5 File Offset: 0x000010C5
		Friend Overridable Property TableLayoutPanel3 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel3 = value
			End Set
		End Property

		' Token: 0x17000217 RID: 535
		' (get) Token: 0x0600057D RID: 1405 RVA: 0x00045918 File Offset: 0x00043B18
		' (set) Token: 0x0600057E RID: 1406 RVA: 0x00002ECF File Offset: 0x000010CF
		Friend Overridable Property TableLayoutPanel2 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel2 = value
			End Set
		End Property

		' Token: 0x17000218 RID: 536
		' (get) Token: 0x0600057F RID: 1407 RVA: 0x00045930 File Offset: 0x00043B30
		' (set) Token: 0x06000580 RID: 1408 RVA: 0x00045948 File Offset: 0x00043B48
		Friend Overridable Property lbl8 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl8 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl8.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl8 = value
				flag = Me._lbl8 IsNot Nothing
				If flag Then
					AddHandler Me._lbl8.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x17000219 RID: 537
		' (get) Token: 0x06000581 RID: 1409 RVA: 0x000459B4 File Offset: 0x00043BB4
		' (set) Token: 0x06000582 RID: 1410 RVA: 0x000459CC File Offset: 0x00043BCC
		Friend Overridable Property lbl9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl9 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl9.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl9 = value
				flag = Me._lbl9 IsNot Nothing
				If flag Then
					AddHandler Me._lbl9.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x1700021A RID: 538
		' (get) Token: 0x06000583 RID: 1411 RVA: 0x00045A38 File Offset: 0x00043C38
		' (set) Token: 0x06000584 RID: 1412 RVA: 0x00045A50 File Offset: 0x00043C50
		Friend Overridable Property lbl13 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl13
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl13 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl13.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl13 = value
				flag = Me._lbl13 IsNot Nothing
				If flag Then
					AddHandler Me._lbl13.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x1700021B RID: 539
		' (get) Token: 0x06000585 RID: 1413 RVA: 0x00045ABC File Offset: 0x00043CBC
		' (set) Token: 0x06000586 RID: 1414 RVA: 0x00045AD4 File Offset: 0x00043CD4
		Friend Overridable Property lbl11 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl11
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl11 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl11.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl11 = value
				flag = Me._lbl11 IsNot Nothing
				If flag Then
					AddHandler Me._lbl11.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x1700021C RID: 540
		' (get) Token: 0x06000587 RID: 1415 RVA: 0x00045B40 File Offset: 0x00043D40
		' (set) Token: 0x06000588 RID: 1416 RVA: 0x00045B58 File Offset: 0x00043D58
		Friend Overridable Property lbl10 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl10 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl10.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl10 = value
				flag = Me._lbl10 IsNot Nothing
				If flag Then
					AddHandler Me._lbl10.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x1700021D RID: 541
		' (get) Token: 0x06000589 RID: 1417 RVA: 0x00045BC4 File Offset: 0x00043DC4
		' (set) Token: 0x0600058A RID: 1418 RVA: 0x00045BDC File Offset: 0x00043DDC
		Friend Overridable Property lbl12 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl12
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl12 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl12.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl12 = value
				flag = Me._lbl12 IsNot Nothing
				If flag Then
					AddHandler Me._lbl12.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x1700021E RID: 542
		' (get) Token: 0x0600058B RID: 1419 RVA: 0x00045C48 File Offset: 0x00043E48
		' (set) Token: 0x0600058C RID: 1420 RVA: 0x00045C60 File Offset: 0x00043E60
		Friend Overridable Property lbl14 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl14
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl14 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl14.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl14 = value
				flag = Me._lbl14 IsNot Nothing
				If flag Then
					AddHandler Me._lbl14.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x1700021F RID: 543
		' (get) Token: 0x0600058D RID: 1421 RVA: 0x00045CCC File Offset: 0x00043ECC
		' (set) Token: 0x0600058E RID: 1422 RVA: 0x00045CE4 File Offset: 0x00043EE4
		Friend Overridable Property lbl1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl1 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl1.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl1 = value
				flag = Me._lbl1 IsNot Nothing
				If flag Then
					AddHandler Me._lbl1.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x17000220 RID: 544
		' (get) Token: 0x0600058F RID: 1423 RVA: 0x00045D50 File Offset: 0x00043F50
		' (set) Token: 0x06000590 RID: 1424 RVA: 0x00045D68 File Offset: 0x00043F68
		Friend Overridable Property lbl2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl2 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl2.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl2 = value
				flag = Me._lbl2 IsNot Nothing
				If flag Then
					AddHandler Me._lbl2.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x17000221 RID: 545
		' (get) Token: 0x06000591 RID: 1425 RVA: 0x00045DD4 File Offset: 0x00043FD4
		' (set) Token: 0x06000592 RID: 1426 RVA: 0x00045DEC File Offset: 0x00043FEC
		Friend Overridable Property lbl4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl4 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl4.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl4 = value
				flag = Me._lbl4 IsNot Nothing
				If flag Then
					AddHandler Me._lbl4.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x17000222 RID: 546
		' (get) Token: 0x06000593 RID: 1427 RVA: 0x00045E58 File Offset: 0x00044058
		' (set) Token: 0x06000594 RID: 1428 RVA: 0x00045E70 File Offset: 0x00044070
		Friend Overridable Property lbl6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl6 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl6.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl6 = value
				flag = Me._lbl6 IsNot Nothing
				If flag Then
					AddHandler Me._lbl6.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x17000223 RID: 547
		' (get) Token: 0x06000595 RID: 1429 RVA: 0x00045EDC File Offset: 0x000440DC
		' (set) Token: 0x06000596 RID: 1430 RVA: 0x00045EF4 File Offset: 0x000440F4
		Friend Overridable Property lbl3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl3 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl3.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl3 = value
				flag = Me._lbl3 IsNot Nothing
				If flag Then
					AddHandler Me._lbl3.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x17000224 RID: 548
		' (get) Token: 0x06000597 RID: 1431 RVA: 0x00045F60 File Offset: 0x00044160
		' (set) Token: 0x06000598 RID: 1432 RVA: 0x00045F78 File Offset: 0x00044178
		Friend Overridable Property lbl5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl5 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl5.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl5 = value
				flag = Me._lbl5 IsNot Nothing
				If flag Then
					AddHandler Me._lbl5.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x17000225 RID: 549
		' (get) Token: 0x06000599 RID: 1433 RVA: 0x00045FE4 File Offset: 0x000441E4
		' (set) Token: 0x0600059A RID: 1434 RVA: 0x00045FFC File Offset: 0x000441FC
		Friend Overridable Property lbl7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl7 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl7.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl7 = value
				flag = Me._lbl7 IsNot Nothing
				If flag Then
					AddHandler Me._lbl7.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x17000226 RID: 550
		' (get) Token: 0x0600059B RID: 1435 RVA: 0x00046068 File Offset: 0x00044268
		' (set) Token: 0x0600059C RID: 1436 RVA: 0x00002ED9 File Offset: 0x000010D9
		Friend Overridable Property btn1 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btn1 = value
			End Set
		End Property

		' Token: 0x17000227 RID: 551
		' (get) Token: 0x0600059D RID: 1437 RVA: 0x00046080 File Offset: 0x00044280
		' (set) Token: 0x0600059E RID: 1438 RVA: 0x00046098 File Offset: 0x00044298
		Friend Overridable Property btn8 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn8 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn8.Click, AddressOf Me.btn2_Click
				End If
				Me._btn8 = value
				flag = Me._btn8 IsNot Nothing
				If flag Then
					AddHandler Me._btn8.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000228 RID: 552
		' (get) Token: 0x0600059F RID: 1439 RVA: 0x00046104 File Offset: 0x00044304
		' (set) Token: 0x060005A0 RID: 1440 RVA: 0x0004611C File Offset: 0x0004431C
		Friend Overridable Property btn9 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn9 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn9.Click, AddressOf Me.btn2_Click
				End If
				Me._btn9 = value
				flag = Me._btn9 IsNot Nothing
				If flag Then
					AddHandler Me._btn9.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000229 RID: 553
		' (get) Token: 0x060005A1 RID: 1441 RVA: 0x00046188 File Offset: 0x00044388
		' (set) Token: 0x060005A2 RID: 1442 RVA: 0x000461A0 File Offset: 0x000443A0
		Friend Overridable Property btn10 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn10 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn10.Click, AddressOf Me.btn2_Click
				End If
				Me._btn10 = value
				flag = Me._btn10 IsNot Nothing
				If flag Then
					AddHandler Me._btn10.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x1700022A RID: 554
		' (get) Token: 0x060005A3 RID: 1443 RVA: 0x0004620C File Offset: 0x0004440C
		' (set) Token: 0x060005A4 RID: 1444 RVA: 0x00046224 File Offset: 0x00044424
		Friend Overridable Property btn11 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn11
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn11 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn11.Click, AddressOf Me.btn2_Click
				End If
				Me._btn11 = value
				flag = Me._btn11 IsNot Nothing
				If flag Then
					AddHandler Me._btn11.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x1700022B RID: 555
		' (get) Token: 0x060005A5 RID: 1445 RVA: 0x00046290 File Offset: 0x00044490
		' (set) Token: 0x060005A6 RID: 1446 RVA: 0x000462A8 File Offset: 0x000444A8
		Friend Overridable Property btn12 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn12
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn12 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn12.Click, AddressOf Me.btn2_Click
				End If
				Me._btn12 = value
				flag = Me._btn12 IsNot Nothing
				If flag Then
					AddHandler Me._btn12.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x1700022C RID: 556
		' (get) Token: 0x060005A7 RID: 1447 RVA: 0x00046314 File Offset: 0x00044514
		' (set) Token: 0x060005A8 RID: 1448 RVA: 0x0004632C File Offset: 0x0004452C
		Friend Overridable Property btn13 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn13
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn13 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn13.Click, AddressOf Me.btn2_Click
				End If
				Me._btn13 = value
				flag = Me._btn13 IsNot Nothing
				If flag Then
					AddHandler Me._btn13.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x1700022D RID: 557
		' (get) Token: 0x060005A9 RID: 1449 RVA: 0x00046398 File Offset: 0x00044598
		' (set) Token: 0x060005AA RID: 1450 RVA: 0x000463B0 File Offset: 0x000445B0
		Friend Overridable Property btn14 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn14
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn14 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn14.Click, AddressOf Me.btn2_Click
				End If
				Me._btn14 = value
				flag = Me._btn14 IsNot Nothing
				If flag Then
					AddHandler Me._btn14.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x1700022E RID: 558
		' (get) Token: 0x060005AB RID: 1451 RVA: 0x0004641C File Offset: 0x0004461C
		' (set) Token: 0x060005AC RID: 1452 RVA: 0x00046434 File Offset: 0x00044634
		Friend Overridable Property btn2 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn2 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn2.Click, AddressOf Me.btn2_Click
				End If
				Me._btn2 = value
				flag = Me._btn2 IsNot Nothing
				If flag Then
					AddHandler Me._btn2.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x1700022F RID: 559
		' (get) Token: 0x060005AD RID: 1453 RVA: 0x000464A0 File Offset: 0x000446A0
		' (set) Token: 0x060005AE RID: 1454 RVA: 0x000464B8 File Offset: 0x000446B8
		Friend Overridable Property btn3 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn3 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn3.Click, AddressOf Me.btn2_Click
				End If
				Me._btn3 = value
				flag = Me._btn3 IsNot Nothing
				If flag Then
					AddHandler Me._btn3.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000230 RID: 560
		' (get) Token: 0x060005AF RID: 1455 RVA: 0x00046524 File Offset: 0x00044724
		' (set) Token: 0x060005B0 RID: 1456 RVA: 0x0004653C File Offset: 0x0004473C
		Friend Overridable Property btn4 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn4 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn4.Click, AddressOf Me.btn2_Click
				End If
				Me._btn4 = value
				flag = Me._btn4 IsNot Nothing
				If flag Then
					AddHandler Me._btn4.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000231 RID: 561
		' (get) Token: 0x060005B1 RID: 1457 RVA: 0x000465A8 File Offset: 0x000447A8
		' (set) Token: 0x060005B2 RID: 1458 RVA: 0x000465C0 File Offset: 0x000447C0
		Friend Overridable Property btn5 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn5 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn5.Click, AddressOf Me.btn2_Click
				End If
				Me._btn5 = value
				flag = Me._btn5 IsNot Nothing
				If flag Then
					AddHandler Me._btn5.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000232 RID: 562
		' (get) Token: 0x060005B3 RID: 1459 RVA: 0x0004662C File Offset: 0x0004482C
		' (set) Token: 0x060005B4 RID: 1460 RVA: 0x00046644 File Offset: 0x00044844
		Friend Overridable Property btn6 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn6 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn6.Click, AddressOf Me.btn2_Click
				End If
				Me._btn6 = value
				flag = Me._btn6 IsNot Nothing
				If flag Then
					AddHandler Me._btn6.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000233 RID: 563
		' (get) Token: 0x060005B5 RID: 1461 RVA: 0x000466B0 File Offset: 0x000448B0
		' (set) Token: 0x060005B6 RID: 1462 RVA: 0x000466C8 File Offset: 0x000448C8
		Friend Overridable Property btn7 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn7 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn7.Click, AddressOf Me.btn2_Click
				End If
				Me._btn7 = value
				flag = Me._btn7 IsNot Nothing
				If flag Then
					AddHandler Me._btn7.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x060005B7 RID: 1463 RVA: 0x00046734 File Offset: 0x00044934
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(1))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(2), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060005B8 RID: 1464 RVA: 0x00046840 File Offset: 0x00044A40
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(2), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x17000234 RID: 564
		' (get) Token: 0x060005B9 RID: 1465 RVA: 0x000468E4 File Offset: 0x00044AE4
		' (set) Token: 0x060005BA RID: 1466 RVA: 0x00002EE3 File Offset: 0x000010E3
		Public Property pstrMaHTTT_JustOne As String
			Get
				Return Me.mstrMaHTTT_JustOne
			End Get
			Set(value As String)
				Me.mstrMaHTTT_JustOne = value
			End Set
		End Property

		' Token: 0x17000235 RID: 565
		' (get) Token: 0x060005BB RID: 1467 RVA: 0x000468FC File Offset: 0x00044AFC
		' (set) Token: 0x060005BC RID: 1468 RVA: 0x00002EEE File Offset: 0x000010EE
		Public Property pstrMaHTTT_1 As String
			Get
				Return Me.mstrMaHTTT_1
			End Get
			Set(value As String)
				Me.mstrMaHTTT_1 = value
			End Set
		End Property

		' Token: 0x17000236 RID: 566
		' (get) Token: 0x060005BD RID: 1469 RVA: 0x00046914 File Offset: 0x00044B14
		' (set) Token: 0x060005BE RID: 1470 RVA: 0x00002EF9 File Offset: 0x000010F9
		Public Property pstrMaHTTT_2 As String
			Get
				Return Me.mstrMaHTTT_2
			End Get
			Set(value As String)
				Me.mstrMaHTTT_2 = value
			End Set
		End Property

		' Token: 0x17000237 RID: 567
		' (get) Token: 0x060005BF RID: 1471 RVA: 0x0004692C File Offset: 0x00044B2C
		' (set) Token: 0x060005C0 RID: 1472 RVA: 0x00002F04 File Offset: 0x00001104
		Public Property pstrMaHTTT_3 As String
			Get
				Return Me.mstrMaHTTT_3
			End Get
			Set(value As String)
				Me.mstrMaHTTT_3 = value
			End Set
		End Property

		' Token: 0x17000238 RID: 568
		' (get) Token: 0x060005C1 RID: 1473 RVA: 0x00046944 File Offset: 0x00044B44
		' (set) Token: 0x060005C2 RID: 1474 RVA: 0x00002F0F File Offset: 0x0000110F
		Public Property pstrMaHTTT_4 As String
			Get
				Return Me.mstrMaHTTT_4
			End Get
			Set(value As String)
				Me.mstrMaHTTT_4 = value
			End Set
		End Property

		' Token: 0x17000239 RID: 569
		' (get) Token: 0x060005C3 RID: 1475 RVA: 0x0004695C File Offset: 0x00044B5C
		' (set) Token: 0x060005C4 RID: 1476 RVA: 0x00002F1A File Offset: 0x0000111A
		Public Property pstrMaHTTT_5 As String
			Get
				Return Me.mstrMaHTTT_5
			End Get
			Set(value As String)
				Me.mstrMaHTTT_5 = value
			End Set
		End Property

		' Token: 0x1700023A RID: 570
		' (get) Token: 0x060005C5 RID: 1477 RVA: 0x00046974 File Offset: 0x00044B74
		' (set) Token: 0x060005C6 RID: 1478 RVA: 0x00002F25 File Offset: 0x00001125
		Public Property pstrMaHTTT_6 As String
			Get
				Return Me.mstrMaHTTT_6
			End Get
			Set(value As String)
				Me.mstrMaHTTT_6 = value
			End Set
		End Property

		' Token: 0x1700023B RID: 571
		' (get) Token: 0x060005C7 RID: 1479 RVA: 0x0004698C File Offset: 0x00044B8C
		' (set) Token: 0x060005C8 RID: 1480 RVA: 0x00002F30 File Offset: 0x00001130
		Public Property pstrMaHTTT_7 As String
			Get
				Return Me.mstrMaHTTT_7
			End Get
			Set(value As String)
				Me.mstrMaHTTT_7 = value
			End Set
		End Property

		' Token: 0x1700023C RID: 572
		' (get) Token: 0x060005C9 RID: 1481 RVA: 0x000469A4 File Offset: 0x00044BA4
		' (set) Token: 0x060005CA RID: 1482 RVA: 0x00002F3B File Offset: 0x0000113B
		Public Property pstrMaHTTT_8 As String
			Get
				Return Me.mstrMaHTTT_8
			End Get
			Set(value As String)
				Me.mstrMaHTTT_8 = value
			End Set
		End Property

		' Token: 0x1700023D RID: 573
		' (get) Token: 0x060005CB RID: 1483 RVA: 0x000469BC File Offset: 0x00044BBC
		' (set) Token: 0x060005CC RID: 1484 RVA: 0x00002F46 File Offset: 0x00001146
		Public Property pstrMaHTTT_9 As String
			Get
				Return Me.mstrMaHTTT_9
			End Get
			Set(value As String)
				Me.mstrMaHTTT_9 = value
			End Set
		End Property

		' Token: 0x1700023E RID: 574
		' (get) Token: 0x060005CD RID: 1485 RVA: 0x000469D4 File Offset: 0x00044BD4
		' (set) Token: 0x060005CE RID: 1486 RVA: 0x00002F51 File Offset: 0x00001151
		Public Property pstrMaHTTT_10 As String
			Get
				Return Me.mstrMaHTTT_10
			End Get
			Set(value As String)
				Me.mstrMaHTTT_10 = value
			End Set
		End Property

		' Token: 0x1700023F RID: 575
		' (get) Token: 0x060005CF RID: 1487 RVA: 0x000469EC File Offset: 0x00044BEC
		' (set) Token: 0x060005D0 RID: 1488 RVA: 0x00002F5C File Offset: 0x0000115C
		Public Property pstrMaHTTT_11 As String
			Get
				Return Me.mstrMaHTTT_11
			End Get
			Set(value As String)
				Me.mstrMaHTTT_11 = value
			End Set
		End Property

		' Token: 0x17000240 RID: 576
		' (get) Token: 0x060005D1 RID: 1489 RVA: 0x00046A04 File Offset: 0x00044C04
		' (set) Token: 0x060005D2 RID: 1490 RVA: 0x00002F67 File Offset: 0x00001167
		Public Property pstrMaHTTT_12 As String
			Get
				Return Me.mstrMaHTTT_12
			End Get
			Set(value As String)
				Me.mstrMaHTTT_12 = value
			End Set
		End Property

		' Token: 0x17000241 RID: 577
		' (get) Token: 0x060005D3 RID: 1491 RVA: 0x00046A1C File Offset: 0x00044C1C
		' (set) Token: 0x060005D4 RID: 1492 RVA: 0x00002F72 File Offset: 0x00001172
		Public Property pstrMaHTTT_13 As String
			Get
				Return Me.mstrMaHTTT_13
			End Get
			Set(value As String)
				Me.mstrMaHTTT_13 = value
			End Set
		End Property

		' Token: 0x17000242 RID: 578
		' (get) Token: 0x060005D5 RID: 1493 RVA: 0x00046A34 File Offset: 0x00044C34
		' (set) Token: 0x060005D6 RID: 1494 RVA: 0x00002F7D File Offset: 0x0000117D
		Public Property pstrMaHTTT_14 As String
			Get
				Return Me.mstrMaHTTT_14
			End Get
			Set(value As String)
				Me.mstrMaHTTT_14 = value
			End Set
		End Property

		' Token: 0x17000243 RID: 579
		' (get) Token: 0x060005D7 RID: 1495 RVA: 0x00046A4C File Offset: 0x00044C4C
		' (set) Token: 0x060005D8 RID: 1496 RVA: 0x00002F88 File Offset: 0x00001188
		Public Property pdblHTTT_1 As Double
			Get
				Return Me.mdblHTTT_1
			End Get
			Set(value As Double)
				Me.mdblHTTT_1 = value
			End Set
		End Property

		' Token: 0x17000244 RID: 580
		' (get) Token: 0x060005D9 RID: 1497 RVA: 0x00046A64 File Offset: 0x00044C64
		' (set) Token: 0x060005DA RID: 1498 RVA: 0x00002F93 File Offset: 0x00001193
		Public Property pdblHTTT_2 As Double
			Get
				Return Me.mdblHTTT_2
			End Get
			Set(value As Double)
				Me.mdblHTTT_2 = value
			End Set
		End Property

		' Token: 0x17000245 RID: 581
		' (get) Token: 0x060005DB RID: 1499 RVA: 0x00046A7C File Offset: 0x00044C7C
		' (set) Token: 0x060005DC RID: 1500 RVA: 0x00002F9E File Offset: 0x0000119E
		Public Property pdblHTTT_3 As Double
			Get
				Return Me.mdblHTTT_3
			End Get
			Set(value As Double)
				Me.mdblHTTT_3 = value
			End Set
		End Property

		' Token: 0x17000246 RID: 582
		' (get) Token: 0x060005DD RID: 1501 RVA: 0x00046A94 File Offset: 0x00044C94
		' (set) Token: 0x060005DE RID: 1502 RVA: 0x00002FA9 File Offset: 0x000011A9
		Public Property pdblHTTT_4 As Double
			Get
				Return Me.mdblHTTT_4
			End Get
			Set(value As Double)
				Me.mdblHTTT_4 = value
			End Set
		End Property

		' Token: 0x17000247 RID: 583
		' (get) Token: 0x060005DF RID: 1503 RVA: 0x00046AAC File Offset: 0x00044CAC
		' (set) Token: 0x060005E0 RID: 1504 RVA: 0x00002FB4 File Offset: 0x000011B4
		Public Property pdblHTTT_5 As Double
			Get
				Return Me.mdblHTTT_5
			End Get
			Set(value As Double)
				Me.mdblHTTT_5 = value
			End Set
		End Property

		' Token: 0x17000248 RID: 584
		' (get) Token: 0x060005E1 RID: 1505 RVA: 0x00046AC4 File Offset: 0x00044CC4
		' (set) Token: 0x060005E2 RID: 1506 RVA: 0x00002FBF File Offset: 0x000011BF
		Public Property pdblHTTT_6 As Double
			Get
				Return Me.mdblHTTT_6
			End Get
			Set(value As Double)
				Me.mdblHTTT_6 = value
			End Set
		End Property

		' Token: 0x17000249 RID: 585
		' (get) Token: 0x060005E3 RID: 1507 RVA: 0x00046ADC File Offset: 0x00044CDC
		' (set) Token: 0x060005E4 RID: 1508 RVA: 0x00002FCA File Offset: 0x000011CA
		Public Property pdblHTTT_7 As Double
			Get
				Return Me.mdblHTTT_7
			End Get
			Set(value As Double)
				Me.mdblHTTT_7 = value
			End Set
		End Property

		' Token: 0x1700024A RID: 586
		' (get) Token: 0x060005E5 RID: 1509 RVA: 0x00046AF4 File Offset: 0x00044CF4
		' (set) Token: 0x060005E6 RID: 1510 RVA: 0x00002FD5 File Offset: 0x000011D5
		Public Property pdblHTTT_8 As Double
			Get
				Return Me.mdblHTTT_8
			End Get
			Set(value As Double)
				Me.mdblHTTT_8 = value
			End Set
		End Property

		' Token: 0x1700024B RID: 587
		' (get) Token: 0x060005E7 RID: 1511 RVA: 0x00046B0C File Offset: 0x00044D0C
		' (set) Token: 0x060005E8 RID: 1512 RVA: 0x00002FE0 File Offset: 0x000011E0
		Public Property pdblHTTT_9 As Double
			Get
				Return Me.mdblHTTT_9
			End Get
			Set(value As Double)
				Me.mdblHTTT_9 = value
			End Set
		End Property

		' Token: 0x1700024C RID: 588
		' (get) Token: 0x060005E9 RID: 1513 RVA: 0x00046B24 File Offset: 0x00044D24
		' (set) Token: 0x060005EA RID: 1514 RVA: 0x00002FEB File Offset: 0x000011EB
		Public Property pdblHTTT_10 As Double
			Get
				Return Me.mdblHTTT_10
			End Get
			Set(value As Double)
				Me.mdblHTTT_10 = value
			End Set
		End Property

		' Token: 0x1700024D RID: 589
		' (get) Token: 0x060005EB RID: 1515 RVA: 0x00046B3C File Offset: 0x00044D3C
		' (set) Token: 0x060005EC RID: 1516 RVA: 0x00002FF6 File Offset: 0x000011F6
		Public Property pdblHTTT_11 As Double
			Get
				Return Me.mdblHTTT_11
			End Get
			Set(value As Double)
				Me.mdblHTTT_11 = value
			End Set
		End Property

		' Token: 0x1700024E RID: 590
		' (get) Token: 0x060005ED RID: 1517 RVA: 0x00046B54 File Offset: 0x00044D54
		' (set) Token: 0x060005EE RID: 1518 RVA: 0x00003001 File Offset: 0x00001201
		Public Property pdblHTTT_12 As Double
			Get
				Return Me.mdblHTTT_12
			End Get
			Set(value As Double)
				Me.mdblHTTT_12 = value
			End Set
		End Property

		' Token: 0x1700024F RID: 591
		' (get) Token: 0x060005EF RID: 1519 RVA: 0x00046B6C File Offset: 0x00044D6C
		' (set) Token: 0x060005F0 RID: 1520 RVA: 0x0000300C File Offset: 0x0000120C
		Public Property pdblHTTT_13 As Double
			Get
				Return Me.mdblHTTT_13
			End Get
			Set(value As Double)
				Me.mdblHTTT_13 = value
			End Set
		End Property

		' Token: 0x17000250 RID: 592
		' (get) Token: 0x060005F1 RID: 1521 RVA: 0x00046B84 File Offset: 0x00044D84
		' (set) Token: 0x060005F2 RID: 1522 RVA: 0x00003017 File Offset: 0x00001217
		Public Property pdblHTTT_14 As Double
			Get
				Return Me.mdblHTTT_14
			End Get
			Set(value As Double)
				Me.mdblHTTT_14 = value
			End Set
		End Property

		' Token: 0x17000251 RID: 593
		' (get) Token: 0x060005F3 RID: 1523 RVA: 0x00046B9C File Offset: 0x00044D9C
		' (set) Token: 0x060005F4 RID: 1524 RVA: 0x00003022 File Offset: 0x00001222
		Public Property pstrMaDV As String
			Get
				Return Me.mstrMaDV
			End Get
			Set(value As String)
				Me.mstrMaDV = value
			End Set
		End Property

		' Token: 0x17000252 RID: 594
		' (get) Token: 0x060005F5 RID: 1525 RVA: 0x00046BB4 File Offset: 0x00044DB4
		' (set) Token: 0x060005F6 RID: 1526 RVA: 0x0000302D File Offset: 0x0000122D
		Public Property pstrTenDV As String
			Get
				Return Me.mstrTenDV
			End Get
			Set(value As String)
				Me.mstrTenDV = value
			End Set
		End Property

		' Token: 0x17000253 RID: 595
		' (get) Token: 0x060005F7 RID: 1527 RVA: 0x00046BCC File Offset: 0x00044DCC
		' (set) Token: 0x060005F8 RID: 1528 RVA: 0x00003038 File Offset: 0x00001238
		Public Property pstrSoCT As String
			Get
				Return Me.mstrSoCT
			End Get
			Set(value As String)
				Me.mstrSoCT = value
			End Set
		End Property

		' Token: 0x17000254 RID: 596
		' (get) Token: 0x060005F9 RID: 1529 RVA: 0x00046BE4 File Offset: 0x00044DE4
		' (set) Token: 0x060005FA RID: 1530 RVA: 0x00003043 File Offset: 0x00001243
		Public Property pstrDateTime As String
			Get
				Return Me.mstrDateTime
			End Get
			Set(value As String)
				Me.mstrDateTime = value
			End Set
		End Property

		' Token: 0x17000255 RID: 597
		' (get) Token: 0x060005FB RID: 1531 RVA: 0x00046BFC File Offset: 0x00044DFC
		' (set) Token: 0x060005FC RID: 1532 RVA: 0x0000304E File Offset: 0x0000124E
		Public Property pdblCash As Double
			Get
				Return Me.mdblCash
			End Get
			Set(value As Double)
				Me.mdblCash = value
			End Set
		End Property

		' Token: 0x17000256 RID: 598
		' (get) Token: 0x060005FD RID: 1533 RVA: 0x00046C14 File Offset: 0x00044E14
		' (set) Token: 0x060005FE RID: 1534 RVA: 0x00003059 File Offset: 0x00001259
		Public Property pbytsuccess As Single
			Get
				Return CSng(Me.mbytsuccess)
			End Get
			Set(value As Single)
				' The following expression was wrapped in a checked-expression
				Me.mbytsuccess = CByte(Math.Round(CDbl(value)))
			End Set
		End Property

		' Token: 0x060005FF RID: 1535 RVA: 0x0000306B File Offset: 0x0000126B
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			mdlFile.gfWriteLogFile("Thoát form thanh toán song song")
			Me.mbytsuccess = 0
			Me.Close()
		End Sub

		' Token: 0x06000600 RID: 1536 RVA: 0x00046C30 File Offset: 0x00044E30
		Private Sub frmCashSongSongEdit_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				Me.sLoadHTTT()
				Me.f_GetData_Psal99()
				Me.CenterToScreen()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(2), vbCrLf, Me.Name, " - frmCashSongSongEdit_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000601 RID: 1537 RVA: 0x00046CF0 File Offset: 0x00044EF0
		Private Sub sLoadHTTT()
			' The following expression was wrapped in a checked-statement
			Try
				Dim clsConnect As clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHTTT")
				Dim b As Byte = 1
				Dim flag As Boolean = clsConnect.Rows.Count > 0
				Dim flag2 As Boolean
				If flag Then
					Try
						For Each obj As Object In clsConnect.Rows
							Dim dataRow As DataRow = CType(obj, DataRow)
							flag2 = Operators.CompareString(dataRow("OBJID").ToString().Trim(), "99", False) = 0
							If flag2 Then
								Me.mstrMaHTTT99 = dataRow("OBJID").ToString().Trim()
							Else
								flag2 = Operators.CompareString(dataRow("OBJID").ToString().Trim(), "01", False) = 0
								If flag2 Then
									Me.lbl1.Text = dataRow("OBJNAME").ToString().Trim()
									Me.lbl1.Tag = dataRow("OBJID").ToString().Trim()
									Me.btn1.Tag = dataRow("LDEBT").ToString().Trim()
									Me.btn1.Enabled = True
								Else
									b += 1
									Select Case b
										Case 2
											Me.lbl2.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl2.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn2.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn2.Enabled = True
										Case 3
											Me.lbl3.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl3.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn3.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn3.Enabled = True
										Case 4
											Me.lbl4.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl4.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn4.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn4.Enabled = True
										Case 5
											Me.lbl5.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl5.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn5.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn5.Enabled = True
										Case 6
											Me.lbl6.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl6.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn6.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn6.Enabled = True
										Case 7
											Me.lbl7.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl7.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn7.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn7.Enabled = True
										Case 8
											Me.lbl8.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl8.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn8.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn8.Enabled = True
										Case 9
											Me.lbl9.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl9.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn9.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn9.Enabled = True
										Case 10
											Me.lbl10.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl10.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn10.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn10.Enabled = True
										Case 11
											Me.lbl11.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl11.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn11.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn11.Enabled = True
										Case 12
											Me.lbl12.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl12.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn12.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn12.Enabled = True
										Case 13
											Me.lbl13.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl13.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn13.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn13.Enabled = True
										Case 14
											Me.lbl14.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl14.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn14.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn14.Enabled = True
									End Select
								End If
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag2 = TypeOf enumerator Is IDisposable
						If flag2 Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
				End If
				flag2 = Me.mstrMaHTTT99.Trim().Length = 0
				If flag2 Then
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(4), "Cash", frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.CanhBao)
					Me.btnExit_Click(RuntimeHelpers.GetObjectValue(New Object()), New EventArgs())
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - sLoadHTTT() " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000602 RID: 1538 RVA: 0x00047590 File Offset: 0x00045790
		Private Function f_GetData_Psal99() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchDOCID"
				array(0).Value = Me.mstrSoCT
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDULIEU, array, "SP_FRMCASHSONGSONG_GET_PSAL99", num)
				Dim flag As Boolean = clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
				If flag Then
					Try
						For Each obj As Object In clsConnect.Rows
							Dim dataRow As DataRow = CType(obj, DataRow)
							Dim label As Label = Me.fGetLabelByHTTT(dataRow("MAHTTT").ToString())
							flag = label IsNot Nothing
							If flag Then
								' The following expression was wrapped in a checked-expression
								Dim num2 As Integer = CInt(Math.Round(Conversion.Val(label.Name.Substring(3))))
								Me.Controls.Find("btn" + Conversions.ToString(num2), True)(0).Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(dataRow("AMT")), CShort(mdlVariable.gbytDECNUMAMT), ",")
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag = TypeOf enumerator Is IDisposable
						If flag Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
					b = 1
				Else
					Me.btn1.Text = mdlUIForm.gfFormatNumber(Me.mdblCash, CShort(mdlVariable.gbytDECNUMAMT), ",")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gf_GetData_Psal99 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000603 RID: 1539 RVA: 0x000477DC File Offset: 0x000459DC
		Private Function fGetLabelByHTTT(strMaHTTT As String) As Label
			Dim label As Label
			Try
				Try
					For Each obj As Object In Me.TableLayoutPanel2.Controls
						Dim control As Control = CType(obj, Control)
						Dim flag As Boolean = TypeOf control Is Label
						If flag Then
							Dim flag2 As Boolean = control.Tag IsNot Nothing
							If flag2 Then
								Dim flag3 As Boolean = Operators.CompareString(control.Tag.ToString().Trim(), strMaHTTT.Trim(), False) = 0
								If flag3 Then
									Return CType(control, Label)
								End If
							End If
						End If
					Next
				Finally
					Dim enumerator As IEnumerator
					Dim flag3 As Boolean = TypeOf enumerator Is IDisposable
					If flag3 Then
						TryCast(enumerator, IDisposable).Dispose()
					End If
				End Try
				Try
					For Each obj2 As Object In Me.TableLayoutPanel3.Controls
						Dim control2 As Control = CType(obj2, Control)
						Dim flag3 As Boolean = TypeOf control2 Is Label
						If flag3 Then
							Dim flag2 As Boolean = control2.Tag IsNot Nothing
							If flag2 Then
								Dim flag As Boolean = Operators.CompareString(control2.Tag.ToString().Trim(), strMaHTTT.Trim(), False) = 0
								If flag Then
									Return CType(control2, Label)
								End If
							End If
						End If
					Next
				Finally
					Dim enumerator2 As IEnumerator
					Dim flag3 As Boolean = TypeOf enumerator2 Is IDisposable
					If flag3 Then
						TryCast(enumerator2, IDisposable).Dispose()
					End If
				End Try
				label = Nothing
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetLabelByHTTT ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				label = Nothing
			End Try
			Return label
		End Function

		' Token: 0x06000604 RID: 1540 RVA: 0x00047A04 File Offset: 0x00045C04
		Private Sub btn2_Click(sender As Object, e As EventArgs)
			Try
				Dim button As Button = CType(sender, Button)
				Dim frmNumPad As frmNumPad = New frmNumPad()
				Dim num As Double = Conversion.Val(button.Text.Replace(",", ""))
				frmNumPad.pSglNumberReturn = CSng(num)
				frmNumPad.ShowDialog()
				Dim flag As Boolean = frmNumPad.pbytSuccess = 1
				If flag Then
					Dim num2 As Double = CDbl(frmNumPad.pSglNumberReturn)
					Dim num3 As Double = Conversion.Val(Me.btn1.Text.Replace(",", "")) + num - num2
					flag = num3 >= 0.0
					If flag Then
						button.Text = mdlUIForm.gfFormatNumber(num2, CShort(mdlVariable.gbytDECNUMAMT), ",")
						Me.btn1.Text = mdlUIForm.gfFormatNumber(num3, CShort(mdlVariable.gbytDECNUMAMT), ",")
					Else
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(10), "Cash", frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btn2_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000605 RID: 1541 RVA: 0x00047BB4 File Offset: 0x00045DB4
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim b As Byte = 0
				Dim flag As Boolean = False
				Dim text As String = ""
				Dim flag2 As Boolean = Conversion.Val(Me.btn1.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn1.Tag)
					text = Me.lbl1.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn2.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn2.Tag)
					text = Me.lbl2.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn3.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn3.Tag)
					text = Me.lbl3.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn4.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn4.Tag)
					text = Me.lbl4.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn5.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn5.Tag)
					text = Me.lbl5.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn6.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn6.Tag)
					text = Me.lbl6.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn7.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn7.Tag)
					text = Me.lbl7.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn8.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn8.Tag)
					text = Me.lbl8.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn9.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn9.Tag)
					text = Me.lbl9.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn10.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn10.Tag)
					text = Me.lbl10.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn11.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn11.Tag)
					text = Me.lbl11.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn12.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn12.Tag)
					text = Me.lbl12.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn13.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn13.Tag)
					text = Me.lbl13.Tag.ToString().Trim()
				End If
				flag2 = Conversion.Val(Me.btn14.Text.Replace(",", "")) > 0.0
				If flag2 Then
					b += 1
					flag = Conversions.ToBoolean(Me.btn14.Tag)
					text = Me.lbl14.Tag.ToString().Trim()
				End If
				flag2 = b = 1
				If flag2 Then
					Dim flag3 As Boolean = flag AndAlso Operators.CompareString(Me.mstrMaDV.Trim(), "", False) = 0
					If flag3 Then
						Dim frmCustomer As frmCustomer = New frmCustomer()
						frmCustomer.ShowDialog()
						flag3 = frmCustomer.pblnOK
						If Not flag3 Then
							Return
						End If
						Me.mstrMaDV = frmCustomer.pstrMadv
						Me.mstrTenDV = frmCustomer.pstrTenDv
					End If
					Me.mstrMaHTTT_JustOne = text
					Me.mbytsuccess = 1
					Me.Close()
				Else
					Me.mstrMaHTTT_JustOne = ""
					Dim flag3 As Boolean = Conversion.Val(Me.btn1.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_1 = Me.lbl1.Tag.ToString().Trim()
						Me.mdblHTTT_1 = Conversion.Val(Me.btn1.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn2.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_2 = Me.lbl2.Tag.ToString().Trim()
						Me.mdblHTTT_2 = Conversion.Val(Me.btn2.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn3.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_3 = Me.lbl3.Tag.ToString().Trim()
						Me.mdblHTTT_3 = Conversion.Val(Me.btn3.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn4.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_4 = Me.lbl4.Tag.ToString().Trim()
						Me.mdblHTTT_4 = Conversion.Val(Me.btn4.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn5.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_5 = Me.lbl5.Tag.ToString().Trim()
						Me.mdblHTTT_5 = Conversion.Val(Me.btn5.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn6.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_6 = Me.lbl6.Tag.ToString().Trim()
						Me.mdblHTTT_6 = Conversion.Val(Me.btn6.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn7.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_7 = Me.lbl7.Tag.ToString().Trim()
						Me.mdblHTTT_7 = Conversion.Val(Me.btn7.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn8.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_8 = Me.lbl8.Tag.ToString().Trim()
						Me.mdblHTTT_8 = Conversion.Val(Me.btn8.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn9.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_9 = Me.lbl9.Tag.ToString().Trim()
						Me.mdblHTTT_9 = Conversion.Val(Me.btn9.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn10.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_10 = Me.lbl10.Tag.ToString().Trim()
						Me.mdblHTTT_10 = Conversion.Val(Me.btn10.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn11.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_11 = Me.lbl11.Tag.ToString().Trim()
						Me.mdblHTTT_11 = Conversion.Val(Me.btn11.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn12.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_12 = Me.lbl12.Tag.ToString().Trim()
						Me.mdblHTTT_12 = Conversion.Val(Me.btn12.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn13.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_13 = Me.lbl13.Tag.ToString().Trim()
						Me.mdblHTTT_13 = Conversion.Val(Me.btn13.Text.Replace(",", ""))
					End If
					flag3 = Conversion.Val(Me.btn14.Text.Replace(",", "")) > 0.0
					If flag3 Then
						Me.mstrMaHTTT_14 = Me.lbl14.Tag.ToString().Trim()
						Me.mdblHTTT_14 = Conversion.Val(Me.btn14.Text.Replace(",", ""))
					End If
				End If
				Me.mbytsuccess = 1
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000606 RID: 1542 RVA: 0x00048860 File Offset: 0x00046A60
		Private Sub lbl_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = CType(sender, Label).Text.Trim().Length = 0
				If Not flag Then
					Me.btn1.Text = "0"
					Me.btn2.Text = "0"
					Me.btn3.Text = "0"
					Me.btn4.Text = "0"
					Me.btn5.Text = "0"
					Me.btn6.Text = "0"
					Me.btn7.Text = "0"
					Me.btn8.Text = "0"
					Me.btn9.Text = "0"
					Me.btn10.Text = "0"
					Me.btn11.Text = "0"
					Me.btn12.Text = "0"
					Me.btn13.Text = "0"
					Me.btn14.Text = "0"
					Dim text As String = CType(sender, Label).Name.Substring(3)
					Me.Controls.Find("btn" + text, True)(0).Text = mdlUIForm.gfFormatNumber(Me.mdblCash, CShort(mdlVariable.gbytDECNUMAMT), ",")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - lbl_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0400025A RID: 602
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400025C RID: 604
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x0400025D RID: 605
		<AccessedThroughProperty("TableLayoutPanel5")>
		Private _TableLayoutPanel5 As TableLayoutPanel

		' Token: 0x0400025E RID: 606
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x0400025F RID: 607
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000260 RID: 608
		<AccessedThroughProperty("TableLayoutPanel3")>
		Private _TableLayoutPanel3 As TableLayoutPanel

		' Token: 0x04000261 RID: 609
		<AccessedThroughProperty("TableLayoutPanel2")>
		Private _TableLayoutPanel2 As TableLayoutPanel

		' Token: 0x04000262 RID: 610
		<AccessedThroughProperty("lbl8")>
		Private _lbl8 As Label

		' Token: 0x04000263 RID: 611
		<AccessedThroughProperty("lbl9")>
		Private _lbl9 As Label

		' Token: 0x04000264 RID: 612
		<AccessedThroughProperty("lbl13")>
		Private _lbl13 As Label

		' Token: 0x04000265 RID: 613
		<AccessedThroughProperty("lbl11")>
		Private _lbl11 As Label

		' Token: 0x04000266 RID: 614
		<AccessedThroughProperty("lbl10")>
		Private _lbl10 As Label

		' Token: 0x04000267 RID: 615
		<AccessedThroughProperty("lbl12")>
		Private _lbl12 As Label

		' Token: 0x04000268 RID: 616
		<AccessedThroughProperty("lbl14")>
		Private _lbl14 As Label

		' Token: 0x04000269 RID: 617
		<AccessedThroughProperty("lbl1")>
		Private _lbl1 As Label

		' Token: 0x0400026A RID: 618
		<AccessedThroughProperty("lbl2")>
		Private _lbl2 As Label

		' Token: 0x0400026B RID: 619
		<AccessedThroughProperty("lbl4")>
		Private _lbl4 As Label

		' Token: 0x0400026C RID: 620
		<AccessedThroughProperty("lbl6")>
		Private _lbl6 As Label

		' Token: 0x0400026D RID: 621
		<AccessedThroughProperty("lbl3")>
		Private _lbl3 As Label

		' Token: 0x0400026E RID: 622
		<AccessedThroughProperty("lbl5")>
		Private _lbl5 As Label

		' Token: 0x0400026F RID: 623
		<AccessedThroughProperty("lbl7")>
		Private _lbl7 As Label

		' Token: 0x04000270 RID: 624
		<AccessedThroughProperty("btn1")>
		Private _btn1 As Button

		' Token: 0x04000271 RID: 625
		<AccessedThroughProperty("btn8")>
		Private _btn8 As Button

		' Token: 0x04000272 RID: 626
		<AccessedThroughProperty("btn9")>
		Private _btn9 As Button

		' Token: 0x04000273 RID: 627
		<AccessedThroughProperty("btn10")>
		Private _btn10 As Button

		' Token: 0x04000274 RID: 628
		<AccessedThroughProperty("btn11")>
		Private _btn11 As Button

		' Token: 0x04000275 RID: 629
		<AccessedThroughProperty("btn12")>
		Private _btn12 As Button

		' Token: 0x04000276 RID: 630
		<AccessedThroughProperty("btn13")>
		Private _btn13 As Button

		' Token: 0x04000277 RID: 631
		<AccessedThroughProperty("btn14")>
		Private _btn14 As Button

		' Token: 0x04000278 RID: 632
		<AccessedThroughProperty("btn2")>
		Private _btn2 As Button

		' Token: 0x04000279 RID: 633
		<AccessedThroughProperty("btn3")>
		Private _btn3 As Button

		' Token: 0x0400027A RID: 634
		<AccessedThroughProperty("btn4")>
		Private _btn4 As Button

		' Token: 0x0400027B RID: 635
		<AccessedThroughProperty("btn5")>
		Private _btn5 As Button

		' Token: 0x0400027C RID: 636
		<AccessedThroughProperty("btn6")>
		Private _btn6 As Button

		' Token: 0x0400027D RID: 637
		<AccessedThroughProperty("btn7")>
		Private _btn7 As Button

		' Token: 0x0400027E RID: 638
		Private mbytsuccess As Byte

		' Token: 0x0400027F RID: 639
		Private mdblCash As Double

		' Token: 0x04000280 RID: 640
		Private mstrSoCT As String

		' Token: 0x04000281 RID: 641
		Private mstrDateTime As String

		' Token: 0x04000282 RID: 642
		Private mstrMaDV As String

		' Token: 0x04000283 RID: 643
		Private mstrTenDV As String

		' Token: 0x04000284 RID: 644
		Private mArrStrFrmMess As String()

		' Token: 0x04000285 RID: 645
		Private mstrMaDVT As String

		' Token: 0x04000286 RID: 646
		Private mstrMaHTTT99 As String

		' Token: 0x04000287 RID: 647
		Private mstrMaHTTT_1 As String

		' Token: 0x04000288 RID: 648
		Private mdblHTTT_1 As Double

		' Token: 0x04000289 RID: 649
		Private mstrMaHTTT_2 As String

		' Token: 0x0400028A RID: 650
		Private mdblHTTT_2 As Double

		' Token: 0x0400028B RID: 651
		Private mstrMaHTTT_3 As String

		' Token: 0x0400028C RID: 652
		Private mdblHTTT_3 As Double

		' Token: 0x0400028D RID: 653
		Private mstrMaHTTT_4 As String

		' Token: 0x0400028E RID: 654
		Private mdblHTTT_4 As Double

		' Token: 0x0400028F RID: 655
		Private mstrMaHTTT_5 As String

		' Token: 0x04000290 RID: 656
		Private mdblHTTT_5 As Double

		' Token: 0x04000291 RID: 657
		Private mstrMaHTTT_6 As String

		' Token: 0x04000292 RID: 658
		Private mdblHTTT_6 As Double

		' Token: 0x04000293 RID: 659
		Private mstrMaHTTT_7 As String

		' Token: 0x04000294 RID: 660
		Private mdblHTTT_7 As Double

		' Token: 0x04000295 RID: 661
		Private mstrMaHTTT_8 As String

		' Token: 0x04000296 RID: 662
		Private mdblHTTT_8 As Double

		' Token: 0x04000297 RID: 663
		Private mstrMaHTTT_9 As String

		' Token: 0x04000298 RID: 664
		Private mdblHTTT_9 As Double

		' Token: 0x04000299 RID: 665
		Private mstrMaHTTT_10 As String

		' Token: 0x0400029A RID: 666
		Private mdblHTTT_10 As Double

		' Token: 0x0400029B RID: 667
		Private mstrMaHTTT_11 As String

		' Token: 0x0400029C RID: 668
		Private mdblHTTT_11 As Double

		' Token: 0x0400029D RID: 669
		Private mstrMaHTTT_12 As String

		' Token: 0x0400029E RID: 670
		Private mdblHTTT_12 As Double

		' Token: 0x0400029F RID: 671
		Private mstrMaHTTT_13 As String

		' Token: 0x040002A0 RID: 672
		Private mdblHTTT_13 As Double

		' Token: 0x040002A1 RID: 673
		Private mstrMaHTTT_14 As String

		' Token: 0x040002A2 RID: 674
		Private mdblHTTT_14 As Double

		' Token: 0x040002A3 RID: 675
		Private mstrMaHTTT_JustOne As String
	End Class
End Namespace
