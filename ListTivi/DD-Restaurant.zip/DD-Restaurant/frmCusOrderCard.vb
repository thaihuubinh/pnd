﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200002E RID: 46
	<DesignerGenerated()>
	Public Partial Class frmCusOrderCard
		Inherits Form

		' Token: 0x06000927 RID: 2343 RVA: 0x0006BDF0 File Offset: 0x00069FF0
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmCusOrder_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmCusOrder_Load
			frmCusOrderCard.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd = False
			Me.mbdsSourceDel = New BindingSource()
			Me.mclsTbData = New clsConnect()
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000367 RID: 871
		' (get) Token: 0x0600092A RID: 2346 RVA: 0x0006C94C File Offset: 0x0006AB4C
		' (set) Token: 0x0600092B RID: 2347 RVA: 0x0000381A File Offset: 0x00001A1A
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000368 RID: 872
		' (get) Token: 0x0600092C RID: 2348 RVA: 0x0006C964 File Offset: 0x0006AB64
		' (set) Token: 0x0600092D RID: 2349 RVA: 0x0006C97C File Offset: 0x0006AB7C
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000369 RID: 873
		' (get) Token: 0x0600092E RID: 2350 RVA: 0x0006C9E8 File Offset: 0x0006ABE8
		' (set) Token: 0x0600092F RID: 2351 RVA: 0x0006CA00 File Offset: 0x0006AC00
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x1700036A RID: 874
		' (get) Token: 0x06000930 RID: 2352 RVA: 0x0006CA6C File Offset: 0x0006AC6C
		' (set) Token: 0x06000931 RID: 2353 RVA: 0x0006CA84 File Offset: 0x0006AC84
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x1700036B RID: 875
		' (get) Token: 0x06000932 RID: 2354 RVA: 0x0006CAF0 File Offset: 0x0006ACF0
		' (set) Token: 0x06000933 RID: 2355 RVA: 0x00003824 File Offset: 0x00001A24
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x1700036C RID: 876
		' (get) Token: 0x06000934 RID: 2356 RVA: 0x0006CB08 File Offset: 0x0006AD08
		' (set) Token: 0x06000935 RID: 2357 RVA: 0x0006CB20 File Offset: 0x0006AD20
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x1700036D RID: 877
		' (get) Token: 0x06000936 RID: 2358 RVA: 0x0006CB8C File Offset: 0x0006AD8C
		' (set) Token: 0x06000937 RID: 2359 RVA: 0x0006CBA4 File Offset: 0x0006ADA4
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x1700036E RID: 878
		' (get) Token: 0x06000938 RID: 2360 RVA: 0x0006CC10 File Offset: 0x0006AE10
		' (set) Token: 0x06000939 RID: 2361 RVA: 0x0006CC28 File Offset: 0x0006AE28
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700036F RID: 879
		' (get) Token: 0x0600093A RID: 2362 RVA: 0x0006CC94 File Offset: 0x0006AE94
		' (set) Token: 0x0600093B RID: 2363 RVA: 0x0000382E File Offset: 0x00001A2E
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x17000370 RID: 880
		' (get) Token: 0x0600093C RID: 2364 RVA: 0x0006CCAC File Offset: 0x0006AEAC
		' (set) Token: 0x0600093D RID: 2365 RVA: 0x00003838 File Offset: 0x00001A38
		Friend Overridable Property lblFilterDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFilterDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFilterDate = value
			End Set
		End Property

		' Token: 0x17000371 RID: 881
		' (get) Token: 0x0600093E RID: 2366 RVA: 0x0006CCC4 File Offset: 0x0006AEC4
		' (set) Token: 0x0600093F RID: 2367 RVA: 0x0006CCDC File Offset: 0x0006AEDC
		Friend Overridable Property txtMaDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMaDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMaDV IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMaDV.TextChanged, AddressOf Me.txtMaDV_TextChanged
					RemoveHandler Me._txtMaDV.Click, AddressOf Me.txtMaDV_Click
				End If
				Me._txtMaDV = value
				flag = Me._txtMaDV IsNot Nothing
				If flag Then
					AddHandler Me._txtMaDV.TextChanged, AddressOf Me.txtMaDV_TextChanged
					AddHandler Me._txtMaDV.Click, AddressOf Me.txtMaDV_Click
				End If
			End Set
		End Property

		' Token: 0x17000372 RID: 882
		' (get) Token: 0x06000940 RID: 2368 RVA: 0x0006CD78 File Offset: 0x0006AF78
		' (set) Token: 0x06000941 RID: 2369 RVA: 0x0006CD90 File Offset: 0x0006AF90
		Friend Overridable Property btnKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKH.Click, AddressOf Me.btnKH_Click
				End If
				Me._btnKH = value
				flag = Me._btnKH IsNot Nothing
				If flag Then
					AddHandler Me._btnKH.Click, AddressOf Me.btnKH_Click
				End If
			End Set
		End Property

		' Token: 0x17000373 RID: 883
		' (get) Token: 0x06000942 RID: 2370 RVA: 0x0006CDFC File Offset: 0x0006AFFC
		' (set) Token: 0x06000943 RID: 2371 RVA: 0x00003842 File Offset: 0x00001A42
		Friend Overridable Property txtTENDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENDV = value
			End Set
		End Property

		' Token: 0x17000374 RID: 884
		' (get) Token: 0x06000944 RID: 2372 RVA: 0x0006CE14 File Offset: 0x0006B014
		' (set) Token: 0x06000945 RID: 2373 RVA: 0x0006CE2C File Offset: 0x0006B02C
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000375 RID: 885
		' (get) Token: 0x06000946 RID: 2374 RVA: 0x0006CE98 File Offset: 0x0006B098
		' (set) Token: 0x06000947 RID: 2375 RVA: 0x0000384C File Offset: 0x00001A4C
		Private Overridable Property mbdsSourceDel As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Me._mbdsSourceDel = value
			End Set
		End Property

		' Token: 0x17000376 RID: 886
		' (get) Token: 0x06000948 RID: 2376 RVA: 0x0006CEB0 File Offset: 0x0006B0B0
		' (set) Token: 0x06000949 RID: 2377 RVA: 0x00003856 File Offset: 0x00001A56
		Public Property pStrNGAYCT As String
			Get
				Return Me.mStrNGAYCT
			End Get
			Set(value As String)
				Me.mStrNGAYCT = value
			End Set
		End Property

		' Token: 0x17000377 RID: 887
		' (get) Token: 0x0600094A RID: 2378 RVA: 0x0006CEC8 File Offset: 0x0006B0C8
		' (set) Token: 0x0600094B RID: 2379 RVA: 0x00003861 File Offset: 0x00001A61
		Public Property pStrNGAYGS As String
			Get
				Return Me.mStrNGAYGS
			End Get
			Set(value As String)
				Me.mStrNGAYGS = value
			End Set
		End Property

		' Token: 0x17000378 RID: 888
		' (get) Token: 0x0600094C RID: 2380 RVA: 0x0006CEE0 File Offset: 0x0006B0E0
		' (set) Token: 0x0600094D RID: 2381 RVA: 0x0000386C File Offset: 0x00001A6C
		Public Property pStrSOCT As String
			Get
				Return Me.mStrSOCT
			End Get
			Set(value As String)
				Me.mStrSOCT = value
			End Set
		End Property

		' Token: 0x17000379 RID: 889
		' (get) Token: 0x0600094E RID: 2382 RVA: 0x0006CEF8 File Offset: 0x0006B0F8
		' (set) Token: 0x0600094F RID: 2383 RVA: 0x00003877 File Offset: 0x00001A77
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06000950 RID: 2384 RVA: 0x0006CF10 File Offset: 0x0006B110
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData("NGAYKT", Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000951 RID: 2385 RVA: 0x0006CFE4 File Offset: 0x0006B1E4
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData("NGAYKT", Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000952 RID: 2386 RVA: 0x0006D0D8 File Offset: 0x0006B2D8
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData("NGAYKT", Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000953 RID: 2387 RVA: 0x0006D1C0 File Offset: 0x0006B3C0
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData("NGAYKT", Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000954 RID: 2388 RVA: 0x0006D288 File Offset: 0x0006B488
		Private Sub frmCusOrder_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmCusOrder_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000955 RID: 2389 RVA: 0x0006D320 File Offset: 0x0006B520
		Private Sub frmCusOrder_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMDV()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmCusOrder_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000956 RID: 2390 RVA: 0x0006D3E0 File Offset: 0x0006B5E0
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000957 RID: 2391 RVA: 0x0006D4E8 File Offset: 0x0006B6E8
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				mdlFile.gfWriteLogFile("Nhấn nút thoát khỏi form danh sách khách hàng mua thẻ.")
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000958 RID: 2392 RVA: 0x0006D58C File Offset: 0x0006B78C
		Private Sub btnKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDV1_RG As frmDMDV1_RG = New frmDMDV1_RG()
				frmDMDV1_RG.pBytOpen_From_Menu = 7
				frmDMDV1_RG.ShowDialog()
				Me.txtMaDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV1_RG.pStrOBJID, "", False) = 0, Me.txtMaDV.Text, frmDMDV1_RG.pStrOBJID))
				Me.txtTENDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV1_RG.pStrOBJNAME, "", False) = 0, Me.txtTENDV.Text, frmDMDV1_RG.pStrOBJNAME))
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnKH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000959 RID: 2393 RVA: 0x0006D690 File Offset: 0x0006B890
		Private Sub txtMaDV_Click(sender As Object, e As EventArgs)
			Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
			frmKeyBoard.ShowDialog()
			Me.txtMaDV.Text = frmKeyBoard.pStrEnterText
		End Sub

		' Token: 0x0600095A RID: 2394 RVA: 0x0006D6C0 File Offset: 0x0006B8C0
		Private Sub txtMaDV_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDV Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDV.Columns("OBJID")
					Me.mclsTbDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDV.Rows.Find(Strings.Trim(Me.txtMaDV.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENDV.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENDV.Text = ""
					End If
					flag = Operators.CompareString(Me.txtTENDV.Text, "", False) <> 0
					If flag Then
						mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
						Dim b As Byte = Me.f_GetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMaDV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
			End Try
		End Sub

		' Token: 0x0600095B RID: 2395 RVA: 0x0006D898 File Offset: 0x0006BA98
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("STT").HeaderText = Me.mArrStrFrmMess(3)
				dgvData.Columns("STT").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.1))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("STT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DOCID").Visible = False
				dgvData.Columns("NGMUA").HeaderText = Strings.Trim(Me.mArrStrFrmMess(4))
				dgvData.Columns("NGMUA").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.16))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("NGMUA").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NOIDUNG").HeaderText = Strings.Trim(Me.mArrStrFrmMess(5))
				dgvData.Columns("NOIDUNG").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.25))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("NOIDUNG").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SOTIEN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(6))
				dgvData.Columns("SOTIEN").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.16))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
				dgvData.Columns("SOTIEN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NGBD").HeaderText = Strings.Trim(Me.mArrStrFrmMess(7))
				dgvData.Columns("NGBD").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.16))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("NGBD").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NGHH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(8))
				dgvData.Columns("NGHH").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.16))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("NGHH").DefaultCellStyle = dataGridViewCellStyle
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600095C RID: 2396 RVA: 0x0006DCA0 File Offset: 0x0006BEA0
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnSelect.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600095D RID: 2397 RVA: 0x0006DD98 File Offset: 0x0006BF98
		Private Function f_GetData_4Grid() As Byte
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchKH"
				array(0).Value = mdlVariable.gStrStockCode
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMADV"
				array(1).Value = Me.txtMaDV.Text.Trim()
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcRet"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim num As Integer
				Me.mclsTbData = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMPTHE_GET_DATA", num)
				Dim flag As Boolean = Me.txtMaDV.Text.Trim().Length > 0
				If flag Then
					mdlFile.gfWriteLogFile("Lọc theo khách hàng: " + Me.txtMaDV.Text.Trim() + "-" + Me.txtTENDV.Text.Trim())
				End If
				flag = num = 1
				If flag Then
					Me.mbdsSource.DataSource = Me.mclsTbData
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - f_GetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				Me.mclsTbData.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600095E RID: 2398 RVA: 0x0006DF84 File Offset: 0x0006C184
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600095F RID: 2399 RVA: 0x0006E038 File Offset: 0x0006C238
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim text As String = Strings.Trim(mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMKH", "OBJID", mdlVariable.gStrStockCode, "OBJNAME"))
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000960 RID: 2400 RVA: 0x0006E188 File Offset: 0x0006C388
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000961 RID: 2401 RVA: 0x0006E234 File Offset: 0x0006C434
		Private Function fGetData_DMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMDV")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000962 RID: 2402 RVA: 0x0006E2E0 File Offset: 0x0006C4E0
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = (Me.txtMaDV.Text.Trim().Length > 0) And (Me.txtTENDV.Text.Trim().Length > 0)
				If flag Then
					Dim flag2 As Boolean = Me.mclsTbData Is Nothing OrElse Me.mclsTbData.Rows.Count = 0
					If flag2 Then
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(14), Me.mArrStrFrmMess(13), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.CanhBao)
					Else
						mdlFile.gfWriteLogFile("Nhấn nút In theo khách hàng: " + Me.txtMaDV.Text.Trim() + "-" + Me.txtTENDV.Text.Trim())
						Me.fPrintCusOrderCard(Me.txtMaDV.Text.Trim() + " - " + Me.txtTENDV.Text.Trim(), Me.mclsTbData)
					End If
				Else
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(12), Me.mArrStrFrmMess(13), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.CanhBao)
				End If
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06000963 RID: 2403 RVA: 0x0006E438 File Offset: 0x0006C638
		Private Function fPrintCusOrderCard(strKhachHang As String, mdtTable As DataTable) As Byte
			Dim rptCusOrderCard As rptCusOrderCard = New rptCusOrderCard()
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptCusOrderCard, "")
				Dim text As String = "2070401000"
				mdlReport.gsSetOfficeReport(rptCusOrderCard, text)
				mdlReport.gsSetFontReport(rptCusOrderCard)
				Dim flag As Boolean = mdtTable.Rows.Count > 0
				If flag Then
					rptCusOrderCard.SetDataSource(mdtTable)
					Dim textObject As TextObject = CType(rptCusOrderCard.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					textObject.Text = Me.mArrStrFrmMess(15)
					Dim textObject2 As TextObject = CType(rptCusOrderCard.ReportDefinition.ReportObjects("txtKhachHang"), TextObject)
					textObject2.Text = strKhachHang
					rptCusOrderCard.DataDefinition.FormulaFields("fNGAYMUA").Text = "{dtReport.NGMUA}"
					rptCusOrderCard.DataDefinition.FormulaFields("fNOIDUNG").Text = "{dtReport.NOIDUNG}"
					rptCusOrderCard.DataDefinition.FormulaFields("fSOTIEN").Text = "{dtReport.SOTIEN}"
					rptCusOrderCard.DataDefinition.FormulaFields("fNGAYBATDAU").Text = "{dtReport.NGBD}"
					rptCusOrderCard.DataDefinition.FormulaFields("fNGAYHETHAN").Text = "{dtReport.NGHH}"
					mdlReport.gsSetTextReport(rptCusOrderCard, "RPTCUSORDERCARD")
					MyProject.Forms.frmReport.pSource = rptCusOrderCard
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					MyProject.Forms.frmReport.Text = textObject.Text
					rptCusOrderCard.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptCusOrderCard.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					mdtTable.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintCusOrderCard " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptCusOrderCard.Dispose()
				mdtTable.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x04000400 RID: 1024
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000402 RID: 1026
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000403 RID: 1027
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000404 RID: 1028
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000405 RID: 1029
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000406 RID: 1030
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000407 RID: 1031
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000408 RID: 1032
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000409 RID: 1033
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x0400040A RID: 1034
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x0400040B RID: 1035
		<AccessedThroughProperty("lblFilterDate")>
		Private _lblFilterDate As Label

		' Token: 0x0400040C RID: 1036
		<AccessedThroughProperty("txtMaDV")>
		Private _txtMaDV As TextBox

		' Token: 0x0400040D RID: 1037
		<AccessedThroughProperty("btnKH")>
		Private _btnKH As Button

		' Token: 0x0400040E RID: 1038
		<AccessedThroughProperty("txtTENDV")>
		Private _txtTENDV As TextBox

		' Token: 0x0400040F RID: 1039
		Private mArrStrFrmMess As String()

		' Token: 0x04000410 RID: 1040
		Private mStrSOCT As String

		' Token: 0x04000411 RID: 1041
		Private mStrNGAYGS As String

		' Token: 0x04000412 RID: 1042
		Private mStrNGAYCT As String

		' Token: 0x04000413 RID: 1043
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000414 RID: 1044
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000415 RID: 1045
		Private marrDrFind As DataRow()

		' Token: 0x04000416 RID: 1046
		Private mintFindLastPos As Integer

		' Token: 0x04000417 RID: 1047
		Private mblnAutoAdd As Boolean

		' Token: 0x04000418 RID: 1048
		Private mbytLen_OBJID As Byte

		' Token: 0x04000419 RID: 1049
		Private mclsTbDMKH As clsConnect

		' Token: 0x0400041A RID: 1050
		Private mclsTbDV As clsConnect

		' Token: 0x0400041B RID: 1051
		<AccessedThroughProperty("mbdsSourceDel")>
		Private _mbdsSourceDel As BindingSource

		' Token: 0x0400041C RID: 1052
		Private mclsTbData As clsConnect
	End Class
End Namespace
