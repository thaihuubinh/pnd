﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000192 RID: 402
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptDocument03
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005C04 RID: 23556 RVA: 0x000102C1 File Offset: 0x0000E4C1
		Public Sub New()
			CachedrptDocument03.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170021D9 RID: 8665
		' (get) Token: 0x06005C05 RID: 23557 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005C06 RID: 23558 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170021DA RID: 8666
		' (get) Token: 0x06005C07 RID: 23559 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005C08 RID: 23560 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170021DB RID: 8667
		' (get) Token: 0x06005C09 RID: 23561 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005C0A RID: 23562 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005C0B RID: 23563 RVA: 0x004DBDA0 File Offset: 0x004D9FA0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptDocument03() With { .Site = Me.Site }
		End Function

		' Token: 0x06005C0C RID: 23564 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x0400278A RID: 10122
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
