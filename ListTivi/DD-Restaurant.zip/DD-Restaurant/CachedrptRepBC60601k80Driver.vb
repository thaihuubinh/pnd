﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000260 RID: 608
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60601k80Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600653E RID: 25918 RVA: 0x000123BF File Offset: 0x000105BF
		Public Sub New()
			CachedrptRepBC60601k80Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x1700270D RID: 9997
		' (get) Token: 0x0600653F RID: 25919 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006540 RID: 25920 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700270E RID: 9998
		' (get) Token: 0x06006541 RID: 25921 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006542 RID: 25922 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700270F RID: 9999
		' (get) Token: 0x06006543 RID: 25923 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006544 RID: 25924 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006545 RID: 25925 RVA: 0x004DD760 File Offset: 0x004DB960
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60601k80Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x06006546 RID: 25926 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002858 RID: 10328
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
