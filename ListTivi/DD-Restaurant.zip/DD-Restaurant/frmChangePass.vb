﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000022 RID: 34
	<DesignerGenerated()>
	Public Partial Class frmChangePass
		Inherits Form

		' Token: 0x0600063E RID: 1598 RVA: 0x0004AEB8 File Offset: 0x000490B8
		<DebuggerNonUserCode()>
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmChangePass_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmChangePass_load
			frmChangePass.__ENCList.Add(New WeakReference(Me))
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000265 RID: 613
		' (get) Token: 0x06000641 RID: 1601 RVA: 0x0004B710 File Offset: 0x00049910
		' (set) Token: 0x06000642 RID: 1602 RVA: 0x000030EC File Offset: 0x000012EC
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000266 RID: 614
		' (get) Token: 0x06000643 RID: 1603 RVA: 0x0004B728 File Offset: 0x00049928
		' (set) Token: 0x06000644 RID: 1604 RVA: 0x0004B740 File Offset: 0x00049940
		Friend Overridable Property btnOK As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnOK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnOK IsNot Nothing
				If flag Then
					RemoveHandler Me._btnOK.Click, AddressOf Me.btnOK_Click
				End If
				Me._btnOK = value
				flag = Me._btnOK IsNot Nothing
				If flag Then
					AddHandler Me._btnOK.Click, AddressOf Me.btnOK_Click
				End If
			End Set
		End Property

		' Token: 0x17000267 RID: 615
		' (get) Token: 0x06000645 RID: 1605 RVA: 0x0004B7AC File Offset: 0x000499AC
		' (set) Token: 0x06000646 RID: 1606 RVA: 0x0004B7C4 File Offset: 0x000499C4
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000268 RID: 616
		' (get) Token: 0x06000647 RID: 1607 RVA: 0x0004B830 File Offset: 0x00049A30
		' (set) Token: 0x06000648 RID: 1608 RVA: 0x000030F6 File Offset: 0x000012F6
		Friend Overridable Property lblOLDPASS As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOLDPASS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOLDPASS = value
			End Set
		End Property

		' Token: 0x17000269 RID: 617
		' (get) Token: 0x06000649 RID: 1609 RVA: 0x0004B848 File Offset: 0x00049A48
		' (set) Token: 0x0600064A RID: 1610 RVA: 0x0004B860 File Offset: 0x00049A60
		Friend Overridable Property txtOLDPASS As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOLDPASS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOLDPASS IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOLDPASS.KeyPress, AddressOf Me.txtOLDPASS_KeyPress
				End If
				Me._txtOLDPASS = value
				flag = Me._txtOLDPASS IsNot Nothing
				If flag Then
					AddHandler Me._txtOLDPASS.KeyPress, AddressOf Me.txtOLDPASS_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700026A RID: 618
		' (get) Token: 0x0600064B RID: 1611 RVA: 0x0004B8CC File Offset: 0x00049ACC
		' (set) Token: 0x0600064C RID: 1612 RVA: 0x00003100 File Offset: 0x00001300
		Friend Overridable Property lblNEWPASS1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblNEWPASS1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblNEWPASS1 = value
			End Set
		End Property

		' Token: 0x1700026B RID: 619
		' (get) Token: 0x0600064D RID: 1613 RVA: 0x0004B8E4 File Offset: 0x00049AE4
		' (set) Token: 0x0600064E RID: 1614 RVA: 0x0004B8FC File Offset: 0x00049AFC
		Friend Overridable Property txtNEWPASS1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtNEWPASS1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtNEWPASS1 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtNEWPASS1.KeyPress, AddressOf Me.txtNEWPASS1_KeyPress
				End If
				Me._txtNEWPASS1 = value
				flag = Me._txtNEWPASS1 IsNot Nothing
				If flag Then
					AddHandler Me._txtNEWPASS1.KeyPress, AddressOf Me.txtNEWPASS1_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700026C RID: 620
		' (get) Token: 0x0600064F RID: 1615 RVA: 0x0004B968 File Offset: 0x00049B68
		' (set) Token: 0x06000650 RID: 1616 RVA: 0x0000310A File Offset: 0x0000130A
		Friend Overridable Property lblNEWPASS2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblNEWPASS2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblNEWPASS2 = value
			End Set
		End Property

		' Token: 0x1700026D RID: 621
		' (get) Token: 0x06000651 RID: 1617 RVA: 0x0004B980 File Offset: 0x00049B80
		' (set) Token: 0x06000652 RID: 1618 RVA: 0x0004B998 File Offset: 0x00049B98
		Friend Overridable Property txtNEWPASS2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtNEWPASS2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtNEWPASS2 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtNEWPASS2.KeyPress, AddressOf Me.txtNEWPASS2_KeyPress
				End If
				Me._txtNEWPASS2 = value
				flag = Me._txtNEWPASS2 IsNot Nothing
				If flag Then
					AddHandler Me._txtNEWPASS2.KeyPress, AddressOf Me.txtNEWPASS2_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700026E RID: 622
		' (get) Token: 0x06000653 RID: 1619 RVA: 0x0004BA04 File Offset: 0x00049C04
		' (set) Token: 0x06000654 RID: 1620 RVA: 0x0004BA1C File Offset: 0x00049C1C
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x06000655 RID: 1621 RVA: 0x0004BA88 File Offset: 0x00049C88
		Private Sub txtOLDPASS_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtNEWPASS1.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - txtOLDPASS_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000656 RID: 1622 RVA: 0x0004BB3C File Offset: 0x00049D3C
		Private Sub txtNEWPASS1_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtNEWPASS2.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - txtNEWPASS1_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000657 RID: 1623 RVA: 0x0004BBF0 File Offset: 0x00049DF0
		Private Sub txtNEWPASS2_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.btnOK.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - txtNEWPASS2_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000658 RID: 1624 RVA: 0x0004BCA4 File Offset: 0x00049EA4
		Private Sub frmChangePass_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - frmChangePass_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000659 RID: 1625 RVA: 0x0004BD3C File Offset: 0x00049F3C
		Private Sub frmChangePass_load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - frmChangePass_load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600065A RID: 1626 RVA: 0x0004BDE8 File Offset: 0x00049FE8
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				mdlFile.gfWriteLogFile("Nhấn nút Thoát form thay đổi mật khẩu.")
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600065B RID: 1627 RVA: 0x0004BE8C File Offset: 0x0004A08C
		Private Sub btnOK_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Me.txtNEWPASS1.Text, Me.txtNEWPASS2.Text, False) <> 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(13), MsgBoxStyle.Critical, Nothing)
					Me.txtNEWPASS1.Focus()
				Else
					flag = Me.fUpdate() = 1
					If flag Then
						mdlFile.gfWriteLogFile("Nhấn nút đồng ý thay đổi mật khẩu.")
						Me.Close()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - btnOK_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x1700026F RID: 623
		' (get) Token: 0x0600065C RID: 1628 RVA: 0x0004BF88 File Offset: 0x0004A188
		' (set) Token: 0x0600065D RID: 1629 RVA: 0x00003114 File Offset: 0x00001314
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Conversions.ToByte(Me.mBytOpen_FromMenu)
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = Conversions.ToString(value)
			End Set
		End Property

		' Token: 0x0600065E RID: 1630 RVA: 0x0004BFA8 File Offset: 0x0004A1A8
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600065F RID: 1631 RVA: 0x0004C054 File Offset: 0x0004A254
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000660 RID: 1632 RVA: 0x0004C160 File Offset: 0x0004A360
		Private Function fUpdate() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pchrOBJID"
				array(0).Value = mdlVariable.gStrUser
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchOLDPASS"
				array(1).Value = Crypto.Encrypt(Me.txtOLDPASS.Text.Trim(), "cocke")
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pvchNEWPASS"
				array(2).Value = Crypto.Encrypt(Me.txtNEWPASS1.Text.Trim(), "cocke")
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pintResult"
				array(3).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCHANGEPASS", flag)
				Dim flag2 As Boolean = Operators.ConditionalCompareObjectEqual(array(3).Value, 0, False)
				If flag2 Then
					b = 1
				Else
					flag2 = Operators.ConditionalCompareObjectEqual(array(3).Value, 2, False)
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(14), MsgBoxStyle.Critical, Nothing)
						Me.txtOLDPASS.Focus()
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(9), MsgBoxStyle.Critical, Nothing)
						Me.txtOLDPASS.Focus()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - fUpdate ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000661 RID: 1633 RVA: 0x0004C394 File Offset: 0x0004A594
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000662 RID: 1634 RVA: 0x0004C434 File Offset: 0x0004A634
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				Me.txtOLDPASS.Focus()
				Me.txtOLDPASS.SelectAll()
			End If
		End Sub

		' Token: 0x06000663 RID: 1635 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x040002B9 RID: 697
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040002BB RID: 699
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x040002BC RID: 700
		<AccessedThroughProperty("btnOK")>
		Private _btnOK As Button

		' Token: 0x040002BD RID: 701
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040002BE RID: 702
		<AccessedThroughProperty("lblOLDPASS")>
		Private _lblOLDPASS As Label

		' Token: 0x040002BF RID: 703
		<AccessedThroughProperty("txtOLDPASS")>
		Private _txtOLDPASS As TextBox

		' Token: 0x040002C0 RID: 704
		<AccessedThroughProperty("lblNEWPASS1")>
		Private _lblNEWPASS1 As Label

		' Token: 0x040002C1 RID: 705
		<AccessedThroughProperty("txtNEWPASS1")>
		Private _txtNEWPASS1 As TextBox

		' Token: 0x040002C2 RID: 706
		<AccessedThroughProperty("lblNEWPASS2")>
		Private _lblNEWPASS2 As Label

		' Token: 0x040002C3 RID: 707
		<AccessedThroughProperty("txtNEWPASS2")>
		Private _txtNEWPASS2 As TextBox

		' Token: 0x040002C4 RID: 708
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x040002C5 RID: 709
		Private mArrStrFrmMess As String()

		' Token: 0x040002C6 RID: 710
		Private mBytOpen_FromMenu As String
	End Class
End Namespace
