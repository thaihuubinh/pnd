﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000040 RID: 64
	<DesignerGenerated()>
	Public Partial Class frmDMDNKM4
		Inherits Form

		' Token: 0x06000F84 RID: 3972 RVA: 0x000B8F98 File Offset: 0x000B7198
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMBP2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMBP2_Load
			frmDMDNKM4.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mbytAllData = 0
			Me.mbtySingle = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700057E RID: 1406
		' (get) Token: 0x06000F87 RID: 3975 RVA: 0x000B9864 File Offset: 0x000B7A64
		' (set) Token: 0x06000F88 RID: 3976 RVA: 0x0000471E File Offset: 0x0000291E
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x1700057F RID: 1407
		' (get) Token: 0x06000F89 RID: 3977 RVA: 0x000B987C File Offset: 0x000B7A7C
		' (set) Token: 0x06000F8A RID: 3978 RVA: 0x000B9894 File Offset: 0x000B7A94
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000580 RID: 1408
		' (get) Token: 0x06000F8B RID: 3979 RVA: 0x000B9900 File Offset: 0x000B7B00
		' (set) Token: 0x06000F8C RID: 3980 RVA: 0x000B9918 File Offset: 0x000B7B18
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000581 RID: 1409
		' (get) Token: 0x06000F8D RID: 3981 RVA: 0x000B9984 File Offset: 0x000B7B84
		' (set) Token: 0x06000F8E RID: 3982 RVA: 0x000B999C File Offset: 0x000B7B9C
		Friend Overridable Property btnThemAll As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnThemAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnThemAll IsNot Nothing
				If flag Then
					RemoveHandler Me._btnThemAll.Click, AddressOf Me.btnThemAll_Click
				End If
				Me._btnThemAll = value
				flag = Me._btnThemAll IsNot Nothing
				If flag Then
					AddHandler Me._btnThemAll.Click, AddressOf Me.btnThemAll_Click
				End If
			End Set
		End Property

		' Token: 0x17000582 RID: 1410
		' (get) Token: 0x06000F8F RID: 3983 RVA: 0x000B9A08 File Offset: 0x000B7C08
		' (set) Token: 0x06000F90 RID: 3984 RVA: 0x000B9A20 File Offset: 0x000B7C20
		Friend Overridable Property btnThem1MH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnThem1MH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnThem1MH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnThem1MH.Click, AddressOf Me.btnThem1MH_Click
				End If
				Me._btnThem1MH = value
				flag = Me._btnThem1MH IsNot Nothing
				If flag Then
					AddHandler Me._btnThem1MH.Click, AddressOf Me.btnThem1MH_Click
				End If
			End Set
		End Property

		' Token: 0x17000583 RID: 1411
		' (get) Token: 0x06000F91 RID: 3985 RVA: 0x000B9A8C File Offset: 0x000B7C8C
		' (set) Token: 0x06000F92 RID: 3986 RVA: 0x000B9AA4 File Offset: 0x000B7CA4
		Friend Overridable Property btnGobo As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnGobo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnGobo IsNot Nothing
				If flag Then
					RemoveHandler Me._btnGobo.Click, AddressOf Me.btnGobo_Click
				End If
				Me._btnGobo = value
				flag = Me._btnGobo IsNot Nothing
				If flag Then
					AddHandler Me._btnGobo.Click, AddressOf Me.btnGobo_Click
				End If
			End Set
		End Property

		' Token: 0x17000584 RID: 1412
		' (get) Token: 0x06000F93 RID: 3987 RVA: 0x000B9B10 File Offset: 0x000B7D10
		' (set) Token: 0x06000F94 RID: 3988 RVA: 0x00004728 File Offset: 0x00002928
		Friend Overridable Property lstHanghoaThemAll As ListBox
			<DebuggerNonUserCode()>
			Get
				Return Me._lstHanghoaThemAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Me._lstHanghoaThemAll = value
			End Set
		End Property

		' Token: 0x17000585 RID: 1413
		' (get) Token: 0x06000F95 RID: 3989 RVA: 0x000B9B28 File Offset: 0x000B7D28
		' (set) Token: 0x06000F96 RID: 3990 RVA: 0x00004732 File Offset: 0x00002932
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000586 RID: 1414
		' (get) Token: 0x06000F97 RID: 3991 RVA: 0x000B9B40 File Offset: 0x000B7D40
		' (set) Token: 0x06000F98 RID: 3992 RVA: 0x000B9B58 File Offset: 0x000B7D58
		Friend Overridable Property btnGoBoAll As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnGoBoAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnGoBoAll IsNot Nothing
				If flag Then
					RemoveHandler Me._btnGoBoAll.Click, AddressOf Me.btnGoBoAll_Click
				End If
				Me._btnGoBoAll = value
				flag = Me._btnGoBoAll IsNot Nothing
				If flag Then
					AddHandler Me._btnGoBoAll.Click, AddressOf Me.btnGoBoAll_Click
				End If
			End Set
		End Property

		' Token: 0x17000587 RID: 1415
		' (get) Token: 0x06000F99 RID: 3993 RVA: 0x000B9BC4 File Offset: 0x000B7DC4
		' (set) Token: 0x06000F9A RID: 3994 RVA: 0x0000473C File Offset: 0x0000293C
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Me._mbdsSource = value
			End Set
		End Property

		' Token: 0x17000588 RID: 1416
		' (get) Token: 0x06000F9B RID: 3995 RVA: 0x000B9BDC File Offset: 0x000B7DDC
		' (set) Token: 0x06000F9C RID: 3996 RVA: 0x00004746 File Offset: 0x00002946
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000589 RID: 1417
		' (get) Token: 0x06000F9D RID: 3997 RVA: 0x000B9BF4 File Offset: 0x000B7DF4
		' (set) Token: 0x06000F9E RID: 3998 RVA: 0x00004751 File Offset: 0x00002951
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x1700058A RID: 1418
		' (get) Token: 0x06000F9F RID: 3999 RVA: 0x000B9C0C File Offset: 0x000B7E0C
		' (set) Token: 0x06000FA0 RID: 4000 RVA: 0x0000475C File Offset: 0x0000295C
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x1700058B RID: 1419
		' (get) Token: 0x06000FA1 RID: 4001 RVA: 0x000B9C24 File Offset: 0x000B7E24
		' (set) Token: 0x06000FA2 RID: 4002 RVA: 0x00004767 File Offset: 0x00002967
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x1700058C RID: 1420
		' (get) Token: 0x06000FA3 RID: 4003 RVA: 0x000B9C3C File Offset: 0x000B7E3C
		' (set) Token: 0x06000FA4 RID: 4004 RVA: 0x00004772 File Offset: 0x00002972
		Public Property pStrMAHHSALE As String
			Get
				Return Me.mStrMAHHSALE
			End Get
			Set(value As String)
				Me.mStrMAHHSALE = value
			End Set
		End Property

		' Token: 0x1700058D RID: 1421
		' (get) Token: 0x06000FA5 RID: 4005 RVA: 0x000B9C54 File Offset: 0x000B7E54
		' (set) Token: 0x06000FA6 RID: 4006 RVA: 0x0000477D File Offset: 0x0000297D
		Public Property pStrMAHHSUR As String
			Get
				Return Me.mStrMAHHSUR
			End Get
			Set(value As String)
				Me.mStrMAHHSUR = value
			End Set
		End Property

		' Token: 0x06000FA7 RID: 4007 RVA: 0x000B9C6C File Offset: 0x000B7E6C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FA8 RID: 4008 RVA: 0x000B9CF8 File Offset: 0x000B7EF8
		Private Sub frmDMBP2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000FA9 RID: 4009 RVA: 0x000B9D90 File Offset: 0x000B7F90
		Private Sub frmDMBP2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000FAA RID: 4010 RVA: 0x000B9E50 File Offset: 0x000B8050
		Private Sub btnGobo_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytFlag = 3
				Me.fGetData_4ListBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnGobo_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FAB RID: 4011 RVA: 0x000B9EE4 File Offset: 0x000B80E4
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbytFormStatus = 1
				Dim flag2 As Boolean
				If flag Then
					flag2 = Me.lstHanghoaThemAll.Items.Count = 0
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(13) + vbCrLf & vbCrLf, MsgBoxStyle.Critical, Nothing)
						Me.btnThemAll.Focus()
						Return
					End If
					Me.sAdd()
				Else
					flag2 = (Me.mbytFormStatus = 3) Or (Me.mbytFormStatus = 4)
					If flag2 Then
						Me.mbytSuccess = Me.fModify()
						Me.sAdd()
					End If
				End If
				flag2 = Me.mbytSuccess = 1
				If flag2 Then
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000FAC RID: 4012 RVA: 0x000BA010 File Offset: 0x000B8210
		Private Sub btnThemAll_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytFlag = 1
				Me.fGetData_4ListBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnThemAll_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FAD RID: 4013 RVA: 0x000BA0A4 File Offset: 0x000B82A4
		Private Sub btnThem1MH_Click(sender As Object, e As EventArgs)
			Me.mbytFlag = 2
			Try
				Dim frmDMHH As frmDMHH1 = New frmDMHH1()
				frmDMHH.pBytOpen_From_Menu = 7
				frmDMHH.ShowDialog()
				Dim flag As Boolean = frmDMHH.pBlnSelect
				If flag Then
					Me.mArrstrMAHH = frmDMHH.pArrOBJID
					Me.mArrstrTENHH = frmDMHH.pArrOBJNAME
					frmDMHH.Dispose()
					flag = Me.mArrstrMAHH.Length > 0 AndAlso Me.mArrstrTENHH.Length > 0
					If flag Then
						Me.fGetData_4ListBox()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnThem1MH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000FAE RID: 4014 RVA: 0x000BA1A4 File Offset: 0x000B83A4
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 4
						Me.sDisplay_Moddelete()
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000FAF RID: 4015 RVA: 0x000BA26C File Offset: 0x000B846C
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnSave.Enabled = False
				Me.btnExit.Enabled = True
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
					Case 4
						Me.btnSave.Enabled = True
						Me.btnExit.Focus()
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return b
		End Function

		' Token: 0x06000FB0 RID: 4016 RVA: 0x000BA37C File Offset: 0x000B857C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.lstHanghoaThemAll.SelectionMode = SelectionMode.MultiSimple
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000FB1 RID: 4017 RVA: 0x000BA434 File Offset: 0x000B8634
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(5))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(6))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(7))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return b
		End Function

		' Token: 0x06000FB2 RID: 4018 RVA: 0x000BA57C File Offset: 0x000B877C
		Private Sub sClear_Form()
			Try
				Me.mclsTBHHThemAll.Dispose()
				Me.mclsTemp.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FB3 RID: 4019 RVA: 0x000BA628 File Offset: 0x000B8828
		Private Function fAddNew(strPara1 As String, strPara2 As String, strPara3 As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADNKM"
				array(0).Value = strPara1
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHHSAL"
				array(1).Value = strPara2
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAHHSUR"
				array(2).Value = strPara3
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@int_Result"
				array(3).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_INSERT_DETAIL", flag)
				Dim num As Integer = Conversions.ToInteger(array(3).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(8), MsgBoxStyle.Critical, Nothing)
						Me.btnExit.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(9), MsgBoxStyle.Critical, Nothing)
							Me.btnExit.Focus()
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(10), MsgBoxStyle.Critical, Nothing)
								Me.btnExit.Focus()
							Else
								flag2 = num = 4
								If flag2 Then
									b = 1
									Me.btnExit.Focus()
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000FB4 RID: 4020 RVA: 0x000BA868 File Offset: 0x000B8A68
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADNKM"
				array(0).Value = Me.mStrOBJID
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_DEL_DETAIL", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000FB5 RID: 4021 RVA: 0x000BA9B8 File Offset: 0x000B8BB8
		Private Function fGetData_4ListBox() As Byte
			' The following expression was wrapped in a checked-statement
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = Me.mbytFlag = 1
				If flag Then
					Me.mclsTBHHThemAll = Nothing
					Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
					Me.sRefesh_ListBox()
				Else
					flag = Me.mbytFlag = 2
					If flag Then
						Dim array As DataColumn() = New DataColumn(0) {}
						flag = Me.lstHanghoaThemAll.Items.Count = 0
						If flag Then
							Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
							Me.mclsTBHHThemAll.Rows.Clear()
						End If
						flag = Me.mclsTBHHThemAll Is Nothing
						If flag Then
							Return b
						End If
						Dim num As Integer = 0
						Dim num2 As Integer = Me.mArrstrMAHH.Length - 1
						Dim num3 As Integer = num
						While True
							Dim num4 As Integer = num3
							Dim num5 As Integer = num2
							If num4 > num5 Then
								Exit For
							End If
							array(0) = Me.mclsTBHHThemAll.Columns("OBJID")
							Me.mclsTBHHThemAll.PrimaryKey = array
							Dim dataRow As DataRow = Me.mclsTBHHThemAll.Rows.Find(Me.mArrstrMAHH(num3).Trim())
							flag = dataRow IsNot Nothing
							If Not flag Then
								Me.mclsTBHHThemAll.Rows.Add(New Object() { Me.mArrstrMAHH(num3).Trim(), Me.mArrstrTENHH(num3).Trim() })
							End If
							num3 += 1
						End While
						Me.sRefesh_ListBox()
					Else
						flag = Me.mbytFlag = 3
						If flag Then
							Dim flag2 As Boolean = False
							Dim num6 As Integer = 0
							Dim num7 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
							Dim num8 As Integer = num6
							While True
								Dim num9 As Integer = num8
								Dim num5 As Integer = num7
								If num9 > num5 Then
									GoTo IL_01C5
								End If
								flag = Me.lstHanghoaThemAll.GetSelected(num8)
								If flag Then
									Exit For
								End If
								num8 += 1
							End While
							flag2 = True
							IL_01C5:
							flag = flag2
							If flag Then
								Try
									Dim num10 As Integer = 0
									Dim num11 As Integer = 0
									Dim num12 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
									num8 = num11
									While True
										Dim num13 As Integer = num8
										Dim num5 As Integer = num12
										If num13 > num5 Then
											Exit For
										End If
										flag = Me.lstHanghoaThemAll.GetSelected(num8)
										If flag Then
											num10 += 1
										End If
										num8 += 1
									End While
									Dim array2 As DataRow() = New DataRow(num10 + 1 - 1) {}
									num10 = 0
									Dim num14 As Integer = 0
									Dim num15 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
									num8 = num14
									While True
										Dim num16 As Integer = num8
										Dim num5 As Integer = num15
										If num16 > num5 Then
											Exit For
										End If
										flag = Me.lstHanghoaThemAll.GetSelected(num8)
										If flag Then
											Dim dataRowView As DataRowView = CType(Me.lstHanghoaThemAll.Items(num8), DataRowView)
											Dim row As DataRow = dataRowView.Row
											array2(num10) = row
											num10 += 1
										End If
										num8 += 1
									End While
									Dim num17 As Integer = 0
									Dim num18 As Integer = num10
									num8 = num17
									While True
										Dim num19 As Integer = num8
										Dim num5 As Integer = num18
										If num19 > num5 Then
											Exit For
										End If
										Me.mclsTBHHThemAll.Rows.Remove(array2(num8))
										num8 += 1
									End While
								Catch ex As Exception
								End Try
								Me.lstHanghoaThemAll.DataSource = Nothing
								Me.sRefesh_ListBox()
							Else
								Me.lstHanghoaThemAll.DataSource = Nothing
							End If
						Else
							flag = Me.mbytFlag = 4
							If flag Then
								Me.mclsTBHHThemAll.Clear()
								Me.lstHanghoaThemAll.DataSource = Nothing
							End If
						End If
					End If
				End If
				b = 1
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4ListBox ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000FB6 RID: 4022 RVA: 0x000BADAC File Offset: 0x000B8FAC
		Private Sub sRefesh_ListBox()
			Try
				Dim lstHanghoaThemAll As ListBox = Me.lstHanghoaThemAll
				lstHanghoaThemAll.DataSource = Me.mclsTBHHThemAll
				lstHanghoaThemAll.DisplayMember = "OBJNAME"
				lstHanghoaThemAll.ValueMember = "OBJID"
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sRefesh_ListBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FB7 RID: 4023 RVA: 0x000BAE60 File Offset: 0x000B9060
		Private Sub sAdd()
			' The following expression was wrapped in a checked-statement
			Try
				Dim num As Integer = 0
				Dim num2 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
				Dim num3 As Integer = num
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						Exit For
					End If
					Dim text As String = Conversions.ToString(NewLateBinding.LateIndexGet(Me.lstHanghoaThemAll.Items(num3), New Object() { "OBJID" }, Nothing))
					Me.mbytSuccess = Me.fAddNew(Me.mStrOBJID, Strings.Trim(text), Strings.Trim(text))
					num3 += 1
				End While
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sAdd ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FB8 RID: 4024 RVA: 0x000BAF60 File Offset: 0x000B9160
		Private Function fGetNameHH(strMAHH As String) As String
			Dim array As DataColumn() = New DataColumn(0) {}
			Dim text As String = ""
			Try
				Me.mclsTemp = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
				array(0) = Me.mclsTemp.Columns("OBJID")
				Me.mclsTemp.PrimaryKey = array
				Dim dataRow As DataRow = Me.mclsTemp.Rows.Find(strMAHH)
				Dim text2 As String = dataRow("OBJNAME").ToString()
				text = text2
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetNameHH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return text
		End Function

		' Token: 0x06000FB9 RID: 4025 RVA: 0x000BB064 File Offset: 0x000B9264
		Private Sub sDisplay_Moddelete()
			Dim dataSet As DataSet = New DataSet()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADNKM"
				array(0).Value = Me.mStrOBJID
				Dim num As Integer
				dataSet = New clsMyDataset(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM4_GET_DATA", num)
				Dim flag As Boolean = Me.lstHanghoaThemAll.Items.Count = 0
				If flag Then
					Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
					Me.mclsTBHHThemAll.Rows.Clear()
				End If
				Dim num2 As Integer = dataSet.Tables(0).Rows.Count
				Dim array2 As String() = New String(num2 + 1 - 1) {}
				Dim num3 As Integer = 0
				Dim num4 As Integer = dataSet.Tables(0).Rows.Count - 1
				num2 = num3
				While True
					Dim num5 As Integer = num2
					Dim num6 As Integer = num4
					If num5 > num6 Then
						Exit For
					End If
					array2(num2) = Conversions.ToString(dataSet.Tables(0).Rows(num2)("MAHHSALE"))
					Dim text As String = array2(num2)
					Dim text2 As String = Me.fGetNameHH(Strings.Trim(text))
					Me.mclsTBHHThemAll.Rows.Add(New Object() { Strings.Trim(text), Strings.Trim(text2) })
					num2 += 1
				End While
				Me.sRefesh_ListBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sDisplay_Moddelete ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FBA RID: 4026 RVA: 0x000BB260 File Offset: 0x000B9460
		Private Sub btnGoBoAll_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytFlag = 4
				Me.fGetData_4ListBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnGobo_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0400068E RID: 1678
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000690 RID: 1680
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000691 RID: 1681
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000692 RID: 1682
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000693 RID: 1683
		<AccessedThroughProperty("btnThemAll")>
		Private _btnThemAll As Button

		' Token: 0x04000694 RID: 1684
		<AccessedThroughProperty("btnThem1MH")>
		Private _btnThem1MH As Button

		' Token: 0x04000695 RID: 1685
		<AccessedThroughProperty("btnGobo")>
		Private _btnGobo As Button

		' Token: 0x04000696 RID: 1686
		<AccessedThroughProperty("lstHanghoaThemAll")>
		Private _lstHanghoaThemAll As ListBox

		' Token: 0x04000697 RID: 1687
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000698 RID: 1688
		<AccessedThroughProperty("btnGoBoAll")>
		Private _btnGoBoAll As Button

		' Token: 0x04000699 RID: 1689
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x0400069A RID: 1690
		Private mArrStrFrmMess As String()

		' Token: 0x0400069B RID: 1691
		Private mbytFormStatus As Byte

		' Token: 0x0400069C RID: 1692
		Private mbytSuccess As Byte

		' Token: 0x0400069D RID: 1693
		Private mStrFilter As String

		' Token: 0x0400069E RID: 1694
		Private mStrOBJID As String

		' Token: 0x0400069F RID: 1695
		Private mStrMAHHSALE As String

		' Token: 0x040006A0 RID: 1696
		Private mStrMAHHSUR As String

		' Token: 0x040006A1 RID: 1697
		Private mclsTBHHThemAll As clsConnect

		' Token: 0x040006A2 RID: 1698
		Private mclsTemp As clsConnect

		' Token: 0x040006A3 RID: 1699
		Private mbytFlag As Byte

		' Token: 0x040006A4 RID: 1700
		Private mArrstrMAHH As String()

		' Token: 0x040006A5 RID: 1701
		Private mArrstrTENHH As String()

		' Token: 0x040006A6 RID: 1702
		Private mbytAllData As Byte

		' Token: 0x040006A7 RID: 1703
		Private mbtySingle As Byte
	End Class
End Namespace
