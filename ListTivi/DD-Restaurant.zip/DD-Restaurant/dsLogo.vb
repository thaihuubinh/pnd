﻿Imports System
Imports System.CodeDom.Compiler
Imports System.Collections
Imports System.ComponentModel
Imports System.ComponentModel.Design
Imports System.Data
Imports System.Diagnostics
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Runtime.Serialization
Imports System.Xml
Imports System.Xml.Schema
Imports System.Xml.Serialization
Imports Microsoft.VisualBasic.CompilerServices

Namespace prjIS_SalesPOS
	' Token: 0x0200000B RID: 11
	<XmlSchemaProvider("GetTypedDataSetSchema")>
	<XmlRoot("dsLogo")>
	<DesignerCategory("code")>
	<ToolboxItem(True)>
	<GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")>
	<HelpKeyword("vs.data.DataSet")>
	<Serializable()>
	Public Class dsLogo
		Inherits DataSet

		' Token: 0x060001D2 RID: 466 RVA: 0x0001D368 File Offset: 0x0001B568
		<DebuggerNonUserCode()>
		Public Sub New()
			dsLogo.__ENCList.Add(New WeakReference(Me))
			Me._schemaSerializationMode = SchemaSerializationMode.IncludeSchema
			Me.BeginInit()
			Me.InitClass()
			Dim collectionChangeEventHandler As CollectionChangeEventHandler = AddressOf Me.SchemaChanged
			AddHandler MyBase.Tables.CollectionChanged, collectionChangeEventHandler
			AddHandler MyBase.Relations.CollectionChanged, collectionChangeEventHandler
			Me.EndInit()
		End Sub

		' Token: 0x060001D3 RID: 467 RVA: 0x0001D3D4 File Offset: 0x0001B5D4
		<DebuggerNonUserCode()>
		Protected Sub New(info As SerializationInfo, context As StreamingContext)
			MyBase.New(info, context, False)
			dsLogo.__ENCList.Add(New WeakReference(Me))
			Me._schemaSerializationMode = SchemaSerializationMode.IncludeSchema
			Dim flag As Boolean = Me.IsBinarySerialized(info, context)
			If flag Then
				Me.InitVars(False)
				Dim collectionChangeEventHandler As CollectionChangeEventHandler = AddressOf Me.SchemaChanged
				AddHandler Me.Tables.CollectionChanged, collectionChangeEventHandler
				AddHandler Me.Relations.CollectionChanged, collectionChangeEventHandler
			Else
				Dim text As String = Conversions.ToString(info.GetValue("XmlSchema", GetType(String)))
				flag = Me.DetermineSchemaSerializationMode(info, context) = SchemaSerializationMode.IncludeSchema
				If flag Then
					Dim dataSet As DataSet = New DataSet()
					dataSet.ReadXmlSchema(New XmlTextReader(New StringReader(text)))
					flag = dataSet.Tables("dtLogo") IsNot Nothing
					If flag Then
						MyBase.Tables.Add(New dsLogo.dtLogoDataTable(dataSet.Tables("dtLogo")))
					End If
					Me.DataSetName = dataSet.DataSetName
					Me.Prefix = dataSet.Prefix
					Me.[Namespace] = dataSet.[Namespace]
					Me.Locale = dataSet.Locale
					Me.CaseSensitive = dataSet.CaseSensitive
					Me.EnforceConstraints = dataSet.EnforceConstraints
					Me.Merge(dataSet, False, MissingSchemaAction.Add)
					Me.InitVars()
				Else
					Me.ReadXmlSchema(New XmlTextReader(New StringReader(text)))
				End If
				Me.GetSerializationData(info, context)
				Dim collectionChangeEventHandler2 As CollectionChangeEventHandler = AddressOf Me.SchemaChanged
				AddHandler MyBase.Tables.CollectionChanged, collectionChangeEventHandler2
				AddHandler Me.Relations.CollectionChanged, collectionChangeEventHandler2
			End If
		End Sub

		' Token: 0x170000D9 RID: 217
		' (get) Token: 0x060001D4 RID: 468 RVA: 0x0001D578 File Offset: 0x0001B778
		<DebuggerNonUserCode()>
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Content)>
		Public ReadOnly Property dtLogo As dsLogo.dtLogoDataTable
			Get
				Return Me.tabledtLogo
			End Get
		End Property

		' Token: 0x170000DA RID: 218
		' (get) Token: 0x060001D5 RID: 469 RVA: 0x0001D590 File Offset: 0x0001B790
		' (set) Token: 0x060001D6 RID: 470 RVA: 0x0000219A File Offset: 0x0000039A
		<DebuggerNonUserCode()>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)>
		<Browsable(True)>
		Public Overrides Property SchemaSerializationMode As SchemaSerializationMode
			Get
				Return Me._schemaSerializationMode
			End Get
			Set(value As SchemaSerializationMode)
				Me._schemaSerializationMode = value
			End Set
		End Property

		' Token: 0x170000DB RID: 219
		' (get) Token: 0x060001D7 RID: 471 RVA: 0x0001D5A8 File Offset: 0x0001B7A8
		<DebuggerNonUserCode()>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Tables As DataTableCollection
			Get
				Return MyBase.Tables
			End Get
		End Property

		' Token: 0x170000DC RID: 220
		' (get) Token: 0x060001D8 RID: 472 RVA: 0x0001D5C0 File Offset: 0x0001B7C0
		<DebuggerNonUserCode()>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Relations As DataRelationCollection
			Get
				Return MyBase.Relations
			End Get
		End Property

		' Token: 0x060001D9 RID: 473 RVA: 0x000021A5 File Offset: 0x000003A5
		<DebuggerNonUserCode()>
		Protected Overrides Sub InitializeDerivedDataSet()
			Me.BeginInit()
			Me.InitClass()
			Me.EndInit()
		End Sub

		' Token: 0x060001DA RID: 474 RVA: 0x0001D5D8 File Offset: 0x0001B7D8
		<DebuggerNonUserCode()>
		Public Overrides Function Clone() As DataSet
			Dim dsLogo As dsLogo = CType(MyBase.Clone(), dsLogo)
			dsLogo.InitVars()
			dsLogo.SchemaSerializationMode = Me.SchemaSerializationMode
			Return dsLogo
		End Function

		' Token: 0x060001DB RID: 475 RVA: 0x0001D60C File Offset: 0x0001B80C
		<DebuggerNonUserCode()>
		Protected Overrides Function ShouldSerializeTables() As Boolean
			Return False
		End Function

		' Token: 0x060001DC RID: 476 RVA: 0x0001D60C File Offset: 0x0001B80C
		<DebuggerNonUserCode()>
		Protected Overrides Function ShouldSerializeRelations() As Boolean
			Return False
		End Function

		' Token: 0x060001DD RID: 477 RVA: 0x0001D620 File Offset: 0x0001B820
		<DebuggerNonUserCode()>
		Protected Overrides Sub ReadXmlSerializable(reader As XmlReader)
			Dim flag As Boolean = Me.DetermineSchemaSerializationMode(reader) = SchemaSerializationMode.IncludeSchema
			If flag Then
				Me.Reset()
				Dim dataSet As DataSet = New DataSet()
				dataSet.ReadXml(reader)
				flag = dataSet.Tables("dtLogo") IsNot Nothing
				If flag Then
					MyBase.Tables.Add(New dsLogo.dtLogoDataTable(dataSet.Tables("dtLogo")))
				End If
				Me.DataSetName = dataSet.DataSetName
				Me.Prefix = dataSet.Prefix
				Me.[Namespace] = dataSet.[Namespace]
				Me.Locale = dataSet.Locale
				Me.CaseSensitive = dataSet.CaseSensitive
				Me.EnforceConstraints = dataSet.EnforceConstraints
				Me.Merge(dataSet, False, MissingSchemaAction.Add)
				Me.InitVars()
			Else
				Me.ReadXml(reader)
				Me.InitVars()
			End If
		End Sub

		' Token: 0x060001DE RID: 478 RVA: 0x0001D704 File Offset: 0x0001B904
		<DebuggerNonUserCode()>
		Protected Overrides Function GetSchemaSerializable() As XmlSchema
			Dim memoryStream As MemoryStream = New MemoryStream()
			Me.WriteXmlSchema(New XmlTextWriter(memoryStream, Nothing))
			memoryStream.Position = 0L
			Return XmlSchema.Read(New XmlTextReader(memoryStream), Nothing)
		End Function

		' Token: 0x060001DF RID: 479 RVA: 0x000021BE File Offset: 0x000003BE
		<DebuggerNonUserCode()>
		Friend Sub InitVars()
			Me.InitVars(True)
		End Sub

		' Token: 0x060001E0 RID: 480 RVA: 0x0001D740 File Offset: 0x0001B940
		<DebuggerNonUserCode()>
		Friend Sub InitVars(initTable As Boolean)
			Me.tabledtLogo = CType(MyBase.Tables("dtLogo"), dsLogo.dtLogoDataTable)
			If initTable Then
				Dim flag As Boolean = Me.tabledtLogo IsNot Nothing
				If flag Then
					Me.tabledtLogo.InitVars()
				End If
			End If
		End Sub

		' Token: 0x060001E1 RID: 481 RVA: 0x0001D790 File Offset: 0x0001B990
		<DebuggerNonUserCode()>
		Private Sub InitClass()
			Me.DataSetName = "dsLogo"
			Me.Prefix = ""
			Me.[Namespace] = "http://tempuri.org/dsLogo.xsd"
			Me.EnforceConstraints = True
			Me.SchemaSerializationMode = SchemaSerializationMode.IncludeSchema
			Me.tabledtLogo = New dsLogo.dtLogoDataTable()
			MyBase.Tables.Add(Me.tabledtLogo)
		End Sub

		' Token: 0x060001E2 RID: 482 RVA: 0x0001D60C File Offset: 0x0001B80C
		<DebuggerNonUserCode()>
		Private Function ShouldSerializedtLogo() As Boolean
			Return False
		End Function

		' Token: 0x060001E3 RID: 483 RVA: 0x0001D7F0 File Offset: 0x0001B9F0
		<DebuggerNonUserCode()>
		Private Sub SchemaChanged(sender As Object, e As CollectionChangeEventArgs)
			Dim flag As Boolean = e.Action = CollectionChangeAction.Remove
			If flag Then
				Me.InitVars()
			End If
		End Sub

		' Token: 0x060001E4 RID: 484 RVA: 0x0001D814 File Offset: 0x0001BA14
		<DebuggerNonUserCode()>
		Public Shared Function GetTypedDataSetSchema(xs As XmlSchemaSet) As XmlSchemaComplexType
			Dim dsLogo As dsLogo = New dsLogo()
			Dim xmlSchemaComplexType As XmlSchemaComplexType = New XmlSchemaComplexType()
			Dim xmlSchemaSequence As XmlSchemaSequence = New XmlSchemaSequence()
			xs.Add(dsLogo.GetSchemaSerializable())
			Dim xmlSchemaAny As XmlSchemaAny = New XmlSchemaAny()
			xmlSchemaAny.[Namespace] = dsLogo.[Namespace]
			xmlSchemaSequence.Items.Add(xmlSchemaAny)
			xmlSchemaComplexType.Particle = xmlSchemaSequence
			Return xmlSchemaComplexType
		End Function

		' Token: 0x040000E6 RID: 230
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040000E7 RID: 231
		Private tabledtLogo As dsLogo.dtLogoDataTable

		' Token: 0x040000E8 RID: 232
		Private _schemaSerializationMode As SchemaSerializationMode

		' Token: 0x0200000C RID: 12
		' (Invoke) Token: 0x060001E8 RID: 488
		Public Delegate Sub dtLogoRowChangeEventHandler(sender As Object, e As dsLogo.dtLogoRowChangeEvent)

		' Token: 0x0200000D RID: 13
		<GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")>
		<XmlSchemaProvider("GetTypedTableSchema")>
		<Serializable()>
		Public Class dtLogoDataTable
			Inherits DataTable
			Implements IEnumerable

			' Token: 0x060001EA RID: 490 RVA: 0x000021D7 File Offset: 0x000003D7
			<DebuggerNonUserCode()>
			Public Sub New()
				dsLogo.dtLogoDataTable.__ENCList.Add(New WeakReference(Me))
				Me.TableName = "dtLogo"
				Me.BeginInit()
				Me.InitClass()
				Me.EndInit()
			End Sub

			' Token: 0x060001EB RID: 491 RVA: 0x0001D874 File Offset: 0x0001BA74
			<DebuggerNonUserCode()>
			Friend Sub New(table As DataTable)
				dsLogo.dtLogoDataTable.__ENCList.Add(New WeakReference(Me))
				Me.TableName = table.TableName
				Dim flag As Boolean = table.CaseSensitive <> table.DataSet.CaseSensitive
				If flag Then
					Me.CaseSensitive = table.CaseSensitive
				End If
				flag = Operators.CompareString(table.Locale.ToString(), table.DataSet.Locale.ToString(), False) <> 0
				If flag Then
					Me.Locale = table.Locale
				End If
				flag = Operators.CompareString(table.[Namespace], table.DataSet.[Namespace], False) <> 0
				If flag Then
					Me.[Namespace] = table.[Namespace]
				End If
				Me.Prefix = table.Prefix
				Me.MinimumCapacity = table.MinimumCapacity
			End Sub

			' Token: 0x060001EC RID: 492 RVA: 0x00002214 File Offset: 0x00000414
			<DebuggerNonUserCode()>
			Protected Sub New(info As SerializationInfo, context As StreamingContext)
				MyBase.New(info, context)
				dsLogo.dtLogoDataTable.__ENCList.Add(New WeakReference(Me))
				Me.InitVars()
			End Sub

			' Token: 0x170000DD RID: 221
			' (get) Token: 0x060001ED RID: 493 RVA: 0x0001D954 File Offset: 0x0001BB54
			<DebuggerNonUserCode()>
			Public ReadOnly Property LOGOColumn As DataColumn
				Get
					Return Me.columnLOGO
				End Get
			End Property

			' Token: 0x170000DE RID: 222
			' (get) Token: 0x060001EE RID: 494 RVA: 0x0001D96C File Offset: 0x0001BB6C
			<Browsable(False)>
			<DebuggerNonUserCode()>
			Public ReadOnly Property Count As Integer
				Get
					Return Me.Rows.Count
				End Get
			End Property

			' Token: 0x170000DF RID: 223
			<DebuggerNonUserCode()>
			Public ReadOnly Default Property Item(index As Integer) As dsLogo.dtLogoRow
				Get
					Return CType(Me.Rows(index), dsLogo.dtLogoRow)
				End Get
			End Property

			' Token: 0x14000001 RID: 1
			' (add) Token: 0x060001F0 RID: 496 RVA: 0x00002239 File Offset: 0x00000439
			' (remove) Token: 0x060001F1 RID: 497 RVA: 0x00002253 File Offset: 0x00000453
			<DebuggerNonUserCode()>
			Public Event dtLogoRowChanging As dsLogo.dtLogoRowChangeEventHandler

			' Token: 0x14000002 RID: 2
			' (add) Token: 0x060001F2 RID: 498 RVA: 0x0000226D File Offset: 0x0000046D
			' (remove) Token: 0x060001F3 RID: 499 RVA: 0x00002287 File Offset: 0x00000487
			<DebuggerNonUserCode()>
			Public Event dtLogoRowChanged As dsLogo.dtLogoRowChangeEventHandler

			' Token: 0x14000003 RID: 3
			' (add) Token: 0x060001F4 RID: 500 RVA: 0x000022A1 File Offset: 0x000004A1
			' (remove) Token: 0x060001F5 RID: 501 RVA: 0x000022BB File Offset: 0x000004BB
			<DebuggerNonUserCode()>
			Public Event dtLogoRowDeleting As dsLogo.dtLogoRowChangeEventHandler

			' Token: 0x14000004 RID: 4
			' (add) Token: 0x060001F6 RID: 502 RVA: 0x000022D5 File Offset: 0x000004D5
			' (remove) Token: 0x060001F7 RID: 503 RVA: 0x000022EF File Offset: 0x000004EF
			<DebuggerNonUserCode()>
			Public Event dtLogoRowDeleted As dsLogo.dtLogoRowChangeEventHandler

			' Token: 0x060001F8 RID: 504 RVA: 0x00002309 File Offset: 0x00000509
			<DebuggerNonUserCode()>
			Public Sub AdddtLogoRow(row As dsLogo.dtLogoRow)
				Me.Rows.Add(row)
			End Sub

			' Token: 0x060001F9 RID: 505 RVA: 0x0001D9B0 File Offset: 0x0001BBB0
			<DebuggerNonUserCode()>
			Public Function AdddtLogoRow(LOGO As Byte()) As dsLogo.dtLogoRow
				Dim dtLogoRow As dsLogo.dtLogoRow = CType(Me.NewRow(), dsLogo.dtLogoRow)
				dtLogoRow.ItemArray = New Object() { LOGO }
				Me.Rows.Add(dtLogoRow)
				Return dtLogoRow
			End Function

			' Token: 0x060001FA RID: 506 RVA: 0x0001D9F0 File Offset: 0x0001BBF0
			<DebuggerNonUserCode()>
			Public Overridable Function GetEnumerator() As IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
				Return Me.Rows.GetEnumerator()
			End Function

			' Token: 0x060001FB RID: 507 RVA: 0x0001DA10 File Offset: 0x0001BC10
			<DebuggerNonUserCode()>
			Public Overrides Function Clone() As DataTable
				Dim dtLogoDataTable As dsLogo.dtLogoDataTable = CType(MyBase.Clone(), dsLogo.dtLogoDataTable)
				dtLogoDataTable.InitVars()
				Return dtLogoDataTable
			End Function

			' Token: 0x060001FC RID: 508 RVA: 0x0001DA38 File Offset: 0x0001BC38
			<DebuggerNonUserCode()>
			Protected Overrides Function CreateInstance() As DataTable
				Return New dsLogo.dtLogoDataTable()
			End Function

			' Token: 0x060001FD RID: 509 RVA: 0x0000231A File Offset: 0x0000051A
			<DebuggerNonUserCode()>
			Friend Sub InitVars()
				Me.columnLOGO = MyBase.Columns("LOGO")
			End Sub

			' Token: 0x060001FE RID: 510 RVA: 0x00002334 File Offset: 0x00000534
			<DebuggerNonUserCode()>
			Private Sub InitClass()
				Me.columnLOGO = New DataColumn("LOGO", GetType(Byte()), Nothing, MappingType.Element)
				MyBase.Columns.Add(Me.columnLOGO)
			End Sub

			' Token: 0x060001FF RID: 511 RVA: 0x0001DA50 File Offset: 0x0001BC50
			<DebuggerNonUserCode()>
			Public Function NewdtLogoRow() As dsLogo.dtLogoRow
				Return CType(Me.NewRow(), dsLogo.dtLogoRow)
			End Function

			' Token: 0x06000200 RID: 512 RVA: 0x0001DA70 File Offset: 0x0001BC70
			<DebuggerNonUserCode()>
			Protected Overrides Function NewRowFromBuilder(builder As DataRowBuilder) As DataRow
				Return New dsLogo.dtLogoRow(builder)
			End Function

			' Token: 0x06000201 RID: 513 RVA: 0x0001DA88 File Offset: 0x0001BC88
			<DebuggerNonUserCode()>
			Protected Overrides Function GetRowType() As Type
				Return GetType(dsLogo.dtLogoRow)
			End Function

			' Token: 0x06000202 RID: 514 RVA: 0x0001DAA4 File Offset: 0x0001BCA4
			<DebuggerNonUserCode()>
			Protected Overrides Sub OnRowChanged(e As DataRowChangeEventArgs)
				MyBase.OnRowChanged(e)
				Dim flag As Boolean = Me.dtLogoRowChangedEvent IsNot Nothing
				If flag Then
					Dim dtLogoRowChangeEventHandler As dsLogo.dtLogoRowChangeEventHandler = Me.dtLogoRowChangedEvent
					flag = dtLogoRowChangeEventHandler IsNot Nothing
					If flag Then
						dtLogoRowChangeEventHandler(Me, New dsLogo.dtLogoRowChangeEvent(CType(e.Row, dsLogo.dtLogoRow), e.Action))
					End If
				End If
			End Sub

			' Token: 0x06000203 RID: 515 RVA: 0x0001DAFC File Offset: 0x0001BCFC
			<DebuggerNonUserCode()>
			Protected Overrides Sub OnRowChanging(e As DataRowChangeEventArgs)
				MyBase.OnRowChanging(e)
				Dim flag As Boolean = Me.dtLogoRowChangingEvent IsNot Nothing
				If flag Then
					Dim dtLogoRowChangeEventHandler As dsLogo.dtLogoRowChangeEventHandler = Me.dtLogoRowChangingEvent
					flag = dtLogoRowChangeEventHandler IsNot Nothing
					If flag Then
						dtLogoRowChangeEventHandler(Me, New dsLogo.dtLogoRowChangeEvent(CType(e.Row, dsLogo.dtLogoRow), e.Action))
					End If
				End If
			End Sub

			' Token: 0x06000204 RID: 516 RVA: 0x0001DB54 File Offset: 0x0001BD54
			<DebuggerNonUserCode()>
			Protected Overrides Sub OnRowDeleted(e As DataRowChangeEventArgs)
				MyBase.OnRowDeleted(e)
				Dim flag As Boolean = Me.dtLogoRowDeletedEvent IsNot Nothing
				If flag Then
					Dim dtLogoRowChangeEventHandler As dsLogo.dtLogoRowChangeEventHandler = Me.dtLogoRowDeletedEvent
					flag = dtLogoRowChangeEventHandler IsNot Nothing
					If flag Then
						dtLogoRowChangeEventHandler(Me, New dsLogo.dtLogoRowChangeEvent(CType(e.Row, dsLogo.dtLogoRow), e.Action))
					End If
				End If
			End Sub

			' Token: 0x06000205 RID: 517 RVA: 0x0001DBAC File Offset: 0x0001BDAC
			<DebuggerNonUserCode()>
			Protected Overrides Sub OnRowDeleting(e As DataRowChangeEventArgs)
				MyBase.OnRowDeleting(e)
				Dim flag As Boolean = Me.dtLogoRowDeletingEvent IsNot Nothing
				If flag Then
					Dim dtLogoRowChangeEventHandler As dsLogo.dtLogoRowChangeEventHandler = Me.dtLogoRowDeletingEvent
					flag = dtLogoRowChangeEventHandler IsNot Nothing
					If flag Then
						dtLogoRowChangeEventHandler(Me, New dsLogo.dtLogoRowChangeEvent(CType(e.Row, dsLogo.dtLogoRow), e.Action))
					End If
				End If
			End Sub

			' Token: 0x06000206 RID: 518 RVA: 0x00002366 File Offset: 0x00000566
			<DebuggerNonUserCode()>
			Public Sub RemovedtLogoRow(row As dsLogo.dtLogoRow)
				Me.Rows.Remove(row)
			End Sub

			' Token: 0x06000207 RID: 519 RVA: 0x0001DC04 File Offset: 0x0001BE04
			<DebuggerNonUserCode()>
			Public Shared Function GetTypedTableSchema(xs As XmlSchemaSet) As XmlSchemaComplexType
				Dim xmlSchemaComplexType As XmlSchemaComplexType = New XmlSchemaComplexType()
				Dim xmlSchemaSequence As XmlSchemaSequence = New XmlSchemaSequence()
				Dim dsLogo As dsLogo = New dsLogo()
				xs.Add(dsLogo.GetSchemaSerializable())
				Dim xmlSchemaAny As XmlSchemaAny = New XmlSchemaAny()
				xmlSchemaAny.[Namespace] = "http://www.w3.org/2001/XMLSchema"
				Dim xmlSchemaParticle As XmlSchemaParticle = xmlSchemaAny
				Dim num As Decimal = 0D
				xmlSchemaParticle.MinOccurs = num
				xmlSchemaAny.MaxOccurs = Decimal.MaxValue
				xmlSchemaAny.ProcessContents = XmlSchemaContentProcessing.Lax
				xmlSchemaSequence.Items.Add(xmlSchemaAny)
				Dim xmlSchemaAny2 As XmlSchemaAny = New XmlSchemaAny()
				xmlSchemaAny2.[Namespace] = "urn:schemas-microsoft-com:xml-diffgram-v1"
				Dim xmlSchemaParticle2 As XmlSchemaParticle = xmlSchemaAny2
				num = 1D
				xmlSchemaParticle2.MinOccurs = num
				xmlSchemaAny2.ProcessContents = XmlSchemaContentProcessing.Lax
				xmlSchemaSequence.Items.Add(xmlSchemaAny2)
				Dim xmlSchemaAttribute As XmlSchemaAttribute = New XmlSchemaAttribute()
				xmlSchemaAttribute.Name = "namespace"
				xmlSchemaAttribute.FixedValue = dsLogo.[Namespace]
				xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute)
				Dim xmlSchemaAttribute2 As XmlSchemaAttribute = New XmlSchemaAttribute()
				xmlSchemaAttribute2.Name = "tableTypeName"
				xmlSchemaAttribute2.FixedValue = "dtLogoDataTable"
				xmlSchemaComplexType.Attributes.Add(xmlSchemaAttribute2)
				xmlSchemaComplexType.Particle = xmlSchemaSequence
				Return xmlSchemaComplexType
			End Function

			' Token: 0x040000E9 RID: 233
			Private Shared __ENCList As ArrayList = New ArrayList()

			' Token: 0x040000EA RID: 234
			Private columnLOGO As DataColumn
		End Class

		' Token: 0x0200000E RID: 14
		<GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")>
		Public Class dtLogoRow
			Inherits DataRow

			' Token: 0x06000208 RID: 520 RVA: 0x00002377 File Offset: 0x00000577
			<DebuggerNonUserCode()>
			Friend Sub New(rb As DataRowBuilder)
				MyBase.New(rb)
				Me.tabledtLogo = CType(Me.Table, dsLogo.dtLogoDataTable)
			End Sub

			' Token: 0x170000E0 RID: 224
			' (get) Token: 0x06000209 RID: 521 RVA: 0x0001DD3C File Offset: 0x0001BF3C
			' (set) Token: 0x0600020A RID: 522 RVA: 0x00002394 File Offset: 0x00000594
			<DebuggerNonUserCode()>
			Public Property LOGO As Byte()
				Get
					Dim array As Byte()
					Try
						array = CType(Me(Me.tabledtLogo.LOGOColumn), Byte())
					Catch ex As InvalidCastException
						Throw New StrongTypingException("The value for column 'LOGO' in table 'dtLogo' is DBNull.", ex)
					End Try
					Return array
				End Get
				Set(value As Byte())
					Me(Me.tabledtLogo.LOGOColumn) = value
				End Set
			End Property

			' Token: 0x0600020B RID: 523 RVA: 0x0001DD94 File Offset: 0x0001BF94
			<DebuggerNonUserCode()>
			Public Function IsLOGONull() As Boolean
				Return Me.IsNull(Me.tabledtLogo.LOGOColumn)
			End Function

			' Token: 0x0600020C RID: 524 RVA: 0x000023AB File Offset: 0x000005AB
			<DebuggerNonUserCode()>
			Public Sub SetLOGONull()
				Me(Me.tabledtLogo.LOGOColumn) = RuntimeHelpers.GetObjectValue(Convert.DBNull)
			End Sub

			' Token: 0x040000EF RID: 239
			Private tabledtLogo As dsLogo.dtLogoDataTable
		End Class

		' Token: 0x0200000F RID: 15
		<GeneratedCode("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")>
		Public Class dtLogoRowChangeEvent
			Inherits EventArgs

			' Token: 0x0600020D RID: 525 RVA: 0x000023CB File Offset: 0x000005CB
			<DebuggerNonUserCode()>
			Public Sub New(row As dsLogo.dtLogoRow, action As DataRowAction)
				Me.eventRow = row
				Me.eventAction = action
			End Sub

			' Token: 0x170000E1 RID: 225
			' (get) Token: 0x0600020E RID: 526 RVA: 0x0001DDB8 File Offset: 0x0001BFB8
			<DebuggerNonUserCode()>
			Public ReadOnly Property Row As dsLogo.dtLogoRow
				Get
					Return Me.eventRow
				End Get
			End Property

			' Token: 0x170000E2 RID: 226
			' (get) Token: 0x0600020F RID: 527 RVA: 0x0001DDD0 File Offset: 0x0001BFD0
			<DebuggerNonUserCode()>
			Public ReadOnly Property Action As DataRowAction
				Get
					Return Me.eventAction
				End Get
			End Property

			' Token: 0x040000F0 RID: 240
			Private eventRow As dsLogo.dtLogoRow

			' Token: 0x040000F1 RID: 241
			Private eventAction As DataRowAction
		End Class
	End Class
End Namespace
