﻿Namespace prjIS_SalesPOS
	' Token: 0x02000054 RID: 84
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMKH2
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600190B RID: 6411 RVA: 0x001371D4 File Offset: 0x001353D4
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600190C RID: 6412 RVA: 0x0013720C File Offset: 0x0013540C
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMKH2))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.lblOBJNAME = New Global.System.Windows.Forms.Label()
			Me.txtOBJNAME = New Global.System.Windows.Forms.TextBox()
			Me.txtOBJID = New Global.System.Windows.Forms.TextBox()
			Me.lblOBJID = New Global.System.Windows.Forms.Label()
			Me.lblEMAIL = New Global.System.Windows.Forms.Label()
			Me.txtADDRESS = New Global.System.Windows.Forms.TextBox()
			Me.txtTEL = New Global.System.Windows.Forms.TextBox()
			Me.txtCONTACT = New Global.System.Windows.Forms.TextBox()
			Me.txtFAX = New Global.System.Windows.Forms.TextBox()
			Me.txtEMAIL = New Global.System.Windows.Forms.TextBox()
			Me.lblADDRESS = New Global.System.Windows.Forms.Label()
			Me.lblTEL = New Global.System.Windows.Forms.Label()
			Me.lblCONTACT = New Global.System.Windows.Forms.Label()
			Me.lblFAX = New Global.System.Windows.Forms.Label()
			Me.txtGHICHU = New Global.System.Windows.Forms.TextBox()
			Me.lblGHICHU = New Global.System.Windows.Forms.Label()
			Me.txt = New Global.System.Windows.Forms.TextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.txtSUBOBJNAME = New Global.System.Windows.Forms.TextBox()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(575, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 526)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 7
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnKeyboard, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 2)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 6
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 505)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 255)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(107, 78)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 6
			Me.btnFilter.Tag = "CR0005"
			Me.btnFilter.Text = "Lọ&c"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 423)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 79)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 87)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(107, 78)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 4
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 339)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(107, 78)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 7
			Me.btnFind.Tag = "CR0006"
			Me.btnFind.Text = "&Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 171)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 78)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 5
			Me.btnDelete.Tag = "CR0004"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.lblOBJNAME.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJNAME As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			point = New Global.System.Drawing.Point(7, 37)
			lblOBJNAME.Location = point
			Me.lblOBJNAME.Name = "lblOBJNAME"
			Dim lblOBJNAME2 As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			size = New Global.System.Drawing.Size(154, 21)
			lblOBJNAME2.Size = size
			Me.lblOBJNAME.TabIndex = 34
			Me.lblOBJNAME.Tag = "CR0008"
			Me.lblOBJNAME.Text = "Tên "
			Me.txtOBJNAME.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJNAME As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			point = New Global.System.Drawing.Point(169, 36)
			txtOBJNAME.Location = point
			Me.txtOBJNAME.Name = "txtOBJNAME"
			Dim txtOBJNAME2 As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			size = New Global.System.Drawing.Size(400, 22)
			txtOBJNAME2.Size = size
			Me.txtOBJNAME.TabIndex = 1
			Me.txtOBJNAME.Tag = "0R0000"
			Me.txtOBJID.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJID As Global.System.Windows.Forms.Control = Me.txtOBJID
			point = New Global.System.Drawing.Point(169, 8)
			txtOBJID.Location = point
			Me.txtOBJID.Name = "txtOBJID"
			Dim txtOBJID2 As Global.System.Windows.Forms.Control = Me.txtOBJID
			size = New Global.System.Drawing.Size(122, 22)
			txtOBJID2.Size = size
			Me.txtOBJID.TabIndex = 0
			Me.txtOBJID.Tag = "0R0000"
			Me.lblOBJID.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJID As Global.System.Windows.Forms.Control = Me.lblOBJID
			point = New Global.System.Drawing.Point(7, 9)
			lblOBJID.Location = point
			Me.lblOBJID.Name = "lblOBJID"
			Dim lblOBJID2 As Global.System.Windows.Forms.Control = Me.lblOBJID
			size = New Global.System.Drawing.Size(154, 21)
			lblOBJID2.Size = size
			Me.lblOBJID.TabIndex = 33
			Me.lblOBJID.Tag = "CR0007"
			Me.lblOBJID.Text = "Mã"
			Me.lblEMAIL.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblEMAIL As Global.System.Windows.Forms.Control = Me.lblEMAIL
			point = New Global.System.Drawing.Point(7, 203)
			lblEMAIL.Location = point
			Me.lblEMAIL.Name = "lblEMAIL"
			Dim lblEMAIL2 As Global.System.Windows.Forms.Control = Me.lblEMAIL
			size = New Global.System.Drawing.Size(154, 21)
			lblEMAIL2.Size = size
			Me.lblEMAIL.TabIndex = 39
			Me.lblEMAIL.Tag = "CR0038"
			Me.lblEMAIL.Text = "Email"
			Me.txtADDRESS.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtADDRESS As Global.System.Windows.Forms.Control = Me.txtADDRESS
			point = New Global.System.Drawing.Point(169, 92)
			txtADDRESS.Location = point
			Me.txtADDRESS.Name = "txtADDRESS"
			Dim txtADDRESS2 As Global.System.Windows.Forms.Control = Me.txtADDRESS
			size = New Global.System.Drawing.Size(400, 22)
			txtADDRESS2.Size = size
			Me.txtADDRESS.TabIndex = 3
			Me.txtADDRESS.Tag = "0R0000"
			Me.txtTEL.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtTEL As Global.System.Windows.Forms.Control = Me.txtTEL
			point = New Global.System.Drawing.Point(169, 120)
			txtTEL.Location = point
			Me.txtTEL.Name = "txtTEL"
			Dim txtTEL2 As Global.System.Windows.Forms.Control = Me.txtTEL
			size = New Global.System.Drawing.Size(400, 22)
			txtTEL2.Size = size
			Me.txtTEL.TabIndex = 4
			Me.txtTEL.Tag = "0R0000"
			Me.txtCONTACT.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtCONTACT As Global.System.Windows.Forms.Control = Me.txtCONTACT
			point = New Global.System.Drawing.Point(169, 176)
			txtCONTACT.Location = point
			Me.txtCONTACT.Name = "txtCONTACT"
			Dim txtCONTACT2 As Global.System.Windows.Forms.Control = Me.txtCONTACT
			size = New Global.System.Drawing.Size(400, 22)
			txtCONTACT2.Size = size
			Me.txtCONTACT.TabIndex = 6
			Me.txtCONTACT.Tag = "0R0000"
			Me.txtFAX.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtFAX As Global.System.Windows.Forms.Control = Me.txtFAX
			point = New Global.System.Drawing.Point(169, 148)
			txtFAX.Location = point
			Me.txtFAX.Name = "txtFAX"
			Dim txtFAX2 As Global.System.Windows.Forms.Control = Me.txtFAX
			size = New Global.System.Drawing.Size(400, 22)
			txtFAX2.Size = size
			Me.txtFAX.TabIndex = 5
			Me.txtFAX.Tag = "0R0000"
			Me.txtEMAIL.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtEMAIL As Global.System.Windows.Forms.Control = Me.txtEMAIL
			point = New Global.System.Drawing.Point(169, 204)
			txtEMAIL.Location = point
			Me.txtEMAIL.Name = "txtEMAIL"
			Dim txtEMAIL2 As Global.System.Windows.Forms.Control = Me.txtEMAIL
			size = New Global.System.Drawing.Size(400, 22)
			txtEMAIL2.Size = size
			Me.txtEMAIL.TabIndex = 7
			Me.txtEMAIL.Tag = "0R0000"
			Me.lblADDRESS.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblADDRESS As Global.System.Windows.Forms.Control = Me.lblADDRESS
			point = New Global.System.Drawing.Point(7, 91)
			lblADDRESS.Location = point
			Me.lblADDRESS.Name = "lblADDRESS"
			Dim lblADDRESS2 As Global.System.Windows.Forms.Control = Me.lblADDRESS
			size = New Global.System.Drawing.Size(154, 21)
			lblADDRESS2.Size = size
			Me.lblADDRESS.TabIndex = 54
			Me.lblADDRESS.Tag = "CR0032"
			Me.lblADDRESS.Text = "Địa chỉ"
			Me.lblTEL.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblTEL As Global.System.Windows.Forms.Control = Me.lblTEL
			point = New Global.System.Drawing.Point(7, 119)
			lblTEL.Location = point
			Me.lblTEL.Name = "lblTEL"
			Dim lblTEL2 As Global.System.Windows.Forms.Control = Me.lblTEL
			size = New Global.System.Drawing.Size(154, 21)
			lblTEL2.Size = size
			Me.lblTEL.TabIndex = 55
			Me.lblTEL.Tag = "CR0033"
			Me.lblTEL.Text = "Điện thoại bàn"
			Me.lblCONTACT.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblCONTACT As Global.System.Windows.Forms.Control = Me.lblCONTACT
			point = New Global.System.Drawing.Point(7, 176)
			lblCONTACT.Location = point
			Me.lblCONTACT.Name = "lblCONTACT"
			Dim lblCONTACT2 As Global.System.Windows.Forms.Control = Me.lblCONTACT
			size = New Global.System.Drawing.Size(154, 21)
			lblCONTACT2.Size = size
			Me.lblCONTACT.TabIndex = 57
			Me.lblCONTACT.Tag = "CR0035"
			Me.lblCONTACT.Text = "Tên người liên hệ"
			Me.lblFAX.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFAX As Global.System.Windows.Forms.Control = Me.lblFAX
			point = New Global.System.Drawing.Point(7, 148)
			lblFAX.Location = point
			Me.lblFAX.Name = "lblFAX"
			Dim lblFAX2 As Global.System.Windows.Forms.Control = Me.lblFAX
			size = New Global.System.Drawing.Size(154, 21)
			lblFAX2.Size = size
			Me.lblFAX.TabIndex = 59
			Me.lblFAX.Tag = "CR0037"
			Me.lblFAX.Text = "Fax"
			Dim txtGHICHU As Global.System.Windows.Forms.Control = Me.txtGHICHU
			point = New Global.System.Drawing.Point(169, 232)
			txtGHICHU.Location = point
			Me.txtGHICHU.Multiline = True
			Me.txtGHICHU.Name = "txtGHICHU"
			Dim txtGHICHU2 As Global.System.Windows.Forms.Control = Me.txtGHICHU
			size = New Global.System.Drawing.Size(400, 70)
			txtGHICHU2.Size = size
			Me.txtGHICHU.TabIndex = 8
			Me.lblGHICHU.AutoSize = True
			Dim lblGHICHU As Global.System.Windows.Forms.Control = Me.lblGHICHU
			point = New Global.System.Drawing.Point(7, 250)
			lblGHICHU.Location = point
			Me.lblGHICHU.Name = "lblGHICHU"
			Dim lblGHICHU2 As Global.System.Windows.Forms.Control = Me.lblGHICHU
			size = New Global.System.Drawing.Size(53, 16)
			lblGHICHU2.Size = size
			Me.lblGHICHU.TabIndex = 64
			Me.lblGHICHU.Tag = "CR0040"
			Me.lblGHICHU.Text = "Ghi chú"
			Me.txt.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txt As Global.System.Windows.Forms.Control = Me.txt
			point = New Global.System.Drawing.Point(353, 347)
			txt.Location = point
			Me.txt.Name = "txt"
			Dim txt2 As Global.System.Windows.Forms.Control = Me.txt
			size = New Global.System.Drawing.Size(104, 22)
			txt2.Size = size
			Me.txt.TabIndex = 65
			Me.txt.Visible = False
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(7, 65)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(154, 21)
			label2.Size = size
			Me.Label1.TabIndex = 67
			Me.Label1.Tag = "CR0041"
			Me.Label1.Text = "Tên "
			Me.txtSUBOBJNAME.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtSUBOBJNAME As Global.System.Windows.Forms.Control = Me.txtSUBOBJNAME
			point = New Global.System.Drawing.Point(169, 64)
			txtSUBOBJNAME.Location = point
			Me.txtSUBOBJNAME.Name = "txtSUBOBJNAME"
			Dim txtSUBOBJNAME2 As Global.System.Windows.Forms.Control = Me.txtSUBOBJNAME
			size = New Global.System.Drawing.Size(400, 22)
			txtSUBOBJNAME2.Size = size
			Me.txtSUBOBJNAME.TabIndex = 2
			Me.txtSUBOBJNAME.Tag = "0R0000"
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnKeyboard.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnKeyboard.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(3, 3)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(107, 78)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 121
			Me.btnKeyboard.Text = "Keyboard"
			Me.btnKeyboard.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(694, 526)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.txtSUBOBJNAME)
			Me.Controls.Add(Me.txt)
			Me.Controls.Add(Me.lblGHICHU)
			Me.Controls.Add(Me.txtGHICHU)
			Me.Controls.Add(Me.lblFAX)
			Me.Controls.Add(Me.lblCONTACT)
			Me.Controls.Add(Me.lblTEL)
			Me.Controls.Add(Me.lblADDRESS)
			Me.Controls.Add(Me.txtEMAIL)
			Me.Controls.Add(Me.txtFAX)
			Me.Controls.Add(Me.txtCONTACT)
			Me.Controls.Add(Me.txtTEL)
			Me.Controls.Add(Me.txtADDRESS)
			Me.Controls.Add(Me.lblEMAIL)
			Me.Controls.Add(Me.lblOBJNAME)
			Me.Controls.Add(Me.txtOBJNAME)
			Me.Controls.Add(Me.txtOBJID)
			Me.Controls.Add(Me.lblOBJID)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMKH2"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Chi tiết DMKH"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x04000A61 RID: 2657
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
