﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002CC RID: 716
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60811
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006A36 RID: 27190 RVA: 0x0001350B File Offset: 0x0001170B
		Public Sub New()
			CachedrptRepBC60811.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170029E9 RID: 10729
		' (get) Token: 0x06006A37 RID: 27191 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006A38 RID: 27192 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170029EA RID: 10730
		' (get) Token: 0x06006A39 RID: 27193 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006A3A RID: 27194 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170029EB RID: 10731
		' (get) Token: 0x06006A3B RID: 27195 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006A3C RID: 27196 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006A3D RID: 27197 RVA: 0x004DE4E0 File Offset: 0x004DC6E0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60811() With { .Site = Me.Site }
		End Function

		' Token: 0x06006A3E RID: 27198 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028C4 RID: 10436
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
