﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200030A RID: 778
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptSALBC02009
		Inherits Component
		Implements ICachedReport

		' Token: 0x060070C8 RID: 28872 RVA: 0x00013EF9 File Offset: 0x000120F9
		Public Sub New()
			CachedrptSALBC02009.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002F45 RID: 12101
		' (get) Token: 0x060070C9 RID: 28873 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060070CA RID: 28874 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002F46 RID: 12102
		' (get) Token: 0x060070CB RID: 28875 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060070CC RID: 28876 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002F47 RID: 12103
		' (get) Token: 0x060070CD RID: 28877 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060070CE RID: 28878 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x060070CF RID: 28879 RVA: 0x004DF384 File Offset: 0x004DD584
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptSALBC02009() With { .Site = Me.Site }
		End Function

		' Token: 0x060070D0 RID: 28880 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002902 RID: 10498
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
