﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002DA RID: 730
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBCPrintReceiptK80Driver_2
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006C1F RID: 27679 RVA: 0x00013749 File Offset: 0x00011949
		Public Sub New()
			CachedrptRepBCPrintReceiptK80Driver_2.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002B8C RID: 11148
		' (get) Token: 0x06006C20 RID: 27680 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006C21 RID: 27681 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002B8D RID: 11149
		' (get) Token: 0x06006C22 RID: 27682 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006C23 RID: 27683 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002B8E RID: 11150
		' (get) Token: 0x06006C24 RID: 27684 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006C25 RID: 27685 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006C26 RID: 27686 RVA: 0x004DED84 File Offset: 0x004DCF84
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBCPrintReceiptK80Driver_2() With { .Site = Me.Site }
		End Function

		' Token: 0x06006C27 RID: 27687 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028D2 RID: 10450
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
