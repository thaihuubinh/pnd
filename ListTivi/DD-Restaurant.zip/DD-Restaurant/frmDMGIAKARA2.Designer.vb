﻿Namespace prjIS_SalesPOS
	' Token: 0x0200004A RID: 74
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMGIAKARA2
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060013DD RID: 5085 RVA: 0x000F216C File Offset: 0x000F036C
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060013DE RID: 5086 RVA: 0x000F21A4 File Offset: 0x000F03A4
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMGIAKARA2))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.lblOBJNAME = New Global.System.Windows.Forms.Label()
			Me.txtOBJNAME = New Global.System.Windows.Forms.TextBox()
			Me.txtOBJID = New Global.System.Windows.Forms.TextBox()
			Me.lblOBJID = New Global.System.Windows.Forms.Label()
			Me.lblFromDate = New Global.System.Windows.Forms.Label()
			Me.txtTENKH = New Global.System.Windows.Forms.TextBox()
			Me.btnSelect = New Global.System.Windows.Forms.Button()
			Me.txtMAKH = New Global.System.Windows.Forms.TextBox()
			Me.lblkHO = New Global.System.Windows.Forms.Label()
			Me.lblToDate = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.lblToTime = New Global.System.Windows.Forms.Label()
			Me.lblFromTime = New Global.System.Windows.Forms.Label()
			Me.chkT2 = New Global.System.Windows.Forms.CheckBox()
			Me.chkT3 = New Global.System.Windows.Forms.CheckBox()
			Me.chkT4 = New Global.System.Windows.Forms.CheckBox()
			Me.chkT5 = New Global.System.Windows.Forms.CheckBox()
			Me.chkT6 = New Global.System.Windows.Forms.CheckBox()
			Me.chkT7 = New Global.System.Windows.Forms.CheckBox()
			Me.chkCN = New Global.System.Windows.Forms.CheckBox()
			Me.mtxFromDate = New Global.System.Windows.Forms.MaskedTextBox()
			Me.mtxToDate = New Global.System.Windows.Forms.MaskedTextBox()
			Me.mtxFromTime = New Global.System.Windows.Forms.MaskedTextBox()
			Me.mtxToTime = New Global.System.Windows.Forms.MaskedTextBox()
			Me.chkFes = New Global.System.Windows.Forms.CheckBox()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(536, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 490)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 20
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnKeyboard, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 2)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 3)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 6
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 469)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 393)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 73)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 22
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 81)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(107, 72)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 18
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 315)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(107, 72)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 21
			Me.btnFind.Tag = "CR0006"
			Me.btnFind.Text = "&Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 159)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 72)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 19
			Me.btnDelete.Tag = "CR0004"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 237)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(107, 72)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 20
			Me.btnFilter.Tag = "CR0005"
			Me.btnFilter.Text = "Lọc"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.lblOBJNAME.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJNAME As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			point = New Global.System.Drawing.Point(7, 46)
			lblOBJNAME.Location = point
			Me.lblOBJNAME.Name = "lblOBJNAME"
			Dim lblOBJNAME2 As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			size = New Global.System.Drawing.Size(154, 21)
			lblOBJNAME2.Size = size
			Me.lblOBJNAME.TabIndex = 102
			Me.lblOBJNAME.Tag = "CR0015"
			Me.lblOBJNAME.Text = "Tên "
			Me.txtOBJNAME.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJNAME As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			point = New Global.System.Drawing.Point(169, 43)
			txtOBJNAME.Location = point
			Me.txtOBJNAME.Name = "txtOBJNAME"
			Dim txtOBJNAME2 As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			size = New Global.System.Drawing.Size(361, 22)
			txtOBJNAME2.Size = size
			Me.txtOBJNAME.TabIndex = 1
			Me.txtOBJNAME.Tag = "0R0000"
			Me.txtOBJID.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJID As Global.System.Windows.Forms.Control = Me.txtOBJID
			point = New Global.System.Drawing.Point(169, 8)
			txtOBJID.Location = point
			Me.txtOBJID.Name = "txtOBJID"
			Dim txtOBJID2 As Global.System.Windows.Forms.Control = Me.txtOBJID
			size = New Global.System.Drawing.Size(122, 22)
			txtOBJID2.Size = size
			Me.txtOBJID.TabIndex = 0
			Me.txtOBJID.Tag = "0R0000"
			Me.lblOBJID.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJID As Global.System.Windows.Forms.Control = Me.lblOBJID
			point = New Global.System.Drawing.Point(7, 9)
			lblOBJID.Location = point
			Me.lblOBJID.Name = "lblOBJID"
			Dim lblOBJID2 As Global.System.Windows.Forms.Control = Me.lblOBJID
			size = New Global.System.Drawing.Size(154, 21)
			lblOBJID2.Size = size
			Me.lblOBJID.TabIndex = 101
			Me.lblOBJID.Tag = "CR0014"
			Me.lblOBJID.Text = "Mã"
			Me.lblFromDate.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFromDate As Global.System.Windows.Forms.Control = Me.lblFromDate
			point = New Global.System.Drawing.Point(7, 122)
			lblFromDate.Location = point
			Me.lblFromDate.Name = "lblFromDate"
			Dim lblFromDate2 As Global.System.Windows.Forms.Control = Me.lblFromDate
			size = New Global.System.Drawing.Size(154, 21)
			lblFromDate2.Size = size
			Me.lblFromDate.TabIndex = 106
			Me.lblFromDate.Tag = "CR0018"
			Me.lblFromDate.Text = "Áp dụng từ ngày"
			Me.txtTENKH.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENKH As Global.System.Windows.Forms.Control = Me.txtTENKH
			point = New Global.System.Drawing.Point(348, 82)
			txtTENKH.Location = point
			Me.txtTENKH.Name = "txtTENKH"
			Dim txtTENKH2 As Global.System.Windows.Forms.Control = Me.txtTENKH
			size = New Global.System.Drawing.Size(182, 22)
			txtTENKH2.Size = size
			Me.txtTENKH.TabIndex = 114
			Me.txtTENKH.Tag = "0R0000"
			Me.btnSelect.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnSelect As Global.System.Windows.Forms.Control = Me.btnSelect
			point = New Global.System.Drawing.Point(297, 82)
			btnSelect.Location = point
			Me.btnSelect.Name = "btnSelect"
			Dim btnSelect2 As Global.System.Windows.Forms.Control = Me.btnSelect
			size = New Global.System.Drawing.Size(45, 22)
			btnSelect2.Size = size
			Me.btnSelect.TabIndex = 3
			Me.btnSelect.Tag = ""
			Me.btnSelect.UseVisualStyleBackColor = True
			Me.txtMAKH.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAKH As Global.System.Windows.Forms.Control = Me.txtMAKH
			point = New Global.System.Drawing.Point(169, 82)
			txtMAKH.Location = point
			Me.txtMAKH.Name = "txtMAKH"
			Dim txtMAKH2 As Global.System.Windows.Forms.Control = Me.txtMAKH
			size = New Global.System.Drawing.Size(122, 22)
			txtMAKH2.Size = size
			Me.txtMAKH.TabIndex = 2
			Me.txtMAKH.Tag = "0R0000"
			Me.lblkHO.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblkHO As Global.System.Windows.Forms.Control = Me.lblkHO
			point = New Global.System.Drawing.Point(7, 81)
			lblkHO.Location = point
			Me.lblkHO.Name = "lblkHO"
			Dim lblkHO2 As Global.System.Windows.Forms.Control = Me.lblkHO
			size = New Global.System.Drawing.Size(154, 21)
			lblkHO2.Size = size
			Me.lblkHO.TabIndex = 103
			Me.lblkHO.Tag = "CR0016"
			Me.lblkHO.Text = "Mã Kho"
			Me.lblToDate.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblToDate As Global.System.Windows.Forms.Control = Me.lblToDate
			point = New Global.System.Drawing.Point(303, 122)
			lblToDate.Location = point
			Me.lblToDate.Name = "lblToDate"
			Dim lblToDate2 As Global.System.Windows.Forms.Control = Me.lblToDate
			size = New Global.System.Drawing.Size(123, 21)
			lblToDate2.Size = size
			Me.lblToDate.TabIndex = 111
			Me.lblToDate.Tag = "CR0019"
			Me.lblToDate.Text = "Đến ngày"
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(7, 160)
			label.Location = point
			Me.Label2.Name = "Label2"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(154, 21)
			label2.Size = size
			Me.Label2.TabIndex = 107
			Me.Label2.Tag = "CR0020"
			Me.Label2.Text = "Áp dụng cho ngày thứ"
			Me.lblToTime.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblToTime As Global.System.Windows.Forms.Control = Me.lblToTime
			point = New Global.System.Drawing.Point(303, 195)
			lblToTime.Location = point
			Me.lblToTime.Name = "lblToTime"
			Dim lblToTime2 As Global.System.Windows.Forms.Control = Me.lblToTime
			size = New Global.System.Drawing.Size(123, 21)
			lblToTime2.Size = size
			Me.lblToTime.TabIndex = 112
			Me.lblToTime.Tag = "CR0022"
			Me.lblToTime.Text = "Đến giờ"
			Me.lblFromTime.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFromTime As Global.System.Windows.Forms.Control = Me.lblFromTime
			point = New Global.System.Drawing.Point(7, 197)
			lblFromTime.Location = point
			Me.lblFromTime.Name = "lblFromTime"
			Dim lblFromTime2 As Global.System.Windows.Forms.Control = Me.lblFromTime
			size = New Global.System.Drawing.Size(154, 21)
			lblFromTime2.Size = size
			Me.lblFromTime.TabIndex = 108
			Me.lblFromTime.Tag = "CR0021"
			Me.lblFromTime.Text = "Áp dụng từ giờ"
			Me.chkT2.AutoSize = True
			Dim chkT As Global.System.Windows.Forms.Control = Me.chkT2
			point = New Global.System.Drawing.Point(169, 161)
			chkT.Location = point
			Me.chkT2.Name = "chkT2"
			Dim chkT2 As Global.System.Windows.Forms.Control = Me.chkT2
			size = New Global.System.Drawing.Size(41, 20)
			chkT2.Size = size
			Me.chkT2.TabIndex = 9
			Me.chkT2.Text = "T2"
			Me.chkT2.UseVisualStyleBackColor = True
			Me.chkT3.AutoSize = True
			Dim chkT3 As Global.System.Windows.Forms.Control = Me.chkT3
			point = New Global.System.Drawing.Point(206, 161)
			chkT3.Location = point
			Me.chkT3.Name = "chkT3"
			Dim chkT4 As Global.System.Windows.Forms.Control = Me.chkT3
			size = New Global.System.Drawing.Size(41, 20)
			chkT4.Size = size
			Me.chkT3.TabIndex = 10
			Me.chkT3.Text = "T3"
			Me.chkT3.UseVisualStyleBackColor = True
			Me.chkT4.AutoSize = True
			Dim chkT5 As Global.System.Windows.Forms.Control = Me.chkT4
			point = New Global.System.Drawing.Point(253, 161)
			chkT5.Location = point
			Me.chkT4.Name = "chkT4"
			Dim chkT6 As Global.System.Windows.Forms.Control = Me.chkT4
			size = New Global.System.Drawing.Size(41, 20)
			chkT6.Size = size
			Me.chkT4.TabIndex = 11
			Me.chkT4.Text = "T4"
			Me.chkT4.UseVisualStyleBackColor = True
			Me.chkT5.AutoSize = True
			Dim chkT7 As Global.System.Windows.Forms.Control = Me.chkT5
			point = New Global.System.Drawing.Point(300, 161)
			chkT7.Location = point
			Me.chkT5.Name = "chkT5"
			Dim chkT8 As Global.System.Windows.Forms.Control = Me.chkT5
			size = New Global.System.Drawing.Size(41, 20)
			chkT8.Size = size
			Me.chkT5.TabIndex = 12
			Me.chkT5.Text = "T5"
			Me.chkT5.UseVisualStyleBackColor = True
			Me.chkT6.AutoSize = True
			Dim chkT9 As Global.System.Windows.Forms.Control = Me.chkT6
			point = New Global.System.Drawing.Point(347, 161)
			chkT9.Location = point
			Me.chkT6.Name = "chkT6"
			Dim chkT10 As Global.System.Windows.Forms.Control = Me.chkT6
			size = New Global.System.Drawing.Size(41, 20)
			chkT10.Size = size
			Me.chkT6.TabIndex = 13
			Me.chkT6.Text = "T6"
			Me.chkT6.UseVisualStyleBackColor = True
			Me.chkT7.AutoSize = True
			Dim chkT11 As Global.System.Windows.Forms.Control = Me.chkT7
			point = New Global.System.Drawing.Point(394, 161)
			chkT11.Location = point
			Me.chkT7.Name = "chkT7"
			Dim chkT12 As Global.System.Windows.Forms.Control = Me.chkT7
			size = New Global.System.Drawing.Size(41, 20)
			chkT12.Size = size
			Me.chkT7.TabIndex = 14
			Me.chkT7.Text = "T7"
			Me.chkT7.UseVisualStyleBackColor = True
			Me.chkCN.AutoSize = True
			Dim chkCN As Global.System.Windows.Forms.Control = Me.chkCN
			point = New Global.System.Drawing.Point(440, 161)
			chkCN.Location = point
			Me.chkCN.Name = "chkCN"
			Dim chkCN2 As Global.System.Windows.Forms.Control = Me.chkCN
			size = New Global.System.Drawing.Size(45, 20)
			chkCN2.Size = size
			Me.chkCN.TabIndex = 15
			Me.chkCN.Text = "CN"
			Me.chkCN.UseVisualStyleBackColor = True
			Dim mtxFromDate As Global.System.Windows.Forms.Control = Me.mtxFromDate
			point = New Global.System.Drawing.Point(169, 119)
			mtxFromDate.Location = point
			Me.mtxFromDate.Mask = "00/00/0000"
			Me.mtxFromDate.Name = "mtxFromDate"
			Me.mtxFromDate.PromptChar = " "c
			Dim mtxFromDate2 As Global.System.Windows.Forms.Control = Me.mtxFromDate
			size = New Global.System.Drawing.Size(113, 22)
			mtxFromDate2.Size = size
			Me.mtxFromDate.TabIndex = 7
			Me.mtxFromDate.Tag = ""
			Me.mtxFromDate.ValidatingType = GetType(Global.System.DateTime)
			Dim mtxToDate As Global.System.Windows.Forms.Control = Me.mtxToDate
			point = New Global.System.Drawing.Point(404, 119)
			mtxToDate.Location = point
			Me.mtxToDate.Mask = "00/00/0000"
			Me.mtxToDate.Name = "mtxToDate"
			Me.mtxToDate.PromptChar = " "c
			Dim mtxToDate2 As Global.System.Windows.Forms.Control = Me.mtxToDate
			size = New Global.System.Drawing.Size(126, 22)
			mtxToDate2.Size = size
			Me.mtxToDate.TabIndex = 8
			Me.mtxToDate.Tag = ""
			Me.mtxToDate.ValidatingType = GetType(Global.System.DateTime)
			Dim mtxFromTime As Global.System.Windows.Forms.Control = Me.mtxFromTime
			point = New Global.System.Drawing.Point(169, 195)
			mtxFromTime.Location = point
			Me.mtxFromTime.Mask = "00:00"
			Me.mtxFromTime.Name = "mtxFromTime"
			Me.mtxFromTime.PromptChar = " "c
			Dim mtxFromTime2 As Global.System.Windows.Forms.Control = Me.mtxFromTime
			size = New Global.System.Drawing.Size(113, 22)
			mtxFromTime2.Size = size
			Me.mtxFromTime.TabIndex = 16
			Me.mtxFromTime.Tag = ""
			Me.mtxFromTime.ValidatingType = GetType(Global.System.DateTime)
			Dim mtxToTime As Global.System.Windows.Forms.Control = Me.mtxToTime
			point = New Global.System.Drawing.Point(426, 194)
			mtxToTime.Location = point
			Me.mtxToTime.Mask = "00:00"
			Me.mtxToTime.Name = "mtxToTime"
			Me.mtxToTime.PromptChar = " "c
			Dim mtxToTime2 As Global.System.Windows.Forms.Control = Me.mtxToTime
			size = New Global.System.Drawing.Size(104, 22)
			mtxToTime2.Size = size
			Me.mtxToTime.TabIndex = 17
			Me.mtxToTime.Tag = ""
			Me.mtxToTime.ValidatingType = GetType(Global.System.DateTime)
			Me.chkFes.AutoSize = True
			Dim chkFes As Global.System.Windows.Forms.Control = Me.chkFes
			point = New Global.System.Drawing.Point(489, 161)
			chkFes.Location = point
			Me.chkFes.Name = "chkFes"
			Dim chkFes2 As Global.System.Windows.Forms.Control = Me.chkFes
			size = New Global.System.Drawing.Size(41, 20)
			chkFes2.Size = size
			Me.chkFes.TabIndex = 115
			Me.chkFes.Tag = "CR0048"
			Me.chkFes.Text = "Lễ"
			Me.chkFes.UseVisualStyleBackColor = True
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnKeyboard.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnKeyboard.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(3, 3)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(107, 72)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 116
			Me.btnKeyboard.Text = "Keyboard"
			Me.btnKeyboard.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(655, 490)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.chkFes)
			Me.Controls.Add(Me.mtxToTime)
			Me.Controls.Add(Me.mtxFromTime)
			Me.Controls.Add(Me.mtxToDate)
			Me.Controls.Add(Me.mtxFromDate)
			Me.Controls.Add(Me.chkCN)
			Me.Controls.Add(Me.chkT7)
			Me.Controls.Add(Me.chkT6)
			Me.Controls.Add(Me.chkT5)
			Me.Controls.Add(Me.chkT4)
			Me.Controls.Add(Me.chkT3)
			Me.Controls.Add(Me.chkT2)
			Me.Controls.Add(Me.lblToTime)
			Me.Controls.Add(Me.lblFromTime)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.lblToDate)
			Me.Controls.Add(Me.txtTENKH)
			Me.Controls.Add(Me.btnSelect)
			Me.Controls.Add(Me.txtMAKH)
			Me.Controls.Add(Me.lblkHO)
			Me.Controls.Add(Me.lblFromDate)
			Me.Controls.Add(Me.lblOBJNAME)
			Me.Controls.Add(Me.txtOBJNAME)
			Me.Controls.Add(Me.txtOBJID)
			Me.Controls.Add(Me.lblOBJID)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMGIAKARA2"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Chi tiết DMDNKM"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x04000842 RID: 2114
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
