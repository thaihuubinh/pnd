﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Threading

Namespace prjIS_SalesPOS
	' Token: 0x02000008 RID: 8
	Public Class clsCheckConnect
		' Token: 0x060001AD RID: 429 RVA: 0x000020A5 File Offset: 0x000002A5
		Public Sub New()
			Me.connectSuccess = False
		End Sub

		' Token: 0x060001AE RID: 430 RVA: 0x0001C3C4 File Offset: 0x0001A5C4
		Public Sub ThreadProc()
			Try
				Me.ThreadProcConn.Open()
				Dim flag As Boolean = Me.ThreadProcConn.State = ConnectionState.Open
				If flag Then
					Me.connectSuccess = True
				Else
					Me.connectSuccess = False
				End If
			Catch ex As Exception
				Me.connectSuccess = False
			End Try
		End Sub

		' Token: 0x060001AF RID: 431 RVA: 0x0001C42C File Offset: 0x0001A62C
		Public Function QuickOpen(conn As SqlConnection, timeout As Integer) As Boolean
			Me.ThreadProcConn = conn
			Dim thread As Thread = AddressOf Me.ThreadProc
			Dim now As DateTime = DateTime.Now
			thread.IsBackground = True
			thread.Start()
			Dim flag As Boolean
			While DateTime.Compare(now.AddSeconds(CDbl(timeout)), DateTime.Now) > 0
				flag = thread.Join(1)
				If flag Then
					Exit While
				End If
			End While
			flag = Not Me.connectSuccess
			Return Not flag
		End Function

		' Token: 0x040000D2 RID: 210
		Private ThreadProcConn As SqlConnection

		' Token: 0x040000D3 RID: 211
		Private connectSuccess As Boolean
	End Class
End Namespace
