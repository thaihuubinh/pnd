﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200004A RID: 74
	<DesignerGenerated()>
	Public Partial Class frmDMGIAKARA2
		Inherits Form

		' Token: 0x060013DC RID: 5084 RVA: 0x000F210C File Offset: 0x000F030C
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMDNKM2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMDNKM2_Load
			frmDMGIAKARA2.__ENCList.Add(New WeakReference(Me))
			Me.mstrKHO = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x170006E9 RID: 1769
		' (get) Token: 0x060013DF RID: 5087 RVA: 0x000F3A3C File Offset: 0x000F1C3C
		' (set) Token: 0x060013E0 RID: 5088 RVA: 0x00004F95 File Offset: 0x00003195
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x170006EA RID: 1770
		' (get) Token: 0x060013E1 RID: 5089 RVA: 0x000F3A54 File Offset: 0x000F1C54
		' (set) Token: 0x060013E2 RID: 5090 RVA: 0x000F3A6C File Offset: 0x000F1C6C
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170006EB RID: 1771
		' (get) Token: 0x060013E3 RID: 5091 RVA: 0x000F3AD8 File Offset: 0x000F1CD8
		' (set) Token: 0x060013E4 RID: 5092 RVA: 0x00004F9F File Offset: 0x0000319F
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x170006EC RID: 1772
		' (get) Token: 0x060013E5 RID: 5093 RVA: 0x000F3AF0 File Offset: 0x000F1CF0
		' (set) Token: 0x060013E6 RID: 5094 RVA: 0x000F3B08 File Offset: 0x000F1D08
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x170006ED RID: 1773
		' (get) Token: 0x060013E7 RID: 5095 RVA: 0x000F3B74 File Offset: 0x000F1D74
		' (set) Token: 0x060013E8 RID: 5096 RVA: 0x000F3B8C File Offset: 0x000F1D8C
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170006EE RID: 1774
		' (get) Token: 0x060013E9 RID: 5097 RVA: 0x000F3BF8 File Offset: 0x000F1DF8
		' (set) Token: 0x060013EA RID: 5098 RVA: 0x000F3C10 File Offset: 0x000F1E10
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170006EF RID: 1775
		' (get) Token: 0x060013EB RID: 5099 RVA: 0x000F3C7C File Offset: 0x000F1E7C
		' (set) Token: 0x060013EC RID: 5100 RVA: 0x00004FA9 File Offset: 0x000031A9
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x170006F0 RID: 1776
		' (get) Token: 0x060013ED RID: 5101 RVA: 0x000F3C94 File Offset: 0x000F1E94
		' (set) Token: 0x060013EE RID: 5102 RVA: 0x000F3CAC File Offset: 0x000F1EAC
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170006F1 RID: 1777
		' (get) Token: 0x060013EF RID: 5103 RVA: 0x000F3D18 File Offset: 0x000F1F18
		' (set) Token: 0x060013F0 RID: 5104 RVA: 0x000F3D30 File Offset: 0x000F1F30
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170006F2 RID: 1778
		' (get) Token: 0x060013F1 RID: 5105 RVA: 0x000F3DCC File Offset: 0x000F1FCC
		' (set) Token: 0x060013F2 RID: 5106 RVA: 0x00004FB3 File Offset: 0x000031B3
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x170006F3 RID: 1779
		' (get) Token: 0x060013F3 RID: 5107 RVA: 0x000F3DE4 File Offset: 0x000F1FE4
		' (set) Token: 0x060013F4 RID: 5108 RVA: 0x00004FBD File Offset: 0x000031BD
		Friend Overridable Property lblFromDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFromDate = value
			End Set
		End Property

		' Token: 0x170006F4 RID: 1780
		' (get) Token: 0x060013F5 RID: 5109 RVA: 0x000F3DFC File Offset: 0x000F1FFC
		' (set) Token: 0x060013F6 RID: 5110 RVA: 0x000F3E14 File Offset: 0x000F2014
		Friend Overridable Property txtTENKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENKH.KeyPress, AddressOf Me.txtTENKH_KeyPress
					RemoveHandler Me._txtTENKH.GotFocus, AddressOf Me.txtTENKH_GotFocus
				End If
				Me._txtTENKH = value
				flag = Me._txtTENKH IsNot Nothing
				If flag Then
					AddHandler Me._txtTENKH.KeyPress, AddressOf Me.txtTENKH_KeyPress
					AddHandler Me._txtTENKH.GotFocus, AddressOf Me.txtTENKH_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170006F5 RID: 1781
		' (get) Token: 0x060013F7 RID: 5111 RVA: 0x000F3EB0 File Offset: 0x000F20B0
		' (set) Token: 0x060013F8 RID: 5112 RVA: 0x000F3EC8 File Offset: 0x000F20C8
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170006F6 RID: 1782
		' (get) Token: 0x060013F9 RID: 5113 RVA: 0x000F3F34 File Offset: 0x000F2134
		' (set) Token: 0x060013FA RID: 5114 RVA: 0x000F3F4C File Offset: 0x000F214C
		Friend Overridable Property txtMAKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
					RemoveHandler Me._txtMAKH.KeyPress, AddressOf Me.txtMAKH_KeyPress
				End If
				Me._txtMAKH = value
				flag = Me._txtMAKH IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
					AddHandler Me._txtMAKH.KeyPress, AddressOf Me.txtMAKH_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170006F7 RID: 1783
		' (get) Token: 0x060013FB RID: 5115 RVA: 0x000F3FE8 File Offset: 0x000F21E8
		' (set) Token: 0x060013FC RID: 5116 RVA: 0x00004FC7 File Offset: 0x000031C7
		Friend Overridable Property lblkHO As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblkHO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblkHO = value
			End Set
		End Property

		' Token: 0x170006F8 RID: 1784
		' (get) Token: 0x060013FD RID: 5117 RVA: 0x000F4000 File Offset: 0x000F2200
		' (set) Token: 0x060013FE RID: 5118 RVA: 0x00004FD1 File Offset: 0x000031D1
		Friend Overridable Property lblToDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblToDate = value
			End Set
		End Property

		' Token: 0x170006F9 RID: 1785
		' (get) Token: 0x060013FF RID: 5119 RVA: 0x000F4018 File Offset: 0x000F2218
		' (set) Token: 0x06001400 RID: 5120 RVA: 0x00004FDB File Offset: 0x000031DB
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x170006FA RID: 1786
		' (get) Token: 0x06001401 RID: 5121 RVA: 0x000F4030 File Offset: 0x000F2230
		' (set) Token: 0x06001402 RID: 5122 RVA: 0x00004FE5 File Offset: 0x000031E5
		Friend Overridable Property lblToTime As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblToTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblToTime = value
			End Set
		End Property

		' Token: 0x170006FB RID: 1787
		' (get) Token: 0x06001403 RID: 5123 RVA: 0x000F4048 File Offset: 0x000F2248
		' (set) Token: 0x06001404 RID: 5124 RVA: 0x00004FEF File Offset: 0x000031EF
		Friend Overridable Property lblFromTime As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFromTime = value
			End Set
		End Property

		' Token: 0x170006FC RID: 1788
		' (get) Token: 0x06001405 RID: 5125 RVA: 0x000F4060 File Offset: 0x000F2260
		' (set) Token: 0x06001406 RID: 5126 RVA: 0x000F4078 File Offset: 0x000F2278
		Friend Overridable Property chkT2 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT2 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT2.KeyPress, AddressOf Me.chkT2_KeyPress
				End If
				Me._chkT2 = value
				flag = Me._chkT2 IsNot Nothing
				If flag Then
					AddHandler Me._chkT2.KeyPress, AddressOf Me.chkT2_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170006FD RID: 1789
		' (get) Token: 0x06001407 RID: 5127 RVA: 0x000F40E4 File Offset: 0x000F22E4
		' (set) Token: 0x06001408 RID: 5128 RVA: 0x000F40FC File Offset: 0x000F22FC
		Friend Overridable Property chkT3 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT3 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT3.KeyPress, AddressOf Me.chkT3_KeyPress
				End If
				Me._chkT3 = value
				flag = Me._chkT3 IsNot Nothing
				If flag Then
					AddHandler Me._chkT3.KeyPress, AddressOf Me.chkT3_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170006FE RID: 1790
		' (get) Token: 0x06001409 RID: 5129 RVA: 0x000F4168 File Offset: 0x000F2368
		' (set) Token: 0x0600140A RID: 5130 RVA: 0x000F4180 File Offset: 0x000F2380
		Friend Overridable Property chkT4 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT4 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT4.KeyPress, AddressOf Me.chkT4_KeyPress
				End If
				Me._chkT4 = value
				flag = Me._chkT4 IsNot Nothing
				If flag Then
					AddHandler Me._chkT4.KeyPress, AddressOf Me.chkT4_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170006FF RID: 1791
		' (get) Token: 0x0600140B RID: 5131 RVA: 0x000F41EC File Offset: 0x000F23EC
		' (set) Token: 0x0600140C RID: 5132 RVA: 0x000F4204 File Offset: 0x000F2404
		Friend Overridable Property chkT5 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT5 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT5.KeyPress, AddressOf Me.chkT5_KeyPress
				End If
				Me._chkT5 = value
				flag = Me._chkT5 IsNot Nothing
				If flag Then
					AddHandler Me._chkT5.KeyPress, AddressOf Me.chkT5_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000700 RID: 1792
		' (get) Token: 0x0600140D RID: 5133 RVA: 0x000F4270 File Offset: 0x000F2470
		' (set) Token: 0x0600140E RID: 5134 RVA: 0x000F4288 File Offset: 0x000F2488
		Friend Overridable Property chkT6 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT6 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT6.KeyPress, AddressOf Me.chkT6_KeyPress
				End If
				Me._chkT6 = value
				flag = Me._chkT6 IsNot Nothing
				If flag Then
					AddHandler Me._chkT6.KeyPress, AddressOf Me.chkT6_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000701 RID: 1793
		' (get) Token: 0x0600140F RID: 5135 RVA: 0x000F42F4 File Offset: 0x000F24F4
		' (set) Token: 0x06001410 RID: 5136 RVA: 0x000F430C File Offset: 0x000F250C
		Friend Overridable Property chkT7 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT7 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT7.KeyPress, AddressOf Me.chkT7_KeyPress
				End If
				Me._chkT7 = value
				flag = Me._chkT7 IsNot Nothing
				If flag Then
					AddHandler Me._chkT7.KeyPress, AddressOf Me.chkT7_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000702 RID: 1794
		' (get) Token: 0x06001411 RID: 5137 RVA: 0x000F4378 File Offset: 0x000F2578
		' (set) Token: 0x06001412 RID: 5138 RVA: 0x000F4390 File Offset: 0x000F2590
		Friend Overridable Property chkCN As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkCN
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkCN IsNot Nothing
				If flag Then
					RemoveHandler Me._chkCN.KeyPress, AddressOf Me.chkCN_KeyPress
				End If
				Me._chkCN = value
				flag = Me._chkCN IsNot Nothing
				If flag Then
					AddHandler Me._chkCN.KeyPress, AddressOf Me.chkCN_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000703 RID: 1795
		' (get) Token: 0x06001413 RID: 5139 RVA: 0x000F43FC File Offset: 0x000F25FC
		' (set) Token: 0x06001414 RID: 5140 RVA: 0x000F4414 File Offset: 0x000F2614
		Friend Overridable Property mtxFromDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxFromDate IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxFromDate.KeyPress, AddressOf Me.mtxFromDate_KeyPress
				End If
				Me._mtxFromDate = value
				flag = Me._mtxFromDate IsNot Nothing
				If flag Then
					AddHandler Me._mtxFromDate.KeyPress, AddressOf Me.mtxFromDate_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000704 RID: 1796
		' (get) Token: 0x06001415 RID: 5141 RVA: 0x000F4480 File Offset: 0x000F2680
		' (set) Token: 0x06001416 RID: 5142 RVA: 0x000F4498 File Offset: 0x000F2698
		Friend Overridable Property mtxToDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxToDate IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxToDate.KeyPress, AddressOf Me.mtxToDate_KeyPress
				End If
				Me._mtxToDate = value
				flag = Me._mtxToDate IsNot Nothing
				If flag Then
					AddHandler Me._mtxToDate.KeyPress, AddressOf Me.mtxToDate_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000705 RID: 1797
		' (get) Token: 0x06001417 RID: 5143 RVA: 0x000F4504 File Offset: 0x000F2704
		' (set) Token: 0x06001418 RID: 5144 RVA: 0x000F451C File Offset: 0x000F271C
		Friend Overridable Property mtxFromTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxFromTime IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxFromTime.KeyPress, AddressOf Me.mtxFromTime_KeyPress
				End If
				Me._mtxFromTime = value
				flag = Me._mtxFromTime IsNot Nothing
				If flag Then
					AddHandler Me._mtxFromTime.KeyPress, AddressOf Me.mtxFromTime_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000706 RID: 1798
		' (get) Token: 0x06001419 RID: 5145 RVA: 0x000F4588 File Offset: 0x000F2788
		' (set) Token: 0x0600141A RID: 5146 RVA: 0x000F45A0 File Offset: 0x000F27A0
		Friend Overridable Property mtxToTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxToTime IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxToTime.KeyPress, AddressOf Me.mtxToTime_KeyPress
				End If
				Me._mtxToTime = value
				flag = Me._mtxToTime IsNot Nothing
				If flag Then
					AddHandler Me._mtxToTime.KeyPress, AddressOf Me.mtxToTime_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000707 RID: 1799
		' (get) Token: 0x0600141B RID: 5147 RVA: 0x000F460C File Offset: 0x000F280C
		' (set) Token: 0x0600141C RID: 5148 RVA: 0x00004FF9 File Offset: 0x000031F9
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000708 RID: 1800
		' (get) Token: 0x0600141D RID: 5149 RVA: 0x000F4624 File Offset: 0x000F2824
		' (set) Token: 0x0600141E RID: 5150 RVA: 0x00005003 File Offset: 0x00003203
		Friend Overridable Property chkFes As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkFes
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkFes = value
			End Set
		End Property

		' Token: 0x17000709 RID: 1801
		' (get) Token: 0x0600141F RID: 5151 RVA: 0x000F463C File Offset: 0x000F283C
		' (set) Token: 0x06001420 RID: 5152 RVA: 0x000F4654 File Offset: 0x000F2854
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x1700070A RID: 1802
		' (get) Token: 0x06001421 RID: 5153 RVA: 0x000F46C0 File Offset: 0x000F28C0
		' (set) Token: 0x06001422 RID: 5154 RVA: 0x0000500D File Offset: 0x0000320D
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x1700070B RID: 1803
		' (get) Token: 0x06001423 RID: 5155 RVA: 0x000F46D8 File Offset: 0x000F28D8
		' (set) Token: 0x06001424 RID: 5156 RVA: 0x00005018 File Offset: 0x00003218
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x1700070C RID: 1804
		' (get) Token: 0x06001425 RID: 5157 RVA: 0x000F46F0 File Offset: 0x000F28F0
		' (set) Token: 0x06001426 RID: 5158 RVA: 0x00005023 File Offset: 0x00003223
		Public Property pStrKHO As String
			Get
				Return Me.mstrKHO
			End Get
			Set(value As String)
				Me.mstrKHO = value
			End Set
		End Property

		' Token: 0x1700070D RID: 1805
		' (get) Token: 0x06001427 RID: 5159 RVA: 0x000F4708 File Offset: 0x000F2908
		' (set) Token: 0x06001428 RID: 5160 RVA: 0x0000502E File Offset: 0x0000322E
		Public Property pStrMANHOMDV As String
			Get
				Return Conversions.ToString(Me.mstrMaNHOMDV)
			End Get
			Set(value As String)
				Me.mstrMaNHOMDV = value
			End Set
		End Property

		' Token: 0x1700070E RID: 1806
		' (get) Token: 0x06001429 RID: 5161 RVA: 0x000F4728 File Offset: 0x000F2928
		' (set) Token: 0x0600142A RID: 5162 RVA: 0x00005039 File Offset: 0x00003239
		Public Property pStrOBJID As String
			Get
				Return Me.mstrOBJID
			End Get
			Set(value As String)
				Me.mstrOBJID = value
			End Set
		End Property

		' Token: 0x1700070F RID: 1807
		' (get) Token: 0x0600142B RID: 5163 RVA: 0x000F4740 File Offset: 0x000F2940
		' (set) Token: 0x0600142C RID: 5164 RVA: 0x00005044 File Offset: 0x00003244
		Public Property pStrHTKM As String
			Get
				Return Me.mstrHTKM
			End Get
			Set(value As String)
				Me.mstrHTKM = value
			End Set
		End Property

		' Token: 0x17000710 RID: 1808
		' (get) Token: 0x0600142D RID: 5165 RVA: 0x000F4758 File Offset: 0x000F2958
		' (set) Token: 0x0600142E RID: 5166 RVA: 0x0000504F File Offset: 0x0000324F
		Public Property pStrFromDate As String
			Get
				Return Me.mStrFromDate
			End Get
			Set(value As String)
				Me.mStrFromDate = value
			End Set
		End Property

		' Token: 0x17000711 RID: 1809
		' (get) Token: 0x0600142F RID: 5167 RVA: 0x000F4770 File Offset: 0x000F2970
		' (set) Token: 0x06001430 RID: 5168 RVA: 0x0000505A File Offset: 0x0000325A
		Public Property pStrToDate As String
			Get
				Return Me.mStrToDate
			End Get
			Set(value As String)
				Me.mStrToDate = value
			End Set
		End Property

		' Token: 0x17000712 RID: 1810
		' (get) Token: 0x06001431 RID: 5169 RVA: 0x000F4788 File Offset: 0x000F2988
		' (set) Token: 0x06001432 RID: 5170 RVA: 0x00005065 File Offset: 0x00003265
		Public Property pStrFromTime As String
			Get
				Return Me.mStrFromTime
			End Get
			Set(value As String)
				Me.mStrFromTime = value
			End Set
		End Property

		' Token: 0x17000713 RID: 1811
		' (get) Token: 0x06001433 RID: 5171 RVA: 0x000F47A0 File Offset: 0x000F29A0
		' (set) Token: 0x06001434 RID: 5172 RVA: 0x00005070 File Offset: 0x00003270
		Public Property pStrToTime As String
			Get
				Return Me.mStrToTime
			End Get
			Set(value As String)
				Me.mStrToTime = value
			End Set
		End Property

		' Token: 0x17000714 RID: 1812
		' (get) Token: 0x06001435 RID: 5173 RVA: 0x000F47B8 File Offset: 0x000F29B8
		' (set) Token: 0x06001436 RID: 5174 RVA: 0x0000507B File Offset: 0x0000327B
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06001437 RID: 5175 RVA: 0x000F47D0 File Offset: 0x000F29D0
		Private Sub frmDMDNKM2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
				Me.txtMAKH_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001438 RID: 5176 RVA: 0x000F488C File Offset: 0x000F2A8C
		Private Sub frmDMDNKM2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMKH()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMNHOMDV()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001439 RID: 5177 RVA: 0x000F496C File Offset: 0x000F2B6C
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						Dim text As String = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
						Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text, "", 1, -1, CompareMethod.Binary))
						flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
							Me.mtxFromDate.Focus()
						Else
							text = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
							text2 = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text, "", 1, -1, CompareMethod.Binary))
							flag = Strings.Len(text2) > 0
							If flag Then
								text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 1, 2) })
								flag = Not Information.IsDate(text2)
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(35), MsgBoxStyle.Critical, Nothing)
									Me.mtxFromDate.Focus()
									Return
								End If
							End If
							text = Strings.Mid(Me.mtxToDate.Text, 3, 1)
							text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text, "", 1, -1, CompareMethod.Binary))
							flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
								Me.mtxToDate.Focus()
							Else
								text = Strings.Mid(Me.mtxToDate.Text, 3, 1)
								text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text, "", 1, -1, CompareMethod.Binary))
								flag = Strings.Len(text2) > 0
								If flag Then
									text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 1, 2) })
									flag = Not Information.IsDate(text2)
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(36), MsgBoxStyle.Critical, Nothing)
										Me.mtxToDate.Focus()
										Return
									End If
								End If
								Dim text3 As String = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text, "", 1, -1, CompareMethod.Binary))
								text3 = Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 4, 2) + Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 1, 2)
								Dim text4 As String = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text, "", 1, -1, CompareMethod.Binary))
								text4 = Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 4, 2) + Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 1, 2)
								flag = Operators.CompareString(text3, text4, False) > 0
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(43), MsgBoxStyle.Critical, Nothing)
									Me.mtxToDate.Focus()
								Else
									text = Strings.Mid(Me.mtxFromTime.Text, 3, 1)
									text2 = Strings.Trim(Strings.Replace(Me.mtxFromTime.Text, text, "", 1, -1, CompareMethod.Binary))
									flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
										Me.mtxFromTime.Focus()
									Else
										text = Strings.Mid(Me.mtxFromTime.Text, 3, 1)
										text2 = Strings.Trim(Strings.Replace(Me.mtxFromTime.Text, text, "", 1, -1, CompareMethod.Binary))
										flag = Strings.Len(text2) > 0
										If flag Then
											Dim text5 As String = Strings.Mid(Me.mtxFromTime.Text, 1, 2)
											Dim text6 As String = Strings.Mid(Me.mtxFromTime.Text, 4, 2)
											flag = (Conversion.Val(text5) < 0.0) Or (Conversion.Val(text5) > 23.0) Or (Conversion.Val(text6) < 0.0) Or (Conversion.Val(text6) > 59.0)
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(37), MsgBoxStyle.Critical, Nothing)
												Me.mtxFromTime.Focus()
												Return
											End If
										End If
										text = Strings.Mid(Me.mtxToTime.Text, 3, 1)
										text2 = Strings.Trim(Strings.Replace(Me.mtxToTime.Text, text, "", 1, -1, CompareMethod.Binary))
										flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
										If flag Then
											Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
											Me.mtxToTime.Focus()
										Else
											text = Strings.Mid(Me.mtxToTime.Text, 3, 1)
											text2 = Strings.Trim(Strings.Replace(Me.mtxToTime.Text, text, "", 1, -1, CompareMethod.Binary))
											flag = Strings.Len(text2) > 0
											If flag Then
												Dim text5 As String = Strings.Mid(Me.mtxToTime.Text, 1, 2)
												Dim text6 As String = Strings.Mid(Me.mtxToTime.Text, 4, 2)
												flag = (Conversion.Val(text5) < 0.0) Or (Conversion.Val(text5) > 23.0) Or (Conversion.Val(text6) < 0.0) Or (Conversion.Val(text6) > 59.0)
												If flag Then
													Interaction.MsgBox(Me.mArrStrFrmMess(38), MsgBoxStyle.Critical, Nothing)
													Me.mtxToTime.Focus()
													Return
												End If
											End If
											Dim text7 As String = Strings.Trim(Strings.Replace(Me.mtxFromTime.Text, text, "", 1, -1, CompareMethod.Binary))
											Dim text8 As String = Strings.Trim(Strings.Replace(Me.mtxToTime.Text, text, "", 1, -1, CompareMethod.Binary))
											flag = Operators.CompareString(text7, text8, False) > 0
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(44), MsgBoxStyle.Critical, Nothing)
												Me.mtxToDate.Focus()
											Else
												flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
												If flag Then
													Me.mbytSuccess = Me.fAddNew()
												Else
													flag = Me.mbytFormStatus = 3
													If flag Then
														Me.mbytSuccess = Me.fModify()
													End If
												End If
												flag = Me.mbytSuccess = 1
												If flag Then
													Me.Close()
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600143A RID: 5178 RVA: 0x000F520C File Offset: 0x000F340C
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600143B RID: 5179 RVA: 0x000F52B0 File Offset: 0x000F34B0
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAKH.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '"), text2), "%'"))
				End If
				Dim text3 As String = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TUNGAY like '%"), text2), "%'"))
				End If
				text3 = Strings.Mid(Me.mtxToDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " DENNGAY like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600143C RID: 5180 RVA: 0x000F55D4 File Offset: 0x000F37D4
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAKH.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '"), text2), "%'"))
				End If
				Dim text3 As String = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TUNGAY like '%"), text2), "%'"))
				End If
				text3 = Strings.Mid(Me.mtxToDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " DENNGAY like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600143D RID: 5181 RVA: 0x000F58F8 File Offset: 0x000F3AF8
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKH As frmDMKH1 = New frmDMKH1()
				frmDMKH.pBytOpen_From_Menu = 7
				frmDMKH.ShowDialog()
				Me.txtMAKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJID, "", False) = 0, Me.txtMAKH.Text, frmDMKH.pStrOBJID))
				Me.txtTENKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJNAME, "", False) = 0, Me.txtTENKH.Text, frmDMKH.pStrOBJNAME))
				frmDMKH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600143E RID: 5182 RVA: 0x000F5A1C File Offset: 0x000F3C1C
		Private Sub btnNDV_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMNHOMDV As frmDMNHOMDV1 = New frmDMNHOMDV1()
				frmDMNHOMDV.pBytOpen_From_Menu = 7
				frmDMNHOMDV.ShowDialog()
				frmDMNHOMDV.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNDV_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600143F RID: 5183 RVA: 0x000F5ACC File Offset: 0x000F3CCC
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJNAME.Focus()
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtTENKH.BackColor
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtTENKH.BackColor
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtOBJNAME.BackColor = Me.txtTENKH.BackColor
						Me.txtMAKH.[ReadOnly] = True
						Me.txtMAKH.BackColor = Me.txtTENKH.BackColor
						Me.btnSelect.Enabled = False
						Me.mtxFromDate.[ReadOnly] = True
						Me.mtxFromDate.BackColor = Me.txtTENKH.BackColor
						Me.mtxToDate.[ReadOnly] = True
						Me.mtxToDate.BackColor = Me.txtTENKH.BackColor
						Me.mtxFromTime.[ReadOnly] = True
						Me.mtxFromTime.BackColor = Me.txtTENKH.BackColor
						Me.mtxToTime.[ReadOnly] = True
						Me.mtxToTime.BackColor = Me.txtTENKH.BackColor
						Me.chkT2.Enabled = False
						Me.chkT3.Enabled = False
						Me.chkT4.Enabled = False
						Me.chkT5.Enabled = False
						Me.chkT6.Enabled = False
						Me.chkT7.Enabled = False
						Me.chkCN.Enabled = False
						Me.chkFes.Enabled = False
						Me.btnDelete.Focus()
					Case 5, 6
						Me.txtOBJID.[ReadOnly] = False
				End Select
				Dim flag As Boolean = Operators.CompareString(Me.mStrFromDate, "", False) <> 0
				If flag Then
					Me.mtxFromDate.Text = Me.mStrFromDate
				End If
				flag = Operators.CompareString(Me.mStrToDate, "", False) <> 0
				If flag Then
					Me.mtxToDate.Text = Me.mStrToDate
				End If
				flag = Operators.CompareString(Me.mStrFromTime, "", False) <> 0
				If flag Then
					Me.mtxFromTime.Text = Me.mStrFromTime
				End If
				flag = Operators.CompareString(Me.mStrToTime, "", False) <> 0
				If flag Then
					Me.mtxToTime.Text = Me.mStrToTime
				End If
				flag = Operators.CompareString(Me.mstrOBJID, "", False) <> 0
				If flag Then
					Me.txtOBJID.Text = Me.mstrOBJID
				End If
				flag = Operators.CompareString(Me.mstrKHO, "", False) <> 0
				If flag Then
					Me.txtMAKH.Text = Me.mstrKHO
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001440 RID: 5184 RVA: 0x000F5E94 File Offset: 0x000F4094
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001441 RID: 5185 RVA: 0x000F6024 File Offset: 0x000F4224
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 10
				Me.txtOBJNAME.MaxLength = 100
				Me.txtMAKH.MaxLength = 3
				Me.txtTENKH.[ReadOnly] = True
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001442 RID: 5186 RVA: 0x000F6114 File Offset: 0x000F4314
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0014"
					Me.lblOBJNAME.Tag = "CB0015"
					Me.lblFromDate.Tag = "CB0018"
					Me.lblToDate.Tag = "CB0019"
					Me.lblFromTime.Tag = "CB0021"
					Me.lblToTime.Tag = "CB0022"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(mdlVariable.gStrPathApp + "\DISPLAY\" + mdlVariable.gStrLanguage + "\FRMDMGIAKARA2.TXT")
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(8))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(9))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(10))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(12))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(11))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001443 RID: 5187 RVA: 0x000F630C File Offset: 0x000F450C
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMKHO.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001444 RID: 5188 RVA: 0x000F63B8 File Offset: 0x000F45B8
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(16) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@PNCHOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@PNCHOBJNAME"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@PNCHMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKH.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@PDATEFROMDATE"
				array(3).Value = Strings.Trim(Me.mtxFromDate.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@PDATETODATE"
				array(4).Value = Strings.Trim(Me.mtxToDate.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pbitLDAY2"
				array(5).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT2.Checked, 1, 0))
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pbitLDAY3"
				array(6).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT3.Checked, 1, 0))
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pbitLDAY4"
				array(7).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT4.Checked, 1, 0))
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pbitLDAY5"
				array(8).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT5.Checked, 1, 0))
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pbitLDAY6"
				array(9).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT6.Checked, 1, 0))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pbitLDAY7"
				array(10).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT7.Checked, 1, 0))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pbitLDAY8"
				array(11).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCN.Checked, 1, 0))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pbitLDAY9"
				array(15).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkFes.Checked, 1, 0))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@PDATEFROMTIME"
				array(12).Value = Strings.Trim(Me.mtxFromTime.Text)
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@PDATETOTIME"
				array(13).Value = Strings.Trim(Me.mtxToTime.Text)
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@int_Result"
				array(14).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "INSERT_DATA_DMGIAKARA1", flag)
				Dim num As Integer = Conversions.ToInteger(array(14).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(31), MsgBoxStyle.Critical, Nothing)
						Me.txtMAKH.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(34), MsgBoxStyle.Critical, Nothing)
							Me.btnExit.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001445 RID: 5189 RVA: 0x000F6910 File Offset: 0x000F4B10
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(16) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@PNCHOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@PNCHOBJNAME"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@PNCHMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKH.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@PNVCFROMDATE"
				array(3).Value = Strings.Trim(Me.mtxFromDate.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@PNVCTODATE"
				array(4).Value = Strings.Trim(Me.mtxToDate.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pbitLDAY2"
				array(5).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT2.Checked, 1, 0))
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pbitLDAY3"
				array(6).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT3.Checked, 1, 0))
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pbitLDAY4"
				array(7).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT4.Checked, 1, 0))
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pbitLDAY5"
				array(8).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT5.Checked, 1, 0))
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pbitLDAY6"
				array(9).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT6.Checked, 1, 0))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pbitLDAY7"
				array(10).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT7.Checked, 1, 0))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pbitLDAY8"
				array(11).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCN.Checked, 1, 0))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pbitLDAY9"
				array(15).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkFes.Checked, 1, 0))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@PDATEFROMTIME"
				array(12).Value = Strings.Trim(Me.mtxFromTime.Text)
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@PDATETOTIME"
				array(13).Value = Strings.Trim(Me.mtxToTime.Text)
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@int_Result"
				array(14).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "UPDATE_DATA_DMGIAKARA1", flag)
				Dim num As Integer = Conversions.ToInteger(array(14).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(31), MsgBoxStyle.Critical, Nothing)
						Me.txtMAKH.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(33), MsgBoxStyle.Critical, Nothing)
							Me.btnExit.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001446 RID: 5190 RVA: 0x000F6E64 File Offset: 0x000F5064
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@PNCHOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "DELETE_DATA_DMGIAKARA1", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 2
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(33), MsgBoxStyle.Critical, Nothing)
						Me.btnExit.Focus()
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001447 RID: 5191 RVA: 0x000F7000 File Offset: 0x000F5200
		Private Sub sClearCheckBox()
			Try
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.chkT2.Checked = False
						Me.chkT3.Checked = False
						Me.chkT4.Checked = False
						Me.chkT5.Checked = False
						Me.chkT6.Checked = False
						Me.chkT7.Checked = False
						Me.chkCN.Checked = False
				End Select
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClearCheckBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001448 RID: 5192 RVA: 0x000F7118 File Offset: 0x000F5318
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001449 RID: 5193 RVA: 0x000F71C4 File Offset: 0x000F53C4
		Private Sub txtTENKH_GotFocus(sender As Object, e As EventArgs)
			Try
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENKH_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600144A RID: 5194 RVA: 0x000F7258 File Offset: 0x000F5458
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600144B RID: 5195 RVA: 0x000F72FC File Offset: 0x000F54FC
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMAKH.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600144C RID: 5196 RVA: 0x000F73A0 File Offset: 0x000F55A0
		Private Sub txtMAKH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtTENKH.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600144D RID: 5197 RVA: 0x000F7444 File Offset: 0x000F5644
		Private Sub txtTENKH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENKH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600144E RID: 5198 RVA: 0x000F74C8 File Offset: 0x000F56C8
		Private Sub cmbHTKM_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxFromDate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbHTKM_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600144F RID: 5199 RVA: 0x000F756C File Offset: 0x000F576C
		Private Sub mtxFromDate_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxToDate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxFromDate_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001450 RID: 5200 RVA: 0x000F7610 File Offset: 0x000F5810
		Private Sub mtxToDate_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT2.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxToDate_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001451 RID: 5201 RVA: 0x000F76B4 File Offset: 0x000F58B4
		Private Sub chkT2_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT3.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT2_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001452 RID: 5202 RVA: 0x000F7758 File Offset: 0x000F5958
		Private Sub chkT3_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT4.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT3_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001453 RID: 5203 RVA: 0x000F77FC File Offset: 0x000F59FC
		Private Sub chkT4_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT5.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT4_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001454 RID: 5204 RVA: 0x000F78A0 File Offset: 0x000F5AA0
		Private Sub chkT5_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT6.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT5_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001455 RID: 5205 RVA: 0x000F7944 File Offset: 0x000F5B44
		Private Sub chkT6_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT7.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT6_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001456 RID: 5206 RVA: 0x000F79E8 File Offset: 0x000F5BE8
		Private Sub chkT7_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkCN.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT7_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001457 RID: 5207 RVA: 0x000F7A8C File Offset: 0x000F5C8C
		Private Sub chkCN_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxFromTime.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkCN_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001458 RID: 5208 RVA: 0x000F7B30 File Offset: 0x000F5D30
		Private Sub mtxFromTime_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxToTime.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxFromTime_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001459 RID: 5209 RVA: 0x000F7BD4 File Offset: 0x000F5DD4
		Private Sub mtxToTime_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxToTime_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600145A RID: 5210 RVA: 0x000F7C58 File Offset: 0x000F5E58
		Private Sub txtMAKH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKHO Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMKHO.Columns("OBJID")
					Me.mclsTbDMKHO.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKHO.Rows.Find(Strings.Trim(Me.txtMAKH.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENKH.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENKH.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600145B RID: 5211 RVA: 0x000F7DAC File Offset: 0x000F5FAC
		Private Function fGetData_DMKH() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKHO = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = Me.mclsTbDMKHO IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMKH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600145C RID: 5212 RVA: 0x000F7E68 File Offset: 0x000F6068
		Private Function fGetData_DMNHOMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMNHOMDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNHOMDV")
				Dim flag As Boolean = Me.mclsTbDMNHOMDV IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMNHOMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600145D RID: 5213 RVA: 0x000F7F24 File Offset: 0x000F6124
		Public Sub gsCheckDate()
			Try
				Me.chkT2.Checked = True
				Me.chkT3.Checked = True
				Me.chkT4.Checked = True
				Me.chkT5.Checked = True
				Me.chkT6.Checked = True
				Me.chkT7.Checked = True
				Me.chkCN.Checked = True
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gsCheckDate ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600145E RID: 5214 RVA: 0x000F8010 File Offset: 0x000F6210
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x0600145F RID: 5215 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x04000841 RID: 2113
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000843 RID: 2115
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000844 RID: 2116
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000845 RID: 2117
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000846 RID: 2118
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000847 RID: 2119
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000848 RID: 2120
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000849 RID: 2121
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x0400084A RID: 2122
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x0400084B RID: 2123
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x0400084C RID: 2124
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x0400084D RID: 2125
		<AccessedThroughProperty("lblFromDate")>
		Private _lblFromDate As Label

		' Token: 0x0400084E RID: 2126
		<AccessedThroughProperty("txtTENKH")>
		Private _txtTENKH As TextBox

		' Token: 0x0400084F RID: 2127
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000850 RID: 2128
		<AccessedThroughProperty("txtMAKH")>
		Private _txtMAKH As TextBox

		' Token: 0x04000851 RID: 2129
		<AccessedThroughProperty("lblkHO")>
		Private _lblkHO As Label

		' Token: 0x04000852 RID: 2130
		<AccessedThroughProperty("lblToDate")>
		Private _lblToDate As Label

		' Token: 0x04000853 RID: 2131
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000854 RID: 2132
		<AccessedThroughProperty("lblToTime")>
		Private _lblToTime As Label

		' Token: 0x04000855 RID: 2133
		<AccessedThroughProperty("lblFromTime")>
		Private _lblFromTime As Label

		' Token: 0x04000856 RID: 2134
		<AccessedThroughProperty("chkT2")>
		Private _chkT2 As CheckBox

		' Token: 0x04000857 RID: 2135
		<AccessedThroughProperty("chkT3")>
		Private _chkT3 As CheckBox

		' Token: 0x04000858 RID: 2136
		<AccessedThroughProperty("chkT4")>
		Private _chkT4 As CheckBox

		' Token: 0x04000859 RID: 2137
		<AccessedThroughProperty("chkT5")>
		Private _chkT5 As CheckBox

		' Token: 0x0400085A RID: 2138
		<AccessedThroughProperty("chkT6")>
		Private _chkT6 As CheckBox

		' Token: 0x0400085B RID: 2139
		<AccessedThroughProperty("chkT7")>
		Private _chkT7 As CheckBox

		' Token: 0x0400085C RID: 2140
		<AccessedThroughProperty("chkCN")>
		Private _chkCN As CheckBox

		' Token: 0x0400085D RID: 2141
		<AccessedThroughProperty("mtxFromDate")>
		Private _mtxFromDate As MaskedTextBox

		' Token: 0x0400085E RID: 2142
		<AccessedThroughProperty("mtxToDate")>
		Private _mtxToDate As MaskedTextBox

		' Token: 0x0400085F RID: 2143
		<AccessedThroughProperty("mtxFromTime")>
		Private _mtxFromTime As MaskedTextBox

		' Token: 0x04000860 RID: 2144
		<AccessedThroughProperty("mtxToTime")>
		Private _mtxToTime As MaskedTextBox

		' Token: 0x04000861 RID: 2145
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000862 RID: 2146
		<AccessedThroughProperty("chkFes")>
		Private _chkFes As CheckBox

		' Token: 0x04000863 RID: 2147
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000864 RID: 2148
		Private mArrStrFrmMess As String()

		' Token: 0x04000865 RID: 2149
		Private mbytFormStatus As Byte

		' Token: 0x04000866 RID: 2150
		Private mbytSuccess As Byte

		' Token: 0x04000867 RID: 2151
		Private mstrKHO As String

		' Token: 0x04000868 RID: 2152
		Private mstrOBJID As String

		' Token: 0x04000869 RID: 2153
		Private mstrHTKM As String

		' Token: 0x0400086A RID: 2154
		Private mstrMaNHOMDV As Object

		' Token: 0x0400086B RID: 2155
		Private mStrFilter As String

		' Token: 0x0400086C RID: 2156
		Private mStrFromDate As String

		' Token: 0x0400086D RID: 2157
		Private mStrToDate As String

		' Token: 0x0400086E RID: 2158
		Private mStrFromTime As String

		' Token: 0x0400086F RID: 2159
		Private mStrToTime As String

		' Token: 0x04000870 RID: 2160
		Private mclsTbDMKHO As clsConnect

		' Token: 0x04000871 RID: 2161
		Private mclsTbDMNHOMDV As clsConnect

		' Token: 0x04000872 RID: 2162
		Private mclsTbDMKM As clsConnect
	End Class
End Namespace
