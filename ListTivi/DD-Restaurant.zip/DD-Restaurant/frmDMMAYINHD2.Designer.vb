﻿Namespace prjIS_SalesPOS
	' Token: 0x02000065 RID: 101
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMMAYINHD2
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06001FA3 RID: 8099 RVA: 0x00188D88 File Offset: 0x00186F88
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06001FA4 RID: 8100 RVA: 0x00188DC0 File Offset: 0x00186FC0
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMMAYINHD2))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.lblOBJNAME = New Global.System.Windows.Forms.Label()
			Me.txtOBJNAME = New Global.System.Windows.Forms.TextBox()
			Me.txtOBJID = New Global.System.Windows.Forms.TextBox()
			Me.lblOBJID = New Global.System.Windows.Forms.Label()
			Me.lblTimeOut = New Global.System.Windows.Forms.Label()
			Me.lblPrintCount = New Global.System.Windows.Forms.Label()
			Me.lblComputer = New Global.System.Windows.Forms.Label()
			Me.txtCOMName = New Global.System.Windows.Forms.TextBox()
			Me.txtBaudrate = New Global.System.Windows.Forms.TextBox()
			Me.txtDataBit = New Global.System.Windows.Forms.TextBox()
			Me.txtParityBit = New Global.System.Windows.Forms.TextBox()
			Me.txtStopBit = New Global.System.Windows.Forms.TextBox()
			Me.txtFlowControl = New Global.System.Windows.Forms.TextBox()
			Me.txtTimeOut = New Global.System.Windows.Forms.TextBox()
			Me.txtPrintCount = New Global.System.Windows.Forms.TextBox()
			Me.lblCOMName = New Global.System.Windows.Forms.Label()
			Me.lblBaudrate = New Global.System.Windows.Forms.Label()
			Me.lblDataBit = New Global.System.Windows.Forms.Label()
			Me.lblParityBit = New Global.System.Windows.Forms.Label()
			Me.lblStopBit = New Global.System.Windows.Forms.Label()
			Me.lblFlowControl = New Global.System.Windows.Forms.Label()
			Me.txtColor = New Global.System.Windows.Forms.TextBox()
			Me.txtRemark = New Global.System.Windows.Forms.TextBox()
			Me.lblRemark = New Global.System.Windows.Forms.Label()
			Me.txtTENMAY = New Global.System.Windows.Forms.TextBox()
			Me.txtMAMAY = New Global.System.Windows.Forms.TextBox()
			Me.btnDMMAY = New Global.System.Windows.Forms.Button()
			Me.cmbBaudrate = New Global.System.Windows.Forms.ComboBox()
			Me.cmbDataBit = New Global.System.Windows.Forms.ComboBox()
			Me.cmbParityBit = New Global.System.Windows.Forms.ComboBox()
			Me.cmbStopBit = New Global.System.Windows.Forms.ComboBox()
			Me.cmbFlowControl = New Global.System.Windows.Forms.ComboBox()
			Me.cmbCOMName = New Global.System.Windows.Forms.ComboBox()
			Me.cmbLoaiMayIn = New Global.System.Windows.Forms.ComboBox()
			Me.lblLoaiMayIn = New Global.System.Windows.Forms.Label()
			Me.lblLOPENDRAWERTAMTINH = New Global.System.Windows.Forms.Label()
			Me.chkLOPENDRAWERTAMTINH = New Global.System.Windows.Forms.CheckBox()
			Me.lblLOPENDRAWER = New Global.System.Windows.Forms.Label()
			Me.chkLOPENDRAWER = New Global.System.Windows.Forms.CheckBox()
			Me.txtPrintWidth = New Global.System.Windows.Forms.TextBox()
			Me.lblPrintW = New Global.System.Windows.Forms.Label()
			Me.LblMAMAYTINHCALL = New Global.System.Windows.Forms.Label()
			Me.txtTENMAYCALL = New Global.System.Windows.Forms.TextBox()
			Me.TxtMAMAYCALL = New Global.System.Windows.Forms.TextBox()
			Me.btnSECLECTMAYCALL = New Global.System.Windows.Forms.Button()
			Me.txtTOP = New Global.System.Windows.Forms.TextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.txtLEFT = New Global.System.Windows.Forms.TextBox()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.txtRight = New Global.System.Windows.Forms.TextBox()
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.txtBottom = New Global.System.Windows.Forms.TextBox()
			Me.Label4 = New Global.System.Windows.Forms.Label()
			Me.Label5 = New Global.System.Windows.Forms.Label()
			Me.Label6 = New Global.System.Windows.Forms.Label()
			Me.Label7 = New Global.System.Windows.Forms.Label()
			Me.Label8 = New Global.System.Windows.Forms.Label()
			Me.lblMargin = New Global.System.Windows.Forms.Label()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(575, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 526)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 23
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnKeyboard, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 2)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 6
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 505)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnKeyboard.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnKeyboard.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(3, 3)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(107, 78)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 171
			Me.btnKeyboard.Text = "Keyboard"
			Me.btnKeyboard.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 255)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(107, 78)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 6
			Me.btnFilter.Tag = "CR0005"
			Me.btnFilter.Text = "Lọ&c"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 423)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 79)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 87)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(107, 78)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 4
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 339)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(107, 78)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 7
			Me.btnFind.Tag = "CR0006"
			Me.btnFind.Text = "&Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 171)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 78)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 5
			Me.btnDelete.Tag = "CR0004"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.lblOBJNAME.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJNAME As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			point = New Global.System.Drawing.Point(7, 35)
			lblOBJNAME.Location = point
			Me.lblOBJNAME.Name = "lblOBJNAME"
			Dim lblOBJNAME2 As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			size = New Global.System.Drawing.Size(154, 21)
			lblOBJNAME2.Size = size
			Me.lblOBJNAME.TabIndex = 34
			Me.lblOBJNAME.Tag = "CR0008"
			Me.lblOBJNAME.Text = "Tên máy in"
			Me.txtOBJNAME.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJNAME As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			point = New Global.System.Drawing.Point(169, 34)
			txtOBJNAME.Location = point
			Me.txtOBJNAME.Name = "txtOBJNAME"
			Dim txtOBJNAME2 As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			size = New Global.System.Drawing.Size(400, 22)
			txtOBJNAME2.Size = size
			Me.txtOBJNAME.TabIndex = 1
			Me.txtOBJNAME.Tag = "0R0000"
			Me.txtOBJID.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJID As Global.System.Windows.Forms.Control = Me.txtOBJID
			point = New Global.System.Drawing.Point(169, 8)
			txtOBJID.Location = point
			Me.txtOBJID.Name = "txtOBJID"
			Dim txtOBJID2 As Global.System.Windows.Forms.Control = Me.txtOBJID
			size = New Global.System.Drawing.Size(173, 22)
			txtOBJID2.Size = size
			Me.txtOBJID.TabIndex = 0
			Me.txtOBJID.Tag = "0R0000"
			Me.lblOBJID.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJID As Global.System.Windows.Forms.Control = Me.lblOBJID
			point = New Global.System.Drawing.Point(7, 9)
			lblOBJID.Location = point
			Me.lblOBJID.Name = "lblOBJID"
			Dim lblOBJID2 As Global.System.Windows.Forms.Control = Me.lblOBJID
			size = New Global.System.Drawing.Size(154, 21)
			lblOBJID2.Size = size
			Me.lblOBJID.TabIndex = 33
			Me.lblOBJID.Tag = "CR0007"
			Me.lblOBJID.Text = "Mã máy in"
			Me.lblTimeOut.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblTimeOut As Global.System.Windows.Forms.Control = Me.lblTimeOut
			point = New Global.System.Drawing.Point(7, 317)
			lblTimeOut.Location = point
			Me.lblTimeOut.Name = "lblTimeOut"
			Dim lblTimeOut2 As Global.System.Windows.Forms.Control = Me.lblTimeOut
			size = New Global.System.Drawing.Size(154, 21)
			lblTimeOut2.Size = size
			Me.lblTimeOut.TabIndex = 39
			Me.lblTimeOut.Tag = "CR0038"
			Me.lblTimeOut.Text = "Time out"
			Me.lblPrintCount.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPrintCount As Global.System.Windows.Forms.Control = Me.lblPrintCount
			point = New Global.System.Drawing.Point(7, 345)
			lblPrintCount.Location = point
			Me.lblPrintCount.Name = "lblPrintCount"
			Dim lblPrintCount2 As Global.System.Windows.Forms.Control = Me.lblPrintCount
			size = New Global.System.Drawing.Size(154, 21)
			lblPrintCount2.Size = size
			Me.lblPrintCount.TabIndex = 40
			Me.lblPrintCount.Tag = "CR0039"
			Me.lblPrintCount.Text = "Số lần in"
			Me.lblComputer.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblComputer As Global.System.Windows.Forms.Control = Me.lblComputer
			point = New Global.System.Drawing.Point(7, 91)
			lblComputer.Location = point
			Me.lblComputer.Name = "lblComputer"
			Dim lblComputer2 As Global.System.Windows.Forms.Control = Me.lblComputer
			size = New Global.System.Drawing.Size(154, 21)
			lblComputer2.Size = size
			Me.lblComputer.TabIndex = 42
			Me.lblComputer.Tag = "CR0031"
			Me.lblComputer.Text = "Mã máy tính"
			Me.txtCOMName.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtCOMName As Global.System.Windows.Forms.Control = Me.txtCOMName
			point = New Global.System.Drawing.Point(308, 150)
			txtCOMName.Location = point
			Me.txtCOMName.Name = "txtCOMName"
			Dim txtCOMName2 As Global.System.Windows.Forms.Control = Me.txtCOMName
			size = New Global.System.Drawing.Size(100, 22)
			txtCOMName2.Size = size
			Me.txtCOMName.TabIndex = 6
			Me.txtCOMName.Tag = "0R0000"
			Me.txtCOMName.Visible = False
			Me.txtBaudrate.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtBaudrate As Global.System.Windows.Forms.Control = Me.txtBaudrate
			point = New Global.System.Drawing.Point(308, 179)
			txtBaudrate.Location = point
			Me.txtBaudrate.Name = "txtBaudrate"
			Dim txtBaudrate2 As Global.System.Windows.Forms.Control = Me.txtBaudrate
			size = New Global.System.Drawing.Size(100, 22)
			txtBaudrate2.Size = size
			Me.txtBaudrate.TabIndex = 8
			Me.txtBaudrate.Tag = "0R0000"
			Me.txtBaudrate.Visible = False
			Me.txtDataBit.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtDataBit As Global.System.Windows.Forms.Control = Me.txtDataBit
			point = New Global.System.Drawing.Point(308, 206)
			txtDataBit.Location = point
			Me.txtDataBit.Name = "txtDataBit"
			Dim txtDataBit2 As Global.System.Windows.Forms.Control = Me.txtDataBit
			size = New Global.System.Drawing.Size(100, 22)
			txtDataBit2.Size = size
			Me.txtDataBit.TabIndex = 10
			Me.txtDataBit.Tag = "0R0000"
			Me.txtDataBit.Visible = False
			Me.txtParityBit.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtParityBit As Global.System.Windows.Forms.Control = Me.txtParityBit
			point = New Global.System.Drawing.Point(308, 234)
			txtParityBit.Location = point
			Me.txtParityBit.Name = "txtParityBit"
			Dim txtParityBit2 As Global.System.Windows.Forms.Control = Me.txtParityBit
			size = New Global.System.Drawing.Size(100, 22)
			txtParityBit2.Size = size
			Me.txtParityBit.TabIndex = 12
			Me.txtParityBit.Tag = "0R0000"
			Me.txtParityBit.Visible = False
			Me.txtStopBit.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtStopBit As Global.System.Windows.Forms.Control = Me.txtStopBit
			point = New Global.System.Drawing.Point(308, 261)
			txtStopBit.Location = point
			Me.txtStopBit.Name = "txtStopBit"
			Dim txtStopBit2 As Global.System.Windows.Forms.Control = Me.txtStopBit
			size = New Global.System.Drawing.Size(100, 22)
			txtStopBit2.Size = size
			Me.txtStopBit.TabIndex = 14
			Me.txtStopBit.Tag = "0R0000"
			Me.txtStopBit.Visible = False
			Me.txtFlowControl.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtFlowControl As Global.System.Windows.Forms.Control = Me.txtFlowControl
			point = New Global.System.Drawing.Point(308, 290)
			txtFlowControl.Location = point
			Me.txtFlowControl.Name = "txtFlowControl"
			Dim txtFlowControl2 As Global.System.Windows.Forms.Control = Me.txtFlowControl
			size = New Global.System.Drawing.Size(100, 22)
			txtFlowControl2.Size = size
			Me.txtFlowControl.TabIndex = 16
			Me.txtFlowControl.Tag = "0R0000"
			Me.txtFlowControl.Visible = False
			Me.txtTimeOut.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtTimeOut As Global.System.Windows.Forms.Control = Me.txtTimeOut
			point = New Global.System.Drawing.Point(169, 318)
			txtTimeOut.Location = point
			Me.txtTimeOut.Name = "txtTimeOut"
			Dim txtTimeOut2 As Global.System.Windows.Forms.Control = Me.txtTimeOut
			size = New Global.System.Drawing.Size(120, 22)
			txtTimeOut2.Size = size
			Me.txtTimeOut.TabIndex = 17
			Me.txtTimeOut.Tag = "0R0000"
			Me.txtPrintCount.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPrintCount As Global.System.Windows.Forms.Control = Me.txtPrintCount
			point = New Global.System.Drawing.Point(169, 348)
			txtPrintCount.Location = point
			Me.txtPrintCount.Name = "txtPrintCount"
			Dim txtPrintCount2 As Global.System.Windows.Forms.Control = Me.txtPrintCount
			size = New Global.System.Drawing.Size(120, 22)
			txtPrintCount2.Size = size
			Me.txtPrintCount.TabIndex = 19
			Me.txtPrintCount.Tag = "0R0000"
			Me.lblCOMName.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblCOMName As Global.System.Windows.Forms.Control = Me.lblCOMName
			point = New Global.System.Drawing.Point(7, 149)
			lblCOMName.Location = point
			Me.lblCOMName.Name = "lblCOMName"
			Dim lblCOMName2 As Global.System.Windows.Forms.Control = Me.lblCOMName
			size = New Global.System.Drawing.Size(154, 21)
			lblCOMName2.Size = size
			Me.lblCOMName.TabIndex = 54
			Me.lblCOMName.Tag = "CR0032"
			Me.lblCOMName.Text = "Tên cổng COM"
			Me.lblBaudrate.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblBaudrate As Global.System.Windows.Forms.Control = Me.lblBaudrate
			point = New Global.System.Drawing.Point(7, 177)
			lblBaudrate.Location = point
			Me.lblBaudrate.Name = "lblBaudrate"
			Dim lblBaudrate2 As Global.System.Windows.Forms.Control = Me.lblBaudrate
			size = New Global.System.Drawing.Size(154, 21)
			lblBaudrate2.Size = size
			Me.lblBaudrate.TabIndex = 55
			Me.lblBaudrate.Tag = "CR0033"
			Me.lblBaudrate.Text = "Tốc độ"
			Me.lblDataBit.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblDataBit As Global.System.Windows.Forms.Control = Me.lblDataBit
			point = New Global.System.Drawing.Point(7, 205)
			lblDataBit.Location = point
			Me.lblDataBit.Name = "lblDataBit"
			Dim lblDataBit2 As Global.System.Windows.Forms.Control = Me.lblDataBit
			size = New Global.System.Drawing.Size(154, 21)
			lblDataBit2.Size = size
			Me.lblDataBit.TabIndex = 56
			Me.lblDataBit.Tag = "CR0034"
			Me.lblDataBit.Text = "Data Bits"
			Me.lblParityBit.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblParityBit As Global.System.Windows.Forms.Control = Me.lblParityBit
			point = New Global.System.Drawing.Point(7, 233)
			lblParityBit.Location = point
			Me.lblParityBit.Name = "lblParityBit"
			Dim lblParityBit2 As Global.System.Windows.Forms.Control = Me.lblParityBit
			size = New Global.System.Drawing.Size(154, 21)
			lblParityBit2.Size = size
			Me.lblParityBit.TabIndex = 57
			Me.lblParityBit.Tag = "CR0035"
			Me.lblParityBit.Text = "Parity Bits"
			Me.lblStopBit.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblStopBit As Global.System.Windows.Forms.Control = Me.lblStopBit
			point = New Global.System.Drawing.Point(7, 261)
			lblStopBit.Location = point
			Me.lblStopBit.Name = "lblStopBit"
			Dim lblStopBit2 As Global.System.Windows.Forms.Control = Me.lblStopBit
			size = New Global.System.Drawing.Size(154, 21)
			lblStopBit2.Size = size
			Me.lblStopBit.TabIndex = 58
			Me.lblStopBit.Tag = "CR0036"
			Me.lblStopBit.Text = "Stop Bits"
			Me.lblFlowControl.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFlowControl As Global.System.Windows.Forms.Control = Me.lblFlowControl
			point = New Global.System.Drawing.Point(7, 289)
			lblFlowControl.Location = point
			Me.lblFlowControl.Name = "lblFlowControl"
			Dim lblFlowControl2 As Global.System.Windows.Forms.Control = Me.lblFlowControl
			size = New Global.System.Drawing.Size(154, 21)
			lblFlowControl2.Size = size
			Me.lblFlowControl.TabIndex = 59
			Me.lblFlowControl.Tag = "CR0037"
			Me.lblFlowControl.Text = "Flow Control"
			Me.txtColor.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtColor As Global.System.Windows.Forms.Control = Me.txtColor
			point = New Global.System.Drawing.Point(448, 6)
			txtColor.Location = point
			Me.txtColor.Name = "txtColor"
			Dim txtColor2 As Global.System.Windows.Forms.Control = Me.txtColor
			size = New Global.System.Drawing.Size(69, 22)
			txtColor2.Size = size
			Me.txtColor.TabIndex = 64
			Me.txtColor.Tag = "0R0000"
			Me.txtColor.Visible = False
			Me.txtRemark.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtRemark As Global.System.Windows.Forms.Control = Me.txtRemark
			point = New Global.System.Drawing.Point(169, 376)
			txtRemark.Location = point
			Me.txtRemark.Multiline = True
			Me.txtRemark.Name = "txtRemark"
			Dim txtRemark2 As Global.System.Windows.Forms.Control = Me.txtRemark
			size = New Global.System.Drawing.Size(400, 46)
			txtRemark2.Size = size
			Me.txtRemark.TabIndex = 21
			Me.txtRemark.Tag = "0R0000"
			Me.lblRemark.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblRemark As Global.System.Windows.Forms.Control = Me.lblRemark
			point = New Global.System.Drawing.Point(7, 388)
			lblRemark.Location = point
			Me.lblRemark.Name = "lblRemark"
			Dim lblRemark2 As Global.System.Windows.Forms.Control = Me.lblRemark
			size = New Global.System.Drawing.Size(154, 21)
			lblRemark2.Size = size
			Me.lblRemark.TabIndex = 66
			Me.lblRemark.Tag = "CR0040"
			Me.lblRemark.Text = "Ghi chú"
			Me.txtTENMAY.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENMAY As Global.System.Windows.Forms.Control = Me.txtTENMAY
			point = New Global.System.Drawing.Point(348, 92)
			txtTENMAY.Location = point
			Me.txtTENMAY.Name = "txtTENMAY"
			Me.txtTENMAY.[ReadOnly] = True
			Dim txtTENMAY2 As Global.System.Windows.Forms.Control = Me.txtTENMAY
			size = New Global.System.Drawing.Size(221, 22)
			txtTENMAY2.Size = size
			Me.txtTENMAY.TabIndex = 103
			Me.txtTENMAY.TabStop = False
			Me.txtTENMAY.Tag = "0R0000"
			Me.txtMAMAY.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAMAY As Global.System.Windows.Forms.Control = Me.txtMAMAY
			point = New Global.System.Drawing.Point(169, 92)
			txtMAMAY.Location = point
			Me.txtMAMAY.Name = "txtMAMAY"
			Dim txtMAMAY2 As Global.System.Windows.Forms.Control = Me.txtMAMAY
			size = New Global.System.Drawing.Size(122, 22)
			txtMAMAY2.Size = size
			Me.txtMAMAY.TabIndex = 3
			Me.txtMAMAY.Tag = "0R0000"
			Me.btnDMMAY.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMMAY As Global.System.Windows.Forms.Control = Me.btnDMMAY
			point = New Global.System.Drawing.Point(297, 92)
			btnDMMAY.Location = point
			Me.btnDMMAY.Name = "btnDMMAY"
			Dim btnDMMAY2 As Global.System.Windows.Forms.Control = Me.btnDMMAY
			size = New Global.System.Drawing.Size(45, 22)
			btnDMMAY2.Size = size
			Me.btnDMMAY.TabIndex = 3
			Me.btnDMMAY.Tag = "CB0011"
			Me.btnDMMAY.UseVisualStyleBackColor = True
			Me.cmbBaudrate.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbBaudrate.FormattingEnabled = True
			Me.cmbBaudrate.IntegralHeight = False
			Me.cmbBaudrate.ItemHeight = 16
			Dim cmbBaudrate As Global.System.Windows.Forms.Control = Me.cmbBaudrate
			point = New Global.System.Drawing.Point(169, 177)
			cmbBaudrate.Location = point
			Me.cmbBaudrate.Name = "cmbBaudrate"
			Dim cmbBaudrate2 As Global.System.Windows.Forms.Control = Me.cmbBaudrate
			size = New Global.System.Drawing.Size(120, 24)
			cmbBaudrate2.Size = size
			Me.cmbBaudrate.TabIndex = 7
			Me.cmbDataBit.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbDataBit.FormattingEnabled = True
			Me.cmbDataBit.IntegralHeight = False
			Me.cmbDataBit.ItemHeight = 16
			Dim cmbDataBit As Global.System.Windows.Forms.Control = Me.cmbDataBit
			point = New Global.System.Drawing.Point(169, 205)
			cmbDataBit.Location = point
			Me.cmbDataBit.Name = "cmbDataBit"
			Dim cmbDataBit2 As Global.System.Windows.Forms.Control = Me.cmbDataBit
			size = New Global.System.Drawing.Size(120, 24)
			cmbDataBit2.Size = size
			Me.cmbDataBit.TabIndex = 9
			Me.cmbParityBit.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbParityBit.FormattingEnabled = True
			Me.cmbParityBit.IntegralHeight = False
			Me.cmbParityBit.ItemHeight = 16
			Dim cmbParityBit As Global.System.Windows.Forms.Control = Me.cmbParityBit
			point = New Global.System.Drawing.Point(169, 233)
			cmbParityBit.Location = point
			Me.cmbParityBit.Name = "cmbParityBit"
			Dim cmbParityBit2 As Global.System.Windows.Forms.Control = Me.cmbParityBit
			size = New Global.System.Drawing.Size(120, 24)
			cmbParityBit2.Size = size
			Me.cmbParityBit.TabIndex = 11
			Me.cmbStopBit.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbStopBit.FormattingEnabled = True
			Me.cmbStopBit.IntegralHeight = False
			Me.cmbStopBit.ItemHeight = 16
			Dim cmbStopBit As Global.System.Windows.Forms.Control = Me.cmbStopBit
			point = New Global.System.Drawing.Point(169, 259)
			cmbStopBit.Location = point
			Me.cmbStopBit.Name = "cmbStopBit"
			Dim cmbStopBit2 As Global.System.Windows.Forms.Control = Me.cmbStopBit
			size = New Global.System.Drawing.Size(120, 24)
			cmbStopBit2.Size = size
			Me.cmbStopBit.TabIndex = 13
			Me.cmbFlowControl.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbFlowControl.FormattingEnabled = True
			Me.cmbFlowControl.IntegralHeight = False
			Me.cmbFlowControl.ItemHeight = 16
			Dim cmbFlowControl As Global.System.Windows.Forms.Control = Me.cmbFlowControl
			point = New Global.System.Drawing.Point(169, 288)
			cmbFlowControl.Location = point
			Me.cmbFlowControl.Name = "cmbFlowControl"
			Dim cmbFlowControl2 As Global.System.Windows.Forms.Control = Me.cmbFlowControl
			size = New Global.System.Drawing.Size(120, 24)
			cmbFlowControl2.Size = size
			Me.cmbFlowControl.TabIndex = 15
			Me.cmbCOMName.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbCOMName.FormattingEnabled = True
			Me.cmbCOMName.IntegralHeight = False
			Me.cmbCOMName.ItemHeight = 16
			Dim cmbCOMName As Global.System.Windows.Forms.Control = Me.cmbCOMName
			point = New Global.System.Drawing.Point(169, 148)
			cmbCOMName.Location = point
			Me.cmbCOMName.Name = "cmbCOMName"
			Dim cmbCOMName2 As Global.System.Windows.Forms.Control = Me.cmbCOMName
			size = New Global.System.Drawing.Size(120, 24)
			cmbCOMName2.Size = size
			Me.cmbCOMName.TabIndex = 5
			Me.cmbLoaiMayIn.DropDownHeight = 150
			Me.cmbLoaiMayIn.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbLoaiMayIn.FormattingEnabled = True
			Me.cmbLoaiMayIn.IntegralHeight = False
			Me.cmbLoaiMayIn.ItemHeight = 16
			Dim cmbLoaiMayIn As Global.System.Windows.Forms.Control = Me.cmbLoaiMayIn
			point = New Global.System.Drawing.Point(169, 62)
			cmbLoaiMayIn.Location = point
			Me.cmbLoaiMayIn.MaxDropDownItems = 18
			Me.cmbLoaiMayIn.Name = "cmbLoaiMayIn"
			Dim cmbLoaiMayIn2 As Global.System.Windows.Forms.Control = Me.cmbLoaiMayIn
			size = New Global.System.Drawing.Size(399, 24)
			cmbLoaiMayIn2.Size = size
			Me.cmbLoaiMayIn.TabIndex = 2
			Me.lblLoaiMayIn.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblLoaiMayIn As Global.System.Windows.Forms.Control = Me.lblLoaiMayIn
			point = New Global.System.Drawing.Point(7, 63)
			lblLoaiMayIn.Location = point
			Me.lblLoaiMayIn.Name = "lblLoaiMayIn"
			Dim lblLoaiMayIn2 As Global.System.Windows.Forms.Control = Me.lblLoaiMayIn
			size = New Global.System.Drawing.Size(154, 21)
			lblLoaiMayIn2.Size = size
			Me.lblLoaiMayIn.TabIndex = 105
			Me.lblLoaiMayIn.Tag = "CR0091"
			Me.lblLoaiMayIn.Text = "Loại máy in"
			Me.lblLOPENDRAWERTAMTINH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblLOPENDRAWERTAMTINH As Global.System.Windows.Forms.Control = Me.lblLOPENDRAWERTAMTINH
			point = New Global.System.Drawing.Point(305, 350)
			lblLOPENDRAWERTAMTINH.Location = point
			Me.lblLOPENDRAWERTAMTINH.Name = "lblLOPENDRAWERTAMTINH"
			Dim lblLOPENDRAWERTAMTINH2 As Global.System.Windows.Forms.Control = Me.lblLOPENDRAWERTAMTINH
			size = New Global.System.Drawing.Size(225, 21)
			lblLOPENDRAWERTAMTINH2.Size = size
			Me.lblLOPENDRAWERTAMTINH.TabIndex = 18
			Me.lblLOPENDRAWERTAMTINH.Tag = "CR0092"
			Me.lblLOPENDRAWERTAMTINH.Text = "Mở két khi in tạm tính"
			Me.chkLOPENDRAWERTAMTINH.AutoSize = True
			Dim chkLOPENDRAWERTAMTINH As Global.System.Windows.Forms.Control = Me.chkLOPENDRAWERTAMTINH
			point = New Global.System.Drawing.Point(554, 352)
			chkLOPENDRAWERTAMTINH.Location = point
			Me.chkLOPENDRAWERTAMTINH.Name = "chkLOPENDRAWERTAMTINH"
			Dim chkLOPENDRAWERTAMTINH2 As Global.System.Windows.Forms.Control = Me.chkLOPENDRAWERTAMTINH
			size = New Global.System.Drawing.Size(15, 14)
			chkLOPENDRAWERTAMTINH2.Size = size
			Me.chkLOPENDRAWERTAMTINH.TabIndex = 107
			Me.chkLOPENDRAWERTAMTINH.UseVisualStyleBackColor = True
			Me.lblLOPENDRAWER.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblLOPENDRAWER As Global.System.Windows.Forms.Control = Me.lblLOPENDRAWER
			point = New Global.System.Drawing.Point(305, 321)
			lblLOPENDRAWER.Location = point
			Me.lblLOPENDRAWER.Name = "lblLOPENDRAWER"
			Dim lblLOPENDRAWER2 As Global.System.Windows.Forms.Control = Me.lblLOPENDRAWER
			size = New Global.System.Drawing.Size(225, 21)
			lblLOPENDRAWER2.Size = size
			Me.lblLOPENDRAWER.TabIndex = 20
			Me.lblLOPENDRAWER.Tag = "CR0101"
			Me.lblLOPENDRAWER.Text = "Mở két khi thanh toán"
			Me.chkLOPENDRAWER.AutoSize = True
			Dim chkLOPENDRAWER As Global.System.Windows.Forms.Control = Me.chkLOPENDRAWER
			point = New Global.System.Drawing.Point(554, 325)
			chkLOPENDRAWER.Location = point
			Me.chkLOPENDRAWER.Name = "chkLOPENDRAWER"
			Dim chkLOPENDRAWER2 As Global.System.Windows.Forms.Control = Me.chkLOPENDRAWER
			size = New Global.System.Drawing.Size(15, 14)
			chkLOPENDRAWER2.Size = size
			Me.chkLOPENDRAWER.TabIndex = 109
			Me.chkLOPENDRAWER.UseVisualStyleBackColor = True
			Me.txtPrintWidth.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPrintWidth As Global.System.Windows.Forms.Control = Me.txtPrintWidth
			point = New Global.System.Drawing.Point(169, 428)
			txtPrintWidth.Location = point
			Me.txtPrintWidth.Name = "txtPrintWidth"
			Dim txtPrintWidth2 As Global.System.Windows.Forms.Control = Me.txtPrintWidth
			size = New Global.System.Drawing.Size(120, 22)
			txtPrintWidth2.Size = size
			Me.txtPrintWidth.TabIndex = 22
			Me.txtPrintWidth.Tag = "0R0000"
			Me.txtPrintWidth.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.lblPrintW.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPrintW As Global.System.Windows.Forms.Control = Me.lblPrintW
			point = New Global.System.Drawing.Point(7, 428)
			lblPrintW.Location = point
			Me.lblPrintW.Name = "lblPrintW"
			Dim lblPrintW2 As Global.System.Windows.Forms.Control = Me.lblPrintW
			size = New Global.System.Drawing.Size(154, 21)
			lblPrintW2.Size = size
			Me.lblPrintW.TabIndex = 113
			Me.lblPrintW.Tag = "CR0103"
			Me.lblPrintW.Text = "BE RONG"
			Me.LblMAMAYTINHCALL.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAMAYTINHCALL As Global.System.Windows.Forms.Control = Me.LblMAMAYTINHCALL
			point = New Global.System.Drawing.Point(8, 120)
			lblMAMAYTINHCALL.Location = point
			Me.LblMAMAYTINHCALL.Name = "LblMAMAYTINHCALL"
			Dim lblMAMAYTINHCALL2 As Global.System.Windows.Forms.Control = Me.LblMAMAYTINHCALL
			size = New Global.System.Drawing.Size(154, 21)
			lblMAMAYTINHCALL2.Size = size
			Me.LblMAMAYTINHCALL.TabIndex = 131
			Me.LblMAMAYTINHCALL.Tag = "CR0105"
			Me.LblMAMAYTINHCALL.Text = "Mã máy tính"
			Me.txtTENMAYCALL.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENMAYCALL As Global.System.Windows.Forms.Control = Me.txtTENMAYCALL
			point = New Global.System.Drawing.Point(348, 120)
			txtTENMAYCALL.Location = point
			Me.txtTENMAYCALL.Name = "txtTENMAYCALL"
			Me.txtTENMAYCALL.[ReadOnly] = True
			Dim txtTENMAYCALL2 As Global.System.Windows.Forms.Control = Me.txtTENMAYCALL
			size = New Global.System.Drawing.Size(221, 22)
			txtTENMAYCALL2.Size = size
			Me.txtTENMAYCALL.TabIndex = 130
			Me.txtTENMAYCALL.TabStop = False
			Me.txtTENMAYCALL.Tag = "0R0000"
			Me.TxtMAMAYCALL.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAMAYCALL As Global.System.Windows.Forms.Control = Me.TxtMAMAYCALL
			point = New Global.System.Drawing.Point(170, 120)
			txtMAMAYCALL.Location = point
			Me.TxtMAMAYCALL.Name = "TxtMAMAYCALL"
			Dim txtMAMAYCALL2 As Global.System.Windows.Forms.Control = Me.TxtMAMAYCALL
			size = New Global.System.Drawing.Size(121, 22)
			txtMAMAYCALL2.Size = size
			Me.TxtMAMAYCALL.TabIndex = 4
			Me.TxtMAMAYCALL.Tag = "0R0000"
			Me.btnSECLECTMAYCALL.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnSECLECTMAYCALL As Global.System.Windows.Forms.Control = Me.btnSECLECTMAYCALL
			point = New Global.System.Drawing.Point(297, 119)
			btnSECLECTMAYCALL.Location = point
			Me.btnSECLECTMAYCALL.Name = "btnSECLECTMAYCALL"
			Dim btnSECLECTMAYCALL2 As Global.System.Windows.Forms.Control = Me.btnSECLECTMAYCALL
			size = New Global.System.Drawing.Size(45, 22)
			btnSECLECTMAYCALL2.Size = size
			Me.btnSECLECTMAYCALL.TabIndex = 129
			Me.btnSECLECTMAYCALL.Tag = "CB0011"
			Me.btnSECLECTMAYCALL.UseVisualStyleBackColor = True
			Me.txtTOP.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtTOP As Global.System.Windows.Forms.Control = Me.txtTOP
			point = New Global.System.Drawing.Point(168, 455)
			txtTOP.Location = point
			Me.txtTOP.Name = "txtTOP"
			Dim txtTOP2 As Global.System.Windows.Forms.Control = Me.txtTOP
			size = New Global.System.Drawing.Size(120, 22)
			txtTOP2.Size = size
			Me.txtTOP.TabIndex = 132
			Me.txtTOP.Tag = "0R0000"
			Me.txtTOP.Text = "0"
			Me.txtTOP.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(9, 456)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(154, 21)
			label2.Size = size
			Me.Label1.TabIndex = 133
			Me.Label1.Tag = "CR0106"
			Me.Label1.Text = "top"
			Me.txtLEFT.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtLEFT As Global.System.Windows.Forms.Control = Me.txtLEFT
			point = New Global.System.Drawing.Point(397, 456)
			txtLEFT.Location = point
			Me.txtLEFT.Name = "txtLEFT"
			Dim txtLEFT2 As Global.System.Windows.Forms.Control = Me.txtLEFT
			size = New Global.System.Drawing.Size(120, 22)
			txtLEFT2.Size = size
			Me.txtLEFT.TabIndex = 134
			Me.txtLEFT.Tag = "0R0000"
			Me.txtLEFT.Text = "0"
			Me.txtLEFT.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(342, 456)
			label3.Location = point
			Me.Label2.Name = "Label2"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(51, 21)
			label4.Size = size
			Me.Label2.TabIndex = 135
			Me.Label2.Tag = "CR0107"
			Me.Label2.Text = "left"
			Me.txtRight.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtRight As Global.System.Windows.Forms.Control = Me.txtRight
			point = New Global.System.Drawing.Point(397, 484)
			txtRight.Location = point
			Me.txtRight.Name = "txtRight"
			Dim txtRight2 As Global.System.Windows.Forms.Control = Me.txtRight
			size = New Global.System.Drawing.Size(120, 22)
			txtRight2.Size = size
			Me.txtRight.TabIndex = 138
			Me.txtRight.Tag = "0R0000"
			Me.txtRight.Text = "0"
			Me.txtRight.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label3.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(342, 484)
			label5.Location = point
			Me.Label3.Name = "Label3"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(51, 21)
			label6.Size = size
			Me.Label3.TabIndex = 139
			Me.Label3.Tag = "CR0109"
			Me.Label3.Text = "right"
			Me.txtBottom.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtBottom As Global.System.Windows.Forms.Control = Me.txtBottom
			point = New Global.System.Drawing.Point(168, 483)
			txtBottom.Location = point
			Me.txtBottom.Name = "txtBottom"
			Dim txtBottom2 As Global.System.Windows.Forms.Control = Me.txtBottom
			size = New Global.System.Drawing.Size(120, 22)
			txtBottom2.Size = size
			Me.txtBottom.TabIndex = 136
			Me.txtBottom.Tag = "0R0000"
			Me.txtBottom.Text = "0"
			Me.txtBottom.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label4.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label7 As Global.System.Windows.Forms.Control = Me.Label4
			point = New Global.System.Drawing.Point(9, 484)
			label7.Location = point
			Me.Label4.Name = "Label4"
			Dim label8 As Global.System.Windows.Forms.Control = Me.Label4
			size = New Global.System.Drawing.Size(154, 21)
			label8.Size = size
			Me.Label4.TabIndex = 137
			Me.Label4.Tag = "CR0108"
			Me.Label4.Text = "bottom"
			Me.Label5.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label9 As Global.System.Windows.Forms.Control = Me.Label5
			point = New Global.System.Drawing.Point(294, 456)
			label9.Location = point
			Me.Label5.Name = "Label5"
			Dim label10 As Global.System.Windows.Forms.Control = Me.Label5
			size = New Global.System.Drawing.Size(42, 21)
			label10.Size = size
			Me.Label5.TabIndex = 140
			Me.Label5.Tag = ""
			Me.Label5.Text = "inch"
			Me.Label6.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label11 As Global.System.Windows.Forms.Control = Me.Label6
			point = New Global.System.Drawing.Point(294, 484)
			label11.Location = point
			Me.Label6.Name = "Label6"
			Dim label12 As Global.System.Windows.Forms.Control = Me.Label6
			size = New Global.System.Drawing.Size(42, 21)
			label12.Size = size
			Me.Label6.TabIndex = 141
			Me.Label6.Tag = ""
			Me.Label6.Text = "inch"
			Me.Label7.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label13 As Global.System.Windows.Forms.Control = Me.Label7
			point = New Global.System.Drawing.Point(523, 459)
			label13.Location = point
			Me.Label7.Name = "Label7"
			Dim label14 As Global.System.Windows.Forms.Control = Me.Label7
			size = New Global.System.Drawing.Size(42, 21)
			label14.Size = size
			Me.Label7.TabIndex = 142
			Me.Label7.Tag = ""
			Me.Label7.Text = "inch"
			Me.Label8.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label15 As Global.System.Windows.Forms.Control = Me.Label8
			point = New Global.System.Drawing.Point(523, 487)
			label15.Location = point
			Me.Label8.Name = "Label8"
			Dim label16 As Global.System.Windows.Forms.Control = Me.Label8
			size = New Global.System.Drawing.Size(42, 21)
			label16.Size = size
			Me.Label8.TabIndex = 143
			Me.Label8.Tag = ""
			Me.Label8.Text = "inch"
			Me.lblMargin.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblMargin.ForeColor = Global.System.Drawing.Color.Blue
			Dim lblMargin As Global.System.Windows.Forms.Control = Me.lblMargin
			point = New Global.System.Drawing.Point(116, 161)
			lblMargin.Location = point
			Me.lblMargin.Name = "lblMargin"
			Dim lblMargin2 As Global.System.Windows.Forms.Control = Me.lblMargin
			size = New Global.System.Drawing.Size(414, 129)
			lblMargin2.Size = size
			Me.lblMargin.TabIndex = 144
			Me.lblMargin.Tag = ""
			Me.lblMargin.Text = componentResourceManager.GetString("lblMargin.Text")
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(694, 526)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.lblMargin)
			Me.Controls.Add(Me.Label8)
			Me.Controls.Add(Me.Label7)
			Me.Controls.Add(Me.Label6)
			Me.Controls.Add(Me.Label5)
			Me.Controls.Add(Me.txtRight)
			Me.Controls.Add(Me.Label3)
			Me.Controls.Add(Me.txtBottom)
			Me.Controls.Add(Me.Label4)
			Me.Controls.Add(Me.txtLEFT)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.txtTOP)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.LblMAMAYTINHCALL)
			Me.Controls.Add(Me.txtTENMAYCALL)
			Me.Controls.Add(Me.TxtMAMAYCALL)
			Me.Controls.Add(Me.btnSECLECTMAYCALL)
			Me.Controls.Add(Me.txtPrintWidth)
			Me.Controls.Add(Me.lblPrintW)
			Me.Controls.Add(Me.chkLOPENDRAWER)
			Me.Controls.Add(Me.lblLOPENDRAWER)
			Me.Controls.Add(Me.chkLOPENDRAWERTAMTINH)
			Me.Controls.Add(Me.lblLOPENDRAWERTAMTINH)
			Me.Controls.Add(Me.cmbLoaiMayIn)
			Me.Controls.Add(Me.lblLoaiMayIn)
			Me.Controls.Add(Me.cmbCOMName)
			Me.Controls.Add(Me.cmbFlowControl)
			Me.Controls.Add(Me.cmbStopBit)
			Me.Controls.Add(Me.cmbParityBit)
			Me.Controls.Add(Me.cmbDataBit)
			Me.Controls.Add(Me.txtTENMAY)
			Me.Controls.Add(Me.cmbBaudrate)
			Me.Controls.Add(Me.txtMAMAY)
			Me.Controls.Add(Me.btnDMMAY)
			Me.Controls.Add(Me.txtRemark)
			Me.Controls.Add(Me.lblRemark)
			Me.Controls.Add(Me.txtColor)
			Me.Controls.Add(Me.lblFlowControl)
			Me.Controls.Add(Me.lblStopBit)
			Me.Controls.Add(Me.lblParityBit)
			Me.Controls.Add(Me.lblDataBit)
			Me.Controls.Add(Me.lblBaudrate)
			Me.Controls.Add(Me.lblCOMName)
			Me.Controls.Add(Me.txtPrintCount)
			Me.Controls.Add(Me.txtTimeOut)
			Me.Controls.Add(Me.txtFlowControl)
			Me.Controls.Add(Me.txtStopBit)
			Me.Controls.Add(Me.txtParityBit)
			Me.Controls.Add(Me.txtDataBit)
			Me.Controls.Add(Me.txtBaudrate)
			Me.Controls.Add(Me.txtCOMName)
			Me.Controls.Add(Me.lblComputer)
			Me.Controls.Add(Me.lblPrintCount)
			Me.Controls.Add(Me.lblTimeOut)
			Me.Controls.Add(Me.lblOBJNAME)
			Me.Controls.Add(Me.txtOBJNAME)
			Me.Controls.Add(Me.txtOBJID)
			Me.Controls.Add(Me.lblOBJID)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMMAYINHD2"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Chi tiết DM Máy in hóa đơn"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x04000CF4 RID: 3316
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
