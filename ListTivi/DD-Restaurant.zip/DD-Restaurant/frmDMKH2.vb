﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000054 RID: 84
	<DesignerGenerated()>
	Public Partial Class frmDMKH2
		Inherits Form

		' Token: 0x0600190A RID: 6410 RVA: 0x00137174 File Offset: 0x00135374
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMKH2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMKH2_Load
			frmDMKH2.__ENCList.Add(New WeakReference(Me))
			Me.mstrBranch = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x170008A5 RID: 2213
		' (get) Token: 0x0600190D RID: 6413 RVA: 0x00138620 File Offset: 0x00136820
		' (set) Token: 0x0600190E RID: 6414 RVA: 0x00005A75 File Offset: 0x00003C75
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x170008A6 RID: 2214
		' (get) Token: 0x0600190F RID: 6415 RVA: 0x00138638 File Offset: 0x00136838
		' (set) Token: 0x06001910 RID: 6416 RVA: 0x00138650 File Offset: 0x00136850
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170008A7 RID: 2215
		' (get) Token: 0x06001911 RID: 6417 RVA: 0x001386BC File Offset: 0x001368BC
		' (set) Token: 0x06001912 RID: 6418 RVA: 0x001386D4 File Offset: 0x001368D4
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170008A8 RID: 2216
		' (get) Token: 0x06001913 RID: 6419 RVA: 0x00138740 File Offset: 0x00136940
		' (set) Token: 0x06001914 RID: 6420 RVA: 0x00138758 File Offset: 0x00136958
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x170008A9 RID: 2217
		' (get) Token: 0x06001915 RID: 6421 RVA: 0x001387C4 File Offset: 0x001369C4
		' (set) Token: 0x06001916 RID: 6422 RVA: 0x001387DC File Offset: 0x001369DC
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170008AA RID: 2218
		' (get) Token: 0x06001917 RID: 6423 RVA: 0x00138848 File Offset: 0x00136A48
		' (set) Token: 0x06001918 RID: 6424 RVA: 0x00138860 File Offset: 0x00136A60
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170008AB RID: 2219
		' (get) Token: 0x06001919 RID: 6425 RVA: 0x001388CC File Offset: 0x00136ACC
		' (set) Token: 0x0600191A RID: 6426 RVA: 0x00005A7F File Offset: 0x00003C7F
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x170008AC RID: 2220
		' (get) Token: 0x0600191B RID: 6427 RVA: 0x001388E4 File Offset: 0x00136AE4
		' (set) Token: 0x0600191C RID: 6428 RVA: 0x001388FC File Offset: 0x00136AFC
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170008AD RID: 2221
		' (get) Token: 0x0600191D RID: 6429 RVA: 0x00138998 File Offset: 0x00136B98
		' (set) Token: 0x0600191E RID: 6430 RVA: 0x001389B0 File Offset: 0x00136BB0
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170008AE RID: 2222
		' (get) Token: 0x0600191F RID: 6431 RVA: 0x00138A4C File Offset: 0x00136C4C
		' (set) Token: 0x06001920 RID: 6432 RVA: 0x00005A89 File Offset: 0x00003C89
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x170008AF RID: 2223
		' (get) Token: 0x06001921 RID: 6433 RVA: 0x00138A64 File Offset: 0x00136C64
		' (set) Token: 0x06001922 RID: 6434 RVA: 0x00005A93 File Offset: 0x00003C93
		Friend Overridable Property lblEMAIL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblEMAIL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblEMAIL = value
			End Set
		End Property

		' Token: 0x170008B0 RID: 2224
		' (get) Token: 0x06001923 RID: 6435 RVA: 0x00138A7C File Offset: 0x00136C7C
		' (set) Token: 0x06001924 RID: 6436 RVA: 0x00138A94 File Offset: 0x00136C94
		Friend Overridable Property txtADDRESS As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtADDRESS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtADDRESS IsNot Nothing
				If flag Then
					RemoveHandler Me._txtADDRESS.KeyPress, AddressOf Me.txtADDRESS_KeyPress
					RemoveHandler Me._txtADDRESS.GotFocus, AddressOf Me.txtADDRESS_GotFocus
				End If
				Me._txtADDRESS = value
				flag = Me._txtADDRESS IsNot Nothing
				If flag Then
					AddHandler Me._txtADDRESS.KeyPress, AddressOf Me.txtADDRESS_KeyPress
					AddHandler Me._txtADDRESS.GotFocus, AddressOf Me.txtADDRESS_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170008B1 RID: 2225
		' (get) Token: 0x06001925 RID: 6437 RVA: 0x00138B30 File Offset: 0x00136D30
		' (set) Token: 0x06001926 RID: 6438 RVA: 0x00138B48 File Offset: 0x00136D48
		Friend Overridable Property txtTEL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTEL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTEL IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTEL.KeyPress, AddressOf Me.txtTEL_KeyPress
					RemoveHandler Me._txtTEL.GotFocus, AddressOf Me.txtTEL_GotFocus
				End If
				Me._txtTEL = value
				flag = Me._txtTEL IsNot Nothing
				If flag Then
					AddHandler Me._txtTEL.KeyPress, AddressOf Me.txtTEL_KeyPress
					AddHandler Me._txtTEL.GotFocus, AddressOf Me.txtTEL_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170008B2 RID: 2226
		' (get) Token: 0x06001927 RID: 6439 RVA: 0x00138BE4 File Offset: 0x00136DE4
		' (set) Token: 0x06001928 RID: 6440 RVA: 0x00138BFC File Offset: 0x00136DFC
		Friend Overridable Property txtCONTACT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCONTACT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtCONTACT IsNot Nothing
				If flag Then
					RemoveHandler Me._txtCONTACT.KeyPress, AddressOf Me.txtCONTACT_KeyPress
					RemoveHandler Me._txtCONTACT.GotFocus, AddressOf Me.txtCONTACT_GotFocus
				End If
				Me._txtCONTACT = value
				flag = Me._txtCONTACT IsNot Nothing
				If flag Then
					AddHandler Me._txtCONTACT.KeyPress, AddressOf Me.txtCONTACT_KeyPress
					AddHandler Me._txtCONTACT.GotFocus, AddressOf Me.txtCONTACT_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170008B3 RID: 2227
		' (get) Token: 0x06001929 RID: 6441 RVA: 0x00138C98 File Offset: 0x00136E98
		' (set) Token: 0x0600192A RID: 6442 RVA: 0x00138CB0 File Offset: 0x00136EB0
		Friend Overridable Property txtFAX As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtFAX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtFAX IsNot Nothing
				If flag Then
					RemoveHandler Me._txtFAX.KeyPress, AddressOf Me.txtFAX_KeyPress
					RemoveHandler Me._txtFAX.GotFocus, AddressOf Me.txtFAX_GotFocus
				End If
				Me._txtFAX = value
				flag = Me._txtFAX IsNot Nothing
				If flag Then
					AddHandler Me._txtFAX.KeyPress, AddressOf Me.txtFAX_KeyPress
					AddHandler Me._txtFAX.GotFocus, AddressOf Me.txtFAX_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170008B4 RID: 2228
		' (get) Token: 0x0600192B RID: 6443 RVA: 0x00138D4C File Offset: 0x00136F4C
		' (set) Token: 0x0600192C RID: 6444 RVA: 0x00138D64 File Offset: 0x00136F64
		Friend Overridable Property txtEMAIL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtEMAIL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtEMAIL IsNot Nothing
				If flag Then
					RemoveHandler Me._txtEMAIL.KeyPress, AddressOf Me.txtEMAIL_KeyPress
					RemoveHandler Me._txtEMAIL.GotFocus, AddressOf Me.txtEMAIL_GotFocus
				End If
				Me._txtEMAIL = value
				flag = Me._txtEMAIL IsNot Nothing
				If flag Then
					AddHandler Me._txtEMAIL.KeyPress, AddressOf Me.txtEMAIL_KeyPress
					AddHandler Me._txtEMAIL.GotFocus, AddressOf Me.txtEMAIL_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170008B5 RID: 2229
		' (get) Token: 0x0600192D RID: 6445 RVA: 0x00138E00 File Offset: 0x00137000
		' (set) Token: 0x0600192E RID: 6446 RVA: 0x00005A9D File Offset: 0x00003C9D
		Friend Overridable Property lblADDRESS As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblADDRESS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblADDRESS = value
			End Set
		End Property

		' Token: 0x170008B6 RID: 2230
		' (get) Token: 0x0600192F RID: 6447 RVA: 0x00138E18 File Offset: 0x00137018
		' (set) Token: 0x06001930 RID: 6448 RVA: 0x00005AA7 File Offset: 0x00003CA7
		Friend Overridable Property lblTEL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTEL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTEL = value
			End Set
		End Property

		' Token: 0x170008B7 RID: 2231
		' (get) Token: 0x06001931 RID: 6449 RVA: 0x00138E30 File Offset: 0x00137030
		' (set) Token: 0x06001932 RID: 6450 RVA: 0x00005AB1 File Offset: 0x00003CB1
		Friend Overridable Property lblCONTACT As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCONTACT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCONTACT = value
			End Set
		End Property

		' Token: 0x170008B8 RID: 2232
		' (get) Token: 0x06001933 RID: 6451 RVA: 0x00138E48 File Offset: 0x00137048
		' (set) Token: 0x06001934 RID: 6452 RVA: 0x00005ABB File Offset: 0x00003CBB
		Friend Overridable Property lblFAX As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFAX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFAX = value
			End Set
		End Property

		' Token: 0x170008B9 RID: 2233
		' (get) Token: 0x06001935 RID: 6453 RVA: 0x00138E60 File Offset: 0x00137060
		' (set) Token: 0x06001936 RID: 6454 RVA: 0x00138E78 File Offset: 0x00137078
		Friend Overridable Property txtGHICHU As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtGHICHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtGHICHU IsNot Nothing
				If flag Then
					RemoveHandler Me._txtGHICHU.KeyPress, AddressOf Me.txtGHICHU_KeyPress
				End If
				Me._txtGHICHU = value
				flag = Me._txtGHICHU IsNot Nothing
				If flag Then
					AddHandler Me._txtGHICHU.KeyPress, AddressOf Me.txtGHICHU_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170008BA RID: 2234
		' (get) Token: 0x06001937 RID: 6455 RVA: 0x00138EE4 File Offset: 0x001370E4
		' (set) Token: 0x06001938 RID: 6456 RVA: 0x00005AC5 File Offset: 0x00003CC5
		Friend Overridable Property lblGHICHU As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblGHICHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblGHICHU = value
			End Set
		End Property

		' Token: 0x170008BB RID: 2235
		' (get) Token: 0x06001939 RID: 6457 RVA: 0x00138EFC File Offset: 0x001370FC
		' (set) Token: 0x0600193A RID: 6458 RVA: 0x00005ACF File Offset: 0x00003CCF
		Friend Overridable Property txt As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txt
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txt = value
			End Set
		End Property

		' Token: 0x170008BC RID: 2236
		' (get) Token: 0x0600193B RID: 6459 RVA: 0x00138F14 File Offset: 0x00137114
		' (set) Token: 0x0600193C RID: 6460 RVA: 0x00005AD9 File Offset: 0x00003CD9
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170008BD RID: 2237
		' (get) Token: 0x0600193D RID: 6461 RVA: 0x00138F2C File Offset: 0x0013712C
		' (set) Token: 0x0600193E RID: 6462 RVA: 0x00005AE3 File Offset: 0x00003CE3
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x170008BE RID: 2238
		' (get) Token: 0x0600193F RID: 6463 RVA: 0x00138F44 File Offset: 0x00137144
		' (set) Token: 0x06001940 RID: 6464 RVA: 0x00005AED File Offset: 0x00003CED
		Friend Overridable Property txtSUBOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtSUBOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtSUBOBJNAME = value
			End Set
		End Property

		' Token: 0x170008BF RID: 2239
		' (get) Token: 0x06001941 RID: 6465 RVA: 0x00138F5C File Offset: 0x0013715C
		' (set) Token: 0x06001942 RID: 6466 RVA: 0x00138F74 File Offset: 0x00137174
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x170008C0 RID: 2240
		' (get) Token: 0x06001943 RID: 6467 RVA: 0x00138FE0 File Offset: 0x001371E0
		' (set) Token: 0x06001944 RID: 6468 RVA: 0x00005AF7 File Offset: 0x00003CF7
		Public Property pStrBranch As String
			Get
				Return Me.mstrBranch
			End Get
			Set(value As String)
				Me.mstrBranch = value
			End Set
		End Property

		' Token: 0x170008C1 RID: 2241
		' (get) Token: 0x06001945 RID: 6469 RVA: 0x00138FF8 File Offset: 0x001371F8
		' (set) Token: 0x06001946 RID: 6470 RVA: 0x00005B02 File Offset: 0x00003D02
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x170008C2 RID: 2242
		' (get) Token: 0x06001947 RID: 6471 RVA: 0x00139010 File Offset: 0x00137210
		' (set) Token: 0x06001948 RID: 6472 RVA: 0x00005B0D File Offset: 0x00003D0D
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x170008C3 RID: 2243
		' (get) Token: 0x06001949 RID: 6473 RVA: 0x00139028 File Offset: 0x00137228
		' (set) Token: 0x0600194A RID: 6474 RVA: 0x00005B18 File Offset: 0x00003D18
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x0600194B RID: 6475 RVA: 0x00139040 File Offset: 0x00137240
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600194C RID: 6476 RVA: 0x001390EC File Offset: 0x001372EC
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600194D RID: 6477 RVA: 0x00139194 File Offset: 0x00137394
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600194E RID: 6478 RVA: 0x00139228 File Offset: 0x00137428
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtADDRESS.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600194F RID: 6479 RVA: 0x001392CC File Offset: 0x001374CC
		Private Sub cmbBRANCH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtADDRESS.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbBRANCH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001950 RID: 6480 RVA: 0x00139370 File Offset: 0x00137570
		Private Sub txtADDRESS_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtADDRESS.[ReadOnly]
				If [readOnly] Then
					Me.txtTEL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtADDRESS_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001951 RID: 6481 RVA: 0x0013941C File Offset: 0x0013761C
		Private Sub txtADDRESS_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtTEL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtADDRESS_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001952 RID: 6482 RVA: 0x001394C0 File Offset: 0x001376C0
		Private Sub txtTEL_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTEL.[ReadOnly]
				If [readOnly] Then
					Me.txtFAX.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTEL_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001953 RID: 6483 RVA: 0x0013956C File Offset: 0x0013776C
		Private Sub txtTEL_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtFAX.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTEL_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001954 RID: 6484 RVA: 0x00139610 File Offset: 0x00137810
		Private Sub txtFAX_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtFAX.[ReadOnly]
				If [readOnly] Then
					Me.txtCONTACT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtFAX_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001955 RID: 6485 RVA: 0x001396BC File Offset: 0x001378BC
		Private Sub txtFAX_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtCONTACT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtFAX_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001956 RID: 6486 RVA: 0x00139760 File Offset: 0x00137960
		Private Sub txtCONTACT_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtCONTACT.[ReadOnly]
				If [readOnly] Then
					Me.txtEMAIL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCONTACT_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001957 RID: 6487 RVA: 0x0013980C File Offset: 0x00137A0C
		Private Sub txtCONTACT_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtEMAIL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCONTACT_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001958 RID: 6488 RVA: 0x001398B0 File Offset: 0x00137AB0
		Private Sub txtEMAIL_GotFocus(sender As Object, e As EventArgs)
			Try
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtEMAIL_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001959 RID: 6489 RVA: 0x00139944 File Offset: 0x00137B44
		Private Sub txtEMAIL_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtGHICHU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtEMAIL_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600195A RID: 6490 RVA: 0x001399E8 File Offset: 0x00137BE8
		Private Sub txtMADV_GotFocus(sender As Object, e As EventArgs)
			Try
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADV_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600195B RID: 6491 RVA: 0x00139A6C File Offset: 0x00137C6C
		Private Sub txtMADV_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim flag2 As Boolean = Me.mbytFormStatus = 5
					If flag2 Then
						Me.btnFilter.Focus()
					Else
						flag2 = Me.mbytFormStatus = 6
						If flag2 Then
							Me.btnFind.Focus()
						Else
							Me.btnSave.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADV_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600195C RID: 6492 RVA: 0x00139B48 File Offset: 0x00137D48
		Private Sub txtMADV_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600195D RID: 6493 RVA: 0x00139BE4 File Offset: 0x00137DE4
		Private Sub txtTENDV_GotFocus(sender As Object, e As EventArgs)
			Try
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENDV_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600195E RID: 6494 RVA: 0x00139C68 File Offset: 0x00137E68
		Private Sub frmDMKH2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMKH2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600195F RID: 6495 RVA: 0x00139D14 File Offset: 0x00137F14
		Private Sub frmDMKH2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Combo()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMKH2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001960 RID: 6496 RVA: 0x00139DD4 File Offset: 0x00137FD4
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
						If flag Then
							Me.mbytSuccess = Me.fAddNew()
						Else
							flag = Me.mbytFormStatus = 3
							If flag Then
								Me.mbytSuccess = Me.fModify()
							End If
						End If
						flag = Me.mbytSuccess = 1
						If flag Then
							mdlVariable.gstrStockName = Strings.Trim(mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMKH", "OBJID", mdlVariable.gStrStockCode, "OBJNAME"))
							Me.Close()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001961 RID: 6497 RVA: 0x00139F88 File Offset: 0x00138188
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001962 RID: 6498 RVA: 0x0013A02C File Offset: 0x0013822C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtADDRESS.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ADDRESS like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtTEL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TEL like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtCONTACT.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " CONTACT like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtFAX.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FAX like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtEMAIL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " EMAIL like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtGHICHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001963 RID: 6499 RVA: 0x0013A470 File Offset: 0x00138670
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtADDRESS.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ADDRESS like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtTEL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TEL like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtCONTACT.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " CONTACT like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtFAX.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FAX like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtEMAIL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " EMAIL like '"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001964 RID: 6500 RVA: 0x0013A844 File Offset: 0x00138A44
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001965 RID: 6501 RVA: 0x0013A8D8 File Offset: 0x00138AD8
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtSUBOBJNAME.[ReadOnly] = True
						Me.txtADDRESS.[ReadOnly] = True
						Me.txtTEL.[ReadOnly] = True
						Me.txtCONTACT.[ReadOnly] = True
						Me.txtFAX.[ReadOnly] = True
						Me.txtEMAIL.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txt.BackColor
						Me.txtOBJNAME.BackColor = Me.txt.BackColor
						Me.txtSUBOBJNAME.BackColor = Me.txt.BackColor
						Me.txtADDRESS.BackColor = Me.txt.BackColor
						Me.txtTEL.BackColor = Me.txt.BackColor
						Me.txtCONTACT.BackColor = Me.txt.BackColor
						Me.txtFAX.BackColor = Me.txt.BackColor
						Me.txtEMAIL.BackColor = Me.txt.BackColor
						Me.txtGHICHU.BackColor = Me.txt.BackColor
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001966 RID: 6502 RVA: 0x0013AAFC File Offset: 0x00138CFC
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001967 RID: 6503 RVA: 0x0013AC8C File Offset: 0x00138E8C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 2
				Me.txtOBJNAME.MaxLength = 60
				Me.txtADDRESS.MaxLength = 100
				Me.txtTEL.MaxLength = 100
				Me.txtFAX.MaxLength = 100
				Me.txtEMAIL.MaxLength = 200
				Me.txtCONTACT.MaxLength = 100
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001968 RID: 6504 RVA: 0x0013ADA8 File Offset: 0x00138FA8
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001969 RID: 6505 RVA: 0x0013AF8C File Offset: 0x0013918C
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMDV.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600196A RID: 6506 RVA: 0x0013B038 File Offset: 0x00139238
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(10) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pnvcSUBOBJNAME"
				array(9).Value = Strings.Trim(Me.txtSUBOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcDC"
				array(2).Value = Strings.Trim(Me.txtADDRESS.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcTEL"
				array(3).Value = Strings.Trim(Me.txtTEL.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvcFAX"
				array(4).Value = Strings.Trim(Me.txtFAX.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcEmail"
				array(5).Value = Strings.Trim(Me.txtEMAIL.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcLH"
				array(6).Value = Strings.Trim(Me.txtCONTACT.Text)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnvcREMARK"
				array(7).Value = Strings.Trim(Me.txtGHICHU.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@int_Result"
				array(8).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKH_INSERT_DMKH", flag)
				Dim num As Integer = Conversions.ToInteger(array(8).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600196B RID: 6507 RVA: 0x0013B3A8 File Offset: 0x001395A8
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(10) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pnvcSUBOBJNAME"
				array(9).Value = Strings.Trim(Me.txtSUBOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcDC"
				array(2).Value = Strings.Trim(Me.txtADDRESS.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcTEL"
				array(3).Value = Strings.Trim(Me.txtTEL.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvcFAX"
				array(4).Value = Strings.Trim(Me.txtFAX.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcEmail"
				array(5).Value = Strings.Trim(Me.txtEMAIL.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcLH"
				array(6).Value = Strings.Trim(Me.txtCONTACT.Text)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnvcREMARK"
				array(7).Value = Strings.Trim(Me.txtGHICHU.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@int_Result"
				array(8).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKH_UPDATE_DMKH", flag)
				Dim num As Integer = Conversions.ToInteger(array(8).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600196C RID: 6508 RVA: 0x0013B708 File Offset: 0x00139908
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKH_DEL_DMKH", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600196D RID: 6509 RVA: 0x0013B8CC File Offset: 0x00139ACC
		Private Function fGetData_4Combo() As Byte
			Dim b As Byte
			Try
				b = 0
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600196E RID: 6510 RVA: 0x0013B960 File Offset: 0x00139B60
		Private Function fGetData_DMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMDV")
				Dim flag As Boolean = Me.mclsTbDMDV IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600196F RID: 6511 RVA: 0x0013BA1C File Offset: 0x00139C1C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001970 RID: 6512 RVA: 0x0013BAB4 File Offset: 0x00139CB4
		Private Sub txtGHICHU_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtGHICHU_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001971 RID: 6513 RVA: 0x0013BB58 File Offset: 0x00139D58
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x06001972 RID: 6514 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x04000A60 RID: 2656
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000A62 RID: 2658
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000A63 RID: 2659
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000A64 RID: 2660
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000A65 RID: 2661
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000A66 RID: 2662
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000A67 RID: 2663
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000A68 RID: 2664
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000A69 RID: 2665
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000A6A RID: 2666
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000A6B RID: 2667
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000A6C RID: 2668
		<AccessedThroughProperty("lblEMAIL")>
		Private _lblEMAIL As Label

		' Token: 0x04000A6D RID: 2669
		<AccessedThroughProperty("txtADDRESS")>
		Private _txtADDRESS As TextBox

		' Token: 0x04000A6E RID: 2670
		<AccessedThroughProperty("txtTEL")>
		Private _txtTEL As TextBox

		' Token: 0x04000A6F RID: 2671
		<AccessedThroughProperty("txtCONTACT")>
		Private _txtCONTACT As TextBox

		' Token: 0x04000A70 RID: 2672
		<AccessedThroughProperty("txtFAX")>
		Private _txtFAX As TextBox

		' Token: 0x04000A71 RID: 2673
		<AccessedThroughProperty("txtEMAIL")>
		Private _txtEMAIL As TextBox

		' Token: 0x04000A72 RID: 2674
		<AccessedThroughProperty("lblADDRESS")>
		Private _lblADDRESS As Label

		' Token: 0x04000A73 RID: 2675
		<AccessedThroughProperty("lblTEL")>
		Private _lblTEL As Label

		' Token: 0x04000A74 RID: 2676
		<AccessedThroughProperty("lblCONTACT")>
		Private _lblCONTACT As Label

		' Token: 0x04000A75 RID: 2677
		<AccessedThroughProperty("lblFAX")>
		Private _lblFAX As Label

		' Token: 0x04000A76 RID: 2678
		<AccessedThroughProperty("txtGHICHU")>
		Private _txtGHICHU As TextBox

		' Token: 0x04000A77 RID: 2679
		<AccessedThroughProperty("lblGHICHU")>
		Private _lblGHICHU As Label

		' Token: 0x04000A78 RID: 2680
		<AccessedThroughProperty("txt")>
		Private _txt As TextBox

		' Token: 0x04000A79 RID: 2681
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000A7A RID: 2682
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000A7B RID: 2683
		<AccessedThroughProperty("txtSUBOBJNAME")>
		Private _txtSUBOBJNAME As TextBox

		' Token: 0x04000A7C RID: 2684
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000A7D RID: 2685
		Private mArrStrFrmMess As String()

		' Token: 0x04000A7E RID: 2686
		Private mbytFormStatus As Byte

		' Token: 0x04000A7F RID: 2687
		Private mbytSuccess As Byte

		' Token: 0x04000A80 RID: 2688
		Private mStrFilter As String

		' Token: 0x04000A81 RID: 2689
		Private mclsTbBranch As clsConnect

		' Token: 0x04000A82 RID: 2690
		Private mstrBranch As String

		' Token: 0x04000A83 RID: 2691
		Private mclsTbDMDV As clsConnect
	End Class
End Namespace
