﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000021 RID: 33
	<DesignerGenerated()>
	Public Partial Class frmCC
		Inherits Form

		' Token: 0x06000608 RID: 1544 RVA: 0x00048A60 File Offset: 0x00046C60
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmCC_Activated
			AddHandler MyBase.Load, AddressOf Me.frmCC_Load
			frmCC.__ENCList.Add(New WeakReference(Me))
			Me.mbytSelect_PXK = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000257 RID: 599
		' (get) Token: 0x0600060B RID: 1547 RVA: 0x00049568 File Offset: 0x00047768
		' (set) Token: 0x0600060C RID: 1548 RVA: 0x00003095 File Offset: 0x00001295
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000258 RID: 600
		' (get) Token: 0x0600060D RID: 1549 RVA: 0x00049580 File Offset: 0x00047780
		' (set) Token: 0x0600060E RID: 1550 RVA: 0x00049598 File Offset: 0x00047798
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000259 RID: 601
		' (get) Token: 0x0600060F RID: 1551 RVA: 0x00049604 File Offset: 0x00047804
		' (set) Token: 0x06000610 RID: 1552 RVA: 0x0004961C File Offset: 0x0004781C
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x1700025A RID: 602
		' (get) Token: 0x06000611 RID: 1553 RVA: 0x00049688 File Offset: 0x00047888
		' (set) Token: 0x06000612 RID: 1554 RVA: 0x0000309F File Offset: 0x0000129F
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x1700025B RID: 603
		' (get) Token: 0x06000613 RID: 1555 RVA: 0x000496A0 File Offset: 0x000478A0
		' (set) Token: 0x06000614 RID: 1556 RVA: 0x000496B8 File Offset: 0x000478B8
		Friend Overridable Property txtMANV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMANV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMANV IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMANV.TextChanged, AddressOf Me.txtMANV_TextChanged
					RemoveHandler Me._txtMANV.KeyPress, AddressOf Me.txtMANV_KeyPress
					RemoveHandler Me._txtMANV.GotFocus, AddressOf Me.txtMANV_GotFocus
				End If
				Me._txtMANV = value
				flag = Me._txtMANV IsNot Nothing
				If flag Then
					AddHandler Me._txtMANV.TextChanged, AddressOf Me.txtMANV_TextChanged
					AddHandler Me._txtMANV.KeyPress, AddressOf Me.txtMANV_KeyPress
					AddHandler Me._txtMANV.GotFocus, AddressOf Me.txtMANV_GotFocus
				End If
			End Set
		End Property

		' Token: 0x1700025C RID: 604
		' (get) Token: 0x06000615 RID: 1557 RVA: 0x00049788 File Offset: 0x00047988
		' (set) Token: 0x06000616 RID: 1558 RVA: 0x000497A0 File Offset: 0x000479A0
		Friend Overridable Property txtTENNV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENNV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENNV IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENNV.GotFocus, AddressOf Me.txtTENNV_GotFocus
				End If
				Me._txtTENNV = value
				flag = Me._txtTENNV IsNot Nothing
				If flag Then
					AddHandler Me._txtTENNV.GotFocus, AddressOf Me.txtTENNV_GotFocus
				End If
			End Set
		End Property

		' Token: 0x1700025D RID: 605
		' (get) Token: 0x06000617 RID: 1559 RVA: 0x0004980C File Offset: 0x00047A0C
		' (set) Token: 0x06000618 RID: 1560 RVA: 0x000030A9 File Offset: 0x000012A9
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x1700025E RID: 606
		' (get) Token: 0x06000619 RID: 1561 RVA: 0x00049824 File Offset: 0x00047A24
		' (set) Token: 0x0600061A RID: 1562 RVA: 0x0004983C File Offset: 0x00047A3C
		Friend Overridable Property txtDate As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtDate IsNot Nothing
				If flag Then
					RemoveHandler Me._txtDate.GotFocus, AddressOf Me.txtDate_GotFocus
				End If
				Me._txtDate = value
				flag = Me._txtDate IsNot Nothing
				If flag Then
					AddHandler Me._txtDate.GotFocus, AddressOf Me.txtDate_GotFocus
				End If
			End Set
		End Property

		' Token: 0x1700025F RID: 607
		' (get) Token: 0x0600061B RID: 1563 RVA: 0x000498A8 File Offset: 0x00047AA8
		' (set) Token: 0x0600061C RID: 1564 RVA: 0x000498C0 File Offset: 0x00047AC0
		Friend Overridable Property txtDisplay As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtDisplay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtDisplay IsNot Nothing
				If flag Then
					RemoveHandler Me._txtDisplay.GotFocus, AddressOf Me.txtDisplay_GotFocus
				End If
				Me._txtDisplay = value
				flag = Me._txtDisplay IsNot Nothing
				If flag Then
					AddHandler Me._txtDisplay.GotFocus, AddressOf Me.txtDisplay_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000260 RID: 608
		' (get) Token: 0x0600061D RID: 1565 RVA: 0x0004992C File Offset: 0x00047B2C
		' (set) Token: 0x0600061E RID: 1566 RVA: 0x00049944 File Offset: 0x00047B44
		Friend Overridable Property tmrTime As Timer
			<DebuggerNonUserCode()>
			Get
				Return Me._tmrTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim flag As Boolean = Me._tmrTime IsNot Nothing
				If flag Then
					RemoveHandler Me._tmrTime.Tick, AddressOf Me.tmrTime_Tick
				End If
				Me._tmrTime = value
				flag = Me._tmrTime IsNot Nothing
				If flag Then
					AddHandler Me._tmrTime.Tick, AddressOf Me.tmrTime_Tick
				End If
			End Set
		End Property

		' Token: 0x17000261 RID: 609
		' (get) Token: 0x0600061F RID: 1567 RVA: 0x000499B0 File Offset: 0x00047BB0
		' (set) Token: 0x06000620 RID: 1568 RVA: 0x000499C8 File Offset: 0x00047BC8
		Friend Overridable Property tmrCount As Timer
			<DebuggerNonUserCode()>
			Get
				Return Me._tmrCount
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim flag As Boolean = Me._tmrCount IsNot Nothing
				If flag Then
					RemoveHandler Me._tmrCount.Tick, AddressOf Me.tmrCount_Tick
				End If
				Me._tmrCount = value
				flag = Me._tmrCount IsNot Nothing
				If flag Then
					AddHandler Me._tmrCount.Tick, AddressOf Me.tmrCount_Tick
				End If
			End Set
		End Property

		' Token: 0x17000262 RID: 610
		' (get) Token: 0x06000621 RID: 1569 RVA: 0x00049A34 File Offset: 0x00047C34
		' (set) Token: 0x06000622 RID: 1570 RVA: 0x00049A4C File Offset: 0x00047C4C
		Friend Overridable Property txtPass As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPass
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPass IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPass.GotFocus, AddressOf Me.txtMANV_GotFocus
					RemoveHandler Me._txtPass.KeyPress, AddressOf Me.txtPass_KeyPress
				End If
				Me._txtPass = value
				flag = Me._txtPass IsNot Nothing
				If flag Then
					AddHandler Me._txtPass.GotFocus, AddressOf Me.txtMANV_GotFocus
					AddHandler Me._txtPass.KeyPress, AddressOf Me.txtPass_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000263 RID: 611
		' (get) Token: 0x06000623 RID: 1571 RVA: 0x00049AE8 File Offset: 0x00047CE8
		' (set) Token: 0x06000624 RID: 1572 RVA: 0x000030B3 File Offset: 0x000012B3
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000264 RID: 612
		' (get) Token: 0x06000625 RID: 1573 RVA: 0x00049B00 File Offset: 0x00047D00
		' (set) Token: 0x06000626 RID: 1574 RVA: 0x00049B18 File Offset: 0x00047D18
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x06000627 RID: 1575 RVA: 0x00049B84 File Offset: 0x00047D84
		Private Sub txtMANV_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMANV.[ReadOnly]
				If [readOnly] Then
					Me.txtTENNV.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMANV_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000628 RID: 1576 RVA: 0x00049C30 File Offset: 0x00047E30
		Private Sub txtMANV_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtPass.Visible
					If visible Then
						Me.txtPass.SelectAll()
						Me.txtPass.Focus()
					Else
						Me.btnSave_Click(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMANV_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000629 RID: 1577 RVA: 0x00049D00 File Offset: 0x00047F00
		Private Sub txtTENNV_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENNV.[ReadOnly]
				If [readOnly] Then
					Me.txtDate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENNV_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600062A RID: 1578 RVA: 0x00049DAC File Offset: 0x00047FAC
		Private Sub txtDate_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtDate.[ReadOnly]
				If [readOnly] Then
					Me.txtDisplay.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtDate_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600062B RID: 1579 RVA: 0x00049E58 File Offset: 0x00048058
		Private Sub txtDisplay_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtDisplay.[ReadOnly]
				If [readOnly] Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtDisplay_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600062C RID: 1580 RVA: 0x000030BD File Offset: 0x000012BD
		Private Sub tmrCount_Tick(sender As Object, e As EventArgs)
			Me.txtDisplay.Text = ""
			Me.tmrCount.Enabled = False
		End Sub

		' Token: 0x0600062D RID: 1581 RVA: 0x00049F04 File Offset: 0x00048104
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtMANV.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600062E RID: 1582 RVA: 0x00049FAC File Offset: 0x000481AC
		Private Sub tmrTime_Tick(sender As Object, e As EventArgs)
			Try
				Me.txtDate.Text = DateAndTime.Now.ToString("dd/MM/yyyy  -  HH:mm:ss")
			Catch ex As Exception
			Finally
			End Try
		End Sub

		' Token: 0x0600062F RID: 1583 RVA: 0x0004A014 File Offset: 0x00048214
		Private Sub txtMANV_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMNV Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMNV.Columns("OBJID")
					Me.mclsTbDMNV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMNV.Rows.Find(Strings.Trim(Me.txtMANV.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENNV.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENNV.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMANV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000630 RID: 1584 RVA: 0x0004A168 File Offset: 0x00048368
		Private Sub frmCC_Activated(sender As Object, e As EventArgs)
			Try
				Me.tmrTime.Enabled = True
				Me.tmrTime.Interval = 1000
				Dim b As Byte = Me.fEnableButton()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmCC_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000631 RID: 1585 RVA: 0x0004A220 File Offset: 0x00048420
		Private Sub frmCC_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMNV()
				End If
				Me.Label2.Visible = mdlVariable.gblnLShowPassCC
				Me.txtPass.Visible = mdlVariable.gblnLShowPassCC
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmCC_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000632 RID: 1586 RVA: 0x0004A300 File Offset: 0x00048500
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				mdlFile.gfWriteLogFile("Nhấn nút thoát form chấm công.")
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000633 RID: 1587 RVA: 0x0004A398 File Offset: 0x00048598
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtMANV.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(10), MsgBoxStyle.Critical, Nothing)
					Me.txtMANV.Focus()
				Else
					flag = (Operators.CompareString(Strings.Trim(Me.txtMANV.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENNV.Text), "", False) = 0)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(11), MsgBoxStyle.Critical, Nothing)
						Me.txtMANV.Focus()
					Else
						flag = Me.txtPass.Visible AndAlso Operators.CompareString(Strings.Trim(Me.txtPass.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(16), MsgBoxStyle.Critical, Nothing)
							Me.txtPass.Focus()
						Else
							flag = Me.txtPass.Visible
							If flag Then
								Dim array As DataColumn() = New DataColumn(0) {}
								flag = Me.mclsTbDMNV Is Nothing
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(18), MsgBoxStyle.Critical, Nothing)
									Return
								End If
								array(0) = Me.mclsTbDMNV.Columns("OBJID")
								Me.mclsTbDMNV.PrimaryKey = array
								Dim dataRow As DataRow = Me.mclsTbDMNV.Rows.Find(Strings.Trim(Me.txtMANV.Text))
								flag = dataRow Is Nothing OrElse Not dataRow("UPASSWORD").ToString().Trim().Equals(Me.txtPass.Text.Trim())
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(17), MsgBoxStyle.Critical, Nothing)
									Me.txtPass.Focus()
									Return
								End If
							End If
							Dim b As Byte = mdlDatabase.gfCreateDB_BaseNow()
							flag = b <> 0
							If flag Then
								b = Me.fAddNew()
								Me.tmrCount.Enabled = True
							End If
							flag = b <> 0
							If flag Then
								mdlFile.gfWriteLogFile("Lưu chấm công: " + Me.txtDisplay.Text.Trim())
								Me.txtMANV.Text = ""
								Me.txtPass.Text = ""
							End If
							Me.txtMANV.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000634 RID: 1588 RVA: 0x0004A6CC File Offset: 0x000488CC
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.txtMANV.Focus()
				Me.txtTENNV.[ReadOnly] = True
				Me.txtDate.[ReadOnly] = True
				Me.txtDisplay.[ReadOnly] = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000635 RID: 1589 RVA: 0x0004A794 File Offset: 0x00048994
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtMANV.MaxLength = 20
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000636 RID: 1590 RVA: 0x0004A84C File Offset: 0x00048A4C
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJNAME.Tag = "CB0008"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000637 RID: 1591 RVA: 0x0004A9A4 File Offset: 0x00048BA4
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000638 RID: 1592 RVA: 0x0004AA44 File Offset: 0x00048C44
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(6) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMANV"
				array(0).Value = Strings.Trim(Me.txtMANV.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchSTRINGTIMEIN"
				array(1).Value = Me.mArrStrFrmMess(12)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pvchSTRINGTIMEOUT"
				array(2).Value = Me.mArrStrFrmMess(13)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pvchSTRING"
				array(3).Size = 100
				array(3).Direction = ParameterDirection.Output
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnchMAKH"
				array(4).Value = mdlVariable.gStrStockCode
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@int_Result"
				array(5).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCC_INSERT", flag)
				Dim num As Integer = Conversions.ToInteger(array(5).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
					Me.txtDisplay.Text = Conversions.ToString(Operators.ConcatenateObject(Me.txtTENNV.Text + " - ", array(3).Value))
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(11), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(14), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000639 RID: 1593 RVA: 0x0004ACC8 File Offset: 0x00048EC8
		Private Function fGetData_DMNV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMNV = New clsConnect(mdlVariable.gStrConISDANHMUC, "UUSER")
				Dim flag As Boolean = Me.mclsTbDMNV IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMNV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600063A RID: 1594 RVA: 0x0004AD84 File Offset: 0x00048F84
		Private Sub txtPass_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.btnSave_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtPass_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600063B RID: 1595 RVA: 0x0004AE2C File Offset: 0x0004902C
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				mdlFile.gfWriteLogFile("Mở bàn phím trong form chấm công.")
				Me.txtMANV.Focus()
				Me.txtMANV.SelectAll()
			End If
		End Sub

		' Token: 0x0600063C RID: 1596 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x040002A4 RID: 676
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040002A6 RID: 678
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x040002A7 RID: 679
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040002A8 RID: 680
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x040002A9 RID: 681
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x040002AA RID: 682
		<AccessedThroughProperty("txtMANV")>
		Private _txtMANV As TextBox

		' Token: 0x040002AB RID: 683
		<AccessedThroughProperty("txtTENNV")>
		Private _txtTENNV As TextBox

		' Token: 0x040002AC RID: 684
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x040002AD RID: 685
		<AccessedThroughProperty("txtDate")>
		Private _txtDate As TextBox

		' Token: 0x040002AE RID: 686
		<AccessedThroughProperty("txtDisplay")>
		Private _txtDisplay As TextBox

		' Token: 0x040002AF RID: 687
		<AccessedThroughProperty("tmrTime")>
		Private _tmrTime As Timer

		' Token: 0x040002B0 RID: 688
		<AccessedThroughProperty("tmrCount")>
		Private _tmrCount As Timer

		' Token: 0x040002B1 RID: 689
		<AccessedThroughProperty("txtPass")>
		Private _txtPass As TextBox

		' Token: 0x040002B2 RID: 690
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x040002B3 RID: 691
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x040002B4 RID: 692
		Private mArrStrFrmMess As String()

		' Token: 0x040002B5 RID: 693
		Private mbytFormStatus As Byte

		' Token: 0x040002B6 RID: 694
		Private mbytSuccess As Byte

		' Token: 0x040002B7 RID: 695
		Private mclsTbDMNV As clsConnect

		' Token: 0x040002B8 RID: 696
		Private mbytSelect_PXK As Byte
	End Class
End Namespace
