﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002A0 RID: 672
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60616k75Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006812 RID: 26642 RVA: 0x00012DFF File Offset: 0x00010FFF
		Public Sub New()
			CachedrptRepBC60616k75Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170028A1 RID: 10401
		' (get) Token: 0x06006813 RID: 26643 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006814 RID: 26644 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170028A2 RID: 10402
		' (get) Token: 0x06006815 RID: 26645 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006816 RID: 26646 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170028A3 RID: 10403
		' (get) Token: 0x06006817 RID: 26647 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006818 RID: 26648 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006819 RID: 26649 RVA: 0x004DDF60 File Offset: 0x004DC160
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60616k75Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x0600681A RID: 26650 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002898 RID: 10392
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
