﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000019 RID: 25
	<DesignerGenerated()>
	Public Partial Class frmBackup
		Inherits Form

		' Token: 0x06000379 RID: 889 RVA: 0x0002A8D8 File Offset: 0x00028AD8
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmBackup_Load
			frmBackup.__ENCList.Add(New WeakReference(Me))
			Me.mstrBackup = ""
			Me.mstrPath_Backup = ""
			Me.mintNumBackup = -1
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700015F RID: 351
		' (get) Token: 0x0600037C RID: 892 RVA: 0x0002BA6C File Offset: 0x00029C6C
		' (set) Token: 0x0600037D RID: 893 RVA: 0x000029D0 File Offset: 0x00000BD0
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000160 RID: 352
		' (get) Token: 0x0600037E RID: 894 RVA: 0x0002BA84 File Offset: 0x00029C84
		' (set) Token: 0x0600037F RID: 895 RVA: 0x0002BA9C File Offset: 0x00029C9C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000161 RID: 353
		' (get) Token: 0x06000380 RID: 896 RVA: 0x0002BB08 File Offset: 0x00029D08
		' (set) Token: 0x06000381 RID: 897 RVA: 0x0002BB20 File Offset: 0x00029D20
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000162 RID: 354
		' (get) Token: 0x06000382 RID: 898 RVA: 0x0002BB8C File Offset: 0x00029D8C
		' (set) Token: 0x06000383 RID: 899 RVA: 0x000029DA File Offset: 0x00000BDA
		Friend Overridable Property grpSelect As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpSelect = value
			End Set
		End Property

		' Token: 0x17000163 RID: 355
		' (get) Token: 0x06000384 RID: 900 RVA: 0x0002BBA4 File Offset: 0x00029DA4
		' (set) Token: 0x06000385 RID: 901 RVA: 0x000029E4 File Offset: 0x00000BE4
		Friend Overridable Property radMonth As RadioButton
			<DebuggerNonUserCode()>
			Get
				Return Me._radMonth
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._radMonth = value
			End Set
		End Property

		' Token: 0x17000164 RID: 356
		' (get) Token: 0x06000386 RID: 902 RVA: 0x0002BBBC File Offset: 0x00029DBC
		' (set) Token: 0x06000387 RID: 903 RVA: 0x000029EE File Offset: 0x00000BEE
		Friend Overridable Property radWeek As RadioButton
			<DebuggerNonUserCode()>
			Get
				Return Me._radWeek
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._radWeek = value
			End Set
		End Property

		' Token: 0x17000165 RID: 357
		' (get) Token: 0x06000388 RID: 904 RVA: 0x0002BBD4 File Offset: 0x00029DD4
		' (set) Token: 0x06000389 RID: 905 RVA: 0x000029F8 File Offset: 0x00000BF8
		Friend Overridable Property radTurnOff As RadioButton
			<DebuggerNonUserCode()>
			Get
				Return Me._radTurnOff
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._radTurnOff = value
			End Set
		End Property

		' Token: 0x17000166 RID: 358
		' (get) Token: 0x0600038A RID: 906 RVA: 0x0002BBEC File Offset: 0x00029DEC
		' (set) Token: 0x0600038B RID: 907 RVA: 0x00002A02 File Offset: 0x00000C02
		Friend Overridable Property nupDay As NumericUpDown
			<DebuggerNonUserCode()>
			Get
				Return Me._nupDay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As NumericUpDown)
				Me._nupDay = value
			End Set
		End Property

		' Token: 0x17000167 RID: 359
		' (get) Token: 0x0600038C RID: 908 RVA: 0x0002BC04 File Offset: 0x00029E04
		' (set) Token: 0x0600038D RID: 909 RVA: 0x00002A0C File Offset: 0x00000C0C
		Friend Overridable Property cmbWeek As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbWeek
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Me._cmbWeek = value
			End Set
		End Property

		' Token: 0x17000168 RID: 360
		' (get) Token: 0x0600038E RID: 910 RVA: 0x0002BC1C File Offset: 0x00029E1C
		' (set) Token: 0x0600038F RID: 911 RVA: 0x0002BC34 File Offset: 0x00029E34
		Friend Overridable Property btnPath As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPath
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPath IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPath.Click, AddressOf Me.btnPath_Click
				End If
				Me._btnPath = value
				flag = Me._btnPath IsNot Nothing
				If flag Then
					AddHandler Me._btnPath.Click, AddressOf Me.btnPath_Click
				End If
			End Set
		End Property

		' Token: 0x17000169 RID: 361
		' (get) Token: 0x06000390 RID: 912 RVA: 0x0002BCA0 File Offset: 0x00029EA0
		' (set) Token: 0x06000391 RID: 913 RVA: 0x00002A16 File Offset: 0x00000C16
		Friend Overridable Property lblPath As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPath
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPath = value
			End Set
		End Property

		' Token: 0x1700016A RID: 362
		' (get) Token: 0x06000392 RID: 914 RVA: 0x0002BCB8 File Offset: 0x00029EB8
		' (set) Token: 0x06000393 RID: 915 RVA: 0x00002A20 File Offset: 0x00000C20
		Friend Overridable Property txtPath As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPath
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtPath = value
			End Set
		End Property

		' Token: 0x1700016B RID: 363
		' (get) Token: 0x06000394 RID: 916 RVA: 0x0002BCD0 File Offset: 0x00029ED0
		' (set) Token: 0x06000395 RID: 917 RVA: 0x00002A2A File Offset: 0x00000C2A
		Friend Overridable Property radNone As RadioButton
			<DebuggerNonUserCode()>
			Get
				Return Me._radNone
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._radNone = value
			End Set
		End Property

		' Token: 0x1700016C RID: 364
		' (get) Token: 0x06000396 RID: 918 RVA: 0x0002BCE8 File Offset: 0x00029EE8
		' (set) Token: 0x06000397 RID: 919 RVA: 0x00002A34 File Offset: 0x00000C34
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x1700016D RID: 365
		' (get) Token: 0x06000398 RID: 920 RVA: 0x0002BD00 File Offset: 0x00029F00
		' (set) Token: 0x06000399 RID: 921 RVA: 0x00002A3E File Offset: 0x00000C3E
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x1700016E RID: 366
		' (get) Token: 0x0600039A RID: 922 RVA: 0x0002BD18 File Offset: 0x00029F18
		' (set) Token: 0x0600039B RID: 923 RVA: 0x00002A48 File Offset: 0x00000C48
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x1700016F RID: 367
		' (get) Token: 0x0600039C RID: 924 RVA: 0x0002BD30 File Offset: 0x00029F30
		' (set) Token: 0x0600039D RID: 925 RVA: 0x00002A52 File Offset: 0x00000C52
		Friend Overridable Property txtNumBackup As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtNumBackup
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtNumBackup = value
			End Set
		End Property

		' Token: 0x17000170 RID: 368
		' (get) Token: 0x0600039E RID: 926 RVA: 0x0002BD48 File Offset: 0x00029F48
		' (set) Token: 0x0600039F RID: 927 RVA: 0x0002BD60 File Offset: 0x00029F60
		Friend Overridable Property btnNumAll As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNumAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNumAll IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNumAll.Click, AddressOf Me.btnNumAll_Click
				End If
				Me._btnNumAll = value
				flag = Me._btnNumAll IsNot Nothing
				If flag Then
					AddHandler Me._btnNumAll.Click, AddressOf Me.btnNumAll_Click
				End If
			End Set
		End Property

		' Token: 0x17000171 RID: 369
		' (get) Token: 0x060003A0 RID: 928 RVA: 0x0002BDCC File Offset: 0x00029FCC
		' (set) Token: 0x060003A1 RID: 929 RVA: 0x0002BDE4 File Offset: 0x00029FE4
		Friend Overridable Property btnNum0 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNum0
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNum0 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNum0.Click, AddressOf Me.btnNum0_Click
				End If
				Me._btnNum0 = value
				flag = Me._btnNum0 IsNot Nothing
				If flag Then
					AddHandler Me._btnNum0.Click, AddressOf Me.btnNum0_Click
				End If
			End Set
		End Property

		' Token: 0x17000172 RID: 370
		' (get) Token: 0x060003A2 RID: 930 RVA: 0x0002BE50 File Offset: 0x0002A050
		' (set) Token: 0x060003A3 RID: 931 RVA: 0x0002BE68 File Offset: 0x0002A068
		Friend Overridable Property btnNumKey As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNumKey
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNumKey IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNumKey.Click, AddressOf Me.btnNumKey_Click
				End If
				Me._btnNumKey = value
				flag = Me._btnNumKey IsNot Nothing
				If flag Then
					AddHandler Me._btnNumKey.Click, AddressOf Me.btnNumKey_Click
				End If
			End Set
		End Property

		' Token: 0x060003A4 RID: 932 RVA: 0x0002BED4 File Offset: 0x0002A0D4
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/BACKUPDB")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mstrBackup = xmlNode.InnerText.Trim()
				End If
				Dim xmlNodeList2 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/BACKUPDBPATH")
				flag = xmlNodeList2.Count > 0
				If flag Then
					Dim xmlNode2 As XmlNode = xmlNodeList2.Item(0)
					Me.mstrPath_Backup = xmlNode2.InnerText.Trim()
				End If
				Dim xmlNodeList3 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/NUMBACKUP")
				flag = xmlNodeList3.Count > 0
				If flag Then
					Dim xmlNode3 As XmlNode = xmlNodeList3.Item(0)
					Me.mintNumBackup = Conversions.ToInteger(xmlNode3.InnerText.Trim())
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - sGetPara_From_SetparaXML " + ex.Message + vbCrLf, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x17000173 RID: 371
		' (get) Token: 0x060003A5 RID: 933 RVA: 0x0002C004 File Offset: 0x0002A204
		' (set) Token: 0x060003A6 RID: 934 RVA: 0x00002A5C File Offset: 0x00000C5C
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000174 RID: 372
		' (get) Token: 0x060003A7 RID: 935 RVA: 0x0002C01C File Offset: 0x0002A21C
		' (set) Token: 0x060003A8 RID: 936 RVA: 0x00002A67 File Offset: 0x00000C67
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x060003A9 RID: 937 RVA: 0x0002C034 File Offset: 0x0002A234
		Private Sub btnPath_Click(sender As Object, e As EventArgs)
			Try
				Dim folderBrowserDialog As FolderBrowserDialog = New FolderBrowserDialog()
				folderBrowserDialog.Description = Me.mArrStrFrmMess(14)
				Dim flag As Boolean = folderBrowserDialog.ShowDialog(Me) = DialogResult.OK
				If flag Then
					Me.txtPath.Text = folderBrowserDialog.SelectedPath
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPath_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003AA RID: 938 RVA: 0x0002C0FC File Offset: 0x0002A2FC
		Private Sub frmBackup_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Me.sGetPara_From_SetparaXML()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmBackup_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003AB RID: 939 RVA: 0x0002C1B0 File Offset: 0x0002A3B0
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtPath.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
					Me.txtPath.Focus()
				Else
					Dim text As String = "Nhấn nút lưu thông tin Backup: "
					flag = Me.radNone.Checked
					If flag Then
						Me.mstrBackup = ""
						text += "Tức thì"
					Else
						flag = Me.radTurnOff.Checked
						If flag Then
							Me.mstrBackup = "TURNOFF"
							text += "Lúc tắt phần mềm"
						Else
							flag = Me.radWeek.Checked
							If flag Then
								Me.mstrBackup = "WEEK," + Me.cmbWeek.SelectedIndex.ToString()
								text = text + "Hàng tuần vào thứ " + Me.cmbWeek.Text
							Else
								flag = Me.radMonth.Checked
								If flag Then
									Me.mstrBackup = "MONTH," + Me.nupDay.Value.ToString()
									text = text + "Hàng tháng vào ngày " + Me.nupDay.Value.ToString()
								End If
							End If
						End If
					End If
					Me.mstrPath_Backup = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Right(Strings.Trim(Me.txtPath.Text), 1), "\", False) = 0, Strings.Left(Strings.Trim(Me.txtPath.Text), Strings.Trim(Me.txtPath.Text).Length - 1), Strings.Trim(Me.txtPath.Text)))
					text = text + ". Đường dẫn backup là: " + Me.mstrPath_Backup
					mdlFile.gfWriteLogFile(text)
					mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
					Dim b As Byte = Me.fUpdateSetPara()
					flag = (b <> 0) And Me.radNone.Checked
					If flag Then
						Dim flag2 As Boolean = False
						Dim text2 As String = ""
						Dim array As String() = Me.mstrPath_Backup.Split(New Char() { "*"c })
						Dim num As Integer = 0
						Dim num2 As Integer = array.Length - 1
						Dim num3 As Integer = num
						While True
							Dim num4 As Integer = num3
							Dim num5 As Integer = num2
							If num4 > num5 Then
								Exit For
							End If
							Dim text3 As String = array(num3).Trim()
							flag = text3.Trim().Length > 0
							If flag Then
								Dim flag3 As Boolean = text3.EndsWith("\")
								If flag3 Then
									text3 = text3.Substring(0, text3.Length - 1)
								End If
								flag3 = Not flag2
								If flag3 Then
									text2 = text3
									b = mdlDatabase.gfBackup(text3)
								Else
									Me.sCopyBackupFileToOrther(text2, text3)
								End If
								flag3 = b = 1
								If flag3 Then
									flag2 = True
								End If
							End If
							num3 += 1
						End While
					End If
					Dim clsConnect As clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "SetPara")
					clsConnect.TableName = "Main"
					New DataSet("Setpara") With { .Tables = { clsConnect } }.WriteXml(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
					b = mdlVariable.gfGetPARACONTROL()
					Interaction.MsgBox(mdlVariable.gArrStrMess(31), MsgBoxStyle.Information, Nothing)
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
			End Try
		End Sub

		' Token: 0x060003AC RID: 940 RVA: 0x0002C5AC File Offset: 0x0002A7AC
		Private Sub sCopyBackupFileToOrther(strPathNguon As String, strPath As String)
			Try
				Dim text As String = "Backup_"
				Dim dayOfWeek As DayOfWeek = DateAndTime.Now.DayOfWeek
				Dim flag As Boolean = dayOfWeek = DayOfWeek.Sunday
				If flag Then
					text += "CN"
				Else
					' The following expression was wrapped in a checked-expression
					text = text + "T" + Conversions.ToString(CInt((DateAndTime.Now.DayOfWeek + 1)))
				End If
				Dim files As String() = Directory.GetFiles(strPathNguon, text.Trim() + "*", SearchOption.TopDirectoryOnly)
				For Each text2 As String In files
					flag = File.Exists(text2)
					If flag Then
						Dim text3 As String = text2.Substring(text2.LastIndexOf("\"))
						File.Copy(text2, strPath + text3, True)
					End If
				Next
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sCopyBackupFileToOrther ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060003AD RID: 941 RVA: 0x0002C6F8 File Offset: 0x0002A8F8
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.nupDay.Minimum = 1D
				Me.nupDay.Maximum = 31D
				Me.nupDay.Value = New Decimal(DateTime.Now.Day)
				Dim array As String() = New String(7) {}
				array = New String() { Me.mArrStrFrmMess(16), Me.mArrStrFrmMess(17), Me.mArrStrFrmMess(18), Me.mArrStrFrmMess(19), Me.mArrStrFrmMess(20), Me.mArrStrFrmMess(21), Me.mArrStrFrmMess(22) }
				Dim cmbWeek As ComboBox = Me.cmbWeek
				cmbWeek.DataSource = array
				cmbWeek.SelectedIndex = 0
				Me.txtPath.Text = Me.mstrPath_Backup
				Dim flag As Boolean = Operators.CompareString(Me.mstrBackup, "", False) = 0
				If flag Then
					Me.radNone.Checked = True
				End If
				flag = Operators.CompareString(Strings.Mid(Me.mstrBackup.ToUpper(), 1, 1), "T", False) = 0
				If flag Then
					Me.radTurnOff.Checked = True
				End If
				flag = Operators.CompareString(Strings.Mid(Me.mstrBackup.ToUpper(), 1, 1), "W", False) = 0
				If flag Then
					Me.radWeek.Checked = True
					Me.cmbWeek.SelectedIndex = Conversions.ToInteger(Strings.Mid(Me.mstrBackup.ToUpper(), 6, 1))
				End If
				flag = Operators.CompareString(Strings.Mid(Me.mstrBackup.ToUpper(), 1, 1), "M", False) = 0
				If flag Then
					Me.radMonth.Checked = True
					Me.nupDay.Value = New Decimal(Conversion.Val(Strings.Mid(Me.mstrBackup.ToUpper(), 7)))
				End If
				Me.txtNumBackup.Text = Conversions.ToString(Me.mintNumBackup)
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060003AE RID: 942 RVA: 0x0002C9C4 File Offset: 0x0002ABC4
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060003AF RID: 943 RVA: 0x0002CAD0 File Offset: 0x0002ACD0
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003B0 RID: 944 RVA: 0x0002CB70 File Offset: 0x0002AD70
		Private Function fUpdateSetPara() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nvcBACKUP"
				array(0).Value = Me.mstrBackup
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nvcBACKUPPATH"
				array(1).Value = Me.mstrPath_Backup
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@intNUMBACKUP"
				array(3).Value = Conversions.ToInteger(Me.txtNumBackup.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMBACKUP_UPDATE_SETPARA", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060003B1 RID: 945 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x060003B2 RID: 946 RVA: 0x00002A76 File Offset: 0x00000C76
		Private Sub btnNumAll_Click(sender As Object, e As EventArgs)
			Me.txtNumBackup.Text = "-1"
		End Sub

		' Token: 0x060003B3 RID: 947 RVA: 0x00002A8B File Offset: 0x00000C8B
		Private Sub btnNum0_Click(sender As Object, e As EventArgs)
			Me.txtNumBackup.Text = "0"
		End Sub

		' Token: 0x060003B4 RID: 948 RVA: 0x0002CD5C File Offset: 0x0002AF5C
		Private Sub btnNumKey_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad = New frmNumPad()
				frmNumPad.ShowDialog()
				Dim flag As Boolean = frmNumPad.pbytSuccess > 0
				If flag Then
					Me.txtNumBackup.Text = Conversions.ToString(Integer.Parse(Conversions.ToString(frmNumPad.pSglNumberReturn)))
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNumKey_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x04000181 RID: 385
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000183 RID: 387
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000184 RID: 388
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000185 RID: 389
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000186 RID: 390
		<AccessedThroughProperty("grpSelect")>
		Private _grpSelect As GroupBox

		' Token: 0x04000187 RID: 391
		<AccessedThroughProperty("radMonth")>
		Private _radMonth As RadioButton

		' Token: 0x04000188 RID: 392
		<AccessedThroughProperty("radWeek")>
		Private _radWeek As RadioButton

		' Token: 0x04000189 RID: 393
		<AccessedThroughProperty("radTurnOff")>
		Private _radTurnOff As RadioButton

		' Token: 0x0400018A RID: 394
		<AccessedThroughProperty("nupDay")>
		Private _nupDay As NumericUpDown

		' Token: 0x0400018B RID: 395
		<AccessedThroughProperty("cmbWeek")>
		Private _cmbWeek As ComboBox

		' Token: 0x0400018C RID: 396
		<AccessedThroughProperty("btnPath")>
		Private _btnPath As Button

		' Token: 0x0400018D RID: 397
		<AccessedThroughProperty("lblPath")>
		Private _lblPath As Label

		' Token: 0x0400018E RID: 398
		<AccessedThroughProperty("txtPath")>
		Private _txtPath As TextBox

		' Token: 0x0400018F RID: 399
		<AccessedThroughProperty("radNone")>
		Private _radNone As RadioButton

		' Token: 0x04000190 RID: 400
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000191 RID: 401
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000192 RID: 402
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000193 RID: 403
		<AccessedThroughProperty("txtNumBackup")>
		Private _txtNumBackup As TextBox

		' Token: 0x04000194 RID: 404
		<AccessedThroughProperty("btnNumAll")>
		Private _btnNumAll As Button

		' Token: 0x04000195 RID: 405
		<AccessedThroughProperty("btnNum0")>
		Private _btnNum0 As Button

		' Token: 0x04000196 RID: 406
		<AccessedThroughProperty("btnNumKey")>
		Private _btnNumKey As Button

		' Token: 0x04000197 RID: 407
		Private mArrStrFrmMess As String()

		' Token: 0x04000198 RID: 408
		Private mbytFormStatus As Byte

		' Token: 0x04000199 RID: 409
		Private mbytSuccess As Byte

		' Token: 0x0400019A RID: 410
		Private mstrBackup As String

		' Token: 0x0400019B RID: 411
		Private mstrPath_Backup As String

		' Token: 0x0400019C RID: 412
		Private mintNumBackup As Integer

		' Token: 0x0400019D RID: 413
		Private mblnSave As Boolean
	End Class
End Namespace
