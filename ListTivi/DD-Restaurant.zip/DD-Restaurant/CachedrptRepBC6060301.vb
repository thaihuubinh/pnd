﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000264 RID: 612
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC6060301
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600656C RID: 25964 RVA: 0x00012463 File Offset: 0x00010663
		Public Sub New()
			CachedrptRepBC6060301.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002727 RID: 10023
		' (get) Token: 0x0600656D RID: 25965 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x0600656E RID: 25966 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002728 RID: 10024
		' (get) Token: 0x0600656F RID: 25967 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006570 RID: 25968 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002729 RID: 10025
		' (get) Token: 0x06006571 RID: 25969 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006572 RID: 25970 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006573 RID: 25971 RVA: 0x004DD7E0 File Offset: 0x004DB9E0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC6060301() With { .Site = Me.Site }
		End Function

		' Token: 0x06006574 RID: 25972 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x0400285C RID: 10332
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
