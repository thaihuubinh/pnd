﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO.Ports
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000065 RID: 101
	<DesignerGenerated()>
	Public Partial Class frmDMMAYINHD2
		Inherits Form

		' Token: 0x06001FA2 RID: 8098 RVA: 0x00188D10 File Offset: 0x00186F10
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMMAYINHD2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMMAYINHD2_Load
			frmDMMAYINHD2.__ENCList.Add(New WeakReference(Me))
			Me.mstrMAY = ""
			Me.mstrLoaiMayIn = ""
			Me.mTbLOAIMAYIN = New DataTable()
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000ADA RID: 2778
		' (get) Token: 0x06001FA5 RID: 8101 RVA: 0x0018BD24 File Offset: 0x00189F24
		' (set) Token: 0x06001FA6 RID: 8102 RVA: 0x000067C4 File Offset: 0x000049C4
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000ADB RID: 2779
		' (get) Token: 0x06001FA7 RID: 8103 RVA: 0x0018BD3C File Offset: 0x00189F3C
		' (set) Token: 0x06001FA8 RID: 8104 RVA: 0x0018BD54 File Offset: 0x00189F54
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000ADC RID: 2780
		' (get) Token: 0x06001FA9 RID: 8105 RVA: 0x0018BDC0 File Offset: 0x00189FC0
		' (set) Token: 0x06001FAA RID: 8106 RVA: 0x000067CE File Offset: 0x000049CE
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x17000ADD RID: 2781
		' (get) Token: 0x06001FAB RID: 8107 RVA: 0x0018BDD8 File Offset: 0x00189FD8
		' (set) Token: 0x06001FAC RID: 8108 RVA: 0x0018BDF0 File Offset: 0x00189FF0
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000ADE RID: 2782
		' (get) Token: 0x06001FAD RID: 8109 RVA: 0x0018BE5C File Offset: 0x0018A05C
		' (set) Token: 0x06001FAE RID: 8110 RVA: 0x0018BE74 File Offset: 0x0018A074
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000ADF RID: 2783
		' (get) Token: 0x06001FAF RID: 8111 RVA: 0x0018BEE0 File Offset: 0x0018A0E0
		' (set) Token: 0x06001FB0 RID: 8112 RVA: 0x0018BEF8 File Offset: 0x0018A0F8
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000AE0 RID: 2784
		' (get) Token: 0x06001FB1 RID: 8113 RVA: 0x0018BF64 File Offset: 0x0018A164
		' (set) Token: 0x06001FB2 RID: 8114 RVA: 0x000067D8 File Offset: 0x000049D8
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x17000AE1 RID: 2785
		' (get) Token: 0x06001FB3 RID: 8115 RVA: 0x0018BF7C File Offset: 0x0018A17C
		' (set) Token: 0x06001FB4 RID: 8116 RVA: 0x0018BF94 File Offset: 0x0018A194
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000AE2 RID: 2786
		' (get) Token: 0x06001FB5 RID: 8117 RVA: 0x0018C030 File Offset: 0x0018A230
		' (set) Token: 0x06001FB6 RID: 8118 RVA: 0x0018C048 File Offset: 0x0018A248
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000AE3 RID: 2787
		' (get) Token: 0x06001FB7 RID: 8119 RVA: 0x0018C0E4 File Offset: 0x0018A2E4
		' (set) Token: 0x06001FB8 RID: 8120 RVA: 0x000067E2 File Offset: 0x000049E2
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x17000AE4 RID: 2788
		' (get) Token: 0x06001FB9 RID: 8121 RVA: 0x0018C0FC File Offset: 0x0018A2FC
		' (set) Token: 0x06001FBA RID: 8122 RVA: 0x000067EC File Offset: 0x000049EC
		Friend Overridable Property lblTimeOut As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTimeOut
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTimeOut = value
			End Set
		End Property

		' Token: 0x17000AE5 RID: 2789
		' (get) Token: 0x06001FBB RID: 8123 RVA: 0x0018C114 File Offset: 0x0018A314
		' (set) Token: 0x06001FBC RID: 8124 RVA: 0x000067F6 File Offset: 0x000049F6
		Friend Overridable Property lblPrintCount As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPrintCount
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPrintCount = value
			End Set
		End Property

		' Token: 0x17000AE6 RID: 2790
		' (get) Token: 0x06001FBD RID: 8125 RVA: 0x0018C12C File Offset: 0x0018A32C
		' (set) Token: 0x06001FBE RID: 8126 RVA: 0x00006800 File Offset: 0x00004A00
		Friend Overridable Property lblComputer As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblComputer
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblComputer = value
			End Set
		End Property

		' Token: 0x17000AE7 RID: 2791
		' (get) Token: 0x06001FBF RID: 8127 RVA: 0x0018C144 File Offset: 0x0018A344
		' (set) Token: 0x06001FC0 RID: 8128 RVA: 0x0000680A File Offset: 0x00004A0A
		Friend Overridable Property txtCOMName As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCOMName
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtCOMName = value
			End Set
		End Property

		' Token: 0x17000AE8 RID: 2792
		' (get) Token: 0x06001FC1 RID: 8129 RVA: 0x0018C15C File Offset: 0x0018A35C
		' (set) Token: 0x06001FC2 RID: 8130 RVA: 0x00006814 File Offset: 0x00004A14
		Friend Overridable Property txtBaudrate As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBaudrate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtBaudrate = value
			End Set
		End Property

		' Token: 0x17000AE9 RID: 2793
		' (get) Token: 0x06001FC3 RID: 8131 RVA: 0x0018C174 File Offset: 0x0018A374
		' (set) Token: 0x06001FC4 RID: 8132 RVA: 0x0000681E File Offset: 0x00004A1E
		Friend Overridable Property txtDataBit As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtDataBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtDataBit = value
			End Set
		End Property

		' Token: 0x17000AEA RID: 2794
		' (get) Token: 0x06001FC5 RID: 8133 RVA: 0x0018C18C File Offset: 0x0018A38C
		' (set) Token: 0x06001FC6 RID: 8134 RVA: 0x00006828 File Offset: 0x00004A28
		Friend Overridable Property txtParityBit As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtParityBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtParityBit = value
			End Set
		End Property

		' Token: 0x17000AEB RID: 2795
		' (get) Token: 0x06001FC7 RID: 8135 RVA: 0x0018C1A4 File Offset: 0x0018A3A4
		' (set) Token: 0x06001FC8 RID: 8136 RVA: 0x00006832 File Offset: 0x00004A32
		Friend Overridable Property txtStopBit As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtStopBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtStopBit = value
			End Set
		End Property

		' Token: 0x17000AEC RID: 2796
		' (get) Token: 0x06001FC9 RID: 8137 RVA: 0x0018C1BC File Offset: 0x0018A3BC
		' (set) Token: 0x06001FCA RID: 8138 RVA: 0x0000683C File Offset: 0x00004A3C
		Friend Overridable Property txtFlowControl As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtFlowControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtFlowControl = value
			End Set
		End Property

		' Token: 0x17000AED RID: 2797
		' (get) Token: 0x06001FCB RID: 8139 RVA: 0x0018C1D4 File Offset: 0x0018A3D4
		' (set) Token: 0x06001FCC RID: 8140 RVA: 0x0018C1EC File Offset: 0x0018A3EC
		Friend Overridable Property txtTimeOut As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTimeOut
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTimeOut IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTimeOut.KeyPress, AddressOf Me.txtTimeOut_KeyPress
					RemoveHandler Me._txtTimeOut.GotFocus, AddressOf Me.txtTimeOut_GotFocus
				End If
				Me._txtTimeOut = value
				flag = Me._txtTimeOut IsNot Nothing
				If flag Then
					AddHandler Me._txtTimeOut.KeyPress, AddressOf Me.txtTimeOut_KeyPress
					AddHandler Me._txtTimeOut.GotFocus, AddressOf Me.txtTimeOut_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000AEE RID: 2798
		' (get) Token: 0x06001FCD RID: 8141 RVA: 0x0018C288 File Offset: 0x0018A488
		' (set) Token: 0x06001FCE RID: 8142 RVA: 0x0018C2A0 File Offset: 0x0018A4A0
		Friend Overridable Property txtPrintCount As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPrintCount
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPrintCount IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPrintCount.KeyPress, AddressOf Me.txtPrintCount_KeyPress
					RemoveHandler Me._txtPrintCount.GotFocus, AddressOf Me.txtPrintCount_GotFocus
				End If
				Me._txtPrintCount = value
				flag = Me._txtPrintCount IsNot Nothing
				If flag Then
					AddHandler Me._txtPrintCount.KeyPress, AddressOf Me.txtPrintCount_KeyPress
					AddHandler Me._txtPrintCount.GotFocus, AddressOf Me.txtPrintCount_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000AEF RID: 2799
		' (get) Token: 0x06001FCF RID: 8143 RVA: 0x0018C33C File Offset: 0x0018A53C
		' (set) Token: 0x06001FD0 RID: 8144 RVA: 0x00006846 File Offset: 0x00004A46
		Friend Overridable Property lblCOMName As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCOMName
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCOMName = value
			End Set
		End Property

		' Token: 0x17000AF0 RID: 2800
		' (get) Token: 0x06001FD1 RID: 8145 RVA: 0x0018C354 File Offset: 0x0018A554
		' (set) Token: 0x06001FD2 RID: 8146 RVA: 0x00006850 File Offset: 0x00004A50
		Friend Overridable Property lblBaudrate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblBaudrate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblBaudrate = value
			End Set
		End Property

		' Token: 0x17000AF1 RID: 2801
		' (get) Token: 0x06001FD3 RID: 8147 RVA: 0x0018C36C File Offset: 0x0018A56C
		' (set) Token: 0x06001FD4 RID: 8148 RVA: 0x0000685A File Offset: 0x00004A5A
		Friend Overridable Property lblDataBit As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDataBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDataBit = value
			End Set
		End Property

		' Token: 0x17000AF2 RID: 2802
		' (get) Token: 0x06001FD5 RID: 8149 RVA: 0x0018C384 File Offset: 0x0018A584
		' (set) Token: 0x06001FD6 RID: 8150 RVA: 0x00006864 File Offset: 0x00004A64
		Friend Overridable Property lblParityBit As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblParityBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblParityBit = value
			End Set
		End Property

		' Token: 0x17000AF3 RID: 2803
		' (get) Token: 0x06001FD7 RID: 8151 RVA: 0x0018C39C File Offset: 0x0018A59C
		' (set) Token: 0x06001FD8 RID: 8152 RVA: 0x0000686E File Offset: 0x00004A6E
		Friend Overridable Property lblStopBit As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblStopBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblStopBit = value
			End Set
		End Property

		' Token: 0x17000AF4 RID: 2804
		' (get) Token: 0x06001FD9 RID: 8153 RVA: 0x0018C3B4 File Offset: 0x0018A5B4
		' (set) Token: 0x06001FDA RID: 8154 RVA: 0x00006878 File Offset: 0x00004A78
		Friend Overridable Property lblFlowControl As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFlowControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFlowControl = value
			End Set
		End Property

		' Token: 0x17000AF5 RID: 2805
		' (get) Token: 0x06001FDB RID: 8155 RVA: 0x0018C3CC File Offset: 0x0018A5CC
		' (set) Token: 0x06001FDC RID: 8156 RVA: 0x00006882 File Offset: 0x00004A82
		Friend Overridable Property txtColor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtColor = value
			End Set
		End Property

		' Token: 0x17000AF6 RID: 2806
		' (get) Token: 0x06001FDD RID: 8157 RVA: 0x0018C3E4 File Offset: 0x0018A5E4
		' (set) Token: 0x06001FDE RID: 8158 RVA: 0x0018C3FC File Offset: 0x0018A5FC
		Friend Overridable Property txtRemark As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtRemark
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtRemark IsNot Nothing
				If flag Then
					RemoveHandler Me._txtRemark.GotFocus, AddressOf Me.txtRemark_GotFocus
				End If
				Me._txtRemark = value
				flag = Me._txtRemark IsNot Nothing
				If flag Then
					AddHandler Me._txtRemark.GotFocus, AddressOf Me.txtRemark_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000AF7 RID: 2807
		' (get) Token: 0x06001FDF RID: 8159 RVA: 0x0018C468 File Offset: 0x0018A668
		' (set) Token: 0x06001FE0 RID: 8160 RVA: 0x0000688C File Offset: 0x00004A8C
		Friend Overridable Property lblRemark As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblRemark
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblRemark = value
			End Set
		End Property

		' Token: 0x17000AF8 RID: 2808
		' (get) Token: 0x06001FE1 RID: 8161 RVA: 0x0018C480 File Offset: 0x0018A680
		' (set) Token: 0x06001FE2 RID: 8162 RVA: 0x00006896 File Offset: 0x00004A96
		Friend Overridable Property txtTENMAY As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENMAY = value
			End Set
		End Property

		' Token: 0x17000AF9 RID: 2809
		' (get) Token: 0x06001FE3 RID: 8163 RVA: 0x0018C498 File Offset: 0x0018A698
		' (set) Token: 0x06001FE4 RID: 8164 RVA: 0x0018C4B0 File Offset: 0x0018A6B0
		Friend Overridable Property txtMAMAY As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAMAY IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAMAY.TextChanged, AddressOf Me.txtMAMAY_TextChanged
					RemoveHandler Me._txtMAMAY.GotFocus, AddressOf Me.txtMAMAY_GotFocus
					RemoveHandler Me._txtMAMAY.KeyPress, AddressOf Me.txtMAMAY_KeyPress
				End If
				Me._txtMAMAY = value
				flag = Me._txtMAMAY IsNot Nothing
				If flag Then
					AddHandler Me._txtMAMAY.TextChanged, AddressOf Me.txtMAMAY_TextChanged
					AddHandler Me._txtMAMAY.GotFocus, AddressOf Me.txtMAMAY_GotFocus
					AddHandler Me._txtMAMAY.KeyPress, AddressOf Me.txtMAMAY_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000AFA RID: 2810
		' (get) Token: 0x06001FE5 RID: 8165 RVA: 0x0018C580 File Offset: 0x0018A780
		' (set) Token: 0x06001FE6 RID: 8166 RVA: 0x0018C598 File Offset: 0x0018A798
		Friend Overridable Property btnDMMAY As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMMAY IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMMAY.Click, AddressOf Me.btnDMMAY_Click
				End If
				Me._btnDMMAY = value
				flag = Me._btnDMMAY IsNot Nothing
				If flag Then
					AddHandler Me._btnDMMAY.Click, AddressOf Me.btnDMMAY_Click
				End If
			End Set
		End Property

		' Token: 0x17000AFB RID: 2811
		' (get) Token: 0x06001FE7 RID: 8167 RVA: 0x0018C604 File Offset: 0x0018A804
		' (set) Token: 0x06001FE8 RID: 8168 RVA: 0x0018C61C File Offset: 0x0018A81C
		Friend Overridable Property cmbBaudrate As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbBaudrate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbBaudrate IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbBaudrate.KeyPress, AddressOf Me.cmbBaudrate_KeyPress
				End If
				Me._cmbBaudrate = value
				flag = Me._cmbBaudrate IsNot Nothing
				If flag Then
					AddHandler Me._cmbBaudrate.KeyPress, AddressOf Me.cmbBaudrate_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000AFC RID: 2812
		' (get) Token: 0x06001FE9 RID: 8169 RVA: 0x0018C688 File Offset: 0x0018A888
		' (set) Token: 0x06001FEA RID: 8170 RVA: 0x0018C6A0 File Offset: 0x0018A8A0
		Friend Overridable Property cmbDataBit As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbDataBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbDataBit IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbDataBit.KeyPress, AddressOf Me.cmbDataBit_KeyPress
				End If
				Me._cmbDataBit = value
				flag = Me._cmbDataBit IsNot Nothing
				If flag Then
					AddHandler Me._cmbDataBit.KeyPress, AddressOf Me.cmbDataBit_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000AFD RID: 2813
		' (get) Token: 0x06001FEB RID: 8171 RVA: 0x0018C70C File Offset: 0x0018A90C
		' (set) Token: 0x06001FEC RID: 8172 RVA: 0x0018C724 File Offset: 0x0018A924
		Friend Overridable Property cmbParityBit As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbParityBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbParityBit IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbParityBit.KeyPress, AddressOf Me.cmbParityBit_KeyPress
				End If
				Me._cmbParityBit = value
				flag = Me._cmbParityBit IsNot Nothing
				If flag Then
					AddHandler Me._cmbParityBit.KeyPress, AddressOf Me.cmbParityBit_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000AFE RID: 2814
		' (get) Token: 0x06001FED RID: 8173 RVA: 0x0018C790 File Offset: 0x0018A990
		' (set) Token: 0x06001FEE RID: 8174 RVA: 0x0018C7A8 File Offset: 0x0018A9A8
		Friend Overridable Property cmbStopBit As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbStopBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbStopBit IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbStopBit.KeyPress, AddressOf Me.cmbStopBit_KeyPress
				End If
				Me._cmbStopBit = value
				flag = Me._cmbStopBit IsNot Nothing
				If flag Then
					AddHandler Me._cmbStopBit.KeyPress, AddressOf Me.cmbStopBit_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000AFF RID: 2815
		' (get) Token: 0x06001FEF RID: 8175 RVA: 0x0018C814 File Offset: 0x0018AA14
		' (set) Token: 0x06001FF0 RID: 8176 RVA: 0x0018C82C File Offset: 0x0018AA2C
		Friend Overridable Property cmbFlowControl As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbFlowControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbFlowControl IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbFlowControl.KeyPress, AddressOf Me.cmbFlowControl_KeyPress
				End If
				Me._cmbFlowControl = value
				flag = Me._cmbFlowControl IsNot Nothing
				If flag Then
					AddHandler Me._cmbFlowControl.KeyPress, AddressOf Me.cmbFlowControl_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000B00 RID: 2816
		' (get) Token: 0x06001FF1 RID: 8177 RVA: 0x0018C898 File Offset: 0x0018AA98
		' (set) Token: 0x06001FF2 RID: 8178 RVA: 0x0018C8B0 File Offset: 0x0018AAB0
		Friend Overridable Property cmbCOMName As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbCOMName
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbCOMName IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbCOMName.KeyPress, AddressOf Me.cmbCOMName_KeyPress
				End If
				Me._cmbCOMName = value
				flag = Me._cmbCOMName IsNot Nothing
				If flag Then
					AddHandler Me._cmbCOMName.KeyPress, AddressOf Me.cmbCOMName_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000B01 RID: 2817
		' (get) Token: 0x06001FF3 RID: 8179 RVA: 0x0018C91C File Offset: 0x0018AB1C
		' (set) Token: 0x06001FF4 RID: 8180 RVA: 0x0018C934 File Offset: 0x0018AB34
		Friend Overridable Property cmbLoaiMayIn As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbLoaiMayIn
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbLoaiMayIn IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbLoaiMayIn.SelectedValueChanged, AddressOf Me.cmbLoaiMayIn_SelectedValueChanged
					RemoveHandler Me._cmbLoaiMayIn.KeyPress, AddressOf Me.cmbLoaiMayIn_KeyPress
				End If
				Me._cmbLoaiMayIn = value
				flag = Me._cmbLoaiMayIn IsNot Nothing
				If flag Then
					AddHandler Me._cmbLoaiMayIn.SelectedValueChanged, AddressOf Me.cmbLoaiMayIn_SelectedValueChanged
					AddHandler Me._cmbLoaiMayIn.KeyPress, AddressOf Me.cmbLoaiMayIn_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000B02 RID: 2818
		' (get) Token: 0x06001FF5 RID: 8181 RVA: 0x0018C9D0 File Offset: 0x0018ABD0
		' (set) Token: 0x06001FF6 RID: 8182 RVA: 0x000068A0 File Offset: 0x00004AA0
		Friend Overridable Property lblLoaiMayIn As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLoaiMayIn
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblLoaiMayIn = value
			End Set
		End Property

		' Token: 0x17000B03 RID: 2819
		' (get) Token: 0x06001FF7 RID: 8183 RVA: 0x0018C9E8 File Offset: 0x0018ABE8
		' (set) Token: 0x06001FF8 RID: 8184 RVA: 0x000068AA File Offset: 0x00004AAA
		Friend Overridable Property lblLOPENDRAWERTAMTINH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLOPENDRAWERTAMTINH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblLOPENDRAWERTAMTINH = value
			End Set
		End Property

		' Token: 0x17000B04 RID: 2820
		' (get) Token: 0x06001FF9 RID: 8185 RVA: 0x0018CA00 File Offset: 0x0018AC00
		' (set) Token: 0x06001FFA RID: 8186 RVA: 0x0018CA18 File Offset: 0x0018AC18
		Friend Overridable Property chkLOPENDRAWERTAMTINH As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLOPENDRAWERTAMTINH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLOPENDRAWERTAMTINH IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLOPENDRAWERTAMTINH.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
				Me._chkLOPENDRAWERTAMTINH = value
				flag = Me._chkLOPENDRAWERTAMTINH IsNot Nothing
				If flag Then
					AddHandler Me._chkLOPENDRAWERTAMTINH.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000B05 RID: 2821
		' (get) Token: 0x06001FFB RID: 8187 RVA: 0x0018CA84 File Offset: 0x0018AC84
		' (set) Token: 0x06001FFC RID: 8188 RVA: 0x000068B4 File Offset: 0x00004AB4
		Friend Overridable Property lblLOPENDRAWER As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLOPENDRAWER
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblLOPENDRAWER = value
			End Set
		End Property

		' Token: 0x17000B06 RID: 2822
		' (get) Token: 0x06001FFD RID: 8189 RVA: 0x0018CA9C File Offset: 0x0018AC9C
		' (set) Token: 0x06001FFE RID: 8190 RVA: 0x0018CAB4 File Offset: 0x0018ACB4
		Friend Overridable Property chkLOPENDRAWER As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLOPENDRAWER
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLOPENDRAWER IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLOPENDRAWER.KeyPress, AddressOf Me.chkLOPENDRAWER_KeyPress
				End If
				Me._chkLOPENDRAWER = value
				flag = Me._chkLOPENDRAWER IsNot Nothing
				If flag Then
					AddHandler Me._chkLOPENDRAWER.KeyPress, AddressOf Me.chkLOPENDRAWER_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000B07 RID: 2823
		' (get) Token: 0x06001FFF RID: 8191 RVA: 0x0018CB20 File Offset: 0x0018AD20
		' (set) Token: 0x06002000 RID: 8192 RVA: 0x000068BE File Offset: 0x00004ABE
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000B08 RID: 2824
		' (get) Token: 0x06002001 RID: 8193 RVA: 0x0018CB38 File Offset: 0x0018AD38
		' (set) Token: 0x06002002 RID: 8194 RVA: 0x000068C8 File Offset: 0x00004AC8
		Friend Overridable Property txtPrintWidth As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPrintWidth
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtPrintWidth = value
			End Set
		End Property

		' Token: 0x17000B09 RID: 2825
		' (get) Token: 0x06002003 RID: 8195 RVA: 0x0018CB50 File Offset: 0x0018AD50
		' (set) Token: 0x06002004 RID: 8196 RVA: 0x000068D2 File Offset: 0x00004AD2
		Friend Overridable Property lblPrintW As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPrintW
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPrintW = value
			End Set
		End Property

		' Token: 0x17000B0A RID: 2826
		' (get) Token: 0x06002005 RID: 8197 RVA: 0x0018CB68 File Offset: 0x0018AD68
		' (set) Token: 0x06002006 RID: 8198 RVA: 0x000068DC File Offset: 0x00004ADC
		Friend Overridable Property LblMAMAYTINHCALL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._LblMAMAYTINHCALL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._LblMAMAYTINHCALL = value
			End Set
		End Property

		' Token: 0x17000B0B RID: 2827
		' (get) Token: 0x06002007 RID: 8199 RVA: 0x0018CB80 File Offset: 0x0018AD80
		' (set) Token: 0x06002008 RID: 8200 RVA: 0x000068E6 File Offset: 0x00004AE6
		Friend Overridable Property txtTENMAYCALL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENMAYCALL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENMAYCALL = value
			End Set
		End Property

		' Token: 0x17000B0C RID: 2828
		' (get) Token: 0x06002009 RID: 8201 RVA: 0x0018CB98 File Offset: 0x0018AD98
		' (set) Token: 0x0600200A RID: 8202 RVA: 0x0018CBB0 File Offset: 0x0018ADB0
		Friend Overridable Property TxtMAMAYCALL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._TxtMAMAYCALL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._TxtMAMAYCALL IsNot Nothing
				If flag Then
					RemoveHandler Me._TxtMAMAYCALL.TextChanged, AddressOf Me.TxtMAMAYCALL_TextChanged
				End If
				Me._TxtMAMAYCALL = value
				flag = Me._TxtMAMAYCALL IsNot Nothing
				If flag Then
					AddHandler Me._TxtMAMAYCALL.TextChanged, AddressOf Me.TxtMAMAYCALL_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000B0D RID: 2829
		' (get) Token: 0x0600200B RID: 8203 RVA: 0x0018CC1C File Offset: 0x0018AE1C
		' (set) Token: 0x0600200C RID: 8204 RVA: 0x0018CC34 File Offset: 0x0018AE34
		Friend Overridable Property btnSECLECTMAYCALL As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSECLECTMAYCALL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSECLECTMAYCALL IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSECLECTMAYCALL.Click, AddressOf Me.btnSECLECTMAYCALL_Click
				End If
				Me._btnSECLECTMAYCALL = value
				flag = Me._btnSECLECTMAYCALL IsNot Nothing
				If flag Then
					AddHandler Me._btnSECLECTMAYCALL.Click, AddressOf Me.btnSECLECTMAYCALL_Click
				End If
			End Set
		End Property

		' Token: 0x17000B0E RID: 2830
		' (get) Token: 0x0600200D RID: 8205 RVA: 0x0018CCA0 File Offset: 0x0018AEA0
		' (set) Token: 0x0600200E RID: 8206 RVA: 0x000068F0 File Offset: 0x00004AF0
		Friend Overridable Property txtTOP As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTOP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTOP = value
			End Set
		End Property

		' Token: 0x17000B0F RID: 2831
		' (get) Token: 0x0600200F RID: 8207 RVA: 0x0018CCB8 File Offset: 0x0018AEB8
		' (set) Token: 0x06002010 RID: 8208 RVA: 0x000068FA File Offset: 0x00004AFA
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000B10 RID: 2832
		' (get) Token: 0x06002011 RID: 8209 RVA: 0x0018CCD0 File Offset: 0x0018AED0
		' (set) Token: 0x06002012 RID: 8210 RVA: 0x00006904 File Offset: 0x00004B04
		Friend Overridable Property txtLEFT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtLEFT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtLEFT = value
			End Set
		End Property

		' Token: 0x17000B11 RID: 2833
		' (get) Token: 0x06002013 RID: 8211 RVA: 0x0018CCE8 File Offset: 0x0018AEE8
		' (set) Token: 0x06002014 RID: 8212 RVA: 0x0000690E File Offset: 0x00004B0E
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000B12 RID: 2834
		' (get) Token: 0x06002015 RID: 8213 RVA: 0x0018CD00 File Offset: 0x0018AF00
		' (set) Token: 0x06002016 RID: 8214 RVA: 0x00006918 File Offset: 0x00004B18
		Friend Overridable Property txtRight As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtRight
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtRight = value
			End Set
		End Property

		' Token: 0x17000B13 RID: 2835
		' (get) Token: 0x06002017 RID: 8215 RVA: 0x0018CD18 File Offset: 0x0018AF18
		' (set) Token: 0x06002018 RID: 8216 RVA: 0x00006922 File Offset: 0x00004B22
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x17000B14 RID: 2836
		' (get) Token: 0x06002019 RID: 8217 RVA: 0x0018CD30 File Offset: 0x0018AF30
		' (set) Token: 0x0600201A RID: 8218 RVA: 0x0000692C File Offset: 0x00004B2C
		Friend Overridable Property txtBottom As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBottom
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtBottom = value
			End Set
		End Property

		' Token: 0x17000B15 RID: 2837
		' (get) Token: 0x0600201B RID: 8219 RVA: 0x0018CD48 File Offset: 0x0018AF48
		' (set) Token: 0x0600201C RID: 8220 RVA: 0x00006936 File Offset: 0x00004B36
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x17000B16 RID: 2838
		' (get) Token: 0x0600201D RID: 8221 RVA: 0x0018CD60 File Offset: 0x0018AF60
		' (set) Token: 0x0600201E RID: 8222 RVA: 0x00006940 File Offset: 0x00004B40
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x17000B17 RID: 2839
		' (get) Token: 0x0600201F RID: 8223 RVA: 0x0018CD78 File Offset: 0x0018AF78
		' (set) Token: 0x06002020 RID: 8224 RVA: 0x0000694A File Offset: 0x00004B4A
		Friend Overridable Property Label6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label6 = value
			End Set
		End Property

		' Token: 0x17000B18 RID: 2840
		' (get) Token: 0x06002021 RID: 8225 RVA: 0x0018CD90 File Offset: 0x0018AF90
		' (set) Token: 0x06002022 RID: 8226 RVA: 0x00006954 File Offset: 0x00004B54
		Friend Overridable Property Label7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		' Token: 0x17000B19 RID: 2841
		' (get) Token: 0x06002023 RID: 8227 RVA: 0x0018CDA8 File Offset: 0x0018AFA8
		' (set) Token: 0x06002024 RID: 8228 RVA: 0x0000695E File Offset: 0x00004B5E
		Friend Overridable Property Label8 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label8 = value
			End Set
		End Property

		' Token: 0x17000B1A RID: 2842
		' (get) Token: 0x06002025 RID: 8229 RVA: 0x0018CDC0 File Offset: 0x0018AFC0
		' (set) Token: 0x06002026 RID: 8230 RVA: 0x00006968 File Offset: 0x00004B68
		Friend Overridable Property lblMargin As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMargin
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMargin = value
			End Set
		End Property

		' Token: 0x17000B1B RID: 2843
		' (get) Token: 0x06002027 RID: 8231 RVA: 0x0018CDD8 File Offset: 0x0018AFD8
		' (set) Token: 0x06002028 RID: 8232 RVA: 0x0018CDF0 File Offset: 0x0018AFF0
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x06002029 RID: 8233
		Public Declare Function AddFontResource Lib "gdi32" (lpFileName As String) As Integer

		' Token: 0x0600202A RID: 8234
		Public Declare Function SendMessage Lib "user32.dll" (hWnd As Integer, Msg As UInteger, wParam As Integer, lParam As Integer) As Integer

		' Token: 0x0600202B RID: 8235
		Public Declare Function WriteProfileString Lib "kernel32.dll" (lpszSection As String, lpszKeyName As String, lpszString As String) As Integer

		' Token: 0x17000B1C RID: 2844
		' (get) Token: 0x0600202C RID: 8236 RVA: 0x0018CE5C File Offset: 0x0018B05C
		' (set) Token: 0x0600202D RID: 8237 RVA: 0x00006972 File Offset: 0x00004B72
		Public Property pStrMAY As String
			Get
				Return Me.mstrMAY
			End Get
			Set(value As String)
				Me.mstrMAY = value
			End Set
		End Property

		' Token: 0x17000B1D RID: 2845
		' (get) Token: 0x0600202E RID: 8238 RVA: 0x0018CE74 File Offset: 0x0018B074
		' (set) Token: 0x0600202F RID: 8239 RVA: 0x0000697D File Offset: 0x00004B7D
		Public Property pStrLoaiMayin As String
			Get
				Return Me.mstrLoaiMayIn
			End Get
			Set(value As String)
				Me.mstrLoaiMayIn = value
			End Set
		End Property

		' Token: 0x17000B1E RID: 2846
		' (get) Token: 0x06002030 RID: 8240 RVA: 0x0018CE8C File Offset: 0x0018B08C
		' (set) Token: 0x06002031 RID: 8241 RVA: 0x00006988 File Offset: 0x00004B88
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000B1F RID: 2847
		' (get) Token: 0x06002032 RID: 8242 RVA: 0x0018CEA4 File Offset: 0x0018B0A4
		' (set) Token: 0x06002033 RID: 8243 RVA: 0x00006993 File Offset: 0x00004B93
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000B20 RID: 2848
		' (get) Token: 0x06002034 RID: 8244 RVA: 0x0018CEBC File Offset: 0x0018B0BC
		' (set) Token: 0x06002035 RID: 8245 RVA: 0x0000699E File Offset: 0x00004B9E
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06002036 RID: 8246 RVA: 0x0018CED4 File Offset: 0x0018B0D4
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002037 RID: 8247 RVA: 0x0018CF80 File Offset: 0x0018B180
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002038 RID: 8248 RVA: 0x0018D028 File Offset: 0x0018B228
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.txtMAMAY.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002039 RID: 8249 RVA: 0x0018D0D4 File Offset: 0x0018B2D4
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbLoaiMayIn.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600203A RID: 8250 RVA: 0x0018D178 File Offset: 0x0018B378
		Private Sub txtMAMAY_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMAMAY.[ReadOnly]
				If [readOnly] Then
					Me.txtTimeOut.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600203B RID: 8251 RVA: 0x0018D224 File Offset: 0x0018B424
		Private Sub txtMAMAY_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbCOMName.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600203C RID: 8252 RVA: 0x0018D2C8 File Offset: 0x0018B4C8
		Private Sub cmbCOMName_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbBaudrate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCOMName_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600203D RID: 8253 RVA: 0x0018D36C File Offset: 0x0018B56C
		Private Sub cmbBaudrate_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbDataBit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbBaudrate_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600203E RID: 8254 RVA: 0x0018D410 File Offset: 0x0018B610
		Private Sub cmbDataBit_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbParityBit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbDataBit_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600203F RID: 8255 RVA: 0x0018D4B4 File Offset: 0x0018B6B4
		Private Sub cmbParityBit_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbStopBit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbParityBit_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002040 RID: 8256 RVA: 0x0018D558 File Offset: 0x0018B758
		Private Sub cmbLoaiMayIn_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkLOPENDRAWERTAMTINH.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbLoaiMayIn_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002041 RID: 8257 RVA: 0x0018D5FC File Offset: 0x0018B7FC
		Private Sub chkLOPENDRAWER_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtRemark.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkLOPENDRAWER_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002042 RID: 8258 RVA: 0x0018D6A0 File Offset: 0x0018B8A0
		Private Sub chkDungChung_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMAMAY.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkDungChung_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002043 RID: 8259 RVA: 0x0018D744 File Offset: 0x0018B944
		Private Sub cmbStopBit_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbFlowControl.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbStopBit_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002044 RID: 8260 RVA: 0x0018D7E8 File Offset: 0x0018B9E8
		Private Sub cmbFlowControl_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtTimeOut.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbFlowControl_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002045 RID: 8261 RVA: 0x0018D88C File Offset: 0x0018BA8C
		Private Sub txtTimeOut_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTimeOut.[ReadOnly]
				If [readOnly] Then
					Me.txtPrintCount.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTimeOut_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002046 RID: 8262 RVA: 0x0018D938 File Offset: 0x0018BB38
		Private Sub txtTimeOut_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txtPrintCount.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTimeOut_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002047 RID: 8263 RVA: 0x0018DAD4 File Offset: 0x0018BCD4
		Private Sub txtPrintCount_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtPrintCount.[ReadOnly]
				If [readOnly] Then
					Me.txtRemark.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002048 RID: 8264 RVA: 0x0018DB80 File Offset: 0x0018BD80
		Private Sub txtPrintCount_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txtRemark.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkLOPENDRAWER.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002049 RID: 8265 RVA: 0x0018DD3C File Offset: 0x0018BF3C
		Private Sub txtRemark_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtRemark.[ReadOnly]
				If [readOnly] Then
					Me.btnDelete.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600204A RID: 8266 RVA: 0x0018DDE8 File Offset: 0x0018BFE8
		Private Sub frmDMMAYINHD2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAYINHD2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600204B RID: 8267 RVA: 0x0018DE94 File Offset: 0x0018C094
		Private Sub btnSECLECTMAYCALL_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAY As frmDMMAY1 = New frmDMMAY1()
				frmDMMAY.pBytOpen_From_Menu = 7
				frmDMMAY.btnSelect.Visible = True
				frmDMMAY.ShowDialog()
				Me.TxtMAMAYCALL.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAY.pStrOBJID, "", False) = 0, Me.TxtMAMAYCALL.Text, frmDMMAY.pStrOBJID))
				Me.txtTENMAYCALL.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAY.pStrOBJID, "", False) = 0, Me.txtTENMAYCALL.Text, frmDMMAY.pStrOBJNAME))
				frmDMMAY.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMNH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600204C RID: 8268 RVA: 0x0018DFDC File Offset: 0x0018C1DC
		Private Sub TxtMAMAYCALL_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMMAY Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMMAY.Columns("OBJID")
					Me.mclsTbDMMAY.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMMAY.Rows.Find(Strings.Trim(Me.TxtMAMAYCALL.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENMAYCALL.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENMAYCALL.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600204D RID: 8269 RVA: 0x0018E130 File Offset: 0x0018C330
		Private Sub frmDMMAYINHD2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMMAY()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMLOAIMAYIN()
				End If
				Me.fGetData_4ComboBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAYINHD2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600204E RID: 8270 RVA: 0x0018E208 File Offset: 0x0018C408
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = Operators.CompareString(Strings.Trim(Me.txtMAMAY.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(41), MsgBoxStyle.Critical, Nothing)
							Me.txtMAMAY.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.txtMAMAY.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENMAY.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(42), MsgBoxStyle.Critical, Nothing)
								Me.txtMAMAY.Focus()
							Else
								flag = Operators.CompareString(Strings.Trim(Me.TxtMAMAYCALL.Text), "", False) = 0
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(41), MsgBoxStyle.Critical, Nothing)
									Me.TxtMAMAYCALL.Focus()
								Else
									flag = (Operators.CompareString(Strings.Trim(Me.TxtMAMAYCALL.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENMAYCALL.Text), "", False) = 0)
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(42), MsgBoxStyle.Critical, Nothing)
										Me.TxtMAMAYCALL.Focus()
									Else
										flag = Me.cmbCOMName.Visible
										Dim flag2 As Boolean
										If flag Then
											flag2 = Operators.CompareString(Strings.Trim(Me.cmbCOMName.Text), "", False) = 0
											If flag2 Then
												Interaction.MsgBox(Me.mArrStrFrmMess(43), MsgBoxStyle.Critical, Nothing)
												Me.cmbCOMName.Focus()
												Return
											End If
										End If
										flag2 = Me.cmbBaudrate.Visible
										If flag2 Then
											flag = Operators.CompareString(Strings.Trim(Me.cmbBaudrate.Text), "", False) = 0
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(44), MsgBoxStyle.Critical, Nothing)
												Me.cmbBaudrate.Focus()
												Return
											End If
										End If
										flag2 = Me.cmbDataBit.Visible
										If flag2 Then
											flag = Operators.CompareString(Strings.Trim(Me.cmbDataBit.Text), "", False) = 0
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(45), MsgBoxStyle.Critical, Nothing)
												Me.cmbDataBit.Focus()
												Return
											End If
										End If
										flag2 = Me.cmbParityBit.Visible
										If flag2 Then
											flag = Operators.CompareString(Strings.Trim(Me.cmbParityBit.Text), "", False) = 0
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(46), MsgBoxStyle.Critical, Nothing)
												Me.cmbParityBit.Focus()
												Return
											End If
										End If
										flag2 = Me.cmbStopBit.Visible
										If flag2 Then
											flag = Operators.CompareString(Strings.Trim(Me.cmbStopBit.Text), "", False) = 0
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(47), MsgBoxStyle.Critical, Nothing)
												Me.cmbStopBit.Focus()
												Return
											End If
										End If
										flag2 = Me.cmbFlowControl.Visible
										If flag2 Then
											flag = Operators.CompareString(Strings.Trim(Me.cmbFlowControl.Text), "", False) = 0
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(48), MsgBoxStyle.Critical, Nothing)
												Me.cmbFlowControl.Focus()
												Return
											End If
										End If
										flag2 = Operators.CompareString(Strings.Trim(Me.txtPrintCount.Text), "", False) = 0
										If flag2 Then
											Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
											Me.txtPrintCount.Focus()
										Else
											flag2 = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
											If flag2 Then
												Me.mbytSuccess = Me.fAddNew()
											Else
												flag2 = Me.mbytFormStatus = 3
												If flag2 Then
													Me.mbytSuccess = Me.fModify()
												End If
											End If
											flag2 = Me.mbytSuccess = 1
											If flag2 Then
												Me.Close()
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600204F RID: 8271 RVA: 0x0018E744 File Offset: 0x0018C944
		Private Sub cmbLoaiMayIn_SelectedValueChanged(sender As Object, e As EventArgs)
			Try
				Dim text As String = Me.cmbLoaiMayIn.SelectedValue.ToString()
				Dim flag As Boolean
				If Operators.CompareString(text, "0", False) <> 0 AndAlso Operators.CompareString(text, "1", False) <> 0 Then
					If Operators.CompareString(text, "2", False) <> 0 Then
						flag = False
						GoTo IL_0048
					End If
				End If
				flag = True
				IL_0048:
				Dim flag2 As Boolean = flag
				If flag2 Then
					Me.sDisable(True)
				Else
					Dim flag3 As Boolean
					If Operators.CompareString(text, "3", False) <> 0 AndAlso Operators.CompareString(text, "4", False) <> 0 Then
						If Operators.CompareString(text, "5", False) <> 0 Then
							If Operators.CompareString(text, "6", False) <> 0 Then
								If Operators.CompareString(text, "7", False) <> 0 Then
									If Operators.CompareString(text, "8", False) <> 0 Then
										If Operators.CompareString(text, "9", False) <> 0 Then
											If Operators.CompareString(text, "10", False) <> 0 Then
												If Operators.CompareString(text, "11", False) <> 0 Then
													If Operators.CompareString(text, "12", False) <> 0 Then
														If Operators.CompareString(text, "13", False) <> 0 Then
															If Operators.CompareString(text, "14", False) <> 0 Then
																If Operators.CompareString(text, "15", False) <> 0 Then
																	If Operators.CompareString(text, "16", False) <> 0 Then
																		If Operators.CompareString(text, "17", False) <> 0 Then
																			If Operators.CompareString(text, "18", False) <> 0 Then
																				If Operators.CompareString(text, "19", False) <> 0 Then
																					If Operators.CompareString(text, "20", False) <> 0 Then
																						If Operators.CompareString(text, "21", False) <> 0 Then
																							If Operators.CompareString(text, "22", False) <> 0 Then
																								If Operators.CompareString(text, "23", False) <> 0 Then
																									If Operators.CompareString(text, "24", False) <> 0 Then
																										flag3 = False
																										GoTo IL_01D0
																									End If
																								End If
																							End If
																						End If
																					End If
																				End If
																			End If
																		End If
																	End If
																End If
															End If
														End If
													End If
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
					flag3 = True
					IL_01D0:
					flag2 = flag3
					If flag2 Then
						Me.sDisable(False)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbLoaiMayIn_SelectedValueChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002050 RID: 8272 RVA: 0x0018E9B0 File Offset: 0x0018CBB0
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002051 RID: 8273 RVA: 0x0018EA54 File Offset: 0x0018CC54
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAMAY.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMAY like '%"), text2), "%'"))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbCOMName.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " COMNAME like '%"), text2), "%'"))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbBaudrate.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " BAUDRATE = "), text2))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbDataBit.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " DATABITS = "), text2))
				End If
				text2 = Conversions.ToString(Interaction.IIf(Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex))) < 0, "", Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex))))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " PARITYBITS = "), text2))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbStopBit.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " STOPBITS = "), text2))
				End If
				text2 = Conversions.ToString(Interaction.IIf(Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex))) < 0, "", Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex))))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FLOWCONTROL = "), text2))
				End If
				text2 = Strings.Trim(Me.txtTimeOut.Text)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TIMEOUT = "), text2))
				End If
				text2 = Strings.Trim(Me.txtPrintCount.Text)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " PRINTCOUNT = "), text2))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtRemark.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Conversions.ToString(Me.cmbLoaiMayIn.SelectedValue)), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " KIND = "), text2), ""))
				End If
				flag = Me.chkLOPENDRAWERTAMTINH.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LOPENDRAWERTAMTINH = "), Me.chkLOPENDRAWERTAMTINH.Checked), ""))
				End If
				flag = Me.chkLOPENDRAWER.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LOPENDRAWER = "), Me.chkLOPENDRAWER.Checked), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002052 RID: 8274 RVA: 0x0018F13C File Offset: 0x0018D33C
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAMAY.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMAY like '%"), text2), "%'"))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbCOMName.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " COMNAME like '%"), text2), "%'"))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbBaudrate.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " BAUDRATE = "), text2))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbDataBit.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " DATABITS = "), text2))
				End If
				text2 = Conversions.ToString(Interaction.IIf(Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex))) < 0, "", Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex))))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " PARITYBITS = "), text2))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbStopBit.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " STOPBITS = "), text2))
				End If
				text2 = Conversions.ToString(Interaction.IIf(Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex))) < 0, "", Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex))))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FLOWCONTROL = "), text2))
				End If
				text2 = Strings.Trim(Me.txtTimeOut.Text)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TIMEOUT = "), text2))
				End If
				text2 = Strings.Trim(Me.txtPrintCount.Text)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " PRINTCOUNT = "), text2))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtRemark.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Conversions.ToString(Me.cmbLoaiMayIn.SelectedValue)), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " KIND = "), text2), ""))
				End If
				flag = Me.chkLOPENDRAWERTAMTINH.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LOPENDRAWERTAMTINH = "), Me.chkLOPENDRAWERTAMTINH.Checked), ""))
				End If
				flag = Me.chkLOPENDRAWER.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LOPENDRAWER = "), Me.chkLOPENDRAWER.Checked), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002053 RID: 8275 RVA: 0x0018F824 File Offset: 0x0018DA24
		Private Sub btnDMMAY_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAY As frmDMMAY1 = New frmDMMAY1()
				frmDMMAY.pBytOpen_From_Menu = 7
				frmDMMAY.btnSelect.Visible = True
				frmDMMAY.ShowDialog()
				Me.txtMAMAY.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAY.pStrOBJID, "", False) = 0, Me.txtMAMAY.Text, frmDMMAY.pStrOBJID))
				Me.txtTENMAY.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAY.pStrOBJID, "", False) = 0, Me.txtTENMAY.Text, frmDMMAY.pStrOBJNAME))
				frmDMMAY.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMNH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002054 RID: 8276 RVA: 0x0018F96C File Offset: 0x0018DB6C
		Private Sub txtMAMAY_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMMAY Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMMAY.Columns("OBJID")
					Me.mclsTbDMMAY.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMMAY.Rows.Find(Strings.Trim(Me.txtMAMAY.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENMAY.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENMAY.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002055 RID: 8277 RVA: 0x0018FAC0 File Offset: 0x0018DCC0
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.cmbLoaiMayIn.SelectedValue = Me.mstrLoaiMayIn
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.cmbBaudrate.Enabled = False
						Me.cmbCOMName.Enabled = False
						Me.cmbDataBit.Enabled = False
						Me.cmbParityBit.Enabled = False
						Me.cmbStopBit.Enabled = False
						Me.cmbFlowControl.Enabled = False
						Me.cmbLoaiMayIn.SelectedValue = Me.mstrLoaiMayIn
						Me.cmbLoaiMayIn.Enabled = False
						Me.chkLOPENDRAWERTAMTINH.Enabled = False
						Me.chkLOPENDRAWER.Enabled = False
						Me.txtTimeOut.[ReadOnly] = True
						Me.txtPrintCount.[ReadOnly] = True
						Me.txtRemark.[ReadOnly] = True
						Me.txtMAMAY.[ReadOnly] = True
						Me.TxtMAMAYCALL.[ReadOnly] = True
						Me.txtPrintWidth.[ReadOnly] = True
						Me.txtTOP.[ReadOnly] = True
						Me.txtLEFT.[ReadOnly] = True
						Me.txtRight.[ReadOnly] = True
						Me.txtBottom.[ReadOnly] = True
						Me.btnDMMAY.Enabled = False
						Me.btnSECLECTMAYCALL.Enabled = False
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.BackColor = Me.txtColor.BackColor
						Me.cmbBaudrate.BackColor = Me.txtColor.BackColor
						Me.cmbCOMName.BackColor = Me.txtColor.BackColor
						Me.cmbDataBit.BackColor = Me.txtColor.BackColor
						Me.cmbParityBit.BackColor = Me.txtColor.BackColor
						Me.cmbStopBit.BackColor = Me.txtColor.BackColor
						Me.cmbFlowControl.BackColor = Me.txtColor.BackColor
						Me.cmbLoaiMayIn.BackColor = Me.txtColor.BackColor
						Me.txtTimeOut.BackColor = Me.txtColor.BackColor
						Me.txtPrintCount.BackColor = Me.txtColor.BackColor
						Me.txtRemark.BackColor = Me.txtColor.BackColor
						Me.txtMAMAY.BackColor = Me.txtColor.BackColor
						Me.TxtMAMAYCALL.BackColor = Me.txtColor.BackColor
						Me.txtPrintWidth.BackColor = Me.txtColor.BackColor
						Me.txtTOP.BackColor = Me.txtColor.BackColor
						Me.txtLEFT.BackColor = Me.txtColor.BackColor
						Me.txtBottom.BackColor = Me.txtColor.BackColor
						Me.txtRight.BackColor = Me.txtColor.BackColor
					Case 5, 6
						Me.chkLOPENDRAWERTAMTINH.CheckState = CheckState.Indeterminate
						Me.chkLOPENDRAWER.CheckState = CheckState.Indeterminate
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002056 RID: 8278 RVA: 0x0018FEF0 File Offset: 0x0018E0F0
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002057 RID: 8279 RVA: 0x00190080 File Offset: 0x0018E280
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				Dim array As String() = New String() { Me.mArrStrFrmMess(51), Me.mArrStrFrmMess(52), Me.mArrStrFrmMess(53), Me.mArrStrFrmMess(54), Me.mArrStrFrmMess(55) }
				Dim array2 As String() = New String() { Me.mArrStrFrmMess(76), Me.mArrStrFrmMess(77), Me.mArrStrFrmMess(78), Me.mArrStrFrmMess(79) }
				Dim array3 As String() = New String() { Me.mArrStrFrmMess(80), Me.mArrStrFrmMess(81), Me.mArrStrFrmMess(82), Me.mArrStrFrmMess(83), Me.mArrStrFrmMess(84) }
				Dim array4 As String() = New String() { Me.mArrStrFrmMess(85), Me.mArrStrFrmMess(86), Me.mArrStrFrmMess(87) }
				Dim array5 As String() = New String() { Me.mArrStrFrmMess(88), Me.mArrStrFrmMess(89), Me.mArrStrFrmMess(90) }
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 5
				Me.txtOBJNAME.MaxLength = 50
				Me.txtMAMAY.MaxLength = 5
				Me.txtCOMName.MaxLength = 10
				Me.txtRemark.MaxLength = 200
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				Me.cmbBaudrate.DataSource = array
				Dim flag As Boolean = SerialPort.GetPortNames() <> Nothing
				If flag Then
					Me.cmbCOMName.DataSource = SerialPort.GetPortNames()
				End If
				Me.cmbDataBit.DataSource = array2
				Me.cmbParityBit.DataSource = array3
				Me.cmbStopBit.DataSource = array4
				Me.cmbFlowControl.DataSource = array5
				Me.cmbBaudrate.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbCOMName.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbDataBit.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbParityBit.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbStopBit.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbFlowControl.DropDownStyle = ComboBoxStyle.DropDownList
				Select Case Me.mbytFormStatus
					Case 1
						Me.cmbBaudrate.SelectedIndex = 3
						flag = Me.cmbCOMName.Items.Count > 0
						If flag Then
							Me.cmbCOMName.SelectedIndex = 0
						End If
						Me.cmbDataBit.SelectedIndex = 3
						Me.cmbParityBit.SelectedIndex = 0
						Me.cmbStopBit.SelectedIndex = 0
						Me.cmbFlowControl.SelectedIndex = 0
						Me.txtTimeOut.Text = Conversions.ToString(0)
						Me.txtPrintCount.Text = Conversions.ToString(1)
					Case 2, 3, 4
						Me.cmbBaudrate.SelectedItem = Strings.Trim(Me.txtBaudrate.Text)
						Me.cmbCOMName.SelectedItem = Strings.Trim(Me.txtCOMName.Text)
						Me.cmbDataBit.SelectedItem = Strings.Trim(Me.txtDataBit.Text)
						Me.cmbParityBit.SelectedIndex = Conversions.ToInteger(Strings.Trim(Me.txtParityBit.Text))
						Me.cmbStopBit.SelectedItem = Strings.Trim(Me.txtStopBit.Text)
						Me.cmbFlowControl.SelectedIndex = Conversions.ToInteger(Strings.Trim(Me.txtFlowControl.Text))
					Case 5, 6
						Me.cmbBaudrate.SelectedIndex = -1
						Me.cmbCOMName.SelectedIndex = -1
						Me.cmbDataBit.SelectedIndex = -1
						Me.cmbParityBit.SelectedIndex = -1
						Me.cmbStopBit.SelectedIndex = -1
						Me.cmbFlowControl.SelectedIndex = -1
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002058 RID: 8280 RVA: 0x00190570 File Offset: 0x0018E770
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
					Me.lblComputer.Tag = "CB0031"
					Me.lblCOMName.Tag = "CB0032"
					Me.lblBaudrate.Tag = "CB0033"
					Me.lblDataBit.Tag = "CB0034"
					Me.lblParityBit.Tag = "CB0035"
					Me.lblStopBit.Tag = "CB00361"
					Me.lblFlowControl.Tag = "CB0037"
					Me.lblPrintCount.Tag = "CB0039"
					Me.LblMAMAYTINHCALL.Tag = "CB0105"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002059 RID: 8281 RVA: 0x001907F0 File Offset: 0x0018E9F0
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMMAY.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600205A RID: 8282 RVA: 0x0019089C File Offset: 0x0018EA9C
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(23) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAMAY"
				array(2).Value = Strings.Trim(Me.txtMAMAY.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchCOMName"
				array(3).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Not Me.cmbCOMName.Visible, "", Strings.Trim(Conversions.ToString(Me.cmbCOMName.SelectedItem))))
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@prelStopBits"
				array(4).Value = Conversions.ToDouble(Strings.Trim(Conversions.ToString(Me.cmbStopBit.SelectedItem)))
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pintBaudrate"
				array(5).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbBaudrate.SelectedItem)))
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@ptniDataBits"
				array(6).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbDataBit.SelectedItem)))
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@ptniFlowControl"
				array(7).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex)))
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pintTimeOut"
				array(8).Value = Strings.Trim(Me.txtTimeOut.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@ptniPrintCount"
				array(9).Value = Conversions.ToInteger(Strings.Trim(Me.txtPrintCount.Text))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@ptniParityBits"
				array(10).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex)))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pnvcRemark"
				array(11).Value = Strings.Trim(Me.txtRemark.Text)
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@ptniKIND"
				array(12).Value = Strings.Trim(Conversions.ToString(Me.cmbLoaiMayIn.SelectedValue))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pbitLSHARE"
				array(13).Value = 0
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitLOPENDRAWER"
				array(14).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLOPENDRAWER.Checked, 1, 0))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pnchMAMAYCALL"
				array(15).Value = Me.TxtMAMAYCALL.Text.Trim()
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@tniPRINTWIDTH"
				array(16).Value = Conversion.Val(Me.txtPrintWidth.Text.Trim())
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@decTOPMARGIN"
				array(17).Value = Conversion.Val(Me.txtTOP.Text.Trim())
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@decLEFTMARGIN"
				array(18).Value = Conversion.Val(Me.txtLEFT.Text.Trim())
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@decBOTTOMMARGIN"
				array(19).Value = Conversion.Val(Me.txtBottom.Text.Trim())
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@decRIGHTMARGIN"
				array(20).Value = Conversion.Val(Me.txtRight.Text.Trim())
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pbitLOPENDRAWERTAMTINH"
				array(22).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLOPENDRAWERTAMTINH.Checked, 1, 0))
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@int_Result"
				array(21).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAYINHD_INSERT_DMMAYINHD", flag)
				Dim num As Integer = Conversions.ToInteger(array(21).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(100), MsgBoxStyle.Critical, Nothing)
							Me.cmbCOMName.Focus()
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
							Me.txtOBJID.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600205B RID: 8283 RVA: 0x00190FC8 File Offset: 0x0018F1C8
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(23) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAMAY"
				array(2).Value = Strings.Trim(Me.txtMAMAY.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchCOMName"
				array(3).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Not Me.cmbCOMName.Visible, "", Strings.Trim(Conversions.ToString(Me.cmbCOMName.SelectedItem))))
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@prelStopBits"
				array(4).Value = Strings.Trim(Conversions.ToString(Me.cmbStopBit.SelectedItem))
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pintBaudrate"
				array(5).Value = Strings.Trim(Conversions.ToString(Me.cmbBaudrate.SelectedItem))
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@ptniDataBits"
				array(6).Value = Strings.Trim(Conversions.ToString(Me.cmbDataBit.SelectedItem))
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@ptniFlowControl"
				array(7).Value = Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex))
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pintTimeOut"
				array(8).Value = Strings.Trim(Me.txtTimeOut.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@ptniPrintCount"
				array(9).Value = Strings.Trim(Me.txtPrintCount.Text)
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@ptniParityBits"
				array(10).Value = Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pnvcRemark"
				array(11).Value = Strings.Trim(Me.txtRemark.Text)
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@ptniKIND"
				array(12).Value = Strings.Trim(Conversions.ToString(Me.cmbLoaiMayIn.SelectedValue))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pbitLSHARE"
				array(13).Value = 0
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitLOPENDRAWER"
				array(14).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLOPENDRAWER.Checked, 1, 0))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pnchMAMAYCALL"
				array(15).Value = Me.TxtMAMAYCALL.Text.Trim()
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@tniPRINTWIDTH"
				array(16).Value = Conversion.Val(Me.txtPrintWidth.Text.Trim())
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@decTOPMARGIN"
				array(17).Value = Conversion.Val(Me.txtTOP.Text.Trim())
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@decLEFTMARGIN"
				array(18).Value = Conversion.Val(Me.txtLEFT.Text.Trim())
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@decBOTTOMMARGIN"
				array(19).Value = Conversion.Val(Me.txtBottom.Text.Trim())
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@decRIGHTMARGIN"
				array(20).Value = Conversion.Val(Me.txtRight.Text.Trim())
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pbitLOPENDRAWERTAMTINH"
				array(22).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLOPENDRAWERTAMTINH.Checked, 1, 0))
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@int_Result"
				array(21).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAYINHD_UPDATE_DMMAYINHD", flag)
				Dim num As Integer = Conversions.ToInteger(array(21).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(100), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600205C RID: 8284 RVA: 0x0019169C File Offset: 0x0018F89C
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAYINHD_DEL_DMMAYINHD", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600205D RID: 8285 RVA: 0x00191860 File Offset: 0x0018FA60
		Private Function fGetData_DMMAY() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMMAY = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMAY")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMMAY ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600205E RID: 8286 RVA: 0x0019190C File Offset: 0x0018FB0C
		Private Function fGetData_DMLOAIMAYIN() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mTbLOAIMAYIN.Columns.Add("OBJID")
				Me.mTbLOAIMAYIN.Columns.Add("OBJNAME")
				Dim flag As Boolean = (Me.mbytFormStatus = 6) Or (Me.mbytFormStatus = 5)
				If flag Then
					Me.mTbLOAIMAYIN.Rows.Add(New Object() { "", "" })
				End If
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "0", Me.mArrStrFrmMess(93) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "1", Me.mArrStrFrmMess(94) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "2", Me.mArrStrFrmMess(95) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "3", Me.mArrStrFrmMess(96) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "4", Me.mArrStrFrmMess(97) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "5", Me.mArrStrFrmMess(98) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "6", Me.mArrStrFrmMess(99) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "7", Me.mArrStrFrmMess(102) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "8", Me.mArrStrFrmMess(110) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "9", Me.mArrStrFrmMess(111) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "10", Me.mArrStrFrmMess(112) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "11", Me.mArrStrFrmMess(113) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "12", Me.mArrStrFrmMess(114) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "13", Me.mArrStrFrmMess(115) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "14", Me.mArrStrFrmMess(116) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "15", Me.mArrStrFrmMess(117) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "16", Me.mArrStrFrmMess(118) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "17", Me.mArrStrFrmMess(119) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "18", Me.mArrStrFrmMess(120) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "19", Me.mArrStrFrmMess(121) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "20", Me.mArrStrFrmMess(122) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "21", Me.mArrStrFrmMess(123) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "22", Me.mArrStrFrmMess(124) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "23", Me.mArrStrFrmMess(125) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "24", Me.mArrStrFrmMess(126) })
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMLOAIMAYIN ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600205F RID: 8287 RVA: 0x00191EC4 File Offset: 0x001900C4
		Private Function fGetData_4ComboBox() As Byte
			Try
				Dim cmbLoaiMayIn As ComboBox = Me.cmbLoaiMayIn
				cmbLoaiMayIn.DataSource = Me.mTbLOAIMAYIN
				cmbLoaiMayIn.DisplayMember = "OBJNAME"
				cmbLoaiMayIn.ValueMember = "OBJID"
				cmbLoaiMayIn.SelectedIndex = Conversions.ToInteger(Me.pStrLoaiMayin)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4ComboBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Dim b As Byte
			Return b
		End Function

		' Token: 0x06002060 RID: 8288 RVA: 0x00191F98 File Offset: 0x00190198
		Private Sub sDisable(pblnValue As Boolean)
			Try
				Me.lblCOMName.Visible = pblnValue
				Me.cmbCOMName.Visible = pblnValue
				Me.lblBaudrate.Visible = pblnValue
				Me.cmbBaudrate.Visible = pblnValue
				Me.lblDataBit.Visible = pblnValue
				Me.cmbDataBit.Visible = pblnValue
				Me.lblParityBit.Visible = pblnValue
				Me.cmbParityBit.Visible = pblnValue
				Me.lblStopBit.Visible = pblnValue
				Me.cmbStopBit.Visible = pblnValue
				Me.lblFlowControl.Visible = pblnValue
				Me.cmbFlowControl.Visible = pblnValue
				Me.lblTimeOut.Visible = pblnValue
				Me.txtTimeOut.Visible = pblnValue
				Me.txtPrintWidth.Visible = pblnValue
				Me.lblPrintW.Visible = pblnValue
				Me.txtTOP.Visible = Not pblnValue
				Me.txtLEFT.Visible = Not pblnValue
				Me.txtBottom.Visible = Not pblnValue
				Me.txtRight.Visible = Not pblnValue
				Me.lblMargin.Visible = Not pblnValue
				Me.Label1.Visible = Not pblnValue
				Me.Label2.Visible = Not pblnValue
				Me.Label4.Visible = Not pblnValue
				Me.Label3.Visible = Not pblnValue
				Me.Label5.Visible = Not pblnValue
				Me.Label6.Visible = Not pblnValue
				Me.Label7.Visible = Not pblnValue
				Me.Label8.Visible = Not pblnValue
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sDisable ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06002061 RID: 8289 RVA: 0x001921C8 File Offset: 0x001903C8
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x06002062 RID: 8290 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x04000CF3 RID: 3315
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000CF5 RID: 3317
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000CF6 RID: 3318
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000CF7 RID: 3319
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000CF8 RID: 3320
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000CF9 RID: 3321
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000CFA RID: 3322
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000CFB RID: 3323
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000CFC RID: 3324
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000CFD RID: 3325
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000CFE RID: 3326
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000CFF RID: 3327
		<AccessedThroughProperty("lblTimeOut")>
		Private _lblTimeOut As Label

		' Token: 0x04000D00 RID: 3328
		<AccessedThroughProperty("lblPrintCount")>
		Private _lblPrintCount As Label

		' Token: 0x04000D01 RID: 3329
		<AccessedThroughProperty("lblComputer")>
		Private _lblComputer As Label

		' Token: 0x04000D02 RID: 3330
		<AccessedThroughProperty("txtCOMName")>
		Private _txtCOMName As TextBox

		' Token: 0x04000D03 RID: 3331
		<AccessedThroughProperty("txtBaudrate")>
		Private _txtBaudrate As TextBox

		' Token: 0x04000D04 RID: 3332
		<AccessedThroughProperty("txtDataBit")>
		Private _txtDataBit As TextBox

		' Token: 0x04000D05 RID: 3333
		<AccessedThroughProperty("txtParityBit")>
		Private _txtParityBit As TextBox

		' Token: 0x04000D06 RID: 3334
		<AccessedThroughProperty("txtStopBit")>
		Private _txtStopBit As TextBox

		' Token: 0x04000D07 RID: 3335
		<AccessedThroughProperty("txtFlowControl")>
		Private _txtFlowControl As TextBox

		' Token: 0x04000D08 RID: 3336
		<AccessedThroughProperty("txtTimeOut")>
		Private _txtTimeOut As TextBox

		' Token: 0x04000D09 RID: 3337
		<AccessedThroughProperty("txtPrintCount")>
		Private _txtPrintCount As TextBox

		' Token: 0x04000D0A RID: 3338
		<AccessedThroughProperty("lblCOMName")>
		Private _lblCOMName As Label

		' Token: 0x04000D0B RID: 3339
		<AccessedThroughProperty("lblBaudrate")>
		Private _lblBaudrate As Label

		' Token: 0x04000D0C RID: 3340
		<AccessedThroughProperty("lblDataBit")>
		Private _lblDataBit As Label

		' Token: 0x04000D0D RID: 3341
		<AccessedThroughProperty("lblParityBit")>
		Private _lblParityBit As Label

		' Token: 0x04000D0E RID: 3342
		<AccessedThroughProperty("lblStopBit")>
		Private _lblStopBit As Label

		' Token: 0x04000D0F RID: 3343
		<AccessedThroughProperty("lblFlowControl")>
		Private _lblFlowControl As Label

		' Token: 0x04000D10 RID: 3344
		<AccessedThroughProperty("txtColor")>
		Private _txtColor As TextBox

		' Token: 0x04000D11 RID: 3345
		<AccessedThroughProperty("txtRemark")>
		Private _txtRemark As TextBox

		' Token: 0x04000D12 RID: 3346
		<AccessedThroughProperty("lblRemark")>
		Private _lblRemark As Label

		' Token: 0x04000D13 RID: 3347
		<AccessedThroughProperty("txtTENMAY")>
		Private _txtTENMAY As TextBox

		' Token: 0x04000D14 RID: 3348
		<AccessedThroughProperty("txtMAMAY")>
		Private _txtMAMAY As TextBox

		' Token: 0x04000D15 RID: 3349
		<AccessedThroughProperty("btnDMMAY")>
		Private _btnDMMAY As Button

		' Token: 0x04000D16 RID: 3350
		<AccessedThroughProperty("cmbBaudrate")>
		Private _cmbBaudrate As ComboBox

		' Token: 0x04000D17 RID: 3351
		<AccessedThroughProperty("cmbDataBit")>
		Private _cmbDataBit As ComboBox

		' Token: 0x04000D18 RID: 3352
		<AccessedThroughProperty("cmbParityBit")>
		Private _cmbParityBit As ComboBox

		' Token: 0x04000D19 RID: 3353
		<AccessedThroughProperty("cmbStopBit")>
		Private _cmbStopBit As ComboBox

		' Token: 0x04000D1A RID: 3354
		<AccessedThroughProperty("cmbFlowControl")>
		Private _cmbFlowControl As ComboBox

		' Token: 0x04000D1B RID: 3355
		<AccessedThroughProperty("cmbCOMName")>
		Private _cmbCOMName As ComboBox

		' Token: 0x04000D1C RID: 3356
		<AccessedThroughProperty("cmbLoaiMayIn")>
		Private _cmbLoaiMayIn As ComboBox

		' Token: 0x04000D1D RID: 3357
		<AccessedThroughProperty("lblLoaiMayIn")>
		Private _lblLoaiMayIn As Label

		' Token: 0x04000D1E RID: 3358
		<AccessedThroughProperty("lblLOPENDRAWERTAMTINH")>
		Private _lblLOPENDRAWERTAMTINH As Label

		' Token: 0x04000D1F RID: 3359
		<AccessedThroughProperty("chkLOPENDRAWERTAMTINH")>
		Private _chkLOPENDRAWERTAMTINH As CheckBox

		' Token: 0x04000D20 RID: 3360
		<AccessedThroughProperty("lblLOPENDRAWER")>
		Private _lblLOPENDRAWER As Label

		' Token: 0x04000D21 RID: 3361
		<AccessedThroughProperty("chkLOPENDRAWER")>
		Private _chkLOPENDRAWER As CheckBox

		' Token: 0x04000D22 RID: 3362
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000D23 RID: 3363
		<AccessedThroughProperty("txtPrintWidth")>
		Private _txtPrintWidth As TextBox

		' Token: 0x04000D24 RID: 3364
		<AccessedThroughProperty("lblPrintW")>
		Private _lblPrintW As Label

		' Token: 0x04000D25 RID: 3365
		<AccessedThroughProperty("LblMAMAYTINHCALL")>
		Private _LblMAMAYTINHCALL As Label

		' Token: 0x04000D26 RID: 3366
		<AccessedThroughProperty("txtTENMAYCALL")>
		Private _txtTENMAYCALL As TextBox

		' Token: 0x04000D27 RID: 3367
		<AccessedThroughProperty("TxtMAMAYCALL")>
		Private _TxtMAMAYCALL As TextBox

		' Token: 0x04000D28 RID: 3368
		<AccessedThroughProperty("btnSECLECTMAYCALL")>
		Private _btnSECLECTMAYCALL As Button

		' Token: 0x04000D29 RID: 3369
		<AccessedThroughProperty("txtTOP")>
		Private _txtTOP As TextBox

		' Token: 0x04000D2A RID: 3370
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000D2B RID: 3371
		<AccessedThroughProperty("txtLEFT")>
		Private _txtLEFT As TextBox

		' Token: 0x04000D2C RID: 3372
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000D2D RID: 3373
		<AccessedThroughProperty("txtRight")>
		Private _txtRight As TextBox

		' Token: 0x04000D2E RID: 3374
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x04000D2F RID: 3375
		<AccessedThroughProperty("txtBottom")>
		Private _txtBottom As TextBox

		' Token: 0x04000D30 RID: 3376
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x04000D31 RID: 3377
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x04000D32 RID: 3378
		<AccessedThroughProperty("Label6")>
		Private _Label6 As Label

		' Token: 0x04000D33 RID: 3379
		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		' Token: 0x04000D34 RID: 3380
		<AccessedThroughProperty("Label8")>
		Private _Label8 As Label

		' Token: 0x04000D35 RID: 3381
		<AccessedThroughProperty("lblMargin")>
		Private _lblMargin As Label

		' Token: 0x04000D36 RID: 3382
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000D37 RID: 3383
		Private mArrStrFrmMess As String()

		' Token: 0x04000D38 RID: 3384
		Private mbytFormStatus As Byte

		' Token: 0x04000D39 RID: 3385
		Private mbytSuccess As Byte

		' Token: 0x04000D3A RID: 3386
		Private mStrFilter As String

		' Token: 0x04000D3B RID: 3387
		Private mclsTbDMMAY As clsConnect

		' Token: 0x04000D3C RID: 3388
		Private mstrMAY As String

		' Token: 0x04000D3D RID: 3389
		Private mstrLoaiMayIn As String

		' Token: 0x04000D3E RID: 3390
		Private mTbLOAIMAYIN As DataTable
	End Class
End Namespace
