﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000050 RID: 80
	<DesignerGenerated()>
	Public Partial Class frmDMHHRES
		Inherits Form

		' Token: 0x060017F0 RID: 6128 RVA: 0x001292B4 File Offset: 0x001274B4
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMHH1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMHH1_Load
			frmDMHHRES.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mBlnCallFromSM = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000850 RID: 2128
		' (get) Token: 0x060017F3 RID: 6131 RVA: 0x00129938 File Offset: 0x00127B38
		' (set) Token: 0x060017F4 RID: 6132 RVA: 0x00129950 File Offset: 0x00127B50
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000851 RID: 2129
		' (get) Token: 0x060017F5 RID: 6133 RVA: 0x001299BC File Offset: 0x00127BBC
		' (set) Token: 0x060017F6 RID: 6134 RVA: 0x001299D4 File Offset: 0x00127BD4
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000852 RID: 2130
		' (get) Token: 0x060017F7 RID: 6135 RVA: 0x00129A40 File Offset: 0x00127C40
		' (set) Token: 0x060017F8 RID: 6136 RVA: 0x00129A58 File Offset: 0x00127C58
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
					RemoveHandler Me._dgvData.KeyDown, AddressOf Me.dgvData_KeyDown
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
					AddHandler Me._dgvData.KeyDown, AddressOf Me.dgvData_KeyDown
				End If
			End Set
		End Property

		' Token: 0x17000853 RID: 2131
		' (get) Token: 0x060017F9 RID: 6137 RVA: 0x00129AF4 File Offset: 0x00127CF4
		' (set) Token: 0x060017FA RID: 6138 RVA: 0x000058B4 File Offset: 0x00003AB4
		Friend Overridable Property lblMANH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMANH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMANH = value
			End Set
		End Property

		' Token: 0x17000854 RID: 2132
		' (get) Token: 0x060017FB RID: 6139 RVA: 0x00129B0C File Offset: 0x00127D0C
		' (set) Token: 0x060017FC RID: 6140 RVA: 0x00129B24 File Offset: 0x00127D24
		Friend Overridable Property txtOBJIDNH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJIDNH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJIDNH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJIDNH.TextChanged, AddressOf Me.txtOBJIDNH_TextChanged
					RemoveHandler Me._txtOBJIDNH.KeyDown, AddressOf Me.txtOBJIDNH_KeyDown
				End If
				Me._txtOBJIDNH = value
				flag = Me._txtOBJIDNH IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJIDNH.TextChanged, AddressOf Me.txtOBJIDNH_TextChanged
					AddHandler Me._txtOBJIDNH.KeyDown, AddressOf Me.txtOBJIDNH_KeyDown
				End If
			End Set
		End Property

		' Token: 0x17000855 RID: 2133
		' (get) Token: 0x060017FD RID: 6141 RVA: 0x00129BC0 File Offset: 0x00127DC0
		' (set) Token: 0x060017FE RID: 6142 RVA: 0x00129BD8 File Offset: 0x00127DD8
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x17000856 RID: 2134
		' (get) Token: 0x060017FF RID: 6143 RVA: 0x00129C44 File Offset: 0x00127E44
		' (set) Token: 0x06001800 RID: 6144 RVA: 0x000058BE File Offset: 0x00003ABE
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Me._mbdsSource = value
			End Set
		End Property

		' Token: 0x17000857 RID: 2135
		' (get) Token: 0x06001801 RID: 6145 RVA: 0x00129C5C File Offset: 0x00127E5C
		' (set) Token: 0x06001802 RID: 6146 RVA: 0x000058C8 File Offset: 0x00003AC8
		Public Property pclsTbDMHH As DataTable
			Get
				Return Me.mclsTbDMHH
			End Get
			Set(value As DataTable)
				Me.mclsTbDMHH = value
			End Set
		End Property

		' Token: 0x17000858 RID: 2136
		' (get) Token: 0x06001803 RID: 6147 RVA: 0x00129C74 File Offset: 0x00127E74
		' (set) Token: 0x06001804 RID: 6148 RVA: 0x000058D3 File Offset: 0x00003AD3
		Public Property pBlnCallFromSM As Boolean
			Get
				Return Me.mBlnCallFromSM
			End Get
			Set(value As Boolean)
				Me.mBlnCallFromSM = value
			End Set
		End Property

		' Token: 0x17000859 RID: 2137
		' (get) Token: 0x06001805 RID: 6149 RVA: 0x00129C8C File Offset: 0x00127E8C
		' (set) Token: 0x06001806 RID: 6150 RVA: 0x000058DE File Offset: 0x00003ADE
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x1700085A RID: 2138
		' (get) Token: 0x06001807 RID: 6151 RVA: 0x00129CA4 File Offset: 0x00127EA4
		' (set) Token: 0x06001808 RID: 6152 RVA: 0x000058E9 File Offset: 0x00003AE9
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06001809 RID: 6153 RVA: 0x00129CBC File Offset: 0x00127EBC
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
				Me.mStrOBJNAME = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJNAME").Value)
				Try
					For Each process As Process In Process.GetProcessesByName("MyKey")
						process.Kill()
					Next
				Catch ex As Exception
				End Try
				Me.Close()
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Me.txtOBJIDNH.Focus()
			Finally
			End Try
		End Sub

		' Token: 0x0600180A RID: 6154 RVA: 0x00129E30 File Offset: 0x00128030
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600180B RID: 6155 RVA: 0x00129F00 File Offset: 0x00128100
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600180C RID: 6156 RVA: 0x00129FF0 File Offset: 0x001281F0
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600180D RID: 6157 RVA: 0x0012A0D4 File Offset: 0x001282D4
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600180E RID: 6158 RVA: 0x0012A198 File Offset: 0x00128398
		Private Sub txtOBJIDNH_KeyDown(sender As Object, e As KeyEventArgs)
			Try
				Dim keyCode As Keys = e.KeyCode
				Dim flag As Boolean = keyCode = Keys.Down
				If flag Then
					Dim flag2 As Boolean = Me.mbdsSource.Count > 0
					If flag2 Then
						Me.dgvData.Focus()
					Else
						Me.txtOBJIDNH.Focus()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJIDNH_KeyDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600180F RID: 6159 RVA: 0x0012A26C File Offset: 0x0012846C
		Private Sub dgvData_KeyDown(sender As Object, e As KeyEventArgs)
			Try
				Dim keyCode As Keys = e.KeyCode
				Dim flag As Boolean = keyCode = Keys.[Return]
				If flag Then
					Dim flag2 As Boolean = Me.mbdsSource.Count > 0
					If flag2 Then
						Me.mStrOBJID = Me.dgvData.CurrentRow.Cells("OBJID").Value.ToString().Trim()
						Me.mStrOBJNAME = Me.dgvData.CurrentRow.Cells("OBJNAME").Value.ToString().Trim()
						Me.mStrMADVT = Me.dgvData.CurrentRow.Cells("MADVT").Value.ToString().Trim()
						Me.Close()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_KeyDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001810 RID: 6160 RVA: 0x0012A3D8 File Offset: 0x001285D8
		Private Sub frmDMHH1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHH1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001811 RID: 6161 RVA: 0x0012A470 File Offset: 0x00128670
		Private Sub frmDMHH1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Me.CancelButton = Me.btnExit
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = Me.mBlnCallFromSM
				If flag Then
					Me.Top = 0
					Me.btnKeyboard_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHH1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001812 RID: 6162 RVA: 0x0012A58C File Offset: 0x0012878C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Try
					Process.GetProcessesByName("MyKey")(0).Kill()
				Catch ex As Exception
				End Try
				Me.Close()
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001813 RID: 6163 RVA: 0x0012A658 File Offset: 0x00128858
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001814 RID: 6164 RVA: 0x0012A708 File Offset: 0x00128908
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 130
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 210
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENDVT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("TENDVT").Width = 70
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("TENDVT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("GIA1").HeaderText = Strings.Trim(Me.mArrStrFrmMess(29))
				dgvData.Columns("GIA1").Width = 70
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("GIA1").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("GIA2").HeaderText = Strings.Trim(Me.mArrStrFrmMess(36))
				dgvData.Columns("GIA2").Width = 70
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("GIA2").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENNH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("TENNH").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENNH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MAHH").Visible = False
				dgvData.Columns("SUBOBJNAME").Visible = False
				dgvData.Columns("DVT").Visible = False
				dgvData.Columns("TENTHUE").Visible = False
				dgvData.Columns("MAPL").Visible = False
				dgvData.Columns("MANSX").Visible = False
				dgvData.Columns("MADVT").Visible = False
				dgvData.Columns("MADC").Visible = False
				dgvData.Columns("MANCHU").Visible = False
				dgvData.Columns("DISCOUNT").Visible = False
				dgvData.Columns("LCOMBOPRICE").Visible = False
				dgvData.Columns("LAMTOPEN").Visible = False
				dgvData.Columns("NGAYHETHAN").Visible = False
				dgvData.Columns("PRICE1").Visible = False
				dgvData.Columns("PRICE2").Visible = False
				dgvData.Columns("PRICE3").Visible = False
				dgvData.Columns("PRICE4").Visible = False
				dgvData.Columns("PRICE5").Visible = False
				dgvData.Columns("PRICE6").Visible = False
				dgvData.Columns("PRICE7").Visible = False
				dgvData.Columns("PRICE8").Visible = False
				dgvData.Columns("PRICE9").Visible = False
				dgvData.Columns("PRICE10").Visible = False
				dgvData.Columns("MAMT").Visible = False
				dgvData.Columns("MANH").Visible = False
				dgvData.Columns("LMATERIAL").Visible = False
				dgvData.Columns("FIXED").Visible = False
				dgvData.Columns("RATE").Visible = False
				dgvData.Columns("MAMAYINBEP1").Visible = False
				dgvData.Columns("MAMAYINBEP2").Visible = False
				dgvData.Columns("MAMAYINBEP3").Visible = False
				dgvData.Columns("LCOMBO").Visible = False
				dgvData.Columns("REMARK").Visible = False
				dgvData.Columns("LOPEN").Visible = False
				dgvData.Columns("TENNSX").Visible = False
				dgvData.Columns("TENPL").Visible = False
				dgvData.Columns("LSAVE").Visible = False
				dgvData.Columns("LSETCOMBO").Visible = False
				dgvData.Columns("LTON_KHACHHANG").Visible = False
				dgvData.Columns("PHIEU").Visible = False
				dgvData.Columns("MAMAYINBEP4").Visible = False
				dgvData.Columns("MAMAYINBEP5").Visible = False
				dgvData.Columns("MAMAYINBEP6").Visible = False
				dgvData.Columns("OBJNAME2").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001815 RID: 6165 RVA: 0x0012AE9C File Offset: 0x0012909C
		Private Function fGetData_4Grid() As Byte
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@gnchMAKH"
				array(0).Value = mdlVariable.gStrStockCodeRes
				Dim num As Integer
				Me.mclsTbDMHH = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMSAL01_GET_DATA_DMHH_DDRES", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = Me.mclsTbDMHH
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001816 RID: 6166 RVA: 0x0012AFB8 File Offset: 0x001291B8
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001817 RID: 6167 RVA: 0x0012B064 File Offset: 0x00129264
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001818 RID: 6168 RVA: 0x0012B170 File Offset: 0x00129370
		Private Sub sClear_Form()
			Try
				Dim flag As Boolean = Me.mbdsSource IsNot Nothing
				If flag Then
					Me.mbdsSource.Dispose()
				End If
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001819 RID: 6169 RVA: 0x0012B22C File Offset: 0x0012942C
		Private Sub txtOBJIDNH_TextChanged(sender As Object, e As EventArgs)
			Dim text As String = Me.txtOBJIDNH.Text.Trim()
			Dim flag As Boolean = Operators.CompareString(text, "", False) = 0
			If flag Then
				Me.mbdsSource.RemoveFilter()
			Else
				text = Conversions.ToString(NewLateBinding.LateGet(Nothing, GetType(Strings), "UCase", New Object() { RuntimeHelpers.GetObjectValue(Interaction.IIf(Operators.CompareString(Strings.Mid(text, 1, 1), "*", False) = 0, Strings.Mid(text, 2), text)) }, Nothing, Nothing, Nothing))
				Dim text2 As String = Conversions.ToString(Operators.ConcatenateObject(Interaction.IIf(mdlVariable.gblnLSEARCH_ALL_TENHH, "*", ""), Me.txtOBJIDNH.Text.Trim()))
				flag = text2.StartsWith("*")
				If flag Then
					Me.mbdsSource.Filter = String.Concat(New String() { "OBJID LIKE '%", Me.txtOBJIDNH.Text, "%' OR OBJNAME LIKE '%", Me.txtOBJIDNH.Text, "%' OR SUBOBJNAME LIKE '%", Me.txtOBJIDNH.Text, "%' OR OBJNAME2 LIKE '%", Me.txtOBJIDNH.Text, "%'" })
				Else
					Me.mbdsSource.Filter = String.Concat(New String() { "OBJID LIKE '", Me.txtOBJIDNH.Text, "%' OR OBJNAME LIKE '", Me.txtOBJIDNH.Text, "%' OR SUBOBJNAME LIKE '", Me.txtOBJIDNH.Text, "%' OR OBJNAME2 LIKE '", Me.txtOBJIDNH.Text, "%'" })
				End If
			End If
		End Sub

		' Token: 0x0600181A RID: 6170 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x0600181B RID: 6171 RVA: 0x0012B438 File Offset: 0x00129638
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				Me.txtOBJIDNH.Focus()
				Me.txtOBJIDNH.SelectAll()
				Me.Focus()
			End If
		End Sub

		' Token: 0x040009EB RID: 2539
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040009ED RID: 2541
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040009EE RID: 2542
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040009EF RID: 2543
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040009F0 RID: 2544
		<AccessedThroughProperty("lblMANH")>
		Private _lblMANH As Label

		' Token: 0x040009F1 RID: 2545
		<AccessedThroughProperty("txtOBJIDNH")>
		Private _txtOBJIDNH As TextBox

		' Token: 0x040009F2 RID: 2546
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x040009F3 RID: 2547
		Private mArrStrFrmMess As String()

		' Token: 0x040009F4 RID: 2548
		Private mStrOBJID As String

		' Token: 0x040009F5 RID: 2549
		Private mStrOBJNAME As String

		' Token: 0x040009F6 RID: 2550
		Private mStrMADVT As String

		' Token: 0x040009F7 RID: 2551
		Private mStrTENDVT As String

		' Token: 0x040009F8 RID: 2552
		Private mStrPRICE1 As String

		' Token: 0x040009F9 RID: 2553
		Private mblnLSAVE As Boolean

		' Token: 0x040009FA RID: 2554
		Private mbytRATE As Byte

		' Token: 0x040009FB RID: 2555
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040009FC RID: 2556
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040009FD RID: 2557
		Private marrDrFind As DataRow()

		' Token: 0x040009FE RID: 2558
		Private mintFindLastPos As Integer

		' Token: 0x040009FF RID: 2559
		Private mclsTbDMHH As DataTable

		' Token: 0x04000A00 RID: 2560
		Private mBlnCallFromSM As Boolean
	End Class
End Namespace
