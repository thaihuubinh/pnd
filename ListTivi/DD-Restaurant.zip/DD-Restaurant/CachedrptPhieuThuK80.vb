﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020001AE RID: 430
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptPhieuThuK80
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005D1A RID: 23834 RVA: 0x0001073D File Offset: 0x0000E93D
		Public Sub New()
			CachedrptPhieuThuK80.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002263 RID: 8803
		' (get) Token: 0x06005D1B RID: 23835 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005D1C RID: 23836 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002264 RID: 8804
		' (get) Token: 0x06005D1D RID: 23837 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005D1E RID: 23838 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002265 RID: 8805
		' (get) Token: 0x06005D1F RID: 23839 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005D20 RID: 23840 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005D21 RID: 23841 RVA: 0x004DC120 File Offset: 0x004DA320
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptPhieuThuK80() With { .Site = Me.Site }
		End Function

		' Token: 0x06005D22 RID: 23842 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040027A6 RID: 10150
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
