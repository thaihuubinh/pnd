﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002F0 RID: 752
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBCTestPrintK58Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006F9F RID: 28575 RVA: 0x00013ACF File Offset: 0x00011CCF
		Public Sub New()
			CachedrptRepBCTestPrintK58Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002E9E RID: 11934
		' (get) Token: 0x06006FA0 RID: 28576 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006FA1 RID: 28577 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002E9F RID: 11935
		' (get) Token: 0x06006FA2 RID: 28578 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006FA3 RID: 28579 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002EA0 RID: 11936
		' (get) Token: 0x06006FA4 RID: 28580 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006FA5 RID: 28581 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006FA6 RID: 28582 RVA: 0x004DF044 File Offset: 0x004DD244
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBCTestPrintK58Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x06006FA7 RID: 28583 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028E8 RID: 10472
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
