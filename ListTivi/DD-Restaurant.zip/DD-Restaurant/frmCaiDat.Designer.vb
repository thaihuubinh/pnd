﻿Namespace prjIS_SalesPOS
	' Token: 0x0200001C RID: 28
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCaiDat
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600045C RID: 1116 RVA: 0x00034BF0 File Offset: 0x00032DF0
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600045D RID: 1117 RVA: 0x00034C28 File Offset: 0x00032E28
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCaiDat))
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim dataGridViewCellStyle2 As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim dataGridViewCellStyle3 As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Me.btnSelect = New Global.System.Windows.Forms.Button()
			Me.TableLayoutPanel5 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnDownNH = New Global.System.Windows.Forms.Button()
			Me.btnUpNH = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.Column2 = New Global.System.Windows.Forms.DataGridViewTextBoxColumn()
			Me.Column1 = New Global.System.Windows.Forms.DataGridViewTextBoxColumn()
			Me.dtgStatus = New Global.System.Windows.Forms.DataGridView()
			Me.TableLayoutPanel5.SuspendLayout()
			CType(Me.dtgStatus, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.btnSelect.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnSelect.BackgroundImage = CType(componentResourceManager.GetObject("btnSelect.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnSelect.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnSelect.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSelect.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnSelect.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnSelect.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnSelect.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Me.btnSelect.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnSelect As Global.System.Windows.Forms.Control = Me.btnSelect
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(249, 3)
			btnSelect.Location = point
			Me.btnSelect.Name = "btnSelect"
			Dim btnSelect2 As Global.System.Windows.Forms.Control = Me.btnSelect
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(117, 38)
			btnSelect2.Size = size
			Me.btnSelect.TabIndex = 3
			Me.btnSelect.Tag = "NC012R0001"
			Me.btnSelect.Text = "Chọn"
			Me.btnSelect.UseVisualStyleBackColor = False
			Me.TableLayoutPanel5.ColumnCount = 4
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.Controls.Add(Me.btnDownNH, 0, 0)
			Me.TableLayoutPanel5.Controls.Add(Me.btnUpNH, 0, 0)
			Me.TableLayoutPanel5.Controls.Add(Me.btnExit, 3, 0)
			Me.TableLayoutPanel5.Controls.Add(Me.btnSelect, 2, 0)
			Me.TableLayoutPanel5.Dock = Global.System.Windows.Forms.DockStyle.Bottom
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel5
			point = New Global.System.Drawing.Point(0, 387)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
			Me.TableLayoutPanel5.RowCount = 1
			Me.TableLayoutPanel5.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel5
			size = New Global.System.Drawing.Size(494, 44)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel5.TabIndex = 7
			Me.btnDownNH.BackColor = Global.System.Drawing.Color.Silver
			Me.btnDownNH.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.hinhnennut
			Me.btnDownNH.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnDownNH.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDownNH.Font = New Global.System.Drawing.Font("Wingdings", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 2)
			Me.btnDownNH.ForeColor = Global.System.Drawing.Color.FromArgb(255, 128, 0)
			Dim btnDownNH As Global.System.Windows.Forms.Control = Me.btnDownNH
			point = New Global.System.Drawing.Point(126, 3)
			btnDownNH.Location = point
			Me.btnDownNH.Name = "btnDownNH"
			Dim btnDownNH2 As Global.System.Windows.Forms.Control = Me.btnDownNH
			size = New Global.System.Drawing.Size(117, 38)
			btnDownNH2.Size = size
			Me.btnDownNH.TabIndex = 2
			Me.btnDownNH.Text = ""
			Me.btnDownNH.UseVisualStyleBackColor = False
			Me.btnUpNH.BackColor = Global.System.Drawing.Color.Silver
			Me.btnUpNH.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.hinhnennut
			Me.btnUpNH.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnUpNH.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnUpNH.Font = New Global.System.Drawing.Font("Wingdings", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 2)
			Me.btnUpNH.ForeColor = Global.System.Drawing.Color.FromArgb(255, 128, 0)
			Dim btnUpNH As Global.System.Windows.Forms.Control = Me.btnUpNH
			point = New Global.System.Drawing.Point(3, 3)
			btnUpNH.Location = point
			Me.btnUpNH.Name = "btnUpNH"
			Dim btnUpNH2 As Global.System.Windows.Forms.Control = Me.btnUpNH
			size = New Global.System.Drawing.Size(117, 38)
			btnUpNH2.Size = size
			Me.btnUpNH.TabIndex = 1
			Me.btnUpNH.Text = ""
			Me.btnUpNH.UseVisualStyleBackColor = False
			Me.btnExit.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(372, 3)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(119, 38)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 3
			Me.btnExit.Tag = "NC012R0002"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.UseVisualStyleBackColor = False
			Me.Column2.FillWeight = 98.47716F
			Me.Column2.HeaderText = "Tên hiển thị"
			Me.Column2.Name = "Column2"
			Me.Column2.[ReadOnly] = True
			Me.Column1.FillWeight = 101.5228F
			Me.Column1.HeaderText = "Mã"
			Me.Column1.Name = "Column1"
			Me.Column1.[ReadOnly] = True
			Me.dtgStatus.AllowUserToAddRows = False
			Me.dtgStatus.AllowUserToDeleteRows = False
			Me.dtgStatus.AllowUserToResizeRows = False
			dataGridViewCellStyle.BackColor = Global.System.Drawing.Color.FromArgb(192, 255, 192)
			Me.dtgStatus.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle
			Me.dtgStatus.AutoSizeColumnsMode = Global.System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
			Me.dtgStatus.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle2.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
			dataGridViewCellStyle2.BackColor = Global.System.Drawing.Color.White
			dataGridViewCellStyle2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle2.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle2.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle2.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle2.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dtgStatus.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2
			Me.dtgStatus.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dtgStatus.ColumnHeadersVisible = False
			Me.dtgStatus.Columns.AddRange(New Global.System.Windows.Forms.DataGridViewColumn() { Me.Column1, Me.Column2 })
			Me.dtgStatus.Dock = Global.System.Windows.Forms.DockStyle.Top
			Me.dtgStatus.GridColor = Global.System.Drawing.Color.Black
			Dim dtgStatus As Global.System.Windows.Forms.Control = Me.dtgStatus
			point = New Global.System.Drawing.Point(0, 0)
			dtgStatus.Location = point
			Me.dtgStatus.MultiSelect = False
			Me.dtgStatus.Name = "dtgStatus"
			Me.dtgStatus.[ReadOnly] = True
			Me.dtgStatus.RowHeadersVisible = False
			dataGridViewCellStyle3.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle3.Font = New Global.System.Drawing.Font("Courier New", 20.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.dtgStatus.RowsDefaultCellStyle = dataGridViewCellStyle3
			Me.dtgStatus.RowTemplate.Height = 50
			Me.dtgStatus.ScrollBars = Global.System.Windows.Forms.ScrollBars.Vertical
			Me.dtgStatus.SelectionMode = Global.System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
			Dim dtgStatus2 As Global.System.Windows.Forms.Control = Me.dtgStatus
			size = New Global.System.Drawing.Size(494, 381)
			dtgStatus2.Size = size
			Me.dtgStatus.TabIndex = 6
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(494, 431)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.TableLayoutPanel5)
			Me.Controls.Add(Me.dtgStatus)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Me.Name = "frmCaiDat"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Cài đặt"
			Me.TableLayoutPanel5.ResumeLayout(False)
			CType(Me.dtgStatus, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x040001E2 RID: 482
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
