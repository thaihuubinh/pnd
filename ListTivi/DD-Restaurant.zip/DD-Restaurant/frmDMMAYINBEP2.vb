﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.IO
Imports System.IO.Ports
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000062 RID: 98
	<DesignerGenerated()>
	Public Partial Class frmDMMAYINBEP2
		Inherits Form

		' Token: 0x06001D8B RID: 7563 RVA: 0x001709A4 File Offset: 0x0016EBA4
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMMAYINBEP2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMMAYINBEP2_Load
			frmDMMAYINBEP2.__ENCList.Add(New WeakReference(Me))
			Me.mstrMAY = ""
			Me.mstrLoaiMayIn = ""
			Me.mTbLOAIMAYIN = New DataTable()
			Me.mstrCOMNAME = ""
			Me.mstrBAULDRATE = ""
			Me.mstrDATABIT = ""
			Me.mstrPARITYBIT = ""
			Me.mstrSTOPBIT = ""
			Me.mstrFLOWCONTROL = ""
			Me.mbytLTENHHFORMAT = 0
			Me.mbytDKSOLUONG = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000A0B RID: 2571
		' (get) Token: 0x06001D8E RID: 7566 RVA: 0x00177328 File Offset: 0x00175528
		' (set) Token: 0x06001D8F RID: 7567 RVA: 0x000061AB File Offset: 0x000043AB
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000A0C RID: 2572
		' (get) Token: 0x06001D90 RID: 7568 RVA: 0x00177340 File Offset: 0x00175540
		' (set) Token: 0x06001D91 RID: 7569 RVA: 0x00177358 File Offset: 0x00175558
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000A0D RID: 2573
		' (get) Token: 0x06001D92 RID: 7570 RVA: 0x001773C4 File Offset: 0x001755C4
		' (set) Token: 0x06001D93 RID: 7571 RVA: 0x000061B5 File Offset: 0x000043B5
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x17000A0E RID: 2574
		' (get) Token: 0x06001D94 RID: 7572 RVA: 0x001773DC File Offset: 0x001755DC
		' (set) Token: 0x06001D95 RID: 7573 RVA: 0x001773F4 File Offset: 0x001755F4
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000A0F RID: 2575
		' (get) Token: 0x06001D96 RID: 7574 RVA: 0x00177460 File Offset: 0x00175660
		' (set) Token: 0x06001D97 RID: 7575 RVA: 0x00177478 File Offset: 0x00175678
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000A10 RID: 2576
		' (get) Token: 0x06001D98 RID: 7576 RVA: 0x001774E4 File Offset: 0x001756E4
		' (set) Token: 0x06001D99 RID: 7577 RVA: 0x001774FC File Offset: 0x001756FC
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000A11 RID: 2577
		' (get) Token: 0x06001D9A RID: 7578 RVA: 0x00177568 File Offset: 0x00175768
		' (set) Token: 0x06001D9B RID: 7579 RVA: 0x000061BF File Offset: 0x000043BF
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x17000A12 RID: 2578
		' (get) Token: 0x06001D9C RID: 7580 RVA: 0x00177580 File Offset: 0x00175780
		' (set) Token: 0x06001D9D RID: 7581 RVA: 0x00177598 File Offset: 0x00175798
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A13 RID: 2579
		' (get) Token: 0x06001D9E RID: 7582 RVA: 0x00177634 File Offset: 0x00175834
		' (set) Token: 0x06001D9F RID: 7583 RVA: 0x0017764C File Offset: 0x0017584C
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000A14 RID: 2580
		' (get) Token: 0x06001DA0 RID: 7584 RVA: 0x001776E8 File Offset: 0x001758E8
		' (set) Token: 0x06001DA1 RID: 7585 RVA: 0x000061C9 File Offset: 0x000043C9
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x17000A15 RID: 2581
		' (get) Token: 0x06001DA2 RID: 7586 RVA: 0x00177700 File Offset: 0x00175900
		' (set) Token: 0x06001DA3 RID: 7587 RVA: 0x000061D3 File Offset: 0x000043D3
		Friend Overridable Property lblTimeOut As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTimeOut
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTimeOut = value
			End Set
		End Property

		' Token: 0x17000A16 RID: 2582
		' (get) Token: 0x06001DA4 RID: 7588 RVA: 0x00177718 File Offset: 0x00175918
		' (set) Token: 0x06001DA5 RID: 7589 RVA: 0x000061DD File Offset: 0x000043DD
		Friend Overridable Property lblPrintCount As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPrintCount
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPrintCount = value
			End Set
		End Property

		' Token: 0x17000A17 RID: 2583
		' (get) Token: 0x06001DA6 RID: 7590 RVA: 0x00177730 File Offset: 0x00175930
		' (set) Token: 0x06001DA7 RID: 7591 RVA: 0x000061E7 File Offset: 0x000043E7
		Friend Overridable Property lblComputer As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblComputer
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblComputer = value
			End Set
		End Property

		' Token: 0x17000A18 RID: 2584
		' (get) Token: 0x06001DA8 RID: 7592 RVA: 0x00177748 File Offset: 0x00175948
		' (set) Token: 0x06001DA9 RID: 7593 RVA: 0x00177760 File Offset: 0x00175960
		Friend Overridable Property txtTimeOut As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTimeOut
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTimeOut IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTimeOut.KeyPress, AddressOf Me.txtTimeOut_KeyPress
					RemoveHandler Me._txtTimeOut.GotFocus, AddressOf Me.txtTimeOut_GotFocus
				End If
				Me._txtTimeOut = value
				flag = Me._txtTimeOut IsNot Nothing
				If flag Then
					AddHandler Me._txtTimeOut.KeyPress, AddressOf Me.txtTimeOut_KeyPress
					AddHandler Me._txtTimeOut.GotFocus, AddressOf Me.txtTimeOut_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000A19 RID: 2585
		' (get) Token: 0x06001DAA RID: 7594 RVA: 0x001777FC File Offset: 0x001759FC
		' (set) Token: 0x06001DAB RID: 7595 RVA: 0x00177814 File Offset: 0x00175A14
		Friend Overridable Property txtPrintCount As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPrintCount
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPrintCount IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPrintCount.KeyPress, AddressOf Me.txtPrintCount_KeyPress
					RemoveHandler Me._txtPrintCount.GotFocus, AddressOf Me.txtPrintCount_GotFocus
				End If
				Me._txtPrintCount = value
				flag = Me._txtPrintCount IsNot Nothing
				If flag Then
					AddHandler Me._txtPrintCount.KeyPress, AddressOf Me.txtPrintCount_KeyPress
					AddHandler Me._txtPrintCount.GotFocus, AddressOf Me.txtPrintCount_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000A1A RID: 2586
		' (get) Token: 0x06001DAC RID: 7596 RVA: 0x001778B0 File Offset: 0x00175AB0
		' (set) Token: 0x06001DAD RID: 7597 RVA: 0x000061F1 File Offset: 0x000043F1
		Friend Overridable Property lblCOMName As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCOMName
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCOMName = value
			End Set
		End Property

		' Token: 0x17000A1B RID: 2587
		' (get) Token: 0x06001DAE RID: 7598 RVA: 0x001778C8 File Offset: 0x00175AC8
		' (set) Token: 0x06001DAF RID: 7599 RVA: 0x000061FB File Offset: 0x000043FB
		Friend Overridable Property lblBaudrate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblBaudrate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblBaudrate = value
			End Set
		End Property

		' Token: 0x17000A1C RID: 2588
		' (get) Token: 0x06001DB0 RID: 7600 RVA: 0x001778E0 File Offset: 0x00175AE0
		' (set) Token: 0x06001DB1 RID: 7601 RVA: 0x00006205 File Offset: 0x00004405
		Friend Overridable Property lblDataBit As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDataBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDataBit = value
			End Set
		End Property

		' Token: 0x17000A1D RID: 2589
		' (get) Token: 0x06001DB2 RID: 7602 RVA: 0x001778F8 File Offset: 0x00175AF8
		' (set) Token: 0x06001DB3 RID: 7603 RVA: 0x0000620F File Offset: 0x0000440F
		Friend Overridable Property lblParityBit As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblParityBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblParityBit = value
			End Set
		End Property

		' Token: 0x17000A1E RID: 2590
		' (get) Token: 0x06001DB4 RID: 7604 RVA: 0x00177910 File Offset: 0x00175B10
		' (set) Token: 0x06001DB5 RID: 7605 RVA: 0x00006219 File Offset: 0x00004419
		Friend Overridable Property lblStopBit As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblStopBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblStopBit = value
			End Set
		End Property

		' Token: 0x17000A1F RID: 2591
		' (get) Token: 0x06001DB6 RID: 7606 RVA: 0x00177928 File Offset: 0x00175B28
		' (set) Token: 0x06001DB7 RID: 7607 RVA: 0x00006223 File Offset: 0x00004423
		Friend Overridable Property lblFlowControl As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFlowControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFlowControl = value
			End Set
		End Property

		' Token: 0x17000A20 RID: 2592
		' (get) Token: 0x06001DB8 RID: 7608 RVA: 0x00177940 File Offset: 0x00175B40
		' (set) Token: 0x06001DB9 RID: 7609 RVA: 0x0000622D File Offset: 0x0000442D
		Friend Overridable Property txtColor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtColor = value
			End Set
		End Property

		' Token: 0x17000A21 RID: 2593
		' (get) Token: 0x06001DBA RID: 7610 RVA: 0x00177958 File Offset: 0x00175B58
		' (set) Token: 0x06001DBB RID: 7611 RVA: 0x00177970 File Offset: 0x00175B70
		Friend Overridable Property txtRemark As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtRemark
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtRemark IsNot Nothing
				If flag Then
					RemoveHandler Me._txtRemark.GotFocus, AddressOf Me.txtRemark_GotFocus
				End If
				Me._txtRemark = value
				flag = Me._txtRemark IsNot Nothing
				If flag Then
					AddHandler Me._txtRemark.GotFocus, AddressOf Me.txtRemark_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000A22 RID: 2594
		' (get) Token: 0x06001DBC RID: 7612 RVA: 0x001779DC File Offset: 0x00175BDC
		' (set) Token: 0x06001DBD RID: 7613 RVA: 0x00006237 File Offset: 0x00004437
		Friend Overridable Property lblRemark As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblRemark
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblRemark = value
			End Set
		End Property

		' Token: 0x17000A23 RID: 2595
		' (get) Token: 0x06001DBE RID: 7614 RVA: 0x001779F4 File Offset: 0x00175BF4
		' (set) Token: 0x06001DBF RID: 7615 RVA: 0x00006241 File Offset: 0x00004441
		Friend Overridable Property txtTENMAY As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENMAY = value
			End Set
		End Property

		' Token: 0x17000A24 RID: 2596
		' (get) Token: 0x06001DC0 RID: 7616 RVA: 0x00177A0C File Offset: 0x00175C0C
		' (set) Token: 0x06001DC1 RID: 7617 RVA: 0x00177A24 File Offset: 0x00175C24
		Friend Overridable Property txtMAMAY As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAMAY IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAMAY.TextChanged, AddressOf Me.txtMAMAY_TextChanged
					RemoveHandler Me._txtMAMAY.GotFocus, AddressOf Me.txtMAMAY_GotFocus
					RemoveHandler Me._txtMAMAY.KeyPress, AddressOf Me.txtMAMAY_KeyPress
				End If
				Me._txtMAMAY = value
				flag = Me._txtMAMAY IsNot Nothing
				If flag Then
					AddHandler Me._txtMAMAY.TextChanged, AddressOf Me.txtMAMAY_TextChanged
					AddHandler Me._txtMAMAY.GotFocus, AddressOf Me.txtMAMAY_GotFocus
					AddHandler Me._txtMAMAY.KeyPress, AddressOf Me.txtMAMAY_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A25 RID: 2597
		' (get) Token: 0x06001DC2 RID: 7618 RVA: 0x00177AF4 File Offset: 0x00175CF4
		' (set) Token: 0x06001DC3 RID: 7619 RVA: 0x00177B0C File Offset: 0x00175D0C
		Friend Overridable Property btnDMMAY As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMMAY IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMMAY.Click, AddressOf Me.btnDMMAY_Click
				End If
				Me._btnDMMAY = value
				flag = Me._btnDMMAY IsNot Nothing
				If flag Then
					AddHandler Me._btnDMMAY.Click, AddressOf Me.btnDMMAY_Click
				End If
			End Set
		End Property

		' Token: 0x17000A26 RID: 2598
		' (get) Token: 0x06001DC4 RID: 7620 RVA: 0x00177B78 File Offset: 0x00175D78
		' (set) Token: 0x06001DC5 RID: 7621 RVA: 0x00177B90 File Offset: 0x00175D90
		Friend Overridable Property cmbBaudrate As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbBaudrate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbBaudrate IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbBaudrate.KeyPress, AddressOf Me.cmbBaudrate_KeyPress
				End If
				Me._cmbBaudrate = value
				flag = Me._cmbBaudrate IsNot Nothing
				If flag Then
					AddHandler Me._cmbBaudrate.KeyPress, AddressOf Me.cmbBaudrate_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A27 RID: 2599
		' (get) Token: 0x06001DC6 RID: 7622 RVA: 0x00177BFC File Offset: 0x00175DFC
		' (set) Token: 0x06001DC7 RID: 7623 RVA: 0x00177C14 File Offset: 0x00175E14
		Friend Overridable Property cmbDataBit As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbDataBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbDataBit IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbDataBit.KeyPress, AddressOf Me.cmbDataBit_KeyPress
				End If
				Me._cmbDataBit = value
				flag = Me._cmbDataBit IsNot Nothing
				If flag Then
					AddHandler Me._cmbDataBit.KeyPress, AddressOf Me.cmbDataBit_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A28 RID: 2600
		' (get) Token: 0x06001DC8 RID: 7624 RVA: 0x00177C80 File Offset: 0x00175E80
		' (set) Token: 0x06001DC9 RID: 7625 RVA: 0x00177C98 File Offset: 0x00175E98
		Friend Overridable Property cmbParityBit As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbParityBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbParityBit IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbParityBit.KeyPress, AddressOf Me.cmbParityBit_KeyPress
				End If
				Me._cmbParityBit = value
				flag = Me._cmbParityBit IsNot Nothing
				If flag Then
					AddHandler Me._cmbParityBit.KeyPress, AddressOf Me.cmbParityBit_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A29 RID: 2601
		' (get) Token: 0x06001DCA RID: 7626 RVA: 0x00177D04 File Offset: 0x00175F04
		' (set) Token: 0x06001DCB RID: 7627 RVA: 0x00177D1C File Offset: 0x00175F1C
		Friend Overridable Property cmbStopBit As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbStopBit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbStopBit IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbStopBit.KeyPress, AddressOf Me.cmbStopBit_KeyPress
				End If
				Me._cmbStopBit = value
				flag = Me._cmbStopBit IsNot Nothing
				If flag Then
					AddHandler Me._cmbStopBit.KeyPress, AddressOf Me.cmbStopBit_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A2A RID: 2602
		' (get) Token: 0x06001DCC RID: 7628 RVA: 0x00177D88 File Offset: 0x00175F88
		' (set) Token: 0x06001DCD RID: 7629 RVA: 0x00177DA0 File Offset: 0x00175FA0
		Friend Overridable Property cmbFlowControl As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbFlowControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbFlowControl IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbFlowControl.KeyPress, AddressOf Me.cmbFlowControl_KeyPress
				End If
				Me._cmbFlowControl = value
				flag = Me._cmbFlowControl IsNot Nothing
				If flag Then
					AddHandler Me._cmbFlowControl.KeyPress, AddressOf Me.cmbFlowControl_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A2B RID: 2603
		' (get) Token: 0x06001DCE RID: 7630 RVA: 0x00177E0C File Offset: 0x0017600C
		' (set) Token: 0x06001DCF RID: 7631 RVA: 0x00177E24 File Offset: 0x00176024
		Friend Overridable Property cmbCOMName As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbCOMName
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbCOMName IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbCOMName.KeyPress, AddressOf Me.cmbCOMName_KeyPress
				End If
				Me._cmbCOMName = value
				flag = Me._cmbCOMName IsNot Nothing
				If flag Then
					AddHandler Me._cmbCOMName.KeyPress, AddressOf Me.cmbCOMName_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A2C RID: 2604
		' (get) Token: 0x06001DD0 RID: 7632 RVA: 0x00177E90 File Offset: 0x00176090
		' (set) Token: 0x06001DD1 RID: 7633 RVA: 0x00177EA8 File Offset: 0x001760A8
		Friend Overridable Property cmbLoaiMayIn As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbLoaiMayIn
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbLoaiMayIn IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbLoaiMayIn.KeyPress, AddressOf Me.cmbLoaiMayIn_KeyPress
					RemoveHandler Me._cmbLoaiMayIn.SelectedValueChanged, AddressOf Me.cmbLoaiMayIn_SelectedValueChanged
				End If
				Me._cmbLoaiMayIn = value
				flag = Me._cmbLoaiMayIn IsNot Nothing
				If flag Then
					AddHandler Me._cmbLoaiMayIn.KeyPress, AddressOf Me.cmbLoaiMayIn_KeyPress
					AddHandler Me._cmbLoaiMayIn.SelectedValueChanged, AddressOf Me.cmbLoaiMayIn_SelectedValueChanged
				End If
			End Set
		End Property

		' Token: 0x17000A2D RID: 2605
		' (get) Token: 0x06001DD2 RID: 7634 RVA: 0x00177F44 File Offset: 0x00176144
		' (set) Token: 0x06001DD3 RID: 7635 RVA: 0x0000624B File Offset: 0x0000444B
		Friend Overridable Property lblLoaiMayIn As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLoaiMayIn
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblLoaiMayIn = value
			End Set
		End Property

		' Token: 0x17000A2E RID: 2606
		' (get) Token: 0x06001DD4 RID: 7636 RVA: 0x00177F5C File Offset: 0x0017615C
		' (set) Token: 0x06001DD5 RID: 7637 RVA: 0x00177F74 File Offset: 0x00176174
		Friend Overridable Property chkLSHARE As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLSHARE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLSHARE IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLSHARE.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
				Me._chkLSHARE = value
				flag = Me._chkLSHARE IsNot Nothing
				If flag Then
					AddHandler Me._chkLSHARE.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A2F RID: 2607
		' (get) Token: 0x06001DD6 RID: 7638 RVA: 0x00177FE0 File Offset: 0x001761E0
		' (set) Token: 0x06001DD7 RID: 7639 RVA: 0x00177FF8 File Offset: 0x001761F8
		Friend Overridable Property ChkLSHOWBILL As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._ChkLSHOWBILL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._ChkLSHOWBILL IsNot Nothing
				If flag Then
					RemoveHandler Me._ChkLSHOWBILL.KeyPress, AddressOf Me.ChkLSHOWBILL_KeyPress
				End If
				Me._ChkLSHOWBILL = value
				flag = Me._ChkLSHOWBILL IsNot Nothing
				If flag Then
					AddHandler Me._ChkLSHOWBILL.KeyPress, AddressOf Me.ChkLSHOWBILL_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A30 RID: 2608
		' (get) Token: 0x06001DD8 RID: 7640 RVA: 0x00178064 File Offset: 0x00176264
		' (set) Token: 0x06001DD9 RID: 7641 RVA: 0x00006255 File Offset: 0x00004455
		Friend Overridable Property LblSHOWBILL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._LblSHOWBILL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._LblSHOWBILL = value
			End Set
		End Property

		' Token: 0x17000A31 RID: 2609
		' (get) Token: 0x06001DDA RID: 7642 RVA: 0x0017807C File Offset: 0x0017627C
		' (set) Token: 0x06001DDB RID: 7643 RVA: 0x00178094 File Offset: 0x00176294
		Friend Overridable Property ChkLBOLD As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._ChkLBOLD
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._ChkLBOLD IsNot Nothing
				If flag Then
					RemoveHandler Me._ChkLBOLD.KeyPress, AddressOf Me.ChkLBOLD_KeyPress
				End If
				Me._ChkLBOLD = value
				flag = Me._ChkLBOLD IsNot Nothing
				If flag Then
					AddHandler Me._ChkLBOLD.KeyPress, AddressOf Me.ChkLBOLD_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A32 RID: 2610
		' (get) Token: 0x06001DDC RID: 7644 RVA: 0x00178100 File Offset: 0x00176300
		' (set) Token: 0x06001DDD RID: 7645 RVA: 0x0000625F File Offset: 0x0000445F
		Friend Overridable Property lBLBOLD As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lBLBOLD
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lBLBOLD = value
			End Set
		End Property

		' Token: 0x17000A33 RID: 2611
		' (get) Token: 0x06001DDE RID: 7646 RVA: 0x00178118 File Offset: 0x00176318
		' (set) Token: 0x06001DDF RID: 7647 RVA: 0x00006269 File Offset: 0x00004469
		Friend Overridable Property ChkLSHOWPRICE As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._ChkLSHOWPRICE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._ChkLSHOWPRICE = value
			End Set
		End Property

		' Token: 0x17000A34 RID: 2612
		' (get) Token: 0x06001DE0 RID: 7648 RVA: 0x00178130 File Offset: 0x00176330
		' (set) Token: 0x06001DE1 RID: 7649 RVA: 0x00006273 File Offset: 0x00004473
		Friend Overridable Property LblSHOWPRICE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._LblSHOWPRICE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._LblSHOWPRICE = value
			End Set
		End Property

		' Token: 0x17000A35 RID: 2613
		' (get) Token: 0x06001DE2 RID: 7650 RVA: 0x00178148 File Offset: 0x00176348
		' (set) Token: 0x06001DE3 RID: 7651 RVA: 0x0000627D File Offset: 0x0000447D
		Friend Overridable Property lblLSHARE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLSHARE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblLSHARE = value
			End Set
		End Property

		' Token: 0x17000A36 RID: 2614
		' (get) Token: 0x06001DE4 RID: 7652 RVA: 0x00178160 File Offset: 0x00176360
		' (set) Token: 0x06001DE5 RID: 7653 RVA: 0x00006287 File Offset: 0x00004487
		Friend Overridable Property txtTENMAYCALL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENMAYCALL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENMAYCALL = value
			End Set
		End Property

		' Token: 0x17000A37 RID: 2615
		' (get) Token: 0x06001DE6 RID: 7654 RVA: 0x00178178 File Offset: 0x00176378
		' (set) Token: 0x06001DE7 RID: 7655 RVA: 0x00178190 File Offset: 0x00176390
		Friend Overridable Property TxtMAMAYCALL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._TxtMAMAYCALL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._TxtMAMAYCALL IsNot Nothing
				If flag Then
					RemoveHandler Me._TxtMAMAYCALL.KeyPress, AddressOf Me.TxtMAMAYCALL_KeyPress
					RemoveHandler Me._TxtMAMAYCALL.TextChanged, AddressOf Me.TxtMAMAYCALL_TextChanged
				End If
				Me._TxtMAMAYCALL = value
				flag = Me._TxtMAMAYCALL IsNot Nothing
				If flag Then
					AddHandler Me._TxtMAMAYCALL.KeyPress, AddressOf Me.TxtMAMAYCALL_KeyPress
					AddHandler Me._TxtMAMAYCALL.TextChanged, AddressOf Me.TxtMAMAYCALL_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000A38 RID: 2616
		' (get) Token: 0x06001DE8 RID: 7656 RVA: 0x0017822C File Offset: 0x0017642C
		' (set) Token: 0x06001DE9 RID: 7657 RVA: 0x00178244 File Offset: 0x00176444
		Friend Overridable Property btnSECLECTMAYCALL As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSECLECTMAYCALL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSECLECTMAYCALL IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSECLECTMAYCALL.Click, AddressOf Me.btnSECLECTMAYCALL_Click
				End If
				Me._btnSECLECTMAYCALL = value
				flag = Me._btnSECLECTMAYCALL IsNot Nothing
				If flag Then
					AddHandler Me._btnSECLECTMAYCALL.Click, AddressOf Me.btnSECLECTMAYCALL_Click
				End If
			End Set
		End Property

		' Token: 0x17000A39 RID: 2617
		' (get) Token: 0x06001DEA RID: 7658 RVA: 0x001782B0 File Offset: 0x001764B0
		' (set) Token: 0x06001DEB RID: 7659 RVA: 0x00006291 File Offset: 0x00004491
		Friend Overridable Property LblMAMAYTINHCALL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._LblMAMAYTINHCALL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._LblMAMAYTINHCALL = value
			End Set
		End Property

		' Token: 0x17000A3A RID: 2618
		' (get) Token: 0x06001DEC RID: 7660 RVA: 0x001782C8 File Offset: 0x001764C8
		' (set) Token: 0x06001DED RID: 7661 RVA: 0x0000629B File Offset: 0x0000449B
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000A3B RID: 2619
		' (get) Token: 0x06001DEE RID: 7662 RVA: 0x001782E0 File Offset: 0x001764E0
		' (set) Token: 0x06001DEF RID: 7663 RVA: 0x000062A5 File Offset: 0x000044A5
		Friend Overridable Property chkCus As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkCus
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkCus = value
			End Set
		End Property

		' Token: 0x17000A3C RID: 2620
		' (get) Token: 0x06001DF0 RID: 7664 RVA: 0x001782F8 File Offset: 0x001764F8
		' (set) Token: 0x06001DF1 RID: 7665 RVA: 0x000062AF File Offset: 0x000044AF
		Friend Overridable Property lblCus As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCus
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCus = value
			End Set
		End Property

		' Token: 0x17000A3D RID: 2621
		' (get) Token: 0x06001DF2 RID: 7666 RVA: 0x00178310 File Offset: 0x00176510
		' (set) Token: 0x06001DF3 RID: 7667 RVA: 0x000062B9 File Offset: 0x000044B9
		Friend Overridable Property chkService As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkService
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkService = value
			End Set
		End Property

		' Token: 0x17000A3E RID: 2622
		' (get) Token: 0x06001DF4 RID: 7668 RVA: 0x00178328 File Offset: 0x00176528
		' (set) Token: 0x06001DF5 RID: 7669 RVA: 0x000062C3 File Offset: 0x000044C3
		Friend Overridable Property lblSevice As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblSevice
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblSevice = value
			End Set
		End Property

		' Token: 0x17000A3F RID: 2623
		' (get) Token: 0x06001DF6 RID: 7670 RVA: 0x00178340 File Offset: 0x00176540
		' (set) Token: 0x06001DF7 RID: 7671 RVA: 0x000062CD File Offset: 0x000044CD
		Friend Overridable Property ckhCashier As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._ckhCashier
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._ckhCashier = value
			End Set
		End Property

		' Token: 0x17000A40 RID: 2624
		' (get) Token: 0x06001DF8 RID: 7672 RVA: 0x00178358 File Offset: 0x00176558
		' (set) Token: 0x06001DF9 RID: 7673 RVA: 0x000062D7 File Offset: 0x000044D7
		Friend Overridable Property lblCashier As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCashier
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCashier = value
			End Set
		End Property

		' Token: 0x17000A41 RID: 2625
		' (get) Token: 0x06001DFA RID: 7674 RVA: 0x00178370 File Offset: 0x00176570
		' (set) Token: 0x06001DFB RID: 7675 RVA: 0x000062E1 File Offset: 0x000044E1
		Friend Overridable Property chkTable As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkTable
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkTable = value
			End Set
		End Property

		' Token: 0x17000A42 RID: 2626
		' (get) Token: 0x06001DFC RID: 7676 RVA: 0x00178388 File Offset: 0x00176588
		' (set) Token: 0x06001DFD RID: 7677 RVA: 0x000062EB File Offset: 0x000044EB
		Friend Overridable Property lblTable As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTable
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTable = value
			End Set
		End Property

		' Token: 0x17000A43 RID: 2627
		' (get) Token: 0x06001DFE RID: 7678 RVA: 0x001783A0 File Offset: 0x001765A0
		' (set) Token: 0x06001DFF RID: 7679 RVA: 0x000062F5 File Offset: 0x000044F5
		Friend Overridable Property chkDate As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkDate = value
			End Set
		End Property

		' Token: 0x17000A44 RID: 2628
		' (get) Token: 0x06001E00 RID: 7680 RVA: 0x001783B8 File Offset: 0x001765B8
		' (set) Token: 0x06001E01 RID: 7681 RVA: 0x000062FF File Offset: 0x000044FF
		Friend Overridable Property lblDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDate = value
			End Set
		End Property

		' Token: 0x17000A45 RID: 2629
		' (get) Token: 0x06001E02 RID: 7682 RVA: 0x001783D0 File Offset: 0x001765D0
		' (set) Token: 0x06001E03 RID: 7683 RVA: 0x00006309 File Offset: 0x00004509
		Friend Overridable Property chkOrder As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkOrder
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkOrder = value
			End Set
		End Property

		' Token: 0x17000A46 RID: 2630
		' (get) Token: 0x06001E04 RID: 7684 RVA: 0x001783E8 File Offset: 0x001765E8
		' (set) Token: 0x06001E05 RID: 7685 RVA: 0x00006313 File Offset: 0x00004513
		Friend Overridable Property lblOrder As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOrder
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOrder = value
			End Set
		End Property

		' Token: 0x17000A47 RID: 2631
		' (get) Token: 0x06001E06 RID: 7686 RVA: 0x00178400 File Offset: 0x00176600
		' (set) Token: 0x06001E07 RID: 7687 RVA: 0x0000631D File Offset: 0x0000451D
		Friend Overridable Property txtPrintWidth As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPrintWidth
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtPrintWidth = value
			End Set
		End Property

		' Token: 0x17000A48 RID: 2632
		' (get) Token: 0x06001E08 RID: 7688 RVA: 0x00178418 File Offset: 0x00176618
		' (set) Token: 0x06001E09 RID: 7689 RVA: 0x00006327 File Offset: 0x00004527
		Friend Overridable Property lblPrintW As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPrintW
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPrintW = value
			End Set
		End Property

		' Token: 0x17000A49 RID: 2633
		' (get) Token: 0x06001E0A RID: 7690 RVA: 0x00178430 File Offset: 0x00176630
		' (set) Token: 0x06001E0B RID: 7691 RVA: 0x00006331 File Offset: 0x00004531
		Friend Overridable Property chkSplit As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkSplit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkSplit = value
			End Set
		End Property

		' Token: 0x17000A4A RID: 2634
		' (get) Token: 0x06001E0C RID: 7692 RVA: 0x00178448 File Offset: 0x00176648
		' (set) Token: 0x06001E0D RID: 7693 RVA: 0x0000633B File Offset: 0x0000453B
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000A4B RID: 2635
		' (get) Token: 0x06001E0E RID: 7694 RVA: 0x00178460 File Offset: 0x00176660
		' (set) Token: 0x06001E0F RID: 7695 RVA: 0x00006345 File Offset: 0x00004545
		Friend Overridable Property chkLCALL As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLCALL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLCALL = value
			End Set
		End Property

		' Token: 0x17000A4C RID: 2636
		' (get) Token: 0x06001E10 RID: 7696 RVA: 0x00178478 File Offset: 0x00176678
		' (set) Token: 0x06001E11 RID: 7697 RVA: 0x0000634F File Offset: 0x0000454F
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000A4D RID: 2637
		' (get) Token: 0x06001E12 RID: 7698 RVA: 0x00178490 File Offset: 0x00176690
		' (set) Token: 0x06001E13 RID: 7699 RVA: 0x00006359 File Offset: 0x00004559
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x17000A4E RID: 2638
		' (get) Token: 0x06001E14 RID: 7700 RVA: 0x001784A8 File Offset: 0x001766A8
		' (set) Token: 0x06001E15 RID: 7701 RVA: 0x001784C0 File Offset: 0x001766C0
		Friend Overridable Property cmbLTENHHFORMAT1 As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbLTENHHFORMAT1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbLTENHHFORMAT1 IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbLTENHHFORMAT1.VisibleChanged, AddressOf Me.cmbLTENHHFORMAT1_VisibleChanged
					RemoveHandler Me._cmbLTENHHFORMAT1.SelectionChangeCommitted, AddressOf Me.cmbLTENHHFORMAT1_SelectionChangeCommitted
				End If
				Me._cmbLTENHHFORMAT1 = value
				flag = Me._cmbLTENHHFORMAT1 IsNot Nothing
				If flag Then
					AddHandler Me._cmbLTENHHFORMAT1.VisibleChanged, AddressOf Me.cmbLTENHHFORMAT1_VisibleChanged
					AddHandler Me._cmbLTENHHFORMAT1.SelectionChangeCommitted, AddressOf Me.cmbLTENHHFORMAT1_SelectionChangeCommitted
				End If
			End Set
		End Property

		' Token: 0x17000A4F RID: 2639
		' (get) Token: 0x06001E16 RID: 7702 RVA: 0x0017855C File Offset: 0x0017675C
		' (set) Token: 0x06001E17 RID: 7703 RVA: 0x00006363 File Offset: 0x00004563
		Friend Overridable Property chkLSHOWLIEN As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLSHOWLIEN
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLSHOWLIEN = value
			End Set
		End Property

		' Token: 0x17000A50 RID: 2640
		' (get) Token: 0x06001E18 RID: 7704 RVA: 0x00178574 File Offset: 0x00176774
		' (set) Token: 0x06001E19 RID: 7705 RVA: 0x0000636D File Offset: 0x0000456D
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x17000A51 RID: 2641
		' (get) Token: 0x06001E1A RID: 7706 RVA: 0x0017858C File Offset: 0x0017678C
		' (set) Token: 0x06001E1B RID: 7707 RVA: 0x00006377 File Offset: 0x00004577
		Friend Overridable Property Label8 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label8 = value
			End Set
		End Property

		' Token: 0x17000A52 RID: 2642
		' (get) Token: 0x06001E1C RID: 7708 RVA: 0x001785A4 File Offset: 0x001767A4
		' (set) Token: 0x06001E1D RID: 7709 RVA: 0x00006381 File Offset: 0x00004581
		Friend Overridable Property Label7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		' Token: 0x17000A53 RID: 2643
		' (get) Token: 0x06001E1E RID: 7710 RVA: 0x001785BC File Offset: 0x001767BC
		' (set) Token: 0x06001E1F RID: 7711 RVA: 0x0000638B File Offset: 0x0000458B
		Friend Overridable Property Label6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label6 = value
			End Set
		End Property

		' Token: 0x17000A54 RID: 2644
		' (get) Token: 0x06001E20 RID: 7712 RVA: 0x001785D4 File Offset: 0x001767D4
		' (set) Token: 0x06001E21 RID: 7713 RVA: 0x00006395 File Offset: 0x00004595
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x17000A55 RID: 2645
		' (get) Token: 0x06001E22 RID: 7714 RVA: 0x001785EC File Offset: 0x001767EC
		' (set) Token: 0x06001E23 RID: 7715 RVA: 0x0000639F File Offset: 0x0000459F
		Friend Overridable Property txtRight As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtRight
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtRight = value
			End Set
		End Property

		' Token: 0x17000A56 RID: 2646
		' (get) Token: 0x06001E24 RID: 7716 RVA: 0x00178604 File Offset: 0x00176804
		' (set) Token: 0x06001E25 RID: 7717 RVA: 0x000063A9 File Offset: 0x000045A9
		Friend Overridable Property Label9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label9 = value
			End Set
		End Property

		' Token: 0x17000A57 RID: 2647
		' (get) Token: 0x06001E26 RID: 7718 RVA: 0x0017861C File Offset: 0x0017681C
		' (set) Token: 0x06001E27 RID: 7719 RVA: 0x000063B3 File Offset: 0x000045B3
		Friend Overridable Property txtBottom As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBottom
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtBottom = value
			End Set
		End Property

		' Token: 0x17000A58 RID: 2648
		' (get) Token: 0x06001E28 RID: 7720 RVA: 0x00178634 File Offset: 0x00176834
		' (set) Token: 0x06001E29 RID: 7721 RVA: 0x000063BD File Offset: 0x000045BD
		Friend Overridable Property Label10 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label10 = value
			End Set
		End Property

		' Token: 0x17000A59 RID: 2649
		' (get) Token: 0x06001E2A RID: 7722 RVA: 0x0017864C File Offset: 0x0017684C
		' (set) Token: 0x06001E2B RID: 7723 RVA: 0x000063C7 File Offset: 0x000045C7
		Friend Overridable Property txtLEFT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtLEFT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtLEFT = value
			End Set
		End Property

		' Token: 0x17000A5A RID: 2650
		' (get) Token: 0x06001E2C RID: 7724 RVA: 0x00178664 File Offset: 0x00176864
		' (set) Token: 0x06001E2D RID: 7725 RVA: 0x000063D1 File Offset: 0x000045D1
		Friend Overridable Property Label11 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label11
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label11 = value
			End Set
		End Property

		' Token: 0x17000A5B RID: 2651
		' (get) Token: 0x06001E2E RID: 7726 RVA: 0x0017867C File Offset: 0x0017687C
		' (set) Token: 0x06001E2F RID: 7727 RVA: 0x000063DB File Offset: 0x000045DB
		Friend Overridable Property txtTOP As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTOP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTOP = value
			End Set
		End Property

		' Token: 0x17000A5C RID: 2652
		' (get) Token: 0x06001E30 RID: 7728 RVA: 0x00178694 File Offset: 0x00176894
		' (set) Token: 0x06001E31 RID: 7729 RVA: 0x000063E5 File Offset: 0x000045E5
		Friend Overridable Property Label12 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label12
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label12 = value
			End Set
		End Property

		' Token: 0x17000A5D RID: 2653
		' (get) Token: 0x06001E32 RID: 7730 RVA: 0x001786AC File Offset: 0x001768AC
		' (set) Token: 0x06001E33 RID: 7731 RVA: 0x000063EF File Offset: 0x000045EF
		Friend Overridable Property chkLKITREMARK1LINE As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLKITREMARK1LINE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLKITREMARK1LINE = value
			End Set
		End Property

		' Token: 0x17000A5E RID: 2654
		' (get) Token: 0x06001E34 RID: 7732 RVA: 0x001786C4 File Offset: 0x001768C4
		' (set) Token: 0x06001E35 RID: 7733 RVA: 0x000063F9 File Offset: 0x000045F9
		Friend Overridable Property Label13 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label13
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label13 = value
			End Set
		End Property

		' Token: 0x17000A5F RID: 2655
		' (get) Token: 0x06001E36 RID: 7734 RVA: 0x001786DC File Offset: 0x001768DC
		' (set) Token: 0x06001E37 RID: 7735 RVA: 0x00006403 File Offset: 0x00004603
		Friend Overridable Property cmbDKSOLUONG As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbDKSOLUONG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Me._cmbDKSOLUONG = value
			End Set
		End Property

		' Token: 0x17000A60 RID: 2656
		' (get) Token: 0x06001E38 RID: 7736 RVA: 0x001786F4 File Offset: 0x001768F4
		' (set) Token: 0x06001E39 RID: 7737 RVA: 0x0000640D File Offset: 0x0000460D
		Friend Overridable Property Label14 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label14
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label14 = value
			End Set
		End Property

		' Token: 0x17000A61 RID: 2657
		' (get) Token: 0x06001E3A RID: 7738 RVA: 0x0017870C File Offset: 0x0017690C
		' (set) Token: 0x06001E3B RID: 7739 RVA: 0x00006417 File Offset: 0x00004617
		Friend Overridable Property Label15 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label15
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label15 = value
			End Set
		End Property

		' Token: 0x17000A62 RID: 2658
		' (get) Token: 0x06001E3C RID: 7740 RVA: 0x00178724 File Offset: 0x00176924
		' (set) Token: 0x06001E3D RID: 7741 RVA: 0x00006421 File Offset: 0x00004621
		Friend Overridable Property chkDVT As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkDVT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkDVT = value
			End Set
		End Property

		' Token: 0x17000A63 RID: 2659
		' (get) Token: 0x06001E3E RID: 7742 RVA: 0x0017873C File Offset: 0x0017693C
		' (set) Token: 0x06001E3F RID: 7743 RVA: 0x0000642B File Offset: 0x0000462B
		Friend Overridable Property GroupBox1 As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._GroupBox1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox1 = value
			End Set
		End Property

		' Token: 0x17000A64 RID: 2660
		' (get) Token: 0x06001E40 RID: 7744 RVA: 0x00178754 File Offset: 0x00176954
		' (set) Token: 0x06001E41 RID: 7745 RVA: 0x00006435 File Offset: 0x00004635
		Friend Overridable Property txtBEPFONT1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBEPFONT1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtBEPFONT1 = value
			End Set
		End Property

		' Token: 0x17000A65 RID: 2661
		' (get) Token: 0x06001E42 RID: 7746 RVA: 0x0017876C File Offset: 0x0017696C
		' (set) Token: 0x06001E43 RID: 7747 RVA: 0x00178784 File Offset: 0x00176984
		Friend Overridable Property txtBEPSIZE1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBEPSIZE1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtBEPSIZE1 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtBEPSIZE1.TextChanged, AddressOf Me.txtBEPSIZE1_TextChanged
				End If
				Me._txtBEPSIZE1 = value
				flag = Me._txtBEPSIZE1 IsNot Nothing
				If flag Then
					AddHandler Me._txtBEPSIZE1.TextChanged, AddressOf Me.txtBEPSIZE1_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000A66 RID: 2662
		' (get) Token: 0x06001E44 RID: 7748 RVA: 0x001787F0 File Offset: 0x001769F0
		' (set) Token: 0x06001E45 RID: 7749 RVA: 0x0000643F File Offset: 0x0000463F
		Friend Overridable Property chkBEPI1 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkBEPI1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkBEPI1 = value
			End Set
		End Property

		' Token: 0x17000A67 RID: 2663
		' (get) Token: 0x06001E46 RID: 7750 RVA: 0x00178808 File Offset: 0x00176A08
		' (set) Token: 0x06001E47 RID: 7751 RVA: 0x00006449 File Offset: 0x00004649
		Friend Overridable Property chkBEPB1 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkBEPB1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkBEPB1 = value
			End Set
		End Property

		' Token: 0x17000A68 RID: 2664
		' (get) Token: 0x06001E48 RID: 7752 RVA: 0x00178820 File Offset: 0x00176A20
		' (set) Token: 0x06001E49 RID: 7753 RVA: 0x00006453 File Offset: 0x00004653
		Friend Overridable Property GroupBox2 As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._GroupBox2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox2 = value
			End Set
		End Property

		' Token: 0x17000A69 RID: 2665
		' (get) Token: 0x06001E4A RID: 7754 RVA: 0x00178838 File Offset: 0x00176A38
		' (set) Token: 0x06001E4B RID: 7755 RVA: 0x0000645D File Offset: 0x0000465D
		Friend Overridable Property GroupBox3 As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._GroupBox3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox3 = value
			End Set
		End Property

		' Token: 0x17000A6A RID: 2666
		' (get) Token: 0x06001E4C RID: 7756 RVA: 0x00178850 File Offset: 0x00176A50
		' (set) Token: 0x06001E4D RID: 7757 RVA: 0x00006467 File Offset: 0x00004667
		Friend Overridable Property txtBEPFONT2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBEPFONT2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtBEPFONT2 = value
			End Set
		End Property

		' Token: 0x17000A6B RID: 2667
		' (get) Token: 0x06001E4E RID: 7758 RVA: 0x00178868 File Offset: 0x00176A68
		' (set) Token: 0x06001E4F RID: 7759 RVA: 0x00178880 File Offset: 0x00176A80
		Friend Overridable Property txtBEPSIZE2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBEPSIZE2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtBEPSIZE2 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtBEPSIZE2.TextChanged, AddressOf Me.txtBEPSIZE2_TextChanged
				End If
				Me._txtBEPSIZE2 = value
				flag = Me._txtBEPSIZE2 IsNot Nothing
				If flag Then
					AddHandler Me._txtBEPSIZE2.TextChanged, AddressOf Me.txtBEPSIZE2_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000A6C RID: 2668
		' (get) Token: 0x06001E50 RID: 7760 RVA: 0x001788EC File Offset: 0x00176AEC
		' (set) Token: 0x06001E51 RID: 7761 RVA: 0x00006471 File Offset: 0x00004671
		Friend Overridable Property chkBEPI2 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkBEPI2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkBEPI2 = value
			End Set
		End Property

		' Token: 0x17000A6D RID: 2669
		' (get) Token: 0x06001E52 RID: 7762 RVA: 0x00178904 File Offset: 0x00176B04
		' (set) Token: 0x06001E53 RID: 7763 RVA: 0x0000647B File Offset: 0x0000467B
		Friend Overridable Property chkBEPB2 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkBEPB2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkBEPB2 = value
			End Set
		End Property

		' Token: 0x17000A6E RID: 2670
		' (get) Token: 0x06001E54 RID: 7764 RVA: 0x0017891C File Offset: 0x00176B1C
		' (set) Token: 0x06001E55 RID: 7765 RVA: 0x00006485 File Offset: 0x00004685
		Friend Overridable Property txtBEPFONT3 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBEPFONT3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtBEPFONT3 = value
			End Set
		End Property

		' Token: 0x17000A6F RID: 2671
		' (get) Token: 0x06001E56 RID: 7766 RVA: 0x00178934 File Offset: 0x00176B34
		' (set) Token: 0x06001E57 RID: 7767 RVA: 0x0017894C File Offset: 0x00176B4C
		Friend Overridable Property txtBEPSIZE3 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBEPSIZE3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtBEPSIZE3 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtBEPSIZE3.TextChanged, AddressOf Me.txtBEPSIZE3_TextChanged
				End If
				Me._txtBEPSIZE3 = value
				flag = Me._txtBEPSIZE3 IsNot Nothing
				If flag Then
					AddHandler Me._txtBEPSIZE3.TextChanged, AddressOf Me.txtBEPSIZE3_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000A70 RID: 2672
		' (get) Token: 0x06001E58 RID: 7768 RVA: 0x001789B8 File Offset: 0x00176BB8
		' (set) Token: 0x06001E59 RID: 7769 RVA: 0x0000648F File Offset: 0x0000468F
		Friend Overridable Property chkBEPI3 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkBEPI3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkBEPI3 = value
			End Set
		End Property

		' Token: 0x17000A71 RID: 2673
		' (get) Token: 0x06001E5A RID: 7770 RVA: 0x001789D0 File Offset: 0x00176BD0
		' (set) Token: 0x06001E5B RID: 7771 RVA: 0x00006499 File Offset: 0x00004699
		Friend Overridable Property chkBEPB3 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkBEPB3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkBEPB3 = value
			End Set
		End Property

		' Token: 0x17000A72 RID: 2674
		' (get) Token: 0x06001E5C RID: 7772 RVA: 0x001789E8 File Offset: 0x00176BE8
		' (set) Token: 0x06001E5D RID: 7773 RVA: 0x00178A00 File Offset: 0x00176C00
		Friend Overridable Property cmbLTENHHFORMAT2 As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbLTENHHFORMAT2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbLTENHHFORMAT2 IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbLTENHHFORMAT2.VisibleChanged, AddressOf Me.cmbLTENHHFORMAT2_VisibleChanged
					RemoveHandler Me._cmbLTENHHFORMAT2.SelectionChangeCommitted, AddressOf Me.cmbLTENHHFORMAT2_SelectionChangeCommitted
				End If
				Me._cmbLTENHHFORMAT2 = value
				flag = Me._cmbLTENHHFORMAT2 IsNot Nothing
				If flag Then
					AddHandler Me._cmbLTENHHFORMAT2.VisibleChanged, AddressOf Me.cmbLTENHHFORMAT2_VisibleChanged
					AddHandler Me._cmbLTENHHFORMAT2.SelectionChangeCommitted, AddressOf Me.cmbLTENHHFORMAT2_SelectionChangeCommitted
				End If
			End Set
		End Property

		' Token: 0x17000A73 RID: 2675
		' (get) Token: 0x06001E5E RID: 7774 RVA: 0x00178A9C File Offset: 0x00176C9C
		' (set) Token: 0x06001E5F RID: 7775 RVA: 0x00178AB4 File Offset: 0x00176CB4
		Friend Overridable Property cmbLTENHHFORMAT3 As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbLTENHHFORMAT3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbLTENHHFORMAT3 IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbLTENHHFORMAT3.VisibleChanged, AddressOf Me.cmbLTENHHFORMAT3_VisibleChanged
					RemoveHandler Me._cmbLTENHHFORMAT3.SelectionChangeCommitted, AddressOf Me.cmbLTENHHFORMAT3_SelectionChangeCommitted
				End If
				Me._cmbLTENHHFORMAT3 = value
				flag = Me._cmbLTENHHFORMAT3 IsNot Nothing
				If flag Then
					AddHandler Me._cmbLTENHHFORMAT3.VisibleChanged, AddressOf Me.cmbLTENHHFORMAT3_VisibleChanged
					AddHandler Me._cmbLTENHHFORMAT3.SelectionChangeCommitted, AddressOf Me.cmbLTENHHFORMAT3_SelectionChangeCommitted
				End If
			End Set
		End Property

		' Token: 0x17000A74 RID: 2676
		' (get) Token: 0x06001E60 RID: 7776 RVA: 0x00178B50 File Offset: 0x00176D50
		' (set) Token: 0x06001E61 RID: 7777 RVA: 0x000064A3 File Offset: 0x000046A3
		Friend Overridable Property Label16 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label16
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label16 = value
			End Set
		End Property

		' Token: 0x17000A75 RID: 2677
		' (get) Token: 0x06001E62 RID: 7778 RVA: 0x00178B68 File Offset: 0x00176D68
		' (set) Token: 0x06001E63 RID: 7779 RVA: 0x00178B80 File Offset: 0x00176D80
		Friend Overridable Property chkLCach1Dong As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLCach1Dong
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLCach1Dong IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLCach1Dong.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
				Me._chkLCach1Dong = value
				flag = Me._chkLCach1Dong IsNot Nothing
				If flag Then
					AddHandler Me._chkLCach1Dong.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A76 RID: 2678
		' (get) Token: 0x06001E64 RID: 7780 RVA: 0x00178BEC File Offset: 0x00176DEC
		' (set) Token: 0x06001E65 RID: 7781 RVA: 0x00178C04 File Offset: 0x00176E04
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x17000A77 RID: 2679
		' (get) Token: 0x06001E66 RID: 7782 RVA: 0x00178C70 File Offset: 0x00176E70
		' (set) Token: 0x06001E67 RID: 7783 RVA: 0x000064AD File Offset: 0x000046AD
		Friend Overridable Property lblSTT As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblSTT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblSTT = value
			End Set
		End Property

		' Token: 0x17000A78 RID: 2680
		' (get) Token: 0x06001E68 RID: 7784 RVA: 0x00178C88 File Offset: 0x00176E88
		' (set) Token: 0x06001E69 RID: 7785 RVA: 0x000064B7 File Offset: 0x000046B7
		Friend Overridable Property chkSTT As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkSTT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkSTT = value
			End Set
		End Property

		' Token: 0x17000A79 RID: 2681
		' (get) Token: 0x06001E6A RID: 7786 RVA: 0x00178CA0 File Offset: 0x00176EA0
		' (set) Token: 0x06001E6B RID: 7787 RVA: 0x000064C1 File Offset: 0x000046C1
		Friend Overridable Property Label17 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label17
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label17 = value
			End Set
		End Property

		' Token: 0x17000A7A RID: 2682
		' (get) Token: 0x06001E6C RID: 7788 RVA: 0x00178CB8 File Offset: 0x00176EB8
		' (set) Token: 0x06001E6D RID: 7789 RVA: 0x000064CB File Offset: 0x000046CB
		Friend Overridable Property chkLSHOWTITLE As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLSHOWTITLE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLSHOWTITLE = value
			End Set
		End Property

		' Token: 0x17000A7B RID: 2683
		' (get) Token: 0x06001E6E RID: 7790 RVA: 0x00178CD0 File Offset: 0x00176ED0
		' (set) Token: 0x06001E6F RID: 7791 RVA: 0x000064D5 File Offset: 0x000046D5
		Friend Overridable Property lblSplitSL1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblSplitSL1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblSplitSL1 = value
			End Set
		End Property

		' Token: 0x17000A7C RID: 2684
		' (get) Token: 0x06001E70 RID: 7792 RVA: 0x00178CE8 File Offset: 0x00176EE8
		' (set) Token: 0x06001E71 RID: 7793 RVA: 0x00178D00 File Offset: 0x00176F00
		Friend Overridable Property chkSplitSL1 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkSplitSL1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkSplitSL1 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkSplitSL1.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
				Me._chkSplitSL1 = value
				flag = Me._chkSplitSL1 IsNot Nothing
				If flag Then
					AddHandler Me._chkSplitSL1.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A7D RID: 2685
		' (get) Token: 0x06001E72 RID: 7794 RVA: 0x00178D6C File Offset: 0x00176F6C
		' (set) Token: 0x06001E73 RID: 7795 RVA: 0x000064DF File Offset: 0x000046DF
		Friend Overridable Property Label18 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label18
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label18 = value
			End Set
		End Property

		' Token: 0x17000A7E RID: 2686
		' (get) Token: 0x06001E74 RID: 7796 RVA: 0x00178D84 File Offset: 0x00176F84
		' (set) Token: 0x06001E75 RID: 7797 RVA: 0x000064E9 File Offset: 0x000046E9
		Friend Overridable Property chkLGachSLAm As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLGachSLAm
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLGachSLAm = value
			End Set
		End Property

		' Token: 0x17000A7F RID: 2687
		' (get) Token: 0x06001E76 RID: 7798 RVA: 0x00178D9C File Offset: 0x00176F9C
		' (set) Token: 0x06001E77 RID: 7799 RVA: 0x000064F3 File Offset: 0x000046F3
		Friend Overridable Property Label19 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label19
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label19 = value
			End Set
		End Property

		' Token: 0x17000A80 RID: 2688
		' (get) Token: 0x06001E78 RID: 7800 RVA: 0x00178DB4 File Offset: 0x00176FB4
		' (set) Token: 0x06001E79 RID: 7801 RVA: 0x00178DCC File Offset: 0x00176FCC
		Friend Overridable Property chkLPrice1Line As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLPrice1Line
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLPrice1Line IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLPrice1Line.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
				Me._chkLPrice1Line = value
				flag = Me._chkLPrice1Line IsNot Nothing
				If flag Then
					AddHandler Me._chkLPrice1Line.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A81 RID: 2689
		' (get) Token: 0x06001E7A RID: 7802 RVA: 0x00178E38 File Offset: 0x00177038
		' (set) Token: 0x06001E7B RID: 7803 RVA: 0x000064FD File Offset: 0x000046FD
		Friend Overridable Property Label20 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label20
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label20 = value
			End Set
		End Property

		' Token: 0x17000A82 RID: 2690
		' (get) Token: 0x06001E7C RID: 7804 RVA: 0x00178E50 File Offset: 0x00177050
		' (set) Token: 0x06001E7D RID: 7805 RVA: 0x00006507 File Offset: 0x00004707
		Friend Overridable Property chkLSHOWMAHH As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLSHOWMAHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLSHOWMAHH = value
			End Set
		End Property

		' Token: 0x17000A83 RID: 2691
		' (get) Token: 0x06001E7E RID: 7806 RVA: 0x00178E68 File Offset: 0x00177068
		' (set) Token: 0x06001E7F RID: 7807 RVA: 0x00006511 File Offset: 0x00004711
		Friend Overridable Property Label21 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label21
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label21 = value
			End Set
		End Property

		' Token: 0x17000A84 RID: 2692
		' (get) Token: 0x06001E80 RID: 7808 RVA: 0x00178E80 File Offset: 0x00177080
		' (set) Token: 0x06001E81 RID: 7809 RVA: 0x00178E98 File Offset: 0x00177098
		Friend Overridable Property chkLShowSLCombo As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLShowSLCombo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLShowSLCombo IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLShowSLCombo.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
				Me._chkLShowSLCombo = value
				flag = Me._chkLShowSLCombo IsNot Nothing
				If flag Then
					AddHandler Me._chkLShowSLCombo.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A85 RID: 2693
		' (get) Token: 0x06001E82 RID: 7810 RVA: 0x00178F04 File Offset: 0x00177104
		' (set) Token: 0x06001E83 RID: 7811 RVA: 0x0000651B File Offset: 0x0000471B
		Friend Overridable Property Label22 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label22
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label22 = value
			End Set
		End Property

		' Token: 0x17000A86 RID: 2694
		' (get) Token: 0x06001E84 RID: 7812 RVA: 0x00178F1C File Offset: 0x0017711C
		' (set) Token: 0x06001E85 RID: 7813 RVA: 0x00006525 File Offset: 0x00004725
		Friend Overridable Property chkLSHOWLYDOXOA As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLSHOWLYDOXOA
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLSHOWLYDOXOA = value
			End Set
		End Property

		' Token: 0x17000A87 RID: 2695
		' (get) Token: 0x06001E86 RID: 7814 RVA: 0x00178F34 File Offset: 0x00177134
		' (set) Token: 0x06001E87 RID: 7815 RVA: 0x0000652F File Offset: 0x0000472F
		Friend Overridable Property Label23 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label23
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label23 = value
			End Set
		End Property

		' Token: 0x17000A88 RID: 2696
		' (get) Token: 0x06001E88 RID: 7816 RVA: 0x00178F4C File Offset: 0x0017714C
		' (set) Token: 0x06001E89 RID: 7817 RVA: 0x00006539 File Offset: 0x00004739
		Friend Overridable Property Label24 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label24
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label24 = value
			End Set
		End Property

		' Token: 0x17000A89 RID: 2697
		' (get) Token: 0x06001E8A RID: 7818 RVA: 0x00178F64 File Offset: 0x00177164
		' (set) Token: 0x06001E8B RID: 7819 RVA: 0x00178F7C File Offset: 0x0017717C
		Friend Overridable Property chkLInChuyenBan As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLInChuyenBan
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLInChuyenBan IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLInChuyenBan.CheckedChanged, AddressOf Me.chkLInChuyenBan_CheckedChanged
				End If
				Me._chkLInChuyenBan = value
				flag = Me._chkLInChuyenBan IsNot Nothing
				If flag Then
					AddHandler Me._chkLInChuyenBan.CheckedChanged, AddressOf Me.chkLInChuyenBan_CheckedChanged
				End If
			End Set
		End Property

		' Token: 0x17000A8A RID: 2698
		' (get) Token: 0x06001E8C RID: 7820 RVA: 0x00178FE8 File Offset: 0x001771E8
		' (set) Token: 0x06001E8D RID: 7821 RVA: 0x00006543 File Offset: 0x00004743
		Friend Overridable Property Label25 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label25
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label25 = value
			End Set
		End Property

		' Token: 0x17000A8B RID: 2699
		' (get) Token: 0x06001E8E RID: 7822 RVA: 0x00179000 File Offset: 0x00177200
		' (set) Token: 0x06001E8F RID: 7823 RVA: 0x0000654D File Offset: 0x0000474D
		Friend Overridable Property Label26 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label26
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label26 = value
			End Set
		End Property

		' Token: 0x17000A8C RID: 2700
		' (get) Token: 0x06001E90 RID: 7824 RVA: 0x00179018 File Offset: 0x00177218
		' (set) Token: 0x06001E91 RID: 7825 RVA: 0x00006557 File Offset: 0x00004757
		Friend Overridable Property chkLInChuyenMon As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLInChuyenMon
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLInChuyenMon = value
			End Set
		End Property

		' Token: 0x17000A8D RID: 2701
		' (get) Token: 0x06001E92 RID: 7826 RVA: 0x00179030 File Offset: 0x00177230
		' (set) Token: 0x06001E93 RID: 7827 RVA: 0x00006561 File Offset: 0x00004761
		Friend Overridable Property lblLInChuyenMon As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLInChuyenMon
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblLInChuyenMon = value
			End Set
		End Property

		' Token: 0x17000A8E RID: 2702
		' (get) Token: 0x06001E94 RID: 7828 RVA: 0x00179048 File Offset: 0x00177248
		' (set) Token: 0x06001E95 RID: 7829 RVA: 0x0000656B File Offset: 0x0000476B
		Friend Overridable Property Label27 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label27
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label27 = value
			End Set
		End Property

		' Token: 0x17000A8F RID: 2703
		' (get) Token: 0x06001E96 RID: 7830 RVA: 0x00179060 File Offset: 0x00177260
		' (set) Token: 0x06001E97 RID: 7831 RVA: 0x00006575 File Offset: 0x00004775
		Friend Overridable Property chkKhu As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkKhu
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkKhu = value
			End Set
		End Property

		' Token: 0x17000A90 RID: 2704
		' (get) Token: 0x06001E98 RID: 7832 RVA: 0x00179078 File Offset: 0x00177278
		' (set) Token: 0x06001E99 RID: 7833 RVA: 0x0000657F File Offset: 0x0000477F
		Friend Overridable Property Label28 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label28
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label28 = value
			End Set
		End Property

		' Token: 0x17000A91 RID: 2705
		' (get) Token: 0x06001E9A RID: 7834 RVA: 0x00179090 File Offset: 0x00177290
		' (set) Token: 0x06001E9B RID: 7835 RVA: 0x00006589 File Offset: 0x00004789
		Friend Overridable Property chkTongSL As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkTongSL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkTongSL = value
			End Set
		End Property

		' Token: 0x17000A92 RID: 2706
		' (get) Token: 0x06001E9C RID: 7836 RVA: 0x001790A8 File Offset: 0x001772A8
		' (set) Token: 0x06001E9D RID: 7837 RVA: 0x00006593 File Offset: 0x00004793
		Friend Overridable Property grpLogo As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpLogo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpLogo = value
			End Set
		End Property

		' Token: 0x17000A93 RID: 2707
		' (get) Token: 0x06001E9E RID: 7838 RVA: 0x001790C0 File Offset: 0x001772C0
		' (set) Token: 0x06001E9F RID: 7839 RVA: 0x0000659D File Offset: 0x0000479D
		Friend Overridable Property Label29 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label29
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label29 = value
			End Set
		End Property

		' Token: 0x17000A94 RID: 2708
		' (get) Token: 0x06001EA0 RID: 7840 RVA: 0x001790D8 File Offset: 0x001772D8
		' (set) Token: 0x06001EA1 RID: 7841 RVA: 0x000065A7 File Offset: 0x000047A7
		Friend Overridable Property chkLShowLogo As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLShowLogo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLShowLogo = value
			End Set
		End Property

		' Token: 0x17000A95 RID: 2709
		' (get) Token: 0x06001EA2 RID: 7842 RVA: 0x001790F0 File Offset: 0x001772F0
		' (set) Token: 0x06001EA3 RID: 7843 RVA: 0x000065B1 File Offset: 0x000047B1
		Friend Overridable Property picpreview As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picpreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._picpreview = value
			End Set
		End Property

		' Token: 0x17000A96 RID: 2710
		' (get) Token: 0x06001EA4 RID: 7844 RVA: 0x00179108 File Offset: 0x00177308
		' (set) Token: 0x06001EA5 RID: 7845 RVA: 0x00179120 File Offset: 0x00177320
		Friend Overridable Property btnBrowse2 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnBrowse2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnBrowse2 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnBrowse2.Click, AddressOf Me.btnBrowse2_Click
				End If
				Me._btnBrowse2 = value
				flag = Me._btnBrowse2 IsNot Nothing
				If flag Then
					AddHandler Me._btnBrowse2.Click, AddressOf Me.btnBrowse2_Click
				End If
			End Set
		End Property

		' Token: 0x17000A97 RID: 2711
		' (get) Token: 0x06001EA6 RID: 7846 RVA: 0x0017918C File Offset: 0x0017738C
		' (set) Token: 0x06001EA7 RID: 7847 RVA: 0x000065BB File Offset: 0x000047BB
		Friend Overridable Property chkLSortNH As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLSortNH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLSortNH = value
			End Set
		End Property

		' Token: 0x17000A98 RID: 2712
		' (get) Token: 0x06001EA8 RID: 7848 RVA: 0x001791A4 File Offset: 0x001773A4
		' (set) Token: 0x06001EA9 RID: 7849 RVA: 0x000065C5 File Offset: 0x000047C5
		Friend Overridable Property Label30 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label30
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label30 = value
			End Set
		End Property

		' Token: 0x17000A99 RID: 2713
		' (get) Token: 0x06001EAA RID: 7850 RVA: 0x001791BC File Offset: 0x001773BC
		' (set) Token: 0x06001EAB RID: 7851 RVA: 0x000065CF File Offset: 0x000047CF
		Friend Overridable Property Label32 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label32
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label32 = value
			End Set
		End Property

		' Token: 0x17000A9A RID: 2714
		' (get) Token: 0x06001EAC RID: 7852 RVA: 0x001791D4 File Offset: 0x001773D4
		' (set) Token: 0x06001EAD RID: 7853 RVA: 0x000065D9 File Offset: 0x000047D9
		Friend Overridable Property chkLShowCus As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLShowCus
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLShowCus = value
			End Set
		End Property

		' Token: 0x17000A9B RID: 2715
		' (get) Token: 0x06001EAE RID: 7854 RVA: 0x001791EC File Offset: 0x001773EC
		' (set) Token: 0x06001EAF RID: 7855 RVA: 0x000065E3 File Offset: 0x000047E3
		Friend Overridable Property Label31 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label31
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label31 = value
			End Set
		End Property

		' Token: 0x17000A9C RID: 2716
		' (get) Token: 0x06001EB0 RID: 7856 RVA: 0x00179204 File Offset: 0x00177404
		' (set) Token: 0x06001EB1 RID: 7857 RVA: 0x0017921C File Offset: 0x0017741C
		Friend Overridable Property chkLShowSLMain As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLShowSLMain
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLShowSLMain IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLShowSLMain.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
				Me._chkLShowSLMain = value
				flag = Me._chkLShowSLMain IsNot Nothing
				If flag Then
					AddHandler Me._chkLShowSLMain.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A9D RID: 2717
		' (get) Token: 0x06001EB2 RID: 7858 RVA: 0x00179288 File Offset: 0x00177488
		' (set) Token: 0x06001EB3 RID: 7859 RVA: 0x000065ED File Offset: 0x000047ED
		Friend Overridable Property lblSTTPerItem As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblSTTPerItem
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblSTTPerItem = value
			End Set
		End Property

		' Token: 0x17000A9E RID: 2718
		' (get) Token: 0x06001EB4 RID: 7860 RVA: 0x001792A0 File Offset: 0x001774A0
		' (set) Token: 0x06001EB5 RID: 7861 RVA: 0x001792B8 File Offset: 0x001774B8
		Friend Overridable Property chkSTTPerItem As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkSTTPerItem
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkSTTPerItem IsNot Nothing
				If flag Then
					RemoveHandler Me._chkSTTPerItem.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
				Me._chkSTTPerItem = value
				flag = Me._chkSTTPerItem IsNot Nothing
				If flag Then
					AddHandler Me._chkSTTPerItem.KeyPress, AddressOf Me.chkDungChung_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000A9F RID: 2719
		' (get) Token: 0x06001EB6 RID: 7862 RVA: 0x00179324 File Offset: 0x00177524
		' (set) Token: 0x06001EB7 RID: 7863 RVA: 0x000065F7 File Offset: 0x000047F7
		Friend Overridable Property chkSplitMoveTBL As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkSplitMoveTBL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkSplitMoveTBL = value
			End Set
		End Property

		' Token: 0x17000AA0 RID: 2720
		' (get) Token: 0x06001EB8 RID: 7864 RVA: 0x0017933C File Offset: 0x0017753C
		' (set) Token: 0x06001EB9 RID: 7865 RVA: 0x00006601 File Offset: 0x00004801
		Friend Overridable Property Label33 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label33
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label33 = value
			End Set
		End Property

		' Token: 0x17000AA1 RID: 2721
		' (get) Token: 0x06001EBA RID: 7866 RVA: 0x00179354 File Offset: 0x00177554
		' (set) Token: 0x06001EBB RID: 7867 RVA: 0x0000660B File Offset: 0x0000480B
		Public Property pbytDKSOLUONG As Byte
			Get
				Return Me.mbytDKSOLUONG
			End Get
			Set(value As Byte)
				Me.mbytDKSOLUONG = value
			End Set
		End Property

		' Token: 0x17000AA2 RID: 2722
		' (get) Token: 0x06001EBC RID: 7868 RVA: 0x0017936C File Offset: 0x0017756C
		' (set) Token: 0x06001EBD RID: 7869 RVA: 0x00006616 File Offset: 0x00004816
		Public Property pbytLTENHHFORMAT As Byte
			Get
				Return Me.mbytLTENHHFORMAT
			End Get
			Set(value As Byte)
				Me.mbytLTENHHFORMAT = value
			End Set
		End Property

		' Token: 0x17000AA3 RID: 2723
		' (get) Token: 0x06001EBE RID: 7870 RVA: 0x00179384 File Offset: 0x00177584
		' (set) Token: 0x06001EBF RID: 7871 RVA: 0x00006621 File Offset: 0x00004821
		Public Property pStrDATABIT As String
			Get
				Return Me.mstrDATABIT
			End Get
			Set(value As String)
				Me.mstrDATABIT = value
			End Set
		End Property

		' Token: 0x17000AA4 RID: 2724
		' (get) Token: 0x06001EC0 RID: 7872 RVA: 0x0017939C File Offset: 0x0017759C
		' (set) Token: 0x06001EC1 RID: 7873 RVA: 0x0000662C File Offset: 0x0000482C
		Public Property pStrPARITYBIT As String
			Get
				Return Me.mstrPARITYBIT
			End Get
			Set(value As String)
				Me.mstrPARITYBIT = value
			End Set
		End Property

		' Token: 0x17000AA5 RID: 2725
		' (get) Token: 0x06001EC2 RID: 7874 RVA: 0x001793B4 File Offset: 0x001775B4
		' (set) Token: 0x06001EC3 RID: 7875 RVA: 0x00006637 File Offset: 0x00004837
		Public Property pStrSTOPBIT As String
			Get
				Return Me.mstrSTOPBIT
			End Get
			Set(value As String)
				Me.mstrSTOPBIT = value
			End Set
		End Property

		' Token: 0x17000AA6 RID: 2726
		' (get) Token: 0x06001EC4 RID: 7876 RVA: 0x001793CC File Offset: 0x001775CC
		' (set) Token: 0x06001EC5 RID: 7877 RVA: 0x00006642 File Offset: 0x00004842
		Public Property pStrFLOWCONTROL As String
			Get
				Return Me.mstrFLOWCONTROL
			End Get
			Set(value As String)
				Me.mstrFLOWCONTROL = value
			End Set
		End Property

		' Token: 0x17000AA7 RID: 2727
		' (get) Token: 0x06001EC6 RID: 7878 RVA: 0x001793E4 File Offset: 0x001775E4
		' (set) Token: 0x06001EC7 RID: 7879 RVA: 0x0000664D File Offset: 0x0000484D
		Public Property pStrCOMNAME As String
			Get
				Return Me.mstrCOMNAME
			End Get
			Set(value As String)
				Me.mstrCOMNAME = value
			End Set
		End Property

		' Token: 0x17000AA8 RID: 2728
		' (get) Token: 0x06001EC8 RID: 7880 RVA: 0x001793FC File Offset: 0x001775FC
		' (set) Token: 0x06001EC9 RID: 7881 RVA: 0x00006658 File Offset: 0x00004858
		Public Property pStrBAULDRATE As String
			Get
				Return Me.mstrBAULDRATE
			End Get
			Set(value As String)
				Me.mstrBAULDRATE = value
			End Set
		End Property

		' Token: 0x17000AA9 RID: 2729
		' (get) Token: 0x06001ECA RID: 7882 RVA: 0x00179414 File Offset: 0x00177614
		' (set) Token: 0x06001ECB RID: 7883 RVA: 0x00006663 File Offset: 0x00004863
		Public Property pStrMAY As String
			Get
				Return Me.mstrMAY
			End Get
			Set(value As String)
				Me.mstrMAY = value
			End Set
		End Property

		' Token: 0x17000AAA RID: 2730
		' (get) Token: 0x06001ECC RID: 7884 RVA: 0x0017942C File Offset: 0x0017762C
		' (set) Token: 0x06001ECD RID: 7885 RVA: 0x0000666E File Offset: 0x0000486E
		Public Property pStrLoaiMayin As String
			Get
				Return Me.mstrLoaiMayIn
			End Get
			Set(value As String)
				Me.mstrLoaiMayIn = value
			End Set
		End Property

		' Token: 0x17000AAB RID: 2731
		' (get) Token: 0x06001ECE RID: 7886 RVA: 0x00179444 File Offset: 0x00177644
		' (set) Token: 0x06001ECF RID: 7887 RVA: 0x00006679 File Offset: 0x00004879
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000AAC RID: 2732
		' (get) Token: 0x06001ED0 RID: 7888 RVA: 0x0017945C File Offset: 0x0017765C
		' (set) Token: 0x06001ED1 RID: 7889 RVA: 0x00006684 File Offset: 0x00004884
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000AAD RID: 2733
		' (get) Token: 0x06001ED2 RID: 7890 RVA: 0x00179474 File Offset: 0x00177674
		' (set) Token: 0x06001ED3 RID: 7891 RVA: 0x0000668F File Offset: 0x0000488F
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06001ED4 RID: 7892 RVA: 0x0017948C File Offset: 0x0017768C
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001ED5 RID: 7893 RVA: 0x00179538 File Offset: 0x00177738
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001ED6 RID: 7894 RVA: 0x001795E0 File Offset: 0x001777E0
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.txtMAMAY.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001ED7 RID: 7895 RVA: 0x0017968C File Offset: 0x0017788C
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbLoaiMayIn.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001ED8 RID: 7896 RVA: 0x00179730 File Offset: 0x00177930
		Private Sub txtMAMAY_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMAMAY.[ReadOnly]
				If [readOnly] Then
					Me.txtTimeOut.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001ED9 RID: 7897 RVA: 0x001797DC File Offset: 0x001779DC
		Private Sub txtMAMAY_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.TxtMAMAYCALL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EDA RID: 7898 RVA: 0x00179880 File Offset: 0x00177A80
		Private Sub cmbCOMName_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbBaudrate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCOMName_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EDB RID: 7899 RVA: 0x00179924 File Offset: 0x00177B24
		Private Sub cmbBaudrate_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbDataBit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbBaudrate_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EDC RID: 7900 RVA: 0x001799C8 File Offset: 0x00177BC8
		Private Sub cmbDataBit_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbParityBit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbDataBit_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EDD RID: 7901 RVA: 0x00179A6C File Offset: 0x00177C6C
		Private Sub cmbParityBit_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbStopBit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbParityBit_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EDE RID: 7902 RVA: 0x00179B10 File Offset: 0x00177D10
		Private Sub cmbLoaiMayIn_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkLSHARE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbLoaiMayIn_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EDF RID: 7903 RVA: 0x00179BB4 File Offset: 0x00177DB4
		Private Sub chkDungChung_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.ChkLSHOWBILL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkDungChung_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EE0 RID: 7904 RVA: 0x00179C58 File Offset: 0x00177E58
		Private Sub cmbStopBit_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbFlowControl.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbStopBit_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EE1 RID: 7905 RVA: 0x00179CFC File Offset: 0x00177EFC
		Private Sub cmbFlowControl_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtTimeOut.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbFlowControl_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EE2 RID: 7906 RVA: 0x00179DA0 File Offset: 0x00177FA0
		Private Sub txtTimeOut_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTimeOut.[ReadOnly]
				If [readOnly] Then
					Me.txtPrintCount.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTimeOut_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EE3 RID: 7907 RVA: 0x00179E4C File Offset: 0x0017804C
		Private Sub txtTimeOut_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txtPrintCount.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTimeOut_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EE4 RID: 7908 RVA: 0x00179FE8 File Offset: 0x001781E8
		Private Sub txtPrintCount_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtPrintCount.[ReadOnly]
				If [readOnly] Then
					Me.txtRemark.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EE5 RID: 7909 RVA: 0x0017A094 File Offset: 0x00178294
		Private Sub txtPrintCount_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txtRemark.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkLSHARE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EE6 RID: 7910 RVA: 0x0017A250 File Offset: 0x00178450
		Private Sub txtRemark_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtRemark.[ReadOnly]
				If [readOnly] Then
					Me.btnDelete.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EE7 RID: 7911 RVA: 0x0017A2FC File Offset: 0x001784FC
		Private Sub frmDMMAYINBEP2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAYINBEP2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EE8 RID: 7912 RVA: 0x0017A3A8 File Offset: 0x001785A8
		Private Sub frmDMMAYINBEP2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMMAY()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMLOAIMAYIN()
				End If
				Me.fGetData_4ComboBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAYINBEP2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EE9 RID: 7913 RVA: 0x0017A480 File Offset: 0x00178680
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.cmbLTENHHFORMAT1.Visible
				If flag Then
					Select Case Me.cmbLTENHHFORMAT1.SelectedIndex
						Case 0
							Me.txtBEPSIZE1.Text = "9"
						Case 1
							Me.txtBEPSIZE1.Text = "10"
						Case 2
							Me.txtBEPSIZE1.Text = "11"
					End Select
					Select Case Me.cmbLTENHHFORMAT2.SelectedIndex
						Case 0
							Me.txtBEPSIZE2.Text = "9"
						Case 1
							Me.txtBEPSIZE2.Text = "10"
						Case 2
							Me.txtBEPSIZE2.Text = "11"
					End Select
					Select Case Me.cmbLTENHHFORMAT3.SelectedIndex
						Case 0
							Me.txtBEPSIZE3.Text = "9"
						Case 1
							Me.txtBEPSIZE3.Text = "10"
						Case 2
							Me.txtBEPSIZE3.Text = "11"
					End Select
				End If
				flag = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = Operators.CompareString(Strings.Trim(Me.txtMAMAY.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(41), MsgBoxStyle.Critical, Nothing)
							Me.txtMAMAY.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.txtMAMAY.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENMAY.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(42), MsgBoxStyle.Critical, Nothing)
								Me.txtMAMAY.Focus()
							Else
								flag = Me.cmbCOMName.Visible
								Dim flag2 As Boolean
								If flag Then
									flag2 = Operators.CompareString(Strings.Trim(Me.cmbCOMName.Text), "", False) = 0
									If flag2 Then
										Interaction.MsgBox(Me.mArrStrFrmMess(43), MsgBoxStyle.Critical, Nothing)
										Me.cmbCOMName.Focus()
										Return
									End If
								End If
								flag2 = Me.cmbBaudrate.Visible
								If flag2 Then
									flag = Operators.CompareString(Strings.Trim(Me.cmbBaudrate.Text), "", False) = 0
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(44), MsgBoxStyle.Critical, Nothing)
										Me.cmbBaudrate.Focus()
										Return
									End If
								End If
								flag2 = Me.cmbDataBit.Visible
								If flag2 Then
									flag = Operators.CompareString(Strings.Trim(Me.cmbDataBit.Text), "", False) = 0
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(45), MsgBoxStyle.Critical, Nothing)
										Me.cmbDataBit.Focus()
										Return
									End If
								End If
								flag2 = Me.cmbParityBit.Visible
								If flag2 Then
									flag = Operators.CompareString(Strings.Trim(Me.cmbParityBit.Text), "", False) = 0
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(46), MsgBoxStyle.Critical, Nothing)
										Me.cmbParityBit.Focus()
										Return
									End If
								End If
								flag2 = Me.cmbStopBit.Visible
								If flag2 Then
									flag = Operators.CompareString(Strings.Trim(Me.cmbStopBit.Text), "", False) = 0
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(47), MsgBoxStyle.Critical, Nothing)
										Me.cmbStopBit.Focus()
										Return
									End If
								End If
								flag2 = Me.cmbFlowControl.Visible
								If flag2 Then
									flag = Operators.CompareString(Strings.Trim(Me.cmbFlowControl.Text), "", False) = 0
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(48), MsgBoxStyle.Critical, Nothing)
										Me.cmbFlowControl.Focus()
										Return
									End If
								End If
								flag2 = Operators.CompareString(Strings.Trim(Me.txtPrintCount.Text), "", False) = 0
								If flag2 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
									Me.txtPrintCount.Focus()
								Else
									flag2 = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
									If flag2 Then
										Me.mbytSuccess = Me.fAddNew()
									Else
										flag2 = Me.mbytFormStatus = 3
										If flag2 Then
											Me.mbytSuccess = Me.fModify()
										End If
									End If
									flag2 = Me.mbytSuccess = 1
									If flag2 Then
										Dim b As Byte = mdlVariable.gfGetDMMAYINBEP()
										Me.Close()
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EEA RID: 7914 RVA: 0x0017AA74 File Offset: 0x00178C74
		Private Sub cmbLoaiMayIn_SelectedValueChanged(sender As Object, e As EventArgs)
			Try
				Me.lblSTTPerItem.Visible = Me.cmbLoaiMayIn.SelectedValue.ToString().Equals("11")
				Me.chkSTTPerItem.Visible = Me.cmbLoaiMayIn.SelectedValue.ToString().Equals("11")
				Dim text As String = Me.cmbLoaiMayIn.SelectedValue.ToString()
				Dim flag As Boolean
				If Operators.CompareString(text, "0", False) <> 0 AndAlso Operators.CompareString(text, "1", False) <> 0 Then
					If Operators.CompareString(text, "2", False) <> 0 Then
						If Operators.CompareString(text, "8", False) <> 0 Then
							flag = False
							GoTo IL_00A5
						End If
					End If
				End If
				flag = True
				IL_00A5:
				Dim flag2 As Boolean = flag
				If flag2 Then
					Me.sDisable(True)
				Else
					Dim flag3 As Boolean
					If Operators.CompareString(text, "3", False) <> 0 AndAlso Operators.CompareString(text, "4", False) <> 0 Then
						If Operators.CompareString(text, "5", False) <> 0 Then
							If Operators.CompareString(text, "6", False) <> 0 Then
								If Operators.CompareString(text, "7", False) <> 0 Then
									If Operators.CompareString(text, "9", False) <> 0 Then
										If Operators.CompareString(text, "10", False) <> 0 Then
											If Operators.CompareString(text, "11", False) <> 0 Then
												flag3 = False
												GoTo IL_013F
											End If
										End If
									End If
								End If
							End If
						End If
					End If
					flag3 = True
					IL_013F:
					flag2 = flag3
					If flag2 Then
						Me.sDisable(False)
					End If
				End If
				Dim flag4 As Boolean
				If Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "7", False) <> 0 AndAlso Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "3", False) <> 0 Then
					If Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "4", False) <> 0 Then
						If Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "5", False) <> 0 Then
							If Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "6", False) <> 0 Then
								If Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "7", False) <> 0 Then
									If Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "9", False) <> 0 Then
										If Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "10", False) <> 0 Then
											If Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "11", False) <> 0 Then
												If Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "0", False) <> 0 Then
													flag4 = False
													GoTo IL_028C
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
				flag4 = True
				IL_028C:
				flag2 = flag4
				If flag2 Then
					Me.lblSplitSL1.Visible = True
					Me.chkSplitSL1.Visible = True
				Else
					Me.lblSplitSL1.Visible = False
					Me.chkSplitSL1.Visible = False
				End If
				Me.grpLogo.Visible = Operators.CompareString(Me.cmbLoaiMayIn.SelectedValue.ToString(), "9", False) = 0
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbLoaiMayIn_SelectedValueChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EEB RID: 7915 RVA: 0x0017ADF4 File Offset: 0x00178FF4
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EEC RID: 7916 RVA: 0x0017AE98 File Offset: 0x00179098
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAMAY.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMAY like '%"), text2), "%'"))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbCOMName.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " COMNAME like '%"), text2), "%'"))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbBaudrate.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " BAUDRATE = "), text2))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbDataBit.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " DATABITS = "), text2))
				End If
				text2 = Conversions.ToString(Interaction.IIf(Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex))) < 0, "", Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex))))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " PARITYBITS = "), text2))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbStopBit.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " STOPBITS = "), text2))
				End If
				text2 = Conversions.ToString(Interaction.IIf(Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex))) < 0, "", Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex))))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FLOWCONTROL = "), text2))
				End If
				text2 = Strings.Trim(Me.txtTimeOut.Text)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TIMEOUT = "), text2))
				End If
				text2 = Strings.Trim(Me.txtPrintCount.Text)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " PRINTCOUNT = "), text2))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtRemark.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Conversions.ToString(Me.cmbLoaiMayIn.SelectedValue)), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " KIND = "), text2), ""))
				End If
				flag = Me.chkLSHARE.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHARE = "), Me.chkLSHARE.Checked), ""))
				End If
				flag = Me.ChkLSHOWBILL.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWBILL = "), Me.chkLSHARE.Checked), ""))
				End If
				flag = Me.ChkLBOLD.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LBOLD = "), Me.chkLSHARE.Checked), ""))
				End If
				flag = Me.ChkLSHOWPRICE.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWPRICE = "), Me.chkLSHARE.Checked), ""))
				End If
				flag = Me.chkCus.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWCUSTOMER = "), Me.chkCus.Checked), ""))
				End If
				flag = Me.chkService.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWSERVICE = "), Me.chkService.Checked), ""))
				End If
				flag = Me.ckhCashier.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWCASHIER = "), Me.ckhCashier.Checked), ""))
				End If
				flag = Me.chkTable.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWTABLE = "), Me.chkTable.Checked), ""))
				End If
				flag = Me.chkDate.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWDATE = "), Me.chkDate.Checked), ""))
				End If
				flag = Me.chkOrder.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWORDER = "), Me.chkOrder.Checked), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EED RID: 7917 RVA: 0x0017B8A8 File Offset: 0x00179AA8
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAMAY.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMAY like '%"), text2), "%'"))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbCOMName.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " COMNAME like '%"), text2), "%'"))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbBaudrate.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " BAUDRATE = "), text2))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbDataBit.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " DATABITS = "), text2))
				End If
				text2 = Conversions.ToString(Interaction.IIf(Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex))) < 0, "", Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex))))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " PARITYBITS = "), text2))
				End If
				text2 = Strings.Trim(Conversions.ToString(Me.cmbStopBit.SelectedItem))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " STOPBITS = "), text2))
				End If
				text2 = Conversions.ToString(Interaction.IIf(Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex))) < 0, "", Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex))))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FLOWCONTROL = "), text2))
				End If
				text2 = Strings.Trim(Me.txtTimeOut.Text)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TIMEOUT = "), text2))
				End If
				text2 = Strings.Trim(Me.txtPrintCount.Text)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " PRINTCOUNT = "), text2))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtRemark.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Conversions.ToString(Me.cmbLoaiMayIn.SelectedValue)), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " KIND = "), text2), ""))
				End If
				flag = Me.chkLSHARE.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHARE = "), Me.chkLSHARE.Checked), ""))
				End If
				flag = Me.ChkLSHOWBILL.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWBILL = "), Me.chkLSHARE.Checked), ""))
				End If
				flag = Me.ChkLBOLD.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LBOLD = "), Me.chkLSHARE.Checked), ""))
				End If
				flag = Me.ChkLSHOWPRICE.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWPRICE = "), Me.chkLSHARE.Checked), ""))
				End If
				flag = Me.chkCus.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWCUSTOMER = "), Me.chkCus.Checked), ""))
				End If
				flag = Me.chkService.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWSERVICE = "), Me.chkService.Checked), ""))
				End If
				flag = Me.ckhCashier.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWCASHIER = "), Me.ckhCashier.Checked), ""))
				End If
				flag = Me.chkTable.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWTABLE = "), Me.chkTable.Checked), ""))
				End If
				flag = Me.chkDate.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWDATE = "), Me.chkDate.Checked), ""))
				End If
				flag = Me.chkOrder.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSHOWORDER = "), Me.chkOrder.Checked), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EEE RID: 7918 RVA: 0x0017C2B8 File Offset: 0x0017A4B8
		Private Sub btnDMMAY_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAY As frmDMMAY1 = New frmDMMAY1()
				frmDMMAY.pBytOpen_From_Menu = 7
				frmDMMAY.btnSelect.Visible = True
				frmDMMAY.ShowDialog()
				Me.txtMAMAY.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAY.pStrOBJID, "", False) = 0, Me.txtMAMAY.Text, frmDMMAY.pStrOBJID))
				Me.txtTENMAY.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAY.pStrOBJID, "", False) = 0, Me.txtTENMAY.Text, frmDMMAY.pStrOBJNAME))
				frmDMMAY.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMNH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EEF RID: 7919 RVA: 0x0017C400 File Offset: 0x0017A600
		Private Sub txtMAMAY_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMMAY Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMMAY.Columns("OBJID")
					Me.mclsTbDMMAY.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMMAY.Rows.Find(Strings.Trim(Me.txtMAMAY.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENMAY.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENMAY.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EF0 RID: 7920 RVA: 0x0017C554 File Offset: 0x0017A754
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.cmbLoaiMayIn.SelectedValue = Me.mstrLoaiMayIn
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.cmbBaudrate.Enabled = False
						Me.cmbCOMName.Enabled = False
						Me.cmbDataBit.Enabled = False
						Me.cmbParityBit.Enabled = False
						Me.cmbStopBit.Enabled = False
						Me.cmbFlowControl.Enabled = False
						Me.cmbLoaiMayIn.SelectedValue = Me.mstrLoaiMayIn
						Me.cmbLoaiMayIn.Enabled = False
						Me.chkLSHARE.Enabled = False
						Me.ChkLSHOWBILL.Enabled = False
						Me.ChkLBOLD.Enabled = False
						Me.ChkLSHOWPRICE.Enabled = False
						Me.chkSplit.Enabled = False
						Me.chkLSHOWLIEN.Enabled = False
						Me.chkLKITREMARK1LINE.Enabled = False
						Me.txtTimeOut.[ReadOnly] = True
						Me.txtPrintCount.[ReadOnly] = True
						Me.txtRemark.[ReadOnly] = True
						Me.txtMAMAY.[ReadOnly] = True
						Me.TxtMAMAYCALL.[ReadOnly] = True
						Me.txtPrintWidth.[ReadOnly] = True
						Me.txtTOP.[ReadOnly] = True
						Me.txtLEFT.[ReadOnly] = True
						Me.txtBottom.[ReadOnly] = True
						Me.txtRight.[ReadOnly] = True
						Me.btnDMMAY.Enabled = False
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.BackColor = Me.txtColor.BackColor
						Me.cmbBaudrate.BackColor = Me.txtColor.BackColor
						Me.cmbCOMName.BackColor = Me.txtColor.BackColor
						Me.cmbDataBit.BackColor = Me.txtColor.BackColor
						Me.cmbParityBit.BackColor = Me.txtColor.BackColor
						Me.cmbStopBit.BackColor = Me.txtColor.BackColor
						Me.cmbFlowControl.BackColor = Me.txtColor.BackColor
						Me.cmbLoaiMayIn.BackColor = Me.txtColor.BackColor
						Me.TxtMAMAYCALL.BackColor = Me.txtColor.BackColor
						Me.txtTimeOut.BackColor = Me.txtColor.BackColor
						Me.txtPrintCount.BackColor = Me.txtColor.BackColor
						Me.txtRemark.BackColor = Me.txtColor.BackColor
						Me.txtMAMAY.BackColor = Me.txtColor.BackColor
						Me.txtPrintWidth.BackColor = Me.txtColor.BackColor
						Me.txtTOP.BackColor = Me.txtColor.BackColor
						Me.txtLEFT.BackColor = Me.txtColor.BackColor
						Me.txtBottom.BackColor = Me.txtColor.BackColor
						Me.txtRight.BackColor = Me.txtColor.BackColor
					Case 5, 6
						Me.chkLSHARE.CheckState = CheckState.Indeterminate
						Me.ChkLSHOWPRICE.CheckState = CheckState.Indeterminate
						Me.ChkLSHOWBILL.CheckState = CheckState.Indeterminate
						Me.ChkLBOLD.CheckState = CheckState.Indeterminate
						Me.ChkLSHOWPRICE.CheckState = CheckState.Indeterminate
						Me.chkSplit.CheckState = CheckState.Indeterminate
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001EF1 RID: 7921 RVA: 0x0017C9EC File Offset: 0x0017ABEC
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnSECLECTMAYCALL.Enabled = False
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
						Me.ChkLSHOWPRICE.CheckState = CheckState.Indeterminate
						Me.ChkLSHOWBILL.CheckState = CheckState.Indeterminate
						Me.ChkLBOLD.CheckState = CheckState.Indeterminate
						Me.ChkLSHOWPRICE.CheckState = CheckState.Indeterminate
						Me.chkCus.CheckState = CheckState.Indeterminate
						Me.chkService.CheckState = CheckState.Indeterminate
						Me.ckhCashier.CheckState = CheckState.Indeterminate
						Me.chkTable.CheckState = CheckState.Indeterminate
						Me.chkDate.CheckState = CheckState.Indeterminate
						Me.chkOrder.CheckState = CheckState.Indeterminate
					Case 6
						Me.btnFind.Enabled = True
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001EF2 RID: 7922 RVA: 0x0017CC20 File Offset: 0x0017AE20
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				Dim array As String() = New String() { Me.mArrStrFrmMess(51), Me.mArrStrFrmMess(52), Me.mArrStrFrmMess(53), Me.mArrStrFrmMess(54), Me.mArrStrFrmMess(55) }
				Dim array2 As String() = New String() { Me.mArrStrFrmMess(76), Me.mArrStrFrmMess(77), Me.mArrStrFrmMess(78), Me.mArrStrFrmMess(79) }
				Dim array3 As String() = New String() { Me.mArrStrFrmMess(80), Me.mArrStrFrmMess(81), Me.mArrStrFrmMess(82), Me.mArrStrFrmMess(83), Me.mArrStrFrmMess(84) }
				Dim array4 As String() = New String() { Me.mArrStrFrmMess(85), Me.mArrStrFrmMess(86), Me.mArrStrFrmMess(87) }
				Dim array5 As String() = New String() { Me.mArrStrFrmMess(88), Me.mArrStrFrmMess(89), Me.mArrStrFrmMess(90) }
				Dim array6 As String() = New String() { Me.mArrStrFrmMess(120), Me.mArrStrFrmMess(121), Me.mArrStrFrmMess(122) }
				Dim array7 As String() = New String() { Me.mArrStrFrmMess(120), Me.mArrStrFrmMess(121), Me.mArrStrFrmMess(122) }
				Dim array8 As String() = New String() { Me.mArrStrFrmMess(120), Me.mArrStrFrmMess(121), Me.mArrStrFrmMess(122) }
				Dim array9 As String() = New String() { Me.mArrStrFrmMess(130), Me.mArrStrFrmMess(131), Me.mArrStrFrmMess(132) }
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 5
				Me.txtOBJNAME.MaxLength = 50
				Me.txtMAMAY.MaxLength = 5
				Me.txtRemark.MaxLength = 200
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				Me.cmbBaudrate.DataSource = array
				Dim flag As Boolean = SerialPort.GetPortNames() <> Nothing
				If flag Then
					Me.cmbCOMName.DataSource = SerialPort.GetPortNames()
				End If
				Me.cmbDataBit.DataSource = array2
				Me.cmbParityBit.DataSource = array3
				Me.cmbStopBit.DataSource = array4
				Me.cmbFlowControl.DataSource = array5
				Me.cmbLTENHHFORMAT1.DataSource = array6
				Me.cmbLTENHHFORMAT2.DataSource = array7
				Me.cmbLTENHHFORMAT3.DataSource = array8
				Me.cmbDKSOLUONG.DataSource = array9
				Me.cmbBaudrate.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbCOMName.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbDataBit.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbParityBit.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbStopBit.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbFlowControl.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbLTENHHFORMAT1.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbLTENHHFORMAT2.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbLTENHHFORMAT3.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbDKSOLUONG.DropDownStyle = ComboBoxStyle.DropDownList
				Select Case Me.mbytFormStatus
					Case 1
						Me.cmbBaudrate.SelectedIndex = 3
						flag = Me.cmbCOMName.Items.Count > 0
						If flag Then
							Me.cmbCOMName.SelectedIndex = 0
						End If
						Me.cmbDataBit.SelectedIndex = 3
						Me.cmbParityBit.SelectedIndex = 0
						Me.cmbStopBit.SelectedIndex = 0
						Me.cmbFlowControl.SelectedIndex = 0
						Me.cmbLTENHHFORMAT1.SelectedIndex = 0
						Me.txtTimeOut.Text = Conversions.ToString(0)
						Me.txtPrintCount.Text = Conversions.ToString(1)
					Case 2, 3, 4
						Me.cmbCOMName.Text = Me.mstrCOMNAME.Trim()
						Me.cmbBaudrate.Text = Me.mstrBAULDRATE
						Me.cmbDataBit.Text = Me.mstrDATABIT
						Me.cmbParityBit.SelectedIndex = Conversions.ToInteger(Me.mstrPARITYBIT)
						Me.cmbStopBit.Text = Me.mstrSTOPBIT
						Me.cmbFlowControl.SelectedIndex = Conversions.ToInteger(Me.mstrFLOWCONTROL)
						Me.cmbLTENHHFORMAT1.SelectedIndex = CInt(Me.mbytLTENHHFORMAT)
						Me.cmbDKSOLUONG.SelectedIndex = CInt(Me.mbytDKSOLUONG)
					Case 5, 6
						Me.cmbBaudrate.SelectedIndex = -1
						Me.cmbCOMName.SelectedIndex = -1
						Me.cmbDataBit.SelectedIndex = -1
						Me.cmbParityBit.SelectedIndex = -1
						Me.cmbStopBit.SelectedIndex = -1
						Me.cmbFlowControl.SelectedIndex = -1
						Me.cmbLTENHHFORMAT1.SelectedIndex = -1
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001EF3 RID: 7923 RVA: 0x0017D254 File Offset: 0x0017B454
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.lblLoaiMayIn.Tag = "CB0091"
				Me.lblTimeOut.Tag = "CB0038"
				Me.lblOBJID.Tag = "CB0007"
				Me.lblOBJNAME.Tag = "CB0008"
				Me.lblComputer.Tag = "CB0031"
				Me.lblCOMName.Tag = "CB0032"
				Me.lblBaudrate.Tag = "CB0033"
				Me.lblDataBit.Tag = "CB0034"
				Me.lblParityBit.Tag = "CB0035"
				Me.lblStopBit.Tag = "CB00361"
				Me.lblFlowControl.Tag = "CB0037"
				Me.lblPrintCount.Tag = "CB0039"
				Me.lblLSHARE.Tag = "CR0102"
				Me.LblSHOWBILL.Tag = "CR0103"
				Me.lBLBOLD.Tag = "CR0104"
				Me.LblSHOWPRICE.Tag = "CR0105"
				Me.LblMAMAYTINHCALL.Tag = "CB0108"
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001EF4 RID: 7924 RVA: 0x0017D514 File Offset: 0x0017B714
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMMAY.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EF5 RID: 7925 RVA: 0x0017D5C0 File Offset: 0x0017B7C0
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(69) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAMAY"
				array(2).Value = Strings.Trim(Me.txtMAMAY.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchCOMName"
				array(3).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Not Me.cmbCOMName.Visible, "", Strings.Trim(Conversions.ToString(Me.cmbCOMName.SelectedItem))))
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@prelStopBits"
				array(4).Value = Conversions.ToDouble(Strings.Trim(Conversions.ToString(Me.cmbStopBit.SelectedItem)))
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pintBaudrate"
				array(5).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbBaudrate.SelectedItem)))
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@ptniDataBits"
				array(6).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbDataBit.SelectedItem)))
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@ptniFlowControl"
				array(7).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex)))
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pintTimeOut"
				array(8).Value = Strings.Trim(Me.txtTimeOut.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@ptniPrintCount"
				array(9).Value = Conversions.ToInteger(Strings.Trim(Me.txtPrintCount.Text))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@ptniParityBits"
				array(10).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex)))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pnvcRemark"
				array(11).Value = Strings.Trim(Me.txtRemark.Text)
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@ptniKIND"
				array(12).Value = Strings.Trim(Conversions.ToString(Me.cmbLoaiMayIn.SelectedValue))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pbitLSHARE"
				array(13).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSHARE.Checked, 1, 0))
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitLSHOWBILL"
				array(14).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.ChkLSHOWBILL.Checked, 1, 0))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pbitLBOLD"
				array(15).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.ChkLBOLD.Checked, 1, 0))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pbitLSHOWPRICE"
				array(16).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.ChkLSHOWPRICE.Checked, 1, 0))
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnchMAMAYCALL"
				array(17).Value = Strings.Trim(Me.TxtMAMAYCALL.Text)
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@pbitLSHOWCUSTOMER"
				array(18).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCus.Checked, 1, 0))
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pbitLSHOWSERVICE"
				array(19).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkService.Checked, 1, 0))
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@pbitLSHOWCASHIER"
				array(20).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.ckhCashier.Checked, 1, 0))
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pbitLSHOWTABLE"
				array(21).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkTable.Checked, 1, 0))
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pbitLSHOWDATE"
				array(22).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkDate.Checked, 1, 0))
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pbitLSHOWORDER"
				array(23).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkOrder.Checked, 1, 0))
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@ptniPRINTWIDTH"
				array(24).Value = Conversion.Val(Me.txtPrintWidth.Text.Trim())
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pbitLSPLIT"
				array(25).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkSplit.Checked, 1, 0))
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pbitLCALL"
				array(26).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLCALL.Checked, 1, 0))
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@ptniLTENHHFORMAT"
				array(27).Value = Me.cmbLTENHHFORMAT1.SelectedIndex
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@bitLSHOWLIEN"
				array(28).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSHOWLIEN.Checked, 1, 0))
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@decTOPMARGIN"
				array(29).Value = Conversion.Val(Me.txtTOP.Text.Trim())
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@decLEFTMARGIN"
				array(30).Value = Conversion.Val(Me.txtLEFT.Text.Trim())
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@decBOTTOMMARGIN"
				array(31).Value = Conversion.Val(Me.txtBottom.Text.Trim())
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@decRIGHTMARGIN"
				array(32).Value = Conversion.Val(Me.txtRight.Text.Trim())
				array(34) = sqlCommand.CreateParameter()
				array(34).ParameterName = "@pbitLKITREMARK1LINE"
				array(34).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLKITREMARK1LINE.Checked, 1, 0))
				array(35) = sqlCommand.CreateParameter()
				array(35).ParameterName = "@tniDKSOLUONG"
				array(35).Value = Me.cmbDKSOLUONG.SelectedIndex
				array(36) = sqlCommand.CreateParameter()
				array(36).ParameterName = "@pbitLSHOWDVT"
				array(36).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkDVT.Checked, 1, 0))
				array(37) = sqlCommand.CreateParameter()
				array(37).ParameterName = "@pnvcFONT1"
				array(37).Value = Me.txtBEPFONT1.Text.Trim()
				array(38) = sqlCommand.CreateParameter()
				array(38).ParameterName = "@pnvcFONT2"
				array(38).Value = Me.txtBEPFONT2.Text.Trim()
				array(39) = sqlCommand.CreateParameter()
				array(39).ParameterName = "@pnvcFONT3"
				array(39).Value = Me.txtBEPFONT3.Text.Trim()
				array(40) = sqlCommand.CreateParameter()
				array(40).ParameterName = "@ptniSIZE1"
				array(40).Value = Conversion.Val(Me.txtBEPSIZE1.Text.Trim())
				array(41) = sqlCommand.CreateParameter()
				array(41).ParameterName = "@ptniSIZE2"
				array(41).Value = Conversion.Val(Me.txtBEPSIZE2.Text.Trim())
				array(42) = sqlCommand.CreateParameter()
				array(42).ParameterName = "@ptniSIZE3"
				array(42).Value = Conversion.Val(Me.txtBEPSIZE3.Text.Trim())
				array(43) = sqlCommand.CreateParameter()
				array(43).ParameterName = "@pbitLBOLD1"
				array(43).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPB1.Checked, 1, 0))
				array(44) = sqlCommand.CreateParameter()
				array(44).ParameterName = "@pbitLBOLD2"
				array(44).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPB2.Checked, 1, 0))
				array(45) = sqlCommand.CreateParameter()
				array(45).ParameterName = "@pbitLBOLD3"
				array(45).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPB3.Checked, 1, 0))
				array(46) = sqlCommand.CreateParameter()
				array(46).ParameterName = "@pbitLITALIC1"
				array(46).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPI1.Checked, 1, 0))
				array(47) = sqlCommand.CreateParameter()
				array(47).ParameterName = "@pbitLITALIC2"
				array(47).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPI2.Checked, 1, 0))
				array(48) = sqlCommand.CreateParameter()
				array(48).ParameterName = "@pbitLITALIC3"
				array(48).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPI3.Checked, 1, 0))
				array(49) = sqlCommand.CreateParameter()
				array(49).ParameterName = "@pbitLCACH1DONG"
				array(49).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLCach1Dong.Checked, 1, 0))
				array(50) = sqlCommand.CreateParameter()
				array(50).ParameterName = "@pbitLSHOWSTT"
				array(50).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkSTT.Checked, 1, 0))
				array(51) = sqlCommand.CreateParameter()
				array(51).ParameterName = "@pbitLSHOWTITLE"
				array(51).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSHOWTITLE.Checked, 1, 0))
				array(52) = sqlCommand.CreateParameter()
				array(52).ParameterName = "@pbitLSPLITSL1"
				array(52).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkSplitSL1.Checked, 1, 0))
				array(53) = sqlCommand.CreateParameter()
				array(53).ParameterName = "@pbitLGACHSLAM"
				array(53).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLGachSLAm.Checked, 1, 0))
				array(54) = sqlCommand.CreateParameter()
				array(54).ParameterName = "@pbitLPRICE1LINE"
				array(54).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLPrice1Line.Checked, 1, 0))
				array(55) = sqlCommand.CreateParameter()
				array(55).ParameterName = "@pbitLPRINTMAHH"
				array(55).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSHOWMAHH.Checked, 1, 0))
				array(56) = sqlCommand.CreateParameter()
				array(56).ParameterName = "@pbitLSHOWSLCOMBO"
				array(56).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLShowSLCombo.Checked, 1, 0))
				array(57) = sqlCommand.CreateParameter()
				array(57).ParameterName = "@pbitLPRINTMOVETBL"
				array(57).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLInChuyenBan.Checked, 1, 0))
				array(58) = sqlCommand.CreateParameter()
				array(58).ParameterName = "@pbitLPRINTLYDOXOA"
				array(58).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSHOWLYDOXOA.Checked, 1, 0))
				array(59) = sqlCommand.CreateParameter()
				array(59).ParameterName = "@pbitLINCHUYENMON"
				array(59).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLInChuyenMon.Checked, 1, 0))
				array(60) = sqlCommand.CreateParameter()
				array(60).ParameterName = "@pbitLSHOWKHU"
				array(60).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkKhu.Checked, 1, 0))
				array(61) = sqlCommand.CreateParameter()
				array(61).ParameterName = "@pbitLSHOWTONGSL"
				array(61).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkTongSL.Checked, 1, 0))
				Dim memoryStream As MemoryStream = New MemoryStream()
				Me.picpreview.BackgroundImage.Save(memoryStream, ImageFormat.Jpeg)
				Dim array2 As Byte() = memoryStream.ToArray()
				array(62) = sqlCommand.CreateParameter()
				array(62).ParameterName = "@pbitLSHOWLOGO"
				array(62).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLShowLogo.Checked, 1, 0))
				array(63) = sqlCommand.CreateParameter()
				array(63).ParameterName = "@IMGLOGO"
				array(63).Value = array2
				array(64) = sqlCommand.CreateParameter()
				array(64).ParameterName = "@pbitLSORTNH"
				array(64).Value = Me.chkLSortNH.Checked
				array(65) = sqlCommand.CreateParameter()
				array(65).ParameterName = "@pbitLSHOWSLMAIN"
				array(65).Value = Me.chkLShowSLMain.Checked
				array(66) = sqlCommand.CreateParameter()
				array(66).ParameterName = "@pbitLSHOWCUS"
				array(66).Value = Me.chkLShowCus.Checked
				array(67) = sqlCommand.CreateParameter()
				array(67).ParameterName = "@pbitLSTTPERITEM"
				array(67).Value = Me.chkSTTPerItem.Checked
				array(68) = sqlCommand.CreateParameter()
				array(68).ParameterName = "@pbitLSPLITMOVETBL"
				array(68).Value = Me.chkSplitMoveTBL.Checked
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@int_Result"
				array(33).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAYINBEP_INSERT_DMMAYINBEP", flag)
				Dim num As Integer = Conversions.ToInteger(array(33).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(100), MsgBoxStyle.Critical, Nothing)
							Me.cmbCOMName.Focus()
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
							Me.txtOBJID.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001EF6 RID: 7926 RVA: 0x0017E940 File Offset: 0x0017CB40
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(69) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAMAY"
				array(2).Value = Strings.Trim(Me.txtMAMAY.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchCOMName"
				array(3).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Not Me.cmbCOMName.Visible, "", Strings.Trim(Conversions.ToString(Me.cmbCOMName.SelectedItem))))
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@prelStopBits"
				array(4).Value = Conversions.ToDouble(Strings.Trim(Conversions.ToString(Me.cmbStopBit.SelectedItem)))
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pintBaudrate"
				array(5).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbBaudrate.SelectedItem)))
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@ptniDataBits"
				array(6).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbDataBit.SelectedItem)))
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@ptniFlowControl"
				array(7).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbFlowControl.SelectedIndex)))
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pintTimeOut"
				array(8).Value = Strings.Trim(Me.txtTimeOut.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@ptniPrintCount"
				array(9).Value = Conversions.ToInteger(Strings.Trim(Me.txtPrintCount.Text))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@ptniParityBits"
				array(10).Value = Conversions.ToInteger(Strings.Trim(Conversions.ToString(Me.cmbParityBit.SelectedIndex)))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pnvcRemark"
				array(11).Value = Strings.Trim(Me.txtRemark.Text)
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@ptniKIND"
				array(12).Value = Strings.Trim(Conversions.ToString(Me.cmbLoaiMayIn.SelectedValue))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pbitLSHARE"
				array(13).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSHARE.Checked, 1, 0))
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitLSHOWBILL"
				array(14).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.ChkLSHOWBILL.Checked, 1, 0))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pbitLBOLD"
				array(15).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.ChkLBOLD.Checked, 1, 0))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pbitLSHOWPRICE"
				array(16).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.ChkLSHOWPRICE.Checked, 1, 0))
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnchMAMAYCALL"
				array(17).Value = Strings.Trim(Me.TxtMAMAYCALL.Text)
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@pbitLSHOWCUSTOMER"
				array(18).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCus.Checked, 1, 0))
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pbitLSHOWSERVICE"
				array(19).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkService.Checked, 1, 0))
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@pbitLSHOWCASHIER"
				array(20).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.ckhCashier.Checked, 1, 0))
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pbitLSHOWTABLE"
				array(21).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkTable.Checked, 1, 0))
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pbitLSHOWDATE"
				array(22).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkDate.Checked, 1, 0))
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pbitLSHOWORDER"
				array(23).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkOrder.Checked, 1, 0))
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@ptniPRINTWIDTH"
				array(24).Value = Conversion.Val(Me.txtPrintWidth.Text.Trim())
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pbitLSPLIT"
				array(25).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkSplit.Checked, 1, 0))
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pbitLCALL"
				array(26).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLCALL.Checked, 1, 0))
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@ptniLTENHHFORMAT"
				array(27).Value = Me.cmbLTENHHFORMAT1.SelectedIndex
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@bitLSHOWLIEN"
				array(28).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSHOWLIEN.Checked, 1, 0))
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@decTOPMARGIN"
				array(29).Value = Conversion.Val(Me.txtTOP.Text.Trim())
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@decLEFTMARGIN"
				array(30).Value = Conversion.Val(Me.txtLEFT.Text.Trim())
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@decBOTTOMMARGIN"
				array(31).Value = Conversion.Val(Me.txtBottom.Text.Trim())
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@decRIGHTMARGIN"
				array(32).Value = Conversion.Val(Me.txtRight.Text.Trim())
				array(34) = sqlCommand.CreateParameter()
				array(34).ParameterName = "@pbitLKITREMARK1LINE"
				array(34).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLKITREMARK1LINE.Checked, 1, 0))
				array(35) = sqlCommand.CreateParameter()
				array(35).ParameterName = "@tniDKSOLUONG"
				array(35).Value = Me.cmbDKSOLUONG.SelectedIndex
				array(36) = sqlCommand.CreateParameter()
				array(36).ParameterName = "@pbitLSHOWDVT"
				array(36).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkDVT.Checked, 1, 0))
				array(37) = sqlCommand.CreateParameter()
				array(37).ParameterName = "@pnvcFONT1"
				array(37).Value = Me.txtBEPFONT1.Text.Trim()
				array(38) = sqlCommand.CreateParameter()
				array(38).ParameterName = "@pnvcFONT2"
				array(38).Value = Me.txtBEPFONT2.Text.Trim()
				array(39) = sqlCommand.CreateParameter()
				array(39).ParameterName = "@pnvcFONT3"
				array(39).Value = Me.txtBEPFONT3.Text.Trim()
				array(40) = sqlCommand.CreateParameter()
				array(40).ParameterName = "@ptniSIZE1"
				array(40).Value = Conversion.Val(Me.txtBEPSIZE1.Text.Trim())
				array(41) = sqlCommand.CreateParameter()
				array(41).ParameterName = "@ptniSIZE2"
				array(41).Value = Conversion.Val(Me.txtBEPSIZE2.Text.Trim())
				array(42) = sqlCommand.CreateParameter()
				array(42).ParameterName = "@ptniSIZE3"
				array(42).Value = Conversion.Val(Me.txtBEPSIZE3.Text.Trim())
				array(43) = sqlCommand.CreateParameter()
				array(43).ParameterName = "@pbitLBOLD1"
				array(43).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPB1.Checked, 1, 0))
				array(44) = sqlCommand.CreateParameter()
				array(44).ParameterName = "@pbitLBOLD2"
				array(44).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPB2.Checked, 1, 0))
				array(45) = sqlCommand.CreateParameter()
				array(45).ParameterName = "@pbitLBOLD3"
				array(45).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPB3.Checked, 1, 0))
				array(46) = sqlCommand.CreateParameter()
				array(46).ParameterName = "@pbitLITALIC1"
				array(46).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPI1.Checked, 1, 0))
				array(47) = sqlCommand.CreateParameter()
				array(47).ParameterName = "@pbitLITALIC2"
				array(47).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPI2.Checked, 1, 0))
				array(48) = sqlCommand.CreateParameter()
				array(48).ParameterName = "@pbitLITALIC3"
				array(48).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkBEPI3.Checked, 1, 0))
				array(49) = sqlCommand.CreateParameter()
				array(49).ParameterName = "@pbitLCACH1DONG"
				array(49).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLCach1Dong.Checked, 1, 0))
				array(50) = sqlCommand.CreateParameter()
				array(50).ParameterName = "@pbitLSHOWSTT"
				array(50).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkSTT.Checked, 1, 0))
				array(51) = sqlCommand.CreateParameter()
				array(51).ParameterName = "@pbitLSHOWTITLE"
				array(51).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSHOWTITLE.Checked, 1, 0))
				array(52) = sqlCommand.CreateParameter()
				array(52).ParameterName = "@pbitLSPLITSL1"
				array(52).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkSplitSL1.Checked, 1, 0))
				array(53) = sqlCommand.CreateParameter()
				array(53).ParameterName = "@pbitLGACHSLAM"
				array(53).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLGachSLAm.Checked, 1, 0))
				array(54) = sqlCommand.CreateParameter()
				array(54).ParameterName = "@pbitLPRICE1LINE"
				array(54).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLPrice1Line.Checked, 1, 0))
				array(55) = sqlCommand.CreateParameter()
				array(55).ParameterName = "@pbitLPRINTMAHH"
				array(55).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSHOWMAHH.Checked, 1, 0))
				array(56) = sqlCommand.CreateParameter()
				array(56).ParameterName = "@pbitLSHOWSLCOMBO"
				array(56).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLShowSLCombo.Checked, 1, 0))
				array(57) = sqlCommand.CreateParameter()
				array(57).ParameterName = "@pbitLPRINTMOVETBL"
				array(57).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLInChuyenBan.Checked, 1, 0))
				array(58) = sqlCommand.CreateParameter()
				array(58).ParameterName = "@pbitLPRINTLYDOXOA"
				array(58).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSHOWLYDOXOA.Checked, 1, 0))
				array(59) = sqlCommand.CreateParameter()
				array(59).ParameterName = "@pbitLINCHUYENMON"
				array(59).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLInChuyenMon.Checked, 1, 0))
				array(60) = sqlCommand.CreateParameter()
				array(60).ParameterName = "@pbitLSHOWKHU"
				array(60).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkKhu.Checked, 1, 0))
				array(61) = sqlCommand.CreateParameter()
				array(61).ParameterName = "@pbitLSHOWTONGSL"
				array(61).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkTongSL.Checked, 1, 0))
				Dim memoryStream As MemoryStream = New MemoryStream()
				Me.picpreview.BackgroundImage.Save(memoryStream, ImageFormat.Jpeg)
				Dim array2 As Byte() = memoryStream.ToArray()
				array(62) = sqlCommand.CreateParameter()
				array(62).ParameterName = "@pbitLSHOWLOGO"
				array(62).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLShowLogo.Checked, 1, 0))
				array(63) = sqlCommand.CreateParameter()
				array(63).ParameterName = "@IMGLOGO"
				array(63).Value = array2
				array(64) = sqlCommand.CreateParameter()
				array(64).ParameterName = "@pbitLSORTNH"
				array(64).Value = Me.chkLSortNH.Checked
				array(65) = sqlCommand.CreateParameter()
				array(65).ParameterName = "@pbitLSHOWSLMAIN"
				array(65).Value = Me.chkLShowSLMain.Checked
				array(66) = sqlCommand.CreateParameter()
				array(66).ParameterName = "@pbitLSHOWCUS"
				array(66).Value = Me.chkLShowCus.Checked
				array(67) = sqlCommand.CreateParameter()
				array(67).ParameterName = "@pbitLSTTPERITEM"
				array(67).Value = Me.chkSTTPerItem.Checked
				array(68) = sqlCommand.CreateParameter()
				array(68).ParameterName = "@pbitLSPLITMOVETBL"
				array(68).Value = Me.chkSplitMoveTBL.Checked
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@int_Result"
				array(33).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAYINBEP_UPDATE_DMMAYINBEP", flag)
				Dim num As Integer = Conversions.ToInteger(array(33).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(100), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001EF7 RID: 7927 RVA: 0x0017FCA8 File Offset: 0x0017DEA8
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAYINBEP_DEL_DMMAYINBEP", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001EF8 RID: 7928 RVA: 0x0017FE6C File Offset: 0x0017E06C
		Private Function fGetData_DMMAY() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMMAY = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMAY")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMMAY ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001EF9 RID: 7929 RVA: 0x0017FF18 File Offset: 0x0017E118
		Private Function fGetData_DMLOAIMAYIN() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mTbLOAIMAYIN.Columns.Add("OBJID")
				Me.mTbLOAIMAYIN.Columns.Add("OBJNAME")
				Dim flag As Boolean = Me.mbytFormStatus = 6 OrElse Me.mbytFormStatus = 5
				If flag Then
					Me.mTbLOAIMAYIN.Rows.Add(New Object() { "", "" })
				End If
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "0", Me.mArrStrFrmMess(93) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "1", Me.mArrStrFrmMess(94) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "2", Me.mArrStrFrmMess(95) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "3", Me.mArrStrFrmMess(96) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "4", Me.mArrStrFrmMess(97) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "5", Me.mArrStrFrmMess(98) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "6", Me.mArrStrFrmMess(99) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "7", Me.mArrStrFrmMess(137) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "8", Me.mArrStrFrmMess(141) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "9", Me.mArrStrFrmMess(146) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "10", Me.mArrStrFrmMess(147) })
				Me.mTbLOAIMAYIN.Rows.Add(New Object() { "11", Me.mArrStrFrmMess(155) })
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMLOAIMAYIN ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001EFA RID: 7930 RVA: 0x0018027C File Offset: 0x0017E47C
		Private Function fGetData_4ComboBox() As Byte
			Try
				Dim cmbLoaiMayIn As ComboBox = Me.cmbLoaiMayIn
				cmbLoaiMayIn.DataSource = Me.mTbLOAIMAYIN
				cmbLoaiMayIn.DisplayMember = "OBJNAME"
				cmbLoaiMayIn.ValueMember = "OBJID"
				cmbLoaiMayIn.SelectedIndex = Conversions.ToInteger(Me.pStrLoaiMayin)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4ComboBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Dim b As Byte
			Return b
		End Function

		' Token: 0x06001EFB RID: 7931 RVA: 0x00180350 File Offset: 0x0017E550
		Private Sub sDisable(pblnValue As Boolean)
			Try
				Me.lblCOMName.Visible = pblnValue
				Me.cmbCOMName.Visible = pblnValue
				Me.lblBaudrate.Visible = pblnValue
				Me.cmbBaudrate.Visible = pblnValue
				Me.lblDataBit.Visible = pblnValue
				Me.cmbDataBit.Visible = pblnValue
				Me.lblParityBit.Visible = pblnValue
				Me.cmbParityBit.Visible = pblnValue
				Me.lblStopBit.Visible = pblnValue
				Me.cmbStopBit.Visible = pblnValue
				Me.lblFlowControl.Visible = pblnValue
				Me.cmbFlowControl.Visible = pblnValue
				Me.lblTimeOut.Visible = pblnValue
				Me.txtTimeOut.Visible = pblnValue
				Me.cmbLTENHHFORMAT1.Visible = pblnValue
				Me.cmbLTENHHFORMAT2.Visible = pblnValue
				Me.cmbLTENHHFORMAT3.Visible = pblnValue
				Me.txtBEPFONT1.Visible = Not pblnValue
				Me.txtBEPFONT2.Visible = Not pblnValue
				Me.txtBEPFONT3.Visible = Not pblnValue
				Me.txtBEPSIZE1.Visible = Not pblnValue
				Me.txtBEPSIZE2.Visible = Not pblnValue
				Me.txtBEPSIZE3.Visible = Not pblnValue
				Me.chkBEPI1.Visible = Not pblnValue
				Me.chkBEPI2.Visible = Not pblnValue
				Me.chkBEPI3.Visible = Not pblnValue
				Me.chkBEPB1.Visible = Not pblnValue
				Me.chkBEPB2.Visible = Not pblnValue
				Me.chkBEPB3.Visible = Not pblnValue
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sDisable ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EFC RID: 7932 RVA: 0x0018057C File Offset: 0x0017E77C
		Private Sub btnSECLECTMAYCALL_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAY As frmDMMAY1 = New frmDMMAY1()
				frmDMMAY.pBlnMultiSel = True
				frmDMMAY.pBytOpen_From_Menu = 7
				frmDMMAY.btnSelect.Visible = True
				frmDMMAY.ShowDialog()
				Dim pBlnOK As Boolean = frmDMMAY.pBlnOK
				If pBlnOK Then
					Me.TxtMAMAYCALL.Text = frmDMMAY.pStrOBJID.Trim()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMNH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EFD RID: 7933 RVA: 0x0018065C File Offset: 0x0017E85C
		Private Sub TxtMAMAYCALL_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbCOMName.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001EFE RID: 7934 RVA: 0x00180700 File Offset: 0x0017E900
		Private Sub TxtMAMAYCALL_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMMAY Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMMAY.Columns("OBJID")
					Me.mclsTbDMMAY.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMMAY.Rows.Find(Strings.Trim(Me.txtMAMAY.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENMAYCALL.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENMAYCALL.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001EFF RID: 7935 RVA: 0x00180854 File Offset: 0x0017EA54
		Private Sub ChkLSHOWBILL_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.ChkLBOLD.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - ChkLSHOWBILL_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001F00 RID: 7936 RVA: 0x001808F8 File Offset: 0x0017EAF8
		Private Sub ChkLBOLD_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.ChkLSHOWPRICE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - ChkLSHOWBILL_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001F01 RID: 7937 RVA: 0x0018099C File Offset: 0x0017EB9C
		Private Sub cmbLTENHHFORMAT1_SelectionChangeCommitted(sender As Object, e As EventArgs)
			Select Case Me.cmbLTENHHFORMAT1.SelectedIndex
				Case 0
					Me.txtBEPSIZE1.Text = Conversions.ToString(9)
				Case 1
					Me.txtBEPSIZE1.Text = Conversions.ToString(10)
				Case 2
					Me.txtBEPSIZE1.Text = Conversions.ToString(11)
			End Select
		End Sub

		' Token: 0x06001F02 RID: 7938 RVA: 0x00180A10 File Offset: 0x0017EC10
		Private Sub cmbLTENHHFORMAT2_SelectionChangeCommitted(sender As Object, e As EventArgs)
			Select Case Me.cmbLTENHHFORMAT2.SelectedIndex
				Case 0
					Me.txtBEPSIZE2.Text = Conversions.ToString(9)
				Case 1
					Me.txtBEPSIZE2.Text = Conversions.ToString(10)
				Case 2
					Me.txtBEPSIZE2.Text = Conversions.ToString(11)
			End Select
		End Sub

		' Token: 0x06001F03 RID: 7939 RVA: 0x00180A84 File Offset: 0x0017EC84
		Private Sub cmbLTENHHFORMAT3_SelectionChangeCommitted(sender As Object, e As EventArgs)
			Select Case Me.cmbLTENHHFORMAT3.SelectedIndex
				Case 0
					Me.txtBEPSIZE3.Text = Conversions.ToString(9)
				Case 1
					Me.txtBEPSIZE3.Text = Conversions.ToString(10)
				Case 2
					Me.txtBEPSIZE3.Text = Conversions.ToString(11)
			End Select
		End Sub

		' Token: 0x06001F04 RID: 7940 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub txtBEPSIZE1_TextChanged(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06001F05 RID: 7941 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub txtBEPSIZE2_TextChanged(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06001F06 RID: 7942 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub txtBEPSIZE3_TextChanged(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06001F07 RID: 7943 RVA: 0x00180AF8 File Offset: 0x0017ECF8
		Private Sub cmbLTENHHFORMAT1_VisibleChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Me.txtBEPSIZE1.Text.Trim(), "9", False) = 0
				If flag Then
					Me.cmbLTENHHFORMAT1.SelectedIndex = 0
				Else
					flag = Operators.CompareString(Me.txtBEPSIZE1.Text.Trim(), "10", False) = 0
					If flag Then
						Me.cmbLTENHHFORMAT1.SelectedIndex = 1
					Else
						flag = Operators.CompareString(Me.txtBEPSIZE1.Text.Trim(), "11", False) = 0
						If flag Then
							Me.cmbLTENHHFORMAT1.SelectedIndex = 2
						Else
							Me.cmbLTENHHFORMAT1.SelectedIndex = 0
						End If
					End If
				End If
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001F08 RID: 7944 RVA: 0x00180BCC File Offset: 0x0017EDCC
		Private Sub cmbLTENHHFORMAT2_VisibleChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Me.txtBEPSIZE2.Text.Trim(), "9", False) = 0
				If flag Then
					Me.cmbLTENHHFORMAT2.SelectedIndex = 0
				Else
					flag = Operators.CompareString(Me.txtBEPSIZE2.Text.Trim(), "10", False) = 0
					If flag Then
						Me.cmbLTENHHFORMAT2.SelectedIndex = 1
					Else
						flag = Operators.CompareString(Me.txtBEPSIZE2.Text.Trim(), "11", False) = 0
						If flag Then
							Me.cmbLTENHHFORMAT2.SelectedIndex = 2
						Else
							Me.cmbLTENHHFORMAT2.SelectedIndex = 0
						End If
					End If
				End If
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001F09 RID: 7945 RVA: 0x00180CA0 File Offset: 0x0017EEA0
		Private Sub cmbLTENHHFORMAT3_VisibleChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Me.txtBEPSIZE3.Text.Trim(), "9", False) = 0
				If flag Then
					Me.cmbLTENHHFORMAT3.SelectedIndex = 0
				Else
					flag = Operators.CompareString(Me.txtBEPSIZE3.Text.Trim(), "10", False) = 0
					If flag Then
						Me.cmbLTENHHFORMAT3.SelectedIndex = 1
					Else
						flag = Operators.CompareString(Me.txtBEPSIZE3.Text.Trim(), "11", False) = 0
						If flag Then
							Me.cmbLTENHHFORMAT3.SelectedIndex = 2
						Else
							Me.cmbLTENHHFORMAT3.SelectedIndex = 0
						End If
					End If
				End If
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001F0A RID: 7946 RVA: 0x00180D74 File Offset: 0x0017EF74
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x06001F0B RID: 7947 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x06001F0C RID: 7948 RVA: 0x0000669A File Offset: 0x0000489A
		Private Sub chkLInChuyenBan_CheckedChanged(sender As Object, e As EventArgs)
			Me.lblLInChuyenMon.Enabled = Me.chkLInChuyenBan.Checked
			Me.chkLInChuyenMon.Enabled = Me.chkLInChuyenBan.Checked
		End Sub

		' Token: 0x06001F0D RID: 7949 RVA: 0x00180DF0 File Offset: 0x0017EFF0
		Private Sub btnBrowse2_Click(sender As Object, e As EventArgs)
			Try
				Dim openFileDialog As OpenFileDialog = New OpenFileDialog()
				openFileDialog.Title = "Image"
				Dim flag As Boolean = openFileDialog.ShowDialog() = DialogResult.OK
				If flag Then
					Dim text As String = openFileDialog.FileName.Trim()
					Me.picpreview.BackgroundImage = Image.FromFile(text)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnBrowse2_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x04000C0E RID: 3086
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000C10 RID: 3088
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000C11 RID: 3089
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000C12 RID: 3090
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000C13 RID: 3091
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000C14 RID: 3092
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000C15 RID: 3093
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000C16 RID: 3094
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000C17 RID: 3095
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000C18 RID: 3096
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000C19 RID: 3097
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000C1A RID: 3098
		<AccessedThroughProperty("lblTimeOut")>
		Private _lblTimeOut As Label

		' Token: 0x04000C1B RID: 3099
		<AccessedThroughProperty("lblPrintCount")>
		Private _lblPrintCount As Label

		' Token: 0x04000C1C RID: 3100
		<AccessedThroughProperty("lblComputer")>
		Private _lblComputer As Label

		' Token: 0x04000C1D RID: 3101
		<AccessedThroughProperty("txtTimeOut")>
		Private _txtTimeOut As TextBox

		' Token: 0x04000C1E RID: 3102
		<AccessedThroughProperty("txtPrintCount")>
		Private _txtPrintCount As TextBox

		' Token: 0x04000C1F RID: 3103
		<AccessedThroughProperty("lblCOMName")>
		Private _lblCOMName As Label

		' Token: 0x04000C20 RID: 3104
		<AccessedThroughProperty("lblBaudrate")>
		Private _lblBaudrate As Label

		' Token: 0x04000C21 RID: 3105
		<AccessedThroughProperty("lblDataBit")>
		Private _lblDataBit As Label

		' Token: 0x04000C22 RID: 3106
		<AccessedThroughProperty("lblParityBit")>
		Private _lblParityBit As Label

		' Token: 0x04000C23 RID: 3107
		<AccessedThroughProperty("lblStopBit")>
		Private _lblStopBit As Label

		' Token: 0x04000C24 RID: 3108
		<AccessedThroughProperty("lblFlowControl")>
		Private _lblFlowControl As Label

		' Token: 0x04000C25 RID: 3109
		<AccessedThroughProperty("txtColor")>
		Private _txtColor As TextBox

		' Token: 0x04000C26 RID: 3110
		<AccessedThroughProperty("txtRemark")>
		Private _txtRemark As TextBox

		' Token: 0x04000C27 RID: 3111
		<AccessedThroughProperty("lblRemark")>
		Private _lblRemark As Label

		' Token: 0x04000C28 RID: 3112
		<AccessedThroughProperty("txtTENMAY")>
		Private _txtTENMAY As TextBox

		' Token: 0x04000C29 RID: 3113
		<AccessedThroughProperty("txtMAMAY")>
		Private _txtMAMAY As TextBox

		' Token: 0x04000C2A RID: 3114
		<AccessedThroughProperty("btnDMMAY")>
		Private _btnDMMAY As Button

		' Token: 0x04000C2B RID: 3115
		<AccessedThroughProperty("cmbBaudrate")>
		Private _cmbBaudrate As ComboBox

		' Token: 0x04000C2C RID: 3116
		<AccessedThroughProperty("cmbDataBit")>
		Private _cmbDataBit As ComboBox

		' Token: 0x04000C2D RID: 3117
		<AccessedThroughProperty("cmbParityBit")>
		Private _cmbParityBit As ComboBox

		' Token: 0x04000C2E RID: 3118
		<AccessedThroughProperty("cmbStopBit")>
		Private _cmbStopBit As ComboBox

		' Token: 0x04000C2F RID: 3119
		<AccessedThroughProperty("cmbFlowControl")>
		Private _cmbFlowControl As ComboBox

		' Token: 0x04000C30 RID: 3120
		<AccessedThroughProperty("cmbCOMName")>
		Private _cmbCOMName As ComboBox

		' Token: 0x04000C31 RID: 3121
		<AccessedThroughProperty("cmbLoaiMayIn")>
		Private _cmbLoaiMayIn As ComboBox

		' Token: 0x04000C32 RID: 3122
		<AccessedThroughProperty("lblLoaiMayIn")>
		Private _lblLoaiMayIn As Label

		' Token: 0x04000C33 RID: 3123
		<AccessedThroughProperty("chkLSHARE")>
		Private _chkLSHARE As CheckBox

		' Token: 0x04000C34 RID: 3124
		<AccessedThroughProperty("ChkLSHOWBILL")>
		Private _ChkLSHOWBILL As CheckBox

		' Token: 0x04000C35 RID: 3125
		<AccessedThroughProperty("LblSHOWBILL")>
		Private _LblSHOWBILL As Label

		' Token: 0x04000C36 RID: 3126
		<AccessedThroughProperty("ChkLBOLD")>
		Private _ChkLBOLD As CheckBox

		' Token: 0x04000C37 RID: 3127
		<AccessedThroughProperty("lBLBOLD")>
		Private _lBLBOLD As Label

		' Token: 0x04000C38 RID: 3128
		<AccessedThroughProperty("ChkLSHOWPRICE")>
		Private _ChkLSHOWPRICE As CheckBox

		' Token: 0x04000C39 RID: 3129
		<AccessedThroughProperty("LblSHOWPRICE")>
		Private _LblSHOWPRICE As Label

		' Token: 0x04000C3A RID: 3130
		<AccessedThroughProperty("lblLSHARE")>
		Private _lblLSHARE As Label

		' Token: 0x04000C3B RID: 3131
		<AccessedThroughProperty("txtTENMAYCALL")>
		Private _txtTENMAYCALL As TextBox

		' Token: 0x04000C3C RID: 3132
		<AccessedThroughProperty("TxtMAMAYCALL")>
		Private _TxtMAMAYCALL As TextBox

		' Token: 0x04000C3D RID: 3133
		<AccessedThroughProperty("btnSECLECTMAYCALL")>
		Private _btnSECLECTMAYCALL As Button

		' Token: 0x04000C3E RID: 3134
		<AccessedThroughProperty("LblMAMAYTINHCALL")>
		Private _LblMAMAYTINHCALL As Label

		' Token: 0x04000C3F RID: 3135
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000C40 RID: 3136
		<AccessedThroughProperty("chkCus")>
		Private _chkCus As CheckBox

		' Token: 0x04000C41 RID: 3137
		<AccessedThroughProperty("lblCus")>
		Private _lblCus As Label

		' Token: 0x04000C42 RID: 3138
		<AccessedThroughProperty("chkService")>
		Private _chkService As CheckBox

		' Token: 0x04000C43 RID: 3139
		<AccessedThroughProperty("lblSevice")>
		Private _lblSevice As Label

		' Token: 0x04000C44 RID: 3140
		<AccessedThroughProperty("ckhCashier")>
		Private _ckhCashier As CheckBox

		' Token: 0x04000C45 RID: 3141
		<AccessedThroughProperty("lblCashier")>
		Private _lblCashier As Label

		' Token: 0x04000C46 RID: 3142
		<AccessedThroughProperty("chkTable")>
		Private _chkTable As CheckBox

		' Token: 0x04000C47 RID: 3143
		<AccessedThroughProperty("lblTable")>
		Private _lblTable As Label

		' Token: 0x04000C48 RID: 3144
		<AccessedThroughProperty("chkDate")>
		Private _chkDate As CheckBox

		' Token: 0x04000C49 RID: 3145
		<AccessedThroughProperty("lblDate")>
		Private _lblDate As Label

		' Token: 0x04000C4A RID: 3146
		<AccessedThroughProperty("chkOrder")>
		Private _chkOrder As CheckBox

		' Token: 0x04000C4B RID: 3147
		<AccessedThroughProperty("lblOrder")>
		Private _lblOrder As Label

		' Token: 0x04000C4C RID: 3148
		<AccessedThroughProperty("txtPrintWidth")>
		Private _txtPrintWidth As TextBox

		' Token: 0x04000C4D RID: 3149
		<AccessedThroughProperty("lblPrintW")>
		Private _lblPrintW As Label

		' Token: 0x04000C4E RID: 3150
		<AccessedThroughProperty("chkSplit")>
		Private _chkSplit As CheckBox

		' Token: 0x04000C4F RID: 3151
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000C50 RID: 3152
		<AccessedThroughProperty("chkLCALL")>
		Private _chkLCALL As CheckBox

		' Token: 0x04000C51 RID: 3153
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000C52 RID: 3154
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x04000C53 RID: 3155
		<AccessedThroughProperty("cmbLTENHHFORMAT1")>
		Private _cmbLTENHHFORMAT1 As ComboBox

		' Token: 0x04000C54 RID: 3156
		<AccessedThroughProperty("chkLSHOWLIEN")>
		Private _chkLSHOWLIEN As CheckBox

		' Token: 0x04000C55 RID: 3157
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x04000C56 RID: 3158
		<AccessedThroughProperty("Label8")>
		Private _Label8 As Label

		' Token: 0x04000C57 RID: 3159
		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		' Token: 0x04000C58 RID: 3160
		<AccessedThroughProperty("Label6")>
		Private _Label6 As Label

		' Token: 0x04000C59 RID: 3161
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x04000C5A RID: 3162
		<AccessedThroughProperty("txtRight")>
		Private _txtRight As TextBox

		' Token: 0x04000C5B RID: 3163
		<AccessedThroughProperty("Label9")>
		Private _Label9 As Label

		' Token: 0x04000C5C RID: 3164
		<AccessedThroughProperty("txtBottom")>
		Private _txtBottom As TextBox

		' Token: 0x04000C5D RID: 3165
		<AccessedThroughProperty("Label10")>
		Private _Label10 As Label

		' Token: 0x04000C5E RID: 3166
		<AccessedThroughProperty("txtLEFT")>
		Private _txtLEFT As TextBox

		' Token: 0x04000C5F RID: 3167
		<AccessedThroughProperty("Label11")>
		Private _Label11 As Label

		' Token: 0x04000C60 RID: 3168
		<AccessedThroughProperty("txtTOP")>
		Private _txtTOP As TextBox

		' Token: 0x04000C61 RID: 3169
		<AccessedThroughProperty("Label12")>
		Private _Label12 As Label

		' Token: 0x04000C62 RID: 3170
		<AccessedThroughProperty("chkLKITREMARK1LINE")>
		Private _chkLKITREMARK1LINE As CheckBox

		' Token: 0x04000C63 RID: 3171
		<AccessedThroughProperty("Label13")>
		Private _Label13 As Label

		' Token: 0x04000C64 RID: 3172
		<AccessedThroughProperty("cmbDKSOLUONG")>
		Private _cmbDKSOLUONG As ComboBox

		' Token: 0x04000C65 RID: 3173
		<AccessedThroughProperty("Label14")>
		Private _Label14 As Label

		' Token: 0x04000C66 RID: 3174
		<AccessedThroughProperty("Label15")>
		Private _Label15 As Label

		' Token: 0x04000C67 RID: 3175
		<AccessedThroughProperty("chkDVT")>
		Private _chkDVT As CheckBox

		' Token: 0x04000C68 RID: 3176
		<AccessedThroughProperty("GroupBox1")>
		Private _GroupBox1 As GroupBox

		' Token: 0x04000C69 RID: 3177
		<AccessedThroughProperty("txtBEPFONT1")>
		Private _txtBEPFONT1 As TextBox

		' Token: 0x04000C6A RID: 3178
		<AccessedThroughProperty("txtBEPSIZE1")>
		Private _txtBEPSIZE1 As TextBox

		' Token: 0x04000C6B RID: 3179
		<AccessedThroughProperty("chkBEPI1")>
		Private _chkBEPI1 As CheckBox

		' Token: 0x04000C6C RID: 3180
		<AccessedThroughProperty("chkBEPB1")>
		Private _chkBEPB1 As CheckBox

		' Token: 0x04000C6D RID: 3181
		<AccessedThroughProperty("GroupBox2")>
		Private _GroupBox2 As GroupBox

		' Token: 0x04000C6E RID: 3182
		<AccessedThroughProperty("GroupBox3")>
		Private _GroupBox3 As GroupBox

		' Token: 0x04000C6F RID: 3183
		<AccessedThroughProperty("txtBEPFONT2")>
		Private _txtBEPFONT2 As TextBox

		' Token: 0x04000C70 RID: 3184
		<AccessedThroughProperty("txtBEPSIZE2")>
		Private _txtBEPSIZE2 As TextBox

		' Token: 0x04000C71 RID: 3185
		<AccessedThroughProperty("chkBEPI2")>
		Private _chkBEPI2 As CheckBox

		' Token: 0x04000C72 RID: 3186
		<AccessedThroughProperty("chkBEPB2")>
		Private _chkBEPB2 As CheckBox

		' Token: 0x04000C73 RID: 3187
		<AccessedThroughProperty("txtBEPFONT3")>
		Private _txtBEPFONT3 As TextBox

		' Token: 0x04000C74 RID: 3188
		<AccessedThroughProperty("txtBEPSIZE3")>
		Private _txtBEPSIZE3 As TextBox

		' Token: 0x04000C75 RID: 3189
		<AccessedThroughProperty("chkBEPI3")>
		Private _chkBEPI3 As CheckBox

		' Token: 0x04000C76 RID: 3190
		<AccessedThroughProperty("chkBEPB3")>
		Private _chkBEPB3 As CheckBox

		' Token: 0x04000C77 RID: 3191
		<AccessedThroughProperty("cmbLTENHHFORMAT2")>
		Private _cmbLTENHHFORMAT2 As ComboBox

		' Token: 0x04000C78 RID: 3192
		<AccessedThroughProperty("cmbLTENHHFORMAT3")>
		Private _cmbLTENHHFORMAT3 As ComboBox

		' Token: 0x04000C79 RID: 3193
		<AccessedThroughProperty("Label16")>
		Private _Label16 As Label

		' Token: 0x04000C7A RID: 3194
		<AccessedThroughProperty("chkLCach1Dong")>
		Private _chkLCach1Dong As CheckBox

		' Token: 0x04000C7B RID: 3195
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000C7C RID: 3196
		<AccessedThroughProperty("lblSTT")>
		Private _lblSTT As Label

		' Token: 0x04000C7D RID: 3197
		<AccessedThroughProperty("chkSTT")>
		Private _chkSTT As CheckBox

		' Token: 0x04000C7E RID: 3198
		<AccessedThroughProperty("Label17")>
		Private _Label17 As Label

		' Token: 0x04000C7F RID: 3199
		<AccessedThroughProperty("chkLSHOWTITLE")>
		Private _chkLSHOWTITLE As CheckBox

		' Token: 0x04000C80 RID: 3200
		<AccessedThroughProperty("lblSplitSL1")>
		Private _lblSplitSL1 As Label

		' Token: 0x04000C81 RID: 3201
		<AccessedThroughProperty("chkSplitSL1")>
		Private _chkSplitSL1 As CheckBox

		' Token: 0x04000C82 RID: 3202
		<AccessedThroughProperty("Label18")>
		Private _Label18 As Label

		' Token: 0x04000C83 RID: 3203
		<AccessedThroughProperty("chkLGachSLAm")>
		Private _chkLGachSLAm As CheckBox

		' Token: 0x04000C84 RID: 3204
		<AccessedThroughProperty("Label19")>
		Private _Label19 As Label

		' Token: 0x04000C85 RID: 3205
		<AccessedThroughProperty("chkLPrice1Line")>
		Private _chkLPrice1Line As CheckBox

		' Token: 0x04000C86 RID: 3206
		<AccessedThroughProperty("Label20")>
		Private _Label20 As Label

		' Token: 0x04000C87 RID: 3207
		<AccessedThroughProperty("chkLSHOWMAHH")>
		Private _chkLSHOWMAHH As CheckBox

		' Token: 0x04000C88 RID: 3208
		<AccessedThroughProperty("Label21")>
		Private _Label21 As Label

		' Token: 0x04000C89 RID: 3209
		<AccessedThroughProperty("chkLShowSLCombo")>
		Private _chkLShowSLCombo As CheckBox

		' Token: 0x04000C8A RID: 3210
		<AccessedThroughProperty("Label22")>
		Private _Label22 As Label

		' Token: 0x04000C8B RID: 3211
		<AccessedThroughProperty("chkLSHOWLYDOXOA")>
		Private _chkLSHOWLYDOXOA As CheckBox

		' Token: 0x04000C8C RID: 3212
		<AccessedThroughProperty("Label23")>
		Private _Label23 As Label

		' Token: 0x04000C8D RID: 3213
		<AccessedThroughProperty("Label24")>
		Private _Label24 As Label

		' Token: 0x04000C8E RID: 3214
		<AccessedThroughProperty("chkLInChuyenBan")>
		Private _chkLInChuyenBan As CheckBox

		' Token: 0x04000C8F RID: 3215
		<AccessedThroughProperty("Label25")>
		Private _Label25 As Label

		' Token: 0x04000C90 RID: 3216
		<AccessedThroughProperty("Label26")>
		Private _Label26 As Label

		' Token: 0x04000C91 RID: 3217
		<AccessedThroughProperty("chkLInChuyenMon")>
		Private _chkLInChuyenMon As CheckBox

		' Token: 0x04000C92 RID: 3218
		<AccessedThroughProperty("lblLInChuyenMon")>
		Private _lblLInChuyenMon As Label

		' Token: 0x04000C93 RID: 3219
		<AccessedThroughProperty("Label27")>
		Private _Label27 As Label

		' Token: 0x04000C94 RID: 3220
		<AccessedThroughProperty("chkKhu")>
		Private _chkKhu As CheckBox

		' Token: 0x04000C95 RID: 3221
		<AccessedThroughProperty("Label28")>
		Private _Label28 As Label

		' Token: 0x04000C96 RID: 3222
		<AccessedThroughProperty("chkTongSL")>
		Private _chkTongSL As CheckBox

		' Token: 0x04000C97 RID: 3223
		<AccessedThroughProperty("grpLogo")>
		Private _grpLogo As GroupBox

		' Token: 0x04000C98 RID: 3224
		<AccessedThroughProperty("Label29")>
		Private _Label29 As Label

		' Token: 0x04000C99 RID: 3225
		<AccessedThroughProperty("chkLShowLogo")>
		Private _chkLShowLogo As CheckBox

		' Token: 0x04000C9A RID: 3226
		<AccessedThroughProperty("picpreview")>
		Private _picpreview As PictureBox

		' Token: 0x04000C9B RID: 3227
		<AccessedThroughProperty("btnBrowse2")>
		Private _btnBrowse2 As Button

		' Token: 0x04000C9C RID: 3228
		<AccessedThroughProperty("chkLSortNH")>
		Private _chkLSortNH As CheckBox

		' Token: 0x04000C9D RID: 3229
		<AccessedThroughProperty("Label30")>
		Private _Label30 As Label

		' Token: 0x04000C9E RID: 3230
		<AccessedThroughProperty("Label32")>
		Private _Label32 As Label

		' Token: 0x04000C9F RID: 3231
		<AccessedThroughProperty("chkLShowCus")>
		Private _chkLShowCus As CheckBox

		' Token: 0x04000CA0 RID: 3232
		<AccessedThroughProperty("Label31")>
		Private _Label31 As Label

		' Token: 0x04000CA1 RID: 3233
		<AccessedThroughProperty("chkLShowSLMain")>
		Private _chkLShowSLMain As CheckBox

		' Token: 0x04000CA2 RID: 3234
		<AccessedThroughProperty("lblSTTPerItem")>
		Private _lblSTTPerItem As Label

		' Token: 0x04000CA3 RID: 3235
		<AccessedThroughProperty("chkSTTPerItem")>
		Private _chkSTTPerItem As CheckBox

		' Token: 0x04000CA4 RID: 3236
		<AccessedThroughProperty("chkSplitMoveTBL")>
		Private _chkSplitMoveTBL As CheckBox

		' Token: 0x04000CA5 RID: 3237
		<AccessedThroughProperty("Label33")>
		Private _Label33 As Label

		' Token: 0x04000CA6 RID: 3238
		Private mArrStrFrmMess As String()

		' Token: 0x04000CA7 RID: 3239
		Private mbytFormStatus As Byte

		' Token: 0x04000CA8 RID: 3240
		Private mbytSuccess As Byte

		' Token: 0x04000CA9 RID: 3241
		Private mStrFilter As String

		' Token: 0x04000CAA RID: 3242
		Private mclsTbDMMAY As clsConnect

		' Token: 0x04000CAB RID: 3243
		Private mstrMAY As String

		' Token: 0x04000CAC RID: 3244
		Private mstrLoaiMayIn As String

		' Token: 0x04000CAD RID: 3245
		Private mTbLOAIMAYIN As DataTable

		' Token: 0x04000CAE RID: 3246
		Private mstrCOMNAME As String

		' Token: 0x04000CAF RID: 3247
		Private mstrBAULDRATE As String

		' Token: 0x04000CB0 RID: 3248
		Private mstrDATABIT As String

		' Token: 0x04000CB1 RID: 3249
		Private mstrPARITYBIT As String

		' Token: 0x04000CB2 RID: 3250
		Private mstrSTOPBIT As String

		' Token: 0x04000CB3 RID: 3251
		Private mstrFLOWCONTROL As String

		' Token: 0x04000CB4 RID: 3252
		Private mbytLTENHHFORMAT As Byte

		' Token: 0x04000CB5 RID: 3253
		Private mbytDKSOLUONG As Byte
	End Class
End Namespace
