﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000060 RID: 96
	<DesignerGenerated()>
	Public Partial Class frmDMMAY2
		Inherits Form

		' Token: 0x06001CD7 RID: 7383 RVA: 0x00164D60 File Offset: 0x00162F60
		<DebuggerNonUserCode()>
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMMAY2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMMAY2_Load
			frmDMMAY2.__ENCList.Add(New WeakReference(Me))
			Me.InitializeComponent()
		End Sub

		' Token: 0x170009D4 RID: 2516
		' (get) Token: 0x06001CDA RID: 7386 RVA: 0x00165F9C File Offset: 0x0016419C
		' (set) Token: 0x06001CDB RID: 7387 RVA: 0x000060AE File Offset: 0x000042AE
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x170009D5 RID: 2517
		' (get) Token: 0x06001CDC RID: 7388 RVA: 0x00165FB4 File Offset: 0x001641B4
		' (set) Token: 0x06001CDD RID: 7389 RVA: 0x00165FCC File Offset: 0x001641CC
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170009D6 RID: 2518
		' (get) Token: 0x06001CDE RID: 7390 RVA: 0x00166038 File Offset: 0x00164238
		' (set) Token: 0x06001CDF RID: 7391 RVA: 0x000060B8 File Offset: 0x000042B8
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x170009D7 RID: 2519
		' (get) Token: 0x06001CE0 RID: 7392 RVA: 0x00166050 File Offset: 0x00164250
		' (set) Token: 0x06001CE1 RID: 7393 RVA: 0x00166068 File Offset: 0x00164268
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x170009D8 RID: 2520
		' (get) Token: 0x06001CE2 RID: 7394 RVA: 0x001660D4 File Offset: 0x001642D4
		' (set) Token: 0x06001CE3 RID: 7395 RVA: 0x001660EC File Offset: 0x001642EC
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170009D9 RID: 2521
		' (get) Token: 0x06001CE4 RID: 7396 RVA: 0x00166158 File Offset: 0x00164358
		' (set) Token: 0x06001CE5 RID: 7397 RVA: 0x00166170 File Offset: 0x00164370
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170009DA RID: 2522
		' (get) Token: 0x06001CE6 RID: 7398 RVA: 0x001661DC File Offset: 0x001643DC
		' (set) Token: 0x06001CE7 RID: 7399 RVA: 0x000060C2 File Offset: 0x000042C2
		Friend Overridable Property lblMAHH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAHH = value
			End Set
		End Property

		' Token: 0x170009DB RID: 2523
		' (get) Token: 0x06001CE8 RID: 7400 RVA: 0x001661F4 File Offset: 0x001643F4
		' (set) Token: 0x06001CE9 RID: 7401 RVA: 0x0016620C File Offset: 0x0016440C
		Friend Overridable Property txtMAKHO As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKHO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKHO IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKHO.KeyPress, AddressOf Me.txtMAKHO_KeyPress
					RemoveHandler Me._txtMAKHO.TextChanged, AddressOf Me.txtMAKHO_TextChanged
					RemoveHandler Me._txtMAKHO.GotFocus, AddressOf Me.txtMAKHO_GotFocus
				End If
				Me._txtMAKHO = value
				flag = Me._txtMAKHO IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKHO.KeyPress, AddressOf Me.txtMAKHO_KeyPress
					AddHandler Me._txtMAKHO.TextChanged, AddressOf Me.txtMAKHO_TextChanged
					AddHandler Me._txtMAKHO.GotFocus, AddressOf Me.txtMAKHO_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170009DC RID: 2524
		' (get) Token: 0x06001CEA RID: 7402 RVA: 0x001662DC File Offset: 0x001644DC
		' (set) Token: 0x06001CEB RID: 7403 RVA: 0x000060CC File Offset: 0x000042CC
		Friend Overridable Property lblMAKH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAKH = value
			End Set
		End Property

		' Token: 0x170009DD RID: 2525
		' (get) Token: 0x06001CEC RID: 7404 RVA: 0x001662F4 File Offset: 0x001644F4
		' (set) Token: 0x06001CED RID: 7405 RVA: 0x0016630C File Offset: 0x0016450C
		Friend Overridable Property txtGHICHU As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtGHICHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtGHICHU IsNot Nothing
				If flag Then
					RemoveHandler Me._txtGHICHU.GotFocus, AddressOf Me.txtGHICHU_GotFocus
					RemoveHandler Me._txtGHICHU.KeyPress, AddressOf Me.txtGHICHU_KeyPress
				End If
				Me._txtGHICHU = value
				flag = Me._txtGHICHU IsNot Nothing
				If flag Then
					AddHandler Me._txtGHICHU.GotFocus, AddressOf Me.txtGHICHU_GotFocus
					AddHandler Me._txtGHICHU.KeyPress, AddressOf Me.txtGHICHU_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170009DE RID: 2526
		' (get) Token: 0x06001CEE RID: 7406 RVA: 0x001663A8 File Offset: 0x001645A8
		' (set) Token: 0x06001CEF RID: 7407 RVA: 0x000060D6 File Offset: 0x000042D6
		Friend Overridable Property lblMIN As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMIN
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMIN = value
			End Set
		End Property

		' Token: 0x170009DF RID: 2527
		' (get) Token: 0x06001CF0 RID: 7408 RVA: 0x001663C0 File Offset: 0x001645C0
		' (set) Token: 0x06001CF1 RID: 7409 RVA: 0x000060E0 File Offset: 0x000042E0
		Friend Overridable Property lblMAX As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAX = value
			End Set
		End Property

		' Token: 0x170009E0 RID: 2528
		' (get) Token: 0x06001CF2 RID: 7410 RVA: 0x001663D8 File Offset: 0x001645D8
		' (set) Token: 0x06001CF3 RID: 7411 RVA: 0x001663F0 File Offset: 0x001645F0
		Friend Overridable Property txtTENMAY As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENMAY IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENMAY.KeyPress, AddressOf Me.txtTENMAY_KeyPress
					RemoveHandler Me._txtTENMAY.GotFocus, AddressOf Me.txtTENMAY_GotFocus
				End If
				Me._txtTENMAY = value
				flag = Me._txtTENMAY IsNot Nothing
				If flag Then
					AddHandler Me._txtTENMAY.KeyPress, AddressOf Me.txtTENMAY_KeyPress
					AddHandler Me._txtTENMAY.GotFocus, AddressOf Me.txtTENMAY_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170009E1 RID: 2529
		' (get) Token: 0x06001CF4 RID: 7412 RVA: 0x0016648C File Offset: 0x0016468C
		' (set) Token: 0x06001CF5 RID: 7413 RVA: 0x001664A4 File Offset: 0x001646A4
		Friend Overridable Property btnDMKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMKH.Click, AddressOf Me.btnDMKH_Click
				End If
				Me._btnDMKH = value
				flag = Me._btnDMKH IsNot Nothing
				If flag Then
					AddHandler Me._btnDMKH.Click, AddressOf Me.btnDMKH_Click
				End If
			End Set
		End Property

		' Token: 0x170009E2 RID: 2530
		' (get) Token: 0x06001CF6 RID: 7414 RVA: 0x00166510 File Offset: 0x00164710
		' (set) Token: 0x06001CF7 RID: 7415 RVA: 0x00166528 File Offset: 0x00164728
		Friend Overridable Property txtTENkho As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENkho
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENkho IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENkho.GotFocus, AddressOf Me.txtTENkho_GotFocus
				End If
				Me._txtTENkho = value
				flag = Me._txtTENkho IsNot Nothing
				If flag Then
					AddHandler Me._txtTENkho.GotFocus, AddressOf Me.txtTENkho_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170009E3 RID: 2531
		' (get) Token: 0x06001CF8 RID: 7416 RVA: 0x00166594 File Offset: 0x00164794
		' (set) Token: 0x06001CF9 RID: 7417 RVA: 0x001665AC File Offset: 0x001647AC
		Friend Overridable Property txtMAMAY As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAMAY IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAMAY.KeyPress, AddressOf Me.txtMAMAY_KeyPress
					RemoveHandler Me._txtMAMAY.GotFocus, AddressOf Me.txtMAMAY_GotFocus
				End If
				Me._txtMAMAY = value
				flag = Me._txtMAMAY IsNot Nothing
				If flag Then
					AddHandler Me._txtMAMAY.KeyPress, AddressOf Me.txtMAMAY_KeyPress
					AddHandler Me._txtMAMAY.GotFocus, AddressOf Me.txtMAMAY_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170009E4 RID: 2532
		' (get) Token: 0x06001CFA RID: 7418 RVA: 0x00166648 File Offset: 0x00164848
		' (set) Token: 0x06001CFB RID: 7419 RVA: 0x000060EA File Offset: 0x000042EA
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170009E5 RID: 2533
		' (get) Token: 0x06001CFC RID: 7420 RVA: 0x00166660 File Offset: 0x00164860
		' (set) Token: 0x06001CFD RID: 7421 RVA: 0x00166678 File Offset: 0x00164878
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x170009E6 RID: 2534
		' (get) Token: 0x06001CFE RID: 7422 RVA: 0x001666E4 File Offset: 0x001648E4
		' (set) Token: 0x06001CFF RID: 7423 RVA: 0x001666FC File Offset: 0x001648FC
		Friend Overridable Property txtIP As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtIP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtIP IsNot Nothing
				If flag Then
					RemoveHandler Me._txtIP.KeyPress, AddressOf Me.txtIP_KeyPress
				End If
				Me._txtIP = value
				flag = Me._txtIP IsNot Nothing
				If flag Then
					AddHandler Me._txtIP.KeyPress, AddressOf Me.txtIP_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170009E7 RID: 2535
		' (get) Token: 0x06001D00 RID: 7424 RVA: 0x00166768 File Offset: 0x00164968
		' (set) Token: 0x06001D01 RID: 7425 RVA: 0x000060F4 File Offset: 0x000042F4
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x170009E8 RID: 2536
		' (get) Token: 0x06001D02 RID: 7426 RVA: 0x00166780 File Offset: 0x00164980
		' (set) Token: 0x06001D03 RID: 7427 RVA: 0x00166798 File Offset: 0x00164998
		Friend Overridable Property txtServer As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtServer
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtServer IsNot Nothing
				If flag Then
					RemoveHandler Me._txtServer.KeyPress, AddressOf Me.txtServer_KeyPress
				End If
				Me._txtServer = value
				flag = Me._txtServer IsNot Nothing
				If flag Then
					AddHandler Me._txtServer.KeyPress, AddressOf Me.txtServer_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170009E9 RID: 2537
		' (get) Token: 0x06001D04 RID: 7428 RVA: 0x00166804 File Offset: 0x00164A04
		' (set) Token: 0x06001D05 RID: 7429 RVA: 0x000060FE File Offset: 0x000042FE
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x170009EA RID: 2538
		' (get) Token: 0x06001D06 RID: 7430 RVA: 0x0016681C File Offset: 0x00164A1C
		' (set) Token: 0x06001D07 RID: 7431 RVA: 0x00006108 File Offset: 0x00004308
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x170009EB RID: 2539
		' (get) Token: 0x06001D08 RID: 7432 RVA: 0x00166834 File Offset: 0x00164A34
		' (set) Token: 0x06001D09 RID: 7433 RVA: 0x00006113 File Offset: 0x00004313
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x170009EC RID: 2540
		' (get) Token: 0x06001D0A RID: 7434 RVA: 0x0016684C File Offset: 0x00164A4C
		' (set) Token: 0x06001D0B RID: 7435 RVA: 0x0000611E File Offset: 0x0000431E
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06001D0C RID: 7436 RVA: 0x00166864 File Offset: 0x00164A64
		Private Sub txtMAMAY_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtTENMAY.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001D0D RID: 7437 RVA: 0x00166908 File Offset: 0x00164B08
		Private Sub txtTENMAY_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMAKHO.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAHH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001D0E RID: 7438 RVA: 0x001669AC File Offset: 0x00164BAC
		Private Sub txtMAKHO_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtIP.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHO_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001D0F RID: 7439 RVA: 0x00166A50 File Offset: 0x00164C50
		Private Sub txtGHICHU_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Select Case Me.mbytFormStatus
						Case 1, 2, 3
							Me.btnSave.Focus()
						Case 4
							Me.btnExit.Focus()
						Case 5
							Me.btnFilter.Focus()
						Case 6
							Me.btnFind.Focus()
					End Select
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtGHICHU_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001D10 RID: 7440 RVA: 0x00166B50 File Offset: 0x00164D50
		Private Sub txtMAMAY_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMAMAY.[ReadOnly]
				If [readOnly] Then
					Me.txtTENMAY.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMAY_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D11 RID: 7441 RVA: 0x00166BFC File Offset: 0x00164DFC
		Private Sub txtTENMAY_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENMAY.[ReadOnly]
				If [readOnly] Then
					Me.txtMAKHO.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENMAY_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D12 RID: 7442 RVA: 0x00166CA8 File Offset: 0x00164EA8
		Private Sub txtMAKHO_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMAKHO.[ReadOnly]
				If [readOnly] Then
					Me.txtGHICHU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHO_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D13 RID: 7443 RVA: 0x00166D54 File Offset: 0x00164F54
		Private Sub txtTENkho_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENkho.[ReadOnly]
				If [readOnly] Then
					Me.txtGHICHU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENkho_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D14 RID: 7444 RVA: 0x00166E00 File Offset: 0x00165000
		Private Sub txtGHICHU_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtGHICHU.[ReadOnly]
				If [readOnly] Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtGHICHU_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D15 RID: 7445 RVA: 0x00166EAC File Offset: 0x001650AC
		Private Sub frmDMMAY2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
				Me.txtMAKHO_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAY2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D16 RID: 7446 RVA: 0x00166F68 File Offset: 0x00165168
		Private Sub frmDMMAY2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMKH()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAY2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D17 RID: 7447 RVA: 0x00167028 File Offset: 0x00165228
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtMAMAY.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(36), MsgBoxStyle.Critical, Nothing)
					Me.txtMAMAY.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtTENMAY.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
						Me.txtTENMAY.Focus()
					Else
						flag = Operators.CompareString(Strings.Trim(Me.txtMAKHO.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(40), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKHO.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.txtMAKHO.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENkho.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
								Me.txtMAKHO.Focus()
							Else
								flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
								If flag Then
									Me.mbytSuccess = Me.fAddNew()
								Else
									flag = Me.mbytFormStatus = 3
									If flag Then
										Me.mbytSuccess = Me.fModify()
									End If
								End If
								flag = Me.mbytSuccess = 1
								If flag Then
									mdlVariable.gstrMachineName = Strings.Trim(mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMMAY", "OBJID", mdlVariable.gStrMachine, "OBJNAME"))
									Me.Close()
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D18 RID: 7448 RVA: 0x0016728C File Offset: 0x0016548C
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D19 RID: 7449 RVA: 0x00167330 File Offset: 0x00165530
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim flag As Boolean = (Operators.CompareString(Strings.Trim(Me.txtMAKHO.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENkho.Text), "", False) = 0)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Me.txtMAKHO.Focus()
				Else
					Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtMAMAY.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJID LIKE '%"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtTENMAY.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME LIKE '%"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtMAKHO.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH LIKE '%"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtGHICHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK LIKE '%"), text2), "%'"))
					End If
					Me.mStrFilter = text
					flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
					If flag Then
						Me.mbytSuccess = 1
					End If
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D1A RID: 7450 RVA: 0x00167648 File Offset: 0x00165848
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim flag As Boolean = (Operators.CompareString(Strings.Trim(Me.txtMAKHO.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENkho.Text), "", False) = 0)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Me.txtMAKHO.Focus()
				Else
					Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtMAMAY.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJID LIKE '%"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtTENMAY.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME LIKE '%"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtMAKHO.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH LIKE '%"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtGHICHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK LIKE '%"), text2), "%'"))
					End If
					Me.mStrFilter = text
					flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
					If flag Then
						Me.mbytSuccess = 1
					End If
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D1B RID: 7451 RVA: 0x00167960 File Offset: 0x00165B60
		Private Sub btnDMKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKH As frmDMKH1 = New frmDMKH1()
				frmDMKH.pBytOpen_From_Menu = 7
				frmDMKH.ShowDialog()
				Me.txtMAKHO.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJID, "", False) = 0, Me.txtMAKHO.Text, frmDMKH.pStrOBJID))
				Me.txtTENkho.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJNAME, "", False) = 0, Me.txtTENkho.Text, frmDMKH.pStrOBJNAME))
				frmDMKH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMKH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D1C RID: 7452 RVA: 0x00167A84 File Offset: 0x00165C84
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.txtTENkho.[ReadOnly] = True
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtMAMAY.[ReadOnly] = True
						Me.txtMAMAY.BackColor = Me.txtTENkho.BackColor
						Me.txtTENMAY.Focus()
					Case 4
						Me.txtMAMAY.[ReadOnly] = True
						Me.txtTENMAY.[ReadOnly] = True
						Me.txtMAKHO.[ReadOnly] = True
						Me.txtGHICHU.[ReadOnly] = True
						Me.txtMAMAY.BackColor = Me.txtTENkho.BackColor
						Me.txtTENMAY.BackColor = Me.txtTENkho.BackColor
						Me.txtMAKHO.BackColor = Me.txtTENkho.BackColor
						Me.txtGHICHU.BackColor = Me.txtTENkho.BackColor
						Me.btnDMKH.Enabled = False
				End Select
				Dim flag As Boolean = Operators.CompareString(mdlVariable.gStrStockCode, "", False) <> 0
				If flag Then
					Me.txtMAKHO.[ReadOnly] = True
					Me.txtMAKHO.BackColor = Me.txtTENkho.BackColor
					Me.btnDMKH.Enabled = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001D1D RID: 7453 RVA: 0x00167C80 File Offset: 0x00165E80
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtMAMAY.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtMAKHO.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001D1E RID: 7454 RVA: 0x00167E10 File Offset: 0x00166010
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtTENMAY.MaxLength = 50
				Me.txtMAMAY.MaxLength = 2
				Me.txtMAKHO.MaxLength = 3
				Me.txtMAKHO.Text = mdlVariable.gStrStockCode
				Me.txtMAKHO.CharacterCasing = CharacterCasing.Upper
				Me.txtMAMAY.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001D1F RID: 7455 RVA: 0x00167F10 File Offset: 0x00166110
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001D20 RID: 7456 RVA: 0x001680E4 File Offset: 0x001662E4
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMKH.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D21 RID: 7457 RVA: 0x00168190 File Offset: 0x00166390
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(7) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pvchMA"
				array(0).Value = Strings.Trim(Me.txtMAMAY.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchTEn"
				array(1).Value = Strings.Trim(Me.txtTENMAY.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKHO.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchGHICHU"
				array(3).Value = Strings.Trim(Me.txtGHICHU.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcIP"
				array(5).Value = Strings.Trim(Me.txtIP.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcSERVER"
				array(6).Value = Strings.Trim(Me.txtServer.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@int_Result"
				array(4).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAY_INSERT_DMMAY", flag)
				Dim num As Integer = Conversions.ToInteger(array(4).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtMAMAY.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtMAKHO.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
							Me.txtMAMAY.Focus()
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(41), MsgBoxStyle.Critical, Nothing)
							Me.txtMAMAY.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001D22 RID: 7458 RVA: 0x00168488 File Offset: 0x00166688
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(7) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAMAY"
				array(0).Value = Strings.Trim(Me.txtMAMAY.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchTENMAY"
				array(1).Value = Strings.Trim(Me.txtTENMAY.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKHO.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchGHICHU"
				array(3).Value = Strings.Trim(Me.txtGHICHU.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcIP"
				array(5).Value = Strings.Trim(Me.txtIP.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcSERVER"
				array(6).Value = Strings.Trim(Me.txtServer.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@int_Result"
				array(4).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAY_UPDATE_DMMAY", flag)
				Dim num As Integer = Conversions.ToInteger(array(4).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtMAMAY.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(42), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001D23 RID: 7459 RVA: 0x00168768 File Offset: 0x00166968
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtMAMAY.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAY_DELETE_DMMAY", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 2
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001D24 RID: 7460 RVA: 0x00168910 File Offset: 0x00166B10
		Private Function fGetData_DMKH() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKH = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = Me.mclsTbDMKH IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMKH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001D25 RID: 7461 RVA: 0x001689CC File Offset: 0x00166BCC
		Private Sub txtMAKHO_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKH Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMKH.Columns("OBJID")
					Me.mclsTbDMKH.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKH.Rows.Find(Strings.Trim(Me.txtMAKHO.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENkho.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENkho.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D26 RID: 7462 RVA: 0x00168B20 File Offset: 0x00166D20
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtMAMAY.[ReadOnly]
				If flag Then
					Me.txtTENMAY.Focus()
					Me.txtTENMAY.SelectAll()
				Else
					Me.txtMAMAY.Focus()
					Me.txtMAMAY.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x06001D27 RID: 7463 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x06001D28 RID: 7464 RVA: 0x00168B9C File Offset: 0x00166D9C
		Private Sub txtIP_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtServer.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtIP_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001D29 RID: 7465 RVA: 0x00168C40 File Offset: 0x00166E40
		Private Sub txtServer_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtGHICHU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtServer_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x04000BCC RID: 3020
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000BCE RID: 3022
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000BCF RID: 3023
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000BD0 RID: 3024
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000BD1 RID: 3025
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000BD2 RID: 3026
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000BD3 RID: 3027
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000BD4 RID: 3028
		<AccessedThroughProperty("lblMAHH")>
		Private _lblMAHH As Label

		' Token: 0x04000BD5 RID: 3029
		<AccessedThroughProperty("txtMAKHO")>
		Private _txtMAKHO As TextBox

		' Token: 0x04000BD6 RID: 3030
		<AccessedThroughProperty("lblMAKH")>
		Private _lblMAKH As Label

		' Token: 0x04000BD7 RID: 3031
		<AccessedThroughProperty("txtGHICHU")>
		Private _txtGHICHU As TextBox

		' Token: 0x04000BD8 RID: 3032
		<AccessedThroughProperty("lblMIN")>
		Private _lblMIN As Label

		' Token: 0x04000BD9 RID: 3033
		<AccessedThroughProperty("lblMAX")>
		Private _lblMAX As Label

		' Token: 0x04000BDA RID: 3034
		<AccessedThroughProperty("txtTENMAY")>
		Private _txtTENMAY As TextBox

		' Token: 0x04000BDB RID: 3035
		<AccessedThroughProperty("btnDMKH")>
		Private _btnDMKH As Button

		' Token: 0x04000BDC RID: 3036
		<AccessedThroughProperty("txtTENkho")>
		Private _txtTENkho As TextBox

		' Token: 0x04000BDD RID: 3037
		<AccessedThroughProperty("txtMAMAY")>
		Private _txtMAMAY As TextBox

		' Token: 0x04000BDE RID: 3038
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000BDF RID: 3039
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000BE0 RID: 3040
		<AccessedThroughProperty("txtIP")>
		Private _txtIP As TextBox

		' Token: 0x04000BE1 RID: 3041
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000BE2 RID: 3042
		<AccessedThroughProperty("txtServer")>
		Private _txtServer As TextBox

		' Token: 0x04000BE3 RID: 3043
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000BE4 RID: 3044
		Private mArrStrFrmMess As String()

		' Token: 0x04000BE5 RID: 3045
		Private mbytFormStatus As Byte

		' Token: 0x04000BE6 RID: 3046
		Private mbytSuccess As Byte

		' Token: 0x04000BE7 RID: 3047
		Private mStrFilter As String

		' Token: 0x04000BE8 RID: 3048
		Private mclsTbDMKH As clsConnect
	End Class
End Namespace
