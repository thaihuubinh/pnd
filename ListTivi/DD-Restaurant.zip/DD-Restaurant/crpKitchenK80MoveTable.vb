﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x0200010B RID: 267
	Public Class crpKitchenK80MoveTable
		Inherits ReportClass

		' Token: 0x06005670 RID: 22128 RVA: 0x0000ED22 File Offset: 0x0000CF22
		Public Sub New()
			crpKitchenK80MoveTable.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001EE6 RID: 7910
		' (get) Token: 0x06005671 RID: 22129 RVA: 0x004DACC8 File Offset: 0x004D8EC8
		' (set) Token: 0x06005672 RID: 22130 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crpKitchenK80MoveTable.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001EE7 RID: 7911
		' (get) Token: 0x06005673 RID: 22131 RVA: 0x004DA738 File Offset: 0x004D8938
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsTitle As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001EE8 RID: 7912
		' (get) Token: 0x06005674 RID: 22132 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsCashier As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001EE9 RID: 7913
		' (get) Token: 0x06005675 RID: 22133 RVA: 0x004DA780 File Offset: 0x004D8980
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsService As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001EEA RID: 7914
		' (get) Token: 0x06005676 RID: 22134 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property phsTieude1 As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001EEB RID: 7915
		' (get) Token: 0x06005677 RID: 22135 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property phsTieude2 As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001EEC RID: 7916
		' (get) Token: 0x06005678 RID: 22136 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsTen As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x17001EED RID: 7917
		' (get) Token: 0x06005679 RID: 22137 RVA: 0x004DA810 File Offset: 0x004D8A10
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsSL As Section
			Get
				Return Me.ReportDefinition.Sections(6)
			End Get
		End Property

		' Token: 0x17001EEE RID: 7918
		' (get) Token: 0x0600567A RID: 22138 RVA: 0x004DA834 File Offset: 0x004D8A34
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dsPrice As Section
			Get
				Return Me.ReportDefinition.Sections(7)
			End Get
		End Property

		' Token: 0x17001EEF RID: 7919
		' (get) Token: 0x0600567B RID: 22139 RVA: 0x004DA858 File Offset: 0x004D8A58
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(8)
			End Get
		End Property

		' Token: 0x17001EF0 RID: 7920
		' (get) Token: 0x0600567C RID: 22140 RVA: 0x004DA87C File Offset: 0x004D8A7C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(9)
			End Get
		End Property

		' Token: 0x17001EF1 RID: 7921
		' (get) Token: 0x0600567D RID: 22141 RVA: 0x004DA8A0 File Offset: 0x004D8AA0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property sNgay2 As Section
			Get
				Return Me.ReportDefinition.Sections(10)
			End Get
		End Property

		' Token: 0x17001EF2 RID: 7922
		' (get) Token: 0x0600567E RID: 22142 RVA: 0x004DA8C4 File Offset: 0x004D8AC4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property sNgay As Section
			Get
				Return Me.ReportDefinition.Sections(11)
			End Get
		End Property

		' Token: 0x17001EF3 RID: 7923
		' (get) Token: 0x0600567F RID: 22143 RVA: 0x004DA8E8 File Offset: 0x004D8AE8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(12)
			End Get
		End Property

		' Token: 0x04002703 RID: 9987
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
