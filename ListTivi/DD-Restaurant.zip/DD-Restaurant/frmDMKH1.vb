﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000053 RID: 83
	<DesignerGenerated()>
	Public Partial Class frmDMKH1
		Inherits Form

		' Token: 0x060018B8 RID: 6328 RVA: 0x00132B1C File Offset: 0x00130D1C
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMKH1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMKH1_Load
			frmDMKH1.__ENCList.Add(New WeakReference(Me))
			Me.mStrADDRESS = ""
			Me.mStrEMAIL = ""
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700088B RID: 2187
		' (get) Token: 0x060018BB RID: 6331 RVA: 0x00133DC8 File Offset: 0x00131FC8
		' (set) Token: 0x060018BC RID: 6332 RVA: 0x00005A09 File Offset: 0x00003C09
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x1700088C RID: 2188
		' (get) Token: 0x060018BD RID: 6333 RVA: 0x00133DE0 File Offset: 0x00131FE0
		' (set) Token: 0x060018BE RID: 6334 RVA: 0x00133DF8 File Offset: 0x00131FF8
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x1700088D RID: 2189
		' (get) Token: 0x060018BF RID: 6335 RVA: 0x00133E64 File Offset: 0x00132064
		' (set) Token: 0x060018C0 RID: 6336 RVA: 0x00133E7C File Offset: 0x0013207C
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x1700088E RID: 2190
		' (get) Token: 0x060018C1 RID: 6337 RVA: 0x00133EE8 File Offset: 0x001320E8
		' (set) Token: 0x060018C2 RID: 6338 RVA: 0x00133F00 File Offset: 0x00132100
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x1700088F RID: 2191
		' (get) Token: 0x060018C3 RID: 6339 RVA: 0x00133F6C File Offset: 0x0013216C
		' (set) Token: 0x060018C4 RID: 6340 RVA: 0x00133F84 File Offset: 0x00132184
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000890 RID: 2192
		' (get) Token: 0x060018C5 RID: 6341 RVA: 0x00133FF0 File Offset: 0x001321F0
		' (set) Token: 0x060018C6 RID: 6342 RVA: 0x00134008 File Offset: 0x00132208
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000891 RID: 2193
		' (get) Token: 0x060018C7 RID: 6343 RVA: 0x00134074 File Offset: 0x00132274
		' (set) Token: 0x060018C8 RID: 6344 RVA: 0x0013408C File Offset: 0x0013228C
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000892 RID: 2194
		' (get) Token: 0x060018C9 RID: 6345 RVA: 0x001340F8 File Offset: 0x001322F8
		' (set) Token: 0x060018CA RID: 6346 RVA: 0x00134110 File Offset: 0x00132310
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000893 RID: 2195
		' (get) Token: 0x060018CB RID: 6347 RVA: 0x0013417C File Offset: 0x0013237C
		' (set) Token: 0x060018CC RID: 6348 RVA: 0x00005A13 File Offset: 0x00003C13
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000894 RID: 2196
		' (get) Token: 0x060018CD RID: 6349 RVA: 0x00134194 File Offset: 0x00132394
		' (set) Token: 0x060018CE RID: 6350 RVA: 0x001341AC File Offset: 0x001323AC
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000895 RID: 2197
		' (get) Token: 0x060018CF RID: 6351 RVA: 0x00134218 File Offset: 0x00132418
		' (set) Token: 0x060018D0 RID: 6352 RVA: 0x00134230 File Offset: 0x00132430
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x17000896 RID: 2198
		' (get) Token: 0x060018D1 RID: 6353 RVA: 0x0013429C File Offset: 0x0013249C
		' (set) Token: 0x060018D2 RID: 6354 RVA: 0x001342B4 File Offset: 0x001324B4
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000897 RID: 2199
		' (get) Token: 0x060018D3 RID: 6355 RVA: 0x00134320 File Offset: 0x00132520
		' (set) Token: 0x060018D4 RID: 6356 RVA: 0x00005A1D File Offset: 0x00003C1D
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x17000898 RID: 2200
		' (get) Token: 0x060018D5 RID: 6357 RVA: 0x00134338 File Offset: 0x00132538
		' (set) Token: 0x060018D6 RID: 6358 RVA: 0x00134350 File Offset: 0x00132550
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x17000899 RID: 2201
		' (get) Token: 0x060018D7 RID: 6359 RVA: 0x001343BC File Offset: 0x001325BC
		' (set) Token: 0x060018D8 RID: 6360 RVA: 0x001343D4 File Offset: 0x001325D4
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x1700089A RID: 2202
		' (get) Token: 0x060018D9 RID: 6361 RVA: 0x00134440 File Offset: 0x00132640
		' (set) Token: 0x060018DA RID: 6362 RVA: 0x00134458 File Offset: 0x00132658
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700089B RID: 2203
		' (get) Token: 0x060018DB RID: 6363 RVA: 0x001344C4 File Offset: 0x001326C4
		' (set) Token: 0x060018DC RID: 6364 RVA: 0x001344DC File Offset: 0x001326DC
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x1700089C RID: 2204
		' (get) Token: 0x060018DD RID: 6365 RVA: 0x00134548 File Offset: 0x00132748
		' (set) Token: 0x060018DE RID: 6366 RVA: 0x00134560 File Offset: 0x00132760
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x1700089D RID: 2205
		' (get) Token: 0x060018DF RID: 6367 RVA: 0x001345CC File Offset: 0x001327CC
		' (set) Token: 0x060018E0 RID: 6368 RVA: 0x001345E4 File Offset: 0x001327E4
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x1700089E RID: 2206
		' (get) Token: 0x060018E1 RID: 6369 RVA: 0x00134650 File Offset: 0x00132850
		' (set) Token: 0x060018E2 RID: 6370 RVA: 0x00005A27 File Offset: 0x00003C27
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x1700089F RID: 2207
		' (get) Token: 0x060018E3 RID: 6371 RVA: 0x00134668 File Offset: 0x00132868
		' (set) Token: 0x060018E4 RID: 6372 RVA: 0x00134680 File Offset: 0x00132880
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170008A0 RID: 2208
		' (get) Token: 0x060018E5 RID: 6373 RVA: 0x001346EC File Offset: 0x001328EC
		' (set) Token: 0x060018E6 RID: 6374 RVA: 0x00005A31 File Offset: 0x00003C31
		Public Property pStrEMAIL As String
			Get
				Return Me.mStrEMAIL
			End Get
			Set(value As String)
				Me.mStrEMAIL = value
			End Set
		End Property

		' Token: 0x170008A1 RID: 2209
		' (get) Token: 0x060018E7 RID: 6375 RVA: 0x00134704 File Offset: 0x00132904
		' (set) Token: 0x060018E8 RID: 6376 RVA: 0x00005A3C File Offset: 0x00003C3C
		Public Property pStrADDRESS As String
			Get
				Return Me.mStrADDRESS
			End Get
			Set(value As String)
				Me.mStrADDRESS = value
			End Set
		End Property

		' Token: 0x170008A2 RID: 2210
		' (get) Token: 0x060018E9 RID: 6377 RVA: 0x0013471C File Offset: 0x0013291C
		' (set) Token: 0x060018EA RID: 6378 RVA: 0x00005A47 File Offset: 0x00003C47
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x170008A3 RID: 2211
		' (get) Token: 0x060018EB RID: 6379 RVA: 0x00134734 File Offset: 0x00132934
		' (set) Token: 0x060018EC RID: 6380 RVA: 0x00005A52 File Offset: 0x00003C52
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x170008A4 RID: 2212
		' (get) Token: 0x060018ED RID: 6381 RVA: 0x0013474C File Offset: 0x0013294C
		' (set) Token: 0x060018EE RID: 6382 RVA: 0x00005A5D File Offset: 0x00003C5D
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060018EF RID: 6383 RVA: 0x00134764 File Offset: 0x00132964
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
				Me.mStrOBJNAME = Me.dgvData.CurrentRow.Cells("OBJNAME").Value.ToString().Trim() + "  " + Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value.ToString().Trim()
				Me.mStrADDRESS = Me.dgvData.CurrentRow.Cells("ADDRESS").Value.ToString().Trim()
				Me.mStrEMAIL = Me.dgvData.CurrentRow.Cells("EMAIL").Value.ToString().Trim()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018F0 RID: 6384 RVA: 0x00134900 File Offset: 0x00132B00
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018F1 RID: 6385 RVA: 0x001349D0 File Offset: 0x00132BD0
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018F2 RID: 6386 RVA: 0x00134AC0 File Offset: 0x00132CC0
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018F3 RID: 6387 RVA: 0x00134BA4 File Offset: 0x00132DA4
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018F4 RID: 6388 RVA: 0x00134C68 File Offset: 0x00132E68
		Private Sub frmDMKH1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMKH1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018F5 RID: 6389 RVA: 0x00134D00 File Offset: 0x00132F00
		Private Sub frmDMKH1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMKH1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018F6 RID: 6390 RVA: 0x00134E08 File Offset: 0x00133008
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018F7 RID: 6391 RVA: 0x00134F10 File Offset: 0x00133110
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMKH As frmDMKH2 = New frmDMKH2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMKH.pbytFromStatus = 1
				Dim flag As Boolean = Me.mblnAutoAdd
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKH_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMKH.txtOBJID.Text = Strings.Right("00000" + array(0).Value.ToString(), 2)
						frmDMKH.txtOBJID.[ReadOnly] = True
						frmDMKH.txtOBJID.BackColor = frmDMKH.txt.BackColor
					End If
				End If
				frmDMKH.ShowDialog()
				flag = frmDMKH.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMKH.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMKH.Dispose()
			End Try
		End Sub

		' Token: 0x060018F8 RID: 6392 RVA: 0x00135148 File Offset: 0x00133348
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMKH As frmDMKH2 = New frmDMKH2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMKH2 As frmDMKH2 = frmDMKH
				frmDMKH2.pbytFromStatus = 2
				frmDMKH2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMKH2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
				frmDMKH2.txtADDRESS.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("ADDRESS").Value, ""))
				frmDMKH2.txtTEL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TEL").Value, ""))
				frmDMKH2.txtCONTACT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CONTACT").Value, ""))
				frmDMKH2.txtFAX.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FAX").Value, ""))
				frmDMKH2.txtEMAIL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("EMAIL").Value, ""))
				frmDMKH2.txtGHICHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				Dim flag As Boolean = Me.mblnAutoAdd
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKH_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMKH.txtOBJID.Text = Strings.Right("00000" + array(0).Value.ToString(), 2)
						frmDMKH.txtOBJID.[ReadOnly] = True
						frmDMKH.txtOBJID.BackColor = frmDMKH.txt.BackColor
					End If
				End If
				frmDMKH.ShowDialog()
				flag = frmDMKH.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMKH.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMKH.Dispose()
			End Try
		End Sub

		' Token: 0x060018F9 RID: 6393 RVA: 0x00135560 File Offset: 0x00133760
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMKH As frmDMKH2 = New frmDMKH2()
			Try
				Dim flag As Boolean = Me.mblnAutoAdd
				If flag Then
					frmDMKH.txtOBJID.BackColor = frmDMKH.txt.BackColor
				End If
				flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					frmDMKH.Dispose()
				Else
					Dim frmDMKH2 As frmDMKH2 = frmDMKH
					frmDMKH2.pbytFromStatus = 3
					frmDMKH2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMKH2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMKH2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
					frmDMKH2.txtADDRESS.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("ADDRESS").Value, ""))
					frmDMKH2.txtTEL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TEL").Value, ""))
					frmDMKH2.txtCONTACT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CONTACT").Value, ""))
					frmDMKH2.txtFAX.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FAX").Value, ""))
					frmDMKH2.txtEMAIL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("EMAIL").Value, ""))
					frmDMKH2.txtGHICHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
					frmDMKH.ShowDialog()
					flag = frmDMKH.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMKH.pStrFilter)
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKH.Dispose()
			End Try
		End Sub

		' Token: 0x060018FA RID: 6394 RVA: 0x00135938 File Offset: 0x00133B38
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMKH As frmDMKH2 = New frmDMKH2()
			Try
				Dim flag As Boolean = Me.mblnAutoAdd
				If flag Then
					frmDMKH.txtOBJID.BackColor = frmDMKH.txt.BackColor
				End If
				flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
					frmDMKH.Dispose()
				Else
					Dim frmDMKH2 As frmDMKH2 = frmDMKH
					frmDMKH2.pbytFromStatus = 4
					frmDMKH2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMKH2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMKH2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
					frmDMKH2.txtADDRESS.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("ADDRESS").Value, ""))
					frmDMKH2.txtTEL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TEL").Value, ""))
					frmDMKH2.txtCONTACT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CONTACT").Value, ""))
					frmDMKH2.txtFAX.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FAX").Value, ""))
					frmDMKH2.txtEMAIL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("EMAIL").Value, ""))
					frmDMKH.ShowDialog()
					flag = frmDMKH.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKH.Dispose()
			End Try
		End Sub

		' Token: 0x060018FB RID: 6395 RVA: 0x00135CB4 File Offset: 0x00133EB4
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMKH As frmDMKH2 = New frmDMKH2()
			Try
				frmDMKH.pbytFromStatus = 6
				frmDMKH.ShowDialog()
				Dim flag As Boolean = frmDMKH.pbytSuccess = 0
				If flag Then
					frmDMKH.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMKH.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMKH.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKH.Dispose()
			End Try
		End Sub

		' Token: 0x060018FC RID: 6396 RVA: 0x00135EA8 File Offset: 0x001340A8
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMKH As frmDMKH2 = New frmDMKH2()
			Try
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				frmDMKH.pbytFromStatus = 5
				frmDMKH.ShowDialog()
				Dim flag As Boolean = frmDMKH.pbytSuccess = 0
				If Not flag Then
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMKH.pStrFilter
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKH.Dispose()
			End Try
		End Sub

		' Token: 0x060018FD RID: 6397 RVA: 0x00135FC0 File Offset: 0x001341C0
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMKH As frmDMKH2 = New frmDMKH2()
			Try
				Dim text As String = ""
				Me.mbdsSource.RemoveFilter()
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0
				If flag Then
					Me.mbdsSource.Filter = text
				End If
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKH.Dispose()
			End Try
		End Sub

		' Token: 0x060018FE RID: 6398 RVA: 0x001360B4 File Offset: 0x001342B4
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x060018FF RID: 6399 RVA: 0x00136230 File Offset: 0x00134430
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fPrintDMKH()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001900 RID: 6400 RVA: 0x001362C8 File Offset: 0x001344C8
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001901 RID: 6401 RVA: 0x00136378 File Offset: 0x00134578
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001902 RID: 6402 RVA: 0x00136410 File Offset: 0x00134610
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SUBOBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(17))
				dgvData.Columns("SUBOBJNAME").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("SUBOBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("ADDRESS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("ADDRESS").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("ADDRESS").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TEL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("TEL").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TEL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("FAX").HeaderText = Strings.Trim(Me.mArrStrFrmMess(31))
				dgvData.Columns("FAX").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("FAX").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("EMAIL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(32))
				dgvData.Columns("EMAIL").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("EMAIL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("CONTACT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(29))
				dgvData.Columns("CONTACT").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("CONTACT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(40))
				dgvData.Columns("REMARK").Width = Me.Width - 910 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("FIXED").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001903 RID: 6403 RVA: 0x001368F4 File Offset: 0x00134AF4
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001904 RID: 6404 RVA: 0x00136A74 File Offset: 0x00134C74
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKH_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001905 RID: 6405 RVA: 0x00136B64 File Offset: 0x00134D64
		Private Function fInitForm() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pintResult"
				array(0).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKH_SETPARA_GET_UPDATELIST", flag2)
				flag = flag2
				If flag Then
					Dim b2 As Byte = Conversions.ToByte(array(0).Value)
					Me.mblnAutoAdd = True
					flag = b2 = 3
					If flag Then
						b2 = 1
					Else
						flag = b2 = 2
						If flag Then
							b2 = 0
						Else
							Me.mblnAutoAdd = False
						End If
					End If
					b2 += Me.mBytOpen_FromMenu
					flag = b2 < 8
					If flag Then
						Me.btnAdd.Visible = False
						Me.btnAddDefault.Visible = False
						Me.btnModify.Visible = False
						Me.btnDelete.Visible = False
					End If
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001906 RID: 6406 RVA: 0x00136D5C File Offset: 0x00134F5C
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2070500000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001907 RID: 6407 RVA: 0x00136E68 File Offset: 0x00135068
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001908 RID: 6408 RVA: 0x00136F14 File Offset: 0x00135114
		Private Function fPrintDMKH() As Byte
			Dim rptDMKH As rptDMKH = New rptDMKH()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMKH, "")
				Dim text As String = "2070500000"
				mdlReport.gsSetOfficeReport(rptDMKH, text)
				mdlReport.gsSetFontReport(rptDMKH)
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "SP_GET_DMKH", flag)
				rptDMKH.SetDataSource(clsConnect)
				rptDMKH.DataDefinition.FormulaFields("fStockCode").Text = "{dtReport.OBJID}"
				rptDMKH.DataDefinition.FormulaFields("fStockName").Text = "{dtReport.OBJNAME}"
				rptDMKH.DataDefinition.FormulaFields("fAddress").Text = "{dtReport.ADDRESS}"
				rptDMKH.DataDefinition.FormulaFields("fPhone").Text = "{dtReport.TEL}"
				rptDMKH.DataDefinition.FormulaFields("fFax").Text = "{dtReport.FAX}"
				mdlReport.gsSetTextReport(rptDMKH, "RPTDMKH")
				MyProject.Forms.frmReport.pSource = rptDMKH
				MyProject.Forms.frmReport.MaximizeBox = True
				MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
				Dim textObject As TextObject = CType(rptDMKH.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
				MyProject.Forms.frmReport.Text = textObject.Text
				rptDMKH.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
				rptDMKH.PrintOptions.PaperSize = PaperSize.PaperA4
				MyProject.Forms.frmReport.ShowDialog()
				MyProject.Forms.frmReport.pSource = Nothing
				clsConnect.Dispose()
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMKH " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMKH.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x04000A3F RID: 2623
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000A41 RID: 2625
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000A42 RID: 2626
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000A43 RID: 2627
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000A44 RID: 2628
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000A45 RID: 2629
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000A46 RID: 2630
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000A47 RID: 2631
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000A48 RID: 2632
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000A49 RID: 2633
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000A4A RID: 2634
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000A4B RID: 2635
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000A4C RID: 2636
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000A4D RID: 2637
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000A4E RID: 2638
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000A4F RID: 2639
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000A50 RID: 2640
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000A51 RID: 2641
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000A52 RID: 2642
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000A53 RID: 2643
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000A54 RID: 2644
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000A55 RID: 2645
		Private mArrStrFrmMess As String()

		' Token: 0x04000A56 RID: 2646
		Private mStrOBJID As String

		' Token: 0x04000A57 RID: 2647
		Private mStrOBJNAME As String

		' Token: 0x04000A58 RID: 2648
		Private mStrADDRESS As String

		' Token: 0x04000A59 RID: 2649
		Private mStrEMAIL As String

		' Token: 0x04000A5A RID: 2650
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000A5B RID: 2651
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000A5C RID: 2652
		Private marrDrFind As DataRow()

		' Token: 0x04000A5D RID: 2653
		Private mintFindLastPos As Integer

		' Token: 0x04000A5E RID: 2654
		Private mblnAutoAdd As Boolean

		' Token: 0x04000A5F RID: 2655
		Private mclsTbBranch As clsConnect
	End Class
End Namespace
