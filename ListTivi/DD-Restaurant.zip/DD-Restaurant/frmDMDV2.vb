﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000044 RID: 68
	<DesignerGenerated()>
	Public Partial Class frmDMDV2
		Inherits Form

		' Token: 0x060010E0 RID: 4320 RVA: 0x000CD1EC File Offset: 0x000CB3EC
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMDV2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMDV2_Load
			AddHandler MyBase.KeyDown, AddressOf Me.frmDMDV2_KeyDown
			frmDMDV2.__ENCList.Add(New WeakReference(Me))
			Me.mstrStore = ""
			Me.mStrNgayNhanViec = ""
			Me.mStrNgayThoiViec = ""
			Me.mstrUIMAGE = ""
			Me.mblnSaveAndSelect = False
			Me.mStrFinger1 = ""
			Me.mStrFinger2 = ""
			Me.mStrFinger3 = ""
			Me.mBlnAutoDel = False
			Me.mBlnModifyMulti = False
			Me.mblnAutoAdd_DMDV = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x170005E8 RID: 1512
		' (get) Token: 0x060010E3 RID: 4323 RVA: 0x000D0860 File Offset: 0x000CEA60
		' (set) Token: 0x060010E4 RID: 4324 RVA: 0x00004958 File Offset: 0x00002B58
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x170005E9 RID: 1513
		' (get) Token: 0x060010E5 RID: 4325 RVA: 0x000D0878 File Offset: 0x000CEA78
		' (set) Token: 0x060010E6 RID: 4326 RVA: 0x000D0890 File Offset: 0x000CEA90
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170005EA RID: 1514
		' (get) Token: 0x060010E7 RID: 4327 RVA: 0x000D08FC File Offset: 0x000CEAFC
		' (set) Token: 0x060010E8 RID: 4328 RVA: 0x00004962 File Offset: 0x00002B62
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x170005EB RID: 1515
		' (get) Token: 0x060010E9 RID: 4329 RVA: 0x000D0914 File Offset: 0x000CEB14
		' (set) Token: 0x060010EA RID: 4330 RVA: 0x000D092C File Offset: 0x000CEB2C
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x170005EC RID: 1516
		' (get) Token: 0x060010EB RID: 4331 RVA: 0x000D0998 File Offset: 0x000CEB98
		' (set) Token: 0x060010EC RID: 4332 RVA: 0x000D09B0 File Offset: 0x000CEBB0
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170005ED RID: 1517
		' (get) Token: 0x060010ED RID: 4333 RVA: 0x000D0A1C File Offset: 0x000CEC1C
		' (set) Token: 0x060010EE RID: 4334 RVA: 0x000D0A34 File Offset: 0x000CEC34
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170005EE RID: 1518
		' (get) Token: 0x060010EF RID: 4335 RVA: 0x000D0AA0 File Offset: 0x000CECA0
		' (set) Token: 0x060010F0 RID: 4336 RVA: 0x0000496C File Offset: 0x00002B6C
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x170005EF RID: 1519
		' (get) Token: 0x060010F1 RID: 4337 RVA: 0x000D0AB8 File Offset: 0x000CECB8
		' (set) Token: 0x060010F2 RID: 4338 RVA: 0x000D0AD0 File Offset: 0x000CECD0
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170005F0 RID: 1520
		' (get) Token: 0x060010F3 RID: 4339 RVA: 0x000D0B6C File Offset: 0x000CED6C
		' (set) Token: 0x060010F4 RID: 4340 RVA: 0x000D0B84 File Offset: 0x000CED84
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170005F1 RID: 1521
		' (get) Token: 0x060010F5 RID: 4341 RVA: 0x000D0C20 File Offset: 0x000CEE20
		' (set) Token: 0x060010F6 RID: 4342 RVA: 0x00004976 File Offset: 0x00002B76
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x170005F2 RID: 1522
		' (get) Token: 0x060010F7 RID: 4343 RVA: 0x000D0C38 File Offset: 0x000CEE38
		' (set) Token: 0x060010F8 RID: 4344 RVA: 0x000D0C50 File Offset: 0x000CEE50
		Friend Overridable Property chkISSUP As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkISSUP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkISSUP IsNot Nothing
				If flag Then
					RemoveHandler Me._chkISSUP.KeyPress, AddressOf Me.chkISSUP_KeyPress
				End If
				Me._chkISSUP = value
				flag = Me._chkISSUP IsNot Nothing
				If flag Then
					AddHandler Me._chkISSUP.KeyPress, AddressOf Me.chkISSUP_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170005F3 RID: 1523
		' (get) Token: 0x060010F9 RID: 4345 RVA: 0x000D0CBC File Offset: 0x000CEEBC
		' (set) Token: 0x060010FA RID: 4346 RVA: 0x00004980 File Offset: 0x00002B80
		Friend Overridable Property lblEMAIL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblEMAIL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblEMAIL = value
			End Set
		End Property

		' Token: 0x170005F4 RID: 1524
		' (get) Token: 0x060010FB RID: 4347 RVA: 0x000D0CD4 File Offset: 0x000CEED4
		' (set) Token: 0x060010FC RID: 4348 RVA: 0x0000498A File Offset: 0x00002B8A
		Friend Overridable Property lblWEBSITE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblWEBSITE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblWEBSITE = value
			End Set
		End Property

		' Token: 0x170005F5 RID: 1525
		' (get) Token: 0x060010FD RID: 4349 RVA: 0x000D0CEC File Offset: 0x000CEEEC
		' (set) Token: 0x060010FE RID: 4350 RVA: 0x000D0D04 File Offset: 0x000CEF04
		Friend Overridable Property cmbStore As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbStore
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbStore IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbStore.KeyPress, AddressOf Me.cmbStore_KeyPress
					RemoveHandler Me._cmbStore.GotFocus, AddressOf Me.cmbStore_GotFocus
				End If
				Me._cmbStore = value
				flag = Me._cmbStore IsNot Nothing
				If flag Then
					AddHandler Me._cmbStore.KeyPress, AddressOf Me.cmbStore_KeyPress
					AddHandler Me._cmbStore.GotFocus, AddressOf Me.cmbStore_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170005F6 RID: 1526
		' (get) Token: 0x060010FF RID: 4351 RVA: 0x000D0DA0 File Offset: 0x000CEFA0
		' (set) Token: 0x06001100 RID: 4352 RVA: 0x00004994 File Offset: 0x00002B94
		Friend Overridable Property lblBRANCH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblBRANCH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblBRANCH = value
			End Set
		End Property

		' Token: 0x170005F7 RID: 1527
		' (get) Token: 0x06001101 RID: 4353 RVA: 0x000D0DB8 File Offset: 0x000CEFB8
		' (set) Token: 0x06001102 RID: 4354 RVA: 0x000D0DD0 File Offset: 0x000CEFD0
		Friend Overridable Property txtADDRESS As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtADDRESS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtADDRESS IsNot Nothing
				If flag Then
					RemoveHandler Me._txtADDRESS.KeyPress, AddressOf Me.txtADDRESS_KeyPress
					RemoveHandler Me._txtADDRESS.GotFocus, AddressOf Me.txtADDRESS_GotFocus
				End If
				Me._txtADDRESS = value
				flag = Me._txtADDRESS IsNot Nothing
				If flag Then
					AddHandler Me._txtADDRESS.KeyPress, AddressOf Me.txtADDRESS_KeyPress
					AddHandler Me._txtADDRESS.GotFocus, AddressOf Me.txtADDRESS_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170005F8 RID: 1528
		' (get) Token: 0x06001103 RID: 4355 RVA: 0x000D0E6C File Offset: 0x000CF06C
		' (set) Token: 0x06001104 RID: 4356 RVA: 0x000D0E84 File Offset: 0x000CF084
		Friend Overridable Property txtTEL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTEL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTEL IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTEL.KeyPress, AddressOf Me.txtTEL_KeyPress
					RemoveHandler Me._txtTEL.GotFocus, AddressOf Me.txtTEL_GotFocus
				End If
				Me._txtTEL = value
				flag = Me._txtTEL IsNot Nothing
				If flag Then
					AddHandler Me._txtTEL.KeyPress, AddressOf Me.txtTEL_KeyPress
					AddHandler Me._txtTEL.GotFocus, AddressOf Me.txtTEL_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170005F9 RID: 1529
		' (get) Token: 0x06001105 RID: 4357 RVA: 0x000D0F20 File Offset: 0x000CF120
		' (set) Token: 0x06001106 RID: 4358 RVA: 0x000D0F38 File Offset: 0x000CF138
		Friend Overridable Property txtMOBILE As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMOBILE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMOBILE IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMOBILE.KeyPress, AddressOf Me.txtMOBILE_KeyPress
					RemoveHandler Me._txtMOBILE.GotFocus, AddressOf Me.txtMOBILE_GotFocus
				End If
				Me._txtMOBILE = value
				flag = Me._txtMOBILE IsNot Nothing
				If flag Then
					AddHandler Me._txtMOBILE.KeyPress, AddressOf Me.txtMOBILE_KeyPress
					AddHandler Me._txtMOBILE.GotFocus, AddressOf Me.txtMOBILE_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170005FA RID: 1530
		' (get) Token: 0x06001107 RID: 4359 RVA: 0x000D0FD4 File Offset: 0x000CF1D4
		' (set) Token: 0x06001108 RID: 4360 RVA: 0x000D0FEC File Offset: 0x000CF1EC
		Friend Overridable Property txtCONTACT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCONTACT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtCONTACT IsNot Nothing
				If flag Then
					RemoveHandler Me._txtCONTACT.KeyPress, AddressOf Me.txtCONTACT_KeyPress
					RemoveHandler Me._txtCONTACT.GotFocus, AddressOf Me.txtCONTACT_GotFocus
				End If
				Me._txtCONTACT = value
				flag = Me._txtCONTACT IsNot Nothing
				If flag Then
					AddHandler Me._txtCONTACT.KeyPress, AddressOf Me.txtCONTACT_KeyPress
					AddHandler Me._txtCONTACT.GotFocus, AddressOf Me.txtCONTACT_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170005FB RID: 1531
		' (get) Token: 0x06001109 RID: 4361 RVA: 0x000D1088 File Offset: 0x000CF288
		' (set) Token: 0x0600110A RID: 4362 RVA: 0x000D10A0 File Offset: 0x000CF2A0
		Friend Overridable Property txtVATCODE As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtVATCODE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtVATCODE IsNot Nothing
				If flag Then
					RemoveHandler Me._txtVATCODE.KeyPress, AddressOf Me.txtVATCODE_KeyPress
					RemoveHandler Me._txtVATCODE.GotFocus, AddressOf Me.txtVATCODE_GotFocus
				End If
				Me._txtVATCODE = value
				flag = Me._txtVATCODE IsNot Nothing
				If flag Then
					AddHandler Me._txtVATCODE.KeyPress, AddressOf Me.txtVATCODE_KeyPress
					AddHandler Me._txtVATCODE.GotFocus, AddressOf Me.txtVATCODE_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170005FC RID: 1532
		' (get) Token: 0x0600110B RID: 4363 RVA: 0x000D113C File Offset: 0x000CF33C
		' (set) Token: 0x0600110C RID: 4364 RVA: 0x000D1154 File Offset: 0x000CF354
		Friend Overridable Property txtFAX As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtFAX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtFAX IsNot Nothing
				If flag Then
					RemoveHandler Me._txtFAX.KeyPress, AddressOf Me.txtFAX_KeyPress
					RemoveHandler Me._txtFAX.GotFocus, AddressOf Me.txtFAX_GotFocus
				End If
				Me._txtFAX = value
				flag = Me._txtFAX IsNot Nothing
				If flag Then
					AddHandler Me._txtFAX.KeyPress, AddressOf Me.txtFAX_KeyPress
					AddHandler Me._txtFAX.GotFocus, AddressOf Me.txtFAX_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170005FD RID: 1533
		' (get) Token: 0x0600110D RID: 4365 RVA: 0x000D11F0 File Offset: 0x000CF3F0
		' (set) Token: 0x0600110E RID: 4366 RVA: 0x000D1208 File Offset: 0x000CF408
		Friend Overridable Property txtEMAIL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtEMAIL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtEMAIL IsNot Nothing
				If flag Then
					RemoveHandler Me._txtEMAIL.KeyPress, AddressOf Me.txtEMAIL_KeyPress
					RemoveHandler Me._txtEMAIL.GotFocus, AddressOf Me.txtEMAIL_GotFocus
				End If
				Me._txtEMAIL = value
				flag = Me._txtEMAIL IsNot Nothing
				If flag Then
					AddHandler Me._txtEMAIL.KeyPress, AddressOf Me.txtEMAIL_KeyPress
					AddHandler Me._txtEMAIL.GotFocus, AddressOf Me.txtEMAIL_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170005FE RID: 1534
		' (get) Token: 0x0600110F RID: 4367 RVA: 0x000D12A4 File Offset: 0x000CF4A4
		' (set) Token: 0x06001110 RID: 4368 RVA: 0x000D12BC File Offset: 0x000CF4BC
		Friend Overridable Property txtWEBSITE As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtWEBSITE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtWEBSITE IsNot Nothing
				If flag Then
					RemoveHandler Me._txtWEBSITE.KeyPress, AddressOf Me.txtWEBSITE_KeyPress
					RemoveHandler Me._txtWEBSITE.GotFocus, AddressOf Me.txtWEBSITE_GotFocus
				End If
				Me._txtWEBSITE = value
				flag = Me._txtWEBSITE IsNot Nothing
				If flag Then
					AddHandler Me._txtWEBSITE.KeyPress, AddressOf Me.txtWEBSITE_KeyPress
					AddHandler Me._txtWEBSITE.GotFocus, AddressOf Me.txtWEBSITE_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170005FF RID: 1535
		' (get) Token: 0x06001111 RID: 4369 RVA: 0x000D1358 File Offset: 0x000CF558
		' (set) Token: 0x06001112 RID: 4370 RVA: 0x000D1370 File Offset: 0x000CF570
		Friend Overridable Property chkISCUS As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkISCUS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkISCUS IsNot Nothing
				If flag Then
					RemoveHandler Me._chkISCUS.KeyPress, AddressOf Me.chkISCUS_KeyPress
				End If
				Me._chkISCUS = value
				flag = Me._chkISCUS IsNot Nothing
				If flag Then
					AddHandler Me._chkISCUS.KeyPress, AddressOf Me.chkISCUS_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000600 RID: 1536
		' (get) Token: 0x06001113 RID: 4371 RVA: 0x000D13DC File Offset: 0x000CF5DC
		' (set) Token: 0x06001114 RID: 4372 RVA: 0x000D13F4 File Offset: 0x000CF5F4
		Friend Overridable Property chkISFOR As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkISFOR
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkISFOR IsNot Nothing
				If flag Then
					RemoveHandler Me._chkISFOR.KeyPress, AddressOf Me.chkISFOR_KeyPress
				End If
				Me._chkISFOR = value
				flag = Me._chkISFOR IsNot Nothing
				If flag Then
					AddHandler Me._chkISFOR.KeyPress, AddressOf Me.chkISFOR_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000601 RID: 1537
		' (get) Token: 0x06001115 RID: 4373 RVA: 0x000D1460 File Offset: 0x000CF660
		' (set) Token: 0x06001116 RID: 4374 RVA: 0x000D1478 File Offset: 0x000CF678
		Friend Overridable Property chkISORG As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkISORG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkISORG IsNot Nothing
				If flag Then
					RemoveHandler Me._chkISORG.KeyPress, AddressOf Me.chkISORG_KeyPress
				End If
				Me._chkISORG = value
				flag = Me._chkISORG IsNot Nothing
				If flag Then
					AddHandler Me._chkISORG.KeyPress, AddressOf Me.chkISORG_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000602 RID: 1538
		' (get) Token: 0x06001117 RID: 4375 RVA: 0x000D14E4 File Offset: 0x000CF6E4
		' (set) Token: 0x06001118 RID: 4376 RVA: 0x0000499E File Offset: 0x00002B9E
		Friend Overridable Property lblADDRESS As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblADDRESS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblADDRESS = value
			End Set
		End Property

		' Token: 0x17000603 RID: 1539
		' (get) Token: 0x06001119 RID: 4377 RVA: 0x000D14FC File Offset: 0x000CF6FC
		' (set) Token: 0x0600111A RID: 4378 RVA: 0x000049A8 File Offset: 0x00002BA8
		Friend Overridable Property lblTEL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTEL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTEL = value
			End Set
		End Property

		' Token: 0x17000604 RID: 1540
		' (get) Token: 0x0600111B RID: 4379 RVA: 0x000D1514 File Offset: 0x000CF714
		' (set) Token: 0x0600111C RID: 4380 RVA: 0x000049B2 File Offset: 0x00002BB2
		Friend Overridable Property lblMOBILE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMOBILE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMOBILE = value
			End Set
		End Property

		' Token: 0x17000605 RID: 1541
		' (get) Token: 0x0600111D RID: 4381 RVA: 0x000D152C File Offset: 0x000CF72C
		' (set) Token: 0x0600111E RID: 4382 RVA: 0x000049BC File Offset: 0x00002BBC
		Friend Overridable Property lblCONTACT As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCONTACT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCONTACT = value
			End Set
		End Property

		' Token: 0x17000606 RID: 1542
		' (get) Token: 0x0600111F RID: 4383 RVA: 0x000D1544 File Offset: 0x000CF744
		' (set) Token: 0x06001120 RID: 4384 RVA: 0x000049C6 File Offset: 0x00002BC6
		Friend Overridable Property lblVATCODE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblVATCODE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblVATCODE = value
			End Set
		End Property

		' Token: 0x17000607 RID: 1543
		' (get) Token: 0x06001121 RID: 4385 RVA: 0x000D155C File Offset: 0x000CF75C
		' (set) Token: 0x06001122 RID: 4386 RVA: 0x000049D0 File Offset: 0x00002BD0
		Friend Overridable Property lblFAX As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFAX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFAX = value
			End Set
		End Property

		' Token: 0x17000608 RID: 1544
		' (get) Token: 0x06001123 RID: 4387 RVA: 0x000D1574 File Offset: 0x000CF774
		' (set) Token: 0x06001124 RID: 4388 RVA: 0x000049DA File Offset: 0x00002BDA
		Friend Overridable Property lblISSUP As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblISSUP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblISSUP = value
			End Set
		End Property

		' Token: 0x17000609 RID: 1545
		' (get) Token: 0x06001125 RID: 4389 RVA: 0x000D158C File Offset: 0x000CF78C
		' (set) Token: 0x06001126 RID: 4390 RVA: 0x000049E4 File Offset: 0x00002BE4
		Friend Overridable Property lblISCUS As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblISCUS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblISCUS = value
			End Set
		End Property

		' Token: 0x1700060A RID: 1546
		' (get) Token: 0x06001127 RID: 4391 RVA: 0x000D15A4 File Offset: 0x000CF7A4
		' (set) Token: 0x06001128 RID: 4392 RVA: 0x000049EE File Offset: 0x00002BEE
		Friend Overridable Property lblISFOR As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblISFOR
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblISFOR = value
			End Set
		End Property

		' Token: 0x1700060B RID: 1547
		' (get) Token: 0x06001129 RID: 4393 RVA: 0x000D15BC File Offset: 0x000CF7BC
		' (set) Token: 0x0600112A RID: 4394 RVA: 0x000049F8 File Offset: 0x00002BF8
		Friend Overridable Property lblISORG As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblISORG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblISORG = value
			End Set
		End Property

		' Token: 0x1700060C RID: 1548
		' (get) Token: 0x0600112B RID: 4395 RVA: 0x000D15D4 File Offset: 0x000CF7D4
		' (set) Token: 0x0600112C RID: 4396 RVA: 0x00004A02 File Offset: 0x00002C02
		Friend Overridable Property txtColor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtColor = value
			End Set
		End Property

		' Token: 0x1700060D RID: 1549
		' (get) Token: 0x0600112D RID: 4397 RVA: 0x000D15EC File Offset: 0x000CF7EC
		' (set) Token: 0x0600112E RID: 4398 RVA: 0x000D1604 File Offset: 0x000CF804
		Friend Overridable Property BtnSELECTMANHOMDV As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._BtnSELECTMANHOMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._BtnSELECTMANHOMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._BtnSELECTMANHOMDV.Click, AddressOf Me.BtnSELECTMANHOMDV_Click
				End If
				Me._BtnSELECTMANHOMDV = value
				flag = Me._BtnSELECTMANHOMDV IsNot Nothing
				If flag Then
					AddHandler Me._BtnSELECTMANHOMDV.Click, AddressOf Me.BtnSELECTMANHOMDV_Click
				End If
			End Set
		End Property

		' Token: 0x1700060E RID: 1550
		' (get) Token: 0x0600112F RID: 4399 RVA: 0x000D1670 File Offset: 0x000CF870
		' (set) Token: 0x06001130 RID: 4400 RVA: 0x00004A0C File Offset: 0x00002C0C
		Friend Overridable Property TxtTENNHOMDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._TxtTENNHOMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TxtTENNHOMDV = value
			End Set
		End Property

		' Token: 0x1700060F RID: 1551
		' (get) Token: 0x06001131 RID: 4401 RVA: 0x000D1688 File Offset: 0x000CF888
		' (set) Token: 0x06001132 RID: 4402 RVA: 0x000D16A0 File Offset: 0x000CF8A0
		Friend Overridable Property TxtMANHOMDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._TxtMANHOMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._TxtMANHOMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._TxtMANHOMDV.KeyPress, AddressOf Me.TxtMANHOMDV_KeyPress
					RemoveHandler Me._TxtMANHOMDV.TextChanged, AddressOf Me.TxtMANHOMDV_TextChanged
				End If
				Me._TxtMANHOMDV = value
				flag = Me._TxtMANHOMDV IsNot Nothing
				If flag Then
					AddHandler Me._TxtMANHOMDV.KeyPress, AddressOf Me.TxtMANHOMDV_KeyPress
					AddHandler Me._TxtMANHOMDV.TextChanged, AddressOf Me.TxtMANHOMDV_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000610 RID: 1552
		' (get) Token: 0x06001133 RID: 4403 RVA: 0x000D173C File Offset: 0x000CF93C
		' (set) Token: 0x06001134 RID: 4404 RVA: 0x00004A16 File Offset: 0x00002C16
		Friend Overridable Property LblMANHOMDV As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._LblMANHOMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._LblMANHOMDV = value
			End Set
		End Property

		' Token: 0x17000611 RID: 1553
		' (get) Token: 0x06001135 RID: 4405 RVA: 0x000D1754 File Offset: 0x000CF954
		' (set) Token: 0x06001136 RID: 4406 RVA: 0x00004A20 File Offset: 0x00002C20
		Friend Overridable Property LblBIRTHDAY As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._LblBIRTHDAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._LblBIRTHDAY = value
			End Set
		End Property

		' Token: 0x17000612 RID: 1554
		' (get) Token: 0x06001137 RID: 4407 RVA: 0x000D176C File Offset: 0x000CF96C
		' (set) Token: 0x06001138 RID: 4408 RVA: 0x000D1784 File Offset: 0x000CF984
		Friend Overridable Property mtxBIRTHDAY As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxBIRTHDAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxBIRTHDAY IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxBIRTHDAY.TextChanged, AddressOf Me.mtxBIRTHDAY_TextChanged
					RemoveHandler Me._mtxBIRTHDAY.KeyPress, AddressOf Me.mtxBIRTHDAY_KeyPress
				End If
				Me._mtxBIRTHDAY = value
				flag = Me._mtxBIRTHDAY IsNot Nothing
				If flag Then
					AddHandler Me._mtxBIRTHDAY.TextChanged, AddressOf Me.mtxBIRTHDAY_TextChanged
					AddHandler Me._mtxBIRTHDAY.KeyPress, AddressOf Me.mtxBIRTHDAY_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000613 RID: 1555
		' (get) Token: 0x06001139 RID: 4409 RVA: 0x000D1820 File Offset: 0x000CFA20
		' (set) Token: 0x0600113A RID: 4410 RVA: 0x00004A2A File Offset: 0x00002C2A
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000614 RID: 1556
		' (get) Token: 0x0600113B RID: 4411 RVA: 0x000D1838 File Offset: 0x000CFA38
		' (set) Token: 0x0600113C RID: 4412 RVA: 0x00004A34 File Offset: 0x00002C34
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000615 RID: 1557
		' (get) Token: 0x0600113D RID: 4413 RVA: 0x000D1850 File Offset: 0x000CFA50
		' (set) Token: 0x0600113E RID: 4414 RVA: 0x00004A3E File Offset: 0x00002C3E
		Friend Overridable Property txtTUOI As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTUOI
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTUOI = value
			End Set
		End Property

		' Token: 0x17000616 RID: 1558
		' (get) Token: 0x0600113F RID: 4415 RVA: 0x000D1868 File Offset: 0x000CFA68
		' (set) Token: 0x06001140 RID: 4416 RVA: 0x00004A48 File Offset: 0x00002C48
		Friend Overridable Property cmbGIOTINH As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbGIOTINH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Me._cmbGIOTINH = value
			End Set
		End Property

		' Token: 0x17000617 RID: 1559
		' (get) Token: 0x06001141 RID: 4417 RVA: 0x000D1880 File Offset: 0x000CFA80
		' (set) Token: 0x06001142 RID: 4418 RVA: 0x00004A52 File Offset: 0x00002C52
		Friend Overridable Property lblNAMGIOI As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblNAMGIOI
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblNAMGIOI = value
			End Set
		End Property

		' Token: 0x17000618 RID: 1560
		' (get) Token: 0x06001143 RID: 4419 RVA: 0x000D1898 File Offset: 0x000CFA98
		' (set) Token: 0x06001144 RID: 4420 RVA: 0x00004A5C File Offset: 0x00002C5C
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000619 RID: 1561
		' (get) Token: 0x06001145 RID: 4421 RVA: 0x000D18B0 File Offset: 0x000CFAB0
		' (set) Token: 0x06001146 RID: 4422 RVA: 0x00004A66 File Offset: 0x00002C66
		Friend Overridable Property txtJOB As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtJOB
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtJOB = value
			End Set
		End Property

		' Token: 0x1700061A RID: 1562
		' (get) Token: 0x06001147 RID: 4423 RVA: 0x000D18C8 File Offset: 0x000CFAC8
		' (set) Token: 0x06001148 RID: 4424 RVA: 0x000D18E0 File Offset: 0x000CFAE0
		Friend Overridable Property txtRemark As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtRemark
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtRemark IsNot Nothing
				If flag Then
					RemoveHandler Me._txtRemark.KeyPress, AddressOf Me.txtREMARK_KeyPress
				End If
				Me._txtRemark = value
				flag = Me._txtRemark IsNot Nothing
				If flag Then
					AddHandler Me._txtRemark.KeyPress, AddressOf Me.txtREMARK_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700061B RID: 1563
		' (get) Token: 0x06001149 RID: 4425 RVA: 0x000D194C File Offset: 0x000CFB4C
		' (set) Token: 0x0600114A RID: 4426 RVA: 0x00004A70 File Offset: 0x00002C70
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x1700061C RID: 1564
		' (get) Token: 0x0600114B RID: 4427 RVA: 0x000D1964 File Offset: 0x000CFB64
		' (set) Token: 0x0600114C RID: 4428 RVA: 0x00004A7A File Offset: 0x00002C7A
		Friend Overridable Property Panel1 As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._Panel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._Panel1 = value
			End Set
		End Property

		' Token: 0x1700061D RID: 1565
		' (get) Token: 0x0600114D RID: 4429 RVA: 0x000D197C File Offset: 0x000CFB7C
		' (set) Token: 0x0600114E RID: 4430 RVA: 0x000D1994 File Offset: 0x000CFB94
		Friend Overridable Property picAnh As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picAnh
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Dim flag As Boolean = Me._picAnh IsNot Nothing
				If flag Then
					RemoveHandler Me._picAnh.MouseLeave, AddressOf Me.picAnh_MouseLeave
					RemoveHandler Me._picAnh.MouseHover, AddressOf Me.picAnh_MouseHover
					RemoveHandler Me._picAnh.Click, AddressOf Me.picAnh_Click
				End If
				Me._picAnh = value
				flag = Me._picAnh IsNot Nothing
				If flag Then
					AddHandler Me._picAnh.MouseLeave, AddressOf Me.picAnh_MouseLeave
					AddHandler Me._picAnh.MouseHover, AddressOf Me.picAnh_MouseHover
					AddHandler Me._picAnh.Click, AddressOf Me.picAnh_Click
				End If
			End Set
		End Property

		' Token: 0x1700061E RID: 1566
		' (get) Token: 0x0600114F RID: 4431 RVA: 0x000D1A64 File Offset: 0x000CFC64
		' (set) Token: 0x06001150 RID: 4432 RVA: 0x00004A84 File Offset: 0x00002C84
		Friend Overridable Property picZoom As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picZoom
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._picZoom = value
			End Set
		End Property

		' Token: 0x1700061F RID: 1567
		' (get) Token: 0x06001151 RID: 4433 RVA: 0x000D1A7C File Offset: 0x000CFC7C
		' (set) Token: 0x06001152 RID: 4434 RVA: 0x00004A8E File Offset: 0x00002C8E
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x17000620 RID: 1568
		' (get) Token: 0x06001153 RID: 4435 RVA: 0x000D1A94 File Offset: 0x000CFC94
		' (set) Token: 0x06001154 RID: 4436 RVA: 0x00004A98 File Offset: 0x00002C98
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x17000621 RID: 1569
		' (get) Token: 0x06001155 RID: 4437 RVA: 0x000D1AAC File Offset: 0x000CFCAC
		' (set) Token: 0x06001156 RID: 4438 RVA: 0x000D1AC4 File Offset: 0x000CFCC4
		Friend Overridable Property txtCHUCVU As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCHUCVU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtCHUCVU IsNot Nothing
				If flag Then
					RemoveHandler Me._txtCHUCVU.KeyPress, AddressOf Me.txtCHUCVU_KeyPress
				End If
				Me._txtCHUCVU = value
				flag = Me._txtCHUCVU IsNot Nothing
				If flag Then
					AddHandler Me._txtCHUCVU.KeyPress, AddressOf Me.txtCHUCVU_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000622 RID: 1570
		' (get) Token: 0x06001157 RID: 4439 RVA: 0x000D1B30 File Offset: 0x000CFD30
		' (set) Token: 0x06001158 RID: 4440 RVA: 0x000D1B48 File Offset: 0x000CFD48
		Friend Overridable Property txtCAP As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCAP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtCAP IsNot Nothing
				If flag Then
					RemoveHandler Me._txtCAP.KeyPress, AddressOf Me.txtCAP_KeyPress
				End If
				Me._txtCAP = value
				flag = Me._txtCAP IsNot Nothing
				If flag Then
					AddHandler Me._txtCAP.KeyPress, AddressOf Me.txtCAP_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000623 RID: 1571
		' (get) Token: 0x06001159 RID: 4441 RVA: 0x000D1BB4 File Offset: 0x000CFDB4
		' (set) Token: 0x0600115A RID: 4442 RVA: 0x000D1BCC File Offset: 0x000CFDCC
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x17000624 RID: 1572
		' (get) Token: 0x0600115B RID: 4443 RVA: 0x000D1C38 File Offset: 0x000CFE38
		' (set) Token: 0x0600115C RID: 4444 RVA: 0x000D1C50 File Offset: 0x000CFE50
		Friend Overridable Property btnSaveAndSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSaveAndSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSaveAndSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSaveAndSelect.Click, AddressOf Me.btnSaveAndSelect_Click
				End If
				Me._btnSaveAndSelect = value
				flag = Me._btnSaveAndSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSaveAndSelect.Click, AddressOf Me.btnSaveAndSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000625 RID: 1573
		' (get) Token: 0x0600115D RID: 4445 RVA: 0x000D1CBC File Offset: 0x000CFEBC
		' (set) Token: 0x0600115E RID: 4446 RVA: 0x00004AA2 File Offset: 0x00002CA2
		Friend Overridable Property Label6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label6 = value
			End Set
		End Property

		' Token: 0x17000626 RID: 1574
		' (get) Token: 0x0600115F RID: 4447 RVA: 0x000D1CD4 File Offset: 0x000CFED4
		' (set) Token: 0x06001160 RID: 4448 RVA: 0x000D1CEC File Offset: 0x000CFEEC
		Friend Overridable Property txtMucGiamGia As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMucGiamGia
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMucGiamGia IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMucGiamGia.KeyPress, AddressOf Me.txtREMARK_KeyPress
				End If
				Me._txtMucGiamGia = value
				flag = Me._txtMucGiamGia IsNot Nothing
				If flag Then
					AddHandler Me._txtMucGiamGia.KeyPress, AddressOf Me.txtREMARK_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000627 RID: 1575
		' (get) Token: 0x06001161 RID: 4449 RVA: 0x000D1D58 File Offset: 0x000CFF58
		' (set) Token: 0x06001162 RID: 4450 RVA: 0x000D1D70 File Offset: 0x000CFF70
		Friend Overridable Property btnMucGiamGia As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnMucGiamGia
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnMucGiamGia IsNot Nothing
				If flag Then
					RemoveHandler Me._btnMucGiamGia.Click, AddressOf Me.btnMucGiamGia_Click
				End If
				Me._btnMucGiamGia = value
				flag = Me._btnMucGiamGia IsNot Nothing
				If flag Then
					AddHandler Me._btnMucGiamGia.Click, AddressOf Me.btnMucGiamGia_Click
				End If
			End Set
		End Property

		' Token: 0x17000628 RID: 1576
		' (get) Token: 0x06001163 RID: 4451 RVA: 0x000D1DDC File Offset: 0x000CFFDC
		' (set) Token: 0x06001164 RID: 4452 RVA: 0x000D1DF4 File Offset: 0x000CFFF4
		Friend Overridable Property btnFinger As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFinger
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFinger IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFinger.Click, AddressOf Me.btnFinger_Click
				End If
				Me._btnFinger = value
				flag = Me._btnFinger IsNot Nothing
				If flag Then
					AddHandler Me._btnFinger.Click, AddressOf Me.btnFinger_Click
				End If
			End Set
		End Property

		' Token: 0x17000629 RID: 1577
		' (get) Token: 0x06001165 RID: 4453 RVA: 0x000D1E60 File Offset: 0x000D0060
		' (set) Token: 0x06001166 RID: 4454 RVA: 0x000D1E78 File Offset: 0x000D0078
		Friend Overridable Property txtCardCode As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCardCode
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtCardCode IsNot Nothing
				If flag Then
					RemoveHandler Me._txtCardCode.KeyPress, AddressOf Me.txtCardCode_KeyPress
					RemoveHandler Me._txtCardCode.KeyPress, AddressOf Me.txtOBJID_KeyPress
				End If
				Me._txtCardCode = value
				flag = Me._txtCardCode IsNot Nothing
				If flag Then
					AddHandler Me._txtCardCode.KeyPress, AddressOf Me.txtCardCode_KeyPress
					AddHandler Me._txtCardCode.KeyPress, AddressOf Me.txtOBJID_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700062A RID: 1578
		' (get) Token: 0x06001167 RID: 4455 RVA: 0x000D1F14 File Offset: 0x000D0114
		' (set) Token: 0x06001168 RID: 4456 RVA: 0x00004AAC File Offset: 0x00002CAC
		Friend Overridable Property Label7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		' Token: 0x1700062B RID: 1579
		' (get) Token: 0x06001169 RID: 4457 RVA: 0x000D1F2C File Offset: 0x000D012C
		' (set) Token: 0x0600116A RID: 4458 RVA: 0x00004AB6 File Offset: 0x00002CB6
		Friend Overridable Property mtxNgayThoiViec As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxNgayThoiViec
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxNgayThoiViec = value
			End Set
		End Property

		' Token: 0x1700062C RID: 1580
		' (get) Token: 0x0600116B RID: 4459 RVA: 0x000D1F44 File Offset: 0x000D0144
		' (set) Token: 0x0600116C RID: 4460 RVA: 0x00004AC0 File Offset: 0x00002CC0
		Friend Overridable Property Label8 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label8 = value
			End Set
		End Property

		' Token: 0x1700062D RID: 1581
		' (get) Token: 0x0600116D RID: 4461 RVA: 0x000D1F5C File Offset: 0x000D015C
		' (set) Token: 0x0600116E RID: 4462 RVA: 0x00004ACA File Offset: 0x00002CCA
		Friend Overridable Property mtxNgayNhanViec As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxNgayNhanViec
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxNgayNhanViec = value
			End Set
		End Property

		' Token: 0x1700062E RID: 1582
		' (get) Token: 0x0600116F RID: 4463 RVA: 0x000D1F74 File Offset: 0x000D0174
		' (set) Token: 0x06001170 RID: 4464 RVA: 0x00004AD4 File Offset: 0x00002CD4
		Friend Overridable Property Label9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label9 = value
			End Set
		End Property

		' Token: 0x1700062F RID: 1583
		' (get) Token: 0x06001171 RID: 4465 RVA: 0x000D1F8C File Offset: 0x000D018C
		' (set) Token: 0x06001172 RID: 4466 RVA: 0x00004ADE File Offset: 0x00002CDE
		Friend Overridable Property Label10 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label10 = value
			End Set
		End Property

		' Token: 0x17000630 RID: 1584
		' (get) Token: 0x06001173 RID: 4467 RVA: 0x000D1FA4 File Offset: 0x000D01A4
		' (set) Token: 0x06001174 RID: 4468 RVA: 0x00004AE8 File Offset: 0x00002CE8
		Friend Overridable Property txtTenUser As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTenUser
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTenUser = value
			End Set
		End Property

		' Token: 0x17000631 RID: 1585
		' (get) Token: 0x06001175 RID: 4469 RVA: 0x000D1FBC File Offset: 0x000D01BC
		' (set) Token: 0x06001176 RID: 4470 RVA: 0x000D1FD4 File Offset: 0x000D01D4
		Friend Overridable Property txtMaUser As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMaUser
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMaUser IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMaUser.TextChanged, AddressOf Me.txtMaUser_TextChanged
				End If
				Me._txtMaUser = value
				flag = Me._txtMaUser IsNot Nothing
				If flag Then
					AddHandler Me._txtMaUser.TextChanged, AddressOf Me.txtMaUser_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000632 RID: 1586
		' (get) Token: 0x06001177 RID: 4471 RVA: 0x000D2040 File Offset: 0x000D0240
		' (set) Token: 0x06001178 RID: 4472 RVA: 0x000D2058 File Offset: 0x000D0258
		Friend Overridable Property btnMaUser As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnMaUser
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnMaUser IsNot Nothing
				If flag Then
					RemoveHandler Me._btnMaUser.Click, AddressOf Me.btnMaUser_Click
				End If
				Me._btnMaUser = value
				flag = Me._btnMaUser IsNot Nothing
				If flag Then
					AddHandler Me._btnMaUser.Click, AddressOf Me.btnMaUser_Click
				End If
			End Set
		End Property

		' Token: 0x17000633 RID: 1587
		' (get) Token: 0x06001179 RID: 4473 RVA: 0x000D20C4 File Offset: 0x000D02C4
		' (set) Token: 0x0600117A RID: 4474 RVA: 0x00004AF2 File Offset: 0x00002CF2
		Public Property pBlnModifyMulti As Boolean
			Get
				Return Me.mBlnModifyMulti
			End Get
			Set(value As Boolean)
				Me.mBlnModifyMulti = value
			End Set
		End Property

		' Token: 0x17000634 RID: 1588
		' (get) Token: 0x0600117B RID: 4475 RVA: 0x000D20DC File Offset: 0x000D02DC
		' (set) Token: 0x0600117C RID: 4476 RVA: 0x00004AFD File Offset: 0x00002CFD
		Public Property pBlnAutoDel As Boolean
			Get
				Return Me.mBlnAutoDel
			End Get
			Set(value As Boolean)
				Me.mBlnAutoDel = value
			End Set
		End Property

		' Token: 0x17000635 RID: 1589
		' (get) Token: 0x0600117D RID: 4477 RVA: 0x000D20F4 File Offset: 0x000D02F4
		' (set) Token: 0x0600117E RID: 4478 RVA: 0x00004B08 File Offset: 0x00002D08
		Public Property pStrNgayNhanViec As String
			Get
				Return Me.mStrNgayNhanViec
			End Get
			Set(value As String)
				Me.mStrNgayNhanViec = value
			End Set
		End Property

		' Token: 0x17000636 RID: 1590
		' (get) Token: 0x0600117F RID: 4479 RVA: 0x000D210C File Offset: 0x000D030C
		' (set) Token: 0x06001180 RID: 4480 RVA: 0x00004B13 File Offset: 0x00002D13
		Public Property pStrNgayThoiViec As String
			Get
				Return Me.mStrNgayThoiViec
			End Get
			Set(value As String)
				Me.mStrNgayThoiViec = value
			End Set
		End Property

		' Token: 0x17000637 RID: 1591
		' (get) Token: 0x06001181 RID: 4481 RVA: 0x000D2124 File Offset: 0x000D0324
		' (set) Token: 0x06001182 RID: 4482 RVA: 0x00004B1E File Offset: 0x00002D1E
		Public Property pstrUIMAGE As String
			Get
				Return Me.mstrUIMAGE
			End Get
			Set(value As String)
				Me.mstrUIMAGE = value
			End Set
		End Property

		' Token: 0x17000638 RID: 1592
		' (get) Token: 0x06001183 RID: 4483 RVA: 0x000D213C File Offset: 0x000D033C
		' (set) Token: 0x06001184 RID: 4484 RVA: 0x00004B29 File Offset: 0x00002D29
		Public Property pblnSaveAndSelect As Boolean
			Get
				Return Me.mblnSaveAndSelect
			End Get
			Set(value As Boolean)
				Me.mblnSaveAndSelect = value
			End Set
		End Property

		' Token: 0x17000639 RID: 1593
		' (get) Token: 0x06001185 RID: 4485 RVA: 0x000D2154 File Offset: 0x000D0354
		' (set) Token: 0x06001186 RID: 4486 RVA: 0x00004B34 File Offset: 0x00002D34
		Public Property pStrFinger1 As String
			Get
				Return Me.mStrFinger1
			End Get
			Set(value As String)
				Me.mStrFinger1 = value
			End Set
		End Property

		' Token: 0x1700063A RID: 1594
		' (get) Token: 0x06001187 RID: 4487 RVA: 0x000D216C File Offset: 0x000D036C
		' (set) Token: 0x06001188 RID: 4488 RVA: 0x00004B3F File Offset: 0x00002D3F
		Public Property pStrFinger2 As String
			Get
				Return Me.mStrFinger2
			End Get
			Set(value As String)
				Me.mStrFinger2 = value
			End Set
		End Property

		' Token: 0x1700063B RID: 1595
		' (get) Token: 0x06001189 RID: 4489 RVA: 0x000D2184 File Offset: 0x000D0384
		' (set) Token: 0x0600118A RID: 4490 RVA: 0x00004B4A File Offset: 0x00002D4A
		Public Property pStrFinger3 As String
			Get
				Return Me.mStrFinger3
			End Get
			Set(value As String)
				Me.mStrFinger3 = value
			End Set
		End Property

		' Token: 0x1700063C RID: 1596
		' (get) Token: 0x0600118B RID: 4491 RVA: 0x000D219C File Offset: 0x000D039C
		' (set) Token: 0x0600118C RID: 4492 RVA: 0x00004B55 File Offset: 0x00002D55
		Public Property pBytGIOITINH As Byte
			Get
				Return Me.mbytGIOITINH
			End Get
			Set(value As Byte)
				Me.mbytGIOITINH = value
			End Set
		End Property

		' Token: 0x1700063D RID: 1597
		' (get) Token: 0x0600118D RID: 4493 RVA: 0x000D21B4 File Offset: 0x000D03B4
		' (set) Token: 0x0600118E RID: 4494 RVA: 0x00004B60 File Offset: 0x00002D60
		Public Property pStrBIRTHDAY As String
			Get
				Return Me.mStrBIRTHDAY
			End Get
			Set(value As String)
				Me.mStrBIRTHDAY = value
			End Set
		End Property

		' Token: 0x1700063E RID: 1598
		' (get) Token: 0x0600118F RID: 4495 RVA: 0x000D21CC File Offset: 0x000D03CC
		' (set) Token: 0x06001190 RID: 4496 RVA: 0x00004B6B File Offset: 0x00002D6B
		Public Property pStrStore As String
			Get
				Return Me.mstrStore
			End Get
			Set(value As String)
				Me.mstrStore = value
			End Set
		End Property

		' Token: 0x1700063F RID: 1599
		' (get) Token: 0x06001191 RID: 4497 RVA: 0x000D21E4 File Offset: 0x000D03E4
		' (set) Token: 0x06001192 RID: 4498 RVA: 0x00004B76 File Offset: 0x00002D76
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000640 RID: 1600
		' (get) Token: 0x06001193 RID: 4499 RVA: 0x000D21FC File Offset: 0x000D03FC
		' (set) Token: 0x06001194 RID: 4500 RVA: 0x00004B81 File Offset: 0x00002D81
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000641 RID: 1601
		' (get) Token: 0x06001195 RID: 4501 RVA: 0x000D2214 File Offset: 0x000D0414
		' (set) Token: 0x06001196 RID: 4502 RVA: 0x00004B8C File Offset: 0x00002D8C
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06001197 RID: 4503 RVA: 0x000D222C File Offset: 0x000D042C
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001198 RID: 4504 RVA: 0x000D22D8 File Offset: 0x000D04D8
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001199 RID: 4505 RVA: 0x000D2380 File Offset: 0x000D0580
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.cmbStore.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600119A RID: 4506 RVA: 0x000D242C File Offset: 0x000D062C
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.TxtMANHOMDV.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600119B RID: 4507 RVA: 0x000D24D0 File Offset: 0x000D06D0
		Private Sub cmbStore_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbytFormStatus = 4
				If flag Then
					Me.txtADDRESS.Focus()
				Else
					Me.cmbStore.DroppedDown = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbStore_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600119C RID: 4508 RVA: 0x000D258C File Offset: 0x000D078C
		Private Sub cmbStore_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxBIRTHDAY.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbStore_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600119D RID: 4509 RVA: 0x000D2630 File Offset: 0x000D0830
		Private Sub txtADDRESS_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtADDRESS.[ReadOnly]
				If [readOnly] Then
					Me.txtTEL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtADDRESS_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600119E RID: 4510 RVA: 0x000D26DC File Offset: 0x000D08DC
		Private Sub txtADDRESS_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtCAP.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtADDRESS_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600119F RID: 4511 RVA: 0x000D2780 File Offset: 0x000D0980
		Private Sub txtTEL_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTEL.[ReadOnly]
				If [readOnly] Then
					Me.txtMOBILE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTEL_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011A0 RID: 4512 RVA: 0x000D282C File Offset: 0x000D0A2C
		Private Sub txtTEL_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMOBILE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTEL_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011A1 RID: 4513 RVA: 0x000D28D0 File Offset: 0x000D0AD0
		Private Sub txtMOBILE_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMOBILE.[ReadOnly]
				If [readOnly] Then
					Me.txtCONTACT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMOBILE_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011A2 RID: 4514 RVA: 0x000D297C File Offset: 0x000D0B7C
		Private Sub txtMOBILE_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtCONTACT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMOBILE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011A3 RID: 4515 RVA: 0x000D2A20 File Offset: 0x000D0C20
		Private Sub txtCONTACT_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtCONTACT.[ReadOnly]
				If [readOnly] Then
					Me.txtVATCODE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCONTACT_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011A4 RID: 4516 RVA: 0x000D2ACC File Offset: 0x000D0CCC
		Private Sub txtCONTACT_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtVATCODE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCONTACT_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011A5 RID: 4517 RVA: 0x000D2B70 File Offset: 0x000D0D70
		Private Sub txtVATCODE_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtVATCODE.[ReadOnly]
				If [readOnly] Then
					Me.txtFAX.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtVATCODE_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011A6 RID: 4518 RVA: 0x000D2C1C File Offset: 0x000D0E1C
		Private Sub txtVATCODE_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtFAX.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtVATCODE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011A7 RID: 4519 RVA: 0x000D2CC0 File Offset: 0x000D0EC0
		Private Sub txtFAX_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtFAX.[ReadOnly]
				If [readOnly] Then
					Me.txtEMAIL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtFAX_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011A8 RID: 4520 RVA: 0x000D2D6C File Offset: 0x000D0F6C
		Private Sub txtFAX_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtEMAIL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtFAX_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011A9 RID: 4521 RVA: 0x000D2E10 File Offset: 0x000D1010
		Private Sub txtEMAIL_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtEMAIL.[ReadOnly]
				If [readOnly] Then
					Me.txtWEBSITE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtEMAIL_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011AA RID: 4522 RVA: 0x000D2EBC File Offset: 0x000D10BC
		Private Sub txtEMAIL_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtWEBSITE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtEMAIL_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011AB RID: 4523 RVA: 0x000D2F60 File Offset: 0x000D1160
		Private Sub txtWEBSITE_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtWEBSITE.[ReadOnly]
				If [readOnly] Then
					Me.chkISSUP.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011AC RID: 4524 RVA: 0x000D300C File Offset: 0x000D120C
		Private Sub txtWEBSITE_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtRemark.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011AD RID: 4525 RVA: 0x000D30B0 File Offset: 0x000D12B0
		Private Sub txtREMARK_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkISSUP.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011AE RID: 4526 RVA: 0x000D3154 File Offset: 0x000D1354
		Private Sub chkISSUP_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkISCUS.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkISSUP_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011AF RID: 4527 RVA: 0x000D31F8 File Offset: 0x000D13F8
		Private Sub chkISCUS_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkISFOR.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkISCUS_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011B0 RID: 4528 RVA: 0x000D329C File Offset: 0x000D149C
		Private Sub chkISFOR_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkISORG.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkISFOR_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011B1 RID: 4529 RVA: 0x000D3340 File Offset: 0x000D1540
		Private Sub chkISORG_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkISORG_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011B2 RID: 4530 RVA: 0x000D33E4 File Offset: 0x000D15E4
		Private Function fGetData_DMNHOMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMNHOMDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNHOMDV")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMNHOMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060011B3 RID: 4531 RVA: 0x000D3490 File Offset: 0x000D1690
		Private Function fGetData_DMUSER() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMUser = New clsConnect(mdlVariable.gStrConISDANHMUC, "UUSER")
				Dim flag As Boolean = Me.mclsTbDMUser IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMUSER ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060011B4 RID: 4532 RVA: 0x000D354C File Offset: 0x000D174C
		Private Function fGetData_4Combo_GIOITINH() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim dataTable As DataTable = New DataTable()
				dataTable.Columns.Add("GIATRI")
				dataTable.Columns.Add("TEN")
				dataTable.Rows.Add(New Object() { 0, Me.mArrStrFrmMess(54) })
				dataTable.Rows.Add(New Object() { 1, Me.mArrStrFrmMess(55) })
				Dim cmbGIOTINH As ComboBox = Me.cmbGIOTINH
				cmbGIOTINH.DataSource = dataTable
				cmbGIOTINH.DisplayMember = "TEN"
				cmbGIOTINH.ValueMember = "GIATRI"
				Dim flag As Boolean = Not Me.mBlnModifyMulti
				If flag Then
					cmbGIOTINH.SelectedIndex = CInt(Me.mbytGIOITINH)
				Else
					cmbGIOTINH.SelectedIndex = -1
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo_GIOITINH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060011B5 RID: 4533 RVA: 0x000D36D8 File Offset: 0x000D18D8
		Private Sub frmDMDV2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
				Me.TxtMANHOMDV_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtMaUser_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDV2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011B6 RID: 4534 RVA: 0x000D37A0 File Offset: 0x000D19A0
		Private Sub frmDMDV2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Combo()
				End If
				flag = b <> 0
				Dim flag2 As Boolean
				If flag Then
					b = Me.fGetData_DMNHOMDV()
					flag = Me.mbytFormStatus = 1
					If flag Then
						flag2 = Me.mclsTbDMNHOMDV.Rows.Count > 0
						If flag2 Then
							Me.TxtMANHOMDV.Text = Me.mclsTbDMNHOMDV.Rows(0)("OBJID").ToString()
						End If
					End If
				End If
				flag2 = b <> 0
				If flag2 Then
					b = Me.fGetData_DMUSER()
				End If
				flag2 = b <> 0
				If flag2 Then
					b = Me.fGetData_4Combo_GIOITINH()
				End If
				flag2 = Me.mbytFormStatus = 3
				If flag2 Then
					flag = mdlUIForm.gfChek_RightSale("00081", False) = 0
					If flag Then
						Me.TxtMANHOMDV.Enabled = False
						Me.BtnSELECTMANHOMDV.Enabled = False
					End If
				End If
				Me.sGetPara_From_SetparaXML()
				flag2 = Me.mBlnAutoDel
				If flag2 Then
					Me.btnDelete_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDV2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011B7 RID: 4535 RVA: 0x000D3968 File Offset: 0x000D1B68
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mBlnModifyMulti
				If Not flag Then
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
						Return
					End If
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
						Return
					End If
					flag = Operators.CompareString(Strings.Trim(Me.TxtMANHOMDV.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
						Me.TxtMANHOMDV.Focus()
						Return
					End If
					flag = (Operators.CompareString(Strings.Trim(Me.TxtMANHOMDV.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.TxtTENNHOMDV.Text), "", False) = 0)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
						Me.TxtMANHOMDV.Focus()
						Return
					End If
					flag = (Operators.CompareString(Strings.Trim(Me.mtxBIRTHDAY.Text.Replace("/", "")), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTUOI.Text), "", False) = 0)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(57), MsgBoxStyle.Critical, Nothing)
						Me.mtxBIRTHDAY.Focus()
						Return
					End If
					flag = Not(Me.chkISCUS.Checked Or Me.chkISFOR.Checked Or Me.chkISORG.Checked Or Me.chkISSUP.Checked)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(44), MsgBoxStyle.Critical, Nothing)
						Me.chkISSUP.Focus()
						Return
					End If
					flag = Not Versioned.IsNumeric(Me.txtMucGiamGia.Text.Trim().Replace(",", ""))
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(64), MsgBoxStyle.Critical, Nothing)
						Me.txtMucGiamGia.Focus()
						Return
					End If
				End If
				flag = Me.txtMucGiamGia.Text.Trim().Length > 0 AndAlso Not Versioned.IsNumeric(Me.txtMucGiamGia.Text.Trim().Replace(",", ""))
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(64), MsgBoxStyle.Critical, Nothing)
					Me.txtMucGiamGia.Focus()
				Else
					flag = (Operators.CompareString(Strings.Trim(Me.txtMaUser.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTenUser.Text), "", False) = 0)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(71), MsgBoxStyle.Critical, Nothing)
						Me.txtMaUser.Focus()
					Else
						flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
						Dim flag2 As Boolean
						If flag Then
							Me.mbytSuccess = Me.gfAddNew(0)
						Else
							flag = Me.mbytFormStatus = 3
							If flag Then
								flag2 = Me.mBlnModifyMulti
								If flag2 Then
									Me.mbytSuccess = Me.fModifyMulti()
								Else
									Me.mbytSuccess = Me.fModify(0)
								End If
							End If
						End If
						flag2 = Me.mbytSuccess = 1
						If flag2 Then
							Me.mblnSaveAndSelect = False
							Me.Close()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011B8 RID: 4536 RVA: 0x000D3DD0 File Offset: 0x000D1FD0
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011B9 RID: 4537 RVA: 0x000D3E74 File Offset: 0x000D2074
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = "*" + Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (OBJNAME like '"), text2), "%')"))
				End If
				Dim text3 As String = Strings.Mid(Me.mtxBIRTHDAY.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxBIRTHDAY.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 1, 2) })
					flag = Not Information.IsDate(text2)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
						Me.mtxBIRTHDAY.Focus()
						Return
					End If
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " BIRTHDAY ='"), Strings.Replace(Strings.Trim(Me.mtxBIRTHDAY.Text), text3, "/", 1, -1, CompareMethod.Binary)), "'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.TxtMANHOMDV.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MANHOMDV like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Trim(Conversions.ToString(Me.cmbStore.SelectedValue))
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtADDRESS.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (ADDRESS like '"), text2), "%')"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtTEL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TEL like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtMOBILE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MOBILE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtCONTACT.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " CONTACT like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtVATCODE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " VATCODE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtFAX.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FAX like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtEMAIL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " EMAIL like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtWEBSITE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " WEBSITE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtRemark.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (REMARK like '"), text2), "%')"))
				End If
				flag = Me.chkISSUP.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISSUP ="), Interaction.IIf(Me.chkISSUP.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISCUS.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISCUS ="), Interaction.IIf(Me.chkISCUS.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISFOR.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISFOR ="), Interaction.IIf(Me.chkISFOR.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISORG.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISORG ="), Interaction.IIf(Me.chkISORG.Checked, 1, 0)), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011BA RID: 4538 RVA: 0x000D4B18 File Offset: 0x000D2D18
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = "*" + Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (OBJNAME like '"), text2), "%')"))
				End If
				Dim text3 As String = Strings.Mid(Me.mtxBIRTHDAY.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxBIRTHDAY.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 1, 2) })
					flag = Not Information.IsDate(text2)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
						Me.mtxBIRTHDAY.Focus()
						Return
					End If
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " BIRTHDAY ='"), Strings.Replace(Strings.Trim(Me.mtxBIRTHDAY.Text), text3, "/", 1, -1, CompareMethod.Binary)), "'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.TxtMANHOMDV.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MANHOMDV like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Trim(Conversions.ToString(Me.cmbStore.SelectedValue))
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtADDRESS.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (ADDRESS like '"), text2), "%')"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtTEL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TEL like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtMOBILE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MOBILE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtCONTACT.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " CONTACT like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtVATCODE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " VATCODE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtFAX.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FAX like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtEMAIL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " EMAIL like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtWEBSITE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " WEBSITE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtRemark.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (REMARK like '"), text2), "%')"))
				End If
				flag = Me.chkISSUP.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISSUP ="), Interaction.IIf(Me.chkISSUP.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISCUS.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISCUS ="), Interaction.IIf(Me.chkISCUS.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISFOR.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISFOR ="), Interaction.IIf(Me.chkISFOR.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISORG.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISORG ="), Interaction.IIf(Me.chkISORG.Checked, 1, 0)), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011BB RID: 4539 RVA: 0x000D57BC File Offset: 0x000D39BC
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtADDRESS.[ReadOnly] = True
						Me.txtTEL.[ReadOnly] = True
						Me.txtMOBILE.[ReadOnly] = True
						Me.txtCONTACT.[ReadOnly] = True
						Me.txtVATCODE.[ReadOnly] = True
						Me.txtFAX.[ReadOnly] = True
						Me.txtEMAIL.[ReadOnly] = True
						Me.txtWEBSITE.[ReadOnly] = True
						Me.mtxBIRTHDAY.[ReadOnly] = True
						Me.TxtMANHOMDV.[ReadOnly] = True
						Me.txtTUOI.[ReadOnly] = True
						Me.txtJOB.[ReadOnly] = True
						Me.txtRemark.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.BackColor = Me.txtColor.BackColor
						Me.txtADDRESS.BackColor = Me.txtColor.BackColor
						Me.txtTEL.BackColor = Me.txtColor.BackColor
						Me.txtMOBILE.BackColor = Me.txtColor.BackColor
						Me.txtCONTACT.BackColor = Me.txtColor.BackColor
						Me.txtVATCODE.BackColor = Me.txtColor.BackColor
						Me.txtFAX.BackColor = Me.txtColor.BackColor
						Me.txtEMAIL.BackColor = Me.txtColor.BackColor
						Me.txtWEBSITE.BackColor = Me.txtColor.BackColor
						Me.cmbStore.BackColor = Me.txtColor.BackColor
						Me.mtxBIRTHDAY.BackColor = Me.txtColor.BackColor
						Me.TxtMANHOMDV.BackColor = Me.txtColor.BackColor
						Me.TxtTENNHOMDV.BackColor = Me.txtColor.BackColor
						Me.txtTUOI.BackColor = Me.txtColor.BackColor
						Me.txtJOB.BackColor = Me.txtColor.BackColor
						Me.txtRemark.BackColor = Me.txtColor.BackColor
						Me.cmbGIOTINH.Enabled = False
						Me.chkISSUP.Enabled = False
						Me.chkISCUS.Enabled = False
						Me.chkISFOR.Enabled = False
						Me.chkISORG.Enabled = False
					Case 5, 6
						Me.cmbStore.SelectedIndex = Me.cmbStore.Items.Count - 1
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060011BC RID: 4540 RVA: 0x000D5B74 File Offset: 0x000D3D74
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060011BD RID: 4541 RVA: 0x000D5D04 File Offset: 0x000D3F04
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 20
				Me.txtOBJNAME.MaxLength = 100
				Me.txtADDRESS.MaxLength = 200
				Me.txtVATCODE.MaxLength = 20
				Me.txtTEL.MaxLength = 100
				Me.txtMOBILE.MaxLength = 100
				Me.txtFAX.MaxLength = 100
				Me.txtEMAIL.MaxLength = 200
				Me.txtWEBSITE.MaxLength = 200
				Me.txtCONTACT.MaxLength = 100
				Me.cmbStore.DropDownStyle = ComboBoxStyle.DropDownList
				Me.TxtTENNHOMDV.[ReadOnly] = True
				Me.TxtTENNHOMDV.BackColor = Me.txtColor.BackColor
				Dim flag As Boolean
				If Me.mbytFormStatus <> 5 AndAlso Me.mbytFormStatus <> 6 Then
					If Not Me.mBlnModifyMulti Then
						flag = False
						GoTo IL_00FF
					End If
				End If
				flag = True
				IL_00FF:
				Dim flag2 As Boolean = flag
				If flag2 Then
					Me.chkISSUP.CheckState = CheckState.Indeterminate
					Me.chkISCUS.CheckState = CheckState.Indeterminate
					Me.chkISFOR.CheckState = CheckState.Indeterminate
					Me.chkISORG.CheckState = CheckState.Indeterminate
					Me.chkISSUP.ThreeState = True
					Me.chkISCUS.ThreeState = True
					Me.chkISFOR.ThreeState = True
					Me.chkISORG.ThreeState = True
				Else
					flag2 = Me.mbytFormStatus = 4
					If flag2 Then
						Me.cmbStore.DropDownStyle = ComboBoxStyle.DropDown
					End If
				End If
				Me.mtxBIRTHDAY.Mask = "00/00/0000"
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060011BE RID: 4542 RVA: 0x000D5F54 File Offset: 0x000D4154
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
					Me.lblBRANCH.Tag = "CB0031"
					Me.LblBIRTHDAY.Tag = "CR0012"
					Me.LblMANHOMDV.Tag = "CB0009"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060011BF RID: 4543 RVA: 0x000D616C File Offset: 0x000D436C
		Private Sub sClear_Form()
			Try
				Me.mclsTbStore.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011C0 RID: 4544 RVA: 0x000D6218 File Offset: 0x000D4418
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMDV")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mblnAutoAdd_DMDV = xmlNode.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011C1 RID: 4545 RVA: 0x000D6314 File Offset: 0x000D4514
		Public Function gfAddNew(Optional pbytNomessage As Byte = 0) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(34) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pvchBIRTHDAY"
				array(2).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxBIRTHDAY.Text).Length <= 4, "", Strings.Trim(Me.mtxBIRTHDAY.Text)))
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchMANHOMDV"
				array(3).Value = Strings.Trim(Me.TxtMANHOMDV.Text)
				Dim flag As Boolean = pbytNomessage = 1
				If flag Then
					array(4) = sqlCommand.CreateParameter()
					array(4).ParameterName = "@pnchMAKH"
					array(4).Value = Me.mstrStore
				Else
					array(4) = sqlCommand.CreateParameter()
					array(4).ParameterName = "@pnchMAKH"
					array(4).Value = RuntimeHelpers.GetObjectValue(Me.cmbStore.SelectedValue)
				End If
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcDC"
				array(5).Value = Strings.Trim(Me.txtADDRESS.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcVAT"
				array(6).Value = Strings.Trim(Me.txtVATCODE.Text)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnvcTEL"
				array(7).Value = Strings.Trim(Me.txtTEL.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnvcMOBI"
				array(8).Value = Strings.Trim(Me.txtMOBILE.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pnvcFAX"
				array(9).Value = Strings.Trim(Me.txtFAX.Text)
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pnvcEmail"
				array(10).Value = Strings.Trim(Me.txtEMAIL.Text)
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pnvcWeb"
				array(11).Value = Strings.Trim(Me.txtWEBSITE.Text)
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pnvcLH"
				array(12).Value = Strings.Trim(Me.txtCONTACT.Text)
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pbitSUP"
				array(13).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISSUP.Checked, 1, 0))
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitCUS"
				array(14).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISCUS.Checked, 1, 0))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pbitFOR"
				array(15).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISFOR.Checked, 1, 0))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pbitORG"
				array(16).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISORG.Checked, 1, 0))
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnvcTUOI"
				array(17).Value = Me.txtTUOI.Text.Trim()
				flag = pbytNomessage = 1
				If flag Then
					array(18) = sqlCommand.CreateParameter()
					array(18).ParameterName = "@ptniGIOITINH"
					array(18).Value = Me.pBytGIOITINH
				Else
					array(18) = sqlCommand.CreateParameter()
					array(18).ParameterName = "@ptniGIOITINH"
					array(18).Value = RuntimeHelpers.GetObjectValue(Me.cmbGIOTINH.SelectedValue)
				End If
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pnvcJOB"
				array(19).Value = Me.txtJOB.Text.Trim()
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = Me.txtRemark.Text.Trim()
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMAUSERUP"
				array(22).Value = mdlVariable.gStrUser
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnvcUIMAGE"
				array(23).Value = Me.mstrUIMAGE
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnvcCAP"
				array(24).Value = Me.txtCAP.Text.Trim()
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnvcCHUCVU"
				array(25).Value = Me.txtCHUCVU.Text.Trim()
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pmnyMUCGIAMGIA"
				array(26).Value = Conversion.Val(Me.txtMucGiamGia.Text.Trim().Replace(",", ""))
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pnvcFINGER1"
				array(27).Value = Me.mStrFinger1
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pnvcFINGER2"
				array(28).Value = Me.mStrFinger2
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pnvcFINGER3"
				array(29).Value = Me.mStrFinger3
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnchCARDCODE"
				array(30).Value = Me.txtCardCode.Text.Trim()
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@pnvcNGAYNHANVIEC"
				array(31).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxNgayNhanViec.Text).Length <= 4, DBNull.Value, Strings.Trim(Me.mtxNgayNhanViec.Text)))
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pnvcNGAYTHOIVIEC"
				array(32).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxNgayThoiViec.Text).Length <= 4, DBNull.Value, Strings.Trim(Me.mtxNgayThoiViec.Text)))
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pnchMAUSERLK"
				array(33).Value = Strings.Trim(Me.txtMaUser.Text)
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@int_Result"
				array(20).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_INSERT_DMDV", flag2)
				Dim num As Integer = Conversions.ToInteger(array(20).Value)
				flag = pbytNomessage = 1
				If flag Then
					Dim flag3 As Boolean = num = 1
					If flag3 Then
						Me.fModify(1)
					End If
				Else
					Dim flag3 As Boolean = num = 0
					If flag3 Then
						Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
						b = 1
					Else
						flag3 = num = 1
						If flag3 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
							Me.txtOBJID.Focus()
						Else
							flag3 = num = 2
							If flag3 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(67), MsgBoxStyle.Critical, Nothing)
								Me.txtVATCODE.Focus()
							Else
								flag3 = num = 3
								If flag3 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(70), MsgBoxStyle.Critical, Nothing)
									Me.txtCardCode.Focus()
								Else
									Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
									Me.txtOBJID.Focus()
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060011C2 RID: 4546 RVA: 0x000D6D48 File Offset: 0x000D4F48
		Private Function fModify(Optional pbytNomessage As Byte = 0) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(34) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				Dim flag As Boolean = pbytNomessage = 1
				If flag Then
					array(2) = sqlCommand.CreateParameter()
					array(2).ParameterName = "@pnchMAKH"
					array(2).Value = Me.mstrStore
				Else
					array(2) = sqlCommand.CreateParameter()
					array(2).ParameterName = "@pnchMAKH"
					array(2).Value = RuntimeHelpers.GetObjectValue(Me.cmbStore.SelectedValue)
				End If
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcDC"
				array(3).Value = Strings.Trim(Me.txtADDRESS.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvcVAT"
				array(4).Value = Strings.Trim(Me.txtVATCODE.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcTEL"
				array(5).Value = Strings.Trim(Me.txtTEL.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcMOBI"
				array(6).Value = Strings.Trim(Me.txtMOBILE.Text)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnvcFAX"
				array(7).Value = Strings.Trim(Me.txtFAX.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnvcEmail"
				array(8).Value = Strings.Trim(Me.txtEMAIL.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pnvcWeb"
				array(9).Value = Strings.Trim(Me.txtWEBSITE.Text)
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pnvcLH"
				array(10).Value = Strings.Trim(Me.txtCONTACT.Text)
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pbitSUP"
				array(11).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISSUP.Checked, 1, 0))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pbitCUS"
				array(12).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISCUS.Checked, 1, 0))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pbitFOR"
				array(13).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISFOR.Checked, 1, 0))
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitORG"
				array(14).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISORG.Checked, 1, 0))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pvchBIRTHDAY"
				array(15).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxBIRTHDAY.Text).Length <= 4, "", Strings.Trim(Me.mtxBIRTHDAY.Text)))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pnchMANHOMDV"
				array(16).Value = Me.TxtMANHOMDV.Text.Trim()
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnvcTUOI"
				array(17).Value = Me.txtTUOI.Text.Trim()
				flag = pbytNomessage = 1
				If flag Then
					array(18) = sqlCommand.CreateParameter()
					array(18).ParameterName = "@ptniGIOITINH"
					array(18).Value = Me.pBytGIOITINH
				Else
					array(18) = sqlCommand.CreateParameter()
					array(18).ParameterName = "@ptniGIOITINH"
					array(18).Value = RuntimeHelpers.GetObjectValue(Me.cmbGIOTINH.SelectedValue)
				End If
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pnvcJOB"
				array(19).Value = Me.txtJOB.Text.Trim()
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = Me.txtRemark.Text.Trim()
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMAUSERUP"
				array(22).Value = mdlVariable.gStrUser
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnvcUIMAGE"
				array(23).Value = Me.mstrUIMAGE
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnvcCAP"
				array(24).Value = Me.txtCAP.Text.Trim()
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnvcCHUCVU"
				array(25).Value = Me.txtCHUCVU.Text.Trim()
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pmnyMUCGIAMGIA"
				array(26).Value = Conversion.Val(Me.txtMucGiamGia.Text.Trim().Replace(",", ""))
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pnvcFINGER1"
				array(27).Value = Me.mStrFinger1
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pnvcFINGER2"
				array(28).Value = Me.mStrFinger2
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pnvcFINGER3"
				array(29).Value = Me.mStrFinger3
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnchCARDCODE"
				array(30).Value = Me.txtCardCode.Text.Trim()
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@pnvcNGAYNHANVIEC"
				array(31).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxNgayNhanViec.Text).Length <= 4, DBNull.Value, Strings.Trim(Me.mtxNgayNhanViec.Text)))
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pnvcNGAYTHOIVIEC"
				array(32).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxNgayThoiViec.Text).Length <= 4, DBNull.Value, Strings.Trim(Me.mtxNgayThoiViec.Text)))
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pnchMAUSERLK"
				array(33).Value = Strings.Trim(Me.txtMaUser.Text)
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@int_Result"
				array(20).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_UPDATE_DMDV", flag2)
				Dim num As Integer = Conversions.ToInteger(array(20).Value)
				flag = num = 0
				If flag Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag = num = 1
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						flag = num = 2
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(67), MsgBoxStyle.Critical, Nothing)
							Me.txtVATCODE.Focus()
						Else
							flag = num = 3
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(70), MsgBoxStyle.Critical, Nothing)
								Me.txtCardCode.Focus()
							Else
								Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060011C3 RID: 4547 RVA: 0x000D774C File Offset: 0x000D594C
		Private Function fModifyMulti() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(33) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = RuntimeHelpers.GetObjectValue(Me.cmbStore.SelectedValue)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcDC"
				array(3).Value = Strings.Trim(Me.txtADDRESS.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvcVAT"
				array(4).Value = Strings.Trim(Me.txtVATCODE.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcTEL"
				array(5).Value = Strings.Trim(Me.txtTEL.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcMOBI"
				array(6).Value = Strings.Trim(Me.txtMOBILE.Text)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnvcFAX"
				array(7).Value = Strings.Trim(Me.txtFAX.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnvcEmail"
				array(8).Value = Strings.Trim(Me.txtEMAIL.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pnvcWeb"
				array(9).Value = Strings.Trim(Me.txtWEBSITE.Text)
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pnvcLH"
				array(10).Value = Strings.Trim(Me.txtCONTACT.Text)
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pbitSUP"
				array(11).DbType = DbType.[Boolean]
				array(11).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISSUP.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkISSUP.Checked))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pbitCUS"
				array(12).DbType = DbType.[Boolean]
				array(12).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISCUS.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkISCUS.Checked))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pbitFOR"
				array(13).DbType = DbType.[Boolean]
				array(13).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISFOR.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkISFOR.Checked))
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitORG"
				array(14).DbType = DbType.[Boolean]
				array(14).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISORG.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkISORG.Checked))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pvchBIRTHDAY"
				array(15).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxBIRTHDAY.Text).Length <= 4, "", Strings.Trim(Me.mtxBIRTHDAY.Text)))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pnchMANHOMDV"
				array(16).Value = Me.TxtMANHOMDV.Text.Trim()
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnvcTUOI"
				array(17).Value = Me.txtTUOI.Text.Trim()
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@ptniGIOITINH"
				array(18).DbType = DbType.Int16
				Dim flag As Boolean = Me.cmbGIOTINH.SelectedIndex >= 0
				If flag Then
					array(18).Value = RuntimeHelpers.GetObjectValue(Me.cmbGIOTINH.SelectedValue)
				Else
					array(18).Value = DBNull.Value
				End If
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pnvcJOB"
				array(19).Value = Me.txtJOB.Text.Trim()
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = Me.txtRemark.Text.Trim()
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMAUSERUP"
				array(22).Value = mdlVariable.gStrUser
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnvcUIMAGE"
				array(23).Value = Me.mstrUIMAGE
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnvcCAP"
				array(24).Value = Me.txtCAP.Text.Trim()
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnvcCHUCVU"
				array(25).Value = Me.txtCHUCVU.Text.Trim()
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pmnyMUCGIAMGIA"
				array(26).DbType = DbType.[Double]
				array(26).DbType = DbType.Currency
				array(26).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtMucGiamGia.Text = Nothing) Or (Operators.CompareString(Me.txtMucGiamGia.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtMucGiamGia.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pnvcFINGER1"
				array(27).Value = Me.mStrFinger1
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pnvcFINGER2"
				array(28).Value = Me.mStrFinger2
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pnvcFINGER3"
				array(29).Value = Me.mStrFinger3
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnchCARDCODE"
				array(30).Value = Me.txtCardCode.Text.Trim()
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@pnvcNGAYNHANVIEC"
				array(31).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxNgayNhanViec.Text).Length <= 4, DBNull.Value, Strings.Trim(Me.mtxNgayNhanViec.Text)))
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pnvcNGAYTHOIVIEC"
				array(32).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxNgayThoiViec.Text).Length <= 4, DBNull.Value, Strings.Trim(Me.mtxNgayThoiViec.Text)))
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@int_Result"
				array(20).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_UPDATE_MULTI_DMDV", flag2)
				Dim num As Integer = Conversions.ToInteger(array(20).Value)
				flag = num = 0
				If flag Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag = num = 1
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						flag = num = 2
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(67), MsgBoxStyle.Critical, Nothing)
							Me.txtVATCODE.Focus()
						Else
							flag = num = 3
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(70), MsgBoxStyle.Critical, Nothing)
								Me.txtCardCode.Focus()
							Else
								Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060011C4 RID: 4548 RVA: 0x000D8188 File Offset: 0x000D6388
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_DEL_DMDV", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Dim flag3 As Boolean = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(30), Me.btnDelete.Text, frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.Yes
							If flag3 Then
								b = Me.fDelete_Now()
							End If
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060011C5 RID: 4549 RVA: 0x000D8370 File Offset: 0x000D6570
		Private Function fDelete_Now() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_DEL_DMDV_NOW", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060011C6 RID: 4550 RVA: 0x000D84F8 File Offset: 0x000D66F8
		Private Function fGetData_4Combo() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbStore = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = (Me.mbytFormStatus = 5) Or (Me.mbytFormStatus = 6)
				If flag Then
					Me.mclsTbStore.Rows.Add(New Object() { "", Me.mArrStrFrmMess(11) })
				End If
				flag = Me.mclsTbStore IsNot Nothing
				If flag Then
					Dim cmbStore As ComboBox = Me.cmbStore
					cmbStore.DataSource = Me.mclsTbStore
					cmbStore.DisplayMember = "OBJNAME"
					cmbStore.ValueMember = "OBJID"
					cmbStore.SelectedIndex = 0
					b = 1
				End If
				flag = Operators.CompareString(Me.mstrStore, "", False) <> 0
				If flag Then
					Me.cmbStore.SelectedValue = Me.mstrStore
				End If
				flag = Operators.CompareString(Me.mStrBIRTHDAY, "", False) <> 0
				If flag Then
					Me.mtxBIRTHDAY.Text = Me.mStrBIRTHDAY
				End If
				Me.mtxNgayNhanViec.Text = Me.mStrNgayNhanViec.Trim()
				Me.mtxNgayThoiViec.Text = Me.mStrNgayThoiViec.Trim()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060011C7 RID: 4551 RVA: 0x000D86E4 File Offset: 0x000D68E4
		Private Sub BtnSELECTMANHOMDV_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMNHOMDV As frmDMNHOMDV1 = New frmDMNHOMDV1()
				frmDMNHOMDV.pBytOpen_From_Menu = 7
				frmDMNHOMDV.ShowDialog()
				Me.TxtMANHOMDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNHOMDV.pStrOBJID, "", False) = 0, Me.TxtMANHOMDV.Text, frmDMNHOMDV.pStrOBJID))
				Me.TxtTENNHOMDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNHOMDV.pStrOBJNAME, "", False) = 0, Me.TxtTENNHOMDV.Text, frmDMNHOMDV.pStrOBJNAME))
				frmDMNHOMDV.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - BtnSELECTMANHOMDV_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011C8 RID: 4552 RVA: 0x000D8808 File Offset: 0x000D6A08
		Private Sub TxtMANHOMDV_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbStore.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - TxtMANHOMDV_KeyPress( ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011C9 RID: 4553 RVA: 0x000D88AC File Offset: 0x000D6AAC
		Private Sub TxtMANHOMDV_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMNHOMDV Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMNHOMDV.Columns("OBJID")
					Me.mclsTbDMNHOMDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMNHOMDV.Rows.Find(Strings.Trim(Me.TxtMANHOMDV.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.TxtTENNHOMDV.Text = dataRow("OBJNAME").ToString()
					Else
						Me.TxtTENNHOMDV.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - TxtMANHOMDV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011CA RID: 4554 RVA: 0x000D8A00 File Offset: 0x000D6C00
		Private Sub mtxBIRTHDAY_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtADDRESS.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxBIRTHDAY_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011CB RID: 4555 RVA: 0x000D8AA4 File Offset: 0x000D6CA4
		Private Sub mtxBIRTHDAY_TextChanged(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.mtxBIRTHDAY.Text.Trim().Length <> 10
			If flag Then
				Me.txtTUOI.Text = ""
			Else
				Dim text As String = String.Concat(New String() { Strings.Mid(Me.mtxBIRTHDAY.Text, 7, 4), "/", Strings.Mid(Me.mtxBIRTHDAY.Text, 4, 2), "/", Strings.Mid(Me.mtxBIRTHDAY.Text, 1, 2) })
				flag = Information.IsDate(text)
				If flag Then
					Me.txtTUOI.Text = Conversions.ToString(Math.Round((DateAndTime.Now.[Date] - Convert.ToDateTime(text)).TotalDays / 365.0))
				End If
			End If
		End Sub

		' Token: 0x060011CC RID: 4556 RVA: 0x000D8B9C File Offset: 0x000D6D9C
		Private Sub picAnh_Click(sender As Object, e As EventArgs)
			Try
				Dim frmselectimage As frmselectimage = New frmselectimage()
				frmselectimage.ShowDialog()
				Dim flag As Boolean = (frmselectimage.pstrPath.Length > 2) And (Operators.CompareString(frmselectimage.pstrPath, "none", False) <> 0)
				If flag Then
					Me.picAnh.BackgroundImage = frmselectimage.pimgImage
					Me.mstrUIMAGE = frmselectimage.pstrPath
				End If
				flag = Operators.CompareString(frmselectimage.pstrPath, "none", False) = 0
				If flag Then
					Me.picAnh.BackgroundImage = frmselectimage.pimgImage
					Me.mstrUIMAGE = ""
				End If
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060011CD RID: 4557 RVA: 0x000D8C5C File Offset: 0x000D6E5C
		Private Sub picAnh_MouseHover(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.mstrUIMAGE Is Nothing OrElse Me.mstrUIMAGE.Length <= 1
			If Not flag Then
				Me.picZoom.BackgroundImage = Me.picAnh.BackgroundImage
				Me.picZoom.Visible = True
			End If
		End Sub

		' Token: 0x060011CE RID: 4558 RVA: 0x00004B97 File Offset: 0x00002D97
		Private Sub picAnh_MouseLeave(sender As Object, e As EventArgs)
			Me.picZoom.Visible = False
		End Sub

		' Token: 0x060011CF RID: 4559 RVA: 0x000D8CB4 File Offset: 0x000D6EB4
		Private Sub txtCAP_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtCHUCVU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCAP_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011D0 RID: 4560 RVA: 0x000D8D58 File Offset: 0x000D6F58
		Private Sub txtCHUCVU_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtTEL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCHUCVU_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060011D1 RID: 4561 RVA: 0x000D8DFC File Offset: 0x000D6FFC
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x060011D2 RID: 4562 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x060011D3 RID: 4563 RVA: 0x000D8E78 File Offset: 0x000D7078
		Private Sub btnSaveAndSelect_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Not Me.mblnAutoAdd_DMDV AndAlso Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = Operators.CompareString(Strings.Trim(Me.TxtMANHOMDV.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
							Me.TxtMANHOMDV.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.TxtMANHOMDV.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.TxtTENNHOMDV.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
								Me.TxtMANHOMDV.Focus()
							Else
								flag = (Operators.CompareString(Strings.Trim(Me.mtxBIRTHDAY.Text.Replace("/", "")), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTUOI.Text), "", False) = 0)
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(57), MsgBoxStyle.Critical, Nothing)
									Me.mtxBIRTHDAY.Focus()
								Else
									flag = Not(Me.chkISCUS.Checked Or Me.chkISFOR.Checked Or Me.chkISORG.Checked Or Me.chkISSUP.Checked)
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(44), MsgBoxStyle.Critical, Nothing)
										Me.chkISSUP.Focus()
									Else
										flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
										If flag Then
											Me.mbytSuccess = Me.gfAddNew(0)
										Else
											flag = Me.mbytFormStatus = 3
											If flag Then
												Me.mbytSuccess = Me.fModify(0)
											End If
										End If
										flag = Me.mbytSuccess = 1
										If flag Then
											Me.mblnSaveAndSelect = True
											Me.Close()
										Else
											Me.mblnSaveAndSelect = False
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSaveAndSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011D4 RID: 4564 RVA: 0x000D91A8 File Offset: 0x000D73A8
		Private Sub frmDMDV2_KeyDown(sender As Object, e As KeyEventArgs)
			Dim flag As Boolean = e.KeyCode = Keys.F4
			If flag Then
				Me.btnSaveAndSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
			End If
		End Sub

		' Token: 0x060011D5 RID: 4565 RVA: 0x000D91D4 File Offset: 0x000D73D4
		Private Sub btnMucGiamGia_Click(sender As Object, e As EventArgs)
			Dim frmNumPad As frmNumPad = New frmNumPad()
			frmNumPad.ShowDialog()
			Dim flag As Boolean = frmNumPad.pbytSuccess = 1
			If flag Then
				Me.txtMucGiamGia.Text = Conversions.ToString(frmNumPad.pSglNumberReturn)
			End If
			frmNumPad.Dispose()
		End Sub

		' Token: 0x060011D6 RID: 4566 RVA: 0x000D921C File Offset: 0x000D741C
		Private Sub btnFinger_Click(sender As Object, e As EventArgs)
			Try
				Dim frmFingerCus As frmFingerCus = New frmFingerCus()
				frmFingerCus.pStrMaDV = Me.txtOBJID.Text.Trim()
				frmFingerCus.pStrFinger1 = Me.mStrFinger1
				frmFingerCus.pStrFinger2 = Me.mStrFinger2
				frmFingerCus.pStrFinger3 = Me.mStrFinger3
				frmFingerCus.ShowDialog()
				Dim flag As Boolean = frmFingerCus.pbytsuccess = 1F
				If flag Then
					Me.mStrFinger1 = frmFingerCus.pStrFinger1
					Me.mStrFinger2 = frmFingerCus.pStrFinger2
					Me.mStrFinger3 = frmFingerCus.pStrFinger3
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFinger ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011D7 RID: 4567 RVA: 0x000D9330 File Offset: 0x000D7530
		Private Sub txtCardCode_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13 AndAlso mdlVariable.gblnLRemoveXChar
				If flag Then
					Me.txtCardCode.Text = Me.txtCardCode.Text.Trim().Replace("?", "").Replace(";", "")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCardCode_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011D8 RID: 4568 RVA: 0x000D941C File Offset: 0x000D761C
		Private Sub txtMaUser_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMUser Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMUser.Columns("OBJID")
					Me.mclsTbDMUser.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMUser.Rows.Find(Strings.Trim(Me.txtMaUser.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTenUser.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTenUser.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTenUser_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060011D9 RID: 4569 RVA: 0x000D9570 File Offset: 0x000D7770
		Private Sub btnMaUser_Click(sender As Object, e As EventArgs)
			Try
				Dim frmUSER As frmUSER1 = New frmUSER1()
				frmUSER.pBytOpen_From_Menu = 7
				frmUSER.ShowDialog()
				Me.txtMaUser.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmUSER.pStrOBJID, "", False) = 0, Me.txtMaUser.Text, frmUSER.pStrOBJID))
				Me.txtTenUser.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmUSER.pStrOBJNAME, "", False) = 0, Me.txtTenUser.Text, frmUSER.pStrOBJNAME))
				frmUSER.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnMaUser_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0400071C RID: 1820
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400071E RID: 1822
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x0400071F RID: 1823
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000720 RID: 1824
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000721 RID: 1825
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000722 RID: 1826
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000723 RID: 1827
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000724 RID: 1828
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000725 RID: 1829
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000726 RID: 1830
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000727 RID: 1831
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000728 RID: 1832
		<AccessedThroughProperty("chkISSUP")>
		Private _chkISSUP As CheckBox

		' Token: 0x04000729 RID: 1833
		<AccessedThroughProperty("lblEMAIL")>
		Private _lblEMAIL As Label

		' Token: 0x0400072A RID: 1834
		<AccessedThroughProperty("lblWEBSITE")>
		Private _lblWEBSITE As Label

		' Token: 0x0400072B RID: 1835
		<AccessedThroughProperty("cmbStore")>
		Private _cmbStore As ComboBox

		' Token: 0x0400072C RID: 1836
		<AccessedThroughProperty("lblBRANCH")>
		Private _lblBRANCH As Label

		' Token: 0x0400072D RID: 1837
		<AccessedThroughProperty("txtADDRESS")>
		Private _txtADDRESS As TextBox

		' Token: 0x0400072E RID: 1838
		<AccessedThroughProperty("txtTEL")>
		Private _txtTEL As TextBox

		' Token: 0x0400072F RID: 1839
		<AccessedThroughProperty("txtMOBILE")>
		Private _txtMOBILE As TextBox

		' Token: 0x04000730 RID: 1840
		<AccessedThroughProperty("txtCONTACT")>
		Private _txtCONTACT As TextBox

		' Token: 0x04000731 RID: 1841
		<AccessedThroughProperty("txtVATCODE")>
		Private _txtVATCODE As TextBox

		' Token: 0x04000732 RID: 1842
		<AccessedThroughProperty("txtFAX")>
		Private _txtFAX As TextBox

		' Token: 0x04000733 RID: 1843
		<AccessedThroughProperty("txtEMAIL")>
		Private _txtEMAIL As TextBox

		' Token: 0x04000734 RID: 1844
		<AccessedThroughProperty("txtWEBSITE")>
		Private _txtWEBSITE As TextBox

		' Token: 0x04000735 RID: 1845
		<AccessedThroughProperty("chkISCUS")>
		Private _chkISCUS As CheckBox

		' Token: 0x04000736 RID: 1846
		<AccessedThroughProperty("chkISFOR")>
		Private _chkISFOR As CheckBox

		' Token: 0x04000737 RID: 1847
		<AccessedThroughProperty("chkISORG")>
		Private _chkISORG As CheckBox

		' Token: 0x04000738 RID: 1848
		<AccessedThroughProperty("lblADDRESS")>
		Private _lblADDRESS As Label

		' Token: 0x04000739 RID: 1849
		<AccessedThroughProperty("lblTEL")>
		Private _lblTEL As Label

		' Token: 0x0400073A RID: 1850
		<AccessedThroughProperty("lblMOBILE")>
		Private _lblMOBILE As Label

		' Token: 0x0400073B RID: 1851
		<AccessedThroughProperty("lblCONTACT")>
		Private _lblCONTACT As Label

		' Token: 0x0400073C RID: 1852
		<AccessedThroughProperty("lblVATCODE")>
		Private _lblVATCODE As Label

		' Token: 0x0400073D RID: 1853
		<AccessedThroughProperty("lblFAX")>
		Private _lblFAX As Label

		' Token: 0x0400073E RID: 1854
		<AccessedThroughProperty("lblISSUP")>
		Private _lblISSUP As Label

		' Token: 0x0400073F RID: 1855
		<AccessedThroughProperty("lblISCUS")>
		Private _lblISCUS As Label

		' Token: 0x04000740 RID: 1856
		<AccessedThroughProperty("lblISFOR")>
		Private _lblISFOR As Label

		' Token: 0x04000741 RID: 1857
		<AccessedThroughProperty("lblISORG")>
		Private _lblISORG As Label

		' Token: 0x04000742 RID: 1858
		<AccessedThroughProperty("txtColor")>
		Private _txtColor As TextBox

		' Token: 0x04000743 RID: 1859
		<AccessedThroughProperty("BtnSELECTMANHOMDV")>
		Private _BtnSELECTMANHOMDV As Button

		' Token: 0x04000744 RID: 1860
		<AccessedThroughProperty("TxtTENNHOMDV")>
		Private _TxtTENNHOMDV As TextBox

		' Token: 0x04000745 RID: 1861
		<AccessedThroughProperty("TxtMANHOMDV")>
		Private _TxtMANHOMDV As TextBox

		' Token: 0x04000746 RID: 1862
		<AccessedThroughProperty("LblMANHOMDV")>
		Private _LblMANHOMDV As Label

		' Token: 0x04000747 RID: 1863
		<AccessedThroughProperty("LblBIRTHDAY")>
		Private _LblBIRTHDAY As Label

		' Token: 0x04000748 RID: 1864
		<AccessedThroughProperty("mtxBIRTHDAY")>
		Private _mtxBIRTHDAY As MaskedTextBox

		' Token: 0x04000749 RID: 1865
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x0400074A RID: 1866
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x0400074B RID: 1867
		<AccessedThroughProperty("txtTUOI")>
		Private _txtTUOI As TextBox

		' Token: 0x0400074C RID: 1868
		<AccessedThroughProperty("cmbGIOTINH")>
		Private _cmbGIOTINH As ComboBox

		' Token: 0x0400074D RID: 1869
		<AccessedThroughProperty("lblNAMGIOI")>
		Private _lblNAMGIOI As Label

		' Token: 0x0400074E RID: 1870
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x0400074F RID: 1871
		<AccessedThroughProperty("txtJOB")>
		Private _txtJOB As TextBox

		' Token: 0x04000750 RID: 1872
		<AccessedThroughProperty("txtRemark")>
		Private _txtRemark As TextBox

		' Token: 0x04000751 RID: 1873
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x04000752 RID: 1874
		<AccessedThroughProperty("Panel1")>
		Private _Panel1 As Panel

		' Token: 0x04000753 RID: 1875
		<AccessedThroughProperty("picAnh")>
		Private _picAnh As PictureBox

		' Token: 0x04000754 RID: 1876
		<AccessedThroughProperty("picZoom")>
		Private _picZoom As PictureBox

		' Token: 0x04000755 RID: 1877
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x04000756 RID: 1878
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x04000757 RID: 1879
		<AccessedThroughProperty("txtCHUCVU")>
		Private _txtCHUCVU As TextBox

		' Token: 0x04000758 RID: 1880
		<AccessedThroughProperty("txtCAP")>
		Private _txtCAP As TextBox

		' Token: 0x04000759 RID: 1881
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x0400075A RID: 1882
		<AccessedThroughProperty("btnSaveAndSelect")>
		Private _btnSaveAndSelect As Button

		' Token: 0x0400075B RID: 1883
		<AccessedThroughProperty("Label6")>
		Private _Label6 As Label

		' Token: 0x0400075C RID: 1884
		<AccessedThroughProperty("txtMucGiamGia")>
		Private _txtMucGiamGia As TextBox

		' Token: 0x0400075D RID: 1885
		<AccessedThroughProperty("btnMucGiamGia")>
		Private _btnMucGiamGia As Button

		' Token: 0x0400075E RID: 1886
		<AccessedThroughProperty("btnFinger")>
		Private _btnFinger As Button

		' Token: 0x0400075F RID: 1887
		<AccessedThroughProperty("txtCardCode")>
		Private _txtCardCode As TextBox

		' Token: 0x04000760 RID: 1888
		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		' Token: 0x04000761 RID: 1889
		<AccessedThroughProperty("mtxNgayThoiViec")>
		Private _mtxNgayThoiViec As MaskedTextBox

		' Token: 0x04000762 RID: 1890
		<AccessedThroughProperty("Label8")>
		Private _Label8 As Label

		' Token: 0x04000763 RID: 1891
		<AccessedThroughProperty("mtxNgayNhanViec")>
		Private _mtxNgayNhanViec As MaskedTextBox

		' Token: 0x04000764 RID: 1892
		<AccessedThroughProperty("Label9")>
		Private _Label9 As Label

		' Token: 0x04000765 RID: 1893
		<AccessedThroughProperty("Label10")>
		Private _Label10 As Label

		' Token: 0x04000766 RID: 1894
		<AccessedThroughProperty("txtTenUser")>
		Private _txtTenUser As TextBox

		' Token: 0x04000767 RID: 1895
		<AccessedThroughProperty("txtMaUser")>
		Private _txtMaUser As TextBox

		' Token: 0x04000768 RID: 1896
		<AccessedThroughProperty("btnMaUser")>
		Private _btnMaUser As Button

		' Token: 0x04000769 RID: 1897
		Private mArrStrFrmMess As String()

		' Token: 0x0400076A RID: 1898
		Private mbytFormStatus As Byte

		' Token: 0x0400076B RID: 1899
		Private mbytSuccess As Byte

		' Token: 0x0400076C RID: 1900
		Private mStrFilter As String

		' Token: 0x0400076D RID: 1901
		Private mclsTbStore As clsConnect

		' Token: 0x0400076E RID: 1902
		Private mclsTbDMBK As clsConnect

		' Token: 0x0400076F RID: 1903
		Private mstrStore As String

		' Token: 0x04000770 RID: 1904
		Private mStrBIRTHDAY As String

		' Token: 0x04000771 RID: 1905
		Private mStrNgayNhanViec As String

		' Token: 0x04000772 RID: 1906
		Private mStrNgayThoiViec As String

		' Token: 0x04000773 RID: 1907
		Private mclsTbDMNHOMDV As clsConnect

		' Token: 0x04000774 RID: 1908
		Private mbytGIOITINH As Byte

		' Token: 0x04000775 RID: 1909
		Private mstrUIMAGE As String

		' Token: 0x04000776 RID: 1910
		Private mblnSaveAndSelect As Boolean

		' Token: 0x04000777 RID: 1911
		Private mStrFinger1 As String

		' Token: 0x04000778 RID: 1912
		Private mStrFinger2 As String

		' Token: 0x04000779 RID: 1913
		Private mStrFinger3 As String

		' Token: 0x0400077A RID: 1914
		Private mBlnAutoDel As Boolean

		' Token: 0x0400077B RID: 1915
		Private mBlnModifyMulti As Boolean

		' Token: 0x0400077C RID: 1916
		Private mblnAutoAdd_DMDV As Boolean

		' Token: 0x0400077D RID: 1917
		Private mclsTbDMUser As clsConnect
	End Class
End Namespace
