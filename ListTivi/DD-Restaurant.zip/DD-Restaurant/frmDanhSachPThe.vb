﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000031 RID: 49
	<DesignerGenerated()>
	Public Partial Class frmDanhSachPThe
		Inherits Form

		' Token: 0x06000A51 RID: 2641 RVA: 0x000792F4 File Offset: 0x000774F4
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmRePrintBill_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDanhSachPThe_Load
			frmDanhSachPThe.__ENCList.Add(New WeakReference(Me))
			Me.mblnAutoAdd = False
			Me.mblnThu = True
			Me.mBlnPThe2 = False
			Me.mStrConISDULIEU = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x170003D4 RID: 980
		' (get) Token: 0x06000A54 RID: 2644 RVA: 0x0007A01C File Offset: 0x0007821C
		' (set) Token: 0x06000A55 RID: 2645 RVA: 0x0007A034 File Offset: 0x00078234
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x170003D5 RID: 981
		' (get) Token: 0x06000A56 RID: 2646 RVA: 0x0007A0A0 File Offset: 0x000782A0
		' (set) Token: 0x06000A57 RID: 2647 RVA: 0x00003BA6 File Offset: 0x00001DA6
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170003D6 RID: 982
		' (get) Token: 0x06000A58 RID: 2648 RVA: 0x0007A0B8 File Offset: 0x000782B8
		' (set) Token: 0x06000A59 RID: 2649 RVA: 0x0007A0D0 File Offset: 0x000782D0
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170003D7 RID: 983
		' (get) Token: 0x06000A5A RID: 2650 RVA: 0x0007A13C File Offset: 0x0007833C
		' (set) Token: 0x06000A5B RID: 2651 RVA: 0x00003BB0 File Offset: 0x00001DB0
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x170003D8 RID: 984
		' (get) Token: 0x06000A5C RID: 2652 RVA: 0x0007A154 File Offset: 0x00078354
		' (set) Token: 0x06000A5D RID: 2653 RVA: 0x00003BBA File Offset: 0x00001DBA
		Friend Overridable Property lblFilterDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFilterDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFilterDate = value
			End Set
		End Property

		' Token: 0x170003D9 RID: 985
		' (get) Token: 0x06000A5E RID: 2654 RVA: 0x0007A16C File Offset: 0x0007836C
		' (set) Token: 0x06000A5F RID: 2655 RVA: 0x00003BC4 File Offset: 0x00001DC4
		Friend Overridable Property btnCancel As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnCancel = value
			End Set
		End Property

		' Token: 0x170003DA RID: 986
		' (get) Token: 0x06000A60 RID: 2656 RVA: 0x0007A184 File Offset: 0x00078384
		' (set) Token: 0x06000A61 RID: 2657 RVA: 0x0007A19C File Offset: 0x0007839C
		Friend Overridable Property mtxFromDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxFromDate IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxFromDate.TextChanged, AddressOf Me.mtxDATE_TextChanged
				End If
				Me._mtxFromDate = value
				flag = Me._mtxFromDate IsNot Nothing
				If flag Then
					AddHandler Me._mtxFromDate.TextChanged, AddressOf Me.mtxDATE_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170003DB RID: 987
		' (get) Token: 0x06000A62 RID: 2658 RVA: 0x0007A208 File Offset: 0x00078408
		' (set) Token: 0x06000A63 RID: 2659 RVA: 0x0007A220 File Offset: 0x00078420
		Friend Overridable Property dtpTuNgay As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpTuNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpTuNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.dtpTuNgay_ValueChanged
				End If
				Me._dtpTuNgay = value
				flag = Me._dtpTuNgay IsNot Nothing
				If flag Then
					AddHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.dtpTuNgay_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x170003DC RID: 988
		' (get) Token: 0x06000A64 RID: 2660 RVA: 0x0007A28C File Offset: 0x0007848C
		' (set) Token: 0x06000A65 RID: 2661 RVA: 0x0007A2A4 File Offset: 0x000784A4
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170003DD RID: 989
		' (get) Token: 0x06000A66 RID: 2662 RVA: 0x0007A310 File Offset: 0x00078510
		' (set) Token: 0x06000A67 RID: 2663 RVA: 0x0007A328 File Offset: 0x00078528
		Friend Overridable Property cboNgay As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cboNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cboNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._cboNgay.SelectedIndexChanged, AddressOf Me.cboNgay_SelectedIndexChanged
				End If
				Me._cboNgay = value
				flag = Me._cboNgay IsNot Nothing
				If flag Then
					AddHandler Me._cboNgay.SelectedIndexChanged, AddressOf Me.cboNgay_SelectedIndexChanged
				End If
			End Set
		End Property

		' Token: 0x170003DE RID: 990
		' (get) Token: 0x06000A68 RID: 2664 RVA: 0x0007A394 File Offset: 0x00078594
		' (set) Token: 0x06000A69 RID: 2665 RVA: 0x00003BCE File Offset: 0x00001DCE
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x170003DF RID: 991
		' (get) Token: 0x06000A6A RID: 2666 RVA: 0x0007A3AC File Offset: 0x000785AC
		' (set) Token: 0x06000A6B RID: 2667 RVA: 0x0007A3C4 File Offset: 0x000785C4
		Friend Overridable Property btnPrintMayInHD As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrintMayInHD
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrintMayInHD IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrintMayInHD.Click, AddressOf Me.btnPrintMayInHD_Click
				End If
				Me._btnPrintMayInHD = value
				flag = Me._btnPrintMayInHD IsNot Nothing
				If flag Then
					AddHandler Me._btnPrintMayInHD.Click, AddressOf Me.btnPrintMayInHD_Click
				End If
			End Set
		End Property

		' Token: 0x170003E0 RID: 992
		' (get) Token: 0x06000A6C RID: 2668 RVA: 0x0007A430 File Offset: 0x00078630
		' (set) Token: 0x06000A6D RID: 2669 RVA: 0x0007A448 File Offset: 0x00078648
		Friend Overridable Property mtxToDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxToDate IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxToDate.TextChanged, AddressOf Me.mtxToDATE_TextChanged
				End If
				Me._mtxToDate = value
				flag = Me._mtxToDate IsNot Nothing
				If flag Then
					AddHandler Me._mtxToDate.TextChanged, AddressOf Me.mtxToDATE_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170003E1 RID: 993
		' (get) Token: 0x06000A6E RID: 2670 RVA: 0x0007A4B4 File Offset: 0x000786B4
		' (set) Token: 0x06000A6F RID: 2671 RVA: 0x0007A4CC File Offset: 0x000786CC
		Friend Overridable Property dtpDenNgay As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpDenNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpDenNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpDenNgay.ValueChanged, AddressOf Me.dtpDenNgay_ValueChanged
				End If
				Me._dtpDenNgay = value
				flag = Me._dtpDenNgay IsNot Nothing
				If flag Then
					AddHandler Me._dtpDenNgay.ValueChanged, AddressOf Me.dtpDenNgay_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x170003E2 RID: 994
		' (get) Token: 0x06000A70 RID: 2672 RVA: 0x0007A538 File Offset: 0x00078738
		' (set) Token: 0x06000A71 RID: 2673 RVA: 0x00003BD8 File Offset: 0x00001DD8
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x170003E3 RID: 995
		' (get) Token: 0x06000A72 RID: 2674 RVA: 0x0007A550 File Offset: 0x00078750
		' (set) Token: 0x06000A73 RID: 2675 RVA: 0x00003BE2 File Offset: 0x00001DE2
		Public Property pBlnPThe2 As Boolean
			Get
				Return Me.mBlnPThe2
			End Get
			Set(value As Boolean)
				Me.mBlnPThe2 = value
			End Set
		End Property

		' Token: 0x170003E4 RID: 996
		' (get) Token: 0x06000A74 RID: 2676 RVA: 0x0007A568 File Offset: 0x00078768
		' (set) Token: 0x06000A75 RID: 2677 RVA: 0x00003BED File Offset: 0x00001DED
		Public Property pblnThu As Boolean
			Get
				Return Me.mblnThu
			End Get
			Set(value As Boolean)
				Me.mblnThu = value
			End Set
		End Property

		' Token: 0x170003E5 RID: 997
		' (get) Token: 0x06000A76 RID: 2678 RVA: 0x0007A580 File Offset: 0x00078780
		' (set) Token: 0x06000A77 RID: 2679 RVA: 0x00003BF8 File Offset: 0x00001DF8
		Public Property pStrNGAYCT As String
			Get
				Return Me.mStrNGAYCT
			End Get
			Set(value As String)
				Me.mStrNGAYCT = value
			End Set
		End Property

		' Token: 0x170003E6 RID: 998
		' (get) Token: 0x06000A78 RID: 2680 RVA: 0x0007A598 File Offset: 0x00078798
		' (set) Token: 0x06000A79 RID: 2681 RVA: 0x00003C03 File Offset: 0x00001E03
		Public Property pStrNGAYGS As String
			Get
				Return Me.mStrNGAYGS
			End Get
			Set(value As String)
				Me.mStrNGAYGS = value
			End Set
		End Property

		' Token: 0x170003E7 RID: 999
		' (get) Token: 0x06000A7A RID: 2682 RVA: 0x0007A5B0 File Offset: 0x000787B0
		' (set) Token: 0x06000A7B RID: 2683 RVA: 0x00003C0E File Offset: 0x00001E0E
		Public Property pStrSOCT As String
			Get
				Return Me.mStrSOCT
			End Get
			Set(value As String)
				Me.mStrSOCT = value
			End Set
		End Property

		' Token: 0x170003E8 RID: 1000
		' (get) Token: 0x06000A7C RID: 2684 RVA: 0x0007A5C8 File Offset: 0x000787C8
		' (set) Token: 0x06000A7D RID: 2685 RVA: 0x00003C19 File Offset: 0x00001E19
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06000A7E RID: 2686 RVA: 0x0007A5E0 File Offset: 0x000787E0
		Private Sub frmRePrintBill_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmRePrintBill_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A7F RID: 2687 RVA: 0x0007A678 File Offset: 0x00078878
		Private Sub frmDanhSachPThe_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				Me.cboNgay.Items.Add(Me.mArrStrFrmMess(4))
				Me.cboNgay.SelectedIndex = 0
				flag = b <> 0
				If flag Then
					b = Me.gf_GetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				Me.mtxFromDate.Text = String.Concat(New String() { DateAndTime.Today.Day.ToString("00"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Year.ToString("0000") })
				Me.mtxToDate.Text = Me.mtxFromDate.Text
				flag = Conversions.ToBoolean(If((Not Conversions.ToBoolean(mdlVariable.garrDrDMMAYINHD.Length > 0) OrElse Not Conversions.ToBoolean(Operators.OrObject(Operators.OrObject(Operators.CompareObjectEqual(mdlVariable.garrDrDMMAYINHD(0)("KIND"), 0, False), Operators.CompareObjectEqual(mdlVariable.garrDrDMMAYINHD(0)("KIND"), 1, False)), Operators.CompareObjectEqual(mdlVariable.garrDrDMMAYINHD(0)("KIND"), 2, False)))), False, True))
				Dim flag2 As Boolean
				If flag Then
					flag2 = mdlVariable.gsrlCOMBillport Is Nothing
					If flag2 Then
						b = mdlPrintReceipt.gfOpenSerialPort()
					End If
				Else
					b = 1
				End If
				flag2 = b = 0
				If flag2 Then
					Me.btnPreview.Enabled = False
					Me.btnPrintMayInHD.Enabled = False
				Else
					Me.btnPreview.Enabled = True
					Me.btnPrintMayInHD.Enabled = True
				End If
				flag2 = Not Me.mBlnPThe2
				If flag2 Then
					Me.btnPrintMayInHD.Visible = False
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmRePrintBill_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A80 RID: 2688 RVA: 0x0007A96C File Offset: 0x00078B6C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				mdlPrintReceipt.gsCloseSerialPort()
				mdlFile.gfWriteLogFile("Nhấn Thoát khỏi form")
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A81 RID: 2689 RVA: 0x0007AA18 File Offset: 0x00078C18
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean = Me.dgvData.SelectedCells.Count = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
				Else
					mdlFile.gfWriteLogFile("Nhấn in thông tin với DOCID: " + Conversions.ToString(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("DOCID").Value))))
					flag = Me.mBlnPThe2
					If flag Then
						Me.fPrintDMPTHE2Detail(Me.mStrConISDULIEU, CLng(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("DOCID").Value)))), 6, 0.0, 0.0, 0.0, 0.0, "")
					Else
						Me.fPrintDMPTHEDetail(Me.mStrConISDULIEU, CLng(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("DOCID").Value)))))
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A82 RID: 2690 RVA: 0x0007ABE0 File Offset: 0x00078DE0
		Private Sub mtxDATE_TextChanged(sender As Object, e As EventArgs)
			Try
				Dim text As String = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
				Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text, "", 1, -1, CompareMethod.Binary))
				Dim flag As Boolean = Strings.Len(text2) < 8
				If Not flag Then
					text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 1, 2) })
					flag = Not Information.IsDate(text2)
					If Not flag Then
						Me.mStrConISDULIEU = String.Concat(New String() { "Data Source = ", mdlVariable.gStrServer, "; Initial Catalog=ISDULIEU", Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 7, 4), Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 4, 2), "; User ID=", mdlVariable.gStrUserID, "; Password=", mdlVariable.gStrPassword })
						flag = Not mdlDatabase.gfCheck_ExistsDB("ISDULIEU" + Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 4, 2))
						If Not flag Then
							Me.gf_GetData_4Grid()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxDATE_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A83 RID: 2691 RVA: 0x0007AE40 File Offset: 0x00079040
		Private Sub mtxToDATE_TextChanged(sender As Object, e As EventArgs)
			Try
				Dim text As String = Strings.Mid(Me.mtxToDate.Text, 3, 1)
				Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text, "", 1, -1, CompareMethod.Binary))
				Dim flag As Boolean = Strings.Len(text2) < 8
				If Not flag Then
					text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 1, 2) })
					flag = Not Information.IsDate(text2)
					If Not flag Then
						Me.mStrConISDULIEU = String.Concat(New String() { "Data Source = ", mdlVariable.gStrServer, "; Initial Catalog=ISDULIEU", Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 7, 4), Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 4, 2), "; User ID=", mdlVariable.gStrUserID, "; Password=", mdlVariable.gStrPassword })
						flag = Not mdlDatabase.gfCheck_ExistsDB("ISDULIEU" + Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 4, 2))
						If Not flag Then
							Me.gf_GetData_4Grid()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxToDATE_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A84 RID: 2692 RVA: 0x0007B0A0 File Offset: 0x000792A0
		Private Sub dtpTuNgay_ValueChanged(sender As Object, e As EventArgs)
			Me.mtxFromDate.Text = String.Concat(New String() { Me.dtpTuNgay.Value.Day.ToString("00"), "/", Me.dtpTuNgay.Value.Month.ToString("00"), "/", Me.dtpTuNgay.Value.Year.ToString("0000") })
		End Sub

		' Token: 0x06000A85 RID: 2693 RVA: 0x0007B150 File Offset: 0x00079350
		Private Sub dtpDenNgay_ValueChanged(sender As Object, e As EventArgs)
			Me.mtxToDate.Text = String.Concat(New String() { Me.dtpDenNgay.Value.Day.ToString("00"), "/", Me.dtpDenNgay.Value.Month.ToString("00"), "/", Me.dtpDenNgay.Value.Year.ToString("0000") })
		End Sub

		' Token: 0x06000A86 RID: 2694 RVA: 0x0007B200 File Offset: 0x00079400
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("NGAYMUA").HeaderText = Strings.Trim(Me.mArrStrFrmMess(4))
				dgvData.Columns("NGAYMUA").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.15))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("NGAYMUA").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENDV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(8))
				dgvData.Columns("TENDV").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.2))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("TENDV").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NOIDUNG").HeaderText = Strings.Trim(Me.mArrStrFrmMess(9))
				dgvData.Columns("NOIDUNG").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.22))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("NOIDUNG").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SOTIEN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(10))
				dgvData.Columns("SOTIEN").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.13))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
				dgvData.Columns("SOTIEN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NGAYBD").HeaderText = Strings.Trim(Me.mArrStrFrmMess(5))
				dgvData.Columns("NGAYBD").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.15))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("NGAYBD").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NGAYHH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(6))
				dgvData.Columns("NGAYHH").Width = CInt(Math.Round(CDbl(Me.dgvData.Width) * 0.15))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("NGAYHH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENUSER").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("TENUSER").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("TENUSER").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DOCID").Visible = False
				dgvData.Columns("MADV").Visible = False
				dgvData.Columns("MAUSER").Visible = False
				Dim pBlnPThe As Boolean = Me.pBlnPThe2
				If pBlnPThe Then
					dgvData.Columns("SOCT").Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000A87 RID: 2695 RVA: 0x0007B6CC File Offset: 0x000798CC
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000A88 RID: 2696 RVA: 0x0007B774 File Offset: 0x00079974
		Public Function gf_GetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				Dim text As String = Me.mtxFromDate.Text.Trim()
				Dim flag As Boolean = text.Trim().Length > 5
				If flag Then
					text = text.Substring(6) + text.Substring(3, 2) + text.Substring(0, 2)
				Else
					text = ""
				End If
				Dim text2 As String = Me.mtxToDate.Text.Trim()
				flag = text2.Trim().Length > 5
				If flag Then
					text2 = text2.Substring(6) + text2.Substring(3, 2) + text2.Substring(0, 2)
				Else
					text2 = ""
				End If
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchKH"
				array(0).Value = mdlVariable.gStrStockCode
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@intDecAmt"
				array(1).Value = mdlVariable.gbytDECNUMAMT
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@nvcNGAY"
				array(2).Value = text
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@nchNGAY"
				array(3).Value = Me.cboNgay.SelectedIndex
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@nvcDENNGAY"
				array(4).Value = text2
				flag = Me.mStrConISDULIEU.Trim().Length = 0
				If flag Then
					Me.mStrConISDULIEU = mdlVariable.gStrConISDULIEU
				End If
				mdlFile.gfWriteLogFile("Lọc dữ liệu theo ngày: " + Me.mtxFromDate.Text.Trim())
				Dim num As Integer
				clsConnect = New clsConnect(Me.mStrConISDULIEU, array, Conversions.ToString(Interaction.IIf(Me.mBlnPThe2, "SP_FRMDANHSACHPTHE2_GET_DATA", "SP_FRMDANHSACHPTHE_GET_DATA")), num)
				flag = num = 1
				If flag Then
					Me.dgvData.DataSource = clsConnect
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gf_GetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000A89 RID: 2697 RVA: 0x0007BA50 File Offset: 0x00079C50
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000A8A RID: 2698 RVA: 0x0007BB04 File Offset: 0x00079D04
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim text As String = Strings.Trim(mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMKH", "OBJID", mdlVariable.gStrStockCode, "OBJNAME"))
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				Dim flag As Boolean = mdlUIForm.gfChek_RightSale("00058", False) = 0
				If flag Then
					Me.btnDelete.Visible = False
				Else
					Me.btnDelete.Visible = True
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000A8B RID: 2699 RVA: 0x0007BC84 File Offset: 0x00079E84
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A8C RID: 2700 RVA: 0x0007BD24 File Offset: 0x00079F24
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.dgvData.SelectedCells.Count = 0
			If flag Then
				MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(15), Me.mArrStrFrmMess(16), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.CanhBao)
			Else
				flag = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(17), Me.mArrStrFrmMess(16), frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.No
				If Not flag Then
					Dim text As String = Me.dgvData.CurrentRow.Cells("DOCID").Value.ToString().Trim()
					Dim clsConnect As clsConnect = New clsConnect()
					Dim sqlCommand As SqlCommand = New SqlCommand()
					Dim array As SqlParameter() = New SqlParameter(1) {}
					Try
						array(0) = sqlCommand.CreateParameter()
						array(0).ParameterName = "@pintDOCID"
						array(0).Value = text
						flag = Me.mStrConISDULIEU.Trim().Length = 0
						If flag Then
							Me.mStrConISDULIEU = mdlVariable.gStrConISDULIEU
						End If
						Dim num As Integer
						clsConnect = New clsConnect(Me.mStrConISDULIEU, array, "SP_FRMDANHSACHPTHE_DELETE", num)
						mdlFile.gfWriteLogFile("Nhấn xóa thông tin với DOCID: " + text)
						flag = num = 1
						If flag Then
							Me.gf_GetData_4Grid()
						End If
					Catch ex As Exception
						Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gf_GetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
					Finally
						sqlCommand.Dispose()
						clsConnect.Dispose()
					End Try
				End If
			End If
		End Sub

		' Token: 0x06000A8D RID: 2701 RVA: 0x00003C24 File Offset: 0x00001E24
		Private Sub cboNgay_SelectedIndexChanged(sender As Object, e As EventArgs)
			Me.mtxDATE_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
		End Sub

		' Token: 0x06000A8E RID: 2702 RVA: 0x0007BF04 File Offset: 0x0007A104
		Private Sub btnPrintMayInHD_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = mdlVariable.gBytPrinting = 1
				If Not flag Then
					flag = Me.dgvData.SelectedCells.Count = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					Else
						mdlFile.gfWriteLogFile("Nhấn in máy in HĐ với DOCID: " + Conversions.ToString(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("DOCID").Value))))
						flag = mdlVariable.garrDrDMMAYINHD IsNot Nothing AndAlso mdlVariable.garrDrDMMAYINHD.Length <= 0
						If flag Then
							Interaction.MsgBox(mdlVariable.gArrStrMess(42) + vbCrLf & "btnPrintMayInHD_Click", MsgBoxStyle.Critical, Nothing)
						Else
							mdlVariable.gBytPrinting = 1
							mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
							Dim obj As Object = mdlVariable.garrDrDMMAYINHD(0)("KIND")
							flag = Conversions.ToBoolean(If((Conversions.ToBoolean(Operators.CompareObjectEqual(obj, 0, False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, 1, False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, 2, False))), True, False))
							If flag Then
								Dim flag2 As Boolean = mdlVariable.gsrlCOMBillport Is Nothing
								If flag2 Then
									Dim b As Byte = mdlPrintReceipt.gfOpenSerialPort()
								End If
							Else
								Dim flag2 As Boolean = Conversions.ToBoolean(If((Conversions.ToBoolean(Operators.CompareObjectEqual(obj, 3, False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, 4, False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, 5, False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, 7, False))), True, False))
								If flag2 Then
									' The following expression was wrapped in a checked-expression
									Me.fPrintDMPTHE2Detail(mdlVariable.gStrConISDULIEU, CLng(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("DOCID").Value)))), Conversions.ToByte(mdlVariable.garrDrDMMAYINHD(0)("KIND")), Conversions.ToDouble(mdlVariable.garrDrDMMAYINHD(0)("TOPMARGIN")), Conversions.ToDouble(mdlVariable.garrDrDMMAYINHD(0)("LEFTMARGIN")), Conversions.ToDouble(mdlVariable.garrDrDMMAYINHD(0)("BOTTOMMARGIN")), Conversions.ToDouble(mdlVariable.garrDrDMMAYINHD(0)("RIGHTMARGIN")), mdlVariable.garrDrDMMAYINHD(0)("OBJNAME").ToString().Trim())
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				mdlVariable.gBytPrinting = 0
				Interaction.MsgBox(mdlVariable.gArrStrMess(1) + vbCrLf & "btnPrintMayInHD_Click " + ex.Message + vbCrLf, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gBytPrinting = 0
				mdlPrintReceipt.gsCloseSerialPort()
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
			End Try
		End Sub

		' Token: 0x06000A8F RID: 2703 RVA: 0x0007C234 File Offset: 0x0007A434
		Private Function fPrintDMPTHEDetail(strConDulieu As String, strDOCID As Long) As Byte
			Dim rptDMPTHEDetail As rptDMPTHEDetail = New rptDMPTHEDetail()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMPTHEDetail, "")
				Dim text As String = "2070401000"
				mdlReport.gsSetOfficeReport(rptDMPTHEDetail, text)
				mdlReport.gsSetFontReport(rptDMPTHEDetail)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchKH"
				array(0).Value = mdlVariable.gStrStockCode
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@intDOCID"
				array(1).Value = strDOCID
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@intDecAmt"
				array(2).Value = mdlVariable.gbytDECNUMAMT
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@nvcNAM"
				array(3).Value = Me.mArrStrFrmMess(21)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@nvcNU"
				array(4).Value = Me.mArrStrFrmMess(22)
				Dim flag As Boolean = strConDulieu.Length = 0
				If flag Then
					strConDulieu = mdlVariable.gStrConISDULIEU
				End If
				Dim num As Integer
				clsConnect = New clsConnect(strConDulieu, array, "SP_FRMDANHSACHPTHE_GET_DATA_REPORT", num)
				flag = num = 1
				If flag Then
					rptDMPTHEDetail.SetDataSource(clsConnect)
					Dim textObject As TextObject = CType(rptDMPTHEDetail.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					textObject.Text = Me.mArrStrFrmMess(20)
					rptDMPTHEDetail.DataDefinition.FormulaFields("fUnitCode").Text = "{dtReport.MADV}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fUnitName").Text = "{dtReport.TENDV}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fAddress").Text = "{dtReport.ADDRESS}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fMobile").Text = "{dtReport.MOBILE}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fBIRTHDAY").Text = "{dtReport.NGAYSINH}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fVATCODE").Text = "{dtReport.CMND}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fGIOITINH").Text = "{dtReport.GIOITINH}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fNHOMDV").Text = "{dtReport.TENNHOMDV}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fNGAYMUA").Text = "{dtReport.NGAYMUA}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fNOIDUNG").Text = "{dtReport.NOIDUNG}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fSOTIEN").Text = "{dtReport.SOTIEN}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fNGAYBATDAU").Text = "{dtReport.NGAYBD}"
					rptDMPTHEDetail.DataDefinition.FormulaFields("fNGAYHETHAN").Text = "{dtReport.NGAYHH}"
					mdlReport.gsSetTextReport(rptDMPTHEDetail, "RPTDMPTHEDETAIL")
					MyProject.Forms.frmReport.pSource = rptDMPTHEDetail
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMPTHEDetail.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMPTHEDetail.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMPTHEDetail " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMPTHEDetail.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000A90 RID: 2704 RVA: 0x0007C6A4 File Offset: 0x0007A8A4
		Private Function fPrintDMPTHE2Detail(strConDulieu As String, strDOCID As Long, Optional pbytPrinter As Byte = 6, Optional pdblTop As Double = 0.0, Optional pdblLeft As Double = 0.0, Optional pdblBot As Double = 0.0, Optional pdblRight As Double = 0.0, Optional pPrinterName As String = "") As Byte
			Dim reportDocument As ReportDocument = New ReportDocument()
			Select Case pbytPrinter
				Case 3, 9
					reportDocument = New rptDMPTHEDetail_DriverK80()
				Case 4
					reportDocument = New rptDMPTHEDetail_DriverK80()
				Case 5
					reportDocument = New rptDMPTHEDetail_DriverK80()
				Case 6
					reportDocument = New rptDMPTHEDetail()
				Case 7
					reportDocument = New rptDMPTHEDetail_DriverK80()
			End Select
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(CType(reportDocument, ReportClass), "")
				Dim text As String = "2070401000"
				mdlReport.gsSetOfficeReport(CType(reportDocument, ReportClass), text)
				mdlReport.gsSetFontReport(CType(reportDocument, ReportClass))
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchKH"
				array(0).Value = mdlVariable.gStrStockCode
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@intDOCID"
				array(1).Value = strDOCID
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@intDecAmt"
				array(2).Value = mdlVariable.gbytDECNUMAMT
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@nvcNAM"
				array(3).Value = Me.mArrStrFrmMess(21)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@nvcNU"
				array(4).Value = Me.mArrStrFrmMess(22)
				Dim flag As Boolean = strConDulieu.Length = 0
				If flag Then
					strConDulieu = mdlVariable.gStrConISDULIEU
				End If
				Dim num As Integer
				clsConnect = New clsConnect(strConDulieu, array, "SP_FRMDANHSACHPTHE2_GET_DATA_REPORT", num)
				flag = num = 1
				If flag Then
					reportDocument.SetDataSource(clsConnect)
					Dim textObject As TextObject = CType(reportDocument.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					textObject.Text = Me.mArrStrFrmMess(20)
					reportDocument.DataDefinition.FormulaFields("fUnitCode").Text = "{dtReport.MADV}"
					reportDocument.DataDefinition.FormulaFields("fUnitName").Text = "{dtReport.TENDV}"
					reportDocument.DataDefinition.FormulaFields("fAddress").Text = "{dtReport.ADDRESS}"
					reportDocument.DataDefinition.FormulaFields("fMobile").Text = "{dtReport.MOBILE}"
					reportDocument.DataDefinition.FormulaFields("fBIRTHDAY").Text = "{dtReport.NGAYSINH}"
					reportDocument.DataDefinition.FormulaFields("fVATCODE").Text = "{dtReport.CMND}"
					reportDocument.DataDefinition.FormulaFields("fGIOITINH").Text = "{dtReport.GIOITINH}"
					reportDocument.DataDefinition.FormulaFields("fNHOMDV").Text = "{dtReport.TENNHOMDV}"
					reportDocument.DataDefinition.FormulaFields("fNGAYMUA").Text = "{dtReport.NGAYMUA}"
					reportDocument.DataDefinition.FormulaFields("fNOIDUNG").Text = "{dtReport.NOIDUNG}"
					reportDocument.DataDefinition.FormulaFields("fSOTIEN").Text = "{dtReport.SOTIEN}"
					reportDocument.DataDefinition.FormulaFields("fNGAYBATDAU").Text = "{dtReport.NGAYBD}"
					reportDocument.DataDefinition.FormulaFields("fNGAYHETHAN").Text = "{dtReport.NGAYHH}"
					mdlReport.gsSetTextReport(reportDocument, "RPTDMPTHEDETAIL")
					MyProject.Forms.frmReport.pSource = reportDocument
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					MyProject.Forms.frmReport.Text = textObject.Text
					flag = pbytPrinter <> 6
					If flag Then
						Dim pageMargins As PageMargins = Nothing
						pageMargins.topMargin = mdlReport.gfInches2Point(pdblTop)
						pageMargins.leftMargin = mdlReport.gfInches2Point(pdblLeft)
						pageMargins.bottomMargin = mdlReport.gfInches2Point(pdblBot)
						pageMargins.rightMargin = mdlReport.gfInches2Point(pdblRight)
						reportDocument.PrintOptions.ApplyPageMargins(pageMargins)
						reportDocument.PrintOptions.PrinterName = pPrinterName
						reportDocument.PrintToPrinter(1, False, 0, 0)
					Else
						reportDocument.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
						reportDocument.PrintOptions.PaperSize = PaperSize.PaperA4
						MyProject.Forms.frmReport.ShowDialog()
					End If
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMPTHE2Detail " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				reportDocument.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0400048C RID: 1164
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400048E RID: 1166
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x0400048F RID: 1167
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000490 RID: 1168
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000491 RID: 1169
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000492 RID: 1170
		<AccessedThroughProperty("lblFilterDate")>
		Private _lblFilterDate As Label

		' Token: 0x04000493 RID: 1171
		<AccessedThroughProperty("btnCancel")>
		Private _btnCancel As Button

		' Token: 0x04000494 RID: 1172
		<AccessedThroughProperty("mtxFromDate")>
		Private _mtxFromDate As MaskedTextBox

		' Token: 0x04000495 RID: 1173
		<AccessedThroughProperty("dtpTuNgay")>
		Private _dtpTuNgay As DateTimePicker

		' Token: 0x04000496 RID: 1174
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000497 RID: 1175
		<AccessedThroughProperty("cboNgay")>
		Private _cboNgay As ComboBox

		' Token: 0x04000498 RID: 1176
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000499 RID: 1177
		<AccessedThroughProperty("btnPrintMayInHD")>
		Private _btnPrintMayInHD As Button

		' Token: 0x0400049A RID: 1178
		<AccessedThroughProperty("mtxToDate")>
		Private _mtxToDate As MaskedTextBox

		' Token: 0x0400049B RID: 1179
		<AccessedThroughProperty("dtpDenNgay")>
		Private _dtpDenNgay As DateTimePicker

		' Token: 0x0400049C RID: 1180
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x0400049D RID: 1181
		Private mArrStrFrmMess As String()

		' Token: 0x0400049E RID: 1182
		Private mStrSOCT As String

		' Token: 0x0400049F RID: 1183
		Private mStrNGAYGS As String

		' Token: 0x040004A0 RID: 1184
		Private mStrNGAYCT As String

		' Token: 0x040004A1 RID: 1185
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040004A2 RID: 1186
		Private mblnAutoAdd As Boolean

		' Token: 0x040004A3 RID: 1187
		Private mbytLen_OBJID As Byte

		' Token: 0x040004A4 RID: 1188
		Private mclsTbDMKH As clsConnect

		' Token: 0x040004A5 RID: 1189
		Private mblnThu As Boolean

		' Token: 0x040004A6 RID: 1190
		Private mBlnPThe2 As Boolean

		' Token: 0x040004A7 RID: 1191
		Private mStrConISDULIEU As String
	End Class
End Namespace
