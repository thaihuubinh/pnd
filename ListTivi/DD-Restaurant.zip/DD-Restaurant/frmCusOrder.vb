﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200002D RID: 45
	<DesignerGenerated()>
	Public Partial Class frmCusOrder
		Inherits Form

		' Token: 0x060008E5 RID: 2277 RVA: 0x00068DB8 File Offset: 0x00066FB8
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmCusOrder_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmCusOrder_Load
			frmCusOrder.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd = False
			Me.mbdsSourceDel = New BindingSource()
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000353 RID: 851
		' (get) Token: 0x060008E8 RID: 2280 RVA: 0x00069A78 File Offset: 0x00067C78
		' (set) Token: 0x060008E9 RID: 2281 RVA: 0x000037A5 File Offset: 0x000019A5
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000354 RID: 852
		' (get) Token: 0x060008EA RID: 2282 RVA: 0x00069A90 File Offset: 0x00067C90
		' (set) Token: 0x060008EB RID: 2283 RVA: 0x00069AA8 File Offset: 0x00067CA8
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000355 RID: 853
		' (get) Token: 0x060008EC RID: 2284 RVA: 0x00069B14 File Offset: 0x00067D14
		' (set) Token: 0x060008ED RID: 2285 RVA: 0x00069B2C File Offset: 0x00067D2C
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000356 RID: 854
		' (get) Token: 0x060008EE RID: 2286 RVA: 0x00069B98 File Offset: 0x00067D98
		' (set) Token: 0x060008EF RID: 2287 RVA: 0x00069BB0 File Offset: 0x00067DB0
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000357 RID: 855
		' (get) Token: 0x060008F0 RID: 2288 RVA: 0x00069C1C File Offset: 0x00067E1C
		' (set) Token: 0x060008F1 RID: 2289 RVA: 0x000037AF File Offset: 0x000019AF
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000358 RID: 856
		' (get) Token: 0x060008F2 RID: 2290 RVA: 0x00069C34 File Offset: 0x00067E34
		' (set) Token: 0x060008F3 RID: 2291 RVA: 0x00069C4C File Offset: 0x00067E4C
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000359 RID: 857
		' (get) Token: 0x060008F4 RID: 2292 RVA: 0x00069CB8 File Offset: 0x00067EB8
		' (set) Token: 0x060008F5 RID: 2293 RVA: 0x00069CD0 File Offset: 0x00067ED0
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x1700035A RID: 858
		' (get) Token: 0x060008F6 RID: 2294 RVA: 0x00069D3C File Offset: 0x00067F3C
		' (set) Token: 0x060008F7 RID: 2295 RVA: 0x00069D54 File Offset: 0x00067F54
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700035B RID: 859
		' (get) Token: 0x060008F8 RID: 2296 RVA: 0x00069DC0 File Offset: 0x00067FC0
		' (set) Token: 0x060008F9 RID: 2297 RVA: 0x00069DD8 File Offset: 0x00067FD8
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.Sorted, AddressOf Me.dgvData_Sorted
					RemoveHandler Me._dgvData.RowEnter, AddressOf Me.dgvData_RowEnter
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.Sorted, AddressOf Me.dgvData_Sorted
					AddHandler Me._dgvData.RowEnter, AddressOf Me.dgvData_RowEnter
				End If
			End Set
		End Property

		' Token: 0x1700035C RID: 860
		' (get) Token: 0x060008FA RID: 2298 RVA: 0x00069E74 File Offset: 0x00068074
		' (set) Token: 0x060008FB RID: 2299 RVA: 0x000037B9 File Offset: 0x000019B9
		Friend Overridable Property lblFilterDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFilterDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFilterDate = value
			End Set
		End Property

		' Token: 0x1700035D RID: 861
		' (get) Token: 0x060008FC RID: 2300 RVA: 0x00069E8C File Offset: 0x0006808C
		' (set) Token: 0x060008FD RID: 2301 RVA: 0x000037C3 File Offset: 0x000019C3
		Friend Overridable Property dgvDataDetail As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvDataDetail
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvDataDetail = value
			End Set
		End Property

		' Token: 0x1700035E RID: 862
		' (get) Token: 0x060008FE RID: 2302 RVA: 0x00069EA4 File Offset: 0x000680A4
		' (set) Token: 0x060008FF RID: 2303 RVA: 0x00069EBC File Offset: 0x000680BC
		Friend Overridable Property txtMaDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMaDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMaDV IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMaDV.TextChanged, AddressOf Me.txtMaDV_TextChanged
					RemoveHandler Me._txtMaDV.Click, AddressOf Me.txtMaDV_Click
				End If
				Me._txtMaDV = value
				flag = Me._txtMaDV IsNot Nothing
				If flag Then
					AddHandler Me._txtMaDV.TextChanged, AddressOf Me.txtMaDV_TextChanged
					AddHandler Me._txtMaDV.Click, AddressOf Me.txtMaDV_Click
				End If
			End Set
		End Property

		' Token: 0x1700035F RID: 863
		' (get) Token: 0x06000900 RID: 2304 RVA: 0x00069F58 File Offset: 0x00068158
		' (set) Token: 0x06000901 RID: 2305 RVA: 0x00069F70 File Offset: 0x00068170
		Friend Overridable Property btnKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKH.Click, AddressOf Me.btnKH_Click
				End If
				Me._btnKH = value
				flag = Me._btnKH IsNot Nothing
				If flag Then
					AddHandler Me._btnKH.Click, AddressOf Me.btnKH_Click
				End If
			End Set
		End Property

		' Token: 0x17000360 RID: 864
		' (get) Token: 0x06000902 RID: 2306 RVA: 0x00069FDC File Offset: 0x000681DC
		' (set) Token: 0x06000903 RID: 2307 RVA: 0x000037CD File Offset: 0x000019CD
		Friend Overridable Property txtTENDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENDV = value
			End Set
		End Property

		' Token: 0x17000361 RID: 865
		' (get) Token: 0x06000904 RID: 2308 RVA: 0x00069FF4 File Offset: 0x000681F4
		' (set) Token: 0x06000905 RID: 2309 RVA: 0x0006A00C File Offset: 0x0006820C
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000362 RID: 866
		' (get) Token: 0x06000906 RID: 2310 RVA: 0x0006A078 File Offset: 0x00068278
		' (set) Token: 0x06000907 RID: 2311 RVA: 0x000037D7 File Offset: 0x000019D7
		Private Overridable Property mbdsSourceDel As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Me._mbdsSourceDel = value
			End Set
		End Property

		' Token: 0x17000363 RID: 867
		' (get) Token: 0x06000908 RID: 2312 RVA: 0x0006A090 File Offset: 0x00068290
		' (set) Token: 0x06000909 RID: 2313 RVA: 0x000037E1 File Offset: 0x000019E1
		Public Property pStrNGAYCT As String
			Get
				Return Me.mStrNGAYCT
			End Get
			Set(value As String)
				Me.mStrNGAYCT = value
			End Set
		End Property

		' Token: 0x17000364 RID: 868
		' (get) Token: 0x0600090A RID: 2314 RVA: 0x0006A0A8 File Offset: 0x000682A8
		' (set) Token: 0x0600090B RID: 2315 RVA: 0x000037EC File Offset: 0x000019EC
		Public Property pStrNGAYGS As String
			Get
				Return Me.mStrNGAYGS
			End Get
			Set(value As String)
				Me.mStrNGAYGS = value
			End Set
		End Property

		' Token: 0x17000365 RID: 869
		' (get) Token: 0x0600090C RID: 2316 RVA: 0x0006A0C0 File Offset: 0x000682C0
		' (set) Token: 0x0600090D RID: 2317 RVA: 0x000037F7 File Offset: 0x000019F7
		Public Property pStrSOCT As String
			Get
				Return Me.mStrSOCT
			End Get
			Set(value As String)
				Me.mStrSOCT = value
			End Set
		End Property

		' Token: 0x17000366 RID: 870
		' (get) Token: 0x0600090E RID: 2318 RVA: 0x0006A0D8 File Offset: 0x000682D8
		' (set) Token: 0x0600090F RID: 2319 RVA: 0x00003802 File Offset: 0x00001A02
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06000910 RID: 2320 RVA: 0x0006A0F0 File Offset: 0x000682F0
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData("NGAYKT", Me.mbdsSource.Position)
				Dim flag As Boolean = Me.mbdsSource.Count > 0
				If flag Then
					Dim dataGridViewCellEventArgs As DataGridViewCellEventArgs = New DataGridViewCellEventArgs(0, Me.mbdsSource.Count - 1)
					Me.dgvData_RowEnter(RuntimeHelpers.GetObjectValue(sender), dataGridViewCellEventArgs)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000911 RID: 2321 RVA: 0x0006A1F8 File Offset: 0x000683F8
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData("NGAYKT", Me.mbdsSource.Position)
					flag = Me.mbdsSource.Count > 0
					If flag Then
						Dim dataGridViewCellEventArgs As DataGridViewCellEventArgs = New DataGridViewCellEventArgs(0, Me.mbdsSource.Position)
						Me.dgvData_RowEnter(RuntimeHelpers.GetObjectValue(sender), dataGridViewCellEventArgs)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000912 RID: 2322 RVA: 0x0006A328 File Offset: 0x00068528
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData("NGAYKT", Me.mbdsSource.Position)
					flag = Me.mbdsSource.Count > 0
					If flag Then
						Dim dataGridViewCellEventArgs As DataGridViewCellEventArgs = New DataGridViewCellEventArgs(0, Me.mbdsSource.Position)
						Me.dgvData_RowEnter(RuntimeHelpers.GetObjectValue(sender), dataGridViewCellEventArgs)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000913 RID: 2323 RVA: 0x0006A44C File Offset: 0x0006864C
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData("NGAYKT", Me.mbdsSource.Position)
				Dim flag As Boolean = Me.mbdsSource.Count > 0
				If flag Then
					Dim dataGridViewCellEventArgs As DataGridViewCellEventArgs = New DataGridViewCellEventArgs(0, 0)
					Me.dgvData_RowEnter(RuntimeHelpers.GetObjectValue(sender), dataGridViewCellEventArgs)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000914 RID: 2324 RVA: 0x0006A53C File Offset: 0x0006873C
		Private Sub frmCusOrder_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmCusOrder_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000915 RID: 2325 RVA: 0x0006A5D4 File Offset: 0x000687D4
		Private Sub frmCusOrder_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMDV()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmCusOrder_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000916 RID: 2326 RVA: 0x0006A694 File Offset: 0x00068894
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000917 RID: 2327 RVA: 0x0006A79C File Offset: 0x0006899C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				mdlFile.gfWriteLogFile("Nhấn nút thoát lịch sử khách hàng")
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000918 RID: 2328 RVA: 0x0006A840 File Offset: 0x00068A40
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean
				If Operators.CompareString(Me.txtMaDV.Text.Trim(), "", False) <> 0 AndAlso Me.dgvDataDetail IsNot Nothing Then
					If Me.dgvDataDetail.RowCount > 0 Then
						flag = False
						GoTo IL_003C
					End If
				End If
				flag = True
				IL_003C:
				Dim flag2 As Boolean = flag
				If Not flag2 Then
					mdlVariable.garrStrCombo = New mdlVariable.struCombo(Me.dgvDataDetail.Rows.Count - 1 + 1 - 1) {}
					Dim num As Integer = 0
					Dim num2 As Integer = Me.dgvDataDetail.Rows.Count - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						mdlVariable.garrStrCombo(num3).strMAHH = Me.dgvDataDetail.Rows(num3).Cells("MAHH").Value.ToString().Trim()
						mdlVariable.garrStrCombo(num3).strTENHH = Me.dgvDataDetail.Rows(num3).Cells("TENHH").Value.ToString().Trim()
						mdlVariable.garrStrCombo(num3).strMADVT = Me.dgvDataDetail.Rows(num3).Cells("MADVT").Value.ToString().Trim()
						mdlVariable.garrStrCombo(num3).strTENDVT = Me.dgvDataDetail.Rows(num3).Cells("DVT").Value.ToString().Trim()
						mdlVariable.garrStrCombo(num3).strHANDUNG = Me.dgvDataDetail.Rows(num3).Cells("HANDUNG").Value.ToString()
						mdlVariable.garrStrCombo(num3).dblQTY = Conversion.Val(Strings.Replace(Me.dgvDataDetail.Rows(num3).Cells("QTY").Value.ToString(), ",", "", 1, -1, CompareMethod.Binary))
						mdlVariable.garrStrCombo(num3).dblPRICE = Conversion.Val(Strings.Replace(Me.dgvDataDetail.Rows(num3).Cells("DONGIA").Value.ToString(), ",", "", 1, -1, CompareMethod.Binary))
						num3 += 1
					End While
					mdlVariable.gfrmSaleMode.gstr_Sal_MADV = Me.txtMaDV.Text.Trim()
					mdlFile.gfWriteLogFile("Nhấn nút chọn trong lịch sử khách hàng")
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000919 RID: 2329 RVA: 0x0006AB7C File Offset: 0x00068D7C
		Private Sub btnKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDV As frmDMDV1 = New frmDMDV1()
				frmDMDV.pBytOpen_From_Menu = 7
				frmDMDV.ShowDialog()
				Me.txtMaDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJID, "", False) = 0, Me.txtMaDV.Text, frmDMDV.pStrOBJID))
				Me.txtTENDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJNAME, "", False) = 0, Me.txtTENDV.Text, frmDMDV.pStrOBJNAME))
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnKH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600091A RID: 2330 RVA: 0x0006AC80 File Offset: 0x00068E80
		Private Sub txtMaDV_Click(sender As Object, e As EventArgs)
			Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
			frmKeyBoard.ShowDialog()
			Me.txtMaDV.Text = frmKeyBoard.pStrEnterText
		End Sub

		' Token: 0x0600091B RID: 2331 RVA: 0x0006ACB0 File Offset: 0x00068EB0
		Private Sub txtMaDV_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDV Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDV.Columns("OBJID")
					Me.mclsTbDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDV.Rows.Find(Strings.Trim(Me.txtMaDV.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENDV.Text = dataRow("OBJNAME").ToString()
						mdlVariable.gfrmSaleMode.gstr_Sal_MANHOMDV = dataRow("MANHOMDV").ToString().Trim()
						mdlVariable.gfrmSaleMode.gstr_Sal_TENDV = dataRow("OBJNAME").ToString().Trim()
						mdlVariable.gfrmSaleMode.gstr_Sal_DIACHIDV = dataRow("ADDRESS").ToString().Trim()
						mdlVariable.gfrmSaleMode.gstr_Sal_DIENTHOAIDV = dataRow("TEL").ToString().Trim()
						mdlVariable.gfrmSaleMode.gstr_Sal_TAXCODEDV = dataRow("VATCODE").ToString().Trim()
					Else
						Me.txtTENDV.Text = ""
					End If
					flag = Operators.CompareString(Me.txtTENDV.Text, "", False) <> 0
					If flag Then
						mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
						Dim b As Byte = Me.f_GetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						Me.mbdsSource.Filter = "MADV like '" + Me.txtMaDV.Text.Trim() + "'"
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						flag = Me.mbdsSource.Count > 0
						If flag Then
							Dim dataGridViewCellEventArgs As DataGridViewCellEventArgs = New DataGridViewCellEventArgs(0, 0)
							Me.dgvData_RowEnter(RuntimeHelpers.GetObjectValue(sender), dataGridViewCellEventArgs)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMaDV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
			End Try
		End Sub

		' Token: 0x0600091C RID: 2332 RVA: 0x0006AF90 File Offset: 0x00069190
		Private Sub dgvData_RowEnter(sender As Object, e As DataGridViewCellEventArgs)
			Dim flag As Boolean = Me.dgvData.CurrentRow IsNot Nothing AndAlso Me.mbdsSourceDel IsNot Nothing
			If flag Then
				Me.mbdsSourceDel.Filter = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("DOCID ='", Me.dgvData.SelectedRows(0).Cells("DOCID").Value), ""), "'"))
				Me.dgvDataDetail.DataSource = Me.mbdsSourceDel
				Me.fInitGrid_Del()
			End If
		End Sub

		' Token: 0x0600091D RID: 2333 RVA: 0x0006B02C File Offset: 0x0006922C
		Private Sub dgvData_Sorted(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.mbdsSource.Count > 0
			If flag Then
				Dim dataGridViewCellEventArgs As DataGridViewCellEventArgs = New DataGridViewCellEventArgs(0, Me.mbdsSource.Position)
				Me.dgvData_RowEnter(RuntimeHelpers.GetObjectValue(sender), dataGridViewCellEventArgs)
			End If
		End Sub

		' Token: 0x0600091E RID: 2334 RVA: 0x0006B070 File Offset: 0x00069270
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				Dim text As String = Conversions.ToString(Interaction.IIf(mdlVariable.gblnLSHOWSOHDTT, "SOTT", "SOCT"))
				dgvData.Columns(text).HeaderText = Conversions.ToString(Interaction.IIf(mdlVariable.gblnLSHOWSOHDTT, Me.mArrStrFrmMess(100).Trim(), Me.mArrStrFrmMess(18).Trim()))
				dgvData.Columns(text).Width = 130
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns(text).DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NGAYKT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(97))
				dgvData.Columns("NGAYKT").Width = 85
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("NGAYKT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("GIOKT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(98))
				dgvData.Columns("GIOKT").Width = 65
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("GIOKT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("THANHTOANBILL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(90))
				dgvData.Columns("THANHTOANBILL").Width = 110
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("THANHTOANBILL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENDV").Visible = False
				dgvData.Columns("MADV").Visible = False
				dgvData.Columns("DOCID").Visible = False
				NewLateBinding.LateSetComplex(NewLateBinding.LateGet(dgvData.Columns, Nothing, "Item", New Object() { RuntimeHelpers.GetObjectValue(Interaction.IIf(mdlVariable.gblnLSHOWSOHDTT, "SOCT", "SOTT")) }, Nothing, Nothing, Nothing), Nothing, "Visible", New Object() { False }, Nothing, Nothing, False, True)
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600091F RID: 2335 RVA: 0x0006B3F0 File Offset: 0x000695F0
		Private Function fInitGrid_Del() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvDataDetail As DataGridView = Me.dgvDataDetail
				dgvDataDetail.MultiSelect = False
				dgvDataDetail.RowHeadersVisible = False
				dgvDataDetail.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvDataDetail.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvDataDetail.Columns("TENHH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvDataDetail.Columns("TENHH").Width = dgvDataDetail.Width - 195
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvDataDetail.Columns("TENHH").DefaultCellStyle = dataGridViewCellStyle
				dgvDataDetail.Columns("QTY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(21))
				dgvDataDetail.Columns("QTY").Width = 40
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvDataDetail.Columns("QTY").DefaultCellStyle = dataGridViewCellStyle
				dgvDataDetail.Columns("DONGIA").HeaderText = Strings.Trim(Me.mArrStrFrmMess(31))
				dgvDataDetail.Columns("DONGIA").Width = 70
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvDataDetail.Columns("DONGIA").DefaultCellStyle = dataGridViewCellStyle
				dgvDataDetail.Columns("THANHTIEN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvDataDetail.Columns("THANHTIEN").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvDataDetail.Columns("THANHTIEN").DefaultCellStyle = dataGridViewCellStyle
				dgvDataDetail.Columns("DVT").Visible = False
				dgvDataDetail.Columns("DOCID").Visible = False
				dgvDataDetail.Columns("MAHH").Visible = False
				dgvDataDetail.Columns("MADVT").Visible = False
				dgvDataDetail.Columns("HANDUNG").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000920 RID: 2336 RVA: 0x0006B714 File Offset: 0x00069914
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnSelect.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000921 RID: 2337 RVA: 0x0006B80C File Offset: 0x00069A0C
		Private Function f_GetData_4Grid() As Byte
			Dim clsMyDataset As clsMyDataset = New clsMyDataset()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchKH"
				array(0).Value = mdlVariable.gStrStockCode
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMADV"
				array(1).Value = Me.txtMaDV.Text.Trim()
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcRet"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim num As Integer
				clsMyDataset = New clsMyDataset(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCUSORDER_GET_DATA_REPORT", num)
				Dim flag As Boolean = Conversions.ToDouble(Me.txtMaDV.Text.Trim()) > 0.0
				If flag Then
					mdlFile.gfWriteLogFile("Lọc lịch sử khách hàng theo KH: " + Me.txtMaDV.Text.Trim() + "-" + Me.txtTENDV.Text.Trim())
				End If
				flag = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsMyDataset.Tables(1)
					Me.mbdsSourceDel.DataSource = clsMyDataset.Tables(0)
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - f_GetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsMyDataset.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000922 RID: 2338 RVA: 0x0006BA24 File Offset: 0x00069C24
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000923 RID: 2339 RVA: 0x0006BAD8 File Offset: 0x00069CD8
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim text As String = Strings.Trim(mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMKH", "OBJID", mdlVariable.gStrStockCode, "OBJNAME"))
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, String.Concat(New String() { Me.mArrStrFrmMess(2), " [", Strings.Mid(mdlVariable.gStrSelectMonth, 5, 2), "/", Strings.Mid(mdlVariable.gStrSelectMonth, 1, 4), " ] ", Me.mArrStrFrmMess(22), " [", text, "]" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000924 RID: 2340 RVA: 0x0006BC98 File Offset: 0x00069E98
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000925 RID: 2341 RVA: 0x0006BD44 File Offset: 0x00069F44
		Private Function fGetData_DMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMDV")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x040003E3 RID: 995
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040003E5 RID: 997
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x040003E6 RID: 998
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x040003E7 RID: 999
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x040003E8 RID: 1000
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040003E9 RID: 1001
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x040003EA RID: 1002
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x040003EB RID: 1003
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x040003EC RID: 1004
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040003ED RID: 1005
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040003EE RID: 1006
		<AccessedThroughProperty("lblFilterDate")>
		Private _lblFilterDate As Label

		' Token: 0x040003EF RID: 1007
		<AccessedThroughProperty("dgvDataDetail")>
		Private _dgvDataDetail As DataGridView

		' Token: 0x040003F0 RID: 1008
		<AccessedThroughProperty("txtMaDV")>
		Private _txtMaDV As TextBox

		' Token: 0x040003F1 RID: 1009
		<AccessedThroughProperty("btnKH")>
		Private _btnKH As Button

		' Token: 0x040003F2 RID: 1010
		<AccessedThroughProperty("txtTENDV")>
		Private _txtTENDV As TextBox

		' Token: 0x040003F3 RID: 1011
		Private mArrStrFrmMess As String()

		' Token: 0x040003F4 RID: 1012
		Private mStrSOCT As String

		' Token: 0x040003F5 RID: 1013
		Private mStrNGAYGS As String

		' Token: 0x040003F6 RID: 1014
		Private mStrNGAYCT As String

		' Token: 0x040003F7 RID: 1015
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040003F8 RID: 1016
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040003F9 RID: 1017
		Private marrDrFind As DataRow()

		' Token: 0x040003FA RID: 1018
		Private mintFindLastPos As Integer

		' Token: 0x040003FB RID: 1019
		Private mblnAutoAdd As Boolean

		' Token: 0x040003FC RID: 1020
		Private mbytLen_OBJID As Byte

		' Token: 0x040003FD RID: 1021
		Private mclsTbDMKH As clsConnect

		' Token: 0x040003FE RID: 1022
		Private mclsTbDV As clsConnect

		' Token: 0x040003FF RID: 1023
		<AccessedThroughProperty("mbdsSourceDel")>
		Private _mbdsSourceDel As BindingSource
	End Class
End Namespace
