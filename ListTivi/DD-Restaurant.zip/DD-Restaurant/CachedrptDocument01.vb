﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200018E RID: 398
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptDocument01
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005BDE RID: 23518 RVA: 0x0001021D File Offset: 0x0000E41D
		Public Sub New()
			CachedrptDocument01.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170021C7 RID: 8647
		' (get) Token: 0x06005BDF RID: 23519 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005BE0 RID: 23520 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170021C8 RID: 8648
		' (get) Token: 0x06005BE1 RID: 23521 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005BE2 RID: 23522 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170021C9 RID: 8649
		' (get) Token: 0x06005BE3 RID: 23523 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005BE4 RID: 23524 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005BE5 RID: 23525 RVA: 0x004DBD20 File Offset: 0x004D9F20
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptDocument01() With { .Site = Me.Site }
		End Function

		' Token: 0x06005BE6 RID: 23526 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002786 RID: 10118
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
