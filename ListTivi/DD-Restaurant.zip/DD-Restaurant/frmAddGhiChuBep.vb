﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000017 RID: 23
	<DesignerGenerated()>
	Public Partial Class frmAddGhiChuBep
		Inherits Form

		' Token: 0x060002DD RID: 733 RVA: 0x00024074 File Offset: 0x00022274
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmAddGhiChuBep_Load
			frmAddGhiChuBep.__ENCList.Add(New WeakReference(Me))
			Me.mstrTEXT = ""
			Me.mblnOK = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000120 RID: 288
		' (get) Token: 0x060002E0 RID: 736 RVA: 0x000246A0 File Offset: 0x000228A0
		' (set) Token: 0x060002E1 RID: 737 RVA: 0x000027D2 File Offset: 0x000009D2
		Friend Overridable Property txtMa As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMa
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtMa = value
			End Set
		End Property

		' Token: 0x17000121 RID: 289
		' (get) Token: 0x060002E2 RID: 738 RVA: 0x000246B8 File Offset: 0x000228B8
		' (set) Token: 0x060002E3 RID: 739 RVA: 0x000246D0 File Offset: 0x000228D0
		Friend Overridable Property btnKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKH.Click, AddressOf Me.btnKH_Click
				End If
				Me._btnKH = value
				flag = Me._btnKH IsNot Nothing
				If flag Then
					AddHandler Me._btnKH.Click, AddressOf Me.btnKH_Click
				End If
			End Set
		End Property

		' Token: 0x17000122 RID: 290
		' (get) Token: 0x060002E4 RID: 740 RVA: 0x0002473C File Offset: 0x0002293C
		' (set) Token: 0x060002E5 RID: 741 RVA: 0x000027DC File Offset: 0x000009DC
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000123 RID: 291
		' (get) Token: 0x060002E6 RID: 742 RVA: 0x00024754 File Offset: 0x00022954
		' (set) Token: 0x060002E7 RID: 743 RVA: 0x0002476C File Offset: 0x0002296C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000124 RID: 292
		' (get) Token: 0x060002E8 RID: 744 RVA: 0x000247D8 File Offset: 0x000229D8
		' (set) Token: 0x060002E9 RID: 745 RVA: 0x000247F0 File Offset: 0x000229F0
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000125 RID: 293
		' (get) Token: 0x060002EA RID: 746 RVA: 0x0002485C File Offset: 0x00022A5C
		' (set) Token: 0x060002EB RID: 747 RVA: 0x000027E6 File Offset: 0x000009E6
		Public Property pblnOK As Boolean
			Get
				Return Me.mblnOK
			End Get
			Set(value As Boolean)
				Me.mblnOK = value
			End Set
		End Property

		' Token: 0x17000126 RID: 294
		' (get) Token: 0x060002EC RID: 748 RVA: 0x00024874 File Offset: 0x00022A74
		' (set) Token: 0x060002ED RID: 749 RVA: 0x000027F1 File Offset: 0x000009F1
		Public Property pStrEnterText As String
			Get
				Return Me.mstrTEXT
			End Get
			Set(value As String)
				Me.mstrTEXT = value
			End Set
		End Property

		' Token: 0x060002EE RID: 750 RVA: 0x0002488C File Offset: 0x00022A8C
		Private Sub frmAddGhiChuBep_Load(sender As Object, e As EventArgs)
			Dim b As Byte = Me.fInitCaption()
		End Sub

		' Token: 0x060002EF RID: 751 RVA: 0x000248A4 File Offset: 0x00022AA4
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(0), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060002F0 RID: 752 RVA: 0x000249B0 File Offset: 0x00022BB0
		Private Function CheckIfRunning() As Boolean
			Me.p = Process.GetProcessesByName("MyKey")
			Return Me.p.Length > 0
		End Function

		' Token: 0x060002F1 RID: 753 RVA: 0x000249EC File Offset: 0x00022BEC
		Private Sub btnKH_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				Me.txtMa.Focus()
				Me.txtMa.SelectAll()
			End If
		End Sub

		' Token: 0x060002F2 RID: 754 RVA: 0x00024A3C File Offset: 0x00022C3C
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Me.mstrTEXT = Me.txtMa.Text
				Me.mblnOK = True
				Dim flag As Boolean = Me.CheckIfRunning()
				If flag Then
					Me.p(0).Kill()
				End If
				mdlFile.gfWriteLogFile("Nhấn nút OK, chuỗi ghi chú là: " + Me.txtMa.Text)
				Me.Close()
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060002F3 RID: 755 RVA: 0x00024AC4 File Offset: 0x00022CC4
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.mblnOK = False
				Dim flag As Boolean = Me.CheckIfRunning()
				If flag Then
					Me.p(0).Kill()
				End If
				mdlFile.gfWriteLogFile("Nhấn nút Thoát form ghi chú.")
				Me.Close()
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x04000139 RID: 313
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400013B RID: 315
		<AccessedThroughProperty("txtMa")>
		Private _txtMa As TextBox

		' Token: 0x0400013C RID: 316
		<AccessedThroughProperty("btnKH")>
		Private _btnKH As Button

		' Token: 0x0400013D RID: 317
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x0400013E RID: 318
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x0400013F RID: 319
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000140 RID: 320
		Private mArrStrFrmMess As String()

		' Token: 0x04000141 RID: 321
		Private mstrTEXT As String

		' Token: 0x04000142 RID: 322
		Private mblnOK As Boolean

		' Token: 0x04000143 RID: 323
		Private p As Process()
	End Class
End Namespace
