﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020001DC RID: 476
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60504
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005F32 RID: 24370 RVA: 0x00010E9B File Offset: 0x0000F09B
		Public Sub New()
			CachedrptRepBC60504.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002395 RID: 9109
		' (get) Token: 0x06005F33 RID: 24371 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005F34 RID: 24372 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002396 RID: 9110
		' (get) Token: 0x06005F35 RID: 24373 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005F36 RID: 24374 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002397 RID: 9111
		' (get) Token: 0x06005F37 RID: 24375 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005F38 RID: 24376 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005F39 RID: 24377 RVA: 0x004DC6E0 File Offset: 0x004DA8E0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60504() With { .Site = Me.Site }
		End Function

		' Token: 0x06005F3A RID: 24378 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040027D4 RID: 10196
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
