﻿Namespace prjIS_SalesPOS
	' Token: 0x0200004F RID: 79
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMHH2
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060015F6 RID: 5622 RVA: 0x0010FBE0 File Offset: 0x0010DDE0
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060015F7 RID: 5623 RVA: 0x0010FC18 File Offset: 0x0010DE18
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMHH2))
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.lblOBJNAME = New Global.System.Windows.Forms.Label()
			Me.txtOBJNAME = New Global.System.Windows.Forms.TextBox()
			Me.txtOBJID = New Global.System.Windows.Forms.TextBox()
			Me.lblOBJID = New Global.System.Windows.Forms.Label()
			Me.txtMADVT = New Global.System.Windows.Forms.TextBox()
			Me.lblDVT = New Global.System.Windows.Forms.Label()
			Me.lblMANH = New Global.System.Windows.Forms.Label()
			Me.txtMAMT = New Global.System.Windows.Forms.TextBox()
			Me.btnDMMT = New Global.System.Windows.Forms.Button()
			Me.txtTENMT = New Global.System.Windows.Forms.TextBox()
			Me.chkLSAVE = New Global.System.Windows.Forms.CheckBox()
			Me.lblMAMT = New Global.System.Windows.Forms.Label()
			Me.lblLSAVE = New Global.System.Windows.Forms.Label()
			Me.txtMANH = New Global.System.Windows.Forms.TextBox()
			Me.btnDMNH = New Global.System.Windows.Forms.Button()
			Me.txtTENNH = New Global.System.Windows.Forms.TextBox()
			Me.txtREMARK = New Global.System.Windows.Forms.TextBox()
			Me.lblREMARK = New Global.System.Windows.Forms.Label()
			Me.lblSUBOBJNAME = New Global.System.Windows.Forms.Label()
			Me.txtSUBOBJNAME = New Global.System.Windows.Forms.TextBox()
			Me.lblMAPL = New Global.System.Windows.Forms.Label()
			Me.txtTENPL = New Global.System.Windows.Forms.TextBox()
			Me.btnMAPL = New Global.System.Windows.Forms.Button()
			Me.txtMAPL = New Global.System.Windows.Forms.TextBox()
			Me.lblMANSX = New Global.System.Windows.Forms.Label()
			Me.txtTENNSX = New Global.System.Windows.Forms.TextBox()
			Me.btnMANSX = New Global.System.Windows.Forms.Button()
			Me.txtMANSX = New Global.System.Windows.Forms.TextBox()
			Me.lblPRICE = New Global.System.Windows.Forms.Label()
			Me.txtPRICE = New Global.System.Windows.Forms.TextBox()
			Me.lblPRICE2 = New Global.System.Windows.Forms.Label()
			Me.txtPRICE2 = New Global.System.Windows.Forms.TextBox()
			Me.lblPRICE3 = New Global.System.Windows.Forms.Label()
			Me.txtPRICE3 = New Global.System.Windows.Forms.TextBox()
			Me.lblPRICE6 = New Global.System.Windows.Forms.Label()
			Me.txtPRICE6 = New Global.System.Windows.Forms.TextBox()
			Me.lblPRICE5 = New Global.System.Windows.Forms.Label()
			Me.txtPRICE5 = New Global.System.Windows.Forms.TextBox()
			Me.lblPRICE4 = New Global.System.Windows.Forms.Label()
			Me.txtPRICE4 = New Global.System.Windows.Forms.TextBox()
			Me.lblPRICE9 = New Global.System.Windows.Forms.Label()
			Me.txtPRICE9 = New Global.System.Windows.Forms.TextBox()
			Me.lblPRICE8 = New Global.System.Windows.Forms.Label()
			Me.txtPRICE8 = New Global.System.Windows.Forms.TextBox()
			Me.lblPRICE7 = New Global.System.Windows.Forms.Label()
			Me.txtPRICE7 = New Global.System.Windows.Forms.TextBox()
			Me.lblPRICE10 = New Global.System.Windows.Forms.Label()
			Me.txtPRICE10 = New Global.System.Windows.Forms.TextBox()
			Me.panMain = New Global.System.Windows.Forms.Panel()
			Me.txtMADVTDG = New Global.System.Windows.Forms.TextBox()
			Me.txtTENDVTDG = New Global.System.Windows.Forms.TextBox()
			Me.btnDVTDG = New Global.System.Windows.Forms.Button()
			Me.lblDVTDG = New Global.System.Windows.Forms.Label()
			Me.btnTen = New Global.System.Windows.Forms.Button()
			Me.txtMADV = New Global.System.Windows.Forms.TextBox()
			Me.txtTENDVT = New Global.System.Windows.Forms.TextBox()
			Me.txtTENDV = New Global.System.Windows.Forms.TextBox()
			Me.btnDVT = New Global.System.Windows.Forms.Button()
			Me.btnDMDV = New Global.System.Windows.Forms.Button()
			Me.lblMADV = New Global.System.Windows.Forms.Label()
			Me.txtBuocNhayMa = New Global.System.Windows.Forms.TextBox()
			Me.txtOBJID_2 = New Global.System.Windows.Forms.TextBox()
			Me.lblBuocNhayMa = New Global.System.Windows.Forms.Label()
			Me.lblOBJID_2 = New Global.System.Windows.Forms.Label()
			Me.panMAMT = New Global.System.Windows.Forms.Panel()
			Me.panMAPL_MANSX = New Global.System.Windows.Forms.Panel()
			Me.panLMATERIAL = New Global.System.Windows.Forms.Panel()
			Me.lblMADC = New Global.System.Windows.Forms.Label()
			Me.txtMADC = New Global.System.Windows.Forms.TextBox()
			Me.btnMADC = New Global.System.Windows.Forms.Button()
			Me.txtTENDC = New Global.System.Windows.Forms.TextBox()
			Me.panPRICE = New Global.System.Windows.Forms.Panel()
			Me.Label7 = New Global.System.Windows.Forms.Label()
			Me.txtPURSE = New Global.System.Windows.Forms.TextBox()
			Me.btnGia1 = New Global.System.Windows.Forms.Button()
			Me.panPRICE2_3_4 = New Global.System.Windows.Forms.Panel()
			Me.panPRICE5_6_7 = New Global.System.Windows.Forms.Panel()
			Me.panPRICE8_9_10 = New Global.System.Windows.Forms.Panel()
			Me.chkLMATERIAL = New Global.System.Windows.Forms.CheckBox()
			Me.lblLMATERIAL = New Global.System.Windows.Forms.Label()
			Me.panLSALE = New Global.System.Windows.Forms.Panel()
			Me.Label21 = New Global.System.Windows.Forms.Label()
			Me.chkLSerial = New Global.System.Windows.Forms.CheckBox()
			Me.Label9 = New Global.System.Windows.Forms.Label()
			Me.chkLTON_KHACHHANG = New Global.System.Windows.Forms.CheckBox()
			Me.Label12 = New Global.System.Windows.Forms.Label()
			Me.chkLComboPrice = New Global.System.Windows.Forms.CheckBox()
			Me.Label20 = New Global.System.Windows.Forms.Label()
			Me.chkLAmtOpen = New Global.System.Windows.Forms.CheckBox()
			Me.Label19 = New Global.System.Windows.Forms.Label()
			Me.chkLQTYMain = New Global.System.Windows.Forms.CheckBox()
			Me.Label8 = New Global.System.Windows.Forms.Label()
			Me.chkLSETCOMBO = New Global.System.Windows.Forms.CheckBox()
			Me.txtPhieu = New Global.System.Windows.Forms.TextBox()
			Me.txtCOMBO = New Global.System.Windows.Forms.TextBox()
			Me.btnPhieu = New Global.System.Windows.Forms.Button()
			Me.btnCOMBO = New Global.System.Windows.Forms.Button()
			Me.Label10 = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.chkCOMBO = New Global.System.Windows.Forms.CheckBox()
			Me.chkStopUse = New Global.System.Windows.Forms.CheckBox()
			Me.lblStop = New Global.System.Windows.Forms.Label()
			Me.chkLopen = New Global.System.Windows.Forms.CheckBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.panButton = New Global.System.Windows.Forms.Panel()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.picAnh = New Global.System.Windows.Forms.PictureBox()
			Me.panREMARK = New Global.System.Windows.Forms.Panel()
			Me.lblbep6 = New Global.System.Windows.Forms.Label()
			Me.lblbep5 = New Global.System.Windows.Forms.Label()
			Me.txtbep6 = New Global.System.Windows.Forms.TextBox()
			Me.lblbep3 = New Global.System.Windows.Forms.Label()
			Me.btnDMBEP6 = New Global.System.Windows.Forms.Button()
			Me.txtbep5 = New Global.System.Windows.Forms.TextBox()
			Me.btnDMBEP5 = New Global.System.Windows.Forms.Button()
			Me.txtTENBEP6 = New Global.System.Windows.Forms.TextBox()
			Me.txtbep3 = New Global.System.Windows.Forms.TextBox()
			Me.txtTENBEP5 = New Global.System.Windows.Forms.TextBox()
			Me.btnDMBEP3 = New Global.System.Windows.Forms.Button()
			Me.lblbep4 = New Global.System.Windows.Forms.Label()
			Me.txtTENBEP3 = New Global.System.Windows.Forms.TextBox()
			Me.txtbep4 = New Global.System.Windows.Forms.TextBox()
			Me.lblbep2 = New Global.System.Windows.Forms.Label()
			Me.btnDMBEP4 = New Global.System.Windows.Forms.Button()
			Me.txtbep2 = New Global.System.Windows.Forms.TextBox()
			Me.txtTENBEP4 = New Global.System.Windows.Forms.TextBox()
			Me.btnDMBEP2 = New Global.System.Windows.Forms.Button()
			Me.txtTENBEP2 = New Global.System.Windows.Forms.TextBox()
			Me.lblbep1 = New Global.System.Windows.Forms.Label()
			Me.txtbep1 = New Global.System.Windows.Forms.TextBox()
			Me.btnDMBEP1 = New Global.System.Windows.Forms.Button()
			Me.txtTENBEP1 = New Global.System.Windows.Forms.TextBox()
			Me.grbTONKHO = New Global.System.Windows.Forms.GroupBox()
			Me.Label11 = New Global.System.Windows.Forms.Label()
			Me.mtbOutDate = New Global.System.Windows.Forms.MaskedTextBox()
			Me.lblOUTDATE = New Global.System.Windows.Forms.Label()
			Me.Label6 = New Global.System.Windows.Forms.Label()
			Me.txtTT = New Global.System.Windows.Forms.TextBox()
			Me.Label5 = New Global.System.Windows.Forms.Label()
			Me.txtDG = New Global.System.Windows.Forms.TextBox()
			Me.Label4 = New Global.System.Windows.Forms.Label()
			Me.txtSL = New Global.System.Windows.Forms.TextBox()
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.txtMAKH = New Global.System.Windows.Forms.TextBox()
			Me.btnDMKH = New Global.System.Windows.Forms.Button()
			Me.txtTENKH = New Global.System.Windows.Forms.TextBox()
			Me.picZoom = New Global.System.Windows.Forms.PictureBox()
			Me.txtBuocNhayGia = New Global.System.Windows.Forms.TextBox()
			Me.lblBuocNhayGia = New Global.System.Windows.Forms.Label()
			Me.GroupBox2 = New Global.System.Windows.Forms.GroupBox()
			Me.txtTiLeDVT = New Global.System.Windows.Forms.TextBox()
			Me.lblTiLeDVT = New Global.System.Windows.Forms.Label()
			Me.GroupBox1 = New Global.System.Windows.Forms.GroupBox()
			Me.Label13 = New Global.System.Windows.Forms.Label()
			Me.txtTHOIKHOANG = New Global.System.Windows.Forms.TextBox()
			Me.Label16 = New Global.System.Windows.Forms.Label()
			Me.Label14 = New Global.System.Windows.Forms.Label()
			Me.txtTienHoaHong = New Global.System.Windows.Forms.TextBox()
			Me.txtHOAHONG = New Global.System.Windows.Forms.TextBox()
			Me.Label15 = New Global.System.Windows.Forms.Label()
			Me.GroupBox3 = New Global.System.Windows.Forms.GroupBox()
			Me.Label17 = New Global.System.Windows.Forms.Label()
			Me.txtScore = New Global.System.Windows.Forms.TextBox()
			Me.panMAMT2 = New Global.System.Windows.Forms.Panel()
			Me.txtMAMT2 = New Global.System.Windows.Forms.TextBox()
			Me.txtTENMT2 = New Global.System.Windows.Forms.TextBox()
			Me.btnDMMT2 = New Global.System.Windows.Forms.Button()
			Me.Label18 = New Global.System.Windows.Forms.Label()
			Me.chkLQtyLe = New Global.System.Windows.Forms.CheckBox()
			Me.Label22 = New Global.System.Windows.Forms.Label()
			Me.panMain.SuspendLayout()
			Me.panMAMT.SuspendLayout()
			Me.panMAPL_MANSX.SuspendLayout()
			Me.panLMATERIAL.SuspendLayout()
			Me.panPRICE.SuspendLayout()
			Me.panPRICE2_3_4.SuspendLayout()
			Me.panPRICE5_6_7.SuspendLayout()
			Me.panPRICE8_9_10.SuspendLayout()
			Me.panLSALE.SuspendLayout()
			Me.panButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			CType(Me.picAnh, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.panREMARK.SuspendLayout()
			Me.grbTONKHO.SuspendLayout()
			CType(Me.picZoom, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.GroupBox2.SuspendLayout()
			Me.GroupBox1.SuspendLayout()
			Me.GroupBox3.SuspendLayout()
			Me.panMAMT2.SuspendLayout()
			Me.SuspendLayout()
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(3, 387)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(113, 76)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 32
			Me.btnFilter.Tag = "CR0005"
			Me.btnFilter.Text = "Lọ&c"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 551)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(113, 77)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 34
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 223)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(113, 76)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 30
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 469)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(113, 76)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 33
			Me.btnFind.Tag = "CR0006"
			Me.btnFind.Text = "&Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 305)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(113, 76)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 31
			Me.btnDelete.Tag = "CR0004"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.lblOBJNAME.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJNAME As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			point = New Global.System.Drawing.Point(7, 27)
			lblOBJNAME.Location = point
			Me.lblOBJNAME.Name = "lblOBJNAME"
			Dim lblOBJNAME2 As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			size = New Global.System.Drawing.Size(129, 21)
			lblOBJNAME2.Size = size
			Me.lblOBJNAME.TabIndex = 34
			Me.lblOBJNAME.Tag = "CR0008"
			Me.lblOBJNAME.Text = "Tên "
			Me.txtOBJNAME.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJNAME As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			point = New Global.System.Drawing.Point(162, 26)
			txtOBJNAME.Location = point
			Me.txtOBJNAME.Name = "txtOBJNAME"
			Dim txtOBJNAME2 As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			size = New Global.System.Drawing.Size(338, 22)
			txtOBJNAME2.Size = size
			Me.txtOBJNAME.TabIndex = 1
			Me.txtOBJNAME.Tag = "0R0000"
			Me.txtOBJID.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJID As Global.System.Windows.Forms.Control = Me.txtOBJID
			point = New Global.System.Drawing.Point(162, 3)
			txtOBJID.Location = point
			Me.txtOBJID.Name = "txtOBJID"
			Dim txtOBJID2 As Global.System.Windows.Forms.Control = Me.txtOBJID
			size = New Global.System.Drawing.Size(122, 22)
			txtOBJID2.Size = size
			Me.txtOBJID.TabIndex = 0
			Me.txtOBJID.Tag = "0R0000"
			Me.lblOBJID.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJID As Global.System.Windows.Forms.Control = Me.lblOBJID
			point = New Global.System.Drawing.Point(7, 4)
			lblOBJID.Location = point
			Me.lblOBJID.Name = "lblOBJID"
			Dim lblOBJID2 As Global.System.Windows.Forms.Control = Me.lblOBJID
			size = New Global.System.Drawing.Size(129, 21)
			lblOBJID2.Size = size
			Me.lblOBJID.TabIndex = 33
			Me.lblOBJID.Tag = "CR0007"
			Me.lblOBJID.Text = "Mã"
			Me.txtMADVT.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMADVT As Global.System.Windows.Forms.Control = Me.txtMADVT
			point = New Global.System.Drawing.Point(162, 72)
			txtMADVT.Location = point
			Me.txtMADVT.Name = "txtMADVT"
			Dim txtMADVT2 As Global.System.Windows.Forms.Control = Me.txtMADVT
			size = New Global.System.Drawing.Size(122, 22)
			txtMADVT2.Size = size
			Me.txtMADVT.TabIndex = 3
			Me.txtMADVT.Tag = "0R0000"
			Me.lblDVT.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblDVT As Global.System.Windows.Forms.Control = Me.lblDVT
			point = New Global.System.Drawing.Point(7, 74)
			lblDVT.Location = point
			Me.lblDVT.Name = "lblDVT"
			Dim lblDVT2 As Global.System.Windows.Forms.Control = Me.lblDVT
			size = New Global.System.Drawing.Size(129, 21)
			lblDVT2.Size = size
			Me.lblDVT.TabIndex = 39
			Me.lblDVT.Tag = "CR0031"
			Me.lblDVT.Text = "Đơn vị tính"
			Me.lblMANH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMANH As Global.System.Windows.Forms.Control = Me.lblMANH
			point = New Global.System.Drawing.Point(7, 143)
			lblMANH.Location = point
			Me.lblMANH.Name = "lblMANH"
			Dim lblMANH2 As Global.System.Windows.Forms.Control = Me.lblMANH
			size = New Global.System.Drawing.Size(134, 21)
			lblMANH2.Size = size
			Me.lblMANH.TabIndex = 40
			Me.lblMANH.Tag = "CR0032"
			Me.lblMANH.Text = "Mã nhóm hàng"
			Me.txtMAMT.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAMT As Global.System.Windows.Forms.Control = Me.txtMAMT
			point = New Global.System.Drawing.Point(162, 1)
			txtMAMT.Location = point
			Me.txtMAMT.Name = "txtMAMT"
			Dim txtMAMT2 As Global.System.Windows.Forms.Control = Me.txtMAMT
			size = New Global.System.Drawing.Size(122, 22)
			txtMAMT2.Size = size
			Me.txtMAMT.TabIndex = 0
			Me.txtMAMT.Tag = "0R0000"
			Me.btnDMMT.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMMT As Global.System.Windows.Forms.Control = Me.btnDMMT
			point = New Global.System.Drawing.Point(290, 1)
			btnDMMT.Location = point
			Me.btnDMMT.Name = "btnDMMT"
			Dim btnDMMT2 As Global.System.Windows.Forms.Control = Me.btnDMMT
			size = New Global.System.Drawing.Size(45, 22)
			btnDMMT2.Size = size
			Me.btnDMMT.TabIndex = 8
			Me.btnDMMT.Tag = "CB0011"
			Me.btnDMMT.UseVisualStyleBackColor = True
			Me.txtTENMT.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENMT As Global.System.Windows.Forms.Control = Me.txtTENMT
			point = New Global.System.Drawing.Point(341, 1)
			txtTENMT.Location = point
			Me.txtTENMT.Name = "txtTENMT"
			Dim txtTENMT2 As Global.System.Windows.Forms.Control = Me.txtTENMT
			size = New Global.System.Drawing.Size(191, 22)
			txtTENMT2.Size = size
			Me.txtTENMT.TabIndex = 100
			Me.txtTENMT.TabStop = False
			Me.txtTENMT.Tag = "0R0000"
			Me.chkLSAVE.AutoSize = True
			Me.chkLSAVE.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkLSAVE As Global.System.Windows.Forms.Control = Me.chkLSAVE
			point = New Global.System.Drawing.Point(71, 7)
			chkLSAVE.Location = point
			Me.chkLSAVE.Name = "chkLSAVE"
			Dim chkLSAVE2 As Global.System.Windows.Forms.Control = Me.chkLSAVE
			size = New Global.System.Drawing.Size(15, 14)
			chkLSAVE2.Size = size
			Me.chkLSAVE.TabIndex = 27
			Me.chkLSAVE.Tag = "0R0000"
			Me.chkLSAVE.UseVisualStyleBackColor = True
			Me.lblMAMT.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAMT As Global.System.Windows.Forms.Control = Me.lblMAMT
			point = New Global.System.Drawing.Point(7, 3)
			lblMAMT.Location = point
			Me.lblMAMT.Name = "lblMAMT"
			Dim lblMAMT2 As Global.System.Windows.Forms.Control = Me.lblMAMT
			size = New Global.System.Drawing.Size(111, 16)
			lblMAMT2.Size = size
			Me.lblMAMT.TabIndex = 39
			Me.lblMAMT.Tag = "CR0033"
			Me.lblMAMT.Text = "Mã mức thuế"
			Me.lblLSAVE.AutoSize = True
			Me.lblLSAVE.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblLSAVE As Global.System.Windows.Forms.Control = Me.lblLSAVE
			point = New Global.System.Drawing.Point(4, 6)
			lblLSAVE.Location = point
			Me.lblLSAVE.Name = "lblLSAVE"
			Dim lblLSAVE2 As Global.System.Windows.Forms.Control = Me.lblLSAVE
			size = New Global.System.Drawing.Size(59, 16)
			lblLSAVE2.Size = size
			Me.lblLSAVE.TabIndex = 40
			Me.lblLSAVE.Tag = "CR0010"
			Me.lblLSAVE.Text = "Tồn kho"
			Me.txtMANH.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMANH As Global.System.Windows.Forms.Control = Me.txtMANH
			point = New Global.System.Drawing.Point(162, 142)
			txtMANH.Location = point
			Me.txtMANH.Name = "txtMANH"
			Dim txtMANH2 As Global.System.Windows.Forms.Control = Me.txtMANH
			size = New Global.System.Drawing.Size(122, 22)
			txtMANH2.Size = size
			Me.txtMANH.TabIndex = 4
			Me.txtMANH.Tag = "0R0000"
			Me.btnDMNH.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMNH As Global.System.Windows.Forms.Control = Me.btnDMNH
			point = New Global.System.Drawing.Point(290, 142)
			btnDMNH.Location = point
			Me.btnDMNH.Name = "btnDMNH"
			Dim btnDMNH2 As Global.System.Windows.Forms.Control = Me.btnDMNH
			size = New Global.System.Drawing.Size(45, 22)
			btnDMNH2.Size = size
			Me.btnDMNH.TabIndex = 6
			Me.btnDMNH.Tag = "CB0011"
			Me.btnDMNH.UseVisualStyleBackColor = True
			Me.txtTENNH.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENNH As Global.System.Windows.Forms.Control = Me.txtTENNH
			point = New Global.System.Drawing.Point(341, 142)
			txtTENNH.Location = point
			Me.txtTENNH.Name = "txtTENNH"
			Dim txtTENNH2 As Global.System.Windows.Forms.Control = Me.txtTENNH
			size = New Global.System.Drawing.Size(191, 22)
			txtTENNH2.Size = size
			Me.txtTENNH.TabIndex = 100
			Me.txtTENNH.TabStop = False
			Me.txtTENNH.Tag = "0R0000"
			Me.txtREMARK.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtREMARK As Global.System.Windows.Forms.Control = Me.txtREMARK
			point = New Global.System.Drawing.Point(135, 75)
			txtREMARK.Location = point
			Me.txtREMARK.Name = "txtREMARK"
			Dim txtREMARK2 As Global.System.Windows.Forms.Control = Me.txtREMARK
			size = New Global.System.Drawing.Size(398, 22)
			txtREMARK2.Size = size
			Me.txtREMARK.TabIndex = 29
			Me.txtREMARK.Tag = "0R0000"
			Me.lblREMARK.AutoSize = True
			Me.lblREMARK.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblREMARK As Global.System.Windows.Forms.Control = Me.lblREMARK
			point = New Global.System.Drawing.Point(3, 78)
			lblREMARK.Location = point
			Me.lblREMARK.Name = "lblREMARK"
			Dim lblREMARK2 As Global.System.Windows.Forms.Control = Me.lblREMARK
			size = New Global.System.Drawing.Size(57, 16)
			lblREMARK2.Size = size
			Me.lblREMARK.TabIndex = 34
			Me.lblREMARK.Tag = "CR0034"
			Me.lblREMARK.Text = "Ghi chú"
			Me.lblSUBOBJNAME.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblSUBOBJNAME As Global.System.Windows.Forms.Control = Me.lblSUBOBJNAME
			point = New Global.System.Drawing.Point(7, 50)
			lblSUBOBJNAME.Location = point
			Me.lblSUBOBJNAME.Name = "lblSUBOBJNAME"
			Dim lblSUBOBJNAME2 As Global.System.Windows.Forms.Control = Me.lblSUBOBJNAME
			size = New Global.System.Drawing.Size(134, 21)
			lblSUBOBJNAME2.Size = size
			Me.lblSUBOBJNAME.TabIndex = 42
			Me.lblSUBOBJNAME.Tag = "CR0038"
			Me.lblSUBOBJNAME.Text = "Tên hàng hóa phụ"
			Me.txtSUBOBJNAME.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtSUBOBJNAME As Global.System.Windows.Forms.Control = Me.txtSUBOBJNAME
			point = New Global.System.Drawing.Point(162, 49)
			txtSUBOBJNAME.Location = point
			Me.txtSUBOBJNAME.Name = "txtSUBOBJNAME"
			Dim txtSUBOBJNAME2 As Global.System.Windows.Forms.Control = Me.txtSUBOBJNAME
			size = New Global.System.Drawing.Size(370, 22)
			txtSUBOBJNAME2.Size = size
			Me.txtSUBOBJNAME.TabIndex = 2
			Me.txtSUBOBJNAME.Tag = "0R0000"
			Me.lblMAPL.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAPL As Global.System.Windows.Forms.Control = Me.lblMAPL
			point = New Global.System.Drawing.Point(7, 1)
			lblMAPL.Location = point
			Me.lblMAPL.Name = "lblMAPL"
			Dim lblMAPL2 As Global.System.Windows.Forms.Control = Me.lblMAPL
			size = New Global.System.Drawing.Size(129, 21)
			lblMAPL2.Size = size
			Me.lblMAPL.TabIndex = 46
			Me.lblMAPL.Tag = "CR0039"
			Me.lblMAPL.Text = "Mã phân loại"
			Me.txtTENPL.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENPL As Global.System.Windows.Forms.Control = Me.txtTENPL
			point = New Global.System.Drawing.Point(341, 1)
			txtTENPL.Location = point
			Me.txtTENPL.Name = "txtTENPL"
			Dim txtTENPL2 As Global.System.Windows.Forms.Control = Me.txtTENPL
			size = New Global.System.Drawing.Size(191, 22)
			txtTENPL2.Size = size
			Me.txtTENPL.TabIndex = 100
			Me.txtTENPL.TabStop = False
			Me.txtTENPL.Tag = "0R0000"
			Me.btnMAPL.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnMAPL As Global.System.Windows.Forms.Control = Me.btnMAPL
			point = New Global.System.Drawing.Point(290, 1)
			btnMAPL.Location = point
			Me.btnMAPL.Name = "btnMAPL"
			Dim btnMAPL2 As Global.System.Windows.Forms.Control = Me.btnMAPL
			size = New Global.System.Drawing.Size(45, 22)
			btnMAPL2.Size = size
			Me.btnMAPL.TabIndex = 10
			Me.btnMAPL.Tag = "CB0011"
			Me.btnMAPL.UseVisualStyleBackColor = True
			Me.txtMAPL.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAPL As Global.System.Windows.Forms.Control = Me.txtMAPL
			point = New Global.System.Drawing.Point(162, 1)
			txtMAPL.Location = point
			Me.txtMAPL.Name = "txtMAPL"
			Dim txtMAPL2 As Global.System.Windows.Forms.Control = Me.txtMAPL
			size = New Global.System.Drawing.Size(122, 22)
			txtMAPL2.Size = size
			Me.txtMAPL.TabIndex = 9
			Me.txtMAPL.Tag = "0R0000"
			Me.lblMANSX.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMANSX As Global.System.Windows.Forms.Control = Me.lblMANSX
			point = New Global.System.Drawing.Point(7, 24)
			lblMANSX.Location = point
			Me.lblMANSX.Name = "lblMANSX"
			Dim lblMANSX2 As Global.System.Windows.Forms.Control = Me.lblMANSX
			size = New Global.System.Drawing.Size(134, 21)
			lblMANSX2.Size = size
			Me.lblMANSX.TabIndex = 50
			Me.lblMANSX.Tag = "CR0040"
			Me.lblMANSX.Text = "Mã nước sản xuất"
			Me.txtTENNSX.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENNSX As Global.System.Windows.Forms.Control = Me.txtTENNSX
			point = New Global.System.Drawing.Point(340, 24)
			txtTENNSX.Location = point
			Me.txtTENNSX.Name = "txtTENNSX"
			Dim txtTENNSX2 As Global.System.Windows.Forms.Control = Me.txtTENNSX
			size = New Global.System.Drawing.Size(192, 22)
			txtTENNSX2.Size = size
			Me.txtTENNSX.TabIndex = 100
			Me.txtTENNSX.TabStop = False
			Me.txtTENNSX.Tag = "0R0000"
			Me.btnMANSX.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnMANSX As Global.System.Windows.Forms.Control = Me.btnMANSX
			point = New Global.System.Drawing.Point(290, 24)
			btnMANSX.Location = point
			Me.btnMANSX.Name = "btnMANSX"
			Dim btnMANSX2 As Global.System.Windows.Forms.Control = Me.btnMANSX
			size = New Global.System.Drawing.Size(45, 22)
			btnMANSX2.Size = size
			Me.btnMANSX.TabIndex = 12
			Me.btnMANSX.Tag = "CB0011"
			Me.btnMANSX.UseVisualStyleBackColor = True
			Me.txtMANSX.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMANSX As Global.System.Windows.Forms.Control = Me.txtMANSX
			point = New Global.System.Drawing.Point(162, 24)
			txtMANSX.Location = point
			Me.txtMANSX.Name = "txtMANSX"
			Dim txtMANSX2 As Global.System.Windows.Forms.Control = Me.txtMANSX
			size = New Global.System.Drawing.Size(122, 22)
			txtMANSX2.Size = size
			Me.txtMANSX.TabIndex = 11
			Me.txtMANSX.Tag = "0R0000"
			Me.lblPRICE.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPRICE As Global.System.Windows.Forms.Control = Me.lblPRICE
			point = New Global.System.Drawing.Point(6, 3)
			lblPRICE.Location = point
			Me.lblPRICE.Name = "lblPRICE"
			Dim lblPRICE2 As Global.System.Windows.Forms.Control = Me.lblPRICE
			size = New Global.System.Drawing.Size(112, 21)
			lblPRICE2.Size = size
			Me.lblPRICE.TabIndex = 52
			Me.lblPRICE.Tag = "CR0041"
			Me.lblPRICE.Text = "Giá"
			Me.txtPRICE.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPRICE As Global.System.Windows.Forms.Control = Me.txtPRICE
			point = New Global.System.Drawing.Point(162, 2)
			txtPRICE.Location = point
			Me.txtPRICE.Name = "txtPRICE"
			Dim txtPRICE2 As Global.System.Windows.Forms.Control = Me.txtPRICE
			size = New Global.System.Drawing.Size(84, 22)
			txtPRICE2.Size = size
			Me.txtPRICE.TabIndex = 15
			Me.txtPRICE.Tag = "0R0000"
			Me.txtPRICE.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.lblPRICE2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPRICE3 As Global.System.Windows.Forms.Control = Me.lblPRICE2
			point = New Global.System.Drawing.Point(7, 5)
			lblPRICE3.Location = point
			Me.lblPRICE2.Name = "lblPRICE2"
			Dim lblPRICE4 As Global.System.Windows.Forms.Control = Me.lblPRICE2
			size = New Global.System.Drawing.Size(45, 21)
			lblPRICE4.Size = size
			Me.lblPRICE2.TabIndex = 54
			Me.lblPRICE2.Tag = "CR0042"
			Me.lblPRICE2.Text = "Giá 2"
			Me.txtPRICE2.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPRICE3 As Global.System.Windows.Forms.Control = Me.txtPRICE2
			point = New Global.System.Drawing.Point(162, 3)
			txtPRICE3.Location = point
			Me.txtPRICE2.Name = "txtPRICE2"
			Dim txtPRICE4 As Global.System.Windows.Forms.Control = Me.txtPRICE2
			size = New Global.System.Drawing.Size(84, 22)
			txtPRICE4.Size = size
			Me.txtPRICE2.TabIndex = 18
			Me.txtPRICE2.Tag = "0R0000"
			Me.txtPRICE2.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.lblPRICE3.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPRICE5 As Global.System.Windows.Forms.Control = Me.lblPRICE3
			point = New Global.System.Drawing.Point(256, 5)
			lblPRICE5.Location = point
			Me.lblPRICE3.Name = "lblPRICE3"
			Dim lblPRICE6 As Global.System.Windows.Forms.Control = Me.lblPRICE3
			size = New Global.System.Drawing.Size(43, 21)
			lblPRICE6.Size = size
			Me.lblPRICE3.TabIndex = 56
			Me.lblPRICE3.Tag = "CR0043"
			Me.lblPRICE3.Text = "Giá 3"
			Me.txtPRICE3.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPRICE5 As Global.System.Windows.Forms.Control = Me.txtPRICE3
			point = New Global.System.Drawing.Point(310, 3)
			txtPRICE5.Location = point
			Me.txtPRICE3.Name = "txtPRICE3"
			Dim txtPRICE6 As Global.System.Windows.Forms.Control = Me.txtPRICE3
			size = New Global.System.Drawing.Size(84, 22)
			txtPRICE6.Size = size
			Me.txtPRICE3.TabIndex = 19
			Me.txtPRICE3.Tag = "0R0000"
			Me.txtPRICE3.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.lblPRICE6.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPRICE7 As Global.System.Windows.Forms.Control = Me.lblPRICE6
			point = New Global.System.Drawing.Point(256, 6)
			lblPRICE7.Location = point
			Me.lblPRICE6.Name = "lblPRICE6"
			Dim lblPRICE8 As Global.System.Windows.Forms.Control = Me.lblPRICE6
			size = New Global.System.Drawing.Size(43, 21)
			lblPRICE8.Size = size
			Me.lblPRICE6.TabIndex = 62
			Me.lblPRICE6.Tag = "CR0046"
			Me.lblPRICE6.Text = "Giá 6"
			Me.txtPRICE6.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPRICE7 As Global.System.Windows.Forms.Control = Me.txtPRICE6
			point = New Global.System.Drawing.Point(310, 3)
			txtPRICE7.Location = point
			Me.txtPRICE6.Name = "txtPRICE6"
			Dim txtPRICE8 As Global.System.Windows.Forms.Control = Me.txtPRICE6
			size = New Global.System.Drawing.Size(84, 22)
			txtPRICE8.Size = size
			Me.txtPRICE6.TabIndex = 22
			Me.txtPRICE6.Tag = "0R0000"
			Me.txtPRICE6.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.lblPRICE5.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPRICE9 As Global.System.Windows.Forms.Control = Me.lblPRICE5
			point = New Global.System.Drawing.Point(7, 5)
			lblPRICE9.Location = point
			Me.lblPRICE5.Name = "lblPRICE5"
			Dim lblPRICE10 As Global.System.Windows.Forms.Control = Me.lblPRICE5
			size = New Global.System.Drawing.Size(44, 21)
			lblPRICE10.Size = size
			Me.lblPRICE5.TabIndex = 60
			Me.lblPRICE5.Tag = "CR0045"
			Me.lblPRICE5.Text = "Giá 5"
			Me.txtPRICE5.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPRICE9 As Global.System.Windows.Forms.Control = Me.txtPRICE5
			point = New Global.System.Drawing.Point(162, 3)
			txtPRICE9.Location = point
			Me.txtPRICE5.Name = "txtPRICE5"
			Dim txtPRICE10 As Global.System.Windows.Forms.Control = Me.txtPRICE5
			size = New Global.System.Drawing.Size(84, 22)
			txtPRICE10.Size = size
			Me.txtPRICE5.TabIndex = 21
			Me.txtPRICE5.Tag = "0R0000"
			Me.txtPRICE5.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.lblPRICE4.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPRICE11 As Global.System.Windows.Forms.Control = Me.lblPRICE4
			point = New Global.System.Drawing.Point(401, 5)
			lblPRICE11.Location = point
			Me.lblPRICE4.Name = "lblPRICE4"
			Dim lblPRICE12 As Global.System.Windows.Forms.Control = Me.lblPRICE4
			size = New Global.System.Drawing.Size(53, 21)
			lblPRICE12.Size = size
			Me.lblPRICE4.TabIndex = 58
			Me.lblPRICE4.Tag = "CR0044"
			Me.lblPRICE4.Text = "Giá 4"
			Me.txtPRICE4.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPRICE11 As Global.System.Windows.Forms.Control = Me.txtPRICE4
			point = New Global.System.Drawing.Point(448, 3)
			txtPRICE11.Location = point
			Me.txtPRICE4.Name = "txtPRICE4"
			Dim txtPRICE12 As Global.System.Windows.Forms.Control = Me.txtPRICE4
			size = New Global.System.Drawing.Size(84, 22)
			txtPRICE12.Size = size
			Me.txtPRICE4.TabIndex = 20
			Me.txtPRICE4.Tag = "0R0000"
			Me.txtPRICE4.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.lblPRICE9.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPRICE13 As Global.System.Windows.Forms.Control = Me.lblPRICE9
			point = New Global.System.Drawing.Point(256, 6)
			lblPRICE13.Location = point
			Me.lblPRICE9.Name = "lblPRICE9"
			Dim lblPRICE14 As Global.System.Windows.Forms.Control = Me.lblPRICE9
			size = New Global.System.Drawing.Size(43, 20)
			lblPRICE14.Size = size
			Me.lblPRICE9.TabIndex = 68
			Me.lblPRICE9.Tag = "CR0049"
			Me.lblPRICE9.Text = "Giá 9"
			Me.txtPRICE9.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPRICE13 As Global.System.Windows.Forms.Control = Me.txtPRICE9
			point = New Global.System.Drawing.Point(310, 4)
			txtPRICE13.Location = point
			Me.txtPRICE9.Name = "txtPRICE9"
			Dim txtPRICE14 As Global.System.Windows.Forms.Control = Me.txtPRICE9
			size = New Global.System.Drawing.Size(84, 22)
			txtPRICE14.Size = size
			Me.txtPRICE9.TabIndex = 25
			Me.txtPRICE9.Tag = "0R0000"
			Me.txtPRICE9.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.lblPRICE8.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPRICE15 As Global.System.Windows.Forms.Control = Me.lblPRICE8
			point = New Global.System.Drawing.Point(7, 5)
			lblPRICE15.Location = point
			Me.lblPRICE8.Name = "lblPRICE8"
			Dim lblPRICE16 As Global.System.Windows.Forms.Control = Me.lblPRICE8
			size = New Global.System.Drawing.Size(44, 20)
			lblPRICE16.Size = size
			Me.lblPRICE8.TabIndex = 66
			Me.lblPRICE8.Tag = "CR0048"
			Me.lblPRICE8.Text = "Giá 8"
			Me.txtPRICE8.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPRICE15 As Global.System.Windows.Forms.Control = Me.txtPRICE8
			point = New Global.System.Drawing.Point(162, 3)
			txtPRICE15.Location = point
			Me.txtPRICE8.Name = "txtPRICE8"
			Dim txtPRICE16 As Global.System.Windows.Forms.Control = Me.txtPRICE8
			size = New Global.System.Drawing.Size(84, 22)
			txtPRICE16.Size = size
			Me.txtPRICE8.TabIndex = 24
			Me.txtPRICE8.Tag = "0R0000"
			Me.txtPRICE8.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.lblPRICE7.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPRICE17 As Global.System.Windows.Forms.Control = Me.lblPRICE7
			point = New Global.System.Drawing.Point(402, 6)
			lblPRICE17.Location = point
			Me.lblPRICE7.Name = "lblPRICE7"
			Dim lblPRICE18 As Global.System.Windows.Forms.Control = Me.lblPRICE7
			size = New Global.System.Drawing.Size(52, 21)
			lblPRICE18.Size = size
			Me.lblPRICE7.TabIndex = 64
			Me.lblPRICE7.Tag = "CR0047"
			Me.lblPRICE7.Text = "Giá 7"
			Me.txtPRICE7.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPRICE17 As Global.System.Windows.Forms.Control = Me.txtPRICE7
			point = New Global.System.Drawing.Point(448, 3)
			txtPRICE17.Location = point
			Me.txtPRICE7.Name = "txtPRICE7"
			Dim txtPRICE18 As Global.System.Windows.Forms.Control = Me.txtPRICE7
			size = New Global.System.Drawing.Size(84, 22)
			txtPRICE18.Size = size
			Me.txtPRICE7.TabIndex = 23
			Me.txtPRICE7.Tag = "0R0000"
			Me.txtPRICE7.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.lblPRICE10.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPRICE19 As Global.System.Windows.Forms.Control = Me.lblPRICE10
			point = New Global.System.Drawing.Point(402, 5)
			lblPRICE19.Location = point
			Me.lblPRICE10.Name = "lblPRICE10"
			Dim lblPRICE20 As Global.System.Windows.Forms.Control = Me.lblPRICE10
			size = New Global.System.Drawing.Size(58, 21)
			lblPRICE20.Size = size
			Me.lblPRICE10.TabIndex = 70
			Me.lblPRICE10.Tag = "CR0050"
			Me.lblPRICE10.Text = "Giá 10"
			Me.txtPRICE10.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPRICE19 As Global.System.Windows.Forms.Control = Me.txtPRICE10
			point = New Global.System.Drawing.Point(448, 2)
			txtPRICE19.Location = point
			Me.txtPRICE10.Name = "txtPRICE10"
			Dim txtPRICE20 As Global.System.Windows.Forms.Control = Me.txtPRICE10
			size = New Global.System.Drawing.Size(84, 22)
			txtPRICE20.Size = size
			Me.txtPRICE10.TabIndex = 26
			Me.txtPRICE10.Tag = "0R0000"
			Me.txtPRICE10.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.panMain.Controls.Add(Me.txtMADVTDG)
			Me.panMain.Controls.Add(Me.txtTENDVTDG)
			Me.panMain.Controls.Add(Me.btnDVTDG)
			Me.panMain.Controls.Add(Me.lblDVTDG)
			Me.panMain.Controls.Add(Me.btnTen)
			Me.panMain.Controls.Add(Me.txtMADV)
			Me.panMain.Controls.Add(Me.txtTENDVT)
			Me.panMain.Controls.Add(Me.txtTENDV)
			Me.panMain.Controls.Add(Me.btnDVT)
			Me.panMain.Controls.Add(Me.btnDMDV)
			Me.panMain.Controls.Add(Me.lblMADV)
			Me.panMain.Controls.Add(Me.txtBuocNhayMa)
			Me.panMain.Controls.Add(Me.txtOBJID_2)
			Me.panMain.Controls.Add(Me.lblBuocNhayMa)
			Me.panMain.Controls.Add(Me.lblOBJID_2)
			Dim panMain As Global.System.Windows.Forms.Control = Me.panMain
			point = New Global.System.Drawing.Point(0, 0)
			panMain.Location = point
			Me.panMain.Name = "panMain"
			Dim panMain2 As Global.System.Windows.Forms.Control = Me.panMain
			size = New Global.System.Drawing.Size(535, 166)
			panMain2.Size = size
			Me.panMain.TabIndex = 106
			Me.txtMADVTDG.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMADVTDG As Global.System.Windows.Forms.Control = Me.txtMADVTDG
			point = New Global.System.Drawing.Point(162, 96)
			txtMADVTDG.Location = point
			Me.txtMADVTDG.Name = "txtMADVTDG"
			Dim txtMADVTDG2 As Global.System.Windows.Forms.Control = Me.txtMADVTDG
			size = New Global.System.Drawing.Size(122, 22)
			txtMADVTDG2.Size = size
			Me.txtMADVTDG.TabIndex = 128
			Me.txtMADVTDG.Tag = "0R0000"
			Me.txtTENDVTDG.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENDVTDG As Global.System.Windows.Forms.Control = Me.txtTENDVTDG
			point = New Global.System.Drawing.Point(341, 96)
			txtTENDVTDG.Location = point
			Me.txtTENDVTDG.Name = "txtTENDVTDG"
			Dim txtTENDVTDG2 As Global.System.Windows.Forms.Control = Me.txtTENDVTDG
			size = New Global.System.Drawing.Size(191, 22)
			txtTENDVTDG2.Size = size
			Me.txtTENDVTDG.TabIndex = 127
			Me.txtTENDVTDG.TabStop = False
			Me.txtTENDVTDG.Tag = "0R0000"
			Me.btnDVTDG.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDVTDG As Global.System.Windows.Forms.Control = Me.btnDVTDG
			point = New Global.System.Drawing.Point(290, 96)
			btnDVTDG.Location = point
			Me.btnDVTDG.Name = "btnDVTDG"
			Dim btnDVTDG2 As Global.System.Windows.Forms.Control = Me.btnDVTDG
			size = New Global.System.Drawing.Size(45, 22)
			btnDVTDG2.Size = size
			Me.btnDVTDG.TabIndex = 129
			Me.btnDVTDG.Tag = "CB0011"
			Me.btnDVTDG.UseVisualStyleBackColor = True
			Me.lblDVTDG.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblDVTDG As Global.System.Windows.Forms.Control = Me.lblDVTDG
			point = New Global.System.Drawing.Point(7, 99)
			lblDVTDG.Location = point
			Me.lblDVTDG.Name = "lblDVTDG"
			Dim lblDVTDG2 As Global.System.Windows.Forms.Control = Me.lblDVTDG
			size = New Global.System.Drawing.Size(149, 17)
			lblDVTDG2.Size = size
			Me.lblDVTDG.TabIndex = 130
			Me.lblDVTDG.Tag = "CR0107"
			Me.lblDVTDG.Text = "Đơn vị tính đóng gói"
			Dim btnTen As Global.System.Windows.Forms.Control = Me.btnTen
			point = New Global.System.Drawing.Point(502, 26)
			btnTen.Location = point
			Me.btnTen.Name = "btnTen"
			Dim btnTen2 As Global.System.Windows.Forms.Control = Me.btnTen
			size = New Global.System.Drawing.Size(31, 22)
			btnTen2.Size = size
			Me.btnTen.TabIndex = 117
			Me.btnTen.Tag = ""
			Me.btnTen.Text = "..."
			Me.btnTen.UseVisualStyleBackColor = True
			Me.txtMADV.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMADV As Global.System.Windows.Forms.Control = Me.txtMADV
			point = New Global.System.Drawing.Point(162, 119)
			txtMADV.Location = point
			Me.txtMADV.Name = "txtMADV"
			Dim txtMADV2 As Global.System.Windows.Forms.Control = Me.txtMADV
			size = New Global.System.Drawing.Size(122, 22)
			txtMADV2.Size = size
			Me.txtMADV.TabIndex = 1
			Me.txtMADV.Tag = "0R0000"
			Me.txtTENDVT.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENDVT As Global.System.Windows.Forms.Control = Me.txtTENDVT
			point = New Global.System.Drawing.Point(341, 72)
			txtTENDVT.Location = point
			Me.txtTENDVT.Name = "txtTENDVT"
			Dim txtTENDVT2 As Global.System.Windows.Forms.Control = Me.txtTENDVT
			size = New Global.System.Drawing.Size(191, 22)
			txtTENDVT2.Size = size
			Me.txtTENDVT.TabIndex = 0
			Me.txtTENDVT.TabStop = False
			Me.txtTENDVT.Tag = "0R0000"
			Me.txtTENDV.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENDV As Global.System.Windows.Forms.Control = Me.txtTENDV
			point = New Global.System.Drawing.Point(341, 119)
			txtTENDV.Location = point
			Me.txtTENDV.Name = "txtTENDV"
			Dim txtTENDV2 As Global.System.Windows.Forms.Control = Me.txtTENDV
			size = New Global.System.Drawing.Size(191, 22)
			txtTENDV2.Size = size
			Me.txtTENDV.TabIndex = 117
			Me.txtTENDV.TabStop = False
			Me.txtTENDV.Tag = "0R0000"
			Me.btnDVT.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDVT As Global.System.Windows.Forms.Control = Me.btnDVT
			point = New Global.System.Drawing.Point(290, 72)
			btnDVT.Location = point
			Me.btnDVT.Name = "btnDVT"
			Dim btnDVT2 As Global.System.Windows.Forms.Control = Me.btnDVT
			size = New Global.System.Drawing.Size(45, 22)
			btnDVT2.Size = size
			Me.btnDVT.TabIndex = 4
			Me.btnDVT.Tag = "CB0011"
			Me.btnDVT.UseVisualStyleBackColor = True
			Me.btnDMDV.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMDV As Global.System.Windows.Forms.Control = Me.btnDMDV
			point = New Global.System.Drawing.Point(290, 119)
			btnDMDV.Location = point
			Me.btnDMDV.Name = "btnDMDV"
			Dim btnDMDV2 As Global.System.Windows.Forms.Control = Me.btnDMDV
			size = New Global.System.Drawing.Size(45, 22)
			btnDMDV2.Size = size
			Me.btnDMDV.TabIndex = 119
			Me.btnDMDV.Tag = "CB0011"
			Me.btnDMDV.UseVisualStyleBackColor = True
			Me.lblMADV.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMADV As Global.System.Windows.Forms.Control = Me.lblMADV
			point = New Global.System.Drawing.Point(7, 121)
			lblMADV.Location = point
			Me.lblMADV.Name = "lblMADV"
			Dim lblMADV2 As Global.System.Windows.Forms.Control = Me.lblMADV
			size = New Global.System.Drawing.Size(129, 21)
			lblMADV2.Size = size
			Me.lblMADV.TabIndex = 120
			Me.lblMADV.Tag = "CR0062"
			Me.lblMADV.Text = "Đơn vị"
			Me.txtBuocNhayMa.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtBuocNhayMa As Global.System.Windows.Forms.Control = Me.txtBuocNhayMa
			point = New Global.System.Drawing.Point(478, 2)
			txtBuocNhayMa.Location = point
			Me.txtBuocNhayMa.Name = "txtBuocNhayMa"
			Dim txtBuocNhayMa2 As Global.System.Windows.Forms.Control = Me.txtBuocNhayMa
			size = New Global.System.Drawing.Size(54, 22)
			txtBuocNhayMa2.Size = size
			Me.txtBuocNhayMa.TabIndex = 0
			Me.txtBuocNhayMa.Tag = "0R0000"
			Me.txtBuocNhayMa.Text = "1"
			Me.txtBuocNhayMa.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.txtBuocNhayMa.Visible = False
			Me.txtOBJID_2.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJID_ As Global.System.Windows.Forms.Control = Me.txtOBJID_2
			point = New Global.System.Drawing.Point(325, 3)
			txtOBJID_.Location = point
			Me.txtOBJID_2.Name = "txtOBJID_2"
			Dim txtOBJID_2 As Global.System.Windows.Forms.Control = Me.txtOBJID_2
			size = New Global.System.Drawing.Size(122, 22)
			txtOBJID_2.Size = size
			Me.txtOBJID_2.TabIndex = 0
			Me.txtOBJID_2.Tag = "0R0000"
			Me.txtOBJID_2.Visible = False
			Me.lblBuocNhayMa.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblBuocNhayMa As Global.System.Windows.Forms.Control = Me.lblBuocNhayMa
			point = New Global.System.Drawing.Point(461, 3)
			lblBuocNhayMa.Location = point
			Me.lblBuocNhayMa.Name = "lblBuocNhayMa"
			Dim lblBuocNhayMa2 As Global.System.Windows.Forms.Control = Me.lblBuocNhayMa
			size = New Global.System.Drawing.Size(16, 21)
			lblBuocNhayMa2.Size = size
			Me.lblBuocNhayMa.TabIndex = 33
			Me.lblBuocNhayMa.Tag = ""
			Me.lblBuocNhayMa.Text = "+"
			Me.lblBuocNhayMa.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lblBuocNhayMa.Visible = False
			Me.lblOBJID_2.Font = New Global.System.Drawing.Font("Arial", 11F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJID_ As Global.System.Windows.Forms.Control = Me.lblOBJID_2
			point = New Global.System.Drawing.Point(287, 3)
			lblOBJID_.Location = point
			Me.lblOBJID_2.Name = "lblOBJID_2"
			Dim lblOBJID_2 As Global.System.Windows.Forms.Control = Me.lblOBJID_2
			size = New Global.System.Drawing.Size(33, 21)
			lblOBJID_2.Size = size
			Me.lblOBJID_2.TabIndex = 33
			Me.lblOBJID_2.Tag = ""
			Me.lblOBJID_2.Text = "=>"
			Me.lblOBJID_2.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lblOBJID_2.Visible = False
			Me.panMAMT.Controls.Add(Me.txtMAMT)
			Me.panMAMT.Controls.Add(Me.txtTENMT)
			Me.panMAMT.Controls.Add(Me.btnDMMT)
			Me.panMAMT.Controls.Add(Me.lblMAMT)
			Dim panMAMT As Global.System.Windows.Forms.Control = Me.panMAMT
			point = New Global.System.Drawing.Point(0, 165)
			panMAMT.Location = point
			Me.panMAMT.Name = "panMAMT"
			Dim panMAMT2 As Global.System.Windows.Forms.Control = Me.panMAMT
			size = New Global.System.Drawing.Size(535, 25)
			panMAMT2.Size = size
			Me.panMAMT.TabIndex = 5
			Me.panMAPL_MANSX.Controls.Add(Me.lblMAPL)
			Me.panMAPL_MANSX.Controls.Add(Me.lblMANSX)
			Me.panMAPL_MANSX.Controls.Add(Me.txtMANSX)
			Me.panMAPL_MANSX.Controls.Add(Me.btnMANSX)
			Me.panMAPL_MANSX.Controls.Add(Me.txtTENNSX)
			Me.panMAPL_MANSX.Controls.Add(Me.txtTENPL)
			Me.panMAPL_MANSX.Controls.Add(Me.txtMAPL)
			Me.panMAPL_MANSX.Controls.Add(Me.btnMAPL)
			Dim panMAPL_MANSX As Global.System.Windows.Forms.Control = Me.panMAPL_MANSX
			point = New Global.System.Drawing.Point(0, 217)
			panMAPL_MANSX.Location = point
			Me.panMAPL_MANSX.Name = "panMAPL_MANSX"
			Dim panMAPL_MANSX2 As Global.System.Windows.Forms.Control = Me.panMAPL_MANSX
			size = New Global.System.Drawing.Size(535, 47)
			panMAPL_MANSX2.Size = size
			Me.panMAPL_MANSX.TabIndex = 108
			Me.panLMATERIAL.Controls.Add(Me.lblMADC)
			Me.panLMATERIAL.Controls.Add(Me.txtMADC)
			Me.panLMATERIAL.Controls.Add(Me.btnMADC)
			Me.panLMATERIAL.Controls.Add(Me.txtTENDC)
			Dim panLMATERIAL As Global.System.Windows.Forms.Control = Me.panLMATERIAL
			point = New Global.System.Drawing.Point(0, 263)
			panLMATERIAL.Location = point
			Me.panLMATERIAL.Name = "panLMATERIAL"
			Dim panLMATERIAL2 As Global.System.Windows.Forms.Control = Me.panLMATERIAL
			size = New Global.System.Drawing.Size(535, 24)
			panLMATERIAL2.Size = size
			Me.panLMATERIAL.TabIndex = 109
			Me.lblMADC.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMADC As Global.System.Windows.Forms.Control = Me.lblMADC
			point = New Global.System.Drawing.Point(7, 2)
			lblMADC.Location = point
			Me.lblMADC.Name = "lblMADC"
			Dim lblMADC2 As Global.System.Windows.Forms.Control = Me.lblMADC
			size = New Global.System.Drawing.Size(134, 21)
			lblMADC2.Size = size
			Me.lblMADC.TabIndex = 54
			Me.lblMADC.Tag = "CR0060"
			Me.lblMADC.Text = "Mã dược chất"
			Me.txtMADC.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMADC As Global.System.Windows.Forms.Control = Me.txtMADC
			point = New Global.System.Drawing.Point(162, 2)
			txtMADC.Location = point
			Me.txtMADC.Name = "txtMADC"
			Dim txtMADC2 As Global.System.Windows.Forms.Control = Me.txtMADC
			size = New Global.System.Drawing.Size(122, 22)
			txtMADC2.Size = size
			Me.txtMADC.TabIndex = 13
			Me.txtMADC.Tag = "0R0000"
			Me.btnMADC.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnMADC As Global.System.Windows.Forms.Control = Me.btnMADC
			point = New Global.System.Drawing.Point(290, 2)
			btnMADC.Location = point
			Me.btnMADC.Name = "btnMADC"
			Dim btnMADC2 As Global.System.Windows.Forms.Control = Me.btnMADC
			size = New Global.System.Drawing.Size(45, 22)
			btnMADC2.Size = size
			Me.btnMADC.TabIndex = 14
			Me.btnMADC.Tag = "CB0011"
			Me.btnMADC.UseVisualStyleBackColor = True
			Me.txtTENDC.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENDC As Global.System.Windows.Forms.Control = Me.txtTENDC
			point = New Global.System.Drawing.Point(341, 2)
			txtTENDC.Location = point
			Me.txtTENDC.Name = "txtTENDC"
			Dim txtTENDC2 As Global.System.Windows.Forms.Control = Me.txtTENDC
			size = New Global.System.Drawing.Size(191, 22)
			txtTENDC2.Size = size
			Me.txtTENDC.TabIndex = 100
			Me.txtTENDC.TabStop = False
			Me.txtTENDC.Tag = "0R0000"
			Me.panPRICE.Controls.Add(Me.Label7)
			Me.panPRICE.Controls.Add(Me.txtPURSE)
			Me.panPRICE.Controls.Add(Me.btnGia1)
			Me.panPRICE.Controls.Add(Me.txtPRICE)
			Me.panPRICE.Controls.Add(Me.lblPRICE)
			Dim panPRICE As Global.System.Windows.Forms.Control = Me.panPRICE
			point = New Global.System.Drawing.Point(0, 286)
			panPRICE.Location = point
			Me.panPRICE.Name = "panPRICE"
			Dim panPRICE2 As Global.System.Windows.Forms.Control = Me.panPRICE
			size = New Global.System.Drawing.Size(535, 26)
			panPRICE2.Size = size
			Me.panPRICE.TabIndex = 110
			Me.Label7.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label7
			point = New Global.System.Drawing.Point(313, 3)
			label.Location = point
			Me.Label7.Name = "Label7"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label7
			size = New Global.System.Drawing.Size(112, 21)
			label2.Size = size
			Me.Label7.TabIndex = 120
			Me.Label7.Tag = "CR0087"
			Me.Label7.Text = "Giá"
			Me.txtPURSE.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPURSE As Global.System.Windows.Forms.Control = Me.txtPURSE
			point = New Global.System.Drawing.Point(448, 2)
			txtPURSE.Location = point
			Me.txtPURSE.Name = "txtPURSE"
			Dim txtPURSE2 As Global.System.Windows.Forms.Control = Me.txtPURSE
			size = New Global.System.Drawing.Size(84, 22)
			txtPURSE2.Size = size
			Me.txtPURSE.TabIndex = 119
			Me.txtPURSE.Tag = "0R0000"
			Me.txtPURSE.Text = "0"
			Me.txtPURSE.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Dim btnGia As Global.System.Windows.Forms.Control = Me.btnGia1
			point = New Global.System.Drawing.Point(247, 3)
			btnGia.Location = point
			Me.btnGia1.Name = "btnGia1"
			Dim btnGia2 As Global.System.Windows.Forms.Control = Me.btnGia1
			size = New Global.System.Drawing.Size(31, 22)
			btnGia2.Size = size
			Me.btnGia1.TabIndex = 118
			Me.btnGia1.Tag = ""
			Me.btnGia1.Text = "..."
			Me.btnGia1.UseVisualStyleBackColor = True
			Me.panPRICE2_3_4.Controls.Add(Me.lblPRICE2)
			Me.panPRICE2_3_4.Controls.Add(Me.txtPRICE4)
			Me.panPRICE2_3_4.Controls.Add(Me.txtPRICE2)
			Me.panPRICE2_3_4.Controls.Add(Me.lblPRICE4)
			Me.panPRICE2_3_4.Controls.Add(Me.lblPRICE3)
			Me.panPRICE2_3_4.Controls.Add(Me.txtPRICE3)
			Dim panPRICE2_3_ As Global.System.Windows.Forms.Control = Me.panPRICE2_3_4
			point = New Global.System.Drawing.Point(0, 311)
			panPRICE2_3_.Location = point
			Me.panPRICE2_3_4.Name = "panPRICE2_3_4"
			Dim panPRICE2_3_2 As Global.System.Windows.Forms.Control = Me.panPRICE2_3_4
			size = New Global.System.Drawing.Size(535, 26)
			panPRICE2_3_2.Size = size
			Me.panPRICE2_3_4.TabIndex = 111
			Me.panPRICE5_6_7.Controls.Add(Me.lblPRICE5)
			Me.panPRICE5_6_7.Controls.Add(Me.txtPRICE7)
			Me.panPRICE5_6_7.Controls.Add(Me.txtPRICE5)
			Me.panPRICE5_6_7.Controls.Add(Me.lblPRICE7)
			Me.panPRICE5_6_7.Controls.Add(Me.lblPRICE6)
			Me.panPRICE5_6_7.Controls.Add(Me.txtPRICE6)
			Dim panPRICE5_6_ As Global.System.Windows.Forms.Control = Me.panPRICE5_6_7
			point = New Global.System.Drawing.Point(0, 338)
			panPRICE5_6_.Location = point
			Me.panPRICE5_6_7.Name = "panPRICE5_6_7"
			Dim panPRICE5_6_2 As Global.System.Windows.Forms.Control = Me.panPRICE5_6_7
			size = New Global.System.Drawing.Size(535, 27)
			panPRICE5_6_2.Size = size
			Me.panPRICE5_6_7.TabIndex = 112
			Me.panPRICE8_9_10.Controls.Add(Me.txtPRICE10)
			Me.panPRICE8_9_10.Controls.Add(Me.lblPRICE8)
			Me.panPRICE8_9_10.Controls.Add(Me.lblPRICE9)
			Me.panPRICE8_9_10.Controls.Add(Me.lblPRICE10)
			Me.panPRICE8_9_10.Controls.Add(Me.txtPRICE9)
			Me.panPRICE8_9_10.Controls.Add(Me.txtPRICE8)
			Dim panPRICE8_9_ As Global.System.Windows.Forms.Control = Me.panPRICE8_9_10
			point = New Global.System.Drawing.Point(0, 364)
			panPRICE8_9_.Location = point
			Me.panPRICE8_9_10.Name = "panPRICE8_9_10"
			Dim panPRICE8_9_2 As Global.System.Windows.Forms.Control = Me.panPRICE8_9_10
			size = New Global.System.Drawing.Size(535, 27)
			panPRICE8_9_2.Size = size
			Me.panPRICE8_9_10.TabIndex = 113
			Me.chkLMATERIAL.AutoSize = True
			Me.chkLMATERIAL.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkLMATERIAL As Global.System.Windows.Forms.Control = Me.chkLMATERIAL
			point = New Global.System.Drawing.Point(273, 6)
			chkLMATERIAL.Location = point
			Me.chkLMATERIAL.Name = "chkLMATERIAL"
			Dim chkLMATERIAL2 As Global.System.Windows.Forms.Control = Me.chkLMATERIAL
			size = New Global.System.Drawing.Size(15, 14)
			chkLMATERIAL2.Size = size
			Me.chkLMATERIAL.TabIndex = 28
			Me.chkLMATERIAL.Tag = "0R0000"
			Me.chkLMATERIAL.UseVisualStyleBackColor = True
			Me.lblLMATERIAL.AutoSize = True
			Me.lblLMATERIAL.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblLMATERIAL As Global.System.Windows.Forms.Control = Me.lblLMATERIAL
			point = New Global.System.Drawing.Point(211, 4)
			lblLMATERIAL.Location = point
			Me.lblLMATERIAL.Name = "lblLMATERIAL"
			Dim lblLMATERIAL2 As Global.System.Windows.Forms.Control = Me.lblLMATERIAL
			size = New Global.System.Drawing.Size(55, 16)
			lblLMATERIAL2.Size = size
			Me.lblLMATERIAL.TabIndex = 42
			Me.lblLMATERIAL.Tag = "CR0073"
			Me.lblLMATERIAL.Text = "Món ẩn"
			Me.panLSALE.Controls.Add(Me.Label22)
			Me.panLSALE.Controls.Add(Me.chkLQtyLe)
			Me.panLSALE.Controls.Add(Me.Label21)
			Me.panLSALE.Controls.Add(Me.chkLSerial)
			Me.panLSALE.Controls.Add(Me.Label9)
			Me.panLSALE.Controls.Add(Me.chkLTON_KHACHHANG)
			Me.panLSALE.Controls.Add(Me.Label12)
			Me.panLSALE.Controls.Add(Me.chkLComboPrice)
			Me.panLSALE.Controls.Add(Me.Label20)
			Me.panLSALE.Controls.Add(Me.chkLAmtOpen)
			Me.panLSALE.Controls.Add(Me.Label19)
			Me.panLSALE.Controls.Add(Me.chkLQTYMain)
			Me.panLSALE.Controls.Add(Me.Label8)
			Me.panLSALE.Controls.Add(Me.chkLSETCOMBO)
			Me.panLSALE.Controls.Add(Me.txtPhieu)
			Me.panLSALE.Controls.Add(Me.txtCOMBO)
			Me.panLSALE.Controls.Add(Me.btnPhieu)
			Me.panLSALE.Controls.Add(Me.btnCOMBO)
			Me.panLSALE.Controls.Add(Me.Label10)
			Me.panLSALE.Controls.Add(Me.Label2)
			Me.panLSALE.Controls.Add(Me.chkCOMBO)
			Me.panLSALE.Controls.Add(Me.chkStopUse)
			Me.panLSALE.Controls.Add(Me.lblStop)
			Me.panLSALE.Controls.Add(Me.chkLopen)
			Me.panLSALE.Controls.Add(Me.Label1)
			Me.panLSALE.Controls.Add(Me.chkLMATERIAL)
			Me.panLSALE.Controls.Add(Me.lblLMATERIAL)
			Me.panLSALE.Controls.Add(Me.lblLSAVE)
			Me.panLSALE.Controls.Add(Me.chkLSAVE)
			Dim panLSALE As Global.System.Windows.Forms.Control = Me.panLSALE
			point = New Global.System.Drawing.Point(0, 391)
			panLSALE.Location = point
			Me.panLSALE.Name = "panLSALE"
			Dim panLSALE2 As Global.System.Windows.Forms.Control = Me.panLSALE
			size = New Global.System.Drawing.Size(535, 134)
			panLSALE2.Size = size
			Me.panLSALE.TabIndex = 114
			Me.Label21.AutoSize = True
			Me.Label21.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label21
			point = New Global.System.Drawing.Point(234, 94)
			label3.Location = point
			Me.Label21.Name = "Label21"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label21
			size = New Global.System.Drawing.Size(82, 16)
			label4.Size = size
			Me.Label21.TabIndex = 118
			Me.Label21.Tag = "CR0112"
			Me.Label21.Text = "Có số serial"
			Me.chkLSerial.AutoSize = True
			Me.chkLSerial.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkLSerial As Global.System.Windows.Forms.Control = Me.chkLSerial
			point = New Global.System.Drawing.Point(344, 96)
			chkLSerial.Location = point
			Me.chkLSerial.Name = "chkLSerial"
			Dim chkLSerial2 As Global.System.Windows.Forms.Control = Me.chkLSerial
			size = New Global.System.Drawing.Size(15, 14)
			chkLSerial2.Size = size
			Me.chkLSerial.TabIndex = 117
			Me.chkLSerial.Tag = "0R0000"
			Me.chkLSerial.UseVisualStyleBackColor = True
			Me.Label9.AutoSize = True
			Me.Label9.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label9
			point = New Global.System.Drawing.Point(4, 72)
			label5.Location = point
			Me.Label9.Name = "Label9"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label9
			size = New Global.System.Drawing.Size(169, 16)
			label6.Size = size
			Me.Label9.TabIndex = 109
			Me.Label9.Tag = "CR0089"
			Me.Label9.Text = "Tồn kho theo khách hàng"
			Me.chkLTON_KHACHHANG.AutoSize = True
			Me.chkLTON_KHACHHANG.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkLTON_KHACHHANG As Global.System.Windows.Forms.Control = Me.chkLTON_KHACHHANG
			point = New Global.System.Drawing.Point(198, 74)
			chkLTON_KHACHHANG.Location = point
			Me.chkLTON_KHACHHANG.Name = "chkLTON_KHACHHANG"
			Dim chkLTON_KHACHHANG2 As Global.System.Windows.Forms.Control = Me.chkLTON_KHACHHANG
			size = New Global.System.Drawing.Size(15, 14)
			chkLTON_KHACHHANG2.Size = size
			Me.chkLTON_KHACHHANG.TabIndex = 108
			Me.chkLTON_KHACHHANG.Tag = "0R0000"
			Me.chkLTON_KHACHHANG.UseVisualStyleBackColor = True
			Me.Label12.AutoSize = True
			Me.Label12.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label7 As Global.System.Windows.Forms.Control = Me.Label12
			point = New Global.System.Drawing.Point(234, 49)
			label7.Location = point
			Me.Label12.Name = "Label12"
			Dim label8 As Global.System.Windows.Forms.Control = Me.Label12
			size = New Global.System.Drawing.Size(165, 16)
			label8.Size = size
			Me.Label12.TabIndex = 107
			Me.Label12.Tag = "CR0098"
			Me.Label12.Text = "Món bán kèm có giá tiền"
			Me.Label12.Visible = False
			Me.chkLComboPrice.AutoSize = True
			Me.chkLComboPrice.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkLComboPrice As Global.System.Windows.Forms.Control = Me.chkLComboPrice
			point = New Global.System.Drawing.Point(445, 51)
			chkLComboPrice.Location = point
			Me.chkLComboPrice.Name = "chkLComboPrice"
			Dim chkLComboPrice2 As Global.System.Windows.Forms.Control = Me.chkLComboPrice
			size = New Global.System.Drawing.Size(15, 14)
			chkLComboPrice2.Size = size
			Me.chkLComboPrice.TabIndex = 106
			Me.chkLComboPrice.Tag = "0R0000"
			Me.chkLComboPrice.UseVisualStyleBackColor = True
			Me.chkLComboPrice.Visible = False
			Me.Label20.AutoSize = True
			Me.Label20.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label9 As Global.System.Windows.Forms.Control = Me.Label20
			point = New Global.System.Drawing.Point(406, 4)
			label9.Location = point
			Me.Label20.Name = "Label20"
			Dim label10 As Global.System.Windows.Forms.Control = Me.Label20
			size = New Global.System.Drawing.Size(101, 16)
			label10.Size = size
			Me.Label20.TabIndex = 107
			Me.Label20.Tag = "CR0111"
			Me.Label20.Text = "Thành tiền mở"
			Me.chkLAmtOpen.AutoSize = True
			Me.chkLAmtOpen.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkLAmtOpen As Global.System.Windows.Forms.Control = Me.chkLAmtOpen
			point = New Global.System.Drawing.Point(515, 5)
			chkLAmtOpen.Location = point
			Me.chkLAmtOpen.Name = "chkLAmtOpen"
			Dim chkLAmtOpen2 As Global.System.Windows.Forms.Control = Me.chkLAmtOpen
			size = New Global.System.Drawing.Size(15, 14)
			chkLAmtOpen2.Size = size
			Me.chkLAmtOpen.TabIndex = 106
			Me.chkLAmtOpen.Tag = "0R0000"
			Me.chkLAmtOpen.UseVisualStyleBackColor = True
			Me.Label19.AutoSize = True
			Me.Label19.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label11 As Global.System.Windows.Forms.Control = Me.Label19
			point = New Global.System.Drawing.Point(4, 93)
			label11.Location = point
			Me.Label19.Name = "Label19"
			Dim label12 As Global.System.Windows.Forms.Control = Me.Label19
			size = New Global.System.Drawing.Size(151, 16)
			label12.Size = size
			Me.Label19.TabIndex = 107
			Me.Label19.Tag = "CR0110"
			Me.Label19.Text = "SL lấy theo món chính"
			Me.chkLQTYMain.AutoSize = True
			Me.chkLQTYMain.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkLQTYMain As Global.System.Windows.Forms.Control = Me.chkLQTYMain
			point = New Global.System.Drawing.Point(198, 95)
			chkLQTYMain.Location = point
			Me.chkLQTYMain.Name = "chkLQTYMain"
			Dim chkLQTYMain2 As Global.System.Windows.Forms.Control = Me.chkLQTYMain
			size = New Global.System.Drawing.Size(15, 14)
			chkLQTYMain2.Size = size
			Me.chkLQTYMain.TabIndex = 106
			Me.chkLQTYMain.Tag = "0R0000"
			Me.chkLQTYMain.UseVisualStyleBackColor = True
			Me.Label8.AutoSize = True
			Me.Label8.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label13 As Global.System.Windows.Forms.Control = Me.Label8
			point = New Global.System.Drawing.Point(4, 51)
			label13.Location = point
			Me.Label8.Name = "Label8"
			Dim label14 As Global.System.Windows.Forms.Control = Me.Label8
			size = New Global.System.Drawing.Size(178, 16)
			label14.Size = size
			Me.Label8.TabIndex = 107
			Me.Label8.Tag = "CR0088"
			Me.Label8.Text = "Tự thêm các món bán kèm"
			Me.Label8.Visible = False
			Me.chkLSETCOMBO.AutoSize = True
			Me.chkLSETCOMBO.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkLSETCOMBO As Global.System.Windows.Forms.Control = Me.chkLSETCOMBO
			point = New Global.System.Drawing.Point(198, 53)
			chkLSETCOMBO.Location = point
			Me.chkLSETCOMBO.Name = "chkLSETCOMBO"
			Dim chkLSETCOMBO2 As Global.System.Windows.Forms.Control = Me.chkLSETCOMBO
			size = New Global.System.Drawing.Size(15, 14)
			chkLSETCOMBO2.Size = size
			Me.chkLSETCOMBO.TabIndex = 106
			Me.chkLSETCOMBO.Tag = "0R0000"
			Me.chkLSETCOMBO.UseVisualStyleBackColor = True
			Me.chkLSETCOMBO.Visible = False
			Me.txtPhieu.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPhieu As Global.System.Windows.Forms.Control = Me.txtPhieu
			point = New Global.System.Drawing.Point(344, 70)
			txtPhieu.Location = point
			Me.txtPhieu.MaxLength = 15
			Me.txtPhieu.Name = "txtPhieu"
			Dim txtPhieu2 As Global.System.Windows.Forms.Control = Me.txtPhieu
			size = New Global.System.Drawing.Size(138, 22)
			txtPhieu2.Size = size
			Me.txtPhieu.TabIndex = 105
			Me.txtPhieu.TabStop = False
			Me.txtPhieu.Tag = "0R0000"
			Me.txtCOMBO.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtCOMBO As Global.System.Windows.Forms.Control = Me.txtCOMBO
			point = New Global.System.Drawing.Point(183, 24)
			txtCOMBO.Location = point
			Me.txtCOMBO.Name = "txtCOMBO"
			Dim txtCOMBO2 As Global.System.Windows.Forms.Control = Me.txtCOMBO
			size = New Global.System.Drawing.Size(299, 22)
			txtCOMBO2.Size = size
			Me.txtCOMBO.TabIndex = 105
			Me.txtCOMBO.TabStop = False
			Me.txtCOMBO.Tag = "0R0000"
			Me.btnPhieu.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnPhieu As Global.System.Windows.Forms.Control = Me.btnPhieu
			point = New Global.System.Drawing.Point(485, 67)
			btnPhieu.Location = point
			Me.btnPhieu.Name = "btnPhieu"
			Dim btnPhieu2 As Global.System.Windows.Forms.Control = Me.btnPhieu
			size = New Global.System.Drawing.Size(45, 25)
			btnPhieu2.Size = size
			Me.btnPhieu.TabIndex = 103
			Me.btnPhieu.Tag = "CB0011"
			Me.btnPhieu.UseVisualStyleBackColor = True
			Me.btnCOMBO.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnCOMBO As Global.System.Windows.Forms.Control = Me.btnCOMBO
			point = New Global.System.Drawing.Point(485, 22)
			btnCOMBO.Location = point
			Me.btnCOMBO.Name = "btnCOMBO"
			Dim btnCOMBO2 As Global.System.Windows.Forms.Control = Me.btnCOMBO
			size = New Global.System.Drawing.Size(45, 25)
			btnCOMBO2.Size = size
			Me.btnCOMBO.TabIndex = 103
			Me.btnCOMBO.Tag = ""
			Me.btnCOMBO.UseVisualStyleBackColor = True
			Me.Label10.AutoSize = True
			Me.Label10.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label15 As Global.System.Windows.Forms.Control = Me.Label10
			point = New Global.System.Drawing.Point(234, 71)
			label15.Location = point
			Me.Label10.Name = "Label10"
			Dim label16 As Global.System.Windows.Forms.Control = Me.Label10
			size = New Global.System.Drawing.Size(99, 16)
			label16.Size = size
			Me.Label10.TabIndex = 48
			Me.Label10.Tag = "CR0090"
			Me.Label10.Text = "Liên kết phiếu"
			Me.Label2.AutoSize = True
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label17 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(4, 26)
			label17.Location = point
			Me.Label2.Name = "Label2"
			Dim label18 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(122, 16)
			label18.Size = size
			Me.Label2.TabIndex = 48
			Me.Label2.Tag = "CR0076"
			Me.Label2.Text = "co mon ban kem?"
			Me.chkCOMBO.AutoSize = True
			Me.chkCOMBO.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkCOMBO As Global.System.Windows.Forms.Control = Me.chkCOMBO
			point = New Global.System.Drawing.Point(161, 28)
			chkCOMBO.Location = point
			Me.chkCOMBO.Name = "chkCOMBO"
			Dim chkCOMBO2 As Global.System.Windows.Forms.Control = Me.chkCOMBO
			size = New Global.System.Drawing.Size(15, 14)
			chkCOMBO2.Size = size
			Me.chkCOMBO.TabIndex = 47
			Me.chkCOMBO.Tag = "0R0000"
			Me.chkCOMBO.UseVisualStyleBackColor = True
			Me.chkStopUse.AutoSize = True
			Dim chkStopUse As Global.System.Windows.Forms.Control = Me.chkStopUse
			point = New Global.System.Drawing.Point(176, 6)
			chkStopUse.Location = point
			Me.chkStopUse.Name = "chkStopUse"
			Dim chkStopUse2 As Global.System.Windows.Forms.Control = Me.chkStopUse
			size = New Global.System.Drawing.Size(15, 14)
			chkStopUse2.Size = size
			Me.chkStopUse.TabIndex = 46
			Me.chkStopUse.UseVisualStyleBackColor = True
			Me.lblStop.AutoSize = True
			Me.lblStop.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblStop As Global.System.Windows.Forms.Control = Me.lblStop
			point = New Global.System.Drawing.Point(98, 4)
			lblStop.Location = point
			Me.lblStop.Name = "lblStop"
			Dim lblStop2 As Global.System.Windows.Forms.Control = Me.lblStop
			size = New Global.System.Drawing.Size(72, 16)
			lblStop2.Size = size
			Me.lblStop.TabIndex = 45
			Me.lblStop.Tag = "CR0074"
			Me.lblStop.Text = "Ngưng SD"
			Me.chkLopen.AutoSize = True
			Dim chkLopen As Global.System.Windows.Forms.Control = Me.chkLopen
			point = New Global.System.Drawing.Point(370, 6)
			chkLopen.Location = point
			Me.chkLopen.Name = "chkLopen"
			Dim chkLopen2 As Global.System.Windows.Forms.Control = Me.chkLopen
			size = New Global.System.Drawing.Size(15, 14)
			chkLopen2.Size = size
			Me.chkLopen.TabIndex = 44
			Me.chkLopen.UseVisualStyleBackColor = True
			Me.Label1.AutoSize = True
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label19 As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(308, 4)
			label19.Location = point
			Me.Label1.Name = "Label1"
			Dim label20 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(54, 16)
			label20.Size = size
			Me.Label1.TabIndex = 43
			Me.Label1.Tag = "CR0072"
			Me.Label1.Text = "Gia mo"
			Me.panButton.Controls.Add(Me.TableLayoutPanel1)
			Me.panButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim panButton As Global.System.Windows.Forms.Control = Me.panButton
			point = New Global.System.Drawing.Point(675, 0)
			panButton.Location = point
			Me.panButton.Name = "panButton"
			Dim panButton2 As Global.System.Windows.Forms.Control = Me.panButton
			size = New Global.System.Drawing.Size(119, 631)
			panButton2.Size = size
			Me.panButton.TabIndex = 116
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnKeyboard, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.picAnh, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 6)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 2)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 3)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(0, 0)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 7
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 22F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 13F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 13F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 13F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 13F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 13F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 13F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(119, 631)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnKeyboard.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnKeyboard.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(3, 141)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(113, 76)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 119
			Me.btnKeyboard.Text = "Keyboard"
			Me.btnKeyboard.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Me.picAnh.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.picAnh.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.picAnh.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim picAnh As Global.System.Windows.Forms.Control = Me.picAnh
			point = New Global.System.Drawing.Point(3, 3)
			picAnh.Location = point
			Me.picAnh.Name = "picAnh"
			Dim picAnh2 As Global.System.Windows.Forms.Control = Me.picAnh
			size = New Global.System.Drawing.Size(113, 132)
			picAnh2.Size = size
			Me.picAnh.TabIndex = 118
			Me.picAnh.TabStop = False
			Me.panREMARK.Controls.Add(Me.lblbep6)
			Me.panREMARK.Controls.Add(Me.lblbep5)
			Me.panREMARK.Controls.Add(Me.txtbep6)
			Me.panREMARK.Controls.Add(Me.lblbep3)
			Me.panREMARK.Controls.Add(Me.btnDMBEP6)
			Me.panREMARK.Controls.Add(Me.txtbep5)
			Me.panREMARK.Controls.Add(Me.btnDMBEP5)
			Me.panREMARK.Controls.Add(Me.txtTENBEP6)
			Me.panREMARK.Controls.Add(Me.txtbep3)
			Me.panREMARK.Controls.Add(Me.txtTENBEP5)
			Me.panREMARK.Controls.Add(Me.btnDMBEP3)
			Me.panREMARK.Controls.Add(Me.lblbep4)
			Me.panREMARK.Controls.Add(Me.txtTENBEP3)
			Me.panREMARK.Controls.Add(Me.txtbep4)
			Me.panREMARK.Controls.Add(Me.lblbep2)
			Me.panREMARK.Controls.Add(Me.btnDMBEP4)
			Me.panREMARK.Controls.Add(Me.txtbep2)
			Me.panREMARK.Controls.Add(Me.txtTENBEP4)
			Me.panREMARK.Controls.Add(Me.btnDMBEP2)
			Me.panREMARK.Controls.Add(Me.txtTENBEP2)
			Me.panREMARK.Controls.Add(Me.lblbep1)
			Me.panREMARK.Controls.Add(Me.txtbep1)
			Me.panREMARK.Controls.Add(Me.btnDMBEP1)
			Me.panREMARK.Controls.Add(Me.txtTENBEP1)
			Me.panREMARK.Controls.Add(Me.lblREMARK)
			Me.panREMARK.Controls.Add(Me.txtREMARK)
			Dim panREMARK As Global.System.Windows.Forms.Control = Me.panREMARK
			point = New Global.System.Drawing.Point(0, 531)
			panREMARK.Location = point
			Me.panREMARK.Name = "panREMARK"
			Dim panREMARK2 As Global.System.Windows.Forms.Control = Me.panREMARK
			size = New Global.System.Drawing.Size(535, 101)
			panREMARK2.Size = size
			Me.panREMARK.TabIndex = 115
			Me.lblbep6.AutoSize = True
			Me.lblbep6.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblbep As Global.System.Windows.Forms.Control = Me.lblbep6
			point = New Global.System.Drawing.Point(280, 51)
			lblbep.Location = point
			Me.lblbep6.Name = "lblbep6"
			Dim lblbep2 As Global.System.Windows.Forms.Control = Me.lblbep6
			size = New Global.System.Drawing.Size(45, 16)
			lblbep2.Size = size
			Me.lblbep6.TabIndex = 111
			Me.lblbep6.Tag = "CR0096"
			Me.lblbep6.Text = "BẾP 6"
			Me.lblbep5.AutoSize = True
			Me.lblbep5.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblbep3 As Global.System.Windows.Forms.Control = Me.lblbep5
			point = New Global.System.Drawing.Point(280, 27)
			lblbep3.Location = point
			Me.lblbep5.Name = "lblbep5"
			Dim lblbep4 As Global.System.Windows.Forms.Control = Me.lblbep5
			size = New Global.System.Drawing.Size(45, 16)
			lblbep4.Size = size
			Me.lblbep5.TabIndex = 111
			Me.lblbep5.Tag = "CR0092"
			Me.lblbep5.Text = "BẾP 5"
			Me.txtbep6.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtbep As Global.System.Windows.Forms.Control = Me.txtbep6
			point = New Global.System.Drawing.Point(329, 49)
			txtbep.Location = point
			Me.txtbep6.Name = "txtbep6"
			Dim txtbep2 As Global.System.Windows.Forms.Control = Me.txtbep6
			size = New Global.System.Drawing.Size(46, 22)
			txtbep2.Size = size
			Me.txtbep6.TabIndex = 109
			Me.txtbep6.Tag = "0R0000"
			Me.lblbep3.AutoSize = True
			Me.lblbep3.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblbep5 As Global.System.Windows.Forms.Control = Me.lblbep3
			point = New Global.System.Drawing.Point(3, 50)
			lblbep5.Location = point
			Me.lblbep3.Name = "lblbep3"
			Dim lblbep6 As Global.System.Windows.Forms.Control = Me.lblbep3
			size = New Global.System.Drawing.Size(45, 16)
			lblbep6.Size = size
			Me.lblbep3.TabIndex = 111
			Me.lblbep3.Tag = "CR0068"
			Me.lblbep3.Text = "BẾP 3"
			Me.btnDMBEP6.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMBEP As Global.System.Windows.Forms.Control = Me.btnDMBEP6
			point = New Global.System.Drawing.Point(377, 48)
			btnDMBEP.Location = point
			Me.btnDMBEP6.Name = "btnDMBEP6"
			Dim btnDMBEP2 As Global.System.Windows.Forms.Control = Me.btnDMBEP6
			size = New Global.System.Drawing.Size(31, 24)
			btnDMBEP2.Size = size
			Me.btnDMBEP6.TabIndex = 110
			Me.btnDMBEP6.Tag = "CB0011"
			Me.btnDMBEP6.UseVisualStyleBackColor = True
			Me.txtbep5.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtbep3 As Global.System.Windows.Forms.Control = Me.txtbep5
			point = New Global.System.Drawing.Point(329, 25)
			txtbep3.Location = point
			Me.txtbep5.Name = "txtbep5"
			Dim txtbep4 As Global.System.Windows.Forms.Control = Me.txtbep5
			size = New Global.System.Drawing.Size(46, 22)
			txtbep4.Size = size
			Me.txtbep5.TabIndex = 109
			Me.txtbep5.Tag = "0R0000"
			Me.btnDMBEP5.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMBEP3 As Global.System.Windows.Forms.Control = Me.btnDMBEP5
			point = New Global.System.Drawing.Point(377, 24)
			btnDMBEP3.Location = point
			Me.btnDMBEP5.Name = "btnDMBEP5"
			Dim btnDMBEP4 As Global.System.Windows.Forms.Control = Me.btnDMBEP5
			size = New Global.System.Drawing.Size(31, 24)
			btnDMBEP4.Size = size
			Me.btnDMBEP5.TabIndex = 110
			Me.btnDMBEP5.Tag = "CB0011"
			Me.btnDMBEP5.UseVisualStyleBackColor = True
			Me.txtTENBEP6.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENBEP As Global.System.Windows.Forms.Control = Me.txtTENBEP6
			point = New Global.System.Drawing.Point(410, 49)
			txtTENBEP.Location = point
			Me.txtTENBEP6.Name = "txtTENBEP6"
			Dim txtTENBEP2 As Global.System.Windows.Forms.Control = Me.txtTENBEP6
			size = New Global.System.Drawing.Size(123, 22)
			txtTENBEP2.Size = size
			Me.txtTENBEP6.TabIndex = 112
			Me.txtTENBEP6.TabStop = False
			Me.txtTENBEP6.Tag = "0R0000"
			Me.txtbep3.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtbep5 As Global.System.Windows.Forms.Control = Me.txtbep3
			point = New Global.System.Drawing.Point(56, 48)
			txtbep5.Location = point
			Me.txtbep3.Name = "txtbep3"
			Dim txtbep6 As Global.System.Windows.Forms.Control = Me.txtbep3
			size = New Global.System.Drawing.Size(46, 22)
			txtbep6.Size = size
			Me.txtbep3.TabIndex = 109
			Me.txtbep3.Tag = "0R0000"
			Me.txtTENBEP5.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENBEP3 As Global.System.Windows.Forms.Control = Me.txtTENBEP5
			point = New Global.System.Drawing.Point(410, 25)
			txtTENBEP3.Location = point
			Me.txtTENBEP5.Name = "txtTENBEP5"
			Dim txtTENBEP4 As Global.System.Windows.Forms.Control = Me.txtTENBEP5
			size = New Global.System.Drawing.Size(123, 22)
			txtTENBEP4.Size = size
			Me.txtTENBEP5.TabIndex = 112
			Me.txtTENBEP5.TabStop = False
			Me.txtTENBEP5.Tag = "0R0000"
			Me.btnDMBEP3.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMBEP5 As Global.System.Windows.Forms.Control = Me.btnDMBEP3
			point = New Global.System.Drawing.Point(103, 47)
			btnDMBEP5.Location = point
			Me.btnDMBEP3.Name = "btnDMBEP3"
			Dim btnDMBEP6 As Global.System.Windows.Forms.Control = Me.btnDMBEP3
			size = New Global.System.Drawing.Size(31, 24)
			btnDMBEP6.Size = size
			Me.btnDMBEP3.TabIndex = 110
			Me.btnDMBEP3.Tag = "CB0011"
			Me.btnDMBEP3.UseVisualStyleBackColor = True
			Me.lblbep4.AutoSize = True
			Me.lblbep4.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblbep7 As Global.System.Windows.Forms.Control = Me.lblbep4
			point = New Global.System.Drawing.Point(280, 3)
			lblbep7.Location = point
			Me.lblbep4.Name = "lblbep4"
			Dim lblbep8 As Global.System.Windows.Forms.Control = Me.lblbep4
			size = New Global.System.Drawing.Size(45, 16)
			lblbep8.Size = size
			Me.lblbep4.TabIndex = 107
			Me.lblbep4.Tag = "CR0091"
			Me.lblbep4.Text = "BẾP 4"
			Me.txtTENBEP3.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENBEP5 As Global.System.Windows.Forms.Control = Me.txtTENBEP3
			point = New Global.System.Drawing.Point(135, 48)
			txtTENBEP5.Location = point
			Me.txtTENBEP3.Name = "txtTENBEP3"
			Dim txtTENBEP6 As Global.System.Windows.Forms.Control = Me.txtTENBEP3
			size = New Global.System.Drawing.Size(123, 22)
			txtTENBEP6.Size = size
			Me.txtTENBEP3.TabIndex = 112
			Me.txtTENBEP3.TabStop = False
			Me.txtTENBEP3.Tag = "0R0000"
			Me.txtbep4.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtbep7 As Global.System.Windows.Forms.Control = Me.txtbep4
			point = New Global.System.Drawing.Point(329, 1)
			txtbep7.Location = point
			Me.txtbep4.Name = "txtbep4"
			Dim txtbep8 As Global.System.Windows.Forms.Control = Me.txtbep4
			size = New Global.System.Drawing.Size(46, 22)
			txtbep8.Size = size
			Me.txtbep4.TabIndex = 105
			Me.txtbep4.Tag = "0R0000"
			Me.lblbep2.AutoSize = True
			Me.lblbep2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblbep9 As Global.System.Windows.Forms.Control = Me.lblbep2
			point = New Global.System.Drawing.Point(3, 26)
			lblbep9.Location = point
			Me.lblbep2.Name = "lblbep2"
			Dim lblbep10 As Global.System.Windows.Forms.Control = Me.lblbep2
			size = New Global.System.Drawing.Size(45, 16)
			lblbep10.Size = size
			Me.lblbep2.TabIndex = 107
			Me.lblbep2.Tag = "CR0067"
			Me.lblbep2.Text = "BẾP 2"
			Me.btnDMBEP4.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMBEP7 As Global.System.Windows.Forms.Control = Me.btnDMBEP4
			point = New Global.System.Drawing.Point(377, 0)
			btnDMBEP7.Location = point
			Me.btnDMBEP4.Name = "btnDMBEP4"
			Dim btnDMBEP8 As Global.System.Windows.Forms.Control = Me.btnDMBEP4
			size = New Global.System.Drawing.Size(31, 24)
			btnDMBEP8.Size = size
			Me.btnDMBEP4.TabIndex = 106
			Me.btnDMBEP4.Tag = "CB0011"
			Me.btnDMBEP4.UseVisualStyleBackColor = True
			Me.txtbep2.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtbep9 As Global.System.Windows.Forms.Control = Me.txtbep2
			point = New Global.System.Drawing.Point(56, 24)
			txtbep9.Location = point
			Me.txtbep2.Name = "txtbep2"
			Dim txtbep10 As Global.System.Windows.Forms.Control = Me.txtbep2
			size = New Global.System.Drawing.Size(46, 22)
			txtbep10.Size = size
			Me.txtbep2.TabIndex = 105
			Me.txtbep2.Tag = "0R0000"
			Me.txtTENBEP4.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENBEP7 As Global.System.Windows.Forms.Control = Me.txtTENBEP4
			point = New Global.System.Drawing.Point(410, 1)
			txtTENBEP7.Location = point
			Me.txtTENBEP4.Name = "txtTENBEP4"
			Dim txtTENBEP8 As Global.System.Windows.Forms.Control = Me.txtTENBEP4
			size = New Global.System.Drawing.Size(123, 22)
			txtTENBEP8.Size = size
			Me.txtTENBEP4.TabIndex = 108
			Me.txtTENBEP4.TabStop = False
			Me.txtTENBEP4.Tag = "0R0000"
			Me.btnDMBEP2.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMBEP9 As Global.System.Windows.Forms.Control = Me.btnDMBEP2
			point = New Global.System.Drawing.Point(103, 23)
			btnDMBEP9.Location = point
			Me.btnDMBEP2.Name = "btnDMBEP2"
			Dim btnDMBEP10 As Global.System.Windows.Forms.Control = Me.btnDMBEP2
			size = New Global.System.Drawing.Size(31, 24)
			btnDMBEP10.Size = size
			Me.btnDMBEP2.TabIndex = 106
			Me.btnDMBEP2.Tag = "CB0011"
			Me.btnDMBEP2.UseVisualStyleBackColor = True
			Me.txtTENBEP2.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENBEP9 As Global.System.Windows.Forms.Control = Me.txtTENBEP2
			point = New Global.System.Drawing.Point(135, 24)
			txtTENBEP9.Location = point
			Me.txtTENBEP2.Name = "txtTENBEP2"
			Dim txtTENBEP10 As Global.System.Windows.Forms.Control = Me.txtTENBEP2
			size = New Global.System.Drawing.Size(123, 22)
			txtTENBEP10.Size = size
			Me.txtTENBEP2.TabIndex = 108
			Me.txtTENBEP2.TabStop = False
			Me.txtTENBEP2.Tag = "0R0000"
			Me.lblbep1.AutoSize = True
			Me.lblbep1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblbep11 As Global.System.Windows.Forms.Control = Me.lblbep1
			point = New Global.System.Drawing.Point(3, 5)
			lblbep11.Location = point
			Me.lblbep1.Name = "lblbep1"
			Dim lblbep12 As Global.System.Windows.Forms.Control = Me.lblbep1
			size = New Global.System.Drawing.Size(45, 16)
			lblbep12.Size = size
			Me.lblbep1.TabIndex = 103
			Me.lblbep1.Tag = "CR0066"
			Me.lblbep1.Text = "BẾP 1"
			Me.txtbep1.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtbep11 As Global.System.Windows.Forms.Control = Me.txtbep1
			point = New Global.System.Drawing.Point(56, 1)
			txtbep11.Location = point
			Me.txtbep1.Name = "txtbep1"
			Dim txtbep12 As Global.System.Windows.Forms.Control = Me.txtbep1
			size = New Global.System.Drawing.Size(46, 22)
			txtbep12.Size = size
			Me.txtbep1.TabIndex = 101
			Me.txtbep1.Tag = "0R0000"
			Me.btnDMBEP1.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMBEP11 As Global.System.Windows.Forms.Control = Me.btnDMBEP1
			point = New Global.System.Drawing.Point(103, 0)
			btnDMBEP11.Location = point
			Me.btnDMBEP1.Name = "btnDMBEP1"
			Dim btnDMBEP12 As Global.System.Windows.Forms.Control = Me.btnDMBEP1
			size = New Global.System.Drawing.Size(31, 24)
			btnDMBEP12.Size = size
			Me.btnDMBEP1.TabIndex = 102
			Me.btnDMBEP1.Tag = "CB0011"
			Me.btnDMBEP1.UseVisualStyleBackColor = True
			Me.txtTENBEP1.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENBEP11 As Global.System.Windows.Forms.Control = Me.txtTENBEP1
			point = New Global.System.Drawing.Point(135, 1)
			txtTENBEP11.Location = point
			Me.txtTENBEP1.Name = "txtTENBEP1"
			Dim txtTENBEP12 As Global.System.Windows.Forms.Control = Me.txtTENBEP1
			size = New Global.System.Drawing.Size(123, 22)
			txtTENBEP12.Size = size
			Me.txtTENBEP1.TabIndex = 104
			Me.txtTENBEP1.TabStop = False
			Me.txtTENBEP1.Tag = "0R0000"
			Me.grbTONKHO.Controls.Add(Me.Label11)
			Me.grbTONKHO.Controls.Add(Me.mtbOutDate)
			Me.grbTONKHO.Controls.Add(Me.lblOUTDATE)
			Me.grbTONKHO.Controls.Add(Me.Label6)
			Me.grbTONKHO.Controls.Add(Me.txtTT)
			Me.grbTONKHO.Controls.Add(Me.Label5)
			Me.grbTONKHO.Controls.Add(Me.txtDG)
			Me.grbTONKHO.Controls.Add(Me.Label4)
			Me.grbTONKHO.Controls.Add(Me.txtSL)
			Me.grbTONKHO.Controls.Add(Me.Label3)
			Me.grbTONKHO.Controls.Add(Me.txtMAKH)
			Me.grbTONKHO.Controls.Add(Me.btnDMKH)
			Me.grbTONKHO.Controls.Add(Me.txtTENKH)
			Dim grbTONKHO As Global.System.Windows.Forms.Control = Me.grbTONKHO
			point = New Global.System.Drawing.Point(537, 289)
			grbTONKHO.Location = point
			Me.grbTONKHO.Name = "grbTONKHO"
			Dim grbTONKHO2 As Global.System.Windows.Forms.Control = Me.grbTONKHO
			size = New Global.System.Drawing.Size(134, 340)
			grbTONKHO2.Size = size
			Me.grbTONKHO.TabIndex = 113
			Me.grbTONKHO.TabStop = False
			Me.grbTONKHO.Tag = ""
			Me.grbTONKHO.Visible = False
			Dim label21 As Global.System.Windows.Forms.Control = Me.Label11
			point = New Global.System.Drawing.Point(7, 13)
			label21.Location = point
			Me.Label11.Name = "Label11"
			Dim label22 As Global.System.Windows.Forms.Control = Me.Label11
			size = New Global.System.Drawing.Size(119, 52)
			label22.Size = size
			Me.Label11.TabIndex = 125
			Me.Label11.Tag = "CR0077"
			Me.Label11.Text = "Tồn kho ban đầu - Chỉ cập nhật khi chưa có khóa sổ"
			Me.mtbOutDate.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.mtbOutDate.ImeMode = Global.System.Windows.Forms.ImeMode.NoControl
			Dim mtbOutDate As Global.System.Windows.Forms.Control = Me.mtbOutDate
			point = New Global.System.Drawing.Point(6, 165)
			mtbOutDate.Location = point
			Me.mtbOutDate.Mask = "00/00/0000"
			Me.mtbOutDate.Name = "mtbOutDate"
			Me.mtbOutDate.PromptChar = "-"c
			Dim mtbOutDate2 As Global.System.Windows.Forms.Control = Me.mtbOutDate
			size = New Global.System.Drawing.Size(116, 22)
			mtbOutDate2.Size = size
			Me.mtbOutDate.TabIndex = 1
			Me.mtbOutDate.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.mtbOutDate.ValidatingType = GetType(Global.System.DateTime)
			Me.lblOUTDATE.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOUTDATE As Global.System.Windows.Forms.Control = Me.lblOUTDATE
			point = New Global.System.Drawing.Point(3, 143)
			lblOUTDATE.Location = point
			Me.lblOUTDATE.Name = "lblOUTDATE"
			Dim lblOUTDATE2 As Global.System.Windows.Forms.Control = Me.lblOUTDATE
			size = New Global.System.Drawing.Size(73, 21)
			lblOUTDATE2.Size = size
			Me.lblOUTDATE.TabIndex = 124
			Me.lblOUTDATE.Tag = "CR0082"
			Me.lblOUTDATE.Text = "han dung"
			Me.Label6.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label23 As Global.System.Windows.Forms.Control = Me.Label6
			point = New Global.System.Drawing.Point(3, 293)
			label23.Location = point
			Me.Label6.Name = "Label6"
			Dim label24 As Global.System.Windows.Forms.Control = Me.Label6
			size = New Global.System.Drawing.Size(73, 21)
			label24.Size = size
			Me.Label6.TabIndex = 122
			Me.Label6.Tag = "CR0081"
			Me.Label6.Text = "thanh tien"
			Me.txtTT.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtTT As Global.System.Windows.Forms.Control = Me.txtTT
			point = New Global.System.Drawing.Point(6, 314)
			txtTT.Location = point
			Me.txtTT.Name = "txtTT"
			Dim txtTT2 As Global.System.Windows.Forms.Control = Me.txtTT
			size = New Global.System.Drawing.Size(116, 22)
			txtTT2.Size = size
			Me.txtTT.TabIndex = 4
			Me.txtTT.Tag = "0R0000"
			Me.txtTT.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label5.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label25 As Global.System.Windows.Forms.Control = Me.Label5
			point = New Global.System.Drawing.Point(3, 244)
			label25.Location = point
			Me.Label5.Name = "Label5"
			Dim label26 As Global.System.Windows.Forms.Control = Me.Label5
			size = New Global.System.Drawing.Size(61, 21)
			label26.Size = size
			Me.Label5.TabIndex = 120
			Me.Label5.Tag = "CR0080"
			Me.Label5.Text = "don gia"
			Me.txtDG.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtDG As Global.System.Windows.Forms.Control = Me.txtDG
			point = New Global.System.Drawing.Point(6, 268)
			txtDG.Location = point
			Me.txtDG.Name = "txtDG"
			Dim txtDG2 As Global.System.Windows.Forms.Control = Me.txtDG
			size = New Global.System.Drawing.Size(116, 22)
			txtDG2.Size = size
			Me.txtDG.TabIndex = 3
			Me.txtDG.Tag = "0R0000"
			Me.txtDG.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label4.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label27 As Global.System.Windows.Forms.Control = Me.Label4
			point = New Global.System.Drawing.Point(3, 193)
			label27.Location = point
			Me.Label4.Name = "Label4"
			Dim label28 As Global.System.Windows.Forms.Control = Me.Label4
			size = New Global.System.Drawing.Size(90, 21)
			label28.Size = size
			Me.Label4.TabIndex = 118
			Me.Label4.Tag = "CR0079"
			Me.Label4.Text = "so luong"
			Me.txtSL.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtSL As Global.System.Windows.Forms.Control = Me.txtSL
			point = New Global.System.Drawing.Point(6, 217)
			txtSL.Location = point
			Me.txtSL.Name = "txtSL"
			Dim txtSL2 As Global.System.Windows.Forms.Control = Me.txtSL
			size = New Global.System.Drawing.Size(116, 22)
			txtSL2.Size = size
			Me.txtSL.TabIndex = 2
			Me.txtSL.Tag = "0R0000"
			Me.txtSL.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label3.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label29 As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(3, 66)
			label29.Location = point
			Me.Label3.Name = "Label3"
			Dim label30 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(93, 21)
			label30.Size = size
			Me.Label3.TabIndex = 115
			Me.Label3.Tag = "CR0078"
			Me.Label3.Text = "ma kho"
			Me.txtMAKH.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAKH As Global.System.Windows.Forms.Control = Me.txtMAKH
			point = New Global.System.Drawing.Point(6, 89)
			txtMAKH.Location = point
			Me.txtMAKH.Name = "txtMAKH"
			Dim txtMAKH2 As Global.System.Windows.Forms.Control = Me.txtMAKH
			size = New Global.System.Drawing.Size(84, 22)
			txtMAKH2.Size = size
			Me.txtMAKH.TabIndex = 0
			Me.txtMAKH.Tag = "0R0000"
			Me.btnDMKH.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMKH As Global.System.Windows.Forms.Control = Me.btnDMKH
			point = New Global.System.Drawing.Point(92, 88)
			btnDMKH.Location = point
			Me.btnDMKH.Name = "btnDMKH"
			Dim btnDMKH2 As Global.System.Windows.Forms.Control = Me.btnDMKH
			size = New Global.System.Drawing.Size(31, 22)
			btnDMKH2.Size = size
			Me.btnDMKH.TabIndex = 114
			Me.btnDMKH.Tag = "CB0011"
			Me.btnDMKH.UseVisualStyleBackColor = True
			Me.txtTENKH.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENKH As Global.System.Windows.Forms.Control = Me.txtTENKH
			point = New Global.System.Drawing.Point(6, 117)
			txtTENKH.Location = point
			Me.txtTENKH.Name = "txtTENKH"
			Dim txtTENKH2 As Global.System.Windows.Forms.Control = Me.txtTENKH
			size = New Global.System.Drawing.Size(116, 22)
			txtTENKH2.Size = size
			Me.txtTENKH.TabIndex = 116
			Me.txtTENKH.TabStop = False
			Me.txtTENKH.Tag = "0R0000"
			Me.picZoom.BackColor = Global.System.Drawing.Color.White
			Me.picZoom.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.picZoom.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Dim picZoom As Global.System.Windows.Forms.Control = Me.picZoom
			point = New Global.System.Drawing.Point(450, 3)
			picZoom.Location = point
			Me.picZoom.Name = "picZoom"
			Dim picZoom2 As Global.System.Windows.Forms.Control = Me.picZoom
			size = New Global.System.Drawing.Size(225, 273)
			picZoom2.Size = size
			Me.picZoom.TabIndex = 118
			Me.picZoom.TabStop = False
			Me.picZoom.Visible = False
			Me.txtBuocNhayGia.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtBuocNhayGia As Global.System.Windows.Forms.Control = Me.txtBuocNhayGia
			point = New Global.System.Drawing.Point(541, 27)
			txtBuocNhayGia.Location = point
			Me.txtBuocNhayGia.Name = "txtBuocNhayGia"
			Dim txtBuocNhayGia2 As Global.System.Windows.Forms.Control = Me.txtBuocNhayGia
			size = New Global.System.Drawing.Size(122, 22)
			txtBuocNhayGia2.Size = size
			Me.txtBuocNhayGia.TabIndex = 15
			Me.txtBuocNhayGia.Tag = "0R0000"
			Me.txtBuocNhayGia.Text = "0"
			Me.txtBuocNhayGia.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.txtBuocNhayGia.Visible = False
			Me.lblBuocNhayGia.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblBuocNhayGia As Global.System.Windows.Forms.Control = Me.lblBuocNhayGia
			point = New Global.System.Drawing.Point(541, 4)
			lblBuocNhayGia.Location = point
			Me.lblBuocNhayGia.Name = "lblBuocNhayGia"
			Dim lblBuocNhayGia2 As Global.System.Windows.Forms.Control = Me.lblBuocNhayGia
			size = New Global.System.Drawing.Size(112, 21)
			lblBuocNhayGia2.Size = size
			Me.lblBuocNhayGia.TabIndex = 52
			Me.lblBuocNhayGia.Tag = "CR0102"
			Me.lblBuocNhayGia.Text = "Bước nhảy giá"
			Me.lblBuocNhayGia.Visible = False
			Me.GroupBox2.Controls.Add(Me.txtTiLeDVT)
			Me.GroupBox2.Controls.Add(Me.lblTiLeDVT)
			Dim groupBox As Global.System.Windows.Forms.Control = Me.GroupBox2
			point = New Global.System.Drawing.Point(538, 160)
			groupBox.Location = point
			Me.GroupBox2.Name = "GroupBox2"
			Dim groupBox2 As Global.System.Windows.Forms.Control = Me.GroupBox2
			size = New Global.System.Drawing.Size(134, 66)
			groupBox2.Size = size
			Me.GroupBox2.TabIndex = 129
			Me.GroupBox2.TabStop = False
			Me.txtTiLeDVT.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtTiLeDVT As Global.System.Windows.Forms.Control = Me.txtTiLeDVT
			point = New Global.System.Drawing.Point(10, 37)
			txtTiLeDVT.Location = point
			Me.txtTiLeDVT.Name = "txtTiLeDVT"
			Dim txtTiLeDVT2 As Global.System.Windows.Forms.Control = Me.txtTiLeDVT
			size = New Global.System.Drawing.Size(115, 22)
			txtTiLeDVT2.Size = size
			Me.txtTiLeDVT.TabIndex = 118
			Me.txtTiLeDVT.Tag = "0R0000"
			Me.txtTiLeDVT.Text = "1"
			Me.txtTiLeDVT.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.lblTiLeDVT.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblTiLeDVT As Global.System.Windows.Forms.Control = Me.lblTiLeDVT
			point = New Global.System.Drawing.Point(3, 17)
			lblTiLeDVT.Location = point
			Me.lblTiLeDVT.Name = "lblTiLeDVT"
			Dim lblTiLeDVT2 As Global.System.Windows.Forms.Control = Me.lblTiLeDVT
			size = New Global.System.Drawing.Size(128, 17)
			lblTiLeDVT2.Size = size
			Me.lblTiLeDVT.TabIndex = 119
			Me.lblTiLeDVT.Tag = "CR0102"
			Me.lblTiLeDVT.Text = "1 ABC = ? CBD"
			Me.lblTiLeDVT.TextAlign = Global.System.Drawing.ContentAlignment.TopCenter
			Me.GroupBox1.Controls.Add(Me.Label13)
			Me.GroupBox1.Controls.Add(Me.txtTHOIKHOANG)
			Me.GroupBox1.Controls.Add(Me.Label16)
			Me.GroupBox1.Controls.Add(Me.Label14)
			Me.GroupBox1.Controls.Add(Me.txtTienHoaHong)
			Me.GroupBox1.Controls.Add(Me.txtHOAHONG)
			Me.GroupBox1.Controls.Add(Me.Label15)
			Dim groupBox3 As Global.System.Windows.Forms.Control = Me.GroupBox1
			point = New Global.System.Drawing.Point(539, 52)
			groupBox3.Location = point
			Me.GroupBox1.Name = "GroupBox1"
			Dim groupBox4 As Global.System.Windows.Forms.Control = Me.GroupBox1
			size = New Global.System.Drawing.Size(135, 103)
			groupBox4.Size = size
			Me.GroupBox1.TabIndex = 128
			Me.GroupBox1.TabStop = False
			Me.Label13.AutoSize = True
			Me.Label13.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label31 As Global.System.Windows.Forms.Control = Me.Label13
			point = New Global.System.Drawing.Point(5, 13)
			label31.Location = point
			Me.Label13.Name = "Label13"
			Dim label32 As Global.System.Windows.Forms.Control = Me.Label13
			size = New Global.System.Drawing.Size(88, 16)
			label32.Size = size
			Me.Label13.TabIndex = 124
			Me.Label13.Tag = "CR0103"
			Me.Label13.Text = "Thời khoảng"
			Me.txtTHOIKHOANG.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtTHOIKHOANG As Global.System.Windows.Forms.Control = Me.txtTHOIKHOANG
			point = New Global.System.Drawing.Point(5, 33)
			txtTHOIKHOANG.Location = point
			Me.txtTHOIKHOANG.Name = "txtTHOIKHOANG"
			Dim txtTHOIKHOANG2 As Global.System.Windows.Forms.Control = Me.txtTHOIKHOANG
			size = New Global.System.Drawing.Size(86, 22)
			txtTHOIKHOANG2.Size = size
			Me.txtTHOIKHOANG.TabIndex = 121
			Me.txtTHOIKHOANG.Tag = "0R0000"
			Me.txtTHOIKHOANG.Text = "0"
			Me.txtTHOIKHOANG.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label16.AutoSize = True
			Me.Label16.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label33 As Global.System.Windows.Forms.Control = Me.Label16
			point = New Global.System.Drawing.Point(41, 82)
			label33.Location = point
			Me.Label16.Name = "Label16"
			Dim label34 As Global.System.Windows.Forms.Control = Me.Label16
			size = New Global.System.Drawing.Size(18, 16)
			label34.Size = size
			Me.Label16.TabIndex = 125
			Me.Label16.Tag = "CR0106"
			Me.Label16.Text = "%"
			Me.Label14.AutoSize = True
			Me.Label14.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label35 As Global.System.Windows.Forms.Control = Me.Label14
			point = New Global.System.Drawing.Point(5, 59)
			label35.Location = point
			Me.Label14.Name = "Label14"
			Dim label36 As Global.System.Windows.Forms.Control = Me.Label14
			size = New Global.System.Drawing.Size(69, 16)
			label36.Size = size
			Me.Label14.TabIndex = 122
			Me.Label14.Tag = "CR0104"
			Me.Label14.Text = "Hoa hồng"
			Me.txtTienHoaHong.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtTienHoaHong As Global.System.Windows.Forms.Control = Me.txtTienHoaHong
			point = New Global.System.Drawing.Point(61, 78)
			txtTienHoaHong.Location = point
			Me.txtTienHoaHong.Name = "txtTienHoaHong"
			Me.txtTienHoaHong.[ReadOnly] = True
			Dim txtTienHoaHong2 As Global.System.Windows.Forms.Control = Me.txtTienHoaHong
			size = New Global.System.Drawing.Size(69, 22)
			txtTienHoaHong2.Size = size
			Me.txtTienHoaHong.TabIndex = 120
			Me.txtTienHoaHong.Tag = "0R0000"
			Me.txtTienHoaHong.Text = "0"
			Me.txtTienHoaHong.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.txtHOAHONG.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtHOAHONG As Global.System.Windows.Forms.Control = Me.txtHOAHONG
			point = New Global.System.Drawing.Point(3, 78)
			txtHOAHONG.Location = point
			Me.txtHOAHONG.Name = "txtHOAHONG"
			Me.txtHOAHONG.[ReadOnly] = True
			Dim txtHOAHONG2 As Global.System.Windows.Forms.Control = Me.txtHOAHONG
			size = New Global.System.Drawing.Size(37, 22)
			txtHOAHONG2.Size = size
			Me.txtHOAHONG.TabIndex = 120
			Me.txtHOAHONG.Tag = "0R0000"
			Me.txtHOAHONG.Text = "0"
			Me.txtHOAHONG.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label15.AutoSize = True
			Me.Label15.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label37 As Global.System.Windows.Forms.Control = Me.Label15
			point = New Global.System.Drawing.Point(94, 35)
			label37.Location = point
			Me.Label15.Name = "Label15"
			Dim label38 As Global.System.Windows.Forms.Control = Me.Label15
			size = New Global.System.Drawing.Size(37, 16)
			label38.Size = size
			Me.Label15.TabIndex = 123
			Me.Label15.Tag = "CR0105"
			Me.Label15.Text = "Phút"
			Me.GroupBox3.Controls.Add(Me.Label17)
			Me.GroupBox3.Controls.Add(Me.txtScore)
			Dim groupBox5 As Global.System.Windows.Forms.Control = Me.GroupBox3
			point = New Global.System.Drawing.Point(538, 228)
			groupBox5.Location = point
			Me.GroupBox3.Name = "GroupBox3"
			Dim groupBox6 As Global.System.Windows.Forms.Control = Me.GroupBox3
			size = New Global.System.Drawing.Size(134, 63)
			groupBox6.Size = size
			Me.GroupBox3.TabIndex = 130
			Me.GroupBox3.TabStop = False
			Me.Label17.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label39 As Global.System.Windows.Forms.Control = Me.Label17
			point = New Global.System.Drawing.Point(3, 13)
			label39.Location = point
			Me.Label17.Name = "Label17"
			Dim label40 As Global.System.Windows.Forms.Control = Me.Label17
			size = New Global.System.Drawing.Size(128, 17)
			label40.Size = size
			Me.Label17.TabIndex = 124
			Me.Label17.Tag = "CR0108"
			Me.Label17.Text = "Điểm thưởng"
			Me.Label17.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.txtScore.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtScore As Global.System.Windows.Forms.Control = Me.txtScore
			point = New Global.System.Drawing.Point(10, 33)
			txtScore.Location = point
			Me.txtScore.Name = "txtScore"
			Dim txtScore2 As Global.System.Windows.Forms.Control = Me.txtScore
			size = New Global.System.Drawing.Size(115, 22)
			txtScore2.Size = size
			Me.txtScore.TabIndex = 123
			Me.txtScore.Tag = "0R0000"
			Me.txtScore.Text = "1"
			Me.txtScore.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.panMAMT2.Controls.Add(Me.txtMAMT2)
			Me.panMAMT2.Controls.Add(Me.txtTENMT2)
			Me.panMAMT2.Controls.Add(Me.btnDMMT2)
			Me.panMAMT2.Controls.Add(Me.Label18)
			Dim panMAMT3 As Global.System.Windows.Forms.Control = Me.panMAMT2
			point = New Global.System.Drawing.Point(0, 191)
			panMAMT3.Location = point
			Me.panMAMT2.Name = "panMAMT2"
			Dim panMAMT4 As Global.System.Windows.Forms.Control = Me.panMAMT2
			size = New Global.System.Drawing.Size(535, 24)
			panMAMT4.Size = size
			Me.panMAMT2.TabIndex = 131
			Me.txtMAMT2.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAMT3 As Global.System.Windows.Forms.Control = Me.txtMAMT2
			point = New Global.System.Drawing.Point(162, 1)
			txtMAMT3.Location = point
			Me.txtMAMT2.Name = "txtMAMT2"
			Dim txtMAMT4 As Global.System.Windows.Forms.Control = Me.txtMAMT2
			size = New Global.System.Drawing.Size(122, 22)
			txtMAMT4.Size = size
			Me.txtMAMT2.TabIndex = 0
			Me.txtMAMT2.Tag = "0R0000"
			Me.txtTENMT2.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENMT3 As Global.System.Windows.Forms.Control = Me.txtTENMT2
			point = New Global.System.Drawing.Point(341, 1)
			txtTENMT3.Location = point
			Me.txtTENMT2.Name = "txtTENMT2"
			Dim txtTENMT4 As Global.System.Windows.Forms.Control = Me.txtTENMT2
			size = New Global.System.Drawing.Size(191, 22)
			txtTENMT4.Size = size
			Me.txtTENMT2.TabIndex = 100
			Me.txtTENMT2.TabStop = False
			Me.txtTENMT2.Tag = "0R0000"
			Me.btnDMMT2.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMMT3 As Global.System.Windows.Forms.Control = Me.btnDMMT2
			point = New Global.System.Drawing.Point(290, 1)
			btnDMMT3.Location = point
			Me.btnDMMT2.Name = "btnDMMT2"
			Dim btnDMMT4 As Global.System.Windows.Forms.Control = Me.btnDMMT2
			size = New Global.System.Drawing.Size(45, 22)
			btnDMMT4.Size = size
			Me.btnDMMT2.TabIndex = 8
			Me.btnDMMT2.Tag = "CB0011"
			Me.btnDMMT2.UseVisualStyleBackColor = True
			Me.Label18.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label41 As Global.System.Windows.Forms.Control = Me.Label18
			point = New Global.System.Drawing.Point(7, 3)
			label41.Location = point
			Me.Label18.Name = "Label18"
			Dim label42 As Global.System.Windows.Forms.Control = Me.Label18
			size = New Global.System.Drawing.Size(111, 16)
			label42.Size = size
			Me.Label18.TabIndex = 39
			Me.Label18.Tag = "CR0109"
			Me.Label18.Text = "Mã mức thuế 2"
			Me.chkLQtyLe.AutoSize = True
			Me.chkLQtyLe.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkLQtyLe As Global.System.Windows.Forms.Control = Me.chkLQtyLe
			point = New Global.System.Drawing.Point(515, 98)
			chkLQtyLe.Location = point
			Me.chkLQtyLe.Name = "chkLQtyLe"
			Dim chkLQtyLe2 As Global.System.Windows.Forms.Control = Me.chkLQtyLe
			size = New Global.System.Drawing.Size(15, 14)
			chkLQtyLe2.Size = size
			Me.chkLQtyLe.TabIndex = 117
			Me.chkLQtyLe.Tag = "0R0000"
			Me.chkLQtyLe.UseVisualStyleBackColor = True
			Me.Label22.AutoSize = True
			Me.Label22.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label43 As Global.System.Windows.Forms.Control = Me.Label22
			point = New Global.System.Drawing.Point(405, 96)
			label43.Location = point
			Me.Label22.Name = "Label22"
			Dim label44 As Global.System.Windows.Forms.Control = Me.Label22
			size = New Global.System.Drawing.Size(83, 16)
			label44.Size = size
			Me.Label22.TabIndex = 118
			Me.Label22.Tag = "CR0113"
			Me.Label22.Text = "Số lượng lẻ"
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(794, 631)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.picZoom)
			Me.Controls.Add(Me.panMAMT2)
			Me.Controls.Add(Me.GroupBox3)
			Me.Controls.Add(Me.GroupBox2)
			Me.Controls.Add(Me.GroupBox1)
			Me.Controls.Add(Me.grbTONKHO)
			Me.Controls.Add(Me.panButton)
			Me.Controls.Add(Me.txtBuocNhayGia)
			Me.Controls.Add(Me.lblBuocNhayGia)
			Me.Controls.Add(Me.panREMARK)
			Me.Controls.Add(Me.panLSALE)
			Me.Controls.Add(Me.panPRICE8_9_10)
			Me.Controls.Add(Me.panPRICE5_6_7)
			Me.Controls.Add(Me.panPRICE2_3_4)
			Me.Controls.Add(Me.panPRICE)
			Me.Controls.Add(Me.txtTENNH)
			Me.Controls.Add(Me.lblOBJID)
			Me.Controls.Add(Me.txtOBJID)
			Me.Controls.Add(Me.txtOBJNAME)
			Me.Controls.Add(Me.lblOBJNAME)
			Me.Controls.Add(Me.txtMADVT)
			Me.Controls.Add(Me.txtMANH)
			Me.Controls.Add(Me.btnDMNH)
			Me.Controls.Add(Me.lblDVT)
			Me.Controls.Add(Me.lblMANH)
			Me.Controls.Add(Me.txtSUBOBJNAME)
			Me.Controls.Add(Me.lblSUBOBJNAME)
			Me.Controls.Add(Me.panLMATERIAL)
			Me.Controls.Add(Me.panMAPL_MANSX)
			Me.Controls.Add(Me.panMAMT)
			Me.Controls.Add(Me.panMain)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMHH2"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Tag = "       "
			Me.Text = "Chi tiết DMHH"
			Me.panMain.ResumeLayout(False)
			Me.panMain.PerformLayout()
			Me.panMAMT.ResumeLayout(False)
			Me.panMAMT.PerformLayout()
			Me.panMAPL_MANSX.ResumeLayout(False)
			Me.panMAPL_MANSX.PerformLayout()
			Me.panLMATERIAL.ResumeLayout(False)
			Me.panLMATERIAL.PerformLayout()
			Me.panPRICE.ResumeLayout(False)
			Me.panPRICE.PerformLayout()
			Me.panPRICE2_3_4.ResumeLayout(False)
			Me.panPRICE2_3_4.PerformLayout()
			Me.panPRICE5_6_7.ResumeLayout(False)
			Me.panPRICE5_6_7.PerformLayout()
			Me.panPRICE8_9_10.ResumeLayout(False)
			Me.panPRICE8_9_10.PerformLayout()
			Me.panLSALE.ResumeLayout(False)
			Me.panLSALE.PerformLayout()
			Me.panButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			CType(Me.picAnh, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.panREMARK.ResumeLayout(False)
			Me.panREMARK.PerformLayout()
			Me.grbTONKHO.ResumeLayout(False)
			Me.grbTONKHO.PerformLayout()
			CType(Me.picZoom, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.GroupBox2.ResumeLayout(False)
			Me.GroupBox2.PerformLayout()
			Me.GroupBox1.ResumeLayout(False)
			Me.GroupBox1.PerformLayout()
			Me.GroupBox3.ResumeLayout(False)
			Me.GroupBox3.PerformLayout()
			Me.panMAMT2.ResumeLayout(False)
			Me.panMAMT2.PerformLayout()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x0400091F RID: 2335
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
