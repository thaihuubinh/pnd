﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000027 RID: 39
	<DesignerGenerated()>
	Public Partial Class frmCOMBO
		Inherits Form

		' Token: 0x06000769 RID: 1897 RVA: 0x000572AC File Offset: 0x000554AC
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDOCUMENT017_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDOCUMENT017_Load
			frmCOMBO.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mbytSuccess = 0
			Me.mStrDMMA = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x170002D8 RID: 728
		' (get) Token: 0x0600076C RID: 1900 RVA: 0x00057DA4 File Offset: 0x00055FA4
		' (set) Token: 0x0600076D RID: 1901 RVA: 0x00003422 File Offset: 0x00001622
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x170002D9 RID: 729
		' (get) Token: 0x0600076E RID: 1902 RVA: 0x00057DBC File Offset: 0x00055FBC
		' (set) Token: 0x0600076F RID: 1903 RVA: 0x00057DD4 File Offset: 0x00055FD4
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x170002DA RID: 730
		' (get) Token: 0x06000770 RID: 1904 RVA: 0x00057E40 File Offset: 0x00056040
		' (set) Token: 0x06000771 RID: 1905 RVA: 0x00057E58 File Offset: 0x00056058
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x170002DB RID: 731
		' (get) Token: 0x06000772 RID: 1906 RVA: 0x00057EC4 File Offset: 0x000560C4
		' (set) Token: 0x06000773 RID: 1907 RVA: 0x0000342C File Offset: 0x0000162C
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x170002DC RID: 732
		' (get) Token: 0x06000774 RID: 1908 RVA: 0x00057EDC File Offset: 0x000560DC
		' (set) Token: 0x06000775 RID: 1909 RVA: 0x00057EF4 File Offset: 0x000560F4
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x170002DD RID: 733
		' (get) Token: 0x06000776 RID: 1910 RVA: 0x00057F60 File Offset: 0x00056160
		' (set) Token: 0x06000777 RID: 1911 RVA: 0x00057F78 File Offset: 0x00056178
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x170002DE RID: 734
		' (get) Token: 0x06000778 RID: 1912 RVA: 0x00057FE4 File Offset: 0x000561E4
		' (set) Token: 0x06000779 RID: 1913 RVA: 0x00003436 File Offset: 0x00001636
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170002DF RID: 735
		' (get) Token: 0x0600077A RID: 1914 RVA: 0x00057FFC File Offset: 0x000561FC
		' (set) Token: 0x0600077B RID: 1915 RVA: 0x00058014 File Offset: 0x00056214
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170002E0 RID: 736
		' (get) Token: 0x0600077C RID: 1916 RVA: 0x00058080 File Offset: 0x00056280
		' (set) Token: 0x0600077D RID: 1917 RVA: 0x00058098 File Offset: 0x00056298
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.CellClick, AddressOf Me.dgvData_CellClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.CellClick, AddressOf Me.dgvData_CellClick
				End If
			End Set
		End Property

		' Token: 0x170002E1 RID: 737
		' (get) Token: 0x0600077E RID: 1918 RVA: 0x00058104 File Offset: 0x00056304
		' (set) Token: 0x0600077F RID: 1919 RVA: 0x0005811C File Offset: 0x0005631C
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170002E2 RID: 738
		' (get) Token: 0x06000780 RID: 1920 RVA: 0x00058188 File Offset: 0x00056388
		' (set) Token: 0x06000781 RID: 1921 RVA: 0x00003440 File Offset: 0x00001640
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170002E3 RID: 739
		' (get) Token: 0x06000782 RID: 1922 RVA: 0x000581A0 File Offset: 0x000563A0
		' (set) Token: 0x06000783 RID: 1923 RVA: 0x000581B8 File Offset: 0x000563B8
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170002E4 RID: 740
		' (get) Token: 0x06000784 RID: 1924 RVA: 0x00058224 File Offset: 0x00056424
		' (set) Token: 0x06000785 RID: 1925 RVA: 0x0000344A File Offset: 0x0000164A
		Public Property pStrDMMA As String
			Get
				Return Me.mStrDMMA
			End Get
			Set(value As String)
				Me.mStrDMMA = value
			End Set
		End Property

		' Token: 0x170002E5 RID: 741
		' (get) Token: 0x06000786 RID: 1926 RVA: 0x0005823C File Offset: 0x0005643C
		' (set) Token: 0x06000787 RID: 1927 RVA: 0x00003455 File Offset: 0x00001655
		Public Property pBytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x170002E6 RID: 742
		' (get) Token: 0x06000788 RID: 1928 RVA: 0x00058254 File Offset: 0x00056454
		' (set) Token: 0x06000789 RID: 1929 RVA: 0x00003460 File Offset: 0x00001660
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x0600078A RID: 1930 RVA: 0x0005826C File Offset: 0x0005646C
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600078B RID: 1931 RVA: 0x0005833C File Offset: 0x0005653C
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600078C RID: 1932 RVA: 0x0005842C File Offset: 0x0005662C
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600078D RID: 1933 RVA: 0x00058510 File Offset: 0x00056710
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600078E RID: 1934 RVA: 0x000585D4 File Offset: 0x000567D4
		Private Sub frmDOCUMENT017_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDOCUMENT017_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600078F RID: 1935 RVA: 0x0005866C File Offset: 0x0005686C
		Private Sub frmDOCUMENT017_Load(sender As Object, e As EventArgs)
			Try
				mdlFile.gfWriteLogFile("Mở form chọn món combo.")
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.gf_GetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
				Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDOCUMENT017_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000790 RID: 1936 RVA: 0x0005878C File Offset: 0x0005698C
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000791 RID: 1937 RVA: 0x00058894 File Offset: 0x00056A94
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				mdlFile.gfWriteLogFile("Nhấn nút Thoát form chọn món combo.")
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000792 RID: 1938 RVA: 0x00058938 File Offset: 0x00056B38
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim num As Integer = 0
				mdlVariable.garrStrCombo = New mdlVariable.struCombo(num + 1 - 1) {}
				Dim text As String = "Chọn các món combo gồm: "
				Dim text2 As String = ""
				Dim num2 As Integer = 0
				Dim num3 As Integer = Me.dgvData.Rows.Count - 1
				Dim num4 As Integer = num2
				While True
					Dim num5 As Integer = num4
					Dim num6 As Integer = num3
					If num5 > num6 Then
						Exit For
					End If
					mdlVariable.garrStrCombo = CType(Utils.CopyArray(CType(mdlVariable.garrStrCombo, Array), New mdlVariable.struCombo(num + 1 - 1) {}), mdlVariable.struCombo())
					mdlVariable.garrStrCombo(num).strMAHH = Me.dgvData.Rows(num4).Cells("OBJID").Value.ToString().Trim()
					mdlVariable.garrStrCombo(num).strTENHH = Me.dgvData.Rows(num4).Cells("OBJNAME").Value.ToString().Trim()
					mdlVariable.garrStrCombo(num).strMADVT = Me.dgvData.Rows(num4).Cells("MADVT").Value.ToString().Trim()
					mdlVariable.garrStrCombo(num).strHANDUNG = Me.dgvData.Rows(num4).Cells("NGAYHETHAN").Value.ToString()
					mdlVariable.garrStrCombo(num).dblQTY = 1.0
					mdlVariable.garrStrCombo(num).dblPRICE = Conversions.ToDouble(Me.dgvData.Rows(num4).Cells("PRICE1").Value.ToString())
					text2 += mdlVariable.garrStrCombo(num).strMAHH.Trim()
					text = text + Me.dgvData.Rows(num4).Cells("OBJNAME").Value.ToString().Trim() + ", "
					num += 1
					num4 += 1
				End While
				mdlFile.gfWriteLogFile(text)
				Dim flag As Boolean = num > 0
				If flag Then
					Me.mStrDMMA = text2.Trim()
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000793 RID: 1939 RVA: 0x00058C2C File Offset: 0x00056E2C
		Private Sub dgvData_CellClick(sender As Object, e As DataGridViewCellEventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean = e.RowIndex < 0
				If Not flag Then
					Dim text As String = Me.dgvData.Rows(e.RowIndex).Cells("MANH").Value.ToString()
					Dim flag2 As Boolean = Conversions.ToBoolean(Me.dgvData.Rows(e.RowIndex).Cells("CHON").Value)
					Dim num As Integer = 0
					Dim num2 As Integer = Me.dgvData.Rows.Count - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						flag = ((Operators.CompareString(Me.dgvData.Rows(num3).Cells("MANH").Value.ToString(), text, False) = 0) And (num3 <> e.RowIndex)) AndAlso Not flag2
						If flag Then
							Me.dgvData.Rows(num3).Cells("CHON").Value = False
						End If
						num3 += 1
					End While
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_CellClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000794 RID: 1940 RVA: 0x00058DE4 File Offset: 0x00056FE4
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.[ReadOnly] = False
				dgvData.Columns("CHON").HeaderText = Strings.Trim(Me.mArrStrFrmMess(33))
				dgvData.Columns("CHON").Width = 60
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("CHON").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("CHON").[ReadOnly] = False
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJID").[ReadOnly] = True
				dgvData.Columns("OBJID").Visible = False
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = Conversions.ToInteger(Operators.SubtractObject(Me.Width - Me.grpControl.Width - 260 - 30 - 130, Interaction.IIf(mdlVariable.gblnSTOCKDATE, 120, 0)))
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").[ReadOnly] = True
				dgvData.Columns("NGAYHETHAN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(31))
				dgvData.Columns("NGAYHETHAN").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("NGAYHETHAN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NGAYHETHAN").[ReadOnly] = True
				dgvData.Columns("DVT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(32))
				dgvData.Columns("DVT").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("DVT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DVT").[ReadOnly] = True
				dgvData.Columns("PRICE1").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("PRICE1").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("PRICE1").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("PRICE1").[ReadOnly] = True
				dgvData.Columns("TENNH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(34))
				dgvData.Columns("TENNH").Width = 130
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENNH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENNH").[ReadOnly] = True
				Dim flag As Boolean = Not mdlVariable.gblnSTOCKDATE
				If flag Then
					dgvData.Columns("NGAYHETHAN").Visible = False
				End If
				dgvData.Columns("MADVT").Visible = False
				dgvData.Columns("MANH").Visible = False
				dgvData.Columns("SOLUONG").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000795 RID: 1941 RVA: 0x0005933C File Offset: 0x0005753C
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnSelect.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000796 RID: 1942 RVA: 0x00059434 File Offset: 0x00057634
		Public Function gf_GetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAKH"
				array(0).Value = mdlVariable.gStrStockCode
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHH_M"
				array(1).Value = ""
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCOMBO_GETDATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					flag = Operators.CompareString(Me.mStrDMMA, "", False) <> 0
					If flag Then
						Me.mbdsSource.Filter = "TRIM(OBJID) IN('" + Strings.Replace(Me.mStrDMMA, ",", "','", 1, -1, CompareMethod.Binary) + "')"
					End If
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gf_GetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000797 RID: 1943 RVA: 0x000595E8 File Offset: 0x000577E8
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000798 RID: 1944 RVA: 0x0005969C File Offset: 0x0005789C
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim text As String = Strings.Trim(mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMKH", "OBJID", mdlVariable.gStrStockCode, "OBJNAME"))
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000799 RID: 1945 RVA: 0x000597EC File Offset: 0x000579EC
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x04000341 RID: 833
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000343 RID: 835
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000344 RID: 836
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000345 RID: 837
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000346 RID: 838
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000347 RID: 839
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000348 RID: 840
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000349 RID: 841
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x0400034A RID: 842
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x0400034B RID: 843
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x0400034C RID: 844
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x0400034D RID: 845
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x0400034E RID: 846
		Private mArrStrFrmMess As String()

		' Token: 0x0400034F RID: 847
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000350 RID: 848
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000351 RID: 849
		Private marrDrFind As DataRow()

		' Token: 0x04000352 RID: 850
		Private mintFindLastPos As Integer

		' Token: 0x04000353 RID: 851
		Private mbytSuccess As Byte

		' Token: 0x04000354 RID: 852
		Private mStrDMMA As String
	End Class
End Namespace
