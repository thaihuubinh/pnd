﻿Namespace prjIS_SalesPOS
	' Token: 0x0200003C RID: 60
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMChat
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000DE7 RID: 3559 RVA: 0x000A41E0 File Offset: 0x000A23E0
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000DE8 RID: 3560 RVA: 0x000A4218 File Offset: 0x000A2418
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Global.System.ComponentModel.Container()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMChat))
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.TableLayoutPanel5 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.txtIn = New Global.System.Windows.Forms.TextBox()
			Me.btnSend = New Global.System.Windows.Forms.Button()
			Me.txtMess = New Global.System.Windows.Forms.RichTextBox()
			Me.Timer1 = New Global.System.Windows.Forms.Timer(Me.components)
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.TableLayoutPanel5.SuspendLayout()
			Me.SuspendLayout()
			Me.btnExit.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.DialogResult = Global.System.Windows.Forms.DialogResult.Cancel
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(400, 3)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(95, 38)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 2
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.UseVisualStyleBackColor = False
			Me.TableLayoutPanel5.ColumnCount = 3
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 60F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel5.Controls.Add(Me.btnExit, 2, 0)
			Me.TableLayoutPanel5.Controls.Add(Me.txtIn, 0, 0)
			Me.TableLayoutPanel5.Controls.Add(Me.btnSend, 1, 0)
			Me.TableLayoutPanel5.Dock = Global.System.Windows.Forms.DockStyle.Bottom
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel5
			point = New Global.System.Drawing.Point(0, 458)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
			Me.TableLayoutPanel5.RowCount = 1
			Me.TableLayoutPanel5.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel5
			size = New Global.System.Drawing.Size(498, 44)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel5.TabIndex = 5
			Me.txtIn.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.txtIn.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtIn As Global.System.Windows.Forms.Control = Me.txtIn
			point = New Global.System.Drawing.Point(3, 3)
			txtIn.Location = point
			Me.txtIn.Multiline = True
			Me.txtIn.Name = "txtIn"
			Dim txtIn2 As Global.System.Windows.Forms.Control = Me.txtIn
			size = New Global.System.Drawing.Size(292, 38)
			txtIn2.Size = size
			Me.txtIn.TabIndex = 0
			Me.btnSend.Dock = Global.System.Windows.Forms.DockStyle.Left
			Me.btnSend.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Selectsmall
			Dim btnSend As Global.System.Windows.Forms.Control = Me.btnSend
			point = New Global.System.Drawing.Point(301, 3)
			btnSend.Location = point
			Me.btnSend.Name = "btnSend"
			Dim btnSend2 As Global.System.Windows.Forms.Control = Me.btnSend
			size = New Global.System.Drawing.Size(93, 38)
			btnSend2.Size = size
			Me.btnSend.TabIndex = 1
			Me.btnSend.Text = "Gửi"
			Me.btnSend.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSend.UseVisualStyleBackColor = True
			Me.txtMess.BackColor = Global.System.Drawing.Color.Ivory
			Me.txtMess.BorderStyle = Global.System.Windows.Forms.BorderStyle.None
			Me.txtMess.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.txtMess.Font = New Global.System.Drawing.Font("Tahoma", 10F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtMess.ForeColor = Global.System.Drawing.Color.Black
			Dim txtMess As Global.System.Windows.Forms.Control = Me.txtMess
			point = New Global.System.Drawing.Point(0, 0)
			txtMess.Location = point
			Me.txtMess.Name = "txtMess"
			Me.txtMess.[ReadOnly] = True
			Me.txtMess.ScrollBars = Global.System.Windows.Forms.RichTextBoxScrollBars.Vertical
			Dim txtMess2 As Global.System.Windows.Forms.Control = Me.txtMess
			size = New Global.System.Drawing.Size(498, 458)
			txtMess2.Size = size
			Me.txtMess.TabIndex = 3
			Me.txtMess.Text = ""
			Me.Timer1.Interval = 1500
			Me.btnKeyboard.BackColor = Global.System.Drawing.Color.White
			Me.btnKeyboard.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnKeyboard.FlatAppearance.BorderSize = 0
			Me.btnKeyboard.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(250, 465)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(42, 30)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 99
			Me.btnKeyboard.UseVisualStyleBackColor = False
			Me.AcceptButton = Me.btnSend
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			Me.CancelButton = Me.btnExit
			size = New Global.System.Drawing.Size(498, 502)
			Me.ClientSize = size
			Me.Controls.Add(Me.btnKeyboard)
			Me.Controls.Add(Me.txtMess)
			Me.Controls.Add(Me.TableLayoutPanel5)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedDialog
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMChat"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "{Chat}"
			Me.TableLayoutPanel5.ResumeLayout(False)
			Me.TableLayoutPanel5.PerformLayout()
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x040005F0 RID: 1520
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
