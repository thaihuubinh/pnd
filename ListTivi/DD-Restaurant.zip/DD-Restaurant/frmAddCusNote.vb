﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000016 RID: 22
	<DesignerGenerated()>
	Public Partial Class frmAddCusNote
		Inherits Form

		' Token: 0x0600028D RID: 653 RVA: 0x00020E38 File Offset: 0x0001F038
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmAddCusNote_Load
			AddHandler MyBase.Shown, AddressOf Me.frmAddCusNote_Shown
			frmAddCusNote.__ENCList.Add(New WeakReference(Me))
			Me.mstrMaDV = ""
			Me.mblnOK = False
			Me.mstrIMG1 = ""
			Me.mstrIMG2 = ""
			Me.mstrIMG3 = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000104 RID: 260
		' (get) Token: 0x06000290 RID: 656 RVA: 0x00021F80 File Offset: 0x00020180
		' (set) Token: 0x06000291 RID: 657 RVA: 0x00002713 File Offset: 0x00000913
		Friend Overridable Property txtNoiDung As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtNoiDung
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtNoiDung = value
			End Set
		End Property

		' Token: 0x17000105 RID: 261
		' (get) Token: 0x06000292 RID: 658 RVA: 0x00021F98 File Offset: 0x00020198
		' (set) Token: 0x06000293 RID: 659 RVA: 0x00021FB0 File Offset: 0x000201B0
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000106 RID: 262
		' (get) Token: 0x06000294 RID: 660 RVA: 0x0002201C File Offset: 0x0002021C
		' (set) Token: 0x06000295 RID: 661 RVA: 0x00022034 File Offset: 0x00020234
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000107 RID: 263
		' (get) Token: 0x06000296 RID: 662 RVA: 0x000220A0 File Offset: 0x000202A0
		' (set) Token: 0x06000297 RID: 663 RVA: 0x0000271D File Offset: 0x0000091D
		Friend Overridable Property lblMA1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMA1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMA1 = value
			End Set
		End Property

		' Token: 0x17000108 RID: 264
		' (get) Token: 0x06000298 RID: 664 RVA: 0x000220B8 File Offset: 0x000202B8
		' (set) Token: 0x06000299 RID: 665 RVA: 0x00002727 File Offset: 0x00000927
		Friend Overridable Property txtTEN1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTEN1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTEN1 = value
			End Set
		End Property

		' Token: 0x17000109 RID: 265
		' (get) Token: 0x0600029A RID: 666 RVA: 0x000220D0 File Offset: 0x000202D0
		' (set) Token: 0x0600029B RID: 667 RVA: 0x000220E8 File Offset: 0x000202E8
		Friend Overridable Property btnDM1 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDM1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDM1 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDM1.Click, AddressOf Me.btnDM1_Click
				End If
				Me._btnDM1 = value
				flag = Me._btnDM1 IsNot Nothing
				If flag Then
					AddHandler Me._btnDM1.Click, AddressOf Me.btnDM1_Click
				End If
			End Set
		End Property

		' Token: 0x1700010A RID: 266
		' (get) Token: 0x0600029C RID: 668 RVA: 0x00022154 File Offset: 0x00020354
		' (set) Token: 0x0600029D RID: 669 RVA: 0x0002216C File Offset: 0x0002036C
		Friend Overridable Property txtMA1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMA1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMA1 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMA1.TextChanged, AddressOf Me.txtMA1_TextChanged
				End If
				Me._txtMA1 = value
				flag = Me._txtMA1 IsNot Nothing
				If flag Then
					AddHandler Me._txtMA1.TextChanged, AddressOf Me.txtMA1_TextChanged
				End If
			End Set
		End Property

		' Token: 0x1700010B RID: 267
		' (get) Token: 0x0600029E RID: 670 RVA: 0x000221D8 File Offset: 0x000203D8
		' (set) Token: 0x0600029F RID: 671 RVA: 0x000221F0 File Offset: 0x000203F0
		Friend Overridable Property dtpTuNgay As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpTuNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpTuNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.dtpTuNgay_ValueChanged
				End If
				Me._dtpTuNgay = value
				flag = Me._dtpTuNgay IsNot Nothing
				If flag Then
					AddHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.dtpTuNgay_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x1700010C RID: 268
		' (get) Token: 0x060002A0 RID: 672 RVA: 0x0002225C File Offset: 0x0002045C
		' (set) Token: 0x060002A1 RID: 673 RVA: 0x00002731 File Offset: 0x00000931
		Friend Overridable Property mtxDATE As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxDATE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxDATE = value
			End Set
		End Property

		' Token: 0x1700010D RID: 269
		' (get) Token: 0x060002A2 RID: 674 RVA: 0x00022274 File Offset: 0x00020474
		' (set) Token: 0x060002A3 RID: 675 RVA: 0x0000273B File Offset: 0x0000093B
		Friend Overridable Property lblFilterDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFilterDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFilterDate = value
			End Set
		End Property

		' Token: 0x1700010E RID: 270
		' (get) Token: 0x060002A4 RID: 676 RVA: 0x0002228C File Offset: 0x0002048C
		' (set) Token: 0x060002A5 RID: 677 RVA: 0x00002745 File Offset: 0x00000945
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x1700010F RID: 271
		' (get) Token: 0x060002A6 RID: 678 RVA: 0x000222A4 File Offset: 0x000204A4
		' (set) Token: 0x060002A7 RID: 679 RVA: 0x0000274F File Offset: 0x0000094F
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000110 RID: 272
		' (get) Token: 0x060002A8 RID: 680 RVA: 0x000222BC File Offset: 0x000204BC
		' (set) Token: 0x060002A9 RID: 681 RVA: 0x00002759 File Offset: 0x00000959
		Friend Overridable Property lblSTT As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblSTT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblSTT = value
			End Set
		End Property

		' Token: 0x17000111 RID: 273
		' (get) Token: 0x060002AA RID: 682 RVA: 0x000222D4 File Offset: 0x000204D4
		' (set) Token: 0x060002AB RID: 683 RVA: 0x000222EC File Offset: 0x000204EC
		Friend Overridable Property picIMG1 As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picIMG1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Dim flag As Boolean = Me._picIMG1 IsNot Nothing
				If flag Then
					RemoveHandler Me._picIMG1.MouseHover, AddressOf Me.picIMG1_MouseHover
					RemoveHandler Me._picIMG1.Click, AddressOf Me.picIMG1_Click
				End If
				Me._picIMG1 = value
				flag = Me._picIMG1 IsNot Nothing
				If flag Then
					AddHandler Me._picIMG1.MouseHover, AddressOf Me.picIMG1_MouseHover
					AddHandler Me._picIMG1.Click, AddressOf Me.picIMG1_Click
				End If
			End Set
		End Property

		' Token: 0x17000112 RID: 274
		' (get) Token: 0x060002AC RID: 684 RVA: 0x00022388 File Offset: 0x00020588
		' (set) Token: 0x060002AD RID: 685 RVA: 0x000223A0 File Offset: 0x000205A0
		Friend Overridable Property picIMG2 As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picIMG2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Dim flag As Boolean = Me._picIMG2 IsNot Nothing
				If flag Then
					RemoveHandler Me._picIMG2.MouseHover, AddressOf Me.picIMG2_MouseHover
					RemoveHandler Me._picIMG2.Click, AddressOf Me.picIMG2_Click
				End If
				Me._picIMG2 = value
				flag = Me._picIMG2 IsNot Nothing
				If flag Then
					AddHandler Me._picIMG2.MouseHover, AddressOf Me.picIMG2_MouseHover
					AddHandler Me._picIMG2.Click, AddressOf Me.picIMG2_Click
				End If
			End Set
		End Property

		' Token: 0x17000113 RID: 275
		' (get) Token: 0x060002AE RID: 686 RVA: 0x0002243C File Offset: 0x0002063C
		' (set) Token: 0x060002AF RID: 687 RVA: 0x00022454 File Offset: 0x00020654
		Friend Overridable Property picIMG3 As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picIMG3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Dim flag As Boolean = Me._picIMG3 IsNot Nothing
				If flag Then
					RemoveHandler Me._picIMG3.MouseHover, AddressOf Me.picIMG3_MouseHover
					RemoveHandler Me._picIMG3.Click, AddressOf Me.picIMG3_Click
				End If
				Me._picIMG3 = value
				flag = Me._picIMG3 IsNot Nothing
				If flag Then
					AddHandler Me._picIMG3.MouseHover, AddressOf Me.picIMG3_MouseHover
					AddHandler Me._picIMG3.Click, AddressOf Me.picIMG3_Click
				End If
			End Set
		End Property

		' Token: 0x17000114 RID: 276
		' (get) Token: 0x060002B0 RID: 688 RVA: 0x000224F0 File Offset: 0x000206F0
		' (set) Token: 0x060002B1 RID: 689 RVA: 0x00022508 File Offset: 0x00020708
		Friend Overridable Property btnDelIMG1 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelIMG1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelIMG1 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelIMG1.Click, AddressOf Me.btnDelIMG1_Click
				End If
				Me._btnDelIMG1 = value
				flag = Me._btnDelIMG1 IsNot Nothing
				If flag Then
					AddHandler Me._btnDelIMG1.Click, AddressOf Me.btnDelIMG1_Click
				End If
			End Set
		End Property

		' Token: 0x17000115 RID: 277
		' (get) Token: 0x060002B2 RID: 690 RVA: 0x00022574 File Offset: 0x00020774
		' (set) Token: 0x060002B3 RID: 691 RVA: 0x0002258C File Offset: 0x0002078C
		Friend Overridable Property btnDelIMG2 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelIMG2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelIMG2 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelIMG2.Click, AddressOf Me.btnDelIMG2_Click
				End If
				Me._btnDelIMG2 = value
				flag = Me._btnDelIMG2 IsNot Nothing
				If flag Then
					AddHandler Me._btnDelIMG2.Click, AddressOf Me.btnDelIMG2_Click
				End If
			End Set
		End Property

		' Token: 0x17000116 RID: 278
		' (get) Token: 0x060002B4 RID: 692 RVA: 0x000225F8 File Offset: 0x000207F8
		' (set) Token: 0x060002B5 RID: 693 RVA: 0x00022610 File Offset: 0x00020810
		Friend Overridable Property btnDelIMG3 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelIMG3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelIMG3 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelIMG3.Click, AddressOf Me.btnDelIMG3_Click
				End If
				Me._btnDelIMG3 = value
				flag = Me._btnDelIMG3 IsNot Nothing
				If flag Then
					AddHandler Me._btnDelIMG3.Click, AddressOf Me.btnDelIMG3_Click
				End If
			End Set
		End Property

		' Token: 0x17000117 RID: 279
		' (get) Token: 0x060002B6 RID: 694 RVA: 0x0002267C File Offset: 0x0002087C
		' (set) Token: 0x060002B7 RID: 695 RVA: 0x00002763 File Offset: 0x00000963
		Friend Overridable Property ToolTip1 As ToolTip
			<DebuggerNonUserCode()>
			Get
				Return Me._ToolTip1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolTip)
				Me._ToolTip1 = value
			End Set
		End Property

		' Token: 0x17000118 RID: 280
		' (get) Token: 0x060002B8 RID: 696 RVA: 0x00022694 File Offset: 0x00020894
		' (set) Token: 0x060002B9 RID: 697 RVA: 0x0000276D File Offset: 0x0000096D
		Public Property pstrIMG1 As String
			Get
				Return Me.mstrIMG1
			End Get
			Set(value As String)
				Me.mstrIMG1 = value
			End Set
		End Property

		' Token: 0x17000119 RID: 281
		' (get) Token: 0x060002BA RID: 698 RVA: 0x000226AC File Offset: 0x000208AC
		' (set) Token: 0x060002BB RID: 699 RVA: 0x00002778 File Offset: 0x00000978
		Public Property pstrIMG2 As String
			Get
				Return Me.mstrIMG2
			End Get
			Set(value As String)
				Me.mstrIMG2 = value
			End Set
		End Property

		' Token: 0x1700011A RID: 282
		' (get) Token: 0x060002BC RID: 700 RVA: 0x000226C4 File Offset: 0x000208C4
		' (set) Token: 0x060002BD RID: 701 RVA: 0x00002783 File Offset: 0x00000983
		Public Property pstrIMG3 As String
			Get
				Return Me.mstrIMG3
			End Get
			Set(value As String)
				Me.mstrIMG3 = value
			End Set
		End Property

		' Token: 0x1700011B RID: 283
		' (get) Token: 0x060002BE RID: 702 RVA: 0x000226DC File Offset: 0x000208DC
		' (set) Token: 0x060002BF RID: 703 RVA: 0x0000278E File Offset: 0x0000098E
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x1700011C RID: 284
		' (get) Token: 0x060002C0 RID: 704 RVA: 0x000226F4 File Offset: 0x000208F4
		' (set) Token: 0x060002C1 RID: 705 RVA: 0x00002799 File Offset: 0x00000999
		Public Property pStrFilterPrint As String
			Get
				Return Me.mStrFilterPrint
			End Get
			Set(value As String)
				Me.mStrFilterPrint = value
			End Set
		End Property

		' Token: 0x1700011D RID: 285
		' (get) Token: 0x060002C2 RID: 706 RVA: 0x0002270C File Offset: 0x0002090C
		' (set) Token: 0x060002C3 RID: 707 RVA: 0x000027A4 File Offset: 0x000009A4
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x1700011E RID: 286
		' (get) Token: 0x060002C4 RID: 708 RVA: 0x00022724 File Offset: 0x00020924
		' (set) Token: 0x060002C5 RID: 709 RVA: 0x000027AF File Offset: 0x000009AF
		Public Property pblnOK As Boolean
			Get
				Return Me.mblnOK
			End Get
			Set(value As Boolean)
				Me.mblnOK = value
			End Set
		End Property

		' Token: 0x1700011F RID: 287
		' (get) Token: 0x060002C6 RID: 710 RVA: 0x0002273C File Offset: 0x0002093C
		' (set) Token: 0x060002C7 RID: 711 RVA: 0x000027BA File Offset: 0x000009BA
		Public Property pStrMaDV As String
			Get
				Return Me.mstrMaDV
			End Get
			Set(value As String)
				Me.mstrMaDV = value
			End Set
		End Property

		' Token: 0x060002C8 RID: 712 RVA: 0x00022754 File Offset: 0x00020954
		Private Sub frmAddCusNote_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fGetData_DMDV()
				End If
				flag = Operators.CompareString(Me.lblSTT.Text.Trim(), "", False) = 0
				Dim flag2 As Boolean
				If flag Then
					Me.txtMA1.Focus()
					Me.Text = Me.mArrStrFrmMess(14)
				Else
					Me.picIMG1.Tag = Me.mstrIMG1
					flag = Me.mstrIMG1.Length > 5
					If flag Then
						flag2 = File.Exists(Me.picIMG1.Tag.ToString().Trim())
						If flag2 Then
							Me.picIMG1.BackgroundImage = Image.FromFile(Me.picIMG1.Tag.ToString().Trim())
						Else
							Me.picIMG1.BackgroundImage = Resources.imgnot
						End If
					End If
					Me.picIMG2.Tag = Me.mstrIMG2
					flag2 = Me.mstrIMG2.Length > 5
					If flag2 Then
						flag = File.Exists(Me.picIMG2.Tag.ToString().Trim())
						If flag Then
							Me.picIMG2.BackgroundImage = Image.FromFile(Me.picIMG2.Tag.ToString().Trim())
						Else
							Me.picIMG2.BackgroundImage = Resources.imgnot
						End If
					End If
					Me.picIMG3.Tag = Me.mstrIMG3
					flag2 = Me.mstrIMG3.Length > 5
					If flag2 Then
						flag = File.Exists(Me.picIMG3.Tag.ToString().Trim())
						If flag Then
							Me.picIMG3.BackgroundImage = Image.FromFile(Me.picIMG3.Tag.ToString().Trim())
						Else
							Me.picIMG3.BackgroundImage = Resources.imgnot
						End If
					End If
					Me.txtNoiDung.Focus()
					Me.Text = Me.mArrStrFrmMess(15)
				End If
				flag2 = Me.mbytFormStatus = 5
				If flag2 Then
					Me.btnSave.Text = Me.mArrStrFrmMess(16)
					Me.txtMA1.Enabled = False
					Me.btnDM1.Enabled = False
				Else
					flag2 = Me.mbytFormStatus = 6
					If flag2 Then
						Me.btnSave.Text = Me.mArrStrFrmMess(17)
						Me.txtMA1.Enabled = False
						Me.btnDM1.Enabled = False
					End If
				End If
				Me.txtMA1_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(11), vbCrLf, Me.Name, " - frmAddCusNote_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060002C9 RID: 713 RVA: 0x00022A88 File Offset: 0x00020C88
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(0), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060002CA RID: 714 RVA: 0x00022B94 File Offset: 0x00020D94
		Private Function fGetData_DMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMDV")
				Dim flag As Boolean = Me.mclsTbDMDV IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(11), vbCrLf, Me.Name, " - fGetData_DMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060002CB RID: 715 RVA: 0x00022C50 File Offset: 0x00020E50
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbytFormStatus = 5 OrElse Me.mbytFormStatus = 6
				If flag Then
					Dim text As String = ""
					Dim text2 As String = ""
					flag = Me.mtxDATE.Text.Trim().Length = 10
					If flag Then
						text = "NGAY='" + Me.mtxDATE.Text + "'"
						text2 = "{dtReport.NGAY}='" + Me.mtxDATE.Text + "'"
					End If
					flag = Me.txtNoiDung.Text.Trim().Length > 0
					If flag Then
						text = Conversions.ToString(Interaction.IIf(text.Trim().Length > 0, text + " AND ", ""))
						text = text + "NOIDUNG LIKE '%" + Me.txtNoiDung.Text + "%'"
						text2 = Conversions.ToString(Interaction.IIf(text2.Trim().Length > 0, text2 + " AND ", ""))
						text2 = text2 + "{dtReport.NOIDUNG} LIKE '*" + Me.txtNoiDung.Text + "*'"
					End If
					Me.mStrFilter = text
					Me.mStrFilterPrint = text2
					Me.mblnOK = True
					Me.Close()
				Else
					flag = Strings.Len(Strings.Trim(Me.mtxDATE.Text)) <= 4
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(8), MsgBoxStyle.Critical, Nothing)
						Me.mtxDATE.Focus()
					Else
						Dim text3 As String = Strings.Mid(Me.mtxDATE.Text, 3, 1)
						Dim text4 As String = Strings.Trim(Strings.Replace(Me.mtxDATE.Text, text3, "", 1, -1, CompareMethod.Binary))
						flag = Strings.Len(text4) > 0
						If flag Then
							text4 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 1, 2) })
							flag = Not Information.IsDate(text4)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(8), MsgBoxStyle.Critical, Nothing)
								Me.mtxDATE.Focus()
								Return
							End If
						End If
						flag = Operators.CompareString(Strings.Trim(Me.txtMA1.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(9), MsgBoxStyle.Critical, Nothing)
							Me.txtMA1.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.txtMA1.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTEN1.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(4), MsgBoxStyle.Critical, Nothing)
								Me.txtMA1.Focus()
							Else
								flag = Operators.CompareString(Strings.Trim(Me.txtNoiDung.Text), "", False) = 0
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(10), MsgBoxStyle.Critical, Nothing)
									Me.txtNoiDung.Focus()
								Else
									flag = Operators.CompareString(Me.lblSTT.Text.Trim(), "", False) <> 0
									Dim b As Byte
									If flag Then
										b = Me.fModify()
									Else
										b = Me.fAddnew()
									End If
									flag = b = 1
									If flag Then
										Me.mblnOK = True
										Me.mstrMaDV = Me.txtMA1.Text.Trim()
										Me.Close()
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(11), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060002CC RID: 716 RVA: 0x000230F8 File Offset: 0x000212F8
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.mblnOK = False
				Me.Close()
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060002CD RID: 717 RVA: 0x00023138 File Offset: 0x00021338
		Private Sub txtMA1_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMDV Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMDV.Columns("OBJID")
					Me.mclsTbDMDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMDV.Rows.Find(Strings.Trim(Me.txtMA1.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTEN1.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTEN1.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(11), vbCrLf, Me.Name, " - txtMADV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060002CE RID: 718 RVA: 0x0002328C File Offset: 0x0002148C
		Private Sub btnDM1_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDV As frmDMDV1 = New frmDMDV1()
				frmDMDV.pBytOpen_From_Menu = 7
				frmDMDV.pIntType = 4S
				frmDMDV.ShowDialog()
				Me.txtMA1.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJID, "", False) = 0, Me.txtMA1.Text, frmDMDV.pStrOBJID))
				Me.txtTEN1.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJNAME, "", False) = 0, Me.txtTEN1.Text, frmDMDV.pStrOBJNAME))
				Me.fGetData_DMDV()
				frmDMDV.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(11), vbCrLf, Me.Name, " - btnDMDV_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060002CF RID: 719 RVA: 0x000233D8 File Offset: 0x000215D8
		Private Sub dtpTuNgay_ValueChanged(sender As Object, e As EventArgs)
			Me.mtxDATE.Text = String.Concat(New String() { Me.dtpTuNgay.Value.Day.ToString("00"), "/", Me.dtpTuNgay.Value.Month.ToString("00"), "/", Me.dtpTuNgay.Value.Year.ToString("0000") })
		End Sub

		' Token: 0x060002D0 RID: 720 RVA: 0x00023488 File Offset: 0x00021688
		Private Function fAddnew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(7) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nvcNGAY"
				array(0).Value = Me.mtxDATE.Text
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nchMADV"
				array(1).Value = Me.txtMA1.Text
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@nvcNOIDUNG"
				array(2).Value = Me.txtNoiDung.Text
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@nvcIMG1"
				Dim flag As Boolean = Me.picIMG1.Tag IsNot Nothing
				If flag Then
					array(4).Value = Me.picIMG1.Tag.ToString()
				Else
					array(4).Value = ""
				End If
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@nvcIMG2"
				flag = Me.picIMG2.Tag IsNot Nothing
				If flag Then
					array(5).Value = Me.picIMG2.Tag.ToString()
				Else
					array(5).Value = ""
				End If
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@nvcIMG3"
				flag = Me.picIMG3.Tag IsNot Nothing
				If flag Then
					array(6).Value = Me.picIMG3.Tag.ToString()
				Else
					array(6).Value = ""
				End If
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@int_Result"
				array(3).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCUSNOTE_INSERT_CUSNOTE", flag2)
				Dim num As Integer = Conversions.ToInteger(array(3).Value)
				flag = num = 0
				If flag Then
					b = 1
				Else
					flag = num = 1
					If flag Then
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(4), Me.mArrStrFrmMess(5), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Hoi)
					Else
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(6), Me.mArrStrFrmMess(5), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Hoi)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060002D1 RID: 721 RVA: 0x000237C4 File Offset: 0x000219C4
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(8) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nvcNGAY"
				array(0).Value = Me.mtxDATE.Text
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nchMADV"
				array(1).Value = Me.txtMA1.Text
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@nvcNOIDUNG"
				array(2).Value = Me.txtNoiDung.Text
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@intSTT"
				array(3).Value = Conversion.Val(Me.lblSTT.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@nvcIMG1"
				Dim flag As Boolean = Me.picIMG1.Tag IsNot Nothing
				If flag Then
					array(5).Value = Me.picIMG1.Tag.ToString()
				Else
					array(5).Value = ""
				End If
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@nvcIMG2"
				flag = Me.picIMG2.Tag IsNot Nothing
				If flag Then
					array(6).Value = Me.picIMG2.Tag.ToString()
				Else
					array(6).Value = ""
				End If
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@nvcIMG3"
				flag = Me.picIMG3.Tag IsNot Nothing
				If flag Then
					array(7).Value = Me.picIMG3.Tag.ToString()
				Else
					array(7).Value = ""
				End If
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@int_Result"
				array(4).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCUSNOTE_UPDATE_CUSNOTE", flag2)
				Dim num As Integer = Conversions.ToInteger(array(4).Value)
				flag = num = 0
				If flag Then
					b = 1
				Else
					flag = num = 1
					If flag Then
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(4), Me.mArrStrFrmMess(5), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Hoi)
					Else
						flag = num = 2
						If flag Then
							MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(7), Me.mArrStrFrmMess(5), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Hoi)
						Else
							MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(6), Me.mArrStrFrmMess(5), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Hoi)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060002D2 RID: 722 RVA: 0x00023B6C File Offset: 0x00021D6C
		Private Sub frmAddCusNote_Shown(sender As Object, e As EventArgs)
			Dim flag As Boolean = Operators.CompareString(Me.lblSTT.Text.Trim(), "", False) = 0
			If flag Then
				Me.txtMA1.Focus()
				Me.Text = Me.mArrStrFrmMess(14)
			Else
				Me.txtNoiDung.Focus()
				Me.Text = Me.mArrStrFrmMess(15)
			End If
		End Sub

		' Token: 0x060002D3 RID: 723 RVA: 0x00023BDC File Offset: 0x00021DDC
		Private Sub picIMG1_Click(sender As Object, e As EventArgs)
			Try
				Dim openFileDialog As OpenFileDialog = New OpenFileDialog()
				openFileDialog.Filter = "Image file (*.jpg, *.png, *.bmp, *.gif)|*.jpg;*.png;*.bmp;*.gif"
				openFileDialog.Multiselect = False
				openFileDialog.RestoreDirectory = False
				Dim flag As Boolean = openFileDialog.ShowDialog() = DialogResult.OK
				If flag Then
					Me.picIMG1.Tag = openFileDialog.FileName
					Me.picIMG1.BackgroundImage = Image.FromFile(Me.picIMG1.Tag.ToString().Trim())
				End If
			Catch ex As Exception
				MessageBox.Show(ex.Message)
			End Try
		End Sub

		' Token: 0x060002D4 RID: 724 RVA: 0x00023C84 File Offset: 0x00021E84
		Private Sub picIMG2_Click(sender As Object, e As EventArgs)
			Try
				Dim openFileDialog As OpenFileDialog = New OpenFileDialog()
				openFileDialog.Filter = "Image file (*.jpg, *.png, *.bmp, *.gif)|*.jpg;*.png;*.bmp;*.gif"
				openFileDialog.Multiselect = False
				openFileDialog.RestoreDirectory = False
				Dim flag As Boolean = openFileDialog.ShowDialog() = DialogResult.OK
				If flag Then
					Me.picIMG2.Tag = openFileDialog.FileName
					Me.picIMG2.BackgroundImage = Image.FromFile(Me.picIMG2.Tag.ToString().Trim())
				End If
			Catch ex As Exception
				MessageBox.Show(ex.Message)
			End Try
		End Sub

		' Token: 0x060002D5 RID: 725 RVA: 0x00023D2C File Offset: 0x00021F2C
		Private Sub picIMG3_Click(sender As Object, e As EventArgs)
			Try
				Dim openFileDialog As OpenFileDialog = New OpenFileDialog()
				openFileDialog.Filter = "Image file (*.jpg, *.png, *.bmp, *.gif)|*.jpg;*.png;*.bmp;*.gif"
				openFileDialog.Multiselect = False
				openFileDialog.RestoreDirectory = False
				Dim flag As Boolean = openFileDialog.ShowDialog() = DialogResult.OK
				If flag Then
					Me.picIMG3.Tag = openFileDialog.FileName
					Me.picIMG3.BackgroundImage = Image.FromFile(Me.picIMG3.Tag.ToString().Trim())
				End If
			Catch ex As Exception
				MessageBox.Show(ex.Message)
			End Try
		End Sub

		' Token: 0x060002D6 RID: 726 RVA: 0x00023DD4 File Offset: 0x00021FD4
		Private Sub btnDelIMG1_Click(sender As Object, e As EventArgs)
			Try
				Me.picIMG1.BackgroundImage = Me.btnDelIMG1.BackgroundImage
				Me.picIMG1.Tag = Nothing
			Catch ex As Exception
				MessageBox.Show(ex.Message)
			End Try
		End Sub

		' Token: 0x060002D7 RID: 727 RVA: 0x00023E38 File Offset: 0x00022038
		Private Sub btnDelIMG2_Click(sender As Object, e As EventArgs)
			Try
				Me.picIMG2.BackgroundImage = Me.btnDelIMG1.BackgroundImage
				Me.picIMG2.Tag = Nothing
			Catch ex As Exception
				MessageBox.Show(ex.Message)
			End Try
		End Sub

		' Token: 0x060002D8 RID: 728 RVA: 0x00023E9C File Offset: 0x0002209C
		Private Sub btnDelIMG3_Click(sender As Object, e As EventArgs)
			Try
				Me.picIMG3.BackgroundImage = Me.btnDelIMG1.BackgroundImage
				Me.picIMG3.Tag = Nothing
			Catch ex As Exception
				MessageBox.Show(ex.Message)
			End Try
		End Sub

		' Token: 0x060002D9 RID: 729 RVA: 0x00023F00 File Offset: 0x00022100
		Private Sub picIMG1_MouseHover(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.picIMG1.Tag IsNot Nothing
				If flag Then
					Me.ToolTip1.SetToolTip(Me.picIMG1, Me.picIMG1.Tag.ToString().Trim())
				End If
			Catch ex As Exception
				MessageBox.Show(ex.Message)
			End Try
		End Sub

		' Token: 0x060002DA RID: 730 RVA: 0x00023F7C File Offset: 0x0002217C
		Private Sub picIMG2_MouseHover(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.picIMG2.Tag IsNot Nothing
				If flag Then
					Me.ToolTip1.SetToolTip(Me.picIMG2, Me.picIMG2.Tag.ToString().Trim())
				End If
			Catch ex As Exception
				MessageBox.Show(ex.Message)
			End Try
		End Sub

		' Token: 0x060002DB RID: 731 RVA: 0x00023FF8 File Offset: 0x000221F8
		Private Sub picIMG3_MouseHover(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.picIMG3.Tag IsNot Nothing
				If flag Then
					Me.ToolTip1.SetToolTip(Me.picIMG3, Me.picIMG3.Tag.ToString().Trim())
				End If
			Catch ex As Exception
				MessageBox.Show(ex.Message)
			End Try
		End Sub

		' Token: 0x04000118 RID: 280
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400011A RID: 282
		<AccessedThroughProperty("txtNoiDung")>
		Private _txtNoiDung As TextBox

		' Token: 0x0400011B RID: 283
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x0400011C RID: 284
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x0400011D RID: 285
		<AccessedThroughProperty("lblMA1")>
		Private _lblMA1 As Label

		' Token: 0x0400011E RID: 286
		<AccessedThroughProperty("txtTEN1")>
		Private _txtTEN1 As TextBox

		' Token: 0x0400011F RID: 287
		<AccessedThroughProperty("btnDM1")>
		Private _btnDM1 As Button

		' Token: 0x04000120 RID: 288
		<AccessedThroughProperty("txtMA1")>
		Private _txtMA1 As TextBox

		' Token: 0x04000121 RID: 289
		<AccessedThroughProperty("dtpTuNgay")>
		Private _dtpTuNgay As DateTimePicker

		' Token: 0x04000122 RID: 290
		<AccessedThroughProperty("mtxDATE")>
		Private _mtxDATE As MaskedTextBox

		' Token: 0x04000123 RID: 291
		<AccessedThroughProperty("lblFilterDate")>
		Private _lblFilterDate As Label

		' Token: 0x04000124 RID: 292
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000125 RID: 293
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000126 RID: 294
		<AccessedThroughProperty("lblSTT")>
		Private _lblSTT As Label

		' Token: 0x04000127 RID: 295
		<AccessedThroughProperty("picIMG1")>
		Private _picIMG1 As PictureBox

		' Token: 0x04000128 RID: 296
		<AccessedThroughProperty("picIMG2")>
		Private _picIMG2 As PictureBox

		' Token: 0x04000129 RID: 297
		<AccessedThroughProperty("picIMG3")>
		Private _picIMG3 As PictureBox

		' Token: 0x0400012A RID: 298
		<AccessedThroughProperty("btnDelIMG1")>
		Private _btnDelIMG1 As Button

		' Token: 0x0400012B RID: 299
		<AccessedThroughProperty("btnDelIMG2")>
		Private _btnDelIMG2 As Button

		' Token: 0x0400012C RID: 300
		<AccessedThroughProperty("btnDelIMG3")>
		Private _btnDelIMG3 As Button

		' Token: 0x0400012D RID: 301
		<AccessedThroughProperty("ToolTip1")>
		Private _ToolTip1 As ToolTip

		' Token: 0x0400012E RID: 302
		Private mArrStrFrmMess As String()

		' Token: 0x0400012F RID: 303
		Private mstrMaDV As String

		' Token: 0x04000130 RID: 304
		Private mblnOK As Boolean

		' Token: 0x04000131 RID: 305
		Private p As Process()

		' Token: 0x04000132 RID: 306
		Private mclsTbDMDV As clsConnect

		' Token: 0x04000133 RID: 307
		Private mbytFormStatus As Byte

		' Token: 0x04000134 RID: 308
		Private mStrFilter As String

		' Token: 0x04000135 RID: 309
		Private mStrFilterPrint As String

		' Token: 0x04000136 RID: 310
		Private mstrIMG1 As String

		' Token: 0x04000137 RID: 311
		Private mstrIMG2 As String

		' Token: 0x04000138 RID: 312
		Private mstrIMG3 As String
	End Class
End Namespace
