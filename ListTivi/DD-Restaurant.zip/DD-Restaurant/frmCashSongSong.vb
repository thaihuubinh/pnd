﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200001F RID: 31
	<DesignerGenerated()>
	Public Partial Class frmCashSongSong
		Inherits Form

		' Token: 0x0600050C RID: 1292 RVA: 0x0003BB94 File Offset: 0x00039D94
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmCashSongSong_Load
			frmCashSongSong.__ENCList.Add(New WeakReference(Me))
			Me.mstrSoCT = ""
			Me.mstrDateTime = ""
			Me.mstrMaBan = ""
			Me.mstrTenBan = ""
			Me.mstrMaDVT = ""
			Me.mstrMaHTTT99 = ""
			Me.mdblCashConLai = 0.0
			Me.mbytP04SOCT = 1
			Me.InitializeComponent()
		End Sub

		' Token: 0x170001EA RID: 490
		' (get) Token: 0x0600050F RID: 1295 RVA: 0x0003E16C File Offset: 0x0003C36C
		' (set) Token: 0x06000510 RID: 1296 RVA: 0x0003E184 File Offset: 0x0003C384
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170001EB RID: 491
		' (get) Token: 0x06000511 RID: 1297 RVA: 0x0003E1F0 File Offset: 0x0003C3F0
		' (set) Token: 0x06000512 RID: 1298 RVA: 0x00002E0C File Offset: 0x0000100C
		Friend Overridable Property TableLayoutPanel5 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel5 = value
			End Set
		End Property

		' Token: 0x170001EC RID: 492
		' (get) Token: 0x06000513 RID: 1299 RVA: 0x0003E208 File Offset: 0x0003C408
		' (set) Token: 0x06000514 RID: 1300 RVA: 0x0003E220 File Offset: 0x0003C420
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170001ED RID: 493
		' (get) Token: 0x06000515 RID: 1301 RVA: 0x0003E28C File Offset: 0x0003C48C
		' (set) Token: 0x06000516 RID: 1302 RVA: 0x00002E16 File Offset: 0x00001016
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170001EE RID: 494
		' (get) Token: 0x06000517 RID: 1303 RVA: 0x0003E2A4 File Offset: 0x0003C4A4
		' (set) Token: 0x06000518 RID: 1304 RVA: 0x00002E20 File Offset: 0x00001020
		Friend Overridable Property TableLayoutPanel3 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel3 = value
			End Set
		End Property

		' Token: 0x170001EF RID: 495
		' (get) Token: 0x06000519 RID: 1305 RVA: 0x0003E2BC File Offset: 0x0003C4BC
		' (set) Token: 0x0600051A RID: 1306 RVA: 0x00002E2A File Offset: 0x0000102A
		Friend Overridable Property TableLayoutPanel2 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel2 = value
			End Set
		End Property

		' Token: 0x170001F0 RID: 496
		' (get) Token: 0x0600051B RID: 1307 RVA: 0x0003E2D4 File Offset: 0x0003C4D4
		' (set) Token: 0x0600051C RID: 1308 RVA: 0x0003E2EC File Offset: 0x0003C4EC
		Friend Overridable Property lbl8 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl8 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl8.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl8 = value
				flag = Me._lbl8 IsNot Nothing
				If flag Then
					AddHandler Me._lbl8.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001F1 RID: 497
		' (get) Token: 0x0600051D RID: 1309 RVA: 0x0003E358 File Offset: 0x0003C558
		' (set) Token: 0x0600051E RID: 1310 RVA: 0x0003E370 File Offset: 0x0003C570
		Friend Overridable Property lbl9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl9 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl9.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl9 = value
				flag = Me._lbl9 IsNot Nothing
				If flag Then
					AddHandler Me._lbl9.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001F2 RID: 498
		' (get) Token: 0x0600051F RID: 1311 RVA: 0x0003E3DC File Offset: 0x0003C5DC
		' (set) Token: 0x06000520 RID: 1312 RVA: 0x0003E3F4 File Offset: 0x0003C5F4
		Friend Overridable Property lbl13 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl13
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl13 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl13.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl13 = value
				flag = Me._lbl13 IsNot Nothing
				If flag Then
					AddHandler Me._lbl13.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001F3 RID: 499
		' (get) Token: 0x06000521 RID: 1313 RVA: 0x0003E460 File Offset: 0x0003C660
		' (set) Token: 0x06000522 RID: 1314 RVA: 0x0003E478 File Offset: 0x0003C678
		Friend Overridable Property lbl11 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl11
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl11 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl11.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl11 = value
				flag = Me._lbl11 IsNot Nothing
				If flag Then
					AddHandler Me._lbl11.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001F4 RID: 500
		' (get) Token: 0x06000523 RID: 1315 RVA: 0x0003E4E4 File Offset: 0x0003C6E4
		' (set) Token: 0x06000524 RID: 1316 RVA: 0x0003E4FC File Offset: 0x0003C6FC
		Friend Overridable Property lbl10 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl10 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl10.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl10 = value
				flag = Me._lbl10 IsNot Nothing
				If flag Then
					AddHandler Me._lbl10.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001F5 RID: 501
		' (get) Token: 0x06000525 RID: 1317 RVA: 0x0003E568 File Offset: 0x0003C768
		' (set) Token: 0x06000526 RID: 1318 RVA: 0x0003E580 File Offset: 0x0003C780
		Friend Overridable Property lbl12 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl12
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl12 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl12.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl12 = value
				flag = Me._lbl12 IsNot Nothing
				If flag Then
					AddHandler Me._lbl12.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001F6 RID: 502
		' (get) Token: 0x06000527 RID: 1319 RVA: 0x0003E5EC File Offset: 0x0003C7EC
		' (set) Token: 0x06000528 RID: 1320 RVA: 0x0003E604 File Offset: 0x0003C804
		Friend Overridable Property lbl14 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl14
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl14 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl14.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl14 = value
				flag = Me._lbl14 IsNot Nothing
				If flag Then
					AddHandler Me._lbl14.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001F7 RID: 503
		' (get) Token: 0x06000529 RID: 1321 RVA: 0x0003E670 File Offset: 0x0003C870
		' (set) Token: 0x0600052A RID: 1322 RVA: 0x0003E688 File Offset: 0x0003C888
		Friend Overridable Property lbl1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl1 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl1.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl1 = value
				flag = Me._lbl1 IsNot Nothing
				If flag Then
					AddHandler Me._lbl1.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001F8 RID: 504
		' (get) Token: 0x0600052B RID: 1323 RVA: 0x0003E6F4 File Offset: 0x0003C8F4
		' (set) Token: 0x0600052C RID: 1324 RVA: 0x0003E70C File Offset: 0x0003C90C
		Friend Overridable Property lbl2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl2 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl2.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl2 = value
				flag = Me._lbl2 IsNot Nothing
				If flag Then
					AddHandler Me._lbl2.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001F9 RID: 505
		' (get) Token: 0x0600052D RID: 1325 RVA: 0x0003E778 File Offset: 0x0003C978
		' (set) Token: 0x0600052E RID: 1326 RVA: 0x0003E790 File Offset: 0x0003C990
		Friend Overridable Property lbl4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl4 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl4.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl4 = value
				flag = Me._lbl4 IsNot Nothing
				If flag Then
					AddHandler Me._lbl4.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001FA RID: 506
		' (get) Token: 0x0600052F RID: 1327 RVA: 0x0003E7FC File Offset: 0x0003C9FC
		' (set) Token: 0x06000530 RID: 1328 RVA: 0x0003E814 File Offset: 0x0003CA14
		Friend Overridable Property lbl6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl6 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl6.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl6 = value
				flag = Me._lbl6 IsNot Nothing
				If flag Then
					AddHandler Me._lbl6.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001FB RID: 507
		' (get) Token: 0x06000531 RID: 1329 RVA: 0x0003E880 File Offset: 0x0003CA80
		' (set) Token: 0x06000532 RID: 1330 RVA: 0x0003E898 File Offset: 0x0003CA98
		Friend Overridable Property lbl3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl3 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl3.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl3 = value
				flag = Me._lbl3 IsNot Nothing
				If flag Then
					AddHandler Me._lbl3.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001FC RID: 508
		' (get) Token: 0x06000533 RID: 1331 RVA: 0x0003E904 File Offset: 0x0003CB04
		' (set) Token: 0x06000534 RID: 1332 RVA: 0x0003E91C File Offset: 0x0003CB1C
		Friend Overridable Property lbl5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl5 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl5.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl5 = value
				flag = Me._lbl5 IsNot Nothing
				If flag Then
					AddHandler Me._lbl5.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001FD RID: 509
		' (get) Token: 0x06000535 RID: 1333 RVA: 0x0003E988 File Offset: 0x0003CB88
		' (set) Token: 0x06000536 RID: 1334 RVA: 0x0003E9A0 File Offset: 0x0003CBA0
		Friend Overridable Property lbl7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbl7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lbl7 IsNot Nothing
				If flag Then
					RemoveHandler Me._lbl7.Click, AddressOf Me.lbl_Click
				End If
				Me._lbl7 = value
				flag = Me._lbl7 IsNot Nothing
				If flag Then
					AddHandler Me._lbl7.Click, AddressOf Me.lbl_Click
				End If
			End Set
		End Property

		' Token: 0x170001FE RID: 510
		' (get) Token: 0x06000537 RID: 1335 RVA: 0x0003EA0C File Offset: 0x0003CC0C
		' (set) Token: 0x06000538 RID: 1336 RVA: 0x00002E34 File Offset: 0x00001034
		Friend Overridable Property btn1 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btn1 = value
			End Set
		End Property

		' Token: 0x170001FF RID: 511
		' (get) Token: 0x06000539 RID: 1337 RVA: 0x0003EA24 File Offset: 0x0003CC24
		' (set) Token: 0x0600053A RID: 1338 RVA: 0x0003EA3C File Offset: 0x0003CC3C
		Friend Overridable Property btn8 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn8 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn8.Click, AddressOf Me.btn2_Click
				End If
				Me._btn8 = value
				flag = Me._btn8 IsNot Nothing
				If flag Then
					AddHandler Me._btn8.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000200 RID: 512
		' (get) Token: 0x0600053B RID: 1339 RVA: 0x0003EAA8 File Offset: 0x0003CCA8
		' (set) Token: 0x0600053C RID: 1340 RVA: 0x0003EAC0 File Offset: 0x0003CCC0
		Friend Overridable Property btn9 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn9 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn9.Click, AddressOf Me.btn2_Click
				End If
				Me._btn9 = value
				flag = Me._btn9 IsNot Nothing
				If flag Then
					AddHandler Me._btn9.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000201 RID: 513
		' (get) Token: 0x0600053D RID: 1341 RVA: 0x0003EB2C File Offset: 0x0003CD2C
		' (set) Token: 0x0600053E RID: 1342 RVA: 0x0003EB44 File Offset: 0x0003CD44
		Friend Overridable Property btn10 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn10 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn10.Click, AddressOf Me.btn2_Click
				End If
				Me._btn10 = value
				flag = Me._btn10 IsNot Nothing
				If flag Then
					AddHandler Me._btn10.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000202 RID: 514
		' (get) Token: 0x0600053F RID: 1343 RVA: 0x0003EBB0 File Offset: 0x0003CDB0
		' (set) Token: 0x06000540 RID: 1344 RVA: 0x0003EBC8 File Offset: 0x0003CDC8
		Friend Overridable Property btn11 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn11
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn11 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn11.Click, AddressOf Me.btn2_Click
				End If
				Me._btn11 = value
				flag = Me._btn11 IsNot Nothing
				If flag Then
					AddHandler Me._btn11.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000203 RID: 515
		' (get) Token: 0x06000541 RID: 1345 RVA: 0x0003EC34 File Offset: 0x0003CE34
		' (set) Token: 0x06000542 RID: 1346 RVA: 0x0003EC4C File Offset: 0x0003CE4C
		Friend Overridable Property btn12 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn12
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn12 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn12.Click, AddressOf Me.btn2_Click
				End If
				Me._btn12 = value
				flag = Me._btn12 IsNot Nothing
				If flag Then
					AddHandler Me._btn12.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000204 RID: 516
		' (get) Token: 0x06000543 RID: 1347 RVA: 0x0003ECB8 File Offset: 0x0003CEB8
		' (set) Token: 0x06000544 RID: 1348 RVA: 0x0003ECD0 File Offset: 0x0003CED0
		Friend Overridable Property btn13 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn13
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn13 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn13.Click, AddressOf Me.btn2_Click
				End If
				Me._btn13 = value
				flag = Me._btn13 IsNot Nothing
				If flag Then
					AddHandler Me._btn13.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000205 RID: 517
		' (get) Token: 0x06000545 RID: 1349 RVA: 0x0003ED3C File Offset: 0x0003CF3C
		' (set) Token: 0x06000546 RID: 1350 RVA: 0x0003ED54 File Offset: 0x0003CF54
		Friend Overridable Property btn14 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn14
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn14 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn14.Click, AddressOf Me.btn2_Click
				End If
				Me._btn14 = value
				flag = Me._btn14 IsNot Nothing
				If flag Then
					AddHandler Me._btn14.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000206 RID: 518
		' (get) Token: 0x06000547 RID: 1351 RVA: 0x0003EDC0 File Offset: 0x0003CFC0
		' (set) Token: 0x06000548 RID: 1352 RVA: 0x0003EDD8 File Offset: 0x0003CFD8
		Friend Overridable Property btn2 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn2 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn2.Click, AddressOf Me.btn2_Click
				End If
				Me._btn2 = value
				flag = Me._btn2 IsNot Nothing
				If flag Then
					AddHandler Me._btn2.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000207 RID: 519
		' (get) Token: 0x06000549 RID: 1353 RVA: 0x0003EE44 File Offset: 0x0003D044
		' (set) Token: 0x0600054A RID: 1354 RVA: 0x0003EE5C File Offset: 0x0003D05C
		Friend Overridable Property btn3 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn3 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn3.Click, AddressOf Me.btn2_Click
				End If
				Me._btn3 = value
				flag = Me._btn3 IsNot Nothing
				If flag Then
					AddHandler Me._btn3.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000208 RID: 520
		' (get) Token: 0x0600054B RID: 1355 RVA: 0x0003EEC8 File Offset: 0x0003D0C8
		' (set) Token: 0x0600054C RID: 1356 RVA: 0x0003EEE0 File Offset: 0x0003D0E0
		Friend Overridable Property btn4 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn4 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn4.Click, AddressOf Me.btn2_Click
				End If
				Me._btn4 = value
				flag = Me._btn4 IsNot Nothing
				If flag Then
					AddHandler Me._btn4.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x17000209 RID: 521
		' (get) Token: 0x0600054D RID: 1357 RVA: 0x0003EF4C File Offset: 0x0003D14C
		' (set) Token: 0x0600054E RID: 1358 RVA: 0x0003EF64 File Offset: 0x0003D164
		Friend Overridable Property btn5 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn5 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn5.Click, AddressOf Me.btn2_Click
				End If
				Me._btn5 = value
				flag = Me._btn5 IsNot Nothing
				If flag Then
					AddHandler Me._btn5.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x1700020A RID: 522
		' (get) Token: 0x0600054F RID: 1359 RVA: 0x0003EFD0 File Offset: 0x0003D1D0
		' (set) Token: 0x06000550 RID: 1360 RVA: 0x0003EFE8 File Offset: 0x0003D1E8
		Friend Overridable Property btn6 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn6 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn6.Click, AddressOf Me.btn2_Click
				End If
				Me._btn6 = value
				flag = Me._btn6 IsNot Nothing
				If flag Then
					AddHandler Me._btn6.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x1700020B RID: 523
		' (get) Token: 0x06000551 RID: 1361 RVA: 0x0003F054 File Offset: 0x0003D254
		' (set) Token: 0x06000552 RID: 1362 RVA: 0x0003F06C File Offset: 0x0003D26C
		Friend Overridable Property btn7 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn7 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn7.Click, AddressOf Me.btn2_Click
				End If
				Me._btn7 = value
				flag = Me._btn7 IsNot Nothing
				If flag Then
					AddHandler Me._btn7.Click, AddressOf Me.btn2_Click
				End If
			End Set
		End Property

		' Token: 0x06000553 RID: 1363 RVA: 0x0003F0D8 File Offset: 0x0003D2D8
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/P04SOCT")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mbytP04SOCT = Byte.Parse(xmlNode.InnerText)
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - sGetPara_From_SetparaXML " + ex.Message + vbCrLf, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000554 RID: 1364 RVA: 0x0003F190 File Offset: 0x0003D390
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(1))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(2), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000555 RID: 1365 RVA: 0x0003F29C File Offset: 0x0003D49C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(2), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x1700020C RID: 524
		' (get) Token: 0x06000556 RID: 1366 RVA: 0x0003F340 File Offset: 0x0003D540
		' (set) Token: 0x06000557 RID: 1367 RVA: 0x00002E3E File Offset: 0x0000103E
		Public Property pstrMaBan As String
			Get
				Return Me.mstrMaBan
			End Get
			Set(value As String)
				Me.mstrMaBan = value
			End Set
		End Property

		' Token: 0x1700020D RID: 525
		' (get) Token: 0x06000558 RID: 1368 RVA: 0x0003F358 File Offset: 0x0003D558
		' (set) Token: 0x06000559 RID: 1369 RVA: 0x00002E49 File Offset: 0x00001049
		Public Property pstrTenBan As String
			Get
				Return Me.mstrTenBan
			End Get
			Set(value As String)
				Me.mstrTenBan = value
			End Set
		End Property

		' Token: 0x1700020E RID: 526
		' (get) Token: 0x0600055A RID: 1370 RVA: 0x0003F370 File Offset: 0x0003D570
		' (set) Token: 0x0600055B RID: 1371 RVA: 0x00002E54 File Offset: 0x00001054
		Public Property pstrSoCT As String
			Get
				Return Me.mstrSoCT
			End Get
			Set(value As String)
				Me.mstrSoCT = value
			End Set
		End Property

		' Token: 0x1700020F RID: 527
		' (get) Token: 0x0600055C RID: 1372 RVA: 0x0003F388 File Offset: 0x0003D588
		' (set) Token: 0x0600055D RID: 1373 RVA: 0x00002E5F File Offset: 0x0000105F
		Public Property pstrDateTime As String
			Get
				Return Me.mstrDateTime
			End Get
			Set(value As String)
				Me.mstrDateTime = value
			End Set
		End Property

		' Token: 0x17000210 RID: 528
		' (get) Token: 0x0600055E RID: 1374 RVA: 0x0003F3A0 File Offset: 0x0003D5A0
		' (set) Token: 0x0600055F RID: 1375 RVA: 0x00002E6A File Offset: 0x0000106A
		Public Property pdblCash As Double
			Get
				Return Me.mdblCash
			End Get
			Set(value As Double)
				Me.mdblCash = value
			End Set
		End Property

		' Token: 0x17000211 RID: 529
		' (get) Token: 0x06000560 RID: 1376 RVA: 0x0003F3B8 File Offset: 0x0003D5B8
		' (set) Token: 0x06000561 RID: 1377 RVA: 0x00002E75 File Offset: 0x00001075
		Public Property pbytsuccess As Single
			Get
				Return CSng(Me.mbytsuccess)
			End Get
			Set(value As Single)
				' The following expression was wrapped in a checked-expression
				Me.mbytsuccess = CByte(Math.Round(CDbl(value)))
			End Set
		End Property

		' Token: 0x06000562 RID: 1378 RVA: 0x00002E87 File Offset: 0x00001087
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			mdlFile.gfWriteLogFile("Thoát form thanh toán song song")
			Me.mbytsuccess = 0
			Me.Close()
		End Sub

		' Token: 0x06000563 RID: 1379 RVA: 0x0003F3D4 File Offset: 0x0003D5D4
		Private Sub frmCashSongSong_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				Me.sGetPara_From_SetparaXML()
				Me.sLoadHTTT()
				Me.mdblCashConLai = Me.mdblCash
				Me.btn1.Text = mdlUIForm.gfFormatNumber(Me.mdblCash, CShort(mdlVariable.gbytDECNUMAMT), ",")
				Me.CenterToScreen()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(2), vbCrLf, Me.Name, " - frmCashSongSong_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000564 RID: 1380 RVA: 0x0003F4C4 File Offset: 0x0003D6C4
		Private Sub sLoadHTTT()
			' The following expression was wrapped in a checked-statement
			Try
				Dim clsConnect As clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHTTT")
				Dim b As Byte = 1
				Dim flag As Boolean = clsConnect.Rows.Count > 0
				Dim flag2 As Boolean
				If flag Then
					Try
						For Each obj As Object In clsConnect.Rows
							Dim dataRow As DataRow = CType(obj, DataRow)
							flag2 = Operators.CompareString(dataRow("OBJID").ToString().Trim(), "99", False) = 0
							If flag2 Then
								Me.mstrMaHTTT99 = dataRow("OBJID").ToString().Trim()
							Else
								flag2 = Operators.CompareString(dataRow("OBJID").ToString().Trim(), "01", False) = 0
								If flag2 Then
									Me.lbl1.Text = dataRow("OBJNAME").ToString().Trim()
									Me.lbl1.Tag = dataRow("OBJID").ToString().Trim()
									Me.btn1.Tag = dataRow("LDEBT").ToString().Trim()
									Me.btn1.Enabled = True
								Else
									b += 1
									Select Case b
										Case 2
											Me.lbl2.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl2.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn2.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn2.Enabled = True
										Case 3
											Me.lbl3.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl3.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn3.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn3.Enabled = True
										Case 4
											Me.lbl4.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl4.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn4.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn4.Enabled = True
										Case 5
											Me.lbl5.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl5.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn5.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn5.Enabled = True
										Case 6
											Me.lbl6.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl6.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn6.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn6.Enabled = True
										Case 7
											Me.lbl7.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl7.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn7.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn7.Enabled = True
										Case 8
											Me.lbl8.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl8.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn8.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn8.Enabled = True
										Case 9
											Me.lbl9.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl9.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn9.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn9.Enabled = True
										Case 10
											Me.lbl10.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl10.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn10.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn10.Enabled = True
										Case 11
											Me.lbl11.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl11.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn11.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn11.Enabled = True
										Case 12
											Me.lbl12.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl12.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn12.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn12.Enabled = True
										Case 13
											Me.lbl13.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl13.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn13.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn13.Enabled = True
										Case 14
											Me.lbl14.Text = dataRow("OBJNAME").ToString().Trim()
											Me.lbl14.Tag = dataRow("OBJID").ToString().Trim()
											Me.btn14.Tag = dataRow("LDEBT").ToString().Trim()
											Me.btn14.Enabled = True
									End Select
								End If
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag2 = TypeOf enumerator Is IDisposable
						If flag2 Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
				End If
				flag2 = Me.mstrMaHTTT99.Trim().Length = 0
				If flag2 Then
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(4), "Cash", frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.CanhBao)
					Me.btnExit_Click(RuntimeHelpers.GetObjectValue(New Object()), New EventArgs())
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - sLoadHTTT() " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000565 RID: 1381 RVA: 0x0003FD64 File Offset: 0x0003DF64
		Private Sub btn2_Click(sender As Object, e As EventArgs)
			Try
				Dim button As Button = CType(sender, Button)
				Dim frmNumPad As frmNumPad = New frmNumPad()
				Dim num As Double = Conversion.Val(button.Text.Replace(",", ""))
				frmNumPad.pSglNumberReturn = CSng(num)
				frmNumPad.ShowDialog()
				Dim flag As Boolean = frmNumPad.pbytSuccess = 1
				If flag Then
					Dim num2 As Double = CDbl(frmNumPad.pSglNumberReturn)
					Dim num3 As Double = Conversion.Val(Me.btn1.Text.Replace(",", "")) + num - num2
					flag = num3 >= 0.0
					If flag Then
						button.Text = mdlUIForm.gfFormatNumber(num2, CShort(mdlVariable.gbytDECNUMAMT), ",")
						Me.btn1.Text = mdlUIForm.gfFormatNumber(num3, CShort(mdlVariable.gbytDECNUMAMT), ",")
					Else
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(10), "Cash", frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btn2_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000566 RID: 1382 RVA: 0x0003FF14 File Offset: 0x0003E114
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = mdlDatabase.gfCreateDB_BaseNow()
				Dim b2 As Byte = 0
				Dim flag As Boolean = False
				Dim flag2 As Boolean = False
				Dim text As String = ""
				Dim flag3 As Boolean = Conversion.Val(Me.btn1.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn1.Tag)
					text = Me.lbl1.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn2.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn2.Tag)
					text = Me.lbl2.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn3.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn3.Tag)
					text = Me.lbl3.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn4.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn4.Tag)
					text = Me.lbl4.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn5.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn5.Tag)
					text = Me.lbl5.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn6.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn6.Tag)
					text = Me.lbl6.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn7.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn7.Tag)
					text = Me.lbl7.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn8.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn8.Tag)
					text = Me.lbl8.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn9.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn9.Tag)
					text = Me.lbl9.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn10.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn10.Tag)
					text = Me.lbl10.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn11.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn11.Tag)
					text = Me.lbl11.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn12.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn12.Tag)
					text = Me.lbl12.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn13.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn13.Tag)
					text = Me.lbl13.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = Conversion.Val(Me.btn14.Text.Replace(",", "")) > 0.0
				If flag3 Then
					b2 += 1
					flag = Conversions.ToBoolean(Me.btn14.Tag)
					text = Me.lbl14.Tag.ToString().Trim()
					flag3 = flag
					If flag3 Then
						flag2 = True
					End If
				End If
				flag3 = b2 = 1
				If flag3 Then
					Dim flag4 As Boolean = flag AndAlso Operators.CompareString(mdlVariable.gfrmSaleMode.gstr_Sal_MADV, "", False) = 0
					If flag4 Then
						mdlFile.gfWriteLogFile("Chọn khách quen trong thanh toán song song.")
						Dim frmCustomer As frmCustomer = New frmCustomer()
						frmCustomer.ShowDialog()
						flag4 = frmCustomer.pblnOK
						If Not flag4 Then
							mdlFile.gfWriteLogFile("Hủy chọn khách quen.")
							Return
						End If
						flag3 = Operators.CompareString(mdlVariable.gfrmSaleMode.gstr_Sal_MADV, frmCustomer.pstrMadv, False) <> 0
						Dim flag5 As Boolean
						If flag3 Then
							flag5 = True
						End If
						mdlVariable.gfrmSaleMode.gstr_Sal_MADV = frmCustomer.pstrMadv
						mdlVariable.gfrmSaleMode.lblCus.Text = frmCustomer.pstrTenDv
						mdlVariable.gfrmSaleMode.gstr_Sal_MANHOMDV = frmCustomer.pstrMaNHOMdv
						mdlVariable.gfrmSaleMode.gstr_Sal_DIACHIDV = frmCustomer.pstrDiachi
						mdlVariable.gfrmSaleMode.gstr_Sal_DIENTHOAIDV = frmCustomer.pstrDienthoai
						mdlVariable.gfrmSaleMode.gdt_Sal_NGAYSINHDV = frmCustomer.pdtNgaySinh
						mdlVariable.gfrmSaleMode.gdbl_Sal_MaDV_MucGiamGia = frmCustomer.pdblMucGiamGia
						mdlFile.gfWriteLogFile("Chọn khách quen thành công: " + frmCustomer.pstrMadv + "-" + frmCustomer.pstrTenDv)
						flag4 = flag5 AndAlso mdlVariable.gblnLAUTOTRAPHIEU
						If flag4 Then
							mdlVariable.gfrmSaleMode.psTraPhieu(True)
						End If
					End If
					mdlVariable.gfrmSaleMode.gdtNow = DateAndTime.Now
					b = Me.fCash(Me.mstrSoCT, Me.mstrDateTime, text, True)
				Else
					Dim flag4 As Boolean = flag2 AndAlso Operators.CompareString(mdlVariable.gfrmSaleMode.gstr_Sal_MADV, "", False) = 0
					If flag4 Then
						mdlFile.gfWriteLogFile("Chọn khách quen trong thanh toán song song.")
						Dim frmCustomer2 As frmCustomer = New frmCustomer()
						frmCustomer2.ShowDialog()
						flag4 = frmCustomer2.pblnOK
						If Not flag4 Then
							mdlFile.gfWriteLogFile("Hủy chọn khách quen.")
							Return
						End If
						flag3 = Operators.CompareString(mdlVariable.gfrmSaleMode.gstr_Sal_MADV, frmCustomer2.pstrMadv, False) <> 0
						Dim flag6 As Boolean
						If flag3 Then
							flag6 = True
						End If
						mdlVariable.gfrmSaleMode.gstr_Sal_MADV = frmCustomer2.pstrMadv
						mdlVariable.gfrmSaleMode.lblCus.Text = frmCustomer2.pstrTenDv
						mdlVariable.gfrmSaleMode.gstr_Sal_MANHOMDV = frmCustomer2.pstrMaNHOMdv
						mdlVariable.gfrmSaleMode.gstr_Sal_DIACHIDV = frmCustomer2.pstrDiachi
						mdlVariable.gfrmSaleMode.gstr_Sal_DIENTHOAIDV = frmCustomer2.pstrDienthoai
						mdlVariable.gfrmSaleMode.gdt_Sal_NGAYSINHDV = frmCustomer2.pdtNgaySinh
						mdlVariable.gfrmSaleMode.gdbl_Sal_MaDV_MucGiamGia = frmCustomer2.pdblMucGiamGia
						mdlFile.gfWriteLogFile("Chọn khách quen thành công: " + frmCustomer2.pstrMadv + "-" + frmCustomer2.pstrTenDv)
						flag4 = flag6 AndAlso mdlVariable.gblnLAUTOTRAPHIEU
						If flag4 Then
							mdlVariable.gfrmSaleMode.psTraPhieu(True)
						End If
					End If
					flag4 = -(flag2 > False)
					If flag4 Then
						flag3 = Me.fCheck_Dup_MaDV_PThu_1N(String.Concat(New String() { DateAndTime.Now.Day.ToString("00"), "/", DateAndTime.Now.Month.ToString("00"), "/", DateAndTime.Now.Year.ToString("0000"), " ", DateAndTime.Now.Hour.ToString("00"), ":", DateAndTime.Now.Minute.ToString("00"), ":59" })) = 1
						If flag3 Then
							MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(18), Me.mArrStrFrmMess(1), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.CanhBao)
							Return
						End If
					End If
					mdlVariable.gfrmSaleMode.gdtNow = DateAndTime.Now
					b = Me.fCash(Me.mstrSoCT, Me.mstrDateTime, Me.mstrMaHTTT99, True)
					Dim num As Double = 0.0
					Dim num2 As Double = 0.0
					flag4 = Conversion.Val(Me.btn1.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn1.Text.Replace(",", "")), Me.lbl1.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn1.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn1.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn1.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn2.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn2.Text.Replace(",", "")), Me.lbl2.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn2.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn2.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn2.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn3.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn3.Text.Replace(",", "")), Me.lbl3.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn3.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn3.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn3.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn4.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn4.Text.Replace(",", "")), Me.lbl4.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn4.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn4.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn4.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn5.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn5.Text.Replace(",", "")), Me.lbl5.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn5.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn5.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn5.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn6.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn6.Text.Replace(",", "")), Me.lbl6.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn6.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn6.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn6.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn7.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn7.Text.Replace(",", "")), Me.lbl7.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn7.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn7.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn7.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn8.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn8.Text.Replace(",", "")), Me.lbl8.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn8.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn8.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn8.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn9.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn9.Text.Replace(",", "")), Me.lbl9.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn9.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn9.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn9.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn10.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn10.Text.Replace(",", "")), Me.lbl10.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn10.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn10.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn10.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn11.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn11.Text.Replace(",", "")), Me.lbl11.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn11.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn11.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn11.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn12.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn12.Text.Replace(",", "")), Me.lbl12.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn12.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn12.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn12.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn13.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn13.Text.Replace(",", "")), Me.lbl13.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn13.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn13.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn13.Text.Replace(",", ""))
						End If
					End If
					flag4 = Conversion.Val(Me.btn14.Text.Replace(",", "")) > 0.0
					If flag4 Then
						Me.sInsertPsal99(Me.mstrSoCT, Conversion.Val(Me.btn14.Text.Replace(",", "")), Me.lbl14.Tag.ToString().Trim())
						flag4 = Conversions.ToBoolean(Me.btn14.Tag)
						If flag4 Then
							num += Conversion.Val(Me.btn14.Text.Replace(",", ""))
						Else
							num2 += Conversion.Val(Me.btn14.Text.Replace(",", ""))
						End If
					End If
					flag4 = flag2 AndAlso num <> 0.0
					If flag4 Then
						Dim text2 As String = Me.fCreate_SOCT_PTHU()
						Dim text3 As String = String.Concat(New String() { DateAndTime.Now.Day.ToString("00"), "/", DateAndTime.Now.Month.ToString("00"), "/", DateAndTime.Now.Year.ToString("0000"), " ", DateAndTime.Now.Hour.ToString("00"), ":", DateAndTime.Now.Minute.ToString("00"), ":59" })
						b = Me.fAddNew_PTHU_Mas(text2, text3)
						flag4 = b = 1
						If flag4 Then
							Me.fAddNew_PTHU_Detail(text2, num2)
						Else
							MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(15), Me.mArrStrFrmMess(16), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.CanhBao)
						End If
					End If
				End If
				Me.mbytsuccess = 1
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000567 RID: 1383 RVA: 0x00041704 File Offset: 0x0003F904
		Private Sub sInsertPsal99(strDocID As String, dblAMT As Double, strHTTT As String)
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Try
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchDOCID"
				array(0).Value = Me.pstrSoCT
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHTTT"
				array(1).Value = strHTTT
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@mnyAMT"
				array(2).Value = dblAMT
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@int_Result"
				array(3).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCASHSONGSONG_INSERT_PSALTEMP99", flag)
			Catch ex As Exception
				Interaction.MsgBox(mdlVariable.gArrStrMess(1) + vbCrLf & " sInsertPsal99 " + ex.Message + vbCrLf, MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
		End Sub

		' Token: 0x06000568 RID: 1384 RVA: 0x00041834 File Offset: 0x0003FA34
		Private Function fCash(pstrSOCT As String, pStrTime As String, Optional pStrMAHTTT As String = "01", Optional pblnLREQUEST As Boolean = True) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(40) {}
			Dim b As Byte
			Try
				b = 0
				Dim text As String = pStrTime.Substring(0, 10)
				text = text.Substring(6) + text.Substring(3, 2)
				mdlDatabase.gfCreateDB_Base_First(text)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchDOCID"
				array(0).Value = pstrSOCT
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@prelPERVATBILL"
				array(1).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_PERVATBILL
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pbitLVAT"
				array(2).Value = mdlVariable.gfrmSaleMode.gbyt_Sal_VAT
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchMAHTTT"
				array(3).Value = pStrMAHTTT
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pmnyDISC_BILL"
				array(4).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_DISC_BILL
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@prelPERDISC_BILL"
				array(5).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_PERDISC_BILL
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pmnyDISC_BILLMIX"
				array(6).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_DISC_BILLMIX
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@prelPERDISC_BILLMIX"
				array(7).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_PERDISC_BILLMIX
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pbitLREQUEST"
				array(8).Value = pblnLREQUEST
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pnchMADV"
				array(9).Value = mdlVariable.gfrmSaleMode.gstr_Sal_MADV
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pvcNGKT"
				array(10).Value = pStrTime
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pvcTIMEOUT"
				array(11).Value = pStrTime
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pnchMATT"
				array(12).Value = mdlVariable.gfrmSaleMode.gstr_Sal_MATT
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pnchMAMT"
				array(13).Value = mdlVariable.gfrmSaleMode.gstr_Sal_MAMT
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pmnyTIP"
				array(14).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_TIP
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pmnySERVICE"
				array(15).Value = 0
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pmnyTENDERAMT"
				array(16).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_TENDERAMT
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pmnyEXCHANGE"
				array(17).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_EXCHANGE
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@pnvcREMARK"
				array(18).Value = mdlVariable.gfrmSaleMode.gstr_Sal_REMARK
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pnvcMAUSERPV"
				array(19).Value = mdlVariable.gfrmSaleMode.gstr_Sal_MAUSERPV
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@pnvcMAUSER"
				array(20).Value = mdlVariable.gStrUser
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnchMAMAYBILL"
				array(21).Value = mdlVariable.gStrMachineBill.Trim()
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMAMAYBEP"
				array(22).Value = mdlVariable.gStrMachineKitchen.Trim()
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnchMAMAY"
				array(23).Value = mdlVariable.gStrMachine.Trim()
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@decPERSERVICE"
				array(24).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_PERSER
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@decPERTIME"
				array(25).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_PERTIME_User
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@decPERGROUP"
				array(26).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_PERGROUP
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@nchPERMAGROUP"
				array(27).Value = mdlVariable.gfrmSaleMode.gstr_Sal_PERMAGROUP.Trim()
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@nvcREMARKJOU"
				array(28).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Operators.CompareString(mdlVariable.gfrmSaleMode.gstr_Sal_REMARKJOU, "", False) = 0, "", "," + mdlVariable.gfrmSaleMode.gstr_Sal_REMARKJOU))
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@nvcHANTHANHTOAN"
				array(30).Value = DBNull.Value
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@pnvcREMARK_DIS"
				array(31).Value = ""
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@tniTOATYPE"
				array(32).Value = 3
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pnvcREMARK22"
				array(33).Value = mdlVariable.gfrmSaleMode.gstr_Sal_Remark2
				array(34) = sqlCommand.CreateParameter()
				array(34).ParameterName = "@pnvcREMARK3"
				array(34).Value = mdlVariable.gfrmSaleMode.gstr_Sal_Remark3
				array(35) = sqlCommand.CreateParameter()
				array(35).ParameterName = "@pnvcREMARK4"
				array(35).Value = mdlVariable.gfrmSaleMode.gstr_Sal_Remark4
				array(36) = sqlCommand.CreateParameter()
				array(36).ParameterName = "@pnvcNGAYGIAO"
				array(36).Value = mdlVariable.gfrmSaleMode.gdt_Sal_NgayGiao.ToString("dd/MM/yyyy")
				array(37) = sqlCommand.CreateParameter()
				array(37).ParameterName = "@decPERGROUP2"
				array(37).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_PERGROUP2
				array(38) = sqlCommand.CreateParameter()
				array(38).ParameterName = "@nchPERMAGROUP2"
				array(38).Value = mdlVariable.gfrmSaleMode.gstr_Sal_PERMAGROUP2.Trim()
				array(39) = sqlCommand.CreateParameter()
				array(39).ParameterName = "@pmnyTIENSUDUNG"
				array(39).Value = mdlVariable.gfrmSaleMode.gdbl_Sal_TienDiemSuDung
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@int_Result"
				array(29).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMSAL011_CASH", flag)
				Dim num As Integer = Conversions.ToInteger(array(29).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						b = 1
					Else
						flag2 = num = 2
						If flag2 Then
							Dim flag3 As Boolean = mdlVariable.gstrSOCTReset.Equals(DateAndTime.Now.Year.ToString("0000") + DateAndTime.Now.Month.ToString("00") + DateAndTime.Now.Day.ToString("00"))
							If flag3 Then
								MyProject.Forms.frmMyMessage.Show(mdlVariable.gfrmSaleMode.gArrStrFrmMess(134), mdlVariable.gfrmSaleMode.gArrStrFrmMess(135), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.CanhBao)
							End If
							mdlVariable.gstrSOCTReset = DateAndTime.Now.Year.ToString("0000") + DateAndTime.Now.Month.ToString("00") + DateAndTime.Now.Day.ToString("00")
							Me.fUp_SOCTRESET(mdlVariable.gstrSOCTReset)
							b = 1
						Else
							Dim flag3 As Boolean = num = 99
							If flag3 Then
								b = 99
							Else
								Interaction.MsgBox(mdlVariable.gfrmSaleMode.gArrStrFrmMess(43), MsgBoxStyle.Critical, Nothing)
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { mdlVariable.gfrmSaleMode.gArrStrFrmMess(1), vbCrLf, Me.Name, " - fCash ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmSaleMode.gstr_Sal_HanThanhToan = ""
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000569 RID: 1385 RVA: 0x000422AC File Offset: 0x000404AC
		Private Function fUp_SOCTRESET(pStrSOCT As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nchSOCTRESET"
				array(0).Value = pStrSOCT
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMPARADEFAULT_UPDATE_SOCTRESET", flag)
				Dim flag2 As Boolean = flag
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(mdlVariable.gArrStrMess(1) + vbCrLf & " fUp_SOCTRESET " + ex.Message + vbCrLf, MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600056A RID: 1386 RVA: 0x00042380 File Offset: 0x00040580
		Private Sub lbl_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = CType(sender, Label).Text.Trim().Length = 0
				If Not flag Then
					Me.btn1.Text = "0"
					Me.btn2.Text = "0"
					Me.btn3.Text = "0"
					Me.btn4.Text = "0"
					Me.btn5.Text = "0"
					Me.btn6.Text = "0"
					Me.btn7.Text = "0"
					Me.btn8.Text = "0"
					Me.btn9.Text = "0"
					Me.btn10.Text = "0"
					Me.btn11.Text = "0"
					Me.btn12.Text = "0"
					Me.btn13.Text = "0"
					Me.btn14.Text = "0"
					Dim text As String = CType(sender, Label).Name.Substring(3)
					Me.Controls.Find("btn" + text, True)(0).Text = mdlUIForm.gfFormatNumber(Me.mdblCash, CShort(mdlVariable.gbytDECNUMAMT), ",")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - lbl_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600056B RID: 1387 RVA: 0x00042580 File Offset: 0x00040780
		Private Function fCreate_SOCT_PTHU() As String
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim text As String = ""
			Try
				Dim flag As Boolean = mdlGeneral.gfCheck_Locked() = 1
				If Not flag Then
					flag = (Me.mbytP04SOCT = 1) Or (Me.mbytP04SOCT = 2)
					If flag Then
						array(0) = sqlCommand.CreateParameter()
						array(0).ParameterName = "@pnvcTENDB"
						array(0).Value = "ISDULIEU" + mdlVariable.gStrSelectMonth + ".DBO.PTHU1"
						array(1) = sqlCommand.CreateParameter()
						array(1).ParameterName = "@pnvcDATE"
						Select Case Me.mbytP04SOCT
							Case 1
								array(1).Value = String.Concat(New String() { "T", Strings.Right("000" + mdlVariable.gStrStockCodeRes, 3), Strings.Mid(mdlVariable.gStrSelectMonth, 3, 2), Strings.Mid(mdlVariable.gStrSelectMonth, 5, 2), Strings.Format(DateAndTime.Now.Day, "00"), "/" })
							Case 2
								array(1).Value = String.Concat(New String() { "T", Strings.Right("000" + mdlVariable.gStrStockCodeRes, 3), Strings.Mid(mdlVariable.gStrSelectMonth, 3, 2), Strings.Mid(mdlVariable.gStrSelectMonth, 5, 2), "/" })
						End Select
						array(2) = sqlCommand.CreateParameter()
						array(2).ParameterName = "@pintResult"
						array(2).Direction = ParameterDirection.ReturnValue
						Dim num As Integer
						clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDOCUMENT_GET_MAX_SOCT", num)
						flag = Operators.ConditionalCompareObjectEqual(array(2).Value, 0, False)
						If flag Then
							text = Conversions.ToString(Operators.ConcatenateObject(clsConnect.Rows(0)("SOCT"), ""))
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fCreate_SOCT_PTHU ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return text
		End Function

		' Token: 0x0600056C RID: 1388 RVA: 0x00042864 File Offset: 0x00040A64
		Private Function fAddNew_PTHU_Mas(pstrSOCT As String, pstrNgayGS As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(18) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnvcYYYYMM"
				array(0).Value = mdlVariable.gStrSelectMonth
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchBRANCH"
				array(1).Value = mdlVariable.gStrStockCodeRes
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchSOCT"
				array(2).Value = pstrSOCT
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcNGGS"
				array(3).Value = pstrNgayGS
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvcNGCT"
				array(4).Value = pstrNgayGS
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnchMADV"
				array(5).Value = mdlVariable.gfrmSaleMode.gstr_Sal_MADV.Trim()
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnchHDD_SERIAL"
				array(6).Value = ""
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnchHDD_SOCT"
				array(7).Value = ""
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnchMANV"
				array(8).Value = mdlVariable.gStrUser
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pnvcHDD_NGCT"
				array(9).Value = ""
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pnvcCONTACT"
				array(10).Value = ""
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pnvcREMARK"
				array(11).Value = Me.mArrStrFrmMess(17)
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pnchMALDTHU"
				array(12).Value = "01"
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitLDATHU"
				array(14).Value = True
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pnvcREMARK2"
				array(15).Value = ""
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pnchSOPXUAT"
				array(16).Value = ""
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnchMAHTTT"
				array(17).Value = "01"
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@int_Result"
				array(13).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDULIEU, array, "SP_FRMDOCUMENT04_INSERT", flag)
				Dim num As Integer = Conversions.ToInteger(array(13).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew_PTHU_Mas ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600056D RID: 1389 RVA: 0x00042C74 File Offset: 0x00040E74
		Private Function fAddNew_PTHU_Detail(pstrSOCT As String, pdblAMT As Double) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(7) {}
			Dim b As Byte
			Try
				b = 0
				Dim clsConnect2 As clsConnect = New clsConnect(mdlVariable.gStrConISDULIEU, "PTHU1")
				Dim text As String = ""
				Dim array2 As DataRow() = clsConnect2.[Select]("SOCT = '" + pstrSOCT + "'")
				Dim flag As Boolean = (array2 IsNot Nothing) And (array2.Length > 0)
				If flag Then
					text = array2(0)("DOCID").ToString()
				End If
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchDOCID"
				array(0).Value = text
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pmnyAMT"
				array(1).Value = pdblAMT
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcREMARK"
				array(2).Value = Me.mArrStrFrmMess(17)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchSOCT"
				array(3).Value = ""
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnchLOAICT"
				array(4).Value = ""
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcYYYYMM"
				array(5).Value = ""
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@int_Result"
				array(6).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDULIEU, array, "SP_FRMDOCUMENT04_INSERT_DETAIL", flag2)
				Dim num As Integer = Conversions.ToInteger(array(6).Value)
				flag = num >= 100
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew_PTHU_Detail ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600056E RID: 1390 RVA: 0x00042F00 File Offset: 0x00041100
		Private Function fCheck_Dup_MaDV_PThu_1N(pstrNgayGS As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnvcNGGS"
				array(0).Value = pstrNgayGS
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMADV"
				array(1).Value = mdlVariable.gfrmSaleMode.gstr_Sal_MADV.Trim()
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDULIEU, array, "SP_FRMDOCUMENT04_CHECK_DUP_MADV_1N", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 1
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fCheck_Dup_MaDV_PThu_1N ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0400022B RID: 555
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400022D RID: 557
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x0400022E RID: 558
		<AccessedThroughProperty("TableLayoutPanel5")>
		Private _TableLayoutPanel5 As TableLayoutPanel

		' Token: 0x0400022F RID: 559
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000230 RID: 560
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000231 RID: 561
		<AccessedThroughProperty("TableLayoutPanel3")>
		Private _TableLayoutPanel3 As TableLayoutPanel

		' Token: 0x04000232 RID: 562
		<AccessedThroughProperty("TableLayoutPanel2")>
		Private _TableLayoutPanel2 As TableLayoutPanel

		' Token: 0x04000233 RID: 563
		<AccessedThroughProperty("lbl8")>
		Private _lbl8 As Label

		' Token: 0x04000234 RID: 564
		<AccessedThroughProperty("lbl9")>
		Private _lbl9 As Label

		' Token: 0x04000235 RID: 565
		<AccessedThroughProperty("lbl13")>
		Private _lbl13 As Label

		' Token: 0x04000236 RID: 566
		<AccessedThroughProperty("lbl11")>
		Private _lbl11 As Label

		' Token: 0x04000237 RID: 567
		<AccessedThroughProperty("lbl10")>
		Private _lbl10 As Label

		' Token: 0x04000238 RID: 568
		<AccessedThroughProperty("lbl12")>
		Private _lbl12 As Label

		' Token: 0x04000239 RID: 569
		<AccessedThroughProperty("lbl14")>
		Private _lbl14 As Label

		' Token: 0x0400023A RID: 570
		<AccessedThroughProperty("lbl1")>
		Private _lbl1 As Label

		' Token: 0x0400023B RID: 571
		<AccessedThroughProperty("lbl2")>
		Private _lbl2 As Label

		' Token: 0x0400023C RID: 572
		<AccessedThroughProperty("lbl4")>
		Private _lbl4 As Label

		' Token: 0x0400023D RID: 573
		<AccessedThroughProperty("lbl6")>
		Private _lbl6 As Label

		' Token: 0x0400023E RID: 574
		<AccessedThroughProperty("lbl3")>
		Private _lbl3 As Label

		' Token: 0x0400023F RID: 575
		<AccessedThroughProperty("lbl5")>
		Private _lbl5 As Label

		' Token: 0x04000240 RID: 576
		<AccessedThroughProperty("lbl7")>
		Private _lbl7 As Label

		' Token: 0x04000241 RID: 577
		<AccessedThroughProperty("btn1")>
		Private _btn1 As Button

		' Token: 0x04000242 RID: 578
		<AccessedThroughProperty("btn8")>
		Private _btn8 As Button

		' Token: 0x04000243 RID: 579
		<AccessedThroughProperty("btn9")>
		Private _btn9 As Button

		' Token: 0x04000244 RID: 580
		<AccessedThroughProperty("btn10")>
		Private _btn10 As Button

		' Token: 0x04000245 RID: 581
		<AccessedThroughProperty("btn11")>
		Private _btn11 As Button

		' Token: 0x04000246 RID: 582
		<AccessedThroughProperty("btn12")>
		Private _btn12 As Button

		' Token: 0x04000247 RID: 583
		<AccessedThroughProperty("btn13")>
		Private _btn13 As Button

		' Token: 0x04000248 RID: 584
		<AccessedThroughProperty("btn14")>
		Private _btn14 As Button

		' Token: 0x04000249 RID: 585
		<AccessedThroughProperty("btn2")>
		Private _btn2 As Button

		' Token: 0x0400024A RID: 586
		<AccessedThroughProperty("btn3")>
		Private _btn3 As Button

		' Token: 0x0400024B RID: 587
		<AccessedThroughProperty("btn4")>
		Private _btn4 As Button

		' Token: 0x0400024C RID: 588
		<AccessedThroughProperty("btn5")>
		Private _btn5 As Button

		' Token: 0x0400024D RID: 589
		<AccessedThroughProperty("btn6")>
		Private _btn6 As Button

		' Token: 0x0400024E RID: 590
		<AccessedThroughProperty("btn7")>
		Private _btn7 As Button

		' Token: 0x0400024F RID: 591
		Private mbytsuccess As Byte

		' Token: 0x04000250 RID: 592
		Private mdblCash As Double

		' Token: 0x04000251 RID: 593
		Private mstrSoCT As String

		' Token: 0x04000252 RID: 594
		Private mstrDateTime As String

		' Token: 0x04000253 RID: 595
		Private mstrMaBan As String

		' Token: 0x04000254 RID: 596
		Private mstrTenBan As String

		' Token: 0x04000255 RID: 597
		Private mArrStrFrmMess As String()

		' Token: 0x04000256 RID: 598
		Private mstrMaDVT As String

		' Token: 0x04000257 RID: 599
		Private mstrMaHTTT99 As String

		' Token: 0x04000258 RID: 600
		Private mdblCashConLai As Double

		' Token: 0x04000259 RID: 601
		Private mbytP04SOCT As Byte
	End Class
End Namespace
