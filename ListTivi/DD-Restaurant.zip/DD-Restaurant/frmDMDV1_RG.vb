﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000043 RID: 67
	<DesignerGenerated()>
	Public Partial Class frmDMDV1_RG
		Inherits Form

		' Token: 0x06001078 RID: 4216 RVA: 0x000C69DC File Offset: 0x000C4BDC
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMDV1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMDV1_Load
			frmDMDV1_RG.__ENCList.Add(New WeakReference(Me))
			Me.mStrOBJID = ""
			Me.mStrOBJNAME = ""
			Me.mStrMANHOMDV = ""
			Me.mStrCardCode = ""
			Me.mbdsSource = New BindingSource()
			Me.mclsTbNHDV = New clsConnect()
			Me.mIntType = 4S
			Me.mblnAutoAdd_DMDV = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x170005C7 RID: 1479
		' (get) Token: 0x0600107B RID: 4219 RVA: 0x000C801C File Offset: 0x000C621C
		' (set) Token: 0x0600107C RID: 4220 RVA: 0x000048C2 File Offset: 0x00002AC2
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x170005C8 RID: 1480
		' (get) Token: 0x0600107D RID: 4221 RVA: 0x000C8034 File Offset: 0x000C6234
		' (set) Token: 0x0600107E RID: 4222 RVA: 0x000C804C File Offset: 0x000C624C
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x170005C9 RID: 1481
		' (get) Token: 0x0600107F RID: 4223 RVA: 0x000C80B8 File Offset: 0x000C62B8
		' (set) Token: 0x06001080 RID: 4224 RVA: 0x000C80D0 File Offset: 0x000C62D0
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170005CA RID: 1482
		' (get) Token: 0x06001081 RID: 4225 RVA: 0x000C813C File Offset: 0x000C633C
		' (set) Token: 0x06001082 RID: 4226 RVA: 0x000C8154 File Offset: 0x000C6354
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x170005CB RID: 1483
		' (get) Token: 0x06001083 RID: 4227 RVA: 0x000C81C0 File Offset: 0x000C63C0
		' (set) Token: 0x06001084 RID: 4228 RVA: 0x000C81D8 File Offset: 0x000C63D8
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x170005CC RID: 1484
		' (get) Token: 0x06001085 RID: 4229 RVA: 0x000C8244 File Offset: 0x000C6444
		' (set) Token: 0x06001086 RID: 4230 RVA: 0x000C825C File Offset: 0x000C645C
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170005CD RID: 1485
		' (get) Token: 0x06001087 RID: 4231 RVA: 0x000C82C8 File Offset: 0x000C64C8
		' (set) Token: 0x06001088 RID: 4232 RVA: 0x000C82E0 File Offset: 0x000C64E0
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x170005CE RID: 1486
		' (get) Token: 0x06001089 RID: 4233 RVA: 0x000C834C File Offset: 0x000C654C
		' (set) Token: 0x0600108A RID: 4234 RVA: 0x000C8364 File Offset: 0x000C6564
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170005CF RID: 1487
		' (get) Token: 0x0600108B RID: 4235 RVA: 0x000C83D0 File Offset: 0x000C65D0
		' (set) Token: 0x0600108C RID: 4236 RVA: 0x000048CC File Offset: 0x00002ACC
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x170005D0 RID: 1488
		' (get) Token: 0x0600108D RID: 4237 RVA: 0x000C83E8 File Offset: 0x000C65E8
		' (set) Token: 0x0600108E RID: 4238 RVA: 0x000C8400 File Offset: 0x000C6600
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x170005D1 RID: 1489
		' (get) Token: 0x0600108F RID: 4239 RVA: 0x000C846C File Offset: 0x000C666C
		' (set) Token: 0x06001090 RID: 4240 RVA: 0x000C8484 File Offset: 0x000C6684
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x170005D2 RID: 1490
		' (get) Token: 0x06001091 RID: 4241 RVA: 0x000C84F0 File Offset: 0x000C66F0
		' (set) Token: 0x06001092 RID: 4242 RVA: 0x000C8508 File Offset: 0x000C6708
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170005D3 RID: 1491
		' (get) Token: 0x06001093 RID: 4243 RVA: 0x000C8574 File Offset: 0x000C6774
		' (set) Token: 0x06001094 RID: 4244 RVA: 0x000048D6 File Offset: 0x00002AD6
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170005D4 RID: 1492
		' (get) Token: 0x06001095 RID: 4245 RVA: 0x000C858C File Offset: 0x000C678C
		' (set) Token: 0x06001096 RID: 4246 RVA: 0x000C85A4 File Offset: 0x000C67A4
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x170005D5 RID: 1493
		' (get) Token: 0x06001097 RID: 4247 RVA: 0x000C8610 File Offset: 0x000C6810
		' (set) Token: 0x06001098 RID: 4248 RVA: 0x000C8628 File Offset: 0x000C6828
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x170005D6 RID: 1494
		' (get) Token: 0x06001099 RID: 4249 RVA: 0x000C8694 File Offset: 0x000C6894
		' (set) Token: 0x0600109A RID: 4250 RVA: 0x000C86AC File Offset: 0x000C68AC
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170005D7 RID: 1495
		' (get) Token: 0x0600109B RID: 4251 RVA: 0x000C8718 File Offset: 0x000C6918
		' (set) Token: 0x0600109C RID: 4252 RVA: 0x000C8730 File Offset: 0x000C6930
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x170005D8 RID: 1496
		' (get) Token: 0x0600109D RID: 4253 RVA: 0x000C879C File Offset: 0x000C699C
		' (set) Token: 0x0600109E RID: 4254 RVA: 0x000C87B4 File Offset: 0x000C69B4
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170005D9 RID: 1497
		' (get) Token: 0x0600109F RID: 4255 RVA: 0x000C8820 File Offset: 0x000C6A20
		' (set) Token: 0x060010A0 RID: 4256 RVA: 0x000C8838 File Offset: 0x000C6A38
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x170005DA RID: 1498
		' (get) Token: 0x060010A1 RID: 4257 RVA: 0x000C88A4 File Offset: 0x000C6AA4
		' (set) Token: 0x060010A2 RID: 4258 RVA: 0x000048E0 File Offset: 0x00002AE0
		Friend Overridable Property lblStore As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblStore
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblStore = value
			End Set
		End Property

		' Token: 0x170005DB RID: 1499
		' (get) Token: 0x060010A3 RID: 4259 RVA: 0x000C88BC File Offset: 0x000C6ABC
		' (set) Token: 0x060010A4 RID: 4260 RVA: 0x000048EA File Offset: 0x00002AEA
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170005DC RID: 1500
		' (get) Token: 0x060010A5 RID: 4261 RVA: 0x000C88D4 File Offset: 0x000C6AD4
		' (set) Token: 0x060010A6 RID: 4262 RVA: 0x000048F4 File Offset: 0x00002AF4
		Friend Overridable Property txtOBJNAMENHDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAMENHDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAMENHDV = value
			End Set
		End Property

		' Token: 0x170005DD RID: 1501
		' (get) Token: 0x060010A7 RID: 4263 RVA: 0x000C88EC File Offset: 0x000C6AEC
		' (set) Token: 0x060010A8 RID: 4264 RVA: 0x000C8904 File Offset: 0x000C6B04
		Friend Overridable Property btnSelectNHDV As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelectNHDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelectNHDV IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelectNHDV.Click, AddressOf Me.btnSelectNHDV_Click
				End If
				Me._btnSelectNHDV = value
				flag = Me._btnSelectNHDV IsNot Nothing
				If flag Then
					AddHandler Me._btnSelectNHDV.Click, AddressOf Me.btnSelectNHDV_Click
				End If
			End Set
		End Property

		' Token: 0x170005DE RID: 1502
		' (get) Token: 0x060010A9 RID: 4265 RVA: 0x000C8970 File Offset: 0x000C6B70
		' (set) Token: 0x060010AA RID: 4266 RVA: 0x000C8988 File Offset: 0x000C6B88
		Friend Overridable Property txtOBJIDNHDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJIDNHDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJIDNHDV IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJIDNHDV.TextChanged, AddressOf Me.txtOBJIDNHDV_TextChanged
				End If
				Me._txtOBJIDNHDV = value
				flag = Me._txtOBJIDNHDV IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJIDNHDV.TextChanged, AddressOf Me.txtOBJIDNHDV_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170005DF RID: 1503
		' (get) Token: 0x060010AB RID: 4267 RVA: 0x000C89F4 File Offset: 0x000C6BF4
		' (set) Token: 0x060010AC RID: 4268 RVA: 0x000C8A0C File Offset: 0x000C6C0C
		Friend Overridable Property btnSendMail As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSendMail
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSendMail IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSendMail.Click, AddressOf Me.btnSendMail_Click
				End If
				Me._btnSendMail = value
				flag = Me._btnSendMail IsNot Nothing
				If flag Then
					AddHandler Me._btnSendMail.Click, AddressOf Me.btnSendMail_Click
				End If
			End Set
		End Property

		' Token: 0x170005E0 RID: 1504
		' (get) Token: 0x060010AD RID: 4269 RVA: 0x000C8A78 File Offset: 0x000C6C78
		' (set) Token: 0x060010AE RID: 4270 RVA: 0x000C8A90 File Offset: 0x000C6C90
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170005E1 RID: 1505
		' (get) Token: 0x060010AF RID: 4271 RVA: 0x000C8AFC File Offset: 0x000C6CFC
		' (set) Token: 0x060010B0 RID: 4272 RVA: 0x000048FE File Offset: 0x00002AFE
		Public Property pblnIsOK As Boolean
			Get
				Return Me.mblnIsOK
			End Get
			Set(value As Boolean)
				Me.mblnIsOK = value
			End Set
		End Property

		' Token: 0x170005E2 RID: 1506
		' (get) Token: 0x060010B1 RID: 4273 RVA: 0x000C8B14 File Offset: 0x000C6D14
		' (set) Token: 0x060010B2 RID: 4274 RVA: 0x00004909 File Offset: 0x00002B09
		Public Property pIntType As Short
			Get
				Return Me.mIntType
			End Get
			Set(value As Short)
				Me.mIntType = value
			End Set
		End Property

		' Token: 0x170005E3 RID: 1507
		' (get) Token: 0x060010B3 RID: 4275 RVA: 0x000C8B2C File Offset: 0x000C6D2C
		' (set) Token: 0x060010B4 RID: 4276 RVA: 0x00004914 File Offset: 0x00002B14
		Public Property pStrCardCode As String
			Get
				Return Me.mStrCardCode
			End Get
			Set(value As String)
				Me.mStrCardCode = value
			End Set
		End Property

		' Token: 0x170005E4 RID: 1508
		' (get) Token: 0x060010B5 RID: 4277 RVA: 0x000C8B44 File Offset: 0x000C6D44
		' (set) Token: 0x060010B6 RID: 4278 RVA: 0x0000491F File Offset: 0x00002B1F
		Public Property pStrMANHOMDV As String
			Get
				Return Me.mStrMANHOMDV
			End Get
			Set(value As String)
				Me.mStrMANHOMDV = value
			End Set
		End Property

		' Token: 0x170005E5 RID: 1509
		' (get) Token: 0x060010B7 RID: 4279 RVA: 0x000C8B5C File Offset: 0x000C6D5C
		' (set) Token: 0x060010B8 RID: 4280 RVA: 0x0000492A File Offset: 0x00002B2A
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x170005E6 RID: 1510
		' (get) Token: 0x060010B9 RID: 4281 RVA: 0x000C8B74 File Offset: 0x000C6D74
		' (set) Token: 0x060010BA RID: 4282 RVA: 0x00004935 File Offset: 0x00002B35
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x170005E7 RID: 1511
		' (get) Token: 0x060010BB RID: 4283 RVA: 0x000C8B8C File Offset: 0x000C6D8C
		' (set) Token: 0x060010BC RID: 4284 RVA: 0x00004940 File Offset: 0x00002B40
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060010BD RID: 4285 RVA: 0x000C8BA4 File Offset: 0x000C6DA4
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				Me.mStrOBJNAME = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				Me.mStrMANHOMDV = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
				Me.mStrCardCode = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CARDCODE").Value, ""))
				Me.mblnIsOK = True
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010BE RID: 4286 RVA: 0x000C8D2C File Offset: 0x000C6F2C
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010BF RID: 4287 RVA: 0x000C8DFC File Offset: 0x000C6FFC
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010C0 RID: 4288 RVA: 0x000C8EEC File Offset: 0x000C70EC
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010C1 RID: 4289 RVA: 0x000C8FD0 File Offset: 0x000C71D0
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010C2 RID: 4290 RVA: 0x000C9094 File Offset: 0x000C7294
		Private Sub frmDMDV1_FormClosing(sender As Object, e As FormClosingEventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim array As String() = New String(0) {}
				Try
					For Each obj As Object In Me.dgvData.Columns
						Dim dataGridViewColumn As DataGridViewColumn = CType(obj, DataGridViewColumn)
						Dim flag As Boolean = dataGridViewColumn.Visible
						If flag Then
							Dim num As Long
							array(CInt(num)) = Conversions.ToString(dataGridViewColumn.Width)
							num += 1L
							array = CType(Utils.CopyArray(CType(array, Array), New String(CInt(num) + 1 - 1) {}), String())
						End If
					Next
				Finally
					Dim enumerator As IEnumerator
					Dim flag As Boolean = TypeOf enumerator Is IDisposable
					If flag Then
						TryCast(enumerator, IDisposable).Dispose()
					End If
				End Try
				mdlFile.gfWriteGridSize_From_Array(array, mdlVariable.gStrPathApp + "\SIZEGRID\DMDVRG.ini")
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDV1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010C3 RID: 4291 RVA: 0x000C9214 File Offset: 0x000C7414
		Private Sub frmDMDV1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Combo()
				End If
				Me.sGetPara_From_SetparaXML()
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
				flag = Me.dgvData.RowCount > 0
				If flag Then
					Me.dgvData.Rows(0).Selected = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDV1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010C4 RID: 4292 RVA: 0x000C9378 File Offset: 0x000C7578
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010C5 RID: 4293 RVA: 0x000C9480 File Offset: 0x000C7680
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.mblnIsOK = False
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010C6 RID: 4294 RVA: 0x000C9520 File Offset: 0x000C7720
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMDV2_RG As frmDMDV2_RG = New frmDMDV2_RG()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMDV2_RG.pbytFromStatus = 1
				frmDMDV2_RG.chkISCUS.Checked = True
				Dim flag As Boolean = Me.mbdsSource.Count > 0
				If flag Then
					frmDMDV2_RG.pStrStore = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				End If
				flag = Me.mblnAutoAdd_DMDV
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim num As Integer
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_GET_MAX_OBJID", num)
					flag = clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
					If flag Then
						frmDMDV2_RG.txtOBJID.Text = clsConnect.Rows(0)("OBJID").ToString()
						frmDMDV2_RG.txtOBJID.[ReadOnly] = True
						frmDMDV2_RG.txtOBJID.BackColor = frmDMDV2_RG.txtColor.BackColor
					End If
				End If
				frmDMDV2_RG.ShowDialog()
				flag = frmDMDV2_RG.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0 AndAlso Not Me.mblnAutoAdd_DMDV
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMDV2_RG.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						' The following expression was wrapped in a checked-expression
						Me.mbdsSource.Position = Me.mbdsSource.Count - 1
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					flag = frmDMDV2_RG.pblnSaveAndSelect AndAlso Me.pBytOpen_From_Menu <> 8
					If flag Then
						Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMDV2_RG.Dispose()
			End Try
		End Sub

		' Token: 0x060010C7 RID: 4295 RVA: 0x000C9824 File Offset: 0x000C7A24
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMDV2_RG As frmDMDV2_RG = New frmDMDV2_RG()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMDV2_RG2 As frmDMDV2_RG = frmDMDV2_RG
				frmDMDV2_RG2.pbytFromStatus = 2
				frmDMDV2_RG2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMDV2_RG2.pStrStore = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMDV2_RG2.txtADDRESS.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("ADDRESS").Value, ""))
				frmDMDV2_RG2.txtTEL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TEL").Value, ""))
				frmDMDV2_RG2.txtMOBILE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MOBILE").Value, ""))
				frmDMDV2_RG2.txtCONTACT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CONTACT").Value, ""))
				frmDMDV2_RG2.txtVATCODE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("VATCODE").Value, ""))
				frmDMDV2_RG2.txtFAX.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FAX").Value, ""))
				frmDMDV2_RG2.txtEMAIL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("EMAIL").Value, ""))
				frmDMDV2_RG2.txtWEBSITE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("WEBSITE").Value, ""))
				frmDMDV2_RG2.pStrBIRTHDAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BIRTHDAY").Value, ""))
				frmDMDV2_RG2.TxtMANHOMDV.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
				frmDMDV2_RG2.txtJOB.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("JOB").Value, ""))
				frmDMDV2_RG2.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMDV2_RG2.txtTUOI.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUOI").Value, ""))
				frmDMDV2_RG2.pBytGIOITINH = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("GIOITINH").Value)
				frmDMDV2_RG2.txtCAP.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CAP").Value, ""))
				frmDMDV2_RG2.txtCHUCVU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CHUCVU").Value, ""))
				frmDMDV2_RG2.chkISCUS.Checked = False
				frmDMDV2_RG2.chkISFOR.Checked = False
				frmDMDV2_RG2.chkISORG.Checked = False
				frmDMDV2_RG2.chkISSUP.Checked = False
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISSUP").Value)
				If flag Then
					frmDMDV2_RG2.chkISSUP.Checked = True
				End If
				flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISCUS").Value)
				If flag Then
					frmDMDV2_RG2.chkISCUS.Checked = True
				End If
				flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISFOR").Value)
				If flag Then
					frmDMDV2_RG2.chkISFOR.Checked = True
				End If
				flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISORG").Value)
				If flag Then
					frmDMDV2_RG2.chkISORG.Checked = True
				End If
				flag = Me.mblnAutoAdd_DMDV
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim num As Integer
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_GET_MAX_OBJID", num)
					flag = clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
					If flag Then
						frmDMDV2_RG.txtOBJID.Text = clsConnect.Rows(0)("OBJID").ToString()
						frmDMDV2_RG.txtOBJID.[ReadOnly] = True
						frmDMDV2_RG.txtOBJID.BackColor = frmDMDV2_RG.txtColor.BackColor
					End If
				End If
				frmDMDV2_RG.ShowDialog()
				flag = frmDMDV2_RG.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0 AndAlso Not Me.mblnAutoAdd_DMDV
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMDV2_RG.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						' The following expression was wrapped in a checked-expression
						Me.mbdsSource.Position = Me.mbdsSource.Count - 1
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					flag = frmDMDV2_RG.pblnSaveAndSelect AndAlso Me.pBytOpen_From_Menu <> 8
					If flag Then
						Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMDV2_RG.Dispose()
			End Try
		End Sub

		' Token: 0x060010C8 RID: 4296 RVA: 0x000CA000 File Offset: 0x000C8200
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMDV2_RG As frmDMDV2_RG = New frmDMDV2_RG()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					frmDMDV2_RG.Dispose()
				Else
					flag = mdlVariable.gblnLRIGHTFORUSER AndAlso Operators.CompareString(mdlVariable.gStrUser.Trim(), Me.dgvData.CurrentRow.Cells("MAUSERUP").Value.ToString().Trim(), False) <> 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(41), MsgBoxStyle.Critical, Nothing)
						frmDMDV2_RG.Dispose()
					Else
						Dim frmDMDV2_RG2 As frmDMDV2_RG = frmDMDV2_RG
						frmDMDV2_RG2.pbytFromStatus = 3
						frmDMDV2_RG2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
						frmDMDV2_RG2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
						frmDMDV2_RG2.pStrStore = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
						frmDMDV2_RG2.txtADDRESS.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("ADDRESS").Value, ""))
						frmDMDV2_RG2.txtTEL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TEL").Value, ""))
						frmDMDV2_RG2.txtMOBILE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MOBILE").Value, ""))
						frmDMDV2_RG2.txtCONTACT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CONTACT").Value, ""))
						frmDMDV2_RG2.txtVATCODE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("VATCODE").Value, ""))
						frmDMDV2_RG2.txtFAX.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FAX").Value, ""))
						frmDMDV2_RG2.txtEMAIL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("EMAIL").Value, ""))
						frmDMDV2_RG2.txtWEBSITE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("WEBSITE").Value, ""))
						frmDMDV2_RG2.pStrBIRTHDAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BIRTHDAY").Value, ""))
						frmDMDV2_RG2.TxtMANHOMDV.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
						frmDMDV2_RG2.txtJOB.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("JOB").Value, ""))
						frmDMDV2_RG2.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
						frmDMDV2_RG2.txtTUOI.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUOI").Value, ""))
						frmDMDV2_RG2.pBytGIOITINH = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("GIOITINH").Value)
						frmDMDV2_RG2.txtCAP.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("CAP").Value)
						frmDMDV2_RG2.txtCHUCVU.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("CHUCVU").Value)
						frmDMDV2_RG2.pStrFinger1 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER1").Value)
						frmDMDV2_RG2.pStrFinger2 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER2").Value)
						frmDMDV2_RG2.pStrFinger3 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER3").Value)
						frmDMDV2_RG2.txtCardCode.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("CARDCODE").Value)
						Try
							frmDMDV2_RG2.pstrUIMAGE = Me.dgvData.CurrentRow.Cells("UIMAGE").Value.ToString().Trim()
							frmDMDV2_RG2.picAnh.BackgroundImage = Image.FromFile(Me.dgvData.CurrentRow.Cells("UIMAGE").Value.ToString().Trim())
						Catch ex As Exception
						End Try
						frmDMDV2_RG2.chkISCUS.Checked = False
						frmDMDV2_RG2.chkISFOR.Checked = False
						frmDMDV2_RG2.chkISORG.Checked = False
						frmDMDV2_RG2.chkISSUP.Checked = False
						flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISSUP").Value)
						If flag Then
							frmDMDV2_RG2.chkISSUP.Checked = True
						End If
						flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISCUS").Value)
						If flag Then
							frmDMDV2_RG2.chkISCUS.Checked = True
						End If
						flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISFOR").Value)
						If flag Then
							frmDMDV2_RG2.chkISFOR.Checked = True
						End If
						flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISORG").Value)
						If flag Then
							frmDMDV2_RG2.chkISORG.Checked = True
						End If
						frmDMDV2_RG2 = Nothing
						frmDMDV2_RG.ShowDialog()
						flag = frmDMDV2_RG.pbytSuccess = 0
						If Not flag Then
							Dim b As Byte = Me.fGetData_4Grid()
							flag = b = 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
							End If
							flag = b <> 0
							If flag Then
								b = Me.fInitGrid()
							End If
							flag = b <> 0
							If flag Then
								Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMDV2_RG.pStrFilter)
								Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
							End If
							flag = frmDMDV2_RG.pblnSaveAndSelect AndAlso Me.pBytOpen_From_Menu <> 8
							If flag Then
								Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
							End If
						End If
					End If
				End If
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDV2_RG.Dispose()
			End Try
		End Sub

		' Token: 0x060010C9 RID: 4297 RVA: 0x000CA8B8 File Offset: 0x000C8AB8
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMDV2_RG As frmDMDV2_RG = New frmDMDV2_RG()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
					frmDMDV2_RG.Dispose()
				Else
					flag = mdlVariable.gblnLRIGHTFORUSER AndAlso Operators.CompareString(mdlVariable.gStrUser.Trim(), Me.dgvData.CurrentRow.Cells("MAUSERUP").Value.ToString().Trim(), False) <> 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(41), MsgBoxStyle.Critical, Nothing)
						frmDMDV2_RG.Dispose()
					Else
						Dim frmDMDV2_RG2 As frmDMDV2_RG = frmDMDV2_RG
						frmDMDV2_RG2.pbytFromStatus = 4
						frmDMDV2_RG2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
						frmDMDV2_RG2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
						frmDMDV2_RG2.pStrStore = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
						frmDMDV2_RG2.txtADDRESS.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("ADDRESS").Value, ""))
						frmDMDV2_RG2.txtTEL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TEL").Value, ""))
						frmDMDV2_RG2.txtMOBILE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MOBILE").Value, ""))
						frmDMDV2_RG2.txtCONTACT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CONTACT").Value, ""))
						frmDMDV2_RG2.txtVATCODE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("VATCODE").Value, ""))
						frmDMDV2_RG2.txtFAX.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FAX").Value, ""))
						frmDMDV2_RG2.txtEMAIL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("EMAIL").Value, ""))
						frmDMDV2_RG2.txtWEBSITE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("WEBSITE").Value, ""))
						frmDMDV2_RG2.pStrBIRTHDAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BIRTHDAY").Value, ""))
						frmDMDV2_RG2.TxtMANHOMDV.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
						frmDMDV2_RG2.txtJOB.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("JOB").Value, ""))
						frmDMDV2_RG2.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
						frmDMDV2_RG2.txtTUOI.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUOI").Value, ""))
						frmDMDV2_RG2.pBytGIOITINH = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("GIOITINH").Value)
						frmDMDV2_RG2.pStrFinger1 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER1").Value)
						frmDMDV2_RG2.pStrFinger2 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER2").Value)
						frmDMDV2_RG2.pStrFinger3 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER3").Value)
						frmDMDV2_RG2.txtCardCode.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("CARDCODE").Value)
						frmDMDV2_RG2.chkISCUS.Checked = False
						frmDMDV2_RG2.chkISFOR.Checked = False
						frmDMDV2_RG2.chkISORG.Checked = False
						frmDMDV2_RG2.chkISSUP.Checked = False
						flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISSUP").Value)
						If flag Then
							frmDMDV2_RG2.chkISSUP.Checked = True
						End If
						flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISCUS").Value)
						If flag Then
							frmDMDV2_RG2.chkISCUS.Checked = True
						End If
						flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISFOR").Value)
						If flag Then
							frmDMDV2_RG2.chkISFOR.Checked = True
						End If
						flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISORG").Value)
						If flag Then
							frmDMDV2_RG2.chkISORG.Checked = True
						End If
						frmDMDV2_RG.ShowDialog()
						flag = frmDMDV2_RG.pbytSuccess = 0
						If Not flag Then
							Dim b As Byte = Me.fGetData_4Grid()
							flag = b = 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
							End If
							flag = b <> 0
							If flag Then
								b = Me.fInitGrid()
							End If
							flag = b <> 0
							If flag Then
								Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDV2_RG.Dispose()
			End Try
		End Sub

		' Token: 0x060010CA RID: 4298 RVA: 0x000CB034 File Offset: 0x000C9234
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMDV2_RG As frmDMDV2_RG = New frmDMDV2_RG()
			Try
				frmDMDV2_RG.pbytFromStatus = 6
				frmDMDV2_RG.ShowDialog()
				Dim flag As Boolean = frmDMDV2_RG.pbytSuccess = 0
				If flag Then
					frmDMDV2_RG.Dispose()
				Else
					Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Me.txtOBJIDNHDV.Text.Trim(), "", False) <> 0, " AND MAKH ='" + Me.txtOBJIDNHDV.Text.Trim() + "'", ""))
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMDV2_RG.pStrFilter + text, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMDV2_RG.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDV2_RG.Dispose()
			End Try
		End Sub

		' Token: 0x060010CB RID: 4299 RVA: 0x000CB280 File Offset: 0x000C9480
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMDV2_RG As frmDMDV2_RG = New frmDMDV2_RG()
			Try
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				frmDMDV2_RG.pbytFromStatus = 5
				frmDMDV2_RG.ShowDialog()
				Dim flag As Boolean = frmDMDV2_RG.pbytSuccess = 0
				If Not flag Then
					Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Me.txtOBJIDNHDV.Text.Trim(), "", False) <> 0, " AND MAKH ='" + Me.txtOBJIDNHDV.Text.Trim() + "'", ""))
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMDV2_RG.pStrFilter + text
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDV2_RG.Dispose()
			End Try
		End Sub

		' Token: 0x060010CC RID: 4300 RVA: 0x000CB408 File Offset: 0x000C9608
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMDV2_RG As frmDMDV2_RG = New frmDMDV2_RG()
			Try
				Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Me.txtOBJIDNHDV.Text.Trim(), "", False) <> 0, " MAKH ='" + Me.txtOBJIDNHDV.Text.Trim() + "'", ""))
				Me.mbdsSource.RemoveFilter()
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0
				If flag Then
					Me.mbdsSource.Filter = text
				End If
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDV2_RG.Dispose()
			End Try
		End Sub

		' Token: 0x060010CD RID: 4301 RVA: 0x000CB544 File Offset: 0x000C9744
		Private Sub btnSelectNHDV_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMNHOMDV As frmDMNHOMDV1 = New frmDMNHOMDV1()
				frmDMNHOMDV.pBytOpen_From_Menu = 7
				frmDMNHOMDV.ShowDialog()
				Me.txtOBJIDNHDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNHOMDV.pStrOBJID, "", False) = 0, Me.txtOBJIDNHDV.Text, frmDMNHOMDV.pStrOBJID))
				frmDMNHOMDV.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelectNHDV_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010CE RID: 4302 RVA: 0x000CB62C File Offset: 0x000C982C
		Private Sub txtOBJIDNHDV_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbNHDV Is Nothing
				If Not flag Then
					Me.btnCancelFilter.Visible = False
					array(0) = Me.mclsTbNHDV.Columns("OBJID")
					Me.mclsTbNHDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbNHDV.Rows.Find(Strings.Trim(Me.txtOBJIDNHDV.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtOBJNAMENHDV.Text = dataRow("OBJNAME").ToString()
						Me.mbdsSource.Filter = "MANHOMDV like '" + Strings.Replace(Strings.Trim(Me.txtOBJIDNHDV.Text), "'", "''", 1, -1, CompareMethod.Binary) + "'"
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						Me.btnCancelFilter.Visible = False
						Me.btnFindNext.Visible = False
					Else
						Me.txtOBJNAMENHDV.Text = ""
						Me.mbdsSource.RemoveFilter()
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJIDNHDV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010CF RID: 4303 RVA: 0x000CB810 File Offset: 0x000C9A10
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x060010D0 RID: 4304 RVA: 0x000CB98C File Offset: 0x000C9B8C
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Interaction.MsgBox(Me.mArrStrFrmMess(42), MsgBoxStyle.YesNo, Nothing) = MsgBoxResult.Yes
				If flag Then
					Dim flag2 As Boolean = Me.dgvData.RowCount <= 0
					If Not flag2 Then
						Dim b As Byte = Me.fPrintDMDVDetail(Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))))
					End If
				Else
					Dim b As Byte = Me.fPrintDMDV(Me.txtOBJIDNHDV.Text.Trim())
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010D1 RID: 4305 RVA: 0x000CBAA8 File Offset: 0x000C9CA8
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010D2 RID: 4306 RVA: 0x000C435C File Offset: 0x000C255C
		Private Function fReadImage(bytarr As Byte()) As Image
			Dim image As Image = Nothing
			Try
				Dim memoryStream As MemoryStream = New MemoryStream(bytarr)
				image = Image.FromStream(memoryStream)
			Catch ex As Exception
			End Try
			Return image
		End Function

		' Token: 0x060010D3 RID: 4307 RVA: 0x000CBB58 File Offset: 0x000C9D58
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMDV")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mblnAutoAdd_DMDV = xmlNode.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010D4 RID: 4308 RVA: 0x000CBC54 File Offset: 0x000C9E54
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("CARDCODE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(50))
				dgvData.Columns("CARDCODE").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("CARDCODE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("ADDRESS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("ADDRESS").Width = Me.Width - 440 - 250 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("ADDRESS").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TEL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("TEL").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("TEL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MOBILE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(28))
				dgvData.Columns("MOBILE").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("MOBILE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENNHOMDV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(49))
				dgvData.Columns("TENNHOMDV").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("TENNHOMDV").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MAKH").Visible = False
				dgvData.Columns("FIXED").Visible = False
				dgvData.Columns("BIRTHDAY").Visible = False
				dgvData.Columns("MANHOMDV").Visible = False
				dgvData.Columns("TENKH").Visible = False
				dgvData.Columns("ISSUP").Visible = False
				dgvData.Columns("ISCUS").Visible = False
				dgvData.Columns("ISFOR").Visible = False
				dgvData.Columns("ISORG").Visible = False
				dgvData.Columns("VATCODE").Visible = False
				dgvData.Columns("FAX").Visible = False
				dgvData.Columns("EMAIL").Visible = False
				dgvData.Columns("WEBSITE").Visible = False
				dgvData.Columns("CONTACT").Visible = False
				dgvData.Columns("TUOI").Visible = False
				dgvData.Columns("GIOITINH").Visible = False
				dgvData.Columns("JOB").Visible = False
				dgvData.Columns("REMARK").Visible = False
				dgvData.Columns("MAUSERUP").Visible = False
				dgvData.Columns("CAP").Visible = False
				dgvData.Columns("CHUCVU").Visible = False
				dgvData.Columns("UIMAGE").Visible = False
				dgvData.Columns("OBJNAME_REMOVE_VIET").Visible = False
				dgvData.Columns("ADDRESS_REMOVE_VIET").Visible = False
				dgvData.Columns("REMARK_REMOVE_VIET").Visible = False
				dgvData.Columns("FINGER1").Visible = False
				dgvData.Columns("FINGER2").Visible = False
				dgvData.Columns("FINGER3").Visible = False
				dgvData.Columns("NGAYNHANVIEC").Visible = False
				dgvData.Columns("NGAYTHOIVIEC").Visible = False
				Dim num As Integer = 0
				Try
					For Each obj As Object In Me.dgvData.Columns
						Dim dataGridViewColumn As DataGridViewColumn = CType(obj, DataGridViewColumn)
						Dim flag As Boolean = dataGridViewColumn.Visible
						If flag Then
							dataGridViewColumn.Width = Conversions.ToInteger(Interaction.IIf(Versioned.IsNumeric(Me.mArrSizeGrid(num)), Me.mArrSizeGrid(num), 100))
							num += 1
						End If
					Next
				Finally
					Dim enumerator As IEnumerator
					Dim flag As Boolean = TypeOf enumerator Is IDisposable
					If flag Then
						TryCast(enumerator, IDisposable).Dispose()
					End If
				End Try
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060010D5 RID: 4309 RVA: 0x000CC3BC File Offset: 0x000CA5BC
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060010D6 RID: 4310 RVA: 0x000CC53C File Offset: 0x000CA73C
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@tniTYPE"
				array(0).Value = Me.mIntType
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_GET_ALL_DATA_TYPE_RUTGON", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060010D7 RID: 4311 RVA: 0x000CC660 File Offset: 0x000CA860
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060010D8 RID: 4312 RVA: 0x000CC7B0 File Offset: 0x000CA9B0
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Me.mArrSizeGrid = mdlFile.gfReadFile_SizeGrid(mdlVariable.gStrPathApp + "\SIZEGRID\DMDVRG.ini")
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2070400000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060010D9 RID: 4313 RVA: 0x000CC8D8 File Offset: 0x000CAAD8
		Private Function fGetData_4Combo() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbNHDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNHOMDV")
				Dim flag As Boolean = Me.mclsTbNHDV IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060010DA RID: 4314 RVA: 0x000CC994 File Offset: 0x000CAB94
		Private Sub sClear_Form()
			Try
				Me.mclsTbNHDV.Dispose()
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060010DB RID: 4315 RVA: 0x000CCA4C File Offset: 0x000CAC4C
		Private Sub btnSendMail_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim text As String = ""
				Dim num As Integer = 0
				Dim num2 As Integer = Me.dgvData.Rows.Count - 1
				Dim num3 As Integer = num
				Dim flag As Boolean
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						Exit For
					End If
					flag = Me.dgvData.Rows(num3).Cells("Email").Value.ToString().Trim().Length > 3
					If flag Then
						text = text + "; " + Me.dgvData.Rows(num3).Cells("Email").Value.ToString().Trim()
					End If
					num3 += 1
				End While
				flag = text.Trim().StartsWith(";")
				If flag Then
					text = text.Substring(1)
					flag = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(44), Me.mArrStrFrmMess(43), frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.Yes
					If flag Then
						Clipboard.SetText(text)
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(45), Me.mArrStrFrmMess(43), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.ThongTin)
					Else
						mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
						Me.OpenEmail(text, "", "")
						mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
					End If
				Else
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(48), Me.mArrStrFrmMess(43), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.ThongTin)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSendMail_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060010DC RID: 4316 RVA: 0x000C5D30 File Offset: 0x000C3F30
		Public Function OpenEmail(EmailAddress As String, Optional Subject As String = "", Optional Body As String = "") As Boolean
			Dim flag As Boolean = True
			Dim text As String = EmailAddress
			Dim flag2 As Boolean = Operators.CompareString(Strings.LCase(Strings.Left(text, 7)), "mailto:", False) <> 0
			If flag2 Then
				text = "mailto:" + text
			End If
			flag2 = Operators.CompareString(Subject, "", False) <> 0
			If flag2 Then
				text = text + "?subject=" + Subject
			End If
			flag2 = Operators.CompareString(Body, "", False) <> 0
			If flag2 Then
				text = Conversions.ToString(Operators.ConcatenateObject(text, Interaction.IIf(Operators.CompareString(Subject, "", False) = 0, "?", "&")))
				text = text + "body=" + Body
			End If
			Try
				Process.Start(text)
			Catch ex As Exception
				flag = False
			End Try
			Return flag
		End Function

		' Token: 0x060010DD RID: 4317 RVA: 0x000C5208 File Offset: 0x000C3408
		Private Function fPrintDMDV(pstrMANHOMDV As String) As Byte
			Dim rptDMDV As rptDMDV = New rptDMDV()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMDV, "")
				Dim text As String = "2070400000"
				mdlReport.gsSetOfficeReport(rptDMDV, text)
				mdlReport.gsSetFontReport(rptDMDV)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMANHOMDV"
				array(0).Value = pstrMANHOMDV
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_GET_DMDV", num)
				Dim flag As Boolean = num = 1
				If flag Then
					rptDMDV.SetDataSource(clsConnect)
					rptDMDV.DataDefinition.FormulaFields("fUnitCode").Text = "{dtReport.OBJID}"
					rptDMDV.DataDefinition.FormulaFields("fUnitName").Text = "{dtReport.OBJNAME}"
					rptDMDV.DataDefinition.FormulaFields("fAddress").Text = "{dtReport.ADDRESS}"
					rptDMDV.DataDefinition.FormulaFields("fTel").Text = "{dtReport.TEL}"
					rptDMDV.DataDefinition.FormulaFields("fMobile").Text = "{dtReport.MOBILE}"
					rptDMDV.DataDefinition.FormulaFields("fStoreName").Text = "{dtReport.TENNHOMDV}"
					rptDMDV.DataDefinition.FormulaFields("fEmail").Text = "{dtReport.Email}"
					rptDMDV.DataDefinition.FormulaFields("fNgaysinh").Text = "{dtReport.Ngaysinh}"
					rptDMDV.DataDefinition.FormulaFields("fCap").Text = "{dtReport.CAP}"
					rptDMDV.DataDefinition.FormulaFields("fMST").Text = "{dtReport.VATCODE}"
					rptDMDV.DataDefinition.FormulaFields("fContact").Text = "{dtReport.CONTACT}"
					mdlReport.gsSetTextReport(rptDMDV, "RPTDMDV")
					MyProject.Forms.frmReport.pSource = rptDMDV
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMDV.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					Dim textObject2 As TextObject = CType(rptDMDV.ReportDefinition.ReportObjects("txtKHO"), TextObject)
					textObject2.Text = mdlVariable.gstrStockName
					rptDMDV.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMDV.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + "mdlRepDMDV - gfPrintDMDV " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMDV.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060010DE RID: 4318 RVA: 0x000CCC68 File Offset: 0x000CAE68
		Private Function fPrintDMDVDetail(pstrMADV As String) As Byte
			Dim rptDMDVDetail As rptDMDVDetail = New rptDMDVDetail()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMDVDetail, "")
				Dim text As String = "2070401000"
				mdlReport.gsSetOfficeReport(rptDMDVDetail, text)
				mdlReport.gsSetFontReport(rptDMDVDetail)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADV"
				array(0).Value = pstrMADV
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcNam"
				array(1).Value = Me.mArrStrFrmMess(58)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcNu"
				array(2).Value = Me.mArrStrFrmMess(59)
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_GET_DMDV_REPORT_DET", num)
				Dim flag As Boolean = num = 1
				If flag Then
					rptDMDVDetail.SetDataSource(clsConnect)
					rptDMDVDetail.DataDefinition.FormulaFields("fUnitCode").Text = "{dtReport.OBJID}"
					rptDMDVDetail.DataDefinition.FormulaFields("fUnitName").Text = "{dtReport.OBJNAME}"
					rptDMDVDetail.DataDefinition.FormulaFields("fAddress").Text = "{dtReport.ADDRESS}"
					rptDMDVDetail.DataDefinition.FormulaFields("fTel").Text = "{dtReport.TEL}"
					rptDMDVDetail.DataDefinition.FormulaFields("fMobile").Text = "{dtReport.MOBILE}"
					rptDMDVDetail.DataDefinition.FormulaFields("fStoreName").Text = "{dtReport.TENKH}"
					rptDMDVDetail.DataDefinition.FormulaFields("fBIRTHDAY").Text = "{dtReport.BIRTHDAY}"
					rptDMDVDetail.DataDefinition.FormulaFields("fVATCODE").Text = "{dtReport.VATCODE}"
					rptDMDVDetail.DataDefinition.FormulaFields("fFAX").Text = "{dtReport.FAX}"
					rptDMDVDetail.DataDefinition.FormulaFields("fEMAIL").Text = "{dtReport.EMAIL}"
					rptDMDVDetail.DataDefinition.FormulaFields("fWEBSITE").Text = "{dtReport.WEBSITE}"
					rptDMDVDetail.DataDefinition.FormulaFields("fCONTACT").Text = "{dtReport.CONTACT}"
					rptDMDVDetail.DataDefinition.FormulaFields("fTUOI").Text = "{dtReport.TUOI}"
					rptDMDVDetail.DataDefinition.FormulaFields("fJOB").Text = "{dtReport.JOB}"
					rptDMDVDetail.DataDefinition.FormulaFields("fGIOITINH").Text = "{dtReport.NAMNU}"
					rptDMDVDetail.DataDefinition.FormulaFields("fREMARK").Text = "{dtReport.REMARK}"
					rptDMDVDetail.DataDefinition.FormulaFields("fUSERUP").Text = "{dtReport.USERUP}"
					rptDMDVDetail.DataDefinition.FormulaFields("fNHOMDV").Text = "{dtReport.TENNHOMDV}"
					rptDMDVDetail.DataDefinition.FormulaFields("fCARDCODE").Text = "{dtReport.CARDCODE}"
					rptDMDVDetail.DataDefinition.FormulaFields("fCAP").Text = "{dtReport.CAP}"
					rptDMDVDetail.DataDefinition.FormulaFields("fCHUCVU").Text = "{dtReport.CHUCVU}"
					rptDMDVDetail.DataDefinition.FormulaFields("fMUCGIAMGIA").Text = "{dtReport.MUCGIAMGIA}"
					rptDMDVDetail.DataDefinition.FormulaFields("fNGAYNV").Text = "{dtReport.NGAYNHANVIEC}"
					rptDMDVDetail.DataDefinition.FormulaFields("fNGAYTV").Text = "{dtReport.NGAYTHOIVIEC}"
					Dim fieldObject As FieldObject = CType(rptDMDVDetail.ReportDefinition.ReportObjects("fMUCGIAMGIA"), FieldObject)
					fieldObject.FieldFormat.NumericFormat.DecimalPlaces = CShort(mdlVariable.gbytDECNUMAMT)
					mdlReport.gsSetTextReport(rptDMDVDetail, "RPTDMDV")
					MyProject.Forms.frmReport.pSource = rptDMDVDetail
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMDVDetail.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMDVDetail.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMDVDetail.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMDVDetail " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMDVDetail.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x040006F3 RID: 1779
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040006F5 RID: 1781
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x040006F6 RID: 1782
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x040006F7 RID: 1783
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x040006F8 RID: 1784
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x040006F9 RID: 1785
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x040006FA RID: 1786
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x040006FB RID: 1787
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x040006FC RID: 1788
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x040006FD RID: 1789
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x040006FE RID: 1790
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x040006FF RID: 1791
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000700 RID: 1792
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000701 RID: 1793
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000702 RID: 1794
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000703 RID: 1795
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000704 RID: 1796
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000705 RID: 1797
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000706 RID: 1798
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000707 RID: 1799
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000708 RID: 1800
		<AccessedThroughProperty("lblStore")>
		Private _lblStore As Label

		' Token: 0x04000709 RID: 1801
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x0400070A RID: 1802
		<AccessedThroughProperty("txtOBJNAMENHDV")>
		Private _txtOBJNAMENHDV As TextBox

		' Token: 0x0400070B RID: 1803
		<AccessedThroughProperty("btnSelectNHDV")>
		Private _btnSelectNHDV As Button

		' Token: 0x0400070C RID: 1804
		<AccessedThroughProperty("txtOBJIDNHDV")>
		Private _txtOBJIDNHDV As TextBox

		' Token: 0x0400070D RID: 1805
		<AccessedThroughProperty("btnSendMail")>
		Private _btnSendMail As Button

		' Token: 0x0400070E RID: 1806
		Private mArrSizeGrid As String()

		' Token: 0x0400070F RID: 1807
		Private mArrStrFrmMess As String()

		' Token: 0x04000710 RID: 1808
		Private mStrOBJID As String

		' Token: 0x04000711 RID: 1809
		Private mStrOBJNAME As String

		' Token: 0x04000712 RID: 1810
		Private mStrMANHOMDV As String

		' Token: 0x04000713 RID: 1811
		Private mStrCardCode As String

		' Token: 0x04000714 RID: 1812
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000715 RID: 1813
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000716 RID: 1814
		Private marrDrFind As DataRow()

		' Token: 0x04000717 RID: 1815
		Private mintFindLastPos As Integer

		' Token: 0x04000718 RID: 1816
		Private mclsTbNHDV As clsConnect

		' Token: 0x04000719 RID: 1817
		Private mIntType As Short

		' Token: 0x0400071A RID: 1818
		Private mblnAutoAdd_DMDV As Boolean

		' Token: 0x0400071B RID: 1819
		Private mblnIsOK As Boolean
	End Class
End Namespace
