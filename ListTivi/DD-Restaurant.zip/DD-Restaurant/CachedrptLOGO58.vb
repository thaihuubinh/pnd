﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200019E RID: 414
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptLOGO58
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005C76 RID: 23670 RVA: 0x000104AD File Offset: 0x0000E6AD
		Public Sub New()
			CachedrptLOGO58.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x1700220F RID: 8719
		' (get) Token: 0x06005C77 RID: 23671 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005C78 RID: 23672 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002210 RID: 8720
		' (get) Token: 0x06005C79 RID: 23673 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005C7A RID: 23674 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002211 RID: 8721
		' (get) Token: 0x06005C7B RID: 23675 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005C7C RID: 23676 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005C7D RID: 23677 RVA: 0x004DBF20 File Offset: 0x004DA120
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptLOGO58() With { .Site = Me.Site }
		End Function

		' Token: 0x06005C7E RID: 23678 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002796 RID: 10134
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
