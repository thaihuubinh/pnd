﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000150 RID: 336
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptDMDV
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005977 RID: 22903 RVA: 0x0000F82F File Offset: 0x0000DA2F
		Public Sub New()
			CachedrptDMDV.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002096 RID: 8342
		' (get) Token: 0x06005978 RID: 22904 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005979 RID: 22905 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002097 RID: 8343
		' (get) Token: 0x0600597A RID: 22906 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x0600597B RID: 22907 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002098 RID: 8344
		' (get) Token: 0x0600597C RID: 22908 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x0600597D RID: 22909 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x0600597E RID: 22910 RVA: 0x004DB560 File Offset: 0x004D9760
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptDMDV() With { .Site = Me.Site }
		End Function

		' Token: 0x0600597F RID: 22911 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002748 RID: 10056
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
