﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020001DE RID: 478
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60504k58Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005F47 RID: 24391 RVA: 0x00010EED File Offset: 0x0000F0ED
		Public Sub New()
			CachedrptRepBC60504k58Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170023A0 RID: 9120
		' (get) Token: 0x06005F48 RID: 24392 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005F49 RID: 24393 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170023A1 RID: 9121
		' (get) Token: 0x06005F4A RID: 24394 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005F4B RID: 24395 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170023A2 RID: 9122
		' (get) Token: 0x06005F4C RID: 24396 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005F4D RID: 24397 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005F4E RID: 24398 RVA: 0x004DC720 File Offset: 0x004DA920
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60504k58Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x06005F4F RID: 24399 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040027D6 RID: 10198
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
