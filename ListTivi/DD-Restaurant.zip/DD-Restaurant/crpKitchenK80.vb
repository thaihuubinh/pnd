﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x02000109 RID: 265
	Public Class crpKitchenK80
		Inherits ReportClass

		' Token: 0x06005641 RID: 22081 RVA: 0x0000ECD0 File Offset: 0x0000CED0
		Public Sub New()
			crpKitchenK80.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001EC1 RID: 7873
		' (get) Token: 0x06005642 RID: 22082 RVA: 0x004DAC88 File Offset: 0x004D8E88
		' (set) Token: 0x06005643 RID: 22083 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crpKitchenK80.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001EC2 RID: 7874
		' (get) Token: 0x06005644 RID: 22084 RVA: 0x004DA738 File Offset: 0x004D8938
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsLogo As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001EC3 RID: 7875
		' (get) Token: 0x06005645 RID: 22085 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsTitle As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001EC4 RID: 7876
		' (get) Token: 0x06005646 RID: 22086 RVA: 0x004DA780 File Offset: 0x004D8980
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsLien As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001EC5 RID: 7877
		' (get) Token: 0x06005647 RID: 22087 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsCall As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001EC6 RID: 7878
		' (get) Token: 0x06005648 RID: 22088 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsBill As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001EC7 RID: 7879
		' (get) Token: 0x06005649 RID: 22089 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsKhu As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x17001EC8 RID: 7880
		' (get) Token: 0x0600564A RID: 22090 RVA: 0x004DA810 File Offset: 0x004D8A10
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsTable As Section
			Get
				Return Me.ReportDefinition.Sections(6)
			End Get
		End Property

		' Token: 0x17001EC9 RID: 7881
		' (get) Token: 0x0600564B RID: 22091 RVA: 0x004DA834 File Offset: 0x004D8A34
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsDonVi As Section
			Get
				Return Me.ReportDefinition.Sections(7)
			End Get
		End Property

		' Token: 0x17001ECA RID: 7882
		' (get) Token: 0x0600564C RID: 22092 RVA: 0x004DA858 File Offset: 0x004D8A58
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsCashier As Section
			Get
				Return Me.ReportDefinition.Sections(8)
			End Get
		End Property

		' Token: 0x17001ECB RID: 7883
		' (get) Token: 0x0600564D RID: 22093 RVA: 0x004DA87C File Offset: 0x004D8A7C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsService As Section
			Get
				Return Me.ReportDefinition.Sections(9)
			End Get
		End Property

		' Token: 0x17001ECC RID: 7884
		' (get) Token: 0x0600564E RID: 22094 RVA: 0x004DA8A0 File Offset: 0x004D8AA0
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsCus As Section
			Get
				Return Me.ReportDefinition.Sections(10)
			End Get
		End Property

		' Token: 0x17001ECD RID: 7885
		' (get) Token: 0x0600564F RID: 22095 RVA: 0x004DA8C4 File Offset: 0x004D8AC4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsIDPrint As Section
			Get
				Return Me.ReportDefinition.Sections(11)
			End Get
		End Property

		' Token: 0x17001ECE RID: 7886
		' (get) Token: 0x06005650 RID: 22096 RVA: 0x004DA8E8 File Offset: 0x004D8AE8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property phsTieude1 As Section
			Get
				Return Me.ReportDefinition.Sections(12)
			End Get
		End Property

		' Token: 0x17001ECF RID: 7887
		' (get) Token: 0x06005651 RID: 22097 RVA: 0x004DA90C File Offset: 0x004D8B0C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property phsTieude2 As Section
			Get
				Return Me.ReportDefinition.Sections(13)
			End Get
		End Property

		' Token: 0x17001ED0 RID: 7888
		' (get) Token: 0x06005652 RID: 22098 RVA: 0x004DA930 File Offset: 0x004D8B30
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property phsTieude3 As Section
			Get
				Return Me.ReportDefinition.Sections(14)
			End Get
		End Property

		' Token: 0x17001ED1 RID: 7889
		' (get) Token: 0x06005653 RID: 22099 RVA: 0x004DA954 File Offset: 0x004D8B54
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property phsTieude4 As Section
			Get
				Return Me.ReportDefinition.Sections(15)
			End Get
		End Property

		' Token: 0x17001ED2 RID: 7890
		' (get) Token: 0x06005654 RID: 22100 RVA: 0x004DA978 File Offset: 0x004D8B78
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property GroupHeaderSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(16)
			End Get
		End Property

		' Token: 0x17001ED3 RID: 7891
		' (get) Token: 0x06005655 RID: 22101 RVA: 0x004DA99C File Offset: 0x004D8B9C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property secCach1Dong As Section
			Get
				Return Me.ReportDefinition.Sections(17)
			End Get
		End Property

		' Token: 0x17001ED4 RID: 7892
		' (get) Token: 0x06005656 RID: 22102 RVA: 0x004DA9C0 File Offset: 0x004D8BC0
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section3 As Section
			Get
				Return Me.ReportDefinition.Sections(18)
			End Get
		End Property

		' Token: 0x17001ED5 RID: 7893
		' (get) Token: 0x06005657 RID: 22103 RVA: 0x004DA9E4 File Offset: 0x004D8BE4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dsTen As Section
			Get
				Return Me.ReportDefinition.Sections(19)
			End Get
		End Property

		' Token: 0x17001ED6 RID: 7894
		' (get) Token: 0x06005658 RID: 22104 RVA: 0x004DAA08 File Offset: 0x004D8C08
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsSL As Section
			Get
				Return Me.ReportDefinition.Sections(20)
			End Get
		End Property

		' Token: 0x17001ED7 RID: 7895
		' (get) Token: 0x06005659 RID: 22105 RVA: 0x004DAA2C File Offset: 0x004D8C2C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsDVTTEN As Section
			Get
				Return Me.ReportDefinition.Sections(21)
			End Get
		End Property

		' Token: 0x17001ED8 RID: 7896
		' (get) Token: 0x0600565A RID: 22106 RVA: 0x004DAA50 File Offset: 0x004D8C50
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dsDVTSL As Section
			Get
				Return Me.ReportDefinition.Sections(22)
			End Get
		End Property

		' Token: 0x17001ED9 RID: 7897
		' (get) Token: 0x0600565B RID: 22107 RVA: 0x004DAA74 File Offset: 0x004D8C74
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dsPrice As Section
			Get
				Return Me.ReportDefinition.Sections(23)
			End Get
		End Property

		' Token: 0x17001EDA RID: 7898
		' (get) Token: 0x0600565C RID: 22108 RVA: 0x004DAA98 File Offset: 0x004D8C98
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(24)
			End Get
		End Property

		' Token: 0x17001EDB RID: 7899
		' (get) Token: 0x0600565D RID: 22109 RVA: 0x004DAABC File Offset: 0x004D8CBC
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(25)
			End Get
		End Property

		' Token: 0x17001EDC RID: 7900
		' (get) Token: 0x0600565E RID: 22110 RVA: 0x004DAAE0 File Offset: 0x004D8CE0
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection3 As Section
			Get
				Return Me.ReportDefinition.Sections(26)
			End Get
		End Property

		' Token: 0x17001EDD RID: 7901
		' (get) Token: 0x0600565F RID: 22111 RVA: 0x004DAB04 File Offset: 0x004D8D04
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property secCach1DongBo As Section
			Get
				Return Me.ReportDefinition.Sections(27)
			End Get
		End Property

		' Token: 0x17001EDE RID: 7902
		' (get) Token: 0x06005660 RID: 22112 RVA: 0x004DAB28 File Offset: 0x004D8D28
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(28)
			End Get
		End Property

		' Token: 0x17001EDF RID: 7903
		' (get) Token: 0x06005661 RID: 22113 RVA: 0x004DAB4C File Offset: 0x004D8D4C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property sTongSL As Section
			Get
				Return Me.ReportDefinition.Sections(29)
			End Get
		End Property

		' Token: 0x17001EE0 RID: 7904
		' (get) Token: 0x06005662 RID: 22114 RVA: 0x004DAB70 File Offset: 0x004D8D70
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property sNgay2 As Section
			Get
				Return Me.ReportDefinition.Sections(30)
			End Get
		End Property

		' Token: 0x17001EE1 RID: 7905
		' (get) Token: 0x06005663 RID: 22115 RVA: 0x004DAB94 File Offset: 0x004D8D94
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property sNgay As Section
			Get
				Return Me.ReportDefinition.Sections(31)
			End Get
		End Property

		' Token: 0x17001EE2 RID: 7906
		' (get) Token: 0x06005664 RID: 22116 RVA: 0x004DABB8 File Offset: 0x004D8DB8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(32)
			End Get
		End Property

		' Token: 0x04002701 RID: 9985
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
