﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000067 RID: 103
	<DesignerGenerated()>
	Public Partial Class frmDMMT1
		Inherits Form

		' Token: 0x06002099 RID: 8345 RVA: 0x00194274 File Offset: 0x00192474
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMMT1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMMT1_Load
			frmDMMT1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000B30 RID: 2864
		' (get) Token: 0x0600209C RID: 8348 RVA: 0x00195504 File Offset: 0x00193704
		' (set) Token: 0x0600209D RID: 8349 RVA: 0x00006A2D File Offset: 0x00004C2D
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000B31 RID: 2865
		' (get) Token: 0x0600209E RID: 8350 RVA: 0x0019551C File Offset: 0x0019371C
		' (set) Token: 0x0600209F RID: 8351 RVA: 0x00195534 File Offset: 0x00193734
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x17000B32 RID: 2866
		' (get) Token: 0x060020A0 RID: 8352 RVA: 0x001955A0 File Offset: 0x001937A0
		' (set) Token: 0x060020A1 RID: 8353 RVA: 0x001955B8 File Offset: 0x001937B8
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000B33 RID: 2867
		' (get) Token: 0x060020A2 RID: 8354 RVA: 0x00195624 File Offset: 0x00193824
		' (set) Token: 0x060020A3 RID: 8355 RVA: 0x0019563C File Offset: 0x0019383C
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000B34 RID: 2868
		' (get) Token: 0x060020A4 RID: 8356 RVA: 0x001956A8 File Offset: 0x001938A8
		' (set) Token: 0x060020A5 RID: 8357 RVA: 0x001956C0 File Offset: 0x001938C0
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000B35 RID: 2869
		' (get) Token: 0x060020A6 RID: 8358 RVA: 0x0019572C File Offset: 0x0019392C
		' (set) Token: 0x060020A7 RID: 8359 RVA: 0x00195744 File Offset: 0x00193944
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000B36 RID: 2870
		' (get) Token: 0x060020A8 RID: 8360 RVA: 0x001957B0 File Offset: 0x001939B0
		' (set) Token: 0x060020A9 RID: 8361 RVA: 0x001957C8 File Offset: 0x001939C8
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000B37 RID: 2871
		' (get) Token: 0x060020AA RID: 8362 RVA: 0x00195834 File Offset: 0x00193A34
		' (set) Token: 0x060020AB RID: 8363 RVA: 0x0019584C File Offset: 0x00193A4C
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000B38 RID: 2872
		' (get) Token: 0x060020AC RID: 8364 RVA: 0x001958B8 File Offset: 0x00193AB8
		' (set) Token: 0x060020AD RID: 8365 RVA: 0x00006A37 File Offset: 0x00004C37
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000B39 RID: 2873
		' (get) Token: 0x060020AE RID: 8366 RVA: 0x001958D0 File Offset: 0x00193AD0
		' (set) Token: 0x060020AF RID: 8367 RVA: 0x001958E8 File Offset: 0x00193AE8
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000B3A RID: 2874
		' (get) Token: 0x060020B0 RID: 8368 RVA: 0x00195954 File Offset: 0x00193B54
		' (set) Token: 0x060020B1 RID: 8369 RVA: 0x0019596C File Offset: 0x00193B6C
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x17000B3B RID: 2875
		' (get) Token: 0x060020B2 RID: 8370 RVA: 0x001959D8 File Offset: 0x00193BD8
		' (set) Token: 0x060020B3 RID: 8371 RVA: 0x001959F0 File Offset: 0x00193BF0
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000B3C RID: 2876
		' (get) Token: 0x060020B4 RID: 8372 RVA: 0x00195A5C File Offset: 0x00193C5C
		' (set) Token: 0x060020B5 RID: 8373 RVA: 0x00006A41 File Offset: 0x00004C41
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x17000B3D RID: 2877
		' (get) Token: 0x060020B6 RID: 8374 RVA: 0x00195A74 File Offset: 0x00193C74
		' (set) Token: 0x060020B7 RID: 8375 RVA: 0x00195A8C File Offset: 0x00193C8C
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x17000B3E RID: 2878
		' (get) Token: 0x060020B8 RID: 8376 RVA: 0x00195AF8 File Offset: 0x00193CF8
		' (set) Token: 0x060020B9 RID: 8377 RVA: 0x00195B10 File Offset: 0x00193D10
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x17000B3F RID: 2879
		' (get) Token: 0x060020BA RID: 8378 RVA: 0x00195B7C File Offset: 0x00193D7C
		' (set) Token: 0x060020BB RID: 8379 RVA: 0x00195B94 File Offset: 0x00193D94
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000B40 RID: 2880
		' (get) Token: 0x060020BC RID: 8380 RVA: 0x00195C00 File Offset: 0x00193E00
		' (set) Token: 0x060020BD RID: 8381 RVA: 0x00195C18 File Offset: 0x00193E18
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000B41 RID: 2881
		' (get) Token: 0x060020BE RID: 8382 RVA: 0x00195C84 File Offset: 0x00193E84
		' (set) Token: 0x060020BF RID: 8383 RVA: 0x00195C9C File Offset: 0x00193E9C
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000B42 RID: 2882
		' (get) Token: 0x060020C0 RID: 8384 RVA: 0x00195D08 File Offset: 0x00193F08
		' (set) Token: 0x060020C1 RID: 8385 RVA: 0x00195D20 File Offset: 0x00193F20
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x17000B43 RID: 2883
		' (get) Token: 0x060020C2 RID: 8386 RVA: 0x00195D8C File Offset: 0x00193F8C
		' (set) Token: 0x060020C3 RID: 8387 RVA: 0x00006A4B File Offset: 0x00004C4B
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000B44 RID: 2884
		' (get) Token: 0x060020C4 RID: 8388 RVA: 0x00195DA4 File Offset: 0x00193FA4
		' (set) Token: 0x060020C5 RID: 8389 RVA: 0x00195DBC File Offset: 0x00193FBC
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000B45 RID: 2885
		' (get) Token: 0x060020C6 RID: 8390 RVA: 0x00195E28 File Offset: 0x00194028
		' (set) Token: 0x060020C7 RID: 8391 RVA: 0x00006A55 File Offset: 0x00004C55
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x17000B46 RID: 2886
		' (get) Token: 0x060020C8 RID: 8392 RVA: 0x00195E40 File Offset: 0x00194040
		' (set) Token: 0x060020C9 RID: 8393 RVA: 0x00006A60 File Offset: 0x00004C60
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000B47 RID: 2887
		' (get) Token: 0x060020CA RID: 8394 RVA: 0x00195E58 File Offset: 0x00194058
		' (set) Token: 0x060020CB RID: 8395 RVA: 0x00006A6B File Offset: 0x00004C6B
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060020CC RID: 8396 RVA: 0x00195E70 File Offset: 0x00194070
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
				Me.mStrOBJNAME = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJNAME").Value)
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020CD RID: 8397 RVA: 0x00195F5C File Offset: 0x0019415C
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020CE RID: 8398 RVA: 0x0019602C File Offset: 0x0019422C
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020CF RID: 8399 RVA: 0x0019611C File Offset: 0x0019431C
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020D0 RID: 8400 RVA: 0x00196200 File Offset: 0x00194400
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020D1 RID: 8401 RVA: 0x001962C4 File Offset: 0x001944C4
		Private Sub frmDMMT1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMT1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020D2 RID: 8402 RVA: 0x0019635C File Offset: 0x0019455C
		Private Sub frmDMMT1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMT1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020D3 RID: 8403 RVA: 0x00196464 File Offset: 0x00194664
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020D4 RID: 8404 RVA: 0x0019656C File Offset: 0x0019476C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020D5 RID: 8405 RVA: 0x00196604 File Offset: 0x00194804
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMMT As frmDMMT2 = New frmDMMT2()
			Try
				frmDMMT.pbytFromStatus = 1
				frmDMMT.ShowDialog()
				Dim flag As Boolean = frmDMMT.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMMT.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMT.Dispose()
			End Try
		End Sub

		' Token: 0x060020D6 RID: 8406 RVA: 0x00196764 File Offset: 0x00194964
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMMT As frmDMMT2 = New frmDMMT2()
			Try
				Dim frmDMMT2 As frmDMMT2 = frmDMMT
				frmDMMT2.pbytFromStatus = 2
				frmDMMT2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMMT2.txtRate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("RATE").Value, ""))
				frmDMMT2.cmbInclude.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CHUATHUE").Value, ""))
				frmDMMT.ShowDialog()
				Dim flag As Boolean = frmDMMT.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMMT.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMT.Dispose()
			End Try
		End Sub

		' Token: 0x060020D7 RID: 8407 RVA: 0x00196980 File Offset: 0x00194B80
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMMT As frmDMMT2 = New frmDMMT2()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					frmDMMT.Dispose()
				Else
					Dim frmDMMT2 As frmDMMT2 = frmDMMT
					frmDMMT2.pbytFromStatus = 3
					frmDMMT2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMMT2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMMT2.txtRate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("RATE").Value, ""))
					frmDMMT2.cmbInclude.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CHUATHUE").Value, ""))
					frmDMMT.ShowDialog()
					flag = frmDMMT.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMMT.pStrFilter)
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMT.Dispose()
			End Try
		End Sub

		' Token: 0x060020D8 RID: 8408 RVA: 0x00196C10 File Offset: 0x00194E10
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMMT As frmDMMT2 = New frmDMMT2()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
					frmDMMT.Dispose()
				Else
					Dim frmDMMT2 As frmDMMT2 = frmDMMT
					frmDMMT2.pbytFromStatus = 4
					frmDMMT2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMMT2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMMT2.txtRate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("RATE").Value, ""))
					frmDMMT2.cmbInclude.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CHUATHUE").Value, ""))
					frmDMMT.ShowDialog()
					flag = frmDMMT.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMT.Dispose()
			End Try
		End Sub

		' Token: 0x060020D9 RID: 8409 RVA: 0x00196E80 File Offset: 0x00195080
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMMT As frmDMMT2 = New frmDMMT2()
			Try
				frmDMMT.pbytFromStatus = 6
				frmDMMT.ShowDialog()
				Dim flag As Boolean = frmDMMT.pbytSuccess = 0
				If flag Then
					frmDMMT.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMMT.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMMT.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMT.Dispose()
			End Try
		End Sub

		' Token: 0x060020DA RID: 8410 RVA: 0x00197074 File Offset: 0x00195274
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMMT As frmDMMT2 = New frmDMMT2()
			Try
				Me.btnFindNext.Visible = False
				frmDMMT.pbytFromStatus = 5
				frmDMMT.ShowDialog()
				Dim flag As Boolean = frmDMMT.pbytSuccess = 0
				If Not flag Then
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMMT.pStrFilter
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMT.Dispose()
			End Try
		End Sub

		' Token: 0x060020DB RID: 8411 RVA: 0x0019717C File Offset: 0x0019537C
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMMT As frmDMMT2 = New frmDMMT2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMT.Dispose()
			End Try
		End Sub

		' Token: 0x060020DC RID: 8412 RVA: 0x00197244 File Offset: 0x00195444
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x060020DD RID: 8413 RVA: 0x001973C0 File Offset: 0x001955C0
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fPrintDMMT()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020DE RID: 8414 RVA: 0x00197458 File Offset: 0x00195658
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020DF RID: 8415 RVA: 0x00197508 File Offset: 0x00195708
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 50
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = Me.Width - 340 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("RATE").HeaderText = Me.mArrStrFrmMess(20)
				dgvData.Columns("RATE").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("RATE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("CHUATHUE").HeaderText = Me.mArrStrFrmMess(21)
				dgvData.Columns("CHUATHUE").Width = 180
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("CHUATHUE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("FIXED").Visible = False
				dgvData.Columns("STS01").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060020E0 RID: 8416 RVA: 0x001977E8 File Offset: 0x001959E8
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060020E1 RID: 8417 RVA: 0x00197968 File Offset: 0x00195B68
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMT_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Dim num2 As Integer = 0
					Dim num3 As Integer = clsConnect.Rows.Count - 1
					Dim num4 As Integer = num2
					While True
						Dim num5 As Integer = num4
						Dim num6 As Integer = num3
						If num5 > num6 Then
							Exit For
						End If
						Dim flag2 As Boolean = Conversions.ToDouble(Strings.Trim(Conversions.ToString(clsConnect.Rows(num4)("CHUATHUE")))) = 1.0
						If flag2 Then
							clsConnect.Rows(num4)("CHUATHUE") = Me.mArrStrFrmMess(16)
						Else
							clsConnect.Rows(num4)("CHUATHUE") = Me.mArrStrFrmMess(17)
						End If
						num4 += 1
					End While
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060020E2 RID: 8418 RVA: 0x00197B14 File Offset: 0x00195D14
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.Dock = DockStyle.Fill
					Me.btnSelect.Visible = False
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.mBytOpen_FromMenu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060020E3 RID: 8419 RVA: 0x00197C64 File Offset: 0x00195E64
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060020E4 RID: 8420 RVA: 0x00197D70 File Offset: 0x00195F70
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060020E5 RID: 8421 RVA: 0x00197E1C File Offset: 0x0019601C
		Private Function fPrintDMMT() As Byte
			Dim rptDMMT As rptDMMT = New rptDMMT()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMMT, "")
				Dim text As String = "2010000000"
				mdlReport.gsSetOfficeReport(rptDMMT, text)
				mdlReport.gsSetFontReport(rptDMMT)
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "SP_FRMDMMT_GET_ALL_DATA", flag)
				Dim flag2 As Boolean = flag
				If flag2 Then
					Dim num As Integer = 0
					Dim num2 As Integer = clsConnect.Rows.Count - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						Dim flag3 As Boolean = Operators.ConditionalCompareObjectEqual(clsConnect.Rows(num3)("STS01"), True, False)
						If flag3 Then
							clsConnect.Rows(num3)("CHUATHUE") = Me.mArrStrFrmMess(25)
						Else
							clsConnect.Rows(num3)("CHUATHUE") = Me.mArrStrFrmMess(26)
						End If
						num3 += 1
					End While
					rptDMMT.SetDataSource(clsConnect)
					rptDMMT.DataDefinition.FormulaFields("fTaxCode").Text = "{dtReport.OBJID}"
					rptDMMT.DataDefinition.FormulaFields("fTaxName").Text = "{dtReport.OBJNAME}"
					rptDMMT.DataDefinition.FormulaFields("fTaxRate").Text = "{dtReport.RATE}"
					rptDMMT.DataDefinition.FormulaFields("fTax").Text = "{dtReport.CHUATHUE}"
					mdlReport.gsSetTextReport(rptDMMT, "RPTDMMT")
					MyProject.Forms.frmReport.pSource = rptDMMT
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim fieldObject As FieldObject = CType(rptDMMT.ReportDefinition.ReportObjects("fTaxRate"), FieldObject)
					fieldObject.FieldFormat.NumericFormat.DecimalPlaces = CShort(mdlVariable.gbytDECNUMPER)
					Dim textObject As TextObject = CType(rptDMMT.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMMT.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMMT.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMMT " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMMT.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x04000D58 RID: 3416
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000D5A RID: 3418
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000D5B RID: 3419
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000D5C RID: 3420
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000D5D RID: 3421
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000D5E RID: 3422
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000D5F RID: 3423
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000D60 RID: 3424
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000D61 RID: 3425
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000D62 RID: 3426
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000D63 RID: 3427
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000D64 RID: 3428
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000D65 RID: 3429
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000D66 RID: 3430
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000D67 RID: 3431
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000D68 RID: 3432
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000D69 RID: 3433
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000D6A RID: 3434
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000D6B RID: 3435
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000D6C RID: 3436
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000D6D RID: 3437
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000D6E RID: 3438
		Private mArrStrFrmMess As String()

		' Token: 0x04000D6F RID: 3439
		Private mStrOBJID As String

		' Token: 0x04000D70 RID: 3440
		Private mStrOBJNAME As String

		' Token: 0x04000D71 RID: 3441
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000D72 RID: 3442
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000D73 RID: 3443
		Private marrDrFind As DataRow()

		' Token: 0x04000D74 RID: 3444
		Private mintFindLastPos As Integer
	End Class
End Namespace
