﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x02000105 RID: 261
	Public Class crpKitchenK58
		Inherits ReportClass

		' Token: 0x060055F1 RID: 22001 RVA: 0x0000EC2C File Offset: 0x0000CE2C
		Public Sub New()
			crpKitchenK58.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001E85 RID: 7813
		' (get) Token: 0x060055F2 RID: 22002 RVA: 0x004DA720 File Offset: 0x004D8920
		' (set) Token: 0x060055F3 RID: 22003 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crpKitchenK58.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001E86 RID: 7814
		' (get) Token: 0x060055F4 RID: 22004 RVA: 0x004DA738 File Offset: 0x004D8938
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsLogo As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001E87 RID: 7815
		' (get) Token: 0x060055F5 RID: 22005 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsTitle As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001E88 RID: 7816
		' (get) Token: 0x060055F6 RID: 22006 RVA: 0x004DA780 File Offset: 0x004D8980
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsLien As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001E89 RID: 7817
		' (get) Token: 0x060055F7 RID: 22007 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsCall As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001E8A RID: 7818
		' (get) Token: 0x060055F8 RID: 22008 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsBill As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001E8B RID: 7819
		' (get) Token: 0x060055F9 RID: 22009 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsKhu As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x17001E8C RID: 7820
		' (get) Token: 0x060055FA RID: 22010 RVA: 0x004DA810 File Offset: 0x004D8A10
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsTable As Section
			Get
				Return Me.ReportDefinition.Sections(6)
			End Get
		End Property

		' Token: 0x17001E8D RID: 7821
		' (get) Token: 0x060055FB RID: 22011 RVA: 0x004DA834 File Offset: 0x004D8A34
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsDonVi As Section
			Get
				Return Me.ReportDefinition.Sections(7)
			End Get
		End Property

		' Token: 0x17001E8E RID: 7822
		' (get) Token: 0x060055FC RID: 22012 RVA: 0x004DA858 File Offset: 0x004D8A58
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsCashier As Section
			Get
				Return Me.ReportDefinition.Sections(8)
			End Get
		End Property

		' Token: 0x17001E8F RID: 7823
		' (get) Token: 0x060055FD RID: 22013 RVA: 0x004DA87C File Offset: 0x004D8A7C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsService As Section
			Get
				Return Me.ReportDefinition.Sections(9)
			End Get
		End Property

		' Token: 0x17001E90 RID: 7824
		' (get) Token: 0x060055FE RID: 22014 RVA: 0x004DA8A0 File Offset: 0x004D8AA0
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsCus As Section
			Get
				Return Me.ReportDefinition.Sections(10)
			End Get
		End Property

		' Token: 0x17001E91 RID: 7825
		' (get) Token: 0x060055FF RID: 22015 RVA: 0x004DA8C4 File Offset: 0x004D8AC4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsIDPrint As Section
			Get
				Return Me.ReportDefinition.Sections(11)
			End Get
		End Property

		' Token: 0x17001E92 RID: 7826
		' (get) Token: 0x06005600 RID: 22016 RVA: 0x004DA8E8 File Offset: 0x004D8AE8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property phsTieude1 As Section
			Get
				Return Me.ReportDefinition.Sections(12)
			End Get
		End Property

		' Token: 0x17001E93 RID: 7827
		' (get) Token: 0x06005601 RID: 22017 RVA: 0x004DA90C File Offset: 0x004D8B0C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property phsTieude3 As Section
			Get
				Return Me.ReportDefinition.Sections(13)
			End Get
		End Property

		' Token: 0x17001E94 RID: 7828
		' (get) Token: 0x06005602 RID: 22018 RVA: 0x004DA930 File Offset: 0x004D8B30
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property phsTieude4 As Section
			Get
				Return Me.ReportDefinition.Sections(14)
			End Get
		End Property

		' Token: 0x17001E95 RID: 7829
		' (get) Token: 0x06005603 RID: 22019 RVA: 0x004DA954 File Offset: 0x004D8B54
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property phsTieude2 As Section
			Get
				Return Me.ReportDefinition.Sections(15)
			End Get
		End Property

		' Token: 0x17001E96 RID: 7830
		' (get) Token: 0x06005604 RID: 22020 RVA: 0x004DA978 File Offset: 0x004D8B78
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property GroupHeaderSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(16)
			End Get
		End Property

		' Token: 0x17001E97 RID: 7831
		' (get) Token: 0x06005605 RID: 22021 RVA: 0x004DA99C File Offset: 0x004D8B9C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property secCach1Dong As Section
			Get
				Return Me.ReportDefinition.Sections(17)
			End Get
		End Property

		' Token: 0x17001E98 RID: 7832
		' (get) Token: 0x06005606 RID: 22022 RVA: 0x004DA9C0 File Offset: 0x004D8BC0
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section3 As Section
			Get
				Return Me.ReportDefinition.Sections(18)
			End Get
		End Property

		' Token: 0x17001E99 RID: 7833
		' (get) Token: 0x06005607 RID: 22023 RVA: 0x004DA9E4 File Offset: 0x004D8BE4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsTen As Section
			Get
				Return Me.ReportDefinition.Sections(19)
			End Get
		End Property

		' Token: 0x17001E9A RID: 7834
		' (get) Token: 0x06005608 RID: 22024 RVA: 0x004DAA08 File Offset: 0x004D8C08
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsSL As Section
			Get
				Return Me.ReportDefinition.Sections(20)
			End Get
		End Property

		' Token: 0x17001E9B RID: 7835
		' (get) Token: 0x06005609 RID: 22025 RVA: 0x004DAA2C File Offset: 0x004D8C2C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsDVTTEN As Section
			Get
				Return Me.ReportDefinition.Sections(21)
			End Get
		End Property

		' Token: 0x17001E9C RID: 7836
		' (get) Token: 0x0600560A RID: 22026 RVA: 0x004DAA50 File Offset: 0x004D8C50
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dsDVTSL As Section
			Get
				Return Me.ReportDefinition.Sections(22)
			End Get
		End Property

		' Token: 0x17001E9D RID: 7837
		' (get) Token: 0x0600560B RID: 22027 RVA: 0x004DAA74 File Offset: 0x004D8C74
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsPrice As Section
			Get
				Return Me.ReportDefinition.Sections(23)
			End Get
		End Property

		' Token: 0x17001E9E RID: 7838
		' (get) Token: 0x0600560C RID: 22028 RVA: 0x004DAA98 File Offset: 0x004D8C98
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(24)
			End Get
		End Property

		' Token: 0x17001E9F RID: 7839
		' (get) Token: 0x0600560D RID: 22029 RVA: 0x004DAABC File Offset: 0x004D8CBC
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(25)
			End Get
		End Property

		' Token: 0x17001EA0 RID: 7840
		' (get) Token: 0x0600560E RID: 22030 RVA: 0x004DAAE0 File Offset: 0x004D8CE0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection3 As Section
			Get
				Return Me.ReportDefinition.Sections(26)
			End Get
		End Property

		' Token: 0x17001EA1 RID: 7841
		' (get) Token: 0x0600560F RID: 22031 RVA: 0x004DAB04 File Offset: 0x004D8D04
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property secCach1DongBo As Section
			Get
				Return Me.ReportDefinition.Sections(27)
			End Get
		End Property

		' Token: 0x17001EA2 RID: 7842
		' (get) Token: 0x06005610 RID: 22032 RVA: 0x004DAB28 File Offset: 0x004D8D28
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(28)
			End Get
		End Property

		' Token: 0x17001EA3 RID: 7843
		' (get) Token: 0x06005611 RID: 22033 RVA: 0x004DAB4C File Offset: 0x004D8D4C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property sTongSL As Section
			Get
				Return Me.ReportDefinition.Sections(29)
			End Get
		End Property

		' Token: 0x17001EA4 RID: 7844
		' (get) Token: 0x06005612 RID: 22034 RVA: 0x004DAB70 File Offset: 0x004D8D70
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property sNgay2 As Section
			Get
				Return Me.ReportDefinition.Sections(30)
			End Get
		End Property

		' Token: 0x17001EA5 RID: 7845
		' (get) Token: 0x06005613 RID: 22035 RVA: 0x004DAB94 File Offset: 0x004D8D94
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property sNgay As Section
			Get
				Return Me.ReportDefinition.Sections(31)
			End Get
		End Property

		' Token: 0x17001EA6 RID: 7846
		' (get) Token: 0x06005614 RID: 22036 RVA: 0x004DABB8 File Offset: 0x004D8DB8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(32)
			End Get
		End Property

		' Token: 0x040026FD RID: 9981
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
