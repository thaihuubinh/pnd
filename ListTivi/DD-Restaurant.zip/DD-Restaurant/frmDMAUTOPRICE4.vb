﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices

Namespace prjIS_SalesPOS
	' Token: 0x02000037 RID: 55
	<DesignerGenerated()>
	Public Partial Class frmDMAUTOPRICE4
		Inherits Form

		' Token: 0x06000C51 RID: 3153 RVA: 0x00090E10 File Offset: 0x0008F010
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMAUTOPRICE4_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMAUTOPRICE4_Load
			frmDMAUTOPRICE4.__ENCList.Add(New WeakReference(Me))
			Me.marrDblPrice = New Double(9) {}
			Me.mstrMADVT_HH = ""
			Me.mbytLevelPrice = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700047B RID: 1147
		' (get) Token: 0x06000C54 RID: 3156 RVA: 0x000919AC File Offset: 0x0008FBAC
		' (set) Token: 0x06000C55 RID: 3157 RVA: 0x00004159 File Offset: 0x00002359
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x1700047C RID: 1148
		' (get) Token: 0x06000C56 RID: 3158 RVA: 0x000919C4 File Offset: 0x0008FBC4
		' (set) Token: 0x06000C57 RID: 3159 RVA: 0x000919DC File Offset: 0x0008FBDC
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x1700047D RID: 1149
		' (get) Token: 0x06000C58 RID: 3160 RVA: 0x00091A48 File Offset: 0x0008FC48
		' (set) Token: 0x06000C59 RID: 3161 RVA: 0x00091A60 File Offset: 0x0008FC60
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x1700047E RID: 1150
		' (get) Token: 0x06000C5A RID: 3162 RVA: 0x00091ACC File Offset: 0x0008FCCC
		' (set) Token: 0x06000C5B RID: 3163 RVA: 0x00004163 File Offset: 0x00002363
		Friend Overridable Property lblMAHH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAHH = value
			End Set
		End Property

		' Token: 0x1700047F RID: 1151
		' (get) Token: 0x06000C5C RID: 3164 RVA: 0x00091AE4 File Offset: 0x0008FCE4
		' (set) Token: 0x06000C5D RID: 3165 RVA: 0x00091AFC File Offset: 0x0008FCFC
		Friend Overridable Property txtTENHH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENHH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENHH.GotFocus, AddressOf Me.txtTENHH_GotFocus
				End If
				Me._txtTENHH = value
				flag = Me._txtTENHH IsNot Nothing
				If flag Then
					AddHandler Me._txtTENHH.GotFocus, AddressOf Me.txtTENHH_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000480 RID: 1152
		' (get) Token: 0x06000C5E RID: 3166 RVA: 0x00091B68 File Offset: 0x0008FD68
		' (set) Token: 0x06000C5F RID: 3167 RVA: 0x00091B80 File Offset: 0x0008FD80
		Friend Overridable Property btnSelDMHH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelDMHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelDMHH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelDMHH.Click, AddressOf Me.btnSelDMHH_Click
				End If
				Me._btnSelDMHH = value
				flag = Me._btnSelDMHH IsNot Nothing
				If flag Then
					AddHandler Me._btnSelDMHH.Click, AddressOf Me.btnSelDMHH_Click
				End If
			End Set
		End Property

		' Token: 0x17000481 RID: 1153
		' (get) Token: 0x06000C60 RID: 3168 RVA: 0x00091BEC File Offset: 0x0008FDEC
		' (set) Token: 0x06000C61 RID: 3169 RVA: 0x00091C04 File Offset: 0x0008FE04
		Friend Overridable Property txtMAHH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAHH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAHH.TextChanged, AddressOf Me.txtMAHH_TextChanged
					RemoveHandler Me._txtMAHH.KeyPress, AddressOf Me.txtMAHH_KeyPress
					RemoveHandler Me._txtMAHH.GotFocus, AddressOf Me.txtMAHH_GotFocus
				End If
				Me._txtMAHH = value
				flag = Me._txtMAHH IsNot Nothing
				If flag Then
					AddHandler Me._txtMAHH.TextChanged, AddressOf Me.txtMAHH_TextChanged
					AddHandler Me._txtMAHH.KeyPress, AddressOf Me.txtMAHH_KeyPress
					AddHandler Me._txtMAHH.GotFocus, AddressOf Me.txtMAHH_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000482 RID: 1154
		' (get) Token: 0x06000C62 RID: 3170 RVA: 0x00091CD4 File Offset: 0x0008FED4
		' (set) Token: 0x06000C63 RID: 3171 RVA: 0x0000416D File Offset: 0x0000236D
		Friend Overridable Property lblDONGIA As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDONGIA
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDONGIA = value
			End Set
		End Property

		' Token: 0x17000483 RID: 1155
		' (get) Token: 0x06000C64 RID: 3172 RVA: 0x00091CEC File Offset: 0x0008FEEC
		' (set) Token: 0x06000C65 RID: 3173 RVA: 0x00091D04 File Offset: 0x0008FF04
		Friend Overridable Property cmbPrice As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbPrice
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbPrice IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbPrice.KeyPress, AddressOf Me.cmbPrice_KeyPress
				End If
				Me._cmbPrice = value
				flag = Me._cmbPrice IsNot Nothing
				If flag Then
					AddHandler Me._cmbPrice.KeyPress, AddressOf Me.cmbPrice_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000484 RID: 1156
		' (get) Token: 0x06000C66 RID: 3174 RVA: 0x00091D70 File Offset: 0x0008FF70
		' (set) Token: 0x06000C67 RID: 3175 RVA: 0x00091D88 File Offset: 0x0008FF88
		Friend Overridable Property txtTENDVT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENDVT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENDVT IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENDVT.GotFocus, AddressOf Me.txtTENDVT_GotFocus
				End If
				Me._txtTENDVT = value
				flag = Me._txtTENDVT IsNot Nothing
				If flag Then
					AddHandler Me._txtTENDVT.GotFocus, AddressOf Me.txtTENDVT_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000485 RID: 1157
		' (get) Token: 0x06000C68 RID: 3176 RVA: 0x00091DF4 File Offset: 0x0008FFF4
		' (set) Token: 0x06000C69 RID: 3177 RVA: 0x00091E0C File Offset: 0x0009000C
		Friend Overridable Property btnDMDVT As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMDVT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMDVT IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMDVT.Click, AddressOf Me.btnDMDVT_Click
				End If
				Me._btnDMDVT = value
				flag = Me._btnDMDVT IsNot Nothing
				If flag Then
					AddHandler Me._btnDMDVT.Click, AddressOf Me.btnDMDVT_Click
				End If
			End Set
		End Property

		' Token: 0x17000486 RID: 1158
		' (get) Token: 0x06000C6A RID: 3178 RVA: 0x00091E78 File Offset: 0x00090078
		' (set) Token: 0x06000C6B RID: 3179 RVA: 0x00091E90 File Offset: 0x00090090
		Friend Overridable Property txtMADVT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMADVT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMADVT IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMADVT.GotFocus, AddressOf Me.txtMADVT_GotFocus
					RemoveHandler Me._txtMADVT.TextChanged, AddressOf Me.txtMADVT_TextChanged
					RemoveHandler Me._txtMADVT.KeyPress, AddressOf Me.txtMADVT_KeyPress
				End If
				Me._txtMADVT = value
				flag = Me._txtMADVT IsNot Nothing
				If flag Then
					AddHandler Me._txtMADVT.GotFocus, AddressOf Me.txtMADVT_GotFocus
					AddHandler Me._txtMADVT.TextChanged, AddressOf Me.txtMADVT_TextChanged
					AddHandler Me._txtMADVT.KeyPress, AddressOf Me.txtMADVT_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000487 RID: 1159
		' (get) Token: 0x06000C6C RID: 3180 RVA: 0x00091F60 File Offset: 0x00090160
		' (set) Token: 0x06000C6D RID: 3181 RVA: 0x00004177 File Offset: 0x00002377
		Friend Overridable Property lblDVTinh As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDVTinh
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDVTinh = value
			End Set
		End Property

		' Token: 0x17000488 RID: 1160
		' (get) Token: 0x06000C6E RID: 3182 RVA: 0x00091F78 File Offset: 0x00090178
		' (set) Token: 0x06000C6F RID: 3183 RVA: 0x00004181 File Offset: 0x00002381
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000489 RID: 1161
		' (get) Token: 0x06000C70 RID: 3184 RVA: 0x00091F90 File Offset: 0x00090190
		' (set) Token: 0x06000C71 RID: 3185 RVA: 0x0000418B File Offset: 0x0000238B
		Public Property pBytLevelPrice As Byte
			Get
				Return Me.mbytLevelPrice
			End Get
			Set(value As Byte)
				Me.mbytLevelPrice = value
			End Set
		End Property

		' Token: 0x1700048A RID: 1162
		' (get) Token: 0x06000C72 RID: 3186 RVA: 0x00091FA8 File Offset: 0x000901A8
		' (set) Token: 0x06000C73 RID: 3187 RVA: 0x00004196 File Offset: 0x00002396
		Public Property pStrMAAUTOPRICE As String
			Get
				Return Me.mStrMAAUTOPRICE
			End Get
			Set(value As String)
				Me.mStrMAAUTOPRICE = value
			End Set
		End Property

		' Token: 0x1700048B RID: 1163
		' (get) Token: 0x06000C74 RID: 3188 RVA: 0x00091FC0 File Offset: 0x000901C0
		' (set) Token: 0x06000C75 RID: 3189 RVA: 0x000041A1 File Offset: 0x000023A1
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x1700048C RID: 1164
		' (get) Token: 0x06000C76 RID: 3190 RVA: 0x00091FD8 File Offset: 0x000901D8
		' (set) Token: 0x06000C77 RID: 3191 RVA: 0x000041AC File Offset: 0x000023AC
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x1700048D RID: 1165
		' (get) Token: 0x06000C78 RID: 3192 RVA: 0x00091FF0 File Offset: 0x000901F0
		' (set) Token: 0x06000C79 RID: 3193 RVA: 0x000041B7 File Offset: 0x000023B7
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06000C7A RID: 3194 RVA: 0x00092008 File Offset: 0x00090208
		Private Sub txtMAHH_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMAHH.[ReadOnly]
				If [readOnly] Then
					Me.txtMADVT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAHH_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C7B RID: 3195 RVA: 0x000920B4 File Offset: 0x000902B4
		Private Sub txtMAHH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMADVT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAHH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000C7C RID: 3196 RVA: 0x00092158 File Offset: 0x00090358
		Private Sub txtMAHH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMHH Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMHH.Columns("OBJID")
					Me.mclsTbDMHH.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMHH.Rows.Find(Strings.Trim(Me.txtMAHH.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENHH.Text = dataRow("OBJNAME").ToString()
						flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
						If flag Then
							Me.txtMADVT.Text = dataRow("MADVT").ToString()
						End If
						Me.mstrMADVT_HH = dataRow("MADVT").ToString()
					Else
						Me.txtTENHH.Text = ""
						Me.mstrMADVT_HH = ""
						flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
						If flag Then
							Me.txtMADVT.Text = ""
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAHH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C7D RID: 3197 RVA: 0x0009232C File Offset: 0x0009052C
		Private Sub txtTENHH_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENHH.[ReadOnly]
				If [readOnly] Then
					Me.txtMADVT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENHH_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C7E RID: 3198 RVA: 0x000923D8 File Offset: 0x000905D8
		Private Sub cmbPrice_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbPrice_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000C7F RID: 3199 RVA: 0x0009247C File Offset: 0x0009067C
		Private Sub btnSelDMHH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMHH As frmDMHH1 = New frmDMHH1()
				frmDMHH.pBytOpen_From_Menu = 7
				frmDMHH.ShowDialog()
				Dim flag As Boolean = Operators.CompareString(frmDMHH.pStrOBJID, "", False) = 0
				If Not flag Then
					Me.txtMAHH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMHH.pStrOBJID, "", False) = 0, Me.txtMAHH.Text, frmDMHH.pStrOBJID))
					Me.txtTENHH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMHH.pStrOBJNAME, "", False) = 0, Me.txtTENHH.Text, frmDMHH.pStrOBJNAME))
					Me.txtMADVT.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMHH.pStrDVT, "", False) = 0, Me.txtMADVT.Text, frmDMHH.pStrDVT))
					frmDMHH.Dispose()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelDMHH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C80 RID: 3200 RVA: 0x00092610 File Offset: 0x00090810
		Private Sub frmDMAUTOPRICE4_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Me.txtMAHH_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtMADVT_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMAUTOPRICE4_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C81 RID: 3201 RVA: 0x000926D8 File Offset: 0x000908D8
		Private Sub frmDMAUTOPRICE4_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4DMHH()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4DMDVT()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4ComboPrice()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMAUTOPRICE4_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C82 RID: 3202 RVA: 0x000927BC File Offset: 0x000909BC
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtMAHH.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(18), MsgBoxStyle.Critical, Nothing)
					Me.txtMAHH.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtMADVT.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(19), MsgBoxStyle.Critical, Nothing)
						Me.txtMADVT.Focus()
					Else
						flag = (Operators.CompareString(Strings.Trim(Me.txtMAHH.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENHH.Text), "", False) = 0)
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
							Me.txtMAHH.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.txtMADVT.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENDVT.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
								Me.txtMADVT.Focus()
							Else
								flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
								If flag Then
									Me.mbytSuccess = Me.fAddNew()
								Else
									flag = Me.mbytFormStatus = 3
									If flag Then
										Me.mbytSuccess = Me.fModify()
									End If
								End If
								flag = Me.mbytSuccess = 1
								If flag Then
									Me.Close()
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C83 RID: 3203 RVA: 0x00092A18 File Offset: 0x00090C18
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C84 RID: 3204 RVA: 0x00092ABC File Offset: 0x00090CBC
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtMAHH.[ReadOnly] = True
						Me.txtMAHH.BackColor = Me.txtTENHH.BackColor
						Me.btnSelDMHH.Enabled = False
						Me.txtMADVT.[ReadOnly] = True
						Me.txtMADVT.BackColor = Me.txtTENHH.BackColor
						Me.btnDMDVT.Enabled = False
					Case 4
						Me.txtMAHH.[ReadOnly] = True
						Me.txtMAHH.BackColor = Me.txtTENHH.BackColor
						Me.cmbPrice.Enabled = False
						Me.cmbPrice.BackColor = Me.txtTENHH.BackColor
						Me.txtMADVT.[ReadOnly] = True
						Me.txtMADVT.BackColor = Me.txtTENHH.BackColor
						Me.btnSelDMHH.Enabled = False
						Me.btnDMDVT.Enabled = False
						Me.btnDelete.Focus()
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C85 RID: 3205 RVA: 0x00092C84 File Offset: 0x00090E84
		Private Sub txtMADVT_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMADVT.[ReadOnly]
				If [readOnly] Then
					Me.cmbPrice.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADVT_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C86 RID: 3206 RVA: 0x00092D30 File Offset: 0x00090F30
		Private Sub txtMADVT_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbPrice.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADVT_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000C87 RID: 3207 RVA: 0x00092DD4 File Offset: 0x00090FD4
		Private Sub txtTENDVT_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENDVT.[ReadOnly]
				If [readOnly] Then
					Me.cmbPrice.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENHH_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C88 RID: 3208 RVA: 0x00092E80 File Offset: 0x00091080
		Private Sub txtMADVT_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMDVT Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMDVT.Columns("OBJID")
					Me.mclsTbDMDVT.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMDVT.Rows.Find(Strings.Trim(Me.txtMADVT.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENDVT.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENDVT.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADVT_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C89 RID: 3209 RVA: 0x00092FD4 File Offset: 0x000911D4
		Private Sub btnDMDVT_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDVT As frmDMDVT1 = New frmDMDVT1()
				frmDMDVT.pBytOpen_From_Menu = 7
				frmDMDVT.ShowDialog()
				Dim flag As Boolean = Operators.CompareString(frmDMDVT.pStrOBJID, "", False) = 0
				If Not flag Then
					Me.txtMADVT.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDVT.pStrOBJID, "", False) = 0, Me.txtMADVT.Text, frmDMDVT.pStrOBJID))
					Me.txtTENDVT.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDVT.pStrOBJNAME, "", False) = 0, Me.txtTENDVT.Text, frmDMDVT.pStrOBJNAME))
					frmDMDVT.Dispose()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMDVT_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C8A RID: 3210 RVA: 0x00093130 File Offset: 0x00091330
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnSave.Enabled = False
				Me.btnDelete.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtMAHH.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtMAHH.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C8B RID: 3211 RVA: 0x0009327C File Offset: 0x0009147C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtMAHH.MaxLength = 15
				Me.txtTENHH.[ReadOnly] = True
				Me.txtMAHH.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C8C RID: 3212 RVA: 0x00093350 File Offset: 0x00091550
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblMAHH.Tag = "CB0007"
					Me.lblDVTinh.Tag = "CB0008"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C8D RID: 3213 RVA: 0x00093534 File Offset: 0x00091734
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMHH.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C8E RID: 3214 RVA: 0x000935E0 File Offset: 0x000917E0
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAAUTOPRICE"
				array(0).Value = Me.mStrMAAUTOPRICE
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHH"
				array(1).Value = Strings.Trim(Me.txtMAHH.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMADVT"
				array(2).Value = Me.txtMADVT.Text.Trim()
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@ptniLEVEL"
				array(3).Value = Me.cmbPrice.SelectedIndex
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@int_Result"
				array(4).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMAUTOPRICE_INSERT_DETAIL", flag)
				Dim num As Integer = Conversions.ToInteger(array(4).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.mStrMAAUTOPRICE) + Strings.Trim(Me.txtMAHH.Text) + Strings.Trim(Me.txtMADVT.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
						Me.txtMAHH.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
							Me.txtMADVT.Focus()
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
								Me.btnExit.Focus()
							Else
								flag2 = num = 4
								If flag2 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
									Me.btnExit.Focus()
								Else
									Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
									Me.btnExit.Focus()
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000C8F RID: 3215 RVA: 0x000938E4 File Offset: 0x00091AE4
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAAUTOPRICE"
				array(0).Value = Me.mStrMAAUTOPRICE
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHH"
				array(1).Value = Strings.Trim(Me.txtMAHH.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMADVT"
				array(2).Value = Me.txtMADVT.Text.Trim()
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@ptniLEVEL"
				array(3).Value = Me.cmbPrice.SelectedIndex
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@int_Result"
				array(4).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMAUTOPRICE_UPDATE_DETAIL", flag)
				Dim num As Integer = Conversions.ToInteger(array(4).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.mStrMAAUTOPRICE) + Strings.Trim(Me.txtMAHH.Text) + Strings.Trim(Me.txtMADVT.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
						Me.txtMAHH.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
							Me.txtMADVT.Focus()
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
								Me.btnExit.Focus()
							Else
								flag2 = num = 4
								If flag2 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
									Me.btnExit.Focus()
								Else
									Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
									Me.btnExit.Focus()
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fModify ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000C90 RID: 3216 RVA: 0x00093BE4 File Offset: 0x00091DE4
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAAUTOPRICE"
				array(0).Value = Me.mStrMAAUTOPRICE
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHH"
				array(1).Value = Strings.Trim(Me.txtMAHH.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMADVT"
				array(2).Value = Me.txtMADVT.Text.Trim()
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@int_Result"
				array(3).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMAUTOPRICE_DEL_DETAIL", flag)
				Dim num As Integer = Conversions.ToInteger(array(3).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000C91 RID: 3217 RVA: 0x00093DE8 File Offset: 0x00091FE8
		Private Function fGetData_4DMHH() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMHH = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
				Dim flag As Boolean = Me.mclsTbDMHH IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4DMHH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C92 RID: 3218 RVA: 0x00093EA4 File Offset: 0x000920A4
		Private Function fGetData_4DMDVT() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMDVT = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMDVT")
				Dim flag As Boolean = Me.mclsTbDMDVT IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4DMDVT ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C93 RID: 3219 RVA: 0x00093F60 File Offset: 0x00092160
		Private Function fGetData_4ComboPrice() As Byte
			' The following expression was wrapped in a checked-statement
			Dim b As Byte
			Try
				b = 0
				Me.cmbPrice.Items.Clear()
				Dim num As Integer = 1
				Dim num2 As Integer
				Dim num3 As Integer
				Do
					Dim cmbPrice As ComboBox = Me.cmbPrice
					cmbPrice.Items.Add(Me.mArrStrFrmMess(10) + " " + num.ToString())
					num += 1
					num2 = num
					num3 = 10
				Loop While num2 <= num3
				Me.cmbPrice.SelectedIndex = Conversions.ToInteger(Interaction.IIf(Me.mbytLevelPrice > 0, CInt((Me.mbytLevelPrice - 1)), 0))
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4ComboPrice ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x04000556 RID: 1366
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000558 RID: 1368
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000559 RID: 1369
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x0400055A RID: 1370
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x0400055B RID: 1371
		<AccessedThroughProperty("lblMAHH")>
		Private _lblMAHH As Label

		' Token: 0x0400055C RID: 1372
		<AccessedThroughProperty("txtTENHH")>
		Private _txtTENHH As TextBox

		' Token: 0x0400055D RID: 1373
		<AccessedThroughProperty("btnSelDMHH")>
		Private _btnSelDMHH As Button

		' Token: 0x0400055E RID: 1374
		<AccessedThroughProperty("txtMAHH")>
		Private _txtMAHH As TextBox

		' Token: 0x0400055F RID: 1375
		<AccessedThroughProperty("lblDONGIA")>
		Private _lblDONGIA As Label

		' Token: 0x04000560 RID: 1376
		<AccessedThroughProperty("cmbPrice")>
		Private _cmbPrice As ComboBox

		' Token: 0x04000561 RID: 1377
		<AccessedThroughProperty("txtTENDVT")>
		Private _txtTENDVT As TextBox

		' Token: 0x04000562 RID: 1378
		<AccessedThroughProperty("btnDMDVT")>
		Private _btnDMDVT As Button

		' Token: 0x04000563 RID: 1379
		<AccessedThroughProperty("txtMADVT")>
		Private _txtMADVT As TextBox

		' Token: 0x04000564 RID: 1380
		<AccessedThroughProperty("lblDVTinh")>
		Private _lblDVTinh As Label

		' Token: 0x04000565 RID: 1381
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000566 RID: 1382
		Private mArrStrFrmMess As String()

		' Token: 0x04000567 RID: 1383
		Private mbytFormStatus As Byte

		' Token: 0x04000568 RID: 1384
		Private mbytSuccess As Byte

		' Token: 0x04000569 RID: 1385
		Private mStrFilter As String

		' Token: 0x0400056A RID: 1386
		Private mStrMAAUTOPRICE As String

		' Token: 0x0400056B RID: 1387
		Private marrDblPrice As Double()

		' Token: 0x0400056C RID: 1388
		Private mclsTbDMHH As clsConnect

		' Token: 0x0400056D RID: 1389
		Private mclsTbDMDVT As clsConnect

		' Token: 0x0400056E RID: 1390
		Private mstrMADVT_HH As String

		' Token: 0x0400056F RID: 1391
		Private mbytLevelPrice As Byte

		' Token: 0x04000570 RID: 1392
		Private strTemp As String
	End Class
End Namespace
