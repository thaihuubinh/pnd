﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x02000111 RID: 273
	Public Class crpKitchenTemTraSua
		Inherits ReportClass

		' Token: 0x060056BB RID: 22203 RVA: 0x0000EE18 File Offset: 0x0000D018
		Public Sub New()
			crpKitchenTemTraSua.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001F13 RID: 7955
		' (get) Token: 0x060056BC RID: 22204 RVA: 0x004DAD88 File Offset: 0x004D8F88
		' (set) Token: 0x060056BD RID: 22205 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crpKitchenTemTraSua.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001F14 RID: 7956
		' (get) Token: 0x060056BE RID: 22206 RVA: 0x004DA738 File Offset: 0x004D8938
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsTitle As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001F15 RID: 7957
		' (get) Token: 0x060056BF RID: 22207 RVA: 0x004DA75C File Offset: 0x004D895C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsCall As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001F16 RID: 7958
		' (get) Token: 0x060056C0 RID: 22208 RVA: 0x004DA780 File Offset: 0x004D8980
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsTable As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001F17 RID: 7959
		' (get) Token: 0x060056C1 RID: 22209 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsTable2 As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001F18 RID: 7960
		' (get) Token: 0x060056C2 RID: 22210 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsLogo As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001F19 RID: 7961
		' (get) Token: 0x060056C3 RID: 22211 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property phsTieude1 As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x17001F1A RID: 7962
		' (get) Token: 0x060056C4 RID: 22212 RVA: 0x004DA810 File Offset: 0x004D8A10
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property PageHeaderSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(6)
			End Get
		End Property

		' Token: 0x17001F1B RID: 7963
		' (get) Token: 0x060056C5 RID: 22213 RVA: 0x004DA834 File Offset: 0x004D8A34
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dsDVTTEN As Section
			Get
				Return Me.ReportDefinition.Sections(7)
			End Get
		End Property

		' Token: 0x17001F1C RID: 7964
		' (get) Token: 0x060056C6 RID: 22214 RVA: 0x004DA858 File Offset: 0x004D8A58
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(8)
			End Get
		End Property

		' Token: 0x17001F1D RID: 7965
		' (get) Token: 0x060056C7 RID: 22215 RVA: 0x004DA87C File Offset: 0x004D8A7C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(9)
			End Get
		End Property

		' Token: 0x17001F1E RID: 7966
		' (get) Token: 0x060056C8 RID: 22216 RVA: 0x004DA8A0 File Offset: 0x004D8AA0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property sTien As Section
			Get
				Return Me.ReportDefinition.Sections(10)
			End Get
		End Property

		' Token: 0x17001F1F RID: 7967
		' (get) Token: 0x060056C9 RID: 22217 RVA: 0x004DA8C4 File Offset: 0x004D8AC4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property sNgay As Section
			Get
				Return Me.ReportDefinition.Sections(11)
			End Get
		End Property

		' Token: 0x17001F20 RID: 7968
		' (get) Token: 0x060056CA RID: 22218 RVA: 0x004DA8E8 File Offset: 0x004D8AE8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsRemark As Section
			Get
				Return Me.ReportDefinition.Sections(12)
			End Get
		End Property

		' Token: 0x17001F21 RID: 7969
		' (get) Token: 0x060056CB RID: 22219 RVA: 0x004DA90C File Offset: 0x004D8B0C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(13)
			End Get
		End Property

		' Token: 0x04002709 RID: 9993
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
