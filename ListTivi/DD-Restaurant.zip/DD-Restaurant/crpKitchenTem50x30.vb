﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x0200010D RID: 269
	Public Class crpKitchenTem50x30
		Inherits ReportClass

		' Token: 0x0600568B RID: 22155 RVA: 0x0000ED74 File Offset: 0x0000CF74
		Public Sub New()
			crpKitchenTem50x30.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001EF7 RID: 7927
		' (get) Token: 0x0600568C RID: 22156 RVA: 0x004DAD08 File Offset: 0x004D8F08
		' (set) Token: 0x0600568D RID: 22157 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crpKitchenTem50x30.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001EF8 RID: 7928
		' (get) Token: 0x0600568E RID: 22158 RVA: 0x004DA738 File Offset: 0x004D8938
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsTitle As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001EF9 RID: 7929
		' (get) Token: 0x0600568F RID: 22159 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsCall As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001EFA RID: 7930
		' (get) Token: 0x06005690 RID: 22160 RVA: 0x004DA780 File Offset: 0x004D8980
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsTable As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001EFB RID: 7931
		' (get) Token: 0x06005691 RID: 22161 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsTable2 As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001EFC RID: 7932
		' (get) Token: 0x06005692 RID: 22162 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsLogo As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001EFD RID: 7933
		' (get) Token: 0x06005693 RID: 22163 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property phsTieude1 As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x17001EFE RID: 7934
		' (get) Token: 0x06005694 RID: 22164 RVA: 0x004DA810 File Offset: 0x004D8A10
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property PageHeaderSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(6)
			End Get
		End Property

		' Token: 0x17001EFF RID: 7935
		' (get) Token: 0x06005695 RID: 22165 RVA: 0x004DA834 File Offset: 0x004D8A34
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dsDVTTEN As Section
			Get
				Return Me.ReportDefinition.Sections(7)
			End Get
		End Property

		' Token: 0x17001F00 RID: 7936
		' (get) Token: 0x06005696 RID: 22166 RVA: 0x004DA858 File Offset: 0x004D8A58
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(8)
			End Get
		End Property

		' Token: 0x17001F01 RID: 7937
		' (get) Token: 0x06005697 RID: 22167 RVA: 0x004DA87C File Offset: 0x004D8A7C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(9)
			End Get
		End Property

		' Token: 0x17001F02 RID: 7938
		' (get) Token: 0x06005698 RID: 22168 RVA: 0x004DA8A0 File Offset: 0x004D8AA0
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property sTien As Section
			Get
				Return Me.ReportDefinition.Sections(10)
			End Get
		End Property

		' Token: 0x17001F03 RID: 7939
		' (get) Token: 0x06005699 RID: 22169 RVA: 0x004DA8C4 File Offset: 0x004D8AC4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property sNgay As Section
			Get
				Return Me.ReportDefinition.Sections(11)
			End Get
		End Property

		' Token: 0x17001F04 RID: 7940
		' (get) Token: 0x0600569A RID: 22170 RVA: 0x004DA8E8 File Offset: 0x004D8AE8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsRemark As Section
			Get
				Return Me.ReportDefinition.Sections(12)
			End Get
		End Property

		' Token: 0x17001F05 RID: 7941
		' (get) Token: 0x0600569B RID: 22171 RVA: 0x004DA90C File Offset: 0x004D8B0C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(13)
			End Get
		End Property

		' Token: 0x04002705 RID: 9989
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
