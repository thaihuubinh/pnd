﻿Imports System
Imports System.Diagnostics

Namespace prjIS_SalesPOS
	' Token: 0x020000F7 RID: 247
	Public Class ApiRequest
		' Token: 0x06005539 RID: 21817 RVA: 0x00007789 File Offset: 0x00005989
		<DebuggerNonUserCode()>
		Public Sub New()
		End Sub

		' Token: 0x040024EE RID: 9454
		Public accountNo As String

		' Token: 0x040024EF RID: 9455
		Public accountName As String

		' Token: 0x040024F0 RID: 9456
		Public acqId As String

		' Token: 0x040024F1 RID: 9457
		Public amount As String

		' Token: 0x040024F2 RID: 9458
		Public addInfo As String

		' Token: 0x040024F3 RID: 9459
		Public format As String

		' Token: 0x040024F4 RID: 9460
		Public template As String
	End Class
End Namespace
