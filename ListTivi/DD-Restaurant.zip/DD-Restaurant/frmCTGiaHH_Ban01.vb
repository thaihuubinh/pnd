﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000029 RID: 41
	<DesignerGenerated()>
	Public Partial Class frmCTGiaHH_Ban01
		Inherits Form

		' Token: 0x060007A1 RID: 1953 RVA: 0x00059A0C File Offset: 0x00057C0C
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDOCUMENT013_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDOCUMENT013_Load
			frmCTGiaHH_Ban01.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSourceDel = New BindingSource()
			Me.mStrMaBan = ""
			Me.mStrTenBan = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x170002E8 RID: 744
		' (get) Token: 0x060007A4 RID: 1956 RVA: 0x0005ADA4 File Offset: 0x00058FA4
		' (set) Token: 0x060007A5 RID: 1957 RVA: 0x000034B1 File Offset: 0x000016B1
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x170002E9 RID: 745
		' (get) Token: 0x060007A6 RID: 1958 RVA: 0x0005ADBC File Offset: 0x00058FBC
		' (set) Token: 0x060007A7 RID: 1959 RVA: 0x000034BB File Offset: 0x000016BB
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnAddDefault = value
			End Set
		End Property

		' Token: 0x170002EA RID: 746
		' (get) Token: 0x060007A8 RID: 1960 RVA: 0x0005ADD4 File Offset: 0x00058FD4
		' (set) Token: 0x060007A9 RID: 1961 RVA: 0x0005ADEC File Offset: 0x00058FEC
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170002EB RID: 747
		' (get) Token: 0x060007AA RID: 1962 RVA: 0x0005AE58 File Offset: 0x00059058
		' (set) Token: 0x060007AB RID: 1963 RVA: 0x0005AE70 File Offset: 0x00059070
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x170002EC RID: 748
		' (get) Token: 0x060007AC RID: 1964 RVA: 0x0005AEDC File Offset: 0x000590DC
		' (set) Token: 0x060007AD RID: 1965 RVA: 0x0005AEF4 File Offset: 0x000590F4
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x170002ED RID: 749
		' (get) Token: 0x060007AE RID: 1966 RVA: 0x0005AF60 File Offset: 0x00059160
		' (set) Token: 0x060007AF RID: 1967 RVA: 0x000034C5 File Offset: 0x000016C5
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnFind = value
			End Set
		End Property

		' Token: 0x170002EE RID: 750
		' (get) Token: 0x060007B0 RID: 1968 RVA: 0x0005AF78 File Offset: 0x00059178
		' (set) Token: 0x060007B1 RID: 1969 RVA: 0x000034CF File Offset: 0x000016CF
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnCancelFilter = value
			End Set
		End Property

		' Token: 0x170002EF RID: 751
		' (get) Token: 0x060007B2 RID: 1970 RVA: 0x0005AF90 File Offset: 0x00059190
		' (set) Token: 0x060007B3 RID: 1971 RVA: 0x000034D9 File Offset: 0x000016D9
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x170002F0 RID: 752
		' (get) Token: 0x060007B4 RID: 1972 RVA: 0x0005AFA8 File Offset: 0x000591A8
		' (set) Token: 0x060007B5 RID: 1973 RVA: 0x0005AFC0 File Offset: 0x000591C0
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x170002F1 RID: 753
		' (get) Token: 0x060007B6 RID: 1974 RVA: 0x0005B02C File Offset: 0x0005922C
		' (set) Token: 0x060007B7 RID: 1975 RVA: 0x0005B044 File Offset: 0x00059244
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x170002F2 RID: 754
		' (get) Token: 0x060007B8 RID: 1976 RVA: 0x0005B0B0 File Offset: 0x000592B0
		' (set) Token: 0x060007B9 RID: 1977 RVA: 0x000034E3 File Offset: 0x000016E3
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnFilter = value
			End Set
		End Property

		' Token: 0x170002F3 RID: 755
		' (get) Token: 0x060007BA RID: 1978 RVA: 0x0005B0C8 File Offset: 0x000592C8
		' (set) Token: 0x060007BB RID: 1979 RVA: 0x000034ED File Offset: 0x000016ED
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170002F4 RID: 756
		' (get) Token: 0x060007BC RID: 1980 RVA: 0x0005B0E0 File Offset: 0x000592E0
		' (set) Token: 0x060007BD RID: 1981 RVA: 0x0005B0F8 File Offset: 0x000592F8
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x170002F5 RID: 757
		' (get) Token: 0x060007BE RID: 1982 RVA: 0x0005B164 File Offset: 0x00059364
		' (set) Token: 0x060007BF RID: 1983 RVA: 0x0005B17C File Offset: 0x0005937C
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x170002F6 RID: 758
		' (get) Token: 0x060007C0 RID: 1984 RVA: 0x0005B1E8 File Offset: 0x000593E8
		' (set) Token: 0x060007C1 RID: 1985 RVA: 0x0005B200 File Offset: 0x00059400
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170002F7 RID: 759
		' (get) Token: 0x060007C2 RID: 1986 RVA: 0x0005B26C File Offset: 0x0005946C
		' (set) Token: 0x060007C3 RID: 1987 RVA: 0x000034F7 File Offset: 0x000016F7
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnFindNext = value
			End Set
		End Property

		' Token: 0x170002F8 RID: 760
		' (get) Token: 0x060007C4 RID: 1988 RVA: 0x0005B284 File Offset: 0x00059484
		' (set) Token: 0x060007C5 RID: 1989 RVA: 0x00003501 File Offset: 0x00001701
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x170002F9 RID: 761
		' (get) Token: 0x060007C6 RID: 1990 RVA: 0x0005B29C File Offset: 0x0005949C
		' (set) Token: 0x060007C7 RID: 1991 RVA: 0x0000350B File Offset: 0x0000170B
		Friend Overridable Property lblMALN As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMALN
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMALN = value
			End Set
		End Property

		' Token: 0x170002FA RID: 762
		' (get) Token: 0x060007C8 RID: 1992 RVA: 0x0005B2B4 File Offset: 0x000594B4
		' (set) Token: 0x060007C9 RID: 1993 RVA: 0x00003515 File Offset: 0x00001715
		Friend Overridable Property txtMALN As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMALN
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtMALN = value
			End Set
		End Property

		' Token: 0x170002FB RID: 763
		' (get) Token: 0x060007CA RID: 1994 RVA: 0x0005B2CC File Offset: 0x000594CC
		' (set) Token: 0x060007CB RID: 1995 RVA: 0x0000351F File Offset: 0x0000171F
		Friend Overridable Property lblMADV As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMADV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMADV = value
			End Set
		End Property

		' Token: 0x170002FC RID: 764
		' (get) Token: 0x060007CC RID: 1996 RVA: 0x0005B2E4 File Offset: 0x000594E4
		' (set) Token: 0x060007CD RID: 1997 RVA: 0x00003529 File Offset: 0x00001729
		Friend Overridable Property txtMaBan As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMaBan
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtMaBan = value
			End Set
		End Property

		' Token: 0x170002FD RID: 765
		' (get) Token: 0x060007CE RID: 1998 RVA: 0x0005B2FC File Offset: 0x000594FC
		' (set) Token: 0x060007CF RID: 1999 RVA: 0x00003533 File Offset: 0x00001733
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170002FE RID: 766
		' (get) Token: 0x060007D0 RID: 2000 RVA: 0x0005B314 File Offset: 0x00059514
		' (set) Token: 0x060007D1 RID: 2001 RVA: 0x0005B32C File Offset: 0x0005952C
		Private Overridable Property mbdsSourceDel As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceDel IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceDel.PositionChanged, AddressOf Me.mbdsSourceDel_PositionChanged
				End If
				Me._mbdsSourceDel = value
				flag = Me._mbdsSourceDel IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceDel.PositionChanged, AddressOf Me.mbdsSourceDel_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170002FF RID: 767
		' (get) Token: 0x060007D2 RID: 2002 RVA: 0x0005B398 File Offset: 0x00059598
		' (set) Token: 0x060007D3 RID: 2003 RVA: 0x0000353D File Offset: 0x0000173D
		Public Property pStrMaBan As String
			Get
				Return Me.mStrMaBan
			End Get
			Set(value As String)
				Me.mStrMaBan = value
			End Set
		End Property

		' Token: 0x17000300 RID: 768
		' (get) Token: 0x060007D4 RID: 2004 RVA: 0x0005B3B0 File Offset: 0x000595B0
		' (set) Token: 0x060007D5 RID: 2005 RVA: 0x00003548 File Offset: 0x00001748
		Public Property pStrTenBan As String
			Get
				Return Me.mStrTenBan
			End Get
			Set(value As String)
				Me.mStrTenBan = value
			End Set
		End Property

		' Token: 0x17000301 RID: 769
		' (get) Token: 0x060007D6 RID: 2006 RVA: 0x0005B3C8 File Offset: 0x000595C8
		' (set) Token: 0x060007D7 RID: 2007 RVA: 0x00003553 File Offset: 0x00001753
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060007D8 RID: 2008 RVA: 0x0005B3E0 File Offset: 0x000595E0
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007D9 RID: 2009 RVA: 0x0005B4B0 File Offset: 0x000596B0
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceDel.Position
				Dim flag As Boolean = position < Me.mbdsSourceDel.Count - 1
				If flag Then
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					mbdsSourceDel.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007DA RID: 2010 RVA: 0x0005B5A0 File Offset: 0x000597A0
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceDel.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					mbdsSourceDel.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007DB RID: 2011 RVA: 0x0005B684 File Offset: 0x00059884
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSourceDel.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007DC RID: 2012 RVA: 0x0005B748 File Offset: 0x00059948
		Private Sub frmDOCUMENT013_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDOCUMENT013_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007DD RID: 2013 RVA: 0x0005B7E0 File Offset: 0x000599E0
		Private Sub frmDOCUMENT013_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				Me.txtMaBan.Text = Me.mStrMaBan
				Me.txtMALN.Text = Me.mStrTenBan
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDOCUMENT013_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007DE RID: 2014 RVA: 0x0005B90C File Offset: 0x00059B0C
		Private Sub mbdsSourceDel_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSourceDel.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					Me.lblPosition.Text = (mbdsSourceDel.Position + 1).ToString() + " / " + mbdsSourceDel.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceDel_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007DF RID: 2015 RVA: 0x0005BA14 File Offset: 0x00059C14
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007E0 RID: 2016 RVA: 0x0005BAAC File Offset: 0x00059CAC
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim text As String = ""
			Try
				Dim frmCTGIAHH_Ban As frmCTGIAHH_Ban02 = New frmCTGIAHH_Ban02()
				frmCTGIAHH_Ban.pbytFromStatus = 1
				frmCTGIAHH_Ban.pStrMABAN = Me.mStrMaBan
				frmCTGIAHH_Ban.ShowDialog()
				Dim flag As Boolean = frmCTGIAHH_Ban.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Find("KHOACHINH", text)
						Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007E1 RID: 2017 RVA: 0x0005BC1C File Offset: 0x00059E1C
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Try
				Dim frmCTGIAHH_Ban As frmCTGIAHH_Ban02 = New frmCTGIAHH_Ban02()
				frmCTGIAHH_Ban.pbytFromStatus = 3
				frmCTGIAHH_Ban.pStrMABAN = Me.mStrMaBan.Trim()
				frmCTGIAHH_Ban.txtMAHH.Text = Me.dgvData.CurrentRow.Cells("MAHH").Value.ToString()
				frmCTGIAHH_Ban.txtDONGIAMUA.Text = Me.dgvData.CurrentRow.Cells("DONGIA").Value.ToString()
				frmCTGIAHH_Ban.ShowDialog()
				Dim flag As Boolean = frmCTGIAHH_Ban.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b <> 0
					If flag Then
						Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007E2 RID: 2018 RVA: 0x0005BDB0 File Offset: 0x00059FB0
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				New frmCTGIAHH_Ban02() With { .pbytFromStatus = 4, .pStrMABAN = Me.mStrMaBan.Trim(), .txtMAHH = { .Text = Me.dgvData.CurrentRow.Cells("MAHH").Value.ToString() }, .txtDONGIAMUA = { .Text = Me.dgvData.CurrentRow.Cells("DONGIA").Value.ToString() } }.ShowDialog()
				Dim b As Byte = Me.fGetData_4Grid()
				Dim flag As Boolean = b = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007E3 RID: 2019 RVA: 0x0005BF20 File Offset: 0x0005A120
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("MAHH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("MAHH").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("MAHH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENHH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("TENHH").Width = Me.dgvData.Width - 300
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENHH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DVT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(21))
				dgvData.Columns("DVT").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("DVT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DONGIA").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("DONGIA").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("DONGIA").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("KHOACHINH").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060007E4 RID: 2020 RVA: 0x0005C1E8 File Offset: 0x0005A3E8
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060007E5 RID: 2021 RVA: 0x0005C2F0 File Offset: 0x0005A4F0
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMABAN"
				array(0).Value = Me.mStrMaBan.Trim()
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCTGIAHH_BAN01_GET_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSourceDel.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSourceDel
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060007E6 RID: 2022 RVA: 0x0005C41C File Offset: 0x0005A61C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Me.txtMaBan.[ReadOnly] = True
				Me.txtMALN.[ReadOnly] = True
				Me.btnAddDefault.Visible = False
				Me.btnFilter.Visible = False
				Me.btnCancelFilter.Visible = False
				Me.btnFind.Visible = False
				Me.btnFindNext.Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060007E7 RID: 2023 RVA: 0x0005C544 File Offset: 0x0005A744
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060007E8 RID: 2024 RVA: 0x0005C640 File Offset: 0x0005A840
		Private Sub sClear_Form()
			Try
				Me.mbdsSourceDel.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060007E9 RID: 2025 RVA: 0x0005C6EC File Offset: 0x0005A8EC
		Private Function fGetData_DMHH() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.Cursor = Cursors.WaitCursor
				Dim flag As Boolean
				Me.mclsTbDMHH = New clsConnect(mdlVariable.gStrConISDANHMUC, "SP_FRMSAL01_GET_DATA_DMHH", flag)
				Dim flag2 As Boolean = Me.mclsTbDMHH IsNot Nothing
				If flag2 Then
					b = 1
				End If
				Me.Cursor = Cursors.[Default]
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMLH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				Me.Cursor = Cursors.[Default]
			End Try
			Return b
		End Function

		' Token: 0x04000358 RID: 856
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400035A RID: 858
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x0400035B RID: 859
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x0400035C RID: 860
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x0400035D RID: 861
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x0400035E RID: 862
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x0400035F RID: 863
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000360 RID: 864
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000361 RID: 865
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000362 RID: 866
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000363 RID: 867
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000364 RID: 868
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000365 RID: 869
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000366 RID: 870
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000367 RID: 871
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000368 RID: 872
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000369 RID: 873
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x0400036A RID: 874
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x0400036B RID: 875
		<AccessedThroughProperty("lblMALN")>
		Private _lblMALN As Label

		' Token: 0x0400036C RID: 876
		<AccessedThroughProperty("txtMALN")>
		Private _txtMALN As TextBox

		' Token: 0x0400036D RID: 877
		<AccessedThroughProperty("lblMADV")>
		Private _lblMADV As Label

		' Token: 0x0400036E RID: 878
		<AccessedThroughProperty("txtMaBan")>
		Private _txtMaBan As TextBox

		' Token: 0x0400036F RID: 879
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000370 RID: 880
		Private mArrStrFrmMess As String()

		' Token: 0x04000371 RID: 881
		Private mStrOBJID As String

		' Token: 0x04000372 RID: 882
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000373 RID: 883
		<AccessedThroughProperty("mbdsSourceDel")>
		Private _mbdsSourceDel As BindingSource

		' Token: 0x04000374 RID: 884
		Private mStrMaBan As String

		' Token: 0x04000375 RID: 885
		Private mStrTenBan As String

		' Token: 0x04000376 RID: 886
		Private mclsTbDMHH As clsConnect
	End Class
End Namespace
