﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000152 RID: 338
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptDMDV_None
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600598B RID: 22923 RVA: 0x0000F881 File Offset: 0x0000DA81
		Public Sub New()
			CachedrptDMDV_None.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170020A0 RID: 8352
		' (get) Token: 0x0600598C RID: 22924 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x0600598D RID: 22925 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170020A1 RID: 8353
		' (get) Token: 0x0600598E RID: 22926 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x0600598F RID: 22927 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170020A2 RID: 8354
		' (get) Token: 0x06005990 RID: 22928 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005991 RID: 22929 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005992 RID: 22930 RVA: 0x004DB5A0 File Offset: 0x004D97A0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptDMDV_None() With { .Site = Me.Site }
		End Function

		' Token: 0x06005993 RID: 22931 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x0400274A RID: 10058
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
