﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000028 RID: 40
	<DesignerGenerated()>
	Public Partial Class frmConnecting
		Inherits Form

		' Token: 0x0600079B RID: 1947 RVA: 0x00003478 File Offset: 0x00001678
		<DebuggerNonUserCode()>
		Public Sub New()
			frmConnecting.__ENCList.Add(New WeakReference(Me))
			Me.InitializeComponent()
		End Sub

		' Token: 0x170002E7 RID: 743
		' (get) Token: 0x0600079E RID: 1950 RVA: 0x000599F4 File Offset: 0x00057BF4
		' (set) Token: 0x0600079F RID: 1951 RVA: 0x0000349A File Offset: 0x0000169A
		Friend Overridable Property picLoad As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picLoad
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._picLoad = value
			End Set
		End Property

		' Token: 0x04000355 RID: 853
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000357 RID: 855
		<AccessedThroughProperty("picLoad")>
		Private _picLoad As PictureBox
	End Class
End Namespace
