﻿Namespace prjIS_SalesPOS
	' Token: 0x02000033 RID: 51
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDiscount
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000AC1 RID: 2753 RVA: 0x0007EE30 File Offset: 0x0007D030
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
				If flag Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		' Token: 0x06000AC2 RID: 2754 RVA: 0x0007EE80 File Offset: 0x0007D080
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDiscount))
			Me.btn10 = New Global.System.Windows.Forms.Button()
			Me.btn20 = New Global.System.Windows.Forms.Button()
			Me.btn30 = New Global.System.Windows.Forms.Button()
			Me.btn40 = New Global.System.Windows.Forms.Button()
			Me.btn50 = New Global.System.Windows.Forms.Button()
			Me.btn60 = New Global.System.Windows.Forms.Button()
			Me.btn70 = New Global.System.Windows.Forms.Button()
			Me.btn80 = New Global.System.Windows.Forms.Button()
			Me.btn90 = New Global.System.Windows.Forms.Button()
			Me.btn100 = New Global.System.Windows.Forms.Button()
			Me.txtPer = New Global.System.Windows.Forms.TextBox()
			Me.btnOK = New Global.System.Windows.Forms.Button()
			Me.GroupBox1 = New Global.System.Windows.Forms.GroupBox()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btn_30 = New Global.System.Windows.Forms.Button()
			Me.btn_60 = New Global.System.Windows.Forms.Button()
			Me.btnUser = New Global.System.Windows.Forms.Button()
			Me.GroupBox1.SuspendLayout()
			Me.SuspendLayout()
			Me.btn10.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn As Global.System.Windows.Forms.Control = Me.btn10
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(9, 8)
			btn.Location = point
			Me.btn10.Name = "btn10"
			Dim btn2 As Global.System.Windows.Forms.Control = Me.btn10
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(75, 55)
			btn2.Size = size
			Me.btn10.TabIndex = 0
			Me.btn10.Tag = "NC014B0002"
			Me.btn10.Text = "5"
			Me.btn10.UseVisualStyleBackColor = True
			Me.btn20.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn3 As Global.System.Windows.Forms.Control = Me.btn20
			point = New Global.System.Drawing.Point(90, 8)
			btn3.Location = point
			Me.btn20.Name = "btn20"
			Dim btn4 As Global.System.Windows.Forms.Control = Me.btn20
			size = New Global.System.Drawing.Size(75, 55)
			btn4.Size = size
			Me.btn20.TabIndex = 0
			Me.btn20.Tag = "NC014B0003"
			Me.btn20.Text = "10"
			Me.btn20.UseVisualStyleBackColor = True
			Me.btn30.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn5 As Global.System.Windows.Forms.Control = Me.btn30
			point = New Global.System.Drawing.Point(172, 8)
			btn5.Location = point
			Me.btn30.Name = "btn30"
			Dim btn6 As Global.System.Windows.Forms.Control = Me.btn30
			size = New Global.System.Drawing.Size(75, 55)
			btn6.Size = size
			Me.btn30.TabIndex = 0
			Me.btn30.Tag = "NC014B0004"
			Me.btn30.Text = "15"
			Me.btn30.UseVisualStyleBackColor = True
			Me.btn40.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn7 As Global.System.Windows.Forms.Control = Me.btn40
			point = New Global.System.Drawing.Point(253, 8)
			btn7.Location = point
			Me.btn40.Name = "btn40"
			Dim btn8 As Global.System.Windows.Forms.Control = Me.btn40
			size = New Global.System.Drawing.Size(75, 55)
			btn8.Size = size
			Me.btn40.TabIndex = 0
			Me.btn40.Tag = "NC014B0005"
			Me.btn40.Text = "20"
			Me.btn40.UseVisualStyleBackColor = True
			Me.btn50.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn9 As Global.System.Windows.Forms.Control = Me.btn50
			point = New Global.System.Drawing.Point(334, 8)
			btn9.Location = point
			Me.btn50.Name = "btn50"
			Dim btn10 As Global.System.Windows.Forms.Control = Me.btn50
			size = New Global.System.Drawing.Size(75, 55)
			btn10.Size = size
			Me.btn50.TabIndex = 0
			Me.btn50.Tag = "NC014B0006"
			Me.btn50.Text = "25"
			Me.btn50.UseVisualStyleBackColor = True
			Me.btn60.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn11 As Global.System.Windows.Forms.Control = Me.btn60
			point = New Global.System.Drawing.Point(9, 69)
			btn11.Location = point
			Me.btn60.Name = "btn60"
			Dim btn12 As Global.System.Windows.Forms.Control = Me.btn60
			size = New Global.System.Drawing.Size(75, 55)
			btn12.Size = size
			Me.btn60.TabIndex = 0
			Me.btn60.Tag = "NC014B0007"
			Me.btn60.Text = "50"
			Me.btn60.UseVisualStyleBackColor = True
			Me.btn70.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn13 As Global.System.Windows.Forms.Control = Me.btn70
			point = New Global.System.Drawing.Point(172, 69)
			btn13.Location = point
			Me.btn70.Name = "btn70"
			Dim btn14 As Global.System.Windows.Forms.Control = Me.btn70
			size = New Global.System.Drawing.Size(75, 55)
			btn14.Size = size
			Me.btn70.TabIndex = 0
			Me.btn70.Tag = "NC014B0008"
			Me.btn70.Text = "70%"
			Me.btn70.UseVisualStyleBackColor = True
			Me.btn80.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn15 As Global.System.Windows.Forms.Control = Me.btn80
			point = New Global.System.Drawing.Point(253, 69)
			btn15.Location = point
			Me.btn80.Name = "btn80"
			Dim btn16 As Global.System.Windows.Forms.Control = Me.btn80
			size = New Global.System.Drawing.Size(75, 55)
			btn16.Size = size
			Me.btn80.TabIndex = 0
			Me.btn80.Tag = "NC014B0009"
			Me.btn80.Text = "80%"
			Me.btn80.UseVisualStyleBackColor = True
			Me.btn90.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn17 As Global.System.Windows.Forms.Control = Me.btn90
			point = New Global.System.Drawing.Point(334, 69)
			btn17.Location = point
			Me.btn90.Name = "btn90"
			Dim btn18 As Global.System.Windows.Forms.Control = Me.btn90
			size = New Global.System.Drawing.Size(75, 55)
			btn18.Size = size
			Me.btn90.TabIndex = 0
			Me.btn90.Tag = "NC014B0010"
			Me.btn90.Text = "90%"
			Me.btn90.UseVisualStyleBackColor = True
			Me.btn100.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn19 As Global.System.Windows.Forms.Control = Me.btn100
			point = New Global.System.Drawing.Point(415, 69)
			btn19.Location = point
			Me.btn100.Name = "btn100"
			Dim btn20 As Global.System.Windows.Forms.Control = Me.btn100
			size = New Global.System.Drawing.Size(75, 55)
			btn20.Size = size
			Me.btn100.TabIndex = 0
			Me.btn100.Tag = "NC014B0011"
			Me.btn100.Text = "100%"
			Me.btn100.UseVisualStyleBackColor = True
			Me.txtPer.Font = New Global.System.Drawing.Font("Arial", 20F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtPer As Global.System.Windows.Forms.Control = Me.txtPer
			point = New Global.System.Drawing.Point(15, 19)
			txtPer.Location = point
			Me.txtPer.Name = "txtPer"
			Dim txtPer2 As Global.System.Windows.Forms.Control = Me.txtPer
			size = New Global.System.Drawing.Size(89, 38)
			txtPer2.Size = size
			Me.txtPer.TabIndex = 2
			Me.txtPer.Text = "0"
			Me.txtPer.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.btnOK.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnOK.BackgroundImage = CType(componentResourceManager.GetObject("btnOK.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnOK.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnOK.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnOK.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnOK.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnOK.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Me.btnOK.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnOK As Global.System.Windows.Forms.Control = Me.btnOK
			point = New Global.System.Drawing.Point(136, 19)
			btnOK.Location = point
			Me.btnOK.Name = "btnOK"
			Dim btnOK2 As Global.System.Windows.Forms.Control = Me.btnOK
			size = New Global.System.Drawing.Size(117, 37)
			btnOK2.Size = size
			Me.btnOK.TabIndex = 4
			Me.btnOK.Tag = "NC014R0014"
			Me.btnOK.Text = "&OK"
			Me.btnOK.UseVisualStyleBackColor = False
			Me.GroupBox1.Controls.Add(Me.btnExit)
			Me.GroupBox1.Controls.Add(Me.txtPer)
			Me.GroupBox1.Controls.Add(Me.btnOK)
			Dim groupBox As Global.System.Windows.Forms.Control = Me.GroupBox1
			point = New Global.System.Drawing.Point(110, 127)
			groupBox.Location = point
			Me.GroupBox1.Name = "GroupBox1"
			Dim groupBox2 As Global.System.Windows.Forms.Control = Me.GroupBox1
			size = New Global.System.Drawing.Size(378, 67)
			groupBox2.Size = size
			Me.GroupBox1.TabIndex = 15
			Me.GroupBox1.TabStop = False
			Me.GroupBox1.Tag = "C00012"
			Me.GroupBox1.Text = "Nhập % giảm"
			Me.btnExit.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(256, 20)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(114, 37)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 11
			Me.btnExit.Tag = "NC014R0015"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = False
			Me.btn_30.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn_ As Global.System.Windows.Forms.Control = Me.btn_30
			point = New Global.System.Drawing.Point(415, 8)
			btn_.Location = point
			Me.btn_30.Name = "btn_30"
			Dim btn_2 As Global.System.Windows.Forms.Control = Me.btn_30
			size = New Global.System.Drawing.Size(75, 55)
			btn_2.Size = size
			Me.btn_30.TabIndex = 0
			Me.btn_30.Tag = "NC014B0017"
			Me.btn_30.Text = "30"
			Me.btn_30.UseVisualStyleBackColor = True
			Me.btn_60.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn_3 As Global.System.Windows.Forms.Control = Me.btn_60
			point = New Global.System.Drawing.Point(90, 69)
			btn_3.Location = point
			Me.btn_60.Name = "btn_60"
			Dim btn_4 As Global.System.Windows.Forms.Control = Me.btn_60
			size = New Global.System.Drawing.Size(75, 55)
			btn_4.Size = size
			Me.btn_60.TabIndex = 0
			Me.btn_60.Tag = "NC014B0018"
			Me.btn_60.Text = "60"
			Me.btn_60.UseVisualStyleBackColor = True
			Me.btnUser.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btnUser As Global.System.Windows.Forms.Control = Me.btnUser
			point = New Global.System.Drawing.Point(9, 132)
			btnUser.Location = point
			Me.btnUser.Name = "btnUser"
			Dim btnUser2 As Global.System.Windows.Forms.Control = Me.btnUser
			size = New Global.System.Drawing.Size(75, 55)
			btnUser2.Size = size
			Me.btnUser.TabIndex = 0
			Me.btnUser.Tag = "NC014B0020"
			Me.btnUser.Text = "40%"
			Me.btnUser.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(504, 198)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.GroupBox1)
			Me.Controls.Add(Me.btn100)
			Me.Controls.Add(Me.btn80)
			Me.Controls.Add(Me.btn90)
			Me.Controls.Add(Me.btn40)
			Me.Controls.Add(Me.btn70)
			Me.Controls.Add(Me.btn30)
			Me.Controls.Add(Me.btnUser)
			Me.Controls.Add(Me.btn60)
			Me.Controls.Add(Me.btn_60)
			Me.Controls.Add(Me.btn_30)
			Me.Controls.Add(Me.btn50)
			Me.Controls.Add(Me.btn20)
			Me.Controls.Add(Me.btn10)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmDiscount"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Tag = "C00001"
			Me.Text = "Discount"
			Me.GroupBox1.ResumeLayout(False)
			Me.GroupBox1.PerformLayout()
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x040004BD RID: 1213
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
