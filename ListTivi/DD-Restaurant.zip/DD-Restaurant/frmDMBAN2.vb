﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000039 RID: 57
	<DesignerGenerated()>
	Public Partial Class frmDMBAN2
		Inherits Form

		' Token: 0x06000CE4 RID: 3300 RVA: 0x00097EF0 File Offset: 0x000960F0
		<DebuggerNonUserCode()>
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMLN2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMLN2_Load
			frmDMBAN2.__ENCList.Add(New WeakReference(Me))
			Me.InitializeComponent()
		End Sub

		' Token: 0x170004A6 RID: 1190
		' (get) Token: 0x06000CE7 RID: 3303 RVA: 0x00099288 File Offset: 0x00097488
		' (set) Token: 0x06000CE8 RID: 3304 RVA: 0x00004225 File Offset: 0x00002425
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x170004A7 RID: 1191
		' (get) Token: 0x06000CE9 RID: 3305 RVA: 0x000992A0 File Offset: 0x000974A0
		' (set) Token: 0x06000CEA RID: 3306 RVA: 0x000992B8 File Offset: 0x000974B8
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170004A8 RID: 1192
		' (get) Token: 0x06000CEB RID: 3307 RVA: 0x00099324 File Offset: 0x00097524
		' (set) Token: 0x06000CEC RID: 3308 RVA: 0x0000422F File Offset: 0x0000242F
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x170004A9 RID: 1193
		' (get) Token: 0x06000CED RID: 3309 RVA: 0x0009933C File Offset: 0x0009753C
		' (set) Token: 0x06000CEE RID: 3310 RVA: 0x00099354 File Offset: 0x00097554
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x170004AA RID: 1194
		' (get) Token: 0x06000CEF RID: 3311 RVA: 0x000993C0 File Offset: 0x000975C0
		' (set) Token: 0x06000CF0 RID: 3312 RVA: 0x000993D8 File Offset: 0x000975D8
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170004AB RID: 1195
		' (get) Token: 0x06000CF1 RID: 3313 RVA: 0x00099444 File Offset: 0x00097644
		' (set) Token: 0x06000CF2 RID: 3314 RVA: 0x0009945C File Offset: 0x0009765C
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170004AC RID: 1196
		' (get) Token: 0x06000CF3 RID: 3315 RVA: 0x000994C8 File Offset: 0x000976C8
		' (set) Token: 0x06000CF4 RID: 3316 RVA: 0x00004239 File Offset: 0x00002439
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x170004AD RID: 1197
		' (get) Token: 0x06000CF5 RID: 3317 RVA: 0x000994E0 File Offset: 0x000976E0
		' (set) Token: 0x06000CF6 RID: 3318 RVA: 0x000994F8 File Offset: 0x000976F8
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170004AE RID: 1198
		' (get) Token: 0x06000CF7 RID: 3319 RVA: 0x00099594 File Offset: 0x00097794
		' (set) Token: 0x06000CF8 RID: 3320 RVA: 0x000995AC File Offset: 0x000977AC
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170004AF RID: 1199
		' (get) Token: 0x06000CF9 RID: 3321 RVA: 0x00099648 File Offset: 0x00097848
		' (set) Token: 0x06000CFA RID: 3322 RVA: 0x00004243 File Offset: 0x00002443
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x170004B0 RID: 1200
		' (get) Token: 0x06000CFB RID: 3323 RVA: 0x00099660 File Offset: 0x00097860
		' (set) Token: 0x06000CFC RID: 3324 RVA: 0x0000424D File Offset: 0x0000244D
		Friend Overridable Property txtColor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtColor = value
			End Set
		End Property

		' Token: 0x170004B1 RID: 1201
		' (get) Token: 0x06000CFD RID: 3325 RVA: 0x00099678 File Offset: 0x00097878
		' (set) Token: 0x06000CFE RID: 3326 RVA: 0x00004257 File Offset: 0x00002457
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170004B2 RID: 1202
		' (get) Token: 0x06000CFF RID: 3327 RVA: 0x00099690 File Offset: 0x00097890
		' (set) Token: 0x06000D00 RID: 3328 RVA: 0x000996A8 File Offset: 0x000978A8
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x170004B3 RID: 1203
		' (get) Token: 0x06000D01 RID: 3329 RVA: 0x00099714 File Offset: 0x00097914
		' (set) Token: 0x06000D02 RID: 3330 RVA: 0x00004261 File Offset: 0x00002461
		Friend Overridable Property txtTenKhu As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTenKhu
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTenKhu = value
			End Set
		End Property

		' Token: 0x170004B4 RID: 1204
		' (get) Token: 0x06000D03 RID: 3331 RVA: 0x0009972C File Offset: 0x0009792C
		' (set) Token: 0x06000D04 RID: 3332 RVA: 0x00099744 File Offset: 0x00097944
		Friend Overridable Property btnMaKhu As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnMaKhu
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnMaKhu IsNot Nothing
				If flag Then
					RemoveHandler Me._btnMaKhu.Click, AddressOf Me.btnMaKhu_Click
				End If
				Me._btnMaKhu = value
				flag = Me._btnMaKhu IsNot Nothing
				If flag Then
					AddHandler Me._btnMaKhu.Click, AddressOf Me.btnMaKhu_Click
				End If
			End Set
		End Property

		' Token: 0x170004B5 RID: 1205
		' (get) Token: 0x06000D05 RID: 3333 RVA: 0x000997B0 File Offset: 0x000979B0
		' (set) Token: 0x06000D06 RID: 3334 RVA: 0x000997C8 File Offset: 0x000979C8
		Friend Overridable Property txtMAKHU As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKHU IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKHU.KeyPress, AddressOf Me.txtMAKHU_KeyPress
					RemoveHandler Me._txtMAKHU.TextChanged, AddressOf Me.txtMAKHU_TextChanged
				End If
				Me._txtMAKHU = value
				flag = Me._txtMAKHU IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKHU.KeyPress, AddressOf Me.txtMAKHU_KeyPress
					AddHandler Me._txtMAKHU.TextChanged, AddressOf Me.txtMAKHU_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170004B6 RID: 1206
		' (get) Token: 0x06000D07 RID: 3335 RVA: 0x00099864 File Offset: 0x00097A64
		' (set) Token: 0x06000D08 RID: 3336 RVA: 0x0000426B File Offset: 0x0000246B
		Friend Overridable Property lblVATCODE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblVATCODE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblVATCODE = value
			End Set
		End Property

		' Token: 0x170004B7 RID: 1207
		' (get) Token: 0x06000D09 RID: 3337 RVA: 0x0009987C File Offset: 0x00097A7C
		' (set) Token: 0x06000D0A RID: 3338 RVA: 0x00004275 File Offset: 0x00002475
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x170004B8 RID: 1208
		' (get) Token: 0x06000D0B RID: 3339 RVA: 0x00099894 File Offset: 0x00097A94
		' (set) Token: 0x06000D0C RID: 3340 RVA: 0x000998AC File Offset: 0x00097AAC
		Friend Overridable Property txtMaKhu2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMaKhu2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMaKhu2 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMaKhu2.KeyPress, AddressOf Me.txtMaKhu2_KeyPress
					RemoveHandler Me._txtMaKhu2.TextChanged, AddressOf Me.txtMAKHU2_TextChanged
				End If
				Me._txtMaKhu2 = value
				flag = Me._txtMaKhu2 IsNot Nothing
				If flag Then
					AddHandler Me._txtMaKhu2.KeyPress, AddressOf Me.txtMaKhu2_KeyPress
					AddHandler Me._txtMaKhu2.TextChanged, AddressOf Me.txtMAKHU2_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170004B9 RID: 1209
		' (get) Token: 0x06000D0D RID: 3341 RVA: 0x00099948 File Offset: 0x00097B48
		' (set) Token: 0x06000D0E RID: 3342 RVA: 0x00099960 File Offset: 0x00097B60
		Friend Overridable Property btnMaKhu2 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnMaKhu2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnMaKhu2 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnMaKhu2.Click, AddressOf Me.btnMaKhu2_Click
				End If
				Me._btnMaKhu2 = value
				flag = Me._btnMaKhu2 IsNot Nothing
				If flag Then
					AddHandler Me._btnMaKhu2.Click, AddressOf Me.btnMaKhu2_Click
				End If
			End Set
		End Property

		' Token: 0x170004BA RID: 1210
		' (get) Token: 0x06000D0F RID: 3343 RVA: 0x000999CC File Offset: 0x00097BCC
		' (set) Token: 0x06000D10 RID: 3344 RVA: 0x0000427F File Offset: 0x0000247F
		Friend Overridable Property txtTenKhu2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTenKhu2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTenKhu2 = value
			End Set
		End Property

		' Token: 0x170004BB RID: 1211
		' (get) Token: 0x06000D11 RID: 3345 RVA: 0x000999E4 File Offset: 0x00097BE4
		' (set) Token: 0x06000D12 RID: 3346 RVA: 0x000999FC File Offset: 0x00097BFC
		Friend Overridable Property txtRemark As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtRemark
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtRemark IsNot Nothing
				If flag Then
					RemoveHandler Me._txtRemark.KeyPress, AddressOf Me.txtRemark_KeyPress
					RemoveHandler Me._txtRemark.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
				End If
				Me._txtRemark = value
				flag = Me._txtRemark IsNot Nothing
				If flag Then
					AddHandler Me._txtRemark.KeyPress, AddressOf Me.txtRemark_KeyPress
					AddHandler Me._txtRemark.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170004BC RID: 1212
		' (get) Token: 0x06000D13 RID: 3347 RVA: 0x00099A98 File Offset: 0x00097C98
		' (set) Token: 0x06000D14 RID: 3348 RVA: 0x00004289 File Offset: 0x00002489
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x170004BD RID: 1213
		' (get) Token: 0x06000D15 RID: 3349 RVA: 0x00099AB0 File Offset: 0x00097CB0
		' (set) Token: 0x06000D16 RID: 3350 RVA: 0x00099AC8 File Offset: 0x00097CC8
		Friend Overridable Property txtRoomCode As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtRoomCode
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtRoomCode IsNot Nothing
				If flag Then
					RemoveHandler Me._txtRoomCode.KeyPress, AddressOf Me.txtRemark_KeyPress
					RemoveHandler Me._txtRoomCode.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
				End If
				Me._txtRoomCode = value
				flag = Me._txtRoomCode IsNot Nothing
				If flag Then
					AddHandler Me._txtRoomCode.KeyPress, AddressOf Me.txtRemark_KeyPress
					AddHandler Me._txtRoomCode.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170004BE RID: 1214
		' (get) Token: 0x06000D17 RID: 3351 RVA: 0x00099B64 File Offset: 0x00097D64
		' (set) Token: 0x06000D18 RID: 3352 RVA: 0x00004293 File Offset: 0x00002493
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x170004BF RID: 1215
		' (get) Token: 0x06000D19 RID: 3353 RVA: 0x00099B7C File Offset: 0x00097D7C
		' (set) Token: 0x06000D1A RID: 3354 RVA: 0x0000429D File Offset: 0x0000249D
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x170004C0 RID: 1216
		' (get) Token: 0x06000D1B RID: 3355 RVA: 0x00099B94 File Offset: 0x00097D94
		' (set) Token: 0x06000D1C RID: 3356 RVA: 0x000042A8 File Offset: 0x000024A8
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x170004C1 RID: 1217
		' (get) Token: 0x06000D1D RID: 3357 RVA: 0x00099BAC File Offset: 0x00097DAC
		' (set) Token: 0x06000D1E RID: 3358 RVA: 0x000042B3 File Offset: 0x000024B3
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06000D1F RID: 3359 RVA: 0x00099BC4 File Offset: 0x00097DC4
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMAKHU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000D20 RID: 3360 RVA: 0x00099C68 File Offset: 0x00097E68
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D21 RID: 3361 RVA: 0x00099D14 File Offset: 0x00097F14
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.btnExit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D22 RID: 3362 RVA: 0x00099DC0 File Offset: 0x00097FC0
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000D23 RID: 3363 RVA: 0x00099E68 File Offset: 0x00098068
		Private Sub frmDMLN2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
				Me.txtMAKHU_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtMAKHU2_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLN2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D24 RID: 3364 RVA: 0x00099F30 File Offset: 0x00098130
		Private Sub frmDMLN2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMKhu()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLN2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D25 RID: 3365 RVA: 0x00099FF0 File Offset: 0x000981F0
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = Operators.CompareString(Strings.Trim(Me.txtMAKHU.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKHU.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.txtMAKHU.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTenKhu.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
								Me.txtMAKHU.Focus()
							Else
								flag = Operators.CompareString(Strings.Trim(Me.txtMaKhu2.Text), "", False) = 0
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
									Me.txtMaKhu2.Focus()
								Else
									flag = (Operators.CompareString(Strings.Trim(Me.txtMaKhu2.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTenKhu2.Text), "", False) = 0)
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(31), MsgBoxStyle.Critical, Nothing)
										Me.txtMaKhu2.Focus()
									Else
										flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
										If Not flag Then
											flag = Me.mbytFormStatus = 3
											If flag Then
												Me.mbytSuccess = Me.fModify()
											End If
										End If
										flag = Me.mbytSuccess = 1
										If flag Then
											Me.Close()
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D26 RID: 3366 RVA: 0x0009A2D0 File Offset: 0x000984D0
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D27 RID: 3367 RVA: 0x0009A368 File Offset: 0x00098568
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D28 RID: 3368 RVA: 0x0009A504 File Offset: 0x00098704
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D29 RID: 3369 RVA: 0x0009A6A0 File Offset: 0x000988A0
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.BackColor = Me.txtColor.BackColor
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000D2A RID: 3370 RVA: 0x0009A7D0 File Offset: 0x000989D0
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000D2B RID: 3371 RVA: 0x0009A960 File Offset: 0x00098B60
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 10
				Me.txtOBJNAME.MaxLength = 50
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000D2C RID: 3372 RVA: 0x0009AA34 File Offset: 0x00098C34
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2020000000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000D2D RID: 3373 RVA: 0x0009AC18 File Offset: 0x00098E18
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D2E RID: 3374 RVA: 0x0009ACB8 File Offset: 0x00098EB8
		Private Function fGetData_DMKhu() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKHU = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKHU")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMKhu ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000D2F RID: 3375 RVA: 0x0009AD64 File Offset: 0x00098F64
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(7) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKHU"
				array(2).Value = Strings.Trim(Me.txtMAKHU.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchMAKHU2"
				array(3).Value = Strings.Trim(Me.txtMaKhu2.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvcREMARK"
				array(4).Value = Strings.Trim(Me.txtRemark.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnchROOMCODE"
				array(6).Value = Strings.Trim(Me.txtRoomCode.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@int_Result"
				array(5).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMBAN_UPDATE_DMBAN", flag)
				Dim num As Integer = Conversions.ToInteger(array(5).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fModify ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000D30 RID: 3376 RVA: 0x0009B024 File Offset: 0x00099224
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x06000D31 RID: 3377 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x06000D32 RID: 3378 RVA: 0x0009B0A0 File Offset: 0x000992A0
		Private Sub txtRemark_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim flag2 As Boolean = Me.mbytFormStatus = 5
					If flag2 Then
						Me.btnFilter.Focus()
					Else
						flag2 = Me.mbytFormStatus = 6
						If flag2 Then
							Me.btnFind.Focus()
						Else
							Me.btnSave.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtRemark_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000D33 RID: 3379 RVA: 0x0009B17C File Offset: 0x0009937C
		Private Sub txtMAKHU_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMaKhu2.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHU_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000D34 RID: 3380 RVA: 0x0009B220 File Offset: 0x00099420
		Private Sub txtMaKhu2_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtRemark.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMaKhu2_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000D35 RID: 3381 RVA: 0x0009B2C4 File Offset: 0x000994C4
		Private Sub txtMAKHU_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKHU Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMKHU.Columns("OBJID")
					Me.mclsTbDMKHU.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKHU.Rows.Find(Strings.Trim(Me.txtMAKHU.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTenKhu.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTenKhu.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHU_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D36 RID: 3382 RVA: 0x0009B418 File Offset: 0x00099618
		Private Sub txtMAKHU2_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKHU Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMKHU.Columns("OBJID")
					Me.mclsTbDMKHU.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKHU.Rows.Find(Strings.Trim(Me.txtMaKhu2.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTenKhu2.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTenKhu2.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHU2_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D37 RID: 3383 RVA: 0x0009B56C File Offset: 0x0009976C
		Private Sub btnMaKhu_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKHU As frmDMKHU1 = New frmDMKHU1()
				frmDMKHU.pBytOpen_From_Menu = 7
				frmDMKHU.ShowDialog()
				Me.txtMAKHU.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKHU.pStrOBJID, "", False) = 0, Me.txtMAKHU.Text, frmDMKHU.pStrOBJID))
				Me.txtTenKhu.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKHU.pStrOBJNAME, "", False) = 0, Me.txtTenKhu.Text, frmDMKHU.pStrOBJNAME))
				frmDMKHU.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnMaKhu_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D38 RID: 3384 RVA: 0x0009B690 File Offset: 0x00099890
		Private Sub btnMaKhu2_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKHU As frmDMKHU1 = New frmDMKHU1()
				frmDMKHU.pBytOpen_From_Menu = 7
				frmDMKHU.ShowDialog()
				Me.txtMaKhu2.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKHU.pStrOBJID, "", False) = 0, Me.txtMaKhu2.Text, frmDMKHU.pStrOBJID))
				Me.txtTenKhu2.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKHU.pStrOBJNAME, "", False) = 0, Me.txtTenKhu2.Text, frmDMKHU.pStrOBJNAME))
				frmDMKHU.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnMaKhu2_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0400058F RID: 1423
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000591 RID: 1425
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000592 RID: 1426
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000593 RID: 1427
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000594 RID: 1428
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000595 RID: 1429
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000596 RID: 1430
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000597 RID: 1431
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000598 RID: 1432
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000599 RID: 1433
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x0400059A RID: 1434
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x0400059B RID: 1435
		<AccessedThroughProperty("txtColor")>
		Private _txtColor As TextBox

		' Token: 0x0400059C RID: 1436
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x0400059D RID: 1437
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x0400059E RID: 1438
		<AccessedThroughProperty("txtTenKhu")>
		Private _txtTenKhu As TextBox

		' Token: 0x0400059F RID: 1439
		<AccessedThroughProperty("btnMaKhu")>
		Private _btnMaKhu As Button

		' Token: 0x040005A0 RID: 1440
		<AccessedThroughProperty("txtMAKHU")>
		Private _txtMAKHU As TextBox

		' Token: 0x040005A1 RID: 1441
		<AccessedThroughProperty("lblVATCODE")>
		Private _lblVATCODE As Label

		' Token: 0x040005A2 RID: 1442
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x040005A3 RID: 1443
		<AccessedThroughProperty("txtMaKhu2")>
		Private _txtMaKhu2 As TextBox

		' Token: 0x040005A4 RID: 1444
		<AccessedThroughProperty("btnMaKhu2")>
		Private _btnMaKhu2 As Button

		' Token: 0x040005A5 RID: 1445
		<AccessedThroughProperty("txtTenKhu2")>
		Private _txtTenKhu2 As TextBox

		' Token: 0x040005A6 RID: 1446
		<AccessedThroughProperty("txtRemark")>
		Private _txtRemark As TextBox

		' Token: 0x040005A7 RID: 1447
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x040005A8 RID: 1448
		<AccessedThroughProperty("txtRoomCode")>
		Private _txtRoomCode As TextBox

		' Token: 0x040005A9 RID: 1449
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x040005AA RID: 1450
		Private mArrStrFrmMess As String()

		' Token: 0x040005AB RID: 1451
		Private mbytFormStatus As Byte

		' Token: 0x040005AC RID: 1452
		Private mbytSuccess As Byte

		' Token: 0x040005AD RID: 1453
		Private mStrFilter As String

		' Token: 0x040005AE RID: 1454
		Private mclsTbDMKHU As clsConnect
	End Class
End Namespace
