﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports HotelReaderLib
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices

Namespace prjIS_SalesPOS
	' Token: 0x0200001E RID: 30
	<DesignerGenerated()>
	Friend Partial Class frmCard
		Inherits Form

		' Token: 0x060004B0 RID: 1200 RVA: 0x00002C9E File Offset: 0x00000E9E
		<DebuggerNonUserCode()>
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmCard_Load
			frmCard.__ENCList.Add(New WeakReference(Me))
			Me.InitializeComponent()
		End Sub

		' Token: 0x170001C5 RID: 453
		' (get) Token: 0x060004B2 RID: 1202 RVA: 0x000387EC File Offset: 0x000369EC
		' (set) Token: 0x060004B3 RID: 1203 RVA: 0x00038804 File Offset: 0x00036A04
		Public Overridable Property btnForceCancel As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnForceCancel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnForceCancel IsNot Nothing
				If flag Then
					RemoveHandler Me._btnForceCancel.Click, AddressOf Me.Command2_Click
				End If
				Me._btnForceCancel = value
				flag = Me._btnForceCancel IsNot Nothing
				If flag Then
					AddHandler Me._btnForceCancel.Click, AddressOf Me.Command2_Click
				End If
			End Set
		End Property

		' Token: 0x170001C6 RID: 454
		' (get) Token: 0x060004B4 RID: 1204 RVA: 0x00038870 File Offset: 0x00036A70
		' (set) Token: 0x060004B5 RID: 1205 RVA: 0x00002CD5 File Offset: 0x00000ED5
		Public Overridable Property ProgressBar1 As ProgressBar
			<DebuggerNonUserCode()>
			Get
				Return Me._ProgressBar1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ProgressBar)
				Me._ProgressBar1 = value
			End Set
		End Property

		' Token: 0x170001C7 RID: 455
		' (get) Token: 0x060004B6 RID: 1206 RVA: 0x00038888 File Offset: 0x00036A88
		' (set) Token: 0x060004B7 RID: 1207 RVA: 0x00002CDF File Offset: 0x00000EDF
		Public Overridable Property cboCardType As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cboCardType
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Me._cboCardType = value
			End Set
		End Property

		' Token: 0x170001C8 RID: 456
		' (get) Token: 0x060004B8 RID: 1208 RVA: 0x000388A0 File Offset: 0x00036AA0
		' (set) Token: 0x060004B9 RID: 1209 RVA: 0x00002CE9 File Offset: 0x00000EE9
		Public Overridable Property txtSubRoom As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtSubRoom
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtSubRoom = value
			End Set
		End Property

		' Token: 0x170001C9 RID: 457
		' (get) Token: 0x060004BA RID: 1210 RVA: 0x000388B8 File Offset: 0x00036AB8
		' (set) Token: 0x060004BB RID: 1211 RVA: 0x00002CF3 File Offset: 0x00000EF3
		Public Overridable Property txtCardAuthCode As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCardAuthCode
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtCardAuthCode = value
			End Set
		End Property

		' Token: 0x170001CA RID: 458
		' (get) Token: 0x060004BC RID: 1212 RVA: 0x000388D0 File Offset: 0x00036AD0
		' (set) Token: 0x060004BD RID: 1213 RVA: 0x00002CFD File Offset: 0x00000EFD
		Public Overridable Property txtCardSnr As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCardSnr
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtCardSnr = value
			End Set
		End Property

		' Token: 0x170001CB RID: 459
		' (get) Token: 0x060004BE RID: 1214 RVA: 0x000388E8 File Offset: 0x00036AE8
		' (set) Token: 0x060004BF RID: 1215 RVA: 0x00002D07 File Offset: 0x00000F07
		Public Overridable Property txtHotelCode As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtHotelCode
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtHotelCode = value
			End Set
		End Property

		' Token: 0x170001CC RID: 460
		' (get) Token: 0x060004C0 RID: 1216 RVA: 0x00038900 File Offset: 0x00036B00
		' (set) Token: 0x060004C1 RID: 1217 RVA: 0x00002D11 File Offset: 0x00000F11
		Public Overridable Property txtCleaning As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCleaning
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtCleaning = value
			End Set
		End Property

		' Token: 0x170001CD RID: 461
		' (get) Token: 0x060004C2 RID: 1218 RVA: 0x00038918 File Offset: 0x00036B18
		' (set) Token: 0x060004C3 RID: 1219 RVA: 0x00002D1B File Offset: 0x00000F1B
		Public Overridable Property txtRoom As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtRoom
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtRoom = value
			End Set
		End Property

		' Token: 0x170001CE RID: 462
		' (get) Token: 0x060004C4 RID: 1220 RVA: 0x00038930 File Offset: 0x00036B30
		' (set) Token: 0x060004C5 RID: 1221 RVA: 0x00002D25 File Offset: 0x00000F25
		Public Overridable Property txtFloor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtFloor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtFloor = value
			End Set
		End Property

		' Token: 0x170001CF RID: 463
		' (get) Token: 0x060004C6 RID: 1222 RVA: 0x00038948 File Offset: 0x00036B48
		' (set) Token: 0x060004C7 RID: 1223 RVA: 0x00002D2F File Offset: 0x00000F2F
		Public Overridable Property txtBuilding As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBuilding
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtBuilding = value
			End Set
		End Property

		' Token: 0x170001D0 RID: 464
		' (get) Token: 0x060004C8 RID: 1224 RVA: 0x00038960 File Offset: 0x00036B60
		' (set) Token: 0x060004C9 RID: 1225 RVA: 0x00002D39 File Offset: 0x00000F39
		Public Overridable Property txtExpireDate As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtExpireDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtExpireDate = value
			End Set
		End Property

		' Token: 0x170001D1 RID: 465
		' (get) Token: 0x060004CA RID: 1226 RVA: 0x00038978 File Offset: 0x00036B78
		' (set) Token: 0x060004CB RID: 1227 RVA: 0x00002D43 File Offset: 0x00000F43
		Public Overridable Property txtCardKey As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCardKey
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtCardKey = value
			End Set
		End Property

		' Token: 0x170001D2 RID: 466
		' (get) Token: 0x060004CC RID: 1228 RVA: 0x00038990 File Offset: 0x00036B90
		' (set) Token: 0x060004CD RID: 1229 RVA: 0x00002D4D File Offset: 0x00000F4D
		Public Overridable Property txtStartDate As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtStartDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtStartDate = value
			End Set
		End Property

		' Token: 0x170001D3 RID: 467
		' (get) Token: 0x060004CE RID: 1230 RVA: 0x000389A8 File Offset: 0x00036BA8
		' (set) Token: 0x060004CF RID: 1231 RVA: 0x00002D57 File Offset: 0x00000F57
		Public Overridable Property Label15 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label15
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label15 = value
			End Set
		End Property

		' Token: 0x170001D4 RID: 468
		' (get) Token: 0x060004D0 RID: 1232 RVA: 0x000389C0 File Offset: 0x00036BC0
		' (set) Token: 0x060004D1 RID: 1233 RVA: 0x00002D61 File Offset: 0x00000F61
		Public Overridable Property Label10 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label10 = value
			End Set
		End Property

		' Token: 0x170001D5 RID: 469
		' (get) Token: 0x060004D2 RID: 1234 RVA: 0x000389D8 File Offset: 0x00036BD8
		' (set) Token: 0x060004D3 RID: 1235 RVA: 0x00002D6B File Offset: 0x00000F6B
		Public Overridable Property Label9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label9 = value
			End Set
		End Property

		' Token: 0x170001D6 RID: 470
		' (get) Token: 0x060004D4 RID: 1236 RVA: 0x000389F0 File Offset: 0x00036BF0
		' (set) Token: 0x060004D5 RID: 1237 RVA: 0x00002D75 File Offset: 0x00000F75
		Public Overridable Property Label8 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label8 = value
			End Set
		End Property

		' Token: 0x170001D7 RID: 471
		' (get) Token: 0x060004D6 RID: 1238 RVA: 0x00038A08 File Offset: 0x00036C08
		' (set) Token: 0x060004D7 RID: 1239 RVA: 0x00002D7F File Offset: 0x00000F7F
		Public Overridable Property Label7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		' Token: 0x170001D8 RID: 472
		' (get) Token: 0x060004D8 RID: 1240 RVA: 0x00038A20 File Offset: 0x00036C20
		' (set) Token: 0x060004D9 RID: 1241 RVA: 0x00002D89 File Offset: 0x00000F89
		Public Overridable Property Label6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label6 = value
			End Set
		End Property

		' Token: 0x170001D9 RID: 473
		' (get) Token: 0x060004DA RID: 1242 RVA: 0x00038A38 File Offset: 0x00036C38
		' (set) Token: 0x060004DB RID: 1243 RVA: 0x00002D93 File Offset: 0x00000F93
		Public Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x170001DA RID: 474
		' (get) Token: 0x060004DC RID: 1244 RVA: 0x00038A50 File Offset: 0x00036C50
		' (set) Token: 0x060004DD RID: 1245 RVA: 0x00002D9D File Offset: 0x00000F9D
		Public Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x170001DB RID: 475
		' (get) Token: 0x060004DE RID: 1246 RVA: 0x00038A68 File Offset: 0x00036C68
		' (set) Token: 0x060004DF RID: 1247 RVA: 0x00002DA7 File Offset: 0x00000FA7
		Public Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x170001DC RID: 476
		' (get) Token: 0x060004E0 RID: 1248 RVA: 0x00038A80 File Offset: 0x00036C80
		' (set) Token: 0x060004E1 RID: 1249 RVA: 0x00002DB1 File Offset: 0x00000FB1
		Public Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x170001DD RID: 477
		' (get) Token: 0x060004E2 RID: 1250 RVA: 0x00038A98 File Offset: 0x00036C98
		' (set) Token: 0x060004E3 RID: 1251 RVA: 0x00002DBB File Offset: 0x00000FBB
		Public Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x170001DE RID: 478
		' (get) Token: 0x060004E4 RID: 1252 RVA: 0x00038AB0 File Offset: 0x00036CB0
		' (set) Token: 0x060004E5 RID: 1253 RVA: 0x00002DC5 File Offset: 0x00000FC5
		Public Overridable Property Frame2 As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._Frame2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._Frame2 = value
			End Set
		End Property

		' Token: 0x170001DF RID: 479
		' (get) Token: 0x060004E6 RID: 1254 RVA: 0x00038AC8 File Offset: 0x00036CC8
		' (set) Token: 0x060004E7 RID: 1255 RVA: 0x00038AE0 File Offset: 0x00036CE0
		Public Overridable Property btnReadAuth As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnReadAuth
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnReadAuth IsNot Nothing
				If flag Then
					RemoveHandler Me._btnReadAuth.Click, AddressOf Me.ReadAuth_Click
				End If
				Me._btnReadAuth = value
				flag = Me._btnReadAuth IsNot Nothing
				If flag Then
					AddHandler Me._btnReadAuth.Click, AddressOf Me.ReadAuth_Click
				End If
			End Set
		End Property

		' Token: 0x170001E0 RID: 480
		' (get) Token: 0x060004E8 RID: 1256 RVA: 0x00038B4C File Offset: 0x00036D4C
		' (set) Token: 0x060004E9 RID: 1257 RVA: 0x00038B64 File Offset: 0x00036D64
		Public Overridable Property btnCheckLink As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCheckLink
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCheckLink IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCheckLink.Click, AddressOf Me.CheckLink_Click
				End If
				Me._btnCheckLink = value
				flag = Me._btnCheckLink IsNot Nothing
				If flag Then
					AddHandler Me._btnCheckLink.Click, AddressOf Me.CheckLink_Click
				End If
			End Set
		End Property

		' Token: 0x170001E1 RID: 481
		' (get) Token: 0x060004EA RID: 1258 RVA: 0x00038BD0 File Offset: 0x00036DD0
		' (set) Token: 0x060004EB RID: 1259 RVA: 0x00038BE8 File Offset: 0x00036DE8
		Public Overridable Property btnCheckCard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCheckCard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCheckCard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCheckCard.Click, AddressOf Me.CheckCard_Click
				End If
				Me._btnCheckCard = value
				flag = Me._btnCheckCard IsNot Nothing
				If flag Then
					AddHandler Me._btnCheckCard.Click, AddressOf Me.CheckCard_Click
				End If
			End Set
		End Property

		' Token: 0x170001E2 RID: 482
		' (get) Token: 0x060004EC RID: 1260 RVA: 0x00038C54 File Offset: 0x00036E54
		' (set) Token: 0x060004ED RID: 1261 RVA: 0x00038C6C File Offset: 0x00036E6C
		Public Overridable Property btnGetNewAuth As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnGetNewAuth
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnGetNewAuth IsNot Nothing
				If flag Then
					RemoveHandler Me._btnGetNewAuth.Click, AddressOf Me.GetNewAuth_Click
				End If
				Me._btnGetNewAuth = value
				flag = Me._btnGetNewAuth IsNot Nothing
				If flag Then
					AddHandler Me._btnGetNewAuth.Click, AddressOf Me.GetNewAuth_Click
				End If
			End Set
		End Property

		' Token: 0x170001E3 RID: 483
		' (get) Token: 0x060004EE RID: 1262 RVA: 0x00038CD8 File Offset: 0x00036ED8
		' (set) Token: 0x060004EF RID: 1263 RVA: 0x00038CF0 File Offset: 0x00036EF0
		Public Overridable Property btnCancelCard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelCard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelCard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelCard.Click, AddressOf Me.CancelCard_Click
				End If
				Me._btnCancelCard = value
				flag = Me._btnCancelCard IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelCard.Click, AddressOf Me.CancelCard_Click
				End If
			End Set
		End Property

		' Token: 0x170001E4 RID: 484
		' (get) Token: 0x060004F0 RID: 1264 RVA: 0x00038D5C File Offset: 0x00036F5C
		' (set) Token: 0x060004F1 RID: 1265 RVA: 0x00038D74 File Offset: 0x00036F74
		Public Overridable Property btnIssueCard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnIssueCard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnIssueCard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnIssueCard.Click, AddressOf Me.IssueCard_Click
				End If
				Me._btnIssueCard = value
				flag = Me._btnIssueCard IsNot Nothing
				If flag Then
					AddHandler Me._btnIssueCard.Click, AddressOf Me.IssueCard_Click
				End If
			End Set
		End Property

		' Token: 0x170001E5 RID: 485
		' (get) Token: 0x060004F2 RID: 1266 RVA: 0x00038DE0 File Offset: 0x00036FE0
		' (set) Token: 0x060004F3 RID: 1267 RVA: 0x00038DF8 File Offset: 0x00036FF8
		Public Overridable Property btnReadCard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnReadCard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnReadCard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnReadCard.Click, AddressOf Me.ReadCard_Click
				End If
				Me._btnReadCard = value
				flag = Me._btnReadCard IsNot Nothing
				If flag Then
					AddHandler Me._btnReadCard.Click, AddressOf Me.ReadCard_Click
				End If
			End Set
		End Property

		' Token: 0x170001E6 RID: 486
		' (get) Token: 0x060004F4 RID: 1268 RVA: 0x00038E64 File Offset: 0x00037064
		' (set) Token: 0x060004F5 RID: 1269 RVA: 0x00002DCF File Offset: 0x00000FCF
		Public Overridable Property Label16 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label16
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label16 = value
			End Set
		End Property

		' Token: 0x170001E7 RID: 487
		' (get) Token: 0x060004F7 RID: 1271 RVA: 0x0003B084 File Offset: 0x00039284
		' (set) Token: 0x060004F8 RID: 1272 RVA: 0x00002DD9 File Offset: 0x00000FD9
		Friend Overridable Property cboLockType As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cboLockType
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Me._cboLockType = value
			End Set
		End Property

		' Token: 0x170001E8 RID: 488
		' (get) Token: 0x060004F9 RID: 1273 RVA: 0x0003B09C File Offset: 0x0003929C
		' (set) Token: 0x060004FA RID: 1274 RVA: 0x0003B0B4 File Offset: 0x000392B4
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170001E9 RID: 489
		' (get) Token: 0x060004FB RID: 1275 RVA: 0x0003B120 File Offset: 0x00039320
		' (set) Token: 0x060004FC RID: 1276 RVA: 0x0003B138 File Offset: 0x00039338
		Private Overridable Property XCard As Card
			<DebuggerNonUserCode()>
			Get
				Return Me._XCard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Card)
				Dim flag As Boolean = Me._XCard IsNot Nothing
				If flag Then
					RemoveHandler Me._XCard.ReadProgress, AddressOf Me.XCard_ReadProgress
				End If
				Me._XCard = value
				flag = Me._XCard IsNot Nothing
				If flag Then
					AddHandler Me._XCard.ReadProgress, AddressOf Me.XCard_ReadProgress
				End If
			End Set
		End Property

		' Token: 0x060004FD RID: 1277 RVA: 0x0003B1A4 File Offset: 0x000393A4
		Private Function GetAuthStr(ByRef xobj As Card) As String
			Return Me.txtCardAuthCode.Text
		End Function

		' Token: 0x060004FE RID: 1278 RVA: 0x0003B1C0 File Offset: 0x000393C0
		Private Sub Command2_Click(eventSender As Object, eventArgs As EventArgs)
			Dim num As Integer
			Dim num2 As Integer
			Dim obj As Object
			Try
				Dim card As Card = New CardClass()
				ProjectData.ClearProjectError()
				num = 2
				card.LockType = CType(Me.cboLockType.SelectedIndex, CLockType)
				card.AuthorizationCode = Me.GetAuthStr(card)
				card.LockSubType = 0S
				card.ToCollector = False
				card.MandatoryCancel = True
				card.CancelCard()
				card = Nothing
				GoTo IL_00AF
				IL_0054:
				card = Nothing
				Interaction.MsgBox(Conversion.ErrorToString(), MsgBoxStyle.OkOnly, Nothing)
				GoTo IL_00AF
				IL_006C:
				num2 = -1
				switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num)
				IL_0080:
			Catch obj2 When endfilter((TypeOf obj Is Exception) And (num <> 0) And (num2 = 0))
				Dim ex As Exception = CType(obj2, Exception)
				GoTo IL_006C
			End Try
			Throw ProjectData.CreateProjectError(-2146828237)
			IL_00AF:
			If num2 <> 0 Then
				ProjectData.ClearProjectError()
			End If
		End Sub

		' Token: 0x060004FF RID: 1279 RVA: 0x0003B298 File Offset: 0x00039498
		Private Sub frmCard_Load(eventSender As Object, eventArgs As EventArgs)
			Me.cboLockType.SelectedIndex = 4
			Me.cboCardType.SelectedIndex = 10
			Me.txtCardKey.Text = Conversions.ToString(DateAndTime.Now)
			Me.txtStartDate.Text = Conversions.ToString(DateAndTime.Now)
			Me.txtExpireDate.Text = Conversions.ToString(DateTime.FromOADate(DateAndTime.Now.ToOADate() + 1.0))
		End Sub

		' Token: 0x06000500 RID: 1280 RVA: 0x0003B31C File Offset: 0x0003951C
		Private Sub ReadAuth_Click(eventSender As Object, eventArgs As EventArgs)
			Dim num As Integer
			Dim num2 As Integer
			Dim obj As Object
			Try
				ProjectData.ClearProjectError()
				num = 2
				Dim card As Card = New CardClass()
				card.LockType = CType(Me.cboLockType.SelectedIndex, CLockType)
				card.LockSubType = 0S
				Me.txtCardAuthCode.Text = card.CardAuthCode
				GoTo IL_009B
				IL_0040:
				Interaction.MsgBox(Conversion.ErrorToString(), MsgBoxStyle.OkOnly, Nothing)
				GoTo IL_009B
				IL_0058:
				num2 = -1
				switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num)
				IL_006C:
			Catch obj2 When endfilter((TypeOf obj Is Exception) And (num <> 0) And (num2 = 0))
				Dim ex As Exception = CType(obj2, Exception)
				GoTo IL_0058
			End Try
			Throw ProjectData.CreateProjectError(-2146828237)
			IL_009B:
			If num2 <> 0 Then
				ProjectData.ClearProjectError()
			End If
		End Sub

		' Token: 0x06000501 RID: 1281 RVA: 0x0003B3E0 File Offset: 0x000395E0
		Private Sub IssueCard_Click(eventSender As Object, eventArgs As EventArgs)
			Dim num As Integer
			Dim num2 As Integer
			Dim obj As Object
			Try
				Dim card As Card = New CardClass()
				ProjectData.ClearProjectError()
				num = 2
				card.LockType = CType(Me.cboLockType.SelectedIndex, CLockType)
				card.CardType = Me.cboCardType.SelectedIndex + CCardType.AuthCard
				card.LockSubType = 0S
				card.AuthorizationCode = Me.GetAuthStr(card)
				card.ToCollector = False
				card.Building = Conversions.ToByte(Me.txtBuilding.Text)
				card.Floor = Conversions.ToByte(Me.txtFloor.Text)
				card.Room = Conversions.ToByte(Me.txtRoom.Text)
				card.Cleaning = Conversions.ToByte(Me.txtCleaning.Text)
				card.SubRoom = Conversions.ToByte(Me.txtSubRoom.Text)
				card.CardKey = Conversions.ToDate(Me.txtCardKey.Text)
				card.StartDate = Conversions.ToDate(Me.txtStartDate.Text)
				card.ExpireDate = Conversions.ToDate(Me.txtExpireDate.Text)
				card.IssueCard()
				card = Nothing
				GoTo IL_0173
				IL_0118:
				card = Nothing
				Interaction.MsgBox(Conversion.ErrorToString(), MsgBoxStyle.OkOnly, Nothing)
				GoTo IL_0173
				IL_0130:
				num2 = -1
				switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num)
				IL_0144:
			Catch obj2 When endfilter((TypeOf obj Is Exception) And (num <> 0) And (num2 = 0))
				Dim ex As Exception = CType(obj2, Exception)
				GoTo IL_0130
			End Try
			Throw ProjectData.CreateProjectError(-2146828237)
			IL_0173:
			If num2 <> 0 Then
				ProjectData.ClearProjectError()
			End If
		End Sub

		' Token: 0x06000502 RID: 1282 RVA: 0x0003B588 File Offset: 0x00039788
		Private Sub CancelCard_Click(eventSender As Object, eventArgs As EventArgs)
			Dim num As Integer
			Dim num2 As Integer
			Dim obj As Object
			Try
				Dim card As Card = New CardClass()
				ProjectData.ClearProjectError()
				num = 2
				card.LockType = CType(Me.cboLockType.SelectedIndex, CLockType)
				card.AuthorizationCode = Me.GetAuthStr(card)
				card.LockSubType = 0S
				card.ToCollector = False
				card.CancelCard()
				card = Nothing
				GoTo IL_00A7
				IL_004C:
				card = Nothing
				Interaction.MsgBox(Conversion.ErrorToString(), MsgBoxStyle.OkOnly, Nothing)
				GoTo IL_00A7
				IL_0064:
				num2 = -1
				switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num)
				IL_0078:
			Catch obj2 When endfilter((TypeOf obj Is Exception) And (num <> 0) And (num2 = 0))
				Dim ex As Exception = CType(obj2, Exception)
				GoTo IL_0064
			End Try
			Throw ProjectData.CreateProjectError(-2146828237)
			IL_00A7:
			If num2 <> 0 Then
				ProjectData.ClearProjectError()
			End If
		End Sub

		' Token: 0x06000503 RID: 1283 RVA: 0x0003B658 File Offset: 0x00039858
		Private Sub GetNewAuth_Click(eventSender As Object, eventArgs As EventArgs)
			Dim num As Integer
			Dim num2 As Integer
			Dim obj As Object
			Try
				Dim card As Card = New CardClass()
				ProjectData.ClearProjectError()
				num = 2
				card.LockType = CType(Me.cboLockType.SelectedIndex, CLockType)
				card.LockSubType = 0S
				Me.txtCardAuthCode.Text = card.NewAuthorizationCode
				card.AuthorizationCode = Me.txtCardAuthCode.Text
				GoTo IL_00AD
				IL_0052:
				Interaction.MsgBox(Conversion.ErrorToString(), MsgBoxStyle.OkOnly, Nothing)
				GoTo IL_00AD
				IL_006A:
				num2 = -1
				switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num)
				IL_007E:
			Catch obj2 When endfilter((TypeOf obj Is Exception) And (num <> 0) And (num2 = 0))
				Dim ex As Exception = CType(obj2, Exception)
				GoTo IL_006A
			End Try
			Throw ProjectData.CreateProjectError(-2146828237)
			IL_00AD:
			If num2 <> 0 Then
				ProjectData.ClearProjectError()
			End If
		End Sub

		' Token: 0x06000504 RID: 1284 RVA: 0x0003B72C File Offset: 0x0003992C
		Private Sub CheckCard_Click(eventSender As Object, eventArgs As EventArgs)
			Dim num As Integer
			Dim num2 As Integer
			Dim obj As Object
			Try
				ProjectData.ClearProjectError()
				num = 2
				Dim cardExists As Boolean = CType(New CardClass() With { .LockType = CType(Me.cboLockType.SelectedIndex, CLockType), .LockSubType = 0S }, ICard).CardExists
				If cardExists Then
					Interaction.MsgBox("Card exists", MsgBoxStyle.OkOnly, Nothing)
				Else
					Interaction.MsgBox("No Card present", MsgBoxStyle.OkOnly, Nothing)
				End If
				GoTo IL_00B3
				IL_0058:
				Interaction.MsgBox(Conversion.ErrorToString(), MsgBoxStyle.OkOnly, Nothing)
				GoTo IL_00B3
				IL_0070:
				num2 = -1
				switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num)
				IL_0084:
			Catch obj2 When endfilter((TypeOf obj Is Exception) And (num <> 0) And (num2 = 0))
				Dim ex As Exception = CType(obj2, Exception)
				GoTo IL_0070
			End Try
			Throw ProjectData.CreateProjectError(-2146828237)
			IL_00B3:
			If num2 <> 0 Then
				ProjectData.ClearProjectError()
			End If
		End Sub

		' Token: 0x06000505 RID: 1285 RVA: 0x0003B808 File Offset: 0x00039A08
		Private Sub CheckLink_Click(eventSender As Object, eventArgs As EventArgs)
			Dim num As Integer
			Dim num2 As Integer
			Dim obj As Object
			Try
				ProjectData.ClearProjectError()
				num = 2
				Dim linkOk As Boolean = CType(New CardClass() With { .LockType = CType(Me.cboLockType.SelectedIndex, CLockType), .LockSubType = 0S }, ICard).LinkOk
				If linkOk Then
					Interaction.MsgBox("Link oK", MsgBoxStyle.OkOnly, Nothing)
				End If
				GoTo IL_00A2
				IL_0047:
				Interaction.MsgBox(Conversion.ErrorToString(), MsgBoxStyle.OkOnly, Nothing)
				GoTo IL_00A2
				IL_005F:
				num2 = -1
				switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num)
				IL_0073:
			Catch obj2 When endfilter((TypeOf obj Is Exception) And (num <> 0) And (num2 = 0))
				Dim ex As Exception = CType(obj2, Exception)
				GoTo IL_005F
			End Try
			Throw ProjectData.CreateProjectError(-2146828237)
			IL_00A2:
			If num2 <> 0 Then
				ProjectData.ClearProjectError()
			End If
		End Sub

		' Token: 0x06000506 RID: 1286 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub SerialNumber_Click()
		End Sub

		' Token: 0x06000507 RID: 1287 RVA: 0x0003B8D0 File Offset: 0x00039AD0
		Private Function CardTypeStr(ByRef CardType As CCardType) As Object
			Dim obj As Object
			Select Case CardType
				Case CCardType.AuthCard
					obj = "AuthCard"
				Case CCardType.ClockCard
					obj = "ClockCard"
				Case CCardType.DataCard
					obj = "DataCard"
				Case CCardType.SetCard
					obj = "SetCard"
				Case CCardType.DiableCard
					obj = "DisableCard"
				Case CCardType.CheckoutCard
					obj = "CheckoutCard"
				Case CCardType.EmergencyCard
					obj = "EmergencyCard"
				Case CCardType.ControlCard
					obj = "ControlCard"
				Case CCardType.BuildingCard
					obj = "BuildingCard"
				Case CCardType.FloorCard
					obj = "FloorCard"
				Case CCardType.GuestCard
					obj = "GuestCard"
				Case CCardType.CleaningCard
					obj = "CleaningCard"
				Case CCardType.MaintainCard
					obj = "MaintainCard"
				Case CCardType.MeetingCard
					obj = "MeetingCard"
				Case Else
					obj = "UnkonwCard"
			End Select
			Return obj
		End Function

		' Token: 0x06000508 RID: 1288 RVA: 0x0003B9AC File Offset: 0x00039BAC
		Private Sub ReadCard_Click(eventSender As Object, eventArgs As EventArgs)
			Dim num As Integer
			Dim num2 As Integer
			Dim obj As Object
			Try
				Dim card As Card = New CardClass()
				ProjectData.ClearProjectError()
				num = 2
				card.LockType = CType(Me.cboLockType.SelectedIndex, CLockType)
				card.LockSubType = 0S
				card.ToCollector = False
				card.AuthorizationCode = Me.GetAuthStr(card)
				card.ReadCard()
				Me.cboLockType.SelectedIndex = CInt(card.LockType)
				Me.cboCardType.SelectedIndex = card.CardType - CCardType.AuthCard
				Me.txtCardSnr.Text = Conversions.ToString(card.CardSnr)
				Me.txtCardKey.Text = card.CardKey.ToString("yyyy-MM-dd HH:mm:ss")
				Me.txtStartDate.Text = card.StartDate.ToString("yyyy-MM-dd HH:mm")
				Me.txtExpireDate.Text = card.ExpireDate.ToString("yyyy-MM-dd HH:mm")
				Me.txtBuilding.Text = Conversions.ToString(card.Building)
				Me.txtFloor.Text = Conversions.ToString(card.Floor)
				Me.txtRoom.Text = Conversions.ToString(card.Room)
				Me.txtCleaning.Text = Conversions.ToString(card.Cleaning)
				Me.txtSubRoom.Text = Conversions.ToString(card.SubRoom)
				card = Nothing
				GoTo IL_01B4
				IL_0159:
				card = Nothing
				Interaction.MsgBox(Conversion.ErrorToString(), MsgBoxStyle.OkOnly, Nothing)
				GoTo IL_01B4
				IL_0171:
				num2 = -1
				switch(ICSharpCode.Decompiler.ILAst.ILLabel[], num)
				IL_0185:
			Catch obj2 When endfilter((TypeOf obj Is Exception) And (num <> 0) And (num2 = 0))
				Dim ex As Exception = CType(obj2, Exception)
				GoTo IL_0171
			End Try
			Throw ProjectData.CreateProjectError(-2146828237)
			IL_01B4:
			If num2 <> 0 Then
				ProjectData.ClearProjectError()
			End If
		End Sub

		' Token: 0x06000509 RID: 1289 RVA: 0x00002DE3 File Offset: 0x00000FE3
		Private Sub XCard_ReadProgress(progress As Integer)
			Me.ProgressBar1.Value = progress
		End Sub

		' Token: 0x0600050A RID: 1290 RVA: 0x00002DF4 File Offset: 0x00000FF4
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub

		' Token: 0x04000203 RID: 515
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000206 RID: 518
		<AccessedThroughProperty("btnForceCancel")>
		Private _btnForceCancel As Button

		' Token: 0x04000207 RID: 519
		<AccessedThroughProperty("ProgressBar1")>
		Private _ProgressBar1 As ProgressBar

		' Token: 0x04000208 RID: 520
		<AccessedThroughProperty("cboCardType")>
		Private _cboCardType As ComboBox

		' Token: 0x04000209 RID: 521
		<AccessedThroughProperty("txtSubRoom")>
		Private _txtSubRoom As TextBox

		' Token: 0x0400020A RID: 522
		<AccessedThroughProperty("txtCardAuthCode")>
		Private _txtCardAuthCode As TextBox

		' Token: 0x0400020B RID: 523
		<AccessedThroughProperty("txtCardSnr")>
		Private _txtCardSnr As TextBox

		' Token: 0x0400020C RID: 524
		<AccessedThroughProperty("txtHotelCode")>
		Private _txtHotelCode As TextBox

		' Token: 0x0400020D RID: 525
		<AccessedThroughProperty("txtCleaning")>
		Private _txtCleaning As TextBox

		' Token: 0x0400020E RID: 526
		<AccessedThroughProperty("txtRoom")>
		Private _txtRoom As TextBox

		' Token: 0x0400020F RID: 527
		<AccessedThroughProperty("txtFloor")>
		Private _txtFloor As TextBox

		' Token: 0x04000210 RID: 528
		<AccessedThroughProperty("txtBuilding")>
		Private _txtBuilding As TextBox

		' Token: 0x04000211 RID: 529
		<AccessedThroughProperty("txtExpireDate")>
		Private _txtExpireDate As TextBox

		' Token: 0x04000212 RID: 530
		<AccessedThroughProperty("txtCardKey")>
		Private _txtCardKey As TextBox

		' Token: 0x04000213 RID: 531
		<AccessedThroughProperty("txtStartDate")>
		Private _txtStartDate As TextBox

		' Token: 0x04000214 RID: 532
		<AccessedThroughProperty("Label15")>
		Private _Label15 As Label

		' Token: 0x04000215 RID: 533
		<AccessedThroughProperty("Label10")>
		Private _Label10 As Label

		' Token: 0x04000216 RID: 534
		<AccessedThroughProperty("Label9")>
		Private _Label9 As Label

		' Token: 0x04000217 RID: 535
		<AccessedThroughProperty("Label8")>
		Private _Label8 As Label

		' Token: 0x04000218 RID: 536
		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		' Token: 0x04000219 RID: 537
		<AccessedThroughProperty("Label6")>
		Private _Label6 As Label

		' Token: 0x0400021A RID: 538
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x0400021B RID: 539
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x0400021C RID: 540
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x0400021D RID: 541
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x0400021E RID: 542
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x0400021F RID: 543
		<AccessedThroughProperty("Frame2")>
		Private _Frame2 As GroupBox

		' Token: 0x04000220 RID: 544
		<AccessedThroughProperty("btnReadAuth")>
		Private _btnReadAuth As Button

		' Token: 0x04000221 RID: 545
		<AccessedThroughProperty("btnCheckLink")>
		Private _btnCheckLink As Button

		' Token: 0x04000222 RID: 546
		<AccessedThroughProperty("btnCheckCard")>
		Private _btnCheckCard As Button

		' Token: 0x04000223 RID: 547
		<AccessedThroughProperty("btnGetNewAuth")>
		Private _btnGetNewAuth As Button

		' Token: 0x04000224 RID: 548
		<AccessedThroughProperty("btnCancelCard")>
		Private _btnCancelCard As Button

		' Token: 0x04000225 RID: 549
		<AccessedThroughProperty("btnIssueCard")>
		Private _btnIssueCard As Button

		' Token: 0x04000226 RID: 550
		<AccessedThroughProperty("btnReadCard")>
		Private _btnReadCard As Button

		' Token: 0x04000227 RID: 551
		<AccessedThroughProperty("Label16")>
		Private _Label16 As Label

		' Token: 0x04000228 RID: 552
		<AccessedThroughProperty("cboLockType")>
		Private _cboLockType As ComboBox

		' Token: 0x04000229 RID: 553
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x0400022A RID: 554
		<AccessedThroughProperty("XCard")>
		Private _XCard As Card
	End Class
End Namespace
