﻿Namespace prjIS_SalesPOS
	' Token: 0x0200004E RID: 78
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMHH1
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06001544 RID: 5444 RVA: 0x00101DE4 File Offset: 0x000FFFE4
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06001545 RID: 5445 RVA: 0x00101E1C File Offset: 0x0010001C
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Global.System.ComponentModel.Container()
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMHH1))
			Me.lblPosition = New Global.System.Windows.Forms.Label()
			Me.btnAddDefault = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.btnLast = New Global.System.Windows.Forms.Button()
			Me.btnNext = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.btnPreview = New Global.System.Windows.Forms.Button()
			Me.btnCancelFilter = New Global.System.Windows.Forms.Button()
			Me.grpNavigater = New Global.System.Windows.Forms.GroupBox()
			Me.btnFirst = New Global.System.Windows.Forms.Button()
			Me.btnPrevious = New Global.System.Windows.Forms.Button()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.grpControl = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnSelect = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnAdd = New Global.System.Windows.Forms.Button()
			Me.btnFindNext = New Global.System.Windows.Forms.Button()
			Me.btnModify = New Global.System.Windows.Forms.Button()
			Me.btnAddDefault2 = New Global.System.Windows.Forms.Button()
			Me.dgvData = New Global.System.Windows.Forms.DataGridView()
			Me.lblMANH = New Global.System.Windows.Forms.Label()
			Me.txtOBJNAMENH = New Global.System.Windows.Forms.TextBox()
			Me.btnSelectNH = New Global.System.Windows.Forms.Button()
			Me.txtOBJIDNH = New Global.System.Windows.Forms.TextBox()
			Me.tblpLuoi = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnEx = New Global.System.Windows.Forms.Button()
			Me.btnIm = New Global.System.Windows.Forms.Button()
			Me.btnSendData = New Global.System.Windows.Forms.Button()
			Me.txtLoc = New Global.System.Windows.Forms.TextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.cboSLIn = New Global.System.Windows.Forms.ComboBox()
			Me.txtSLIn = New Global.System.Windows.Forms.TextBox()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.btnSLIn = New Global.System.Windows.Forms.Button()
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.btnSelAll = New Global.System.Windows.Forms.Button()
			Me.btnUnSelAll = New Global.System.Windows.Forms.Button()
			Me.ToolTip1 = New Global.System.Windows.Forms.ToolTip(Me.components)
			Me.Label4 = New Global.System.Windows.Forms.Label()
			Me.txtTongSLIn = New Global.System.Windows.Forms.TextBox()
			Me.btnPrintBarcode = New Global.System.Windows.Forms.Button()
			Me.grpNavigater.SuspendLayout()
			Me.grpControl.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.tblpLuoi.SuspendLayout()
			Me.SuspendLayout()
			Me.lblPosition.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.lblPosition.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblPosition.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPosition As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(83, 14)
			lblPosition.Location = point
			Me.lblPosition.Name = "lblPosition"
			Dim lblPosition2 As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(93, 35)
			lblPosition2.Size = size
			Me.lblPosition.TabIndex = 6
			Me.lblPosition.Tag = "0R0000"
			Me.lblPosition.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btnAddDefault.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnAddDefault.Image = Global.prjIS_SalesPOS.My.Resources.Resources.them_copy
			Dim btnAddDefault As Global.System.Windows.Forms.Control = Me.btnAddDefault
			point = New Global.System.Drawing.Point(3, 45)
			btnAddDefault.Location = point
			Me.btnAddDefault.Name = "btnAddDefault"
			Dim btnAddDefault2 As Global.System.Windows.Forms.Control = Me.btnAddDefault
			size = New Global.System.Drawing.Size(107, 36)
			btnAddDefault2.Size = size
			Me.btnAddDefault.TabIndex = 3
			Me.btnAddDefault.Tag = "CR0005"
			Me.btnAddDefault.Text = "Copy"
			Me.btnAddDefault.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnAddDefault.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 171)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 36)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 2
			Me.btnDelete.Tag = "CR0007"
			Me.btnDelete.Text = "Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.btnLast.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi_1
			Dim btnLast As Global.System.Windows.Forms.Control = Me.btnLast
			point = New Global.System.Drawing.Point(213, 14)
			btnLast.Location = point
			Me.btnLast.Name = "btnLast"
			Dim btnLast2 As Global.System.Windows.Forms.Control = Me.btnLast
			size = New Global.System.Drawing.Size(40, 35)
			btnLast2.Size = size
			Me.btnLast.TabIndex = 5
			Me.btnLast.UseVisualStyleBackColor = True
			Me.btnNext.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi
			Dim btnNext As Global.System.Windows.Forms.Control = Me.btnNext
			point = New Global.System.Drawing.Point(175, 14)
			btnNext.Location = point
			Me.btnNext.Name = "btnNext"
			Dim btnNext2 As Global.System.Windows.Forms.Control = Me.btnNext
			size = New Global.System.Drawing.Size(40, 35)
			btnNext2.Size = size
			Me.btnNext.TabIndex = 4
			Me.btnNext.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 297)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(107, 36)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 4
			Me.btnFind.Tag = "CR0010"
			Me.btnFind.Text = "Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.btnPreview.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnPreview.Image = Global.prjIS_SalesPOS.My.Resources.Resources._in
			Dim btnPreview As Global.System.Windows.Forms.Control = Me.btnPreview
			point = New Global.System.Drawing.Point(3, 381)
			btnPreview.Location = point
			Me.btnPreview.Name = "btnPreview"
			Dim btnPreview2 As Global.System.Windows.Forms.Control = Me.btnPreview
			size = New Global.System.Drawing.Size(107, 36)
			btnPreview2.Size = size
			Me.btnPreview.TabIndex = 7
			Me.btnPreview.Tag = "CR0012"
			Me.btnPreview.Text = "In"
			Me.btnPreview.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnPreview.UseVisualStyleBackColor = True
			Me.btnCancelFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnCancelFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Cancel
			Dim btnCancelFilter As Global.System.Windows.Forms.Control = Me.btnCancelFilter
			point = New Global.System.Drawing.Point(3, 255)
			btnCancelFilter.Location = point
			Me.btnCancelFilter.Name = "btnCancelFilter"
			Dim btnCancelFilter2 As Global.System.Windows.Forms.Control = Me.btnCancelFilter
			size = New Global.System.Drawing.Size(107, 36)
			btnCancelFilter2.Size = size
			Me.btnCancelFilter.TabIndex = 6
			Me.btnCancelFilter.Tag = "CR0009"
			Me.btnCancelFilter.Text = "Bỏ lọc"
			Me.btnCancelFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnCancelFilter.UseVisualStyleBackColor = True
			Me.grpNavigater.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom
			Me.grpNavigater.Controls.Add(Me.lblPosition)
			Me.grpNavigater.Controls.Add(Me.btnFirst)
			Me.grpNavigater.Controls.Add(Me.btnPrevious)
			Me.grpNavigater.Controls.Add(Me.btnLast)
			Me.grpNavigater.Controls.Add(Me.btnNext)
			Dim grpNavigater As Global.System.Windows.Forms.Control = Me.grpNavigater
			point = New Global.System.Drawing.Point(325, 453)
			grpNavigater.Location = point
			Me.grpNavigater.Name = "grpNavigater"
			Dim grpNavigater2 As Global.System.Windows.Forms.Control = Me.grpNavigater
			size = New Global.System.Drawing.Size(260, 61)
			grpNavigater2.Size = size
			Me.grpNavigater.TabIndex = 12
			Me.grpNavigater.TabStop = False
			Me.btnFirst.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui_1
			Dim btnFirst As Global.System.Windows.Forms.Control = Me.btnFirst
			point = New Global.System.Drawing.Point(6, 14)
			btnFirst.Location = point
			Me.btnFirst.Name = "btnFirst"
			Dim btnFirst2 As Global.System.Windows.Forms.Control = Me.btnFirst
			size = New Global.System.Drawing.Size(40, 35)
			btnFirst2.Size = size
			Me.btnFirst.TabIndex = 2
			Me.btnFirst.UseVisualStyleBackColor = True
			Me.btnPrevious.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui
			Dim btnPrevious As Global.System.Windows.Forms.Control = Me.btnPrevious
			point = New Global.System.Drawing.Point(44, 14)
			btnPrevious.Location = point
			Me.btnPrevious.Name = "btnPrevious"
			Dim btnPrevious2 As Global.System.Windows.Forms.Control = Me.btnPrevious
			size = New Global.System.Drawing.Size(40, 35)
			btnPrevious2.Size = size
			Me.btnPrevious.TabIndex = 3
			Me.btnPrevious.UseVisualStyleBackColor = True
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 213)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(107, 36)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 5
			Me.btnFilter.Tag = "CR0008"
			Me.btnFilter.Text = "Lọc"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.grpControl.Controls.Add(Me.TableLayoutPanel1)
			Me.grpControl.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpControl As Global.System.Windows.Forms.Control = Me.grpControl
			point = New Global.System.Drawing.Point(901, 0)
			grpControl.Location = point
			Me.grpControl.Name = "grpControl"
			Dim grpControl2 As Global.System.Windows.Forms.Control = Me.grpControl
			size = New Global.System.Drawing.Size(119, 526)
			grpControl2.Size = size
			Me.grpControl.TabIndex = 10
			Me.grpControl.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnSelect, 0, 10)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 11)
			Me.TableLayoutPanel1.Controls.Add(Me.btnCancelFilter, 0, 6)
			Me.TableLayoutPanel1.Controls.Add(Me.btnAdd, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnAddDefault, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFindNext, 0, 8)
			Me.TableLayoutPanel1.Controls.Add(Me.btnPreview, 0, 9)
			Me.TableLayoutPanel1.Controls.Add(Me.btnModify, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 7)
			Me.TableLayoutPanel1.Controls.Add(Me.btnAddDefault2, 0, 2)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 12
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 505)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnSelect.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Dim btnSelect As Global.System.Windows.Forms.Control = Me.btnSelect
			point = New Global.System.Drawing.Point(3, 423)
			btnSelect.Location = point
			Me.btnSelect.Name = "btnSelect"
			Dim btnSelect2 As Global.System.Windows.Forms.Control = Me.btnSelect
			size = New Global.System.Drawing.Size(107, 36)
			btnSelect2.Size = size
			Me.btnSelect.TabIndex = 13
			Me.btnSelect.Tag = "CR0013"
			Me.btnSelect.Text = "Chọn"
			Me.btnSelect.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSelect.UseVisualStyleBackColor = True
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 465)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 37)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 12
			Me.btnExit.Tag = "CR0003"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnAdd.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnAdd.Image = Global.prjIS_SalesPOS.My.Resources.Resources.them
			Dim btnAdd As Global.System.Windows.Forms.Control = Me.btnAdd
			point = New Global.System.Drawing.Point(3, 3)
			btnAdd.Location = point
			Me.btnAdd.Name = "btnAdd"
			Dim btnAdd2 As Global.System.Windows.Forms.Control = Me.btnAdd
			size = New Global.System.Drawing.Size(107, 36)
			btnAdd2.Size = size
			Me.btnAdd.TabIndex = 0
			Me.btnAdd.Tag = "CR0004"
			Me.btnAdd.Text = "Thêm"
			Me.btnAdd.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnAdd.UseVisualStyleBackColor = True
			Me.btnFindNext.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFindNext.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnFindNext.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim_tiep
			Dim btnFindNext As Global.System.Windows.Forms.Control = Me.btnFindNext
			point = New Global.System.Drawing.Point(3, 339)
			btnFindNext.Location = point
			Me.btnFindNext.Name = "btnFindNext"
			Dim btnFindNext2 As Global.System.Windows.Forms.Control = Me.btnFindNext
			size = New Global.System.Drawing.Size(107, 36)
			btnFindNext2.Size = size
			Me.btnFindNext.TabIndex = 8
			Me.btnFindNext.Tag = "CR0011"
			Me.btnFindNext.Text = "Tìm tiếp"
			Me.btnFindNext.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFindNext.UseVisualStyleBackColor = True
			Me.btnModify.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnModify.Image = Global.prjIS_SalesPOS.My.Resources.Resources.sua
			Dim btnModify As Global.System.Windows.Forms.Control = Me.btnModify
			point = New Global.System.Drawing.Point(3, 129)
			btnModify.Location = point
			Me.btnModify.Name = "btnModify"
			Dim btnModify2 As Global.System.Windows.Forms.Control = Me.btnModify
			size = New Global.System.Drawing.Size(107, 36)
			btnModify2.Size = size
			Me.btnModify.TabIndex = 1
			Me.btnModify.Tag = "CR0006"
			Me.btnModify.Text = "Sửa"
			Me.btnModify.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnModify.UseVisualStyleBackColor = True
			Me.btnAddDefault2.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnAddDefault2.Image = Global.prjIS_SalesPOS.My.Resources.Resources.them_copy
			Dim btnAddDefault3 As Global.System.Windows.Forms.Control = Me.btnAddDefault2
			point = New Global.System.Drawing.Point(3, 87)
			btnAddDefault3.Location = point
			Me.btnAddDefault2.Name = "btnAddDefault2"
			Dim btnAddDefault4 As Global.System.Windows.Forms.Control = Me.btnAddDefault2
			size = New Global.System.Drawing.Size(107, 36)
			btnAddDefault4.Size = size
			Me.btnAddDefault2.TabIndex = 3
			Me.btnAddDefault2.Tag = "CR0043"
			Me.btnAddDefault2.Text = "Copy 2"
			Me.btnAddDefault2.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnAddDefault2.UseVisualStyleBackColor = True
			Me.dgvData.AllowUserToAddRows = False
			Me.dgvData.AllowUserToDeleteRows = False
			Me.dgvData.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvData.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvData.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvData As Global.System.Windows.Forms.Control = Me.dgvData
			point = New Global.System.Drawing.Point(3, 3)
			dgvData.Location = point
			Me.dgvData.Name = "dgvData"
			Me.dgvData.[ReadOnly] = True
			Dim dgvData2 As Global.System.Windows.Forms.Control = Me.dgvData
			size = New Global.System.Drawing.Size(892, 381)
			dgvData2.Size = size
			Me.dgvData.TabIndex = 13
			Me.lblMANH.AutoSize = True
			Me.lblMANH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMANH As Global.System.Windows.Forms.Control = Me.lblMANH
			point = New Global.System.Drawing.Point(2, 9)
			lblMANH.Location = point
			Me.lblMANH.Name = "lblMANH"
			Dim lblMANH2 As Global.System.Windows.Forms.Control = Me.lblMANH
			size = New Global.System.Drawing.Size(126, 16)
			lblMANH2.Size = size
			Me.lblMANH.TabIndex = 43
			Me.lblMANH.Tag = "CR0017"
			Me.lblMANH.Text = "Lọc theo nhóm hàng"
			Me.txtOBJNAMENH.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtOBJNAMENH As Global.System.Windows.Forms.Control = Me.txtOBJNAMENH
			point = New Global.System.Drawing.Point(254, 6)
			txtOBJNAMENH.Location = point
			Me.txtOBJNAMENH.Name = "txtOBJNAMENH"
			Dim txtOBJNAMENH2 As Global.System.Windows.Forms.Control = Me.txtOBJNAMENH
			size = New Global.System.Drawing.Size(177, 22)
			txtOBJNAMENH2.Size = size
			Me.txtOBJNAMENH.TabIndex = 42
			Me.txtOBJNAMENH.Tag = "0R0000"
			Me.btnSelectNH.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnSelectNH As Global.System.Windows.Forms.Control = Me.btnSelectNH
			point = New Global.System.Drawing.Point(216, 3)
			btnSelectNH.Location = point
			Me.btnSelectNH.Name = "btnSelectNH"
			Dim btnSelectNH2 As Global.System.Windows.Forms.Control = Me.btnSelectNH
			size = New Global.System.Drawing.Size(37, 27)
			btnSelectNH2.Size = size
			Me.btnSelectNH.TabIndex = 41
			Me.btnSelectNH.Tag = "CB0016"
			Me.btnSelectNH.UseVisualStyleBackColor = True
			Me.txtOBJIDNH.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJIDNH As Global.System.Windows.Forms.Control = Me.txtOBJIDNH
			point = New Global.System.Drawing.Point(143, 6)
			txtOBJIDNH.Location = point
			Me.txtOBJIDNH.Name = "txtOBJIDNH"
			Dim txtOBJIDNH2 As Global.System.Windows.Forms.Control = Me.txtOBJIDNH
			size = New Global.System.Drawing.Size(72, 22)
			txtOBJIDNH2.Size = size
			Me.txtOBJIDNH.TabIndex = 40
			Me.txtOBJIDNH.Tag = "0R0000"
			Me.txtOBJIDNH.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.tblpLuoi.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.tblpLuoi.ColumnCount = 1
			Me.tblpLuoi.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.tblpLuoi.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Absolute, 20F))
			Me.tblpLuoi.Controls.Add(Me.dgvData, 0, 0)
			Dim tblpLuoi As Global.System.Windows.Forms.Control = Me.tblpLuoi
			point = New Global.System.Drawing.Point(0, 61)
			tblpLuoi.Location = point
			Me.tblpLuoi.Name = "tblpLuoi"
			Me.tblpLuoi.RowCount = 1
			Me.tblpLuoi.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.tblpLuoi.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Absolute, 387F))
			Dim tblpLuoi2 As Global.System.Windows.Forms.Control = Me.tblpLuoi
			size = New Global.System.Drawing.Size(898, 387)
			tblpLuoi2.Size = size
			Me.tblpLuoi.TabIndex = 44
			Me.btnEx.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left
			Me.btnEx.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Next
			Dim btnEx As Global.System.Windows.Forms.Control = Me.btnEx
			point = New Global.System.Drawing.Point(6, 451)
			btnEx.Location = point
			Me.btnEx.Name = "btnEx"
			Dim btnEx2 As Global.System.Windows.Forms.Control = Me.btnEx
			size = New Global.System.Drawing.Size(102, 34)
			btnEx2.Size = size
			Me.btnEx.TabIndex = 45
			Me.btnEx.Tag = "CR0036"
			Me.btnEx.Text = "Xuất excel"
			Me.btnEx.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnEx.UseVisualStyleBackColor = True
			Me.btnIm.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left
			Me.btnIm.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Previous
			Dim btnIm As Global.System.Windows.Forms.Control = Me.btnIm
			point = New Global.System.Drawing.Point(6, 486)
			btnIm.Location = point
			Me.btnIm.Name = "btnIm"
			Dim btnIm2 As Global.System.Windows.Forms.Control = Me.btnIm
			size = New Global.System.Drawing.Size(102, 34)
			btnIm2.Size = size
			Me.btnIm.TabIndex = 46
			Me.btnIm.Tag = "CR0037"
			Me.btnIm.Text = "Nhập excel"
			Me.btnIm.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnIm.UseVisualStyleBackColor = True
			Me.btnSendData.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left
			Dim btnSendData As Global.System.Windows.Forms.Control = Me.btnSendData
			point = New Global.System.Drawing.Point(333, 468)
			btnSendData.Location = point
			Me.btnSendData.Name = "btnSendData"
			Dim btnSendData2 As Global.System.Windows.Forms.Control = Me.btnSendData
			size = New Global.System.Drawing.Size(35, 34)
			btnSendData2.Size = size
			Me.btnSendData.TabIndex = 45
			Me.btnSendData.Tag = "CR0042"
			Me.btnSendData.Text = "Gửi dữ liệu"
			Me.btnSendData.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSendData.UseVisualStyleBackColor = True
			Me.btnSendData.Visible = False
			Me.txtLoc.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.txtLoc.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtLoc As Global.System.Windows.Forms.Control = Me.txtLoc
			point = New Global.System.Drawing.Point(597, 6)
			txtLoc.Location = point
			Me.txtLoc.Name = "txtLoc"
			Dim txtLoc2 As Global.System.Windows.Forms.Control = Me.txtLoc
			size = New Global.System.Drawing.Size(296, 22)
			txtLoc2.Size = size
			Me.txtLoc.TabIndex = 40
			Me.txtLoc.Tag = "0R0000"
			Me.Label1.AutoSize = True
			Me.Label1.BackColor = Global.System.Drawing.Color.Transparent
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(445, 9)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(149, 16)
			label2.Size = size
			Me.Label1.TabIndex = 43
			Me.Label1.Tag = "CR0047"
			Me.Label1.Text = "Lọc theo mã/tên/tên phụ"
			Me.cboSLIn.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cboSLIn.FormattingEnabled = True
			Dim cboSLIn As Global.System.Windows.Forms.Control = Me.cboSLIn
			point = New Global.System.Drawing.Point(597, 32)
			cboSLIn.Location = point
			Me.cboSLIn.Name = "cboSLIn"
			Dim cboSLIn2 As Global.System.Windows.Forms.Control = Me.cboSLIn
			size = New Global.System.Drawing.Size(94, 24)
			cboSLIn2.Size = size
			Me.cboSLIn.TabIndex = 47
			Me.txtSLIn.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtSLIn As Global.System.Windows.Forms.Control = Me.txtSLIn
			point = New Global.System.Drawing.Point(143, 32)
			txtSLIn.Location = point
			Me.txtSLIn.Name = "txtSLIn"
			Dim txtSLIn2 As Global.System.Windows.Forms.Control = Me.txtSLIn
			size = New Global.System.Drawing.Size(72, 22)
			txtSLIn2.Size = size
			Me.txtSLIn.TabIndex = 40
			Me.txtSLIn.Tag = "0R0000"
			Me.txtSLIn.Text = "1"
			Me.txtSLIn.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.Label2.AutoSize = True
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(2, 35)
			label3.Location = point
			Me.Label2.Name = "Label2"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(134, 16)
			label4.Size = size
			Me.Label2.TabIndex = 43
			Me.Label2.Tag = "CR0048"
			Me.Label2.Text = "Số lượng in mặc định"
			Me.btnSLIn.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnSLIn As Global.System.Windows.Forms.Control = Me.btnSLIn
			point = New Global.System.Drawing.Point(216, 30)
			btnSLIn.Location = point
			Me.btnSLIn.Name = "btnSLIn"
			Dim btnSLIn2 As Global.System.Windows.Forms.Control = Me.btnSLIn
			size = New Global.System.Drawing.Size(37, 27)
			btnSLIn2.Size = size
			Me.btnSLIn.TabIndex = 41
			Me.btnSLIn.Tag = "CB0016"
			Me.btnSLIn.UseVisualStyleBackColor = True
			Me.Label3.AutoSize = True
			Me.Label3.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(445, 35)
			label5.Location = point
			Me.Label3.Name = "Label3"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(129, 16)
			label6.Size = size
			Me.Label3.TabIndex = 43
			Me.Label3.Tag = "CR0049"
			Me.Label3.Text = "Lọc theo số lượng in"
			Me.btnSelAll.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btnSelAll.BackColor = Global.System.Drawing.Color.Snow
			Me.btnSelAll.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.selall
			Me.btnSelAll.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnSelAll.FlatAppearance.BorderColor = Global.System.Drawing.Color.DimGray
			Me.btnSelAll.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Dim btnSelAll As Global.System.Windows.Forms.Control = Me.btnSelAll
			point = New Global.System.Drawing.Point(734, 30)
			btnSelAll.Location = point
			Me.btnSelAll.Name = "btnSelAll"
			Dim btnSelAll2 As Global.System.Windows.Forms.Control = Me.btnSelAll
			size = New Global.System.Drawing.Size(78, 29)
			btnSelAll2.Size = size
			Me.btnSelAll.TabIndex = 48
			Me.ToolTip1.SetToolTip(Me.btnSelAll, "Chọn tất cả")
			Me.btnSelAll.UseVisualStyleBackColor = False
			Me.btnUnSelAll.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btnUnSelAll.BackColor = Global.System.Drawing.Color.Snow
			Me.btnUnSelAll.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.unselall
			Me.btnUnSelAll.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnUnSelAll.FlatAppearance.BorderColor = Global.System.Drawing.Color.DimGray
			Me.btnUnSelAll.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Dim btnUnSelAll As Global.System.Windows.Forms.Control = Me.btnUnSelAll
			point = New Global.System.Drawing.Point(815, 30)
			btnUnSelAll.Location = point
			Me.btnUnSelAll.Name = "btnUnSelAll"
			Dim btnUnSelAll2 As Global.System.Windows.Forms.Control = Me.btnUnSelAll
			size = New Global.System.Drawing.Size(78, 29)
			btnUnSelAll2.Size = size
			Me.btnUnSelAll.TabIndex = 48
			Me.ToolTip1.SetToolTip(Me.btnUnSelAll, "Bỏ chọn tất cả")
			Me.btnUnSelAll.UseVisualStyleBackColor = False
			Me.ToolTip1.IsBalloon = True
			Me.Label4.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.Label4.AutoSize = True
			Me.Label4.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label7 As Global.System.Windows.Forms.Control = Me.Label4
			point = New Global.System.Drawing.Point(676, 456)
			label7.Location = point
			Me.Label4.Name = "Label4"
			Dim label8 As Global.System.Windows.Forms.Control = Me.Label4
			size = New Global.System.Drawing.Size(77, 16)
			label8.Size = size
			Me.Label4.TabIndex = 43
			Me.Label4.Tag = "CR0055"
			Me.Label4.Text = "Tổng SL in"
			Me.txtTongSLIn.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.txtTongSLIn.BackColor = Global.System.Drawing.Color.FromArgb(192, 255, 255)
			Me.txtTongSLIn.Font = New Global.System.Drawing.Font("Arial", 13F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtTongSLIn As Global.System.Windows.Forms.Control = Me.txtTongSLIn
			point = New Global.System.Drawing.Point(761, 451)
			txtTongSLIn.Location = point
			Me.txtTongSLIn.Name = "txtTongSLIn"
			Dim txtTongSLIn2 As Global.System.Windows.Forms.Control = Me.txtTongSLIn
			size = New Global.System.Drawing.Size(132, 27)
			txtTongSLIn2.Size = size
			Me.txtTongSLIn.TabIndex = 49
			Me.txtTongSLIn.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.btnPrintBarcode.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btnPrintBarcode.BackColor = Global.System.Drawing.Color.Snow
			Me.btnPrintBarcode.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnPrintBarcode.Image = Global.prjIS_SalesPOS.My.Resources.Resources.barcode
			Me.btnPrintBarcode.ImageAlign = Global.System.Drawing.ContentAlignment.TopCenter
			Dim btnPrintBarcode As Global.System.Windows.Forms.Control = Me.btnPrintBarcode
			point = New Global.System.Drawing.Point(761, 480)
			btnPrintBarcode.Location = point
			Me.btnPrintBarcode.Name = "btnPrintBarcode"
			Dim btnPrintBarcode2 As Global.System.Windows.Forms.Control = Me.btnPrintBarcode
			size = New Global.System.Drawing.Size(132, 40)
			btnPrintBarcode2.Size = size
			Me.btnPrintBarcode.TabIndex = 45
			Me.btnPrintBarcode.Tag = "CR0054"
			Me.btnPrintBarcode.Text = "In mã vạch"
			Me.btnPrintBarcode.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnPrintBarcode.UseVisualStyleBackColor = False
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(1020, 526)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.txtTongSLIn)
			Me.Controls.Add(Me.btnUnSelAll)
			Me.Controls.Add(Me.btnSelAll)
			Me.Controls.Add(Me.cboSLIn)
			Me.Controls.Add(Me.btnIm)
			Me.Controls.Add(Me.btnPrintBarcode)
			Me.Controls.Add(Me.btnSendData)
			Me.Controls.Add(Me.btnEx)
			Me.Controls.Add(Me.tblpLuoi)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.Label4)
			Me.Controls.Add(Me.Label3)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.lblMANH)
			Me.Controls.Add(Me.txtOBJNAMENH)
			Me.Controls.Add(Me.txtLoc)
			Me.Controls.Add(Me.btnSLIn)
			Me.Controls.Add(Me.btnSelectNH)
			Me.Controls.Add(Me.txtSLIn)
			Me.Controls.Add(Me.txtOBJIDNH)
			Me.Controls.Add(Me.grpNavigater)
			Me.Controls.Add(Me.grpControl)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmDMHH1"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Danh mục HH"
			Me.grpNavigater.ResumeLayout(False)
			Me.grpControl.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.tblpLuoi.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x040008D2 RID: 2258
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
