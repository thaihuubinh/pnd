﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000138 RID: 312
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptBCReservation
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600587E RID: 22654 RVA: 0x0000F457 File Offset: 0x0000D657
		Public Sub New()
			CachedrptBCReservation.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002015 RID: 8213
		' (get) Token: 0x0600587F RID: 22655 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005880 RID: 22656 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002016 RID: 8214
		' (get) Token: 0x06005881 RID: 22657 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005882 RID: 22658 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002017 RID: 8215
		' (get) Token: 0x06005883 RID: 22659 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005884 RID: 22660 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005885 RID: 22661 RVA: 0x004DB260 File Offset: 0x004D9460
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptBCReservation() With { .Site = Me.Site }
		End Function

		' Token: 0x06005886 RID: 22662 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002730 RID: 10032
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
