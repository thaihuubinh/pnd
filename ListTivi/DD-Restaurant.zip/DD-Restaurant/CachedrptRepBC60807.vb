﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002C8 RID: 712
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60807
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006A0E RID: 27150 RVA: 0x00013467 File Offset: 0x00011667
		Public Sub New()
			CachedrptRepBC60807.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170029D5 RID: 10709
		' (get) Token: 0x06006A0F RID: 27151 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006A10 RID: 27152 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170029D6 RID: 10710
		' (get) Token: 0x06006A11 RID: 27153 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006A12 RID: 27154 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170029D7 RID: 10711
		' (get) Token: 0x06006A13 RID: 27155 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006A14 RID: 27156 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006A15 RID: 27157 RVA: 0x004DE460 File Offset: 0x004DC660
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60807() With { .Site = Me.Site }
		End Function

		' Token: 0x06006A16 RID: 27158 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028C0 RID: 10432
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
