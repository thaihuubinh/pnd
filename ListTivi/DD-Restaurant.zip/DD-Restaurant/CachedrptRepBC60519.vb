﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000226 RID: 550
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60519
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006274 RID: 25204 RVA: 0x00011A75 File Offset: 0x0000FC75
		Public Sub New()
			CachedrptRepBC60519.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002565 RID: 9573
		' (get) Token: 0x06006275 RID: 25205 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006276 RID: 25206 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002566 RID: 9574
		' (get) Token: 0x06006277 RID: 25207 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006278 RID: 25208 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002567 RID: 9575
		' (get) Token: 0x06006279 RID: 25209 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x0600627A RID: 25210 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x0600627B RID: 25211 RVA: 0x004DD020 File Offset: 0x004DB220
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60519() With { .Site = Me.Site }
		End Function

		' Token: 0x0600627C RID: 25212 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x0400281E RID: 10270
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
