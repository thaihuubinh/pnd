﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000058 RID: 88
	<DesignerGenerated()>
	Public Partial Class frmDMLDCHI2
		Inherits Form

		' Token: 0x06001A8D RID: 6797 RVA: 0x00149888 File Offset: 0x00147A88
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMLDTHU2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMLDTHU2_Load
			frmDMLDCHI2.__ENCList.Add(New WeakReference(Me))
			Me.mblnFix = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700091F RID: 2335
		' (get) Token: 0x06001A90 RID: 6800 RVA: 0x0014A5AC File Offset: 0x001487AC
		' (set) Token: 0x06001A91 RID: 6801 RVA: 0x00005D08 File Offset: 0x00003F08
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000920 RID: 2336
		' (get) Token: 0x06001A92 RID: 6802 RVA: 0x0014A5C4 File Offset: 0x001487C4
		' (set) Token: 0x06001A93 RID: 6803 RVA: 0x0014A5DC File Offset: 0x001487DC
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000921 RID: 2337
		' (get) Token: 0x06001A94 RID: 6804 RVA: 0x0014A648 File Offset: 0x00148848
		' (set) Token: 0x06001A95 RID: 6805 RVA: 0x00005D12 File Offset: 0x00003F12
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x17000922 RID: 2338
		' (get) Token: 0x06001A96 RID: 6806 RVA: 0x0014A660 File Offset: 0x00148860
		' (set) Token: 0x06001A97 RID: 6807 RVA: 0x0014A678 File Offset: 0x00148878
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000923 RID: 2339
		' (get) Token: 0x06001A98 RID: 6808 RVA: 0x0014A6E4 File Offset: 0x001488E4
		' (set) Token: 0x06001A99 RID: 6809 RVA: 0x0014A6FC File Offset: 0x001488FC
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000924 RID: 2340
		' (get) Token: 0x06001A9A RID: 6810 RVA: 0x0014A768 File Offset: 0x00148968
		' (set) Token: 0x06001A9B RID: 6811 RVA: 0x0014A780 File Offset: 0x00148980
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000925 RID: 2341
		' (get) Token: 0x06001A9C RID: 6812 RVA: 0x0014A7EC File Offset: 0x001489EC
		' (set) Token: 0x06001A9D RID: 6813 RVA: 0x00005D1C File Offset: 0x00003F1C
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x17000926 RID: 2342
		' (get) Token: 0x06001A9E RID: 6814 RVA: 0x0014A804 File Offset: 0x00148A04
		' (set) Token: 0x06001A9F RID: 6815 RVA: 0x0014A81C File Offset: 0x00148A1C
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000927 RID: 2343
		' (get) Token: 0x06001AA0 RID: 6816 RVA: 0x0014A8B8 File Offset: 0x00148AB8
		' (set) Token: 0x06001AA1 RID: 6817 RVA: 0x0014A8D0 File Offset: 0x00148AD0
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000928 RID: 2344
		' (get) Token: 0x06001AA2 RID: 6818 RVA: 0x0014A96C File Offset: 0x00148B6C
		' (set) Token: 0x06001AA3 RID: 6819 RVA: 0x00005D26 File Offset: 0x00003F26
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x17000929 RID: 2345
		' (get) Token: 0x06001AA4 RID: 6820 RVA: 0x0014A984 File Offset: 0x00148B84
		' (set) Token: 0x06001AA5 RID: 6821 RVA: 0x00005D30 File Offset: 0x00003F30
		Friend Overridable Property txtColor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtColor = value
			End Set
		End Property

		' Token: 0x1700092A RID: 2346
		' (get) Token: 0x06001AA6 RID: 6822 RVA: 0x0014A99C File Offset: 0x00148B9C
		' (set) Token: 0x06001AA7 RID: 6823 RVA: 0x00005D3A File Offset: 0x00003F3A
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x1700092B RID: 2347
		' (get) Token: 0x06001AA8 RID: 6824 RVA: 0x0014A9B4 File Offset: 0x00148BB4
		' (set) Token: 0x06001AA9 RID: 6825 RVA: 0x00005D44 File Offset: 0x00003F44
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x1700092C RID: 2348
		' (get) Token: 0x06001AAA RID: 6826 RVA: 0x0014A9CC File Offset: 0x00148BCC
		' (set) Token: 0x06001AAB RID: 6827 RVA: 0x00005D4E File Offset: 0x00003F4E
		Friend Overridable Property txtSUBOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtSUBOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtSUBOBJNAME = value
			End Set
		End Property

		' Token: 0x1700092D RID: 2349
		' (get) Token: 0x06001AAC RID: 6828 RVA: 0x0014A9E4 File Offset: 0x00148BE4
		' (set) Token: 0x06001AAD RID: 6829 RVA: 0x0014A9FC File Offset: 0x00148BFC
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x1700092E RID: 2350
		' (get) Token: 0x06001AAE RID: 6830 RVA: 0x0014AA68 File Offset: 0x00148C68
		' (set) Token: 0x06001AAF RID: 6831 RVA: 0x00005D58 File Offset: 0x00003F58
		Public Property pblnFix As Boolean
			Get
				Return Me.mblnFix
			End Get
			Set(value As Boolean)
				Me.mblnFix = value
			End Set
		End Property

		' Token: 0x1700092F RID: 2351
		' (get) Token: 0x06001AB0 RID: 6832 RVA: 0x0014AA80 File Offset: 0x00148C80
		' (set) Token: 0x06001AB1 RID: 6833 RVA: 0x00005D63 File Offset: 0x00003F63
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000930 RID: 2352
		' (get) Token: 0x06001AB2 RID: 6834 RVA: 0x0014AA98 File Offset: 0x00148C98
		' (set) Token: 0x06001AB3 RID: 6835 RVA: 0x00005D6E File Offset: 0x00003F6E
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000931 RID: 2353
		' (get) Token: 0x06001AB4 RID: 6836 RVA: 0x0014AAB0 File Offset: 0x00148CB0
		' (set) Token: 0x06001AB5 RID: 6837 RVA: 0x00005D79 File Offset: 0x00003F79
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06001AB6 RID: 6838 RVA: 0x0014AAC8 File Offset: 0x00148CC8
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim flag2 As Boolean = Me.mbytFormStatus = 5
					If flag2 Then
						Me.btnFilter.Focus()
					Else
						flag2 = Me.mbytFormStatus = 6
						If flag2 Then
							Me.btnFind.Focus()
						Else
							Me.btnSave.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001AB7 RID: 6839 RVA: 0x0014ABA4 File Offset: 0x00148DA4
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001AB8 RID: 6840 RVA: 0x0014AC50 File Offset: 0x00148E50
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.btnExit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001AB9 RID: 6841 RVA: 0x0014ACFC File Offset: 0x00148EFC
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001ABA RID: 6842 RVA: 0x0014ADA4 File Offset: 0x00148FA4
		Private Sub frmDMLDTHU2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLDTHU2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001ABB RID: 6843 RVA: 0x0014AE50 File Offset: 0x00149050
		Private Sub frmDMLDTHU2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLDTHU2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001ABC RID: 6844 RVA: 0x0014AEFC File Offset: 0x001490FC
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
						If flag Then
							Me.mbytSuccess = Me.fAddNew()
						Else
							flag = Me.mbytFormStatus = 3
							If flag Then
								Me.mbytSuccess = Me.fModify()
							End If
						End If
						flag = Me.mbytSuccess = 1
						If flag Then
							Me.Close()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001ABD RID: 6845 RVA: 0x0014B088 File Offset: 0x00149288
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001ABE RID: 6846 RVA: 0x0014B12C File Offset: 0x0014932C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001ABF RID: 6847 RVA: 0x0014B330 File Offset: 0x00149530
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001AC0 RID: 6848 RVA: 0x0014B534 File Offset: 0x00149734
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtSUBOBJNAME.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.BackColor = Me.txtColor.BackColor
						Me.txtSUBOBJNAME.BackColor = Me.txtColor.BackColor
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001AC1 RID: 6849 RVA: 0x0014B6A4 File Offset: 0x001498A4
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001AC2 RID: 6850 RVA: 0x0014B834 File Offset: 0x00149A34
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 2
				Me.txtOBJNAME.MaxLength = 50
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001AC3 RID: 6851 RVA: 0x0014B908 File Offset: 0x00149B08
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(mdlVariable.gStrPathApp + "\DISPLAY\" + mdlVariable.gStrLanguage + "\FRMDMLDCHI2.TXT")
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2040400000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001AC4 RID: 6852 RVA: 0x0014BABC File Offset: 0x00149CBC
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001AC5 RID: 6853 RVA: 0x0014BB5C File Offset: 0x00149D5C
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcSUBOBJNAME"
				array(3).Value = Strings.Trim(Me.txtSUBOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLDCHI_INSERT_DMLDCHI", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001AC6 RID: 6854 RVA: 0x0014BD90 File Offset: 0x00149F90
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcSUBOBJNAME"
				array(3).Value = Strings.Trim(Me.txtSUBOBJNAME.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pbitFIX"
				array(4).Value = Me.mblnFix
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLDCHI_UPDATE_DMLDCHI", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001AC7 RID: 6855 RVA: 0x0014BFE4 File Offset: 0x0014A1E4
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLDCHI_DEL_DMLDCHI", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001AC8 RID: 6856 RVA: 0x0014C1A8 File Offset: 0x0014A3A8
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x06001AC9 RID: 6857 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x04000AF1 RID: 2801
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000AF3 RID: 2803
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000AF4 RID: 2804
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000AF5 RID: 2805
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000AF6 RID: 2806
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000AF7 RID: 2807
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000AF8 RID: 2808
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000AF9 RID: 2809
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000AFA RID: 2810
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000AFB RID: 2811
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000AFC RID: 2812
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000AFD RID: 2813
		<AccessedThroughProperty("txtColor")>
		Private _txtColor As TextBox

		' Token: 0x04000AFE RID: 2814
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000AFF RID: 2815
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000B00 RID: 2816
		<AccessedThroughProperty("txtSUBOBJNAME")>
		Private _txtSUBOBJNAME As TextBox

		' Token: 0x04000B01 RID: 2817
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000B02 RID: 2818
		Private mArrStrFrmMess As String()

		' Token: 0x04000B03 RID: 2819
		Private mbytFormStatus As Byte

		' Token: 0x04000B04 RID: 2820
		Private mbytSuccess As Byte

		' Token: 0x04000B05 RID: 2821
		Private mStrFilter As String

		' Token: 0x04000B06 RID: 2822
		Private mblnFix As Boolean
	End Class
End Namespace
