﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020001D2 RID: 466
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60503
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005EC7 RID: 24263 RVA: 0x00010D01 File Offset: 0x0000EF01
		Public Sub New()
			CachedrptRepBC60503.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x1700235C RID: 9052
		' (get) Token: 0x06005EC8 RID: 24264 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005EC9 RID: 24265 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700235D RID: 9053
		' (get) Token: 0x06005ECA RID: 24266 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005ECB RID: 24267 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700235E RID: 9054
		' (get) Token: 0x06005ECC RID: 24268 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005ECD RID: 24269 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005ECE RID: 24270 RVA: 0x004DC5A0 File Offset: 0x004DA7A0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60503() With { .Site = Me.Site }
		End Function

		' Token: 0x06005ECF RID: 24271 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040027CA RID: 10186
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
