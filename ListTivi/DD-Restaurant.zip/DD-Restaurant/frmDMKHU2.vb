﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000056 RID: 86
	<DesignerGenerated()>
	Public Partial Class frmDMKHU2
		Inherits Form

		' Token: 0x060019D5 RID: 6613 RVA: 0x00140DC4 File Offset: 0x0013EFC4
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMKHU2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMKHU2_Load
			frmDMKHU2.__ENCList.Add(New WeakReference(Me))
			Me.mstrMAKH = ""
			Me.mbytStatus = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x170008E3 RID: 2275
		' (get) Token: 0x060019D8 RID: 6616 RVA: 0x00142654 File Offset: 0x00140854
		' (set) Token: 0x060019D9 RID: 6617 RVA: 0x00005BB0 File Offset: 0x00003DB0
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x170008E4 RID: 2276
		' (get) Token: 0x060019DA RID: 6618 RVA: 0x0014266C File Offset: 0x0014086C
		' (set) Token: 0x060019DB RID: 6619 RVA: 0x00142684 File Offset: 0x00140884
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170008E5 RID: 2277
		' (get) Token: 0x060019DC RID: 6620 RVA: 0x001426F0 File Offset: 0x001408F0
		' (set) Token: 0x060019DD RID: 6621 RVA: 0x00005BBA File Offset: 0x00003DBA
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x170008E6 RID: 2278
		' (get) Token: 0x060019DE RID: 6622 RVA: 0x00142708 File Offset: 0x00140908
		' (set) Token: 0x060019DF RID: 6623 RVA: 0x00142720 File Offset: 0x00140920
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x170008E7 RID: 2279
		' (get) Token: 0x060019E0 RID: 6624 RVA: 0x0014278C File Offset: 0x0014098C
		' (set) Token: 0x060019E1 RID: 6625 RVA: 0x001427A4 File Offset: 0x001409A4
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170008E8 RID: 2280
		' (get) Token: 0x060019E2 RID: 6626 RVA: 0x00142810 File Offset: 0x00140A10
		' (set) Token: 0x060019E3 RID: 6627 RVA: 0x00142828 File Offset: 0x00140A28
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170008E9 RID: 2281
		' (get) Token: 0x060019E4 RID: 6628 RVA: 0x00142894 File Offset: 0x00140A94
		' (set) Token: 0x060019E5 RID: 6629 RVA: 0x00005BC4 File Offset: 0x00003DC4
		Friend Overridable Property lblMAHH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAHH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAHH = value
			End Set
		End Property

		' Token: 0x170008EA RID: 2282
		' (get) Token: 0x060019E6 RID: 6630 RVA: 0x001428AC File Offset: 0x00140AAC
		' (set) Token: 0x060019E7 RID: 6631 RVA: 0x001428C4 File Offset: 0x00140AC4
		Friend Overridable Property txtMAKHO As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKHO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKHO IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKHO.TextChanged, AddressOf Me.txtMAKHO_TextChanged
					RemoveHandler Me._txtMAKHO.GotFocus, AddressOf Me.txtMAKHO_GotFocus
					RemoveHandler Me._txtMAKHO.KeyPress, AddressOf Me.txtMAKHO_KeyPress
				End If
				Me._txtMAKHO = value
				flag = Me._txtMAKHO IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKHO.TextChanged, AddressOf Me.txtMAKHO_TextChanged
					AddHandler Me._txtMAKHO.GotFocus, AddressOf Me.txtMAKHO_GotFocus
					AddHandler Me._txtMAKHO.KeyPress, AddressOf Me.txtMAKHO_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170008EB RID: 2283
		' (get) Token: 0x060019E8 RID: 6632 RVA: 0x00142994 File Offset: 0x00140B94
		' (set) Token: 0x060019E9 RID: 6633 RVA: 0x00005BCE File Offset: 0x00003DCE
		Friend Overridable Property lblMAKH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAKH = value
			End Set
		End Property

		' Token: 0x170008EC RID: 2284
		' (get) Token: 0x060019EA RID: 6634 RVA: 0x001429AC File Offset: 0x00140BAC
		' (set) Token: 0x060019EB RID: 6635 RVA: 0x001429C4 File Offset: 0x00140BC4
		Friend Overridable Property txtGHICHU As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtGHICHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtGHICHU IsNot Nothing
				If flag Then
					RemoveHandler Me._txtGHICHU.GotFocus, AddressOf Me.txtGHICHU_GotFocus
					RemoveHandler Me._txtGHICHU.KeyPress, AddressOf Me.txtGHICHU_KeyPress
				End If
				Me._txtGHICHU = value
				flag = Me._txtGHICHU IsNot Nothing
				If flag Then
					AddHandler Me._txtGHICHU.GotFocus, AddressOf Me.txtGHICHU_GotFocus
					AddHandler Me._txtGHICHU.KeyPress, AddressOf Me.txtGHICHU_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170008ED RID: 2285
		' (get) Token: 0x060019EC RID: 6636 RVA: 0x00142A60 File Offset: 0x00140C60
		' (set) Token: 0x060019ED RID: 6637 RVA: 0x00005BD8 File Offset: 0x00003DD8
		Friend Overridable Property lblMIN As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMIN
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMIN = value
			End Set
		End Property

		' Token: 0x170008EE RID: 2286
		' (get) Token: 0x060019EE RID: 6638 RVA: 0x00142A78 File Offset: 0x00140C78
		' (set) Token: 0x060019EF RID: 6639 RVA: 0x00005BE2 File Offset: 0x00003DE2
		Friend Overridable Property lblMAX As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAX = value
			End Set
		End Property

		' Token: 0x170008EF RID: 2287
		' (get) Token: 0x060019F0 RID: 6640 RVA: 0x00142A90 File Offset: 0x00140C90
		' (set) Token: 0x060019F1 RID: 6641 RVA: 0x00142AA8 File Offset: 0x00140CA8
		Friend Overridable Property txtTENKHU As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENKHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENKHU IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENKHU.GotFocus, AddressOf Me.txtTENKHU_GotFocus
					RemoveHandler Me._txtTENKHU.KeyPress, AddressOf Me.txtTENKHU_KeyPress
				End If
				Me._txtTENKHU = value
				flag = Me._txtTENKHU IsNot Nothing
				If flag Then
					AddHandler Me._txtTENKHU.GotFocus, AddressOf Me.txtTENKHU_GotFocus
					AddHandler Me._txtTENKHU.KeyPress, AddressOf Me.txtTENKHU_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170008F0 RID: 2288
		' (get) Token: 0x060019F2 RID: 6642 RVA: 0x00142B44 File Offset: 0x00140D44
		' (set) Token: 0x060019F3 RID: 6643 RVA: 0x00142B5C File Offset: 0x00140D5C
		Friend Overridable Property btnDMKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMKH.Click, AddressOf Me.btnDMKH_Click
				End If
				Me._btnDMKH = value
				flag = Me._btnDMKH IsNot Nothing
				If flag Then
					AddHandler Me._btnDMKH.Click, AddressOf Me.btnDMKH_Click
				End If
			End Set
		End Property

		' Token: 0x170008F1 RID: 2289
		' (get) Token: 0x060019F4 RID: 6644 RVA: 0x00142BC8 File Offset: 0x00140DC8
		' (set) Token: 0x060019F5 RID: 6645 RVA: 0x00142BE0 File Offset: 0x00140DE0
		Friend Overridable Property txtTENkho As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENkho
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENkho IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENkho.GotFocus, AddressOf Me.txtTENkho_GotFocus
				End If
				Me._txtTENkho = value
				flag = Me._txtTENkho IsNot Nothing
				If flag Then
					AddHandler Me._txtTENkho.GotFocus, AddressOf Me.txtTENkho_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170008F2 RID: 2290
		' (get) Token: 0x060019F6 RID: 6646 RVA: 0x00142C4C File Offset: 0x00140E4C
		' (set) Token: 0x060019F7 RID: 6647 RVA: 0x00142C64 File Offset: 0x00140E64
		Friend Overridable Property txtMAKHU As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKHU IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKHU.KeyPress, AddressOf Me.txtMAKHU_KeyPress
					RemoveHandler Me._txtMAKHU.GotFocus, AddressOf Me.txtMAKHU_GotFocus
				End If
				Me._txtMAKHU = value
				flag = Me._txtMAKHU IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKHU.KeyPress, AddressOf Me.txtMAKHU_KeyPress
					AddHandler Me._txtMAKHU.GotFocus, AddressOf Me.txtMAKHU_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170008F3 RID: 2291
		' (get) Token: 0x060019F8 RID: 6648 RVA: 0x00142D00 File Offset: 0x00140F00
		' (set) Token: 0x060019F9 RID: 6649 RVA: 0x00005BEC File Offset: 0x00003DEC
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170008F4 RID: 2292
		' (get) Token: 0x060019FA RID: 6650 RVA: 0x00142D18 File Offset: 0x00140F18
		' (set) Token: 0x060019FB RID: 6651 RVA: 0x00005BF6 File Offset: 0x00003DF6
		Friend Overridable Property cmbLevelPrice As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbLevelPrice
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Me._cmbLevelPrice = value
			End Set
		End Property

		' Token: 0x170008F5 RID: 2293
		' (get) Token: 0x060019FC RID: 6652 RVA: 0x00142D30 File Offset: 0x00140F30
		' (set) Token: 0x060019FD RID: 6653 RVA: 0x00005C00 File Offset: 0x00003E00
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x170008F6 RID: 2294
		' (get) Token: 0x060019FE RID: 6654 RVA: 0x00142D48 File Offset: 0x00140F48
		' (set) Token: 0x060019FF RID: 6655 RVA: 0x00005C0A File Offset: 0x00003E0A
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x170008F7 RID: 2295
		' (get) Token: 0x06001A00 RID: 6656 RVA: 0x00142D60 File Offset: 0x00140F60
		' (set) Token: 0x06001A01 RID: 6657 RVA: 0x00005C14 File Offset: 0x00003E14
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x170008F8 RID: 2296
		' (get) Token: 0x06001A02 RID: 6658 RVA: 0x00142D78 File Offset: 0x00140F78
		' (set) Token: 0x06001A03 RID: 6659 RVA: 0x00005C1E File Offset: 0x00003E1E
		Friend Overridable Property cmbStatusClose As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbStatusClose
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Me._cmbStatusClose = value
			End Set
		End Property

		' Token: 0x170008F9 RID: 2297
		' (get) Token: 0x06001A04 RID: 6660 RVA: 0x00142D90 File Offset: 0x00140F90
		' (set) Token: 0x06001A05 RID: 6661 RVA: 0x00005C28 File Offset: 0x00003E28
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x170008FA RID: 2298
		' (get) Token: 0x06001A06 RID: 6662 RVA: 0x00142DA8 File Offset: 0x00140FA8
		' (set) Token: 0x06001A07 RID: 6663 RVA: 0x00005C32 File Offset: 0x00003E32
		Friend Overridable Property txtPERSERVICE As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPERSERVICE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtPERSERVICE = value
			End Set
		End Property

		' Token: 0x170008FB RID: 2299
		' (get) Token: 0x06001A08 RID: 6664 RVA: 0x00142DC0 File Offset: 0x00140FC0
		' (set) Token: 0x06001A09 RID: 6665 RVA: 0x00142DD8 File Offset: 0x00140FD8
		Friend Overridable Property btnKey As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKey
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKey IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKey.Click, AddressOf Me.btnKey_Click
				End If
				Me._btnKey = value
				flag = Me._btnKey IsNot Nothing
				If flag Then
					AddHandler Me._btnKey.Click, AddressOf Me.btnKey_Click
				End If
			End Set
		End Property

		' Token: 0x170008FC RID: 2300
		' (get) Token: 0x06001A0A RID: 6666 RVA: 0x00142E44 File Offset: 0x00141044
		' (set) Token: 0x06001A0B RID: 6667 RVA: 0x00005C3C File Offset: 0x00003E3C
		Friend Overridable Property txtPERVAT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPERVAT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtPERVAT = value
			End Set
		End Property

		' Token: 0x170008FD RID: 2301
		' (get) Token: 0x06001A0C RID: 6668 RVA: 0x00142E5C File Offset: 0x0014105C
		' (set) Token: 0x06001A0D RID: 6669 RVA: 0x00005C46 File Offset: 0x00003E46
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x170008FE RID: 2302
		' (get) Token: 0x06001A0E RID: 6670 RVA: 0x00142E74 File Offset: 0x00141074
		' (set) Token: 0x06001A0F RID: 6671 RVA: 0x00142E8C File Offset: 0x0014108C
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x170008FF RID: 2303
		' (get) Token: 0x06001A10 RID: 6672 RVA: 0x00142EF8 File Offset: 0x001410F8
		' (set) Token: 0x06001A11 RID: 6673 RVA: 0x00005C50 File Offset: 0x00003E50
		Friend Overridable Property Label6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label6 = value
			End Set
		End Property

		' Token: 0x17000900 RID: 2304
		' (get) Token: 0x06001A12 RID: 6674 RVA: 0x00142F10 File Offset: 0x00141110
		' (set) Token: 0x06001A13 RID: 6675 RVA: 0x00005C5A File Offset: 0x00003E5A
		Friend Overridable Property chkLOnlyCash As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLOnlyCash
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLOnlyCash = value
			End Set
		End Property

		' Token: 0x17000901 RID: 2305
		' (get) Token: 0x06001A14 RID: 6676 RVA: 0x00142F28 File Offset: 0x00141128
		' (set) Token: 0x06001A15 RID: 6677 RVA: 0x00005C64 File Offset: 0x00003E64
		Friend Overridable Property chkLNotVAT As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLNotVAT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLNotVAT = value
			End Set
		End Property

		' Token: 0x17000902 RID: 2306
		' (get) Token: 0x06001A16 RID: 6678 RVA: 0x00142F40 File Offset: 0x00141140
		' (set) Token: 0x06001A17 RID: 6679 RVA: 0x00005C6E File Offset: 0x00003E6E
		Public Property pbytStatusClose As Byte
			Get
				Return Me.mbytStatus
			End Get
			Set(value As Byte)
				Me.mbytStatus = value
			End Set
		End Property

		' Token: 0x17000903 RID: 2307
		' (get) Token: 0x06001A18 RID: 6680 RVA: 0x00142F58 File Offset: 0x00141158
		' (set) Token: 0x06001A19 RID: 6681 RVA: 0x00005C79 File Offset: 0x00003E79
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000904 RID: 2308
		' (get) Token: 0x06001A1A RID: 6682 RVA: 0x00142F70 File Offset: 0x00141170
		' (set) Token: 0x06001A1B RID: 6683 RVA: 0x00005C84 File Offset: 0x00003E84
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000905 RID: 2309
		' (get) Token: 0x06001A1C RID: 6684 RVA: 0x00142F88 File Offset: 0x00141188
		' (set) Token: 0x06001A1D RID: 6685 RVA: 0x00005C8F File Offset: 0x00003E8F
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x17000906 RID: 2310
		' (get) Token: 0x06001A1E RID: 6686 RVA: 0x00142FA0 File Offset: 0x001411A0
		' (set) Token: 0x06001A1F RID: 6687 RVA: 0x00005C9A File Offset: 0x00003E9A
		Public Property pStrMAKH As String
			Get
				Return Me.mstrMAKH
			End Get
			Set(value As String)
				Me.mstrMAKH = value
			End Set
		End Property

		' Token: 0x06001A20 RID: 6688 RVA: 0x00142FB8 File Offset: 0x001411B8
		Private Sub txtMAKHU_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtTENKHU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHU_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001A21 RID: 6689 RVA: 0x0014305C File Offset: 0x0014125C
		Private Sub txtTENKHU_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMAKHO.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAHH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001A22 RID: 6690 RVA: 0x00143100 File Offset: 0x00141300
		Private Sub txtMAKHO_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtGHICHU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHO_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001A23 RID: 6691 RVA: 0x001431A4 File Offset: 0x001413A4
		Private Sub txtGHICHU_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Select Case Me.mbytFormStatus
						Case 1, 2, 3
							Me.btnSave.Focus()
						Case 4
							Me.btnExit.Focus()
						Case 5
							Me.btnFilter.Focus()
						Case 6
							Me.btnFind.Focus()
					End Select
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtGHICHU_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001A24 RID: 6692 RVA: 0x001432A4 File Offset: 0x001414A4
		Private Sub txtMAKHU_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMAKHU.[ReadOnly]
				If [readOnly] Then
					Me.txtTENKHU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHU_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A25 RID: 6693 RVA: 0x00143350 File Offset: 0x00141550
		Private Sub txtTENKHU_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENKHU.[ReadOnly]
				If [readOnly] Then
					Me.txtMAKHO.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENKHU_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A26 RID: 6694 RVA: 0x001433FC File Offset: 0x001415FC
		Private Sub txtMAKHO_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMAKHO.[ReadOnly]
				If [readOnly] Then
					Me.txtGHICHU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHO_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A27 RID: 6695 RVA: 0x001434A8 File Offset: 0x001416A8
		Private Sub txtTENkho_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENkho.[ReadOnly]
				If [readOnly] Then
					Me.txtGHICHU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENkho_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A28 RID: 6696 RVA: 0x00143554 File Offset: 0x00141754
		Private Sub txtGHICHU_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtGHICHU.[ReadOnly]
				If [readOnly] Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtGHICHU_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A29 RID: 6697 RVA: 0x00143600 File Offset: 0x00141800
		Private Sub frmDMKHU2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
				Me.txtMAKHO_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMKHU2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A2A RID: 6698 RVA: 0x001436BC File Offset: 0x001418BC
		Private Sub frmDMKHU2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMKH()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMKHU2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A2B RID: 6699 RVA: 0x0014377C File Offset: 0x0014197C
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtMAKHU.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(36), MsgBoxStyle.Critical, Nothing)
					Me.txtMAKHU.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtTENKHU.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
						Me.txtTENKHU.Focus()
					Else
						flag = Operators.CompareString(Strings.Trim(Me.txtMAKHO.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(40), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKHO.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.txtMAKHO.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENkho.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
								Me.txtMAKHO.Focus()
							Else
								flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
								If flag Then
									Me.mbytSuccess = Me.fAddNew()
								Else
									flag = Me.mbytFormStatus = 3 AndAlso Me.cmbLevelPrice.Visible
									If flag Then
										Me.mbytSuccess = Me.fModify()
									Else
										flag = Me.mbytFormStatus = 3 AndAlso Not Me.cmbLevelPrice.Visible
										If flag Then
											Me.mbytSuccess = Me.fModify_Ten()
										End If
									End If
								End If
								flag = Me.mbytSuccess = 1
								If flag Then
									Me.Close()
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A2C RID: 6700 RVA: 0x001439F4 File Offset: 0x00141BF4
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A2D RID: 6701 RVA: 0x00143A98 File Offset: 0x00141C98
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim flag As Boolean = (Operators.CompareString(Strings.Trim(Me.txtMAKHO.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENkho.Text), "", False) = 0)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Me.txtMAKHO.Focus()
				Else
					Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtMAKHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJID LIKE '"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtTENKHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME LIKE '"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtMAKHO.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH LIKE '"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtGHICHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK LIKE '"), text2), "%'"))
					End If
					Me.mStrFilter = text
					flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
					If flag Then
						Me.mbytSuccess = 1
					End If
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A2E RID: 6702 RVA: 0x00143DB0 File Offset: 0x00141FB0
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim flag As Boolean = (Operators.CompareString(Strings.Trim(Me.txtMAKHO.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENkho.Text), "", False) = 0)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Me.txtMAKHO.Focus()
				Else
					Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtMAKHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJID LIKE '"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtTENKHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME LIKE '"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtMAKHO.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH LIKE '"), text2), "%'"))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtGHICHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK LIKE '"), text2), "%'"))
					End If
					Me.mStrFilter = text
					flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
					If flag Then
						Me.mbytSuccess = 1
					End If
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A2F RID: 6703 RVA: 0x001440C8 File Offset: 0x001422C8
		Private Sub btnDMKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKH As frmDMKH1 = New frmDMKH1()
				frmDMKH.pBytOpen_From_Menu = 7
				frmDMKH.ShowDialog()
				Me.txtMAKHO.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJID, "", False) = 0, Me.txtMAKHO.Text, frmDMKH.pStrOBJID))
				Me.txtTENkho.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJNAME, "", False) = 0, Me.txtTENkho.Text, frmDMKH.pStrOBJNAME))
				frmDMKH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMKH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A30 RID: 6704 RVA: 0x001441EC File Offset: 0x001423EC
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.txtTENkho.[ReadOnly] = True
				Me.txtMAKHO.Text = Me.mstrMAKH
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtMAKHU.[ReadOnly] = True
						Me.txtMAKHU.BackColor = Me.txtTENkho.BackColor
						Me.txtTENKHU.Focus()
					Case 4
						Me.txtMAKHU.[ReadOnly] = True
						Me.txtTENKHU.[ReadOnly] = True
						Me.txtMAKHO.[ReadOnly] = True
						Me.txtGHICHU.[ReadOnly] = True
						Me.txtPERSERVICE.[ReadOnly] = True
						Me.txtMAKHU.BackColor = Me.txtTENkho.BackColor
						Me.txtTENKHU.BackColor = Me.txtTENkho.BackColor
						Me.txtMAKHO.BackColor = Me.txtTENkho.BackColor
						Me.txtGHICHU.BackColor = Me.txtTENkho.BackColor
						Me.txtPERSERVICE.BackColor = Me.txtTENkho.BackColor
						Me.cmbLevelPrice.Enabled = False
						Me.cmbStatusClose.Enabled = False
						Me.btnDMKH.Enabled = False
				End Select
				Dim flag As Boolean = Operators.CompareString(mdlVariable.gStrStockCode, "", False) <> 0
				If flag Then
					Me.txtMAKHO.[ReadOnly] = True
					Me.txtMAKHO.BackColor = Me.txtTENkho.BackColor
					Me.txtMAKHO.Text = mdlVariable.gStrStockCode
					Me.btnDMKH.Enabled = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001A31 RID: 6705 RVA: 0x0014444C File Offset: 0x0014264C
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtMAKHU.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtMAKHO.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001A32 RID: 6706 RVA: 0x001445DC File Offset: 0x001427DC
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtTENKHU.MaxLength = 50
				Me.txtMAKHU.MaxLength = 5
				Me.txtMAKHO.MaxLength = 3
				Me.txtMAKHO.Text = mdlVariable.gStrStockCode
				Me.txtMAKHO.CharacterCasing = CharacterCasing.Upper
				Me.txtMAKHU.CharacterCasing = CharacterCasing.Upper
				Dim dataTable As DataTable = New DataTable()
				dataTable.Columns.Add("OBJID")
				dataTable.Columns.Add("OBJNAME")
				dataTable.Rows.Add(New Object(-1) {})
				dataTable.Rows(0)("OBJID") = 0
				dataTable.Rows(0)("OBJNAME") = Me.mArrStrFrmMess(47)
				dataTable.Rows.Add(New Object(-1) {})
				dataTable.Rows(1)("OBJID") = 1
				dataTable.Rows(1)("OBJNAME") = Me.mArrStrFrmMess(48)
				dataTable.Rows.Add(New Object(-1) {})
				dataTable.Rows(2)("OBJID") = 2
				dataTable.Rows(2)("OBJNAME") = Me.mArrStrFrmMess(49)
				dataTable.Rows.Add(New Object(-1) {})
				dataTable.Rows(3)("OBJID") = 3
				dataTable.Rows(3)("OBJNAME") = Me.mArrStrFrmMess(50)
				dataTable.Rows.Add(New Object(-1) {})
				dataTable.Rows(4)("OBJID") = 4
				dataTable.Rows(4)("OBJNAME") = Me.mArrStrFrmMess(51)
				Me.cmbStatusClose.DataSource = dataTable
				Me.cmbStatusClose.ValueMember = "OBJID"
				Me.cmbStatusClose.DisplayMember = "OBJNAME"
				Me.cmbStatusClose.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbStatusClose.SelectedValue = Me.mbytStatus
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001A33 RID: 6707 RVA: 0x001448F8 File Offset: 0x00142AF8
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001A34 RID: 6708 RVA: 0x00144ACC File Offset: 0x00142CCC
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMKH.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A35 RID: 6709 RVA: 0x00144B78 File Offset: 0x00142D78
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(11) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pvchMA"
				array(0).Value = Strings.Trim(Me.txtMAKHU.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchTEn"
				array(1).Value = Strings.Trim(Me.txtTENKHU.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKHO.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchGHICHU"
				array(3).Value = Strings.Trim(Me.txtGHICHU.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@ptniLEVELPRICE"
				array(4).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Me.cmbLevelPrice.SelectedItem))
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@ptniSTATUSCLOSE"
				array(5).Value = RuntimeHelpers.GetObjectValue(Me.cmbStatusClose.SelectedValue)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@decPERSERVICE"
				array(7).Value = Conversion.Val(Me.txtPERSERVICE.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@decPERVAT"
				array(8).Value = Conversion.Val(Me.txtPERVAT.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pbitLONLYCASH"
				array(9).Value = Me.chkLOnlyCash.Checked
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pbitLNOTVAT"
				array(10).Value = Me.chkLNotVAT.Checked
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@int_Result"
				array(6).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKHU_INSERT_DMKHU", flag)
				Dim num As Integer = Conversions.ToInteger(array(6).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtMAKHU.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtMAKHO.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKHU.Focus()
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(42), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKHU.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001A36 RID: 6710 RVA: 0x00144F5C File Offset: 0x0014315C
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(11) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAKHU"
				array(0).Value = Strings.Trim(Me.txtMAKHU.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchTENKHU"
				array(1).Value = Strings.Trim(Me.txtTENKHU.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKHO.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchGHICHU"
				array(3).Value = Strings.Trim(Me.txtGHICHU.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@ptniLEVELPRICE"
				array(4).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Me.cmbLevelPrice.SelectedItem))
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@ptniSTATUSCLOSE"
				array(5).Value = RuntimeHelpers.GetObjectValue(Me.cmbStatusClose.SelectedValue)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@decPERSERVICE"
				array(7).Value = Conversion.Val(Me.txtPERSERVICE.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@decPERVAT"
				array(8).Value = Conversion.Val(Me.txtPERVAT.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pbitLONLYCASH"
				array(9).Value = Me.chkLOnlyCash.Checked
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pbitLNOTVAT"
				array(10).Value = Me.chkLNotVAT.Checked
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@int_Result"
				array(6).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKHU_UPDATE_DMKHU", flag)
				Dim num As Integer = Conversions.ToInteger(array(6).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtMAKHU.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(43), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001A37 RID: 6711 RVA: 0x00145328 File Offset: 0x00143528
		Private Function fModify_Ten() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAKHU"
				array(0).Value = Strings.Trim(Me.txtMAKHU.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchTENKHU"
				array(1).Value = Strings.Trim(Me.txtTENKHU.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKHO.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@int_Result"
				array(3).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKHU_UPDATE_DMKHU_TEN", flag)
				Dim num As Integer = Conversions.ToInteger(array(3).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtMAKHU.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(43), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001A38 RID: 6712 RVA: 0x0014556C File Offset: 0x0014376C
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtMAKHU.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKHU_DELETE_DMKHU", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 2
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001A39 RID: 6713 RVA: 0x00145714 File Offset: 0x00143914
		Private Function fGetData_DMKH() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKH = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = Me.mclsTbDMKH IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMKH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001A3A RID: 6714 RVA: 0x001457D0 File Offset: 0x001439D0
		Private Sub txtMAKHO_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKH Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMKH.Columns("OBJID")
					Me.mclsTbDMKH.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKH.Rows.Find(Strings.Trim(Me.txtMAKHO.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENkho.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENkho.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A3B RID: 6715 RVA: 0x00145924 File Offset: 0x00143B24
		Private Sub btnKey_Click(sender As Object, e As EventArgs)
			Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
			frmKeyBoard.pStrEnterText = Me.txtTENKHU.Text.Trim()
			frmKeyBoard.ShowDialog()
			Dim pBlnOK As Boolean = frmKeyBoard.pBlnOK
			If pBlnOK Then
				Me.txtTENKHU.Text = frmKeyBoard.pStrEnterText.Trim()
			End If
		End Sub

		' Token: 0x06001A3C RID: 6716 RVA: 0x0014597C File Offset: 0x00143B7C
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtMAKHU.[ReadOnly]
				If flag Then
					Me.txtTENKHU.Focus()
					Me.txtTENKHU.SelectAll()
				Else
					Me.txtMAKHU.Focus()
					Me.txtMAKHU.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x06001A3D RID: 6717 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x04000AAB RID: 2731
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000AAD RID: 2733
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000AAE RID: 2734
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000AAF RID: 2735
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000AB0 RID: 2736
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000AB1 RID: 2737
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000AB2 RID: 2738
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000AB3 RID: 2739
		<AccessedThroughProperty("lblMAHH")>
		Private _lblMAHH As Label

		' Token: 0x04000AB4 RID: 2740
		<AccessedThroughProperty("txtMAKHO")>
		Private _txtMAKHO As TextBox

		' Token: 0x04000AB5 RID: 2741
		<AccessedThroughProperty("lblMAKH")>
		Private _lblMAKH As Label

		' Token: 0x04000AB6 RID: 2742
		<AccessedThroughProperty("txtGHICHU")>
		Private _txtGHICHU As TextBox

		' Token: 0x04000AB7 RID: 2743
		<AccessedThroughProperty("lblMIN")>
		Private _lblMIN As Label

		' Token: 0x04000AB8 RID: 2744
		<AccessedThroughProperty("lblMAX")>
		Private _lblMAX As Label

		' Token: 0x04000AB9 RID: 2745
		<AccessedThroughProperty("txtTENKHU")>
		Private _txtTENKHU As TextBox

		' Token: 0x04000ABA RID: 2746
		<AccessedThroughProperty("btnDMKH")>
		Private _btnDMKH As Button

		' Token: 0x04000ABB RID: 2747
		<AccessedThroughProperty("txtTENkho")>
		Private _txtTENkho As TextBox

		' Token: 0x04000ABC RID: 2748
		<AccessedThroughProperty("txtMAKHU")>
		Private _txtMAKHU As TextBox

		' Token: 0x04000ABD RID: 2749
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000ABE RID: 2750
		<AccessedThroughProperty("cmbLevelPrice")>
		Private _cmbLevelPrice As ComboBox

		' Token: 0x04000ABF RID: 2751
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000AC0 RID: 2752
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000AC1 RID: 2753
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x04000AC2 RID: 2754
		<AccessedThroughProperty("cmbStatusClose")>
		Private _cmbStatusClose As ComboBox

		' Token: 0x04000AC3 RID: 2755
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x04000AC4 RID: 2756
		<AccessedThroughProperty("txtPERSERVICE")>
		Private _txtPERSERVICE As TextBox

		' Token: 0x04000AC5 RID: 2757
		<AccessedThroughProperty("btnKey")>
		Private _btnKey As Button

		' Token: 0x04000AC6 RID: 2758
		<AccessedThroughProperty("txtPERVAT")>
		Private _txtPERVAT As TextBox

		' Token: 0x04000AC7 RID: 2759
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x04000AC8 RID: 2760
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000AC9 RID: 2761
		<AccessedThroughProperty("Label6")>
		Private _Label6 As Label

		' Token: 0x04000ACA RID: 2762
		<AccessedThroughProperty("chkLOnlyCash")>
		Private _chkLOnlyCash As CheckBox

		' Token: 0x04000ACB RID: 2763
		<AccessedThroughProperty("chkLNotVAT")>
		Private _chkLNotVAT As CheckBox

		' Token: 0x04000ACC RID: 2764
		Private mArrStrFrmMess As String()

		' Token: 0x04000ACD RID: 2765
		Private mbytFormStatus As Byte

		' Token: 0x04000ACE RID: 2766
		Private mbytSuccess As Byte

		' Token: 0x04000ACF RID: 2767
		Private mStrFilter As String

		' Token: 0x04000AD0 RID: 2768
		Private mclsTbDMKH As clsConnect

		' Token: 0x04000AD1 RID: 2769
		Private mstrMAKH As String

		' Token: 0x04000AD2 RID: 2770
		Private mbytStatus As Byte
	End Class
End Namespace
