﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000042 RID: 66
	<DesignerGenerated()>
	Public Partial Class frmDMDV1
		Inherits Form

		' Token: 0x06000FFC RID: 4092 RVA: 0x000BE118 File Offset: 0x000BC318
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMDV1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMDV1_Load
			frmDMDV1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mclsTbNHDV = New clsConnect()
			Me.mIntType = 4S
			Me.mblnAutoAdd_DMDV = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x170005A0 RID: 1440
		' (get) Token: 0x06000FFF RID: 4095 RVA: 0x000BFB20 File Offset: 0x000BDD20
		' (set) Token: 0x06001000 RID: 4096 RVA: 0x00004816 File Offset: 0x00002A16
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x170005A1 RID: 1441
		' (get) Token: 0x06001001 RID: 4097 RVA: 0x000BFB38 File Offset: 0x000BDD38
		' (set) Token: 0x06001002 RID: 4098 RVA: 0x000BFB50 File Offset: 0x000BDD50
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x170005A2 RID: 1442
		' (get) Token: 0x06001003 RID: 4099 RVA: 0x000BFBBC File Offset: 0x000BDDBC
		' (set) Token: 0x06001004 RID: 4100 RVA: 0x000BFBD4 File Offset: 0x000BDDD4
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170005A3 RID: 1443
		' (get) Token: 0x06001005 RID: 4101 RVA: 0x000BFC40 File Offset: 0x000BDE40
		' (set) Token: 0x06001006 RID: 4102 RVA: 0x000BFC58 File Offset: 0x000BDE58
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x170005A4 RID: 1444
		' (get) Token: 0x06001007 RID: 4103 RVA: 0x000BFCC4 File Offset: 0x000BDEC4
		' (set) Token: 0x06001008 RID: 4104 RVA: 0x000BFCDC File Offset: 0x000BDEDC
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x170005A5 RID: 1445
		' (get) Token: 0x06001009 RID: 4105 RVA: 0x000BFD48 File Offset: 0x000BDF48
		' (set) Token: 0x0600100A RID: 4106 RVA: 0x000BFD60 File Offset: 0x000BDF60
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170005A6 RID: 1446
		' (get) Token: 0x0600100B RID: 4107 RVA: 0x000BFDCC File Offset: 0x000BDFCC
		' (set) Token: 0x0600100C RID: 4108 RVA: 0x000BFDE4 File Offset: 0x000BDFE4
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x170005A7 RID: 1447
		' (get) Token: 0x0600100D RID: 4109 RVA: 0x000BFE50 File Offset: 0x000BE050
		' (set) Token: 0x0600100E RID: 4110 RVA: 0x000BFE68 File Offset: 0x000BE068
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170005A8 RID: 1448
		' (get) Token: 0x0600100F RID: 4111 RVA: 0x000BFED4 File Offset: 0x000BE0D4
		' (set) Token: 0x06001010 RID: 4112 RVA: 0x00004820 File Offset: 0x00002A20
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x170005A9 RID: 1449
		' (get) Token: 0x06001011 RID: 4113 RVA: 0x000BFEEC File Offset: 0x000BE0EC
		' (set) Token: 0x06001012 RID: 4114 RVA: 0x000BFF04 File Offset: 0x000BE104
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x170005AA RID: 1450
		' (get) Token: 0x06001013 RID: 4115 RVA: 0x000BFF70 File Offset: 0x000BE170
		' (set) Token: 0x06001014 RID: 4116 RVA: 0x000BFF88 File Offset: 0x000BE188
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x170005AB RID: 1451
		' (get) Token: 0x06001015 RID: 4117 RVA: 0x000BFFF4 File Offset: 0x000BE1F4
		' (set) Token: 0x06001016 RID: 4118 RVA: 0x000C000C File Offset: 0x000BE20C
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170005AC RID: 1452
		' (get) Token: 0x06001017 RID: 4119 RVA: 0x000C0078 File Offset: 0x000BE278
		' (set) Token: 0x06001018 RID: 4120 RVA: 0x0000482A File Offset: 0x00002A2A
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170005AD RID: 1453
		' (get) Token: 0x06001019 RID: 4121 RVA: 0x000C0090 File Offset: 0x000BE290
		' (set) Token: 0x0600101A RID: 4122 RVA: 0x000C00A8 File Offset: 0x000BE2A8
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x170005AE RID: 1454
		' (get) Token: 0x0600101B RID: 4123 RVA: 0x000C0114 File Offset: 0x000BE314
		' (set) Token: 0x0600101C RID: 4124 RVA: 0x000C012C File Offset: 0x000BE32C
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x170005AF RID: 1455
		' (get) Token: 0x0600101D RID: 4125 RVA: 0x000C0198 File Offset: 0x000BE398
		' (set) Token: 0x0600101E RID: 4126 RVA: 0x000C01B0 File Offset: 0x000BE3B0
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170005B0 RID: 1456
		' (get) Token: 0x0600101F RID: 4127 RVA: 0x000C021C File Offset: 0x000BE41C
		' (set) Token: 0x06001020 RID: 4128 RVA: 0x000C0234 File Offset: 0x000BE434
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x170005B1 RID: 1457
		' (get) Token: 0x06001021 RID: 4129 RVA: 0x000C02A0 File Offset: 0x000BE4A0
		' (set) Token: 0x06001022 RID: 4130 RVA: 0x000C02B8 File Offset: 0x000BE4B8
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170005B2 RID: 1458
		' (get) Token: 0x06001023 RID: 4131 RVA: 0x000C0324 File Offset: 0x000BE524
		' (set) Token: 0x06001024 RID: 4132 RVA: 0x000C033C File Offset: 0x000BE53C
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x170005B3 RID: 1459
		' (get) Token: 0x06001025 RID: 4133 RVA: 0x000C03A8 File Offset: 0x000BE5A8
		' (set) Token: 0x06001026 RID: 4134 RVA: 0x00004834 File Offset: 0x00002A34
		Friend Overridable Property lblStore As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblStore
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblStore = value
			End Set
		End Property

		' Token: 0x170005B4 RID: 1460
		' (get) Token: 0x06001027 RID: 4135 RVA: 0x000C03C0 File Offset: 0x000BE5C0
		' (set) Token: 0x06001028 RID: 4136 RVA: 0x0000483E File Offset: 0x00002A3E
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170005B5 RID: 1461
		' (get) Token: 0x06001029 RID: 4137 RVA: 0x000C03D8 File Offset: 0x000BE5D8
		' (set) Token: 0x0600102A RID: 4138 RVA: 0x00004848 File Offset: 0x00002A48
		Friend Overridable Property txtOBJNAMENHDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAMENHDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAMENHDV = value
			End Set
		End Property

		' Token: 0x170005B6 RID: 1462
		' (get) Token: 0x0600102B RID: 4139 RVA: 0x000C03F0 File Offset: 0x000BE5F0
		' (set) Token: 0x0600102C RID: 4140 RVA: 0x000C0408 File Offset: 0x000BE608
		Friend Overridable Property btnSelectNHDV As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelectNHDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelectNHDV IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelectNHDV.Click, AddressOf Me.btnSelectNHDV_Click
				End If
				Me._btnSelectNHDV = value
				flag = Me._btnSelectNHDV IsNot Nothing
				If flag Then
					AddHandler Me._btnSelectNHDV.Click, AddressOf Me.btnSelectNHDV_Click
				End If
			End Set
		End Property

		' Token: 0x170005B7 RID: 1463
		' (get) Token: 0x0600102D RID: 4141 RVA: 0x000C0474 File Offset: 0x000BE674
		' (set) Token: 0x0600102E RID: 4142 RVA: 0x000C048C File Offset: 0x000BE68C
		Friend Overridable Property txtOBJIDNHDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJIDNHDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJIDNHDV IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJIDNHDV.TextChanged, AddressOf Me.txtOBJIDNHDV_TextChanged
				End If
				Me._txtOBJIDNHDV = value
				flag = Me._txtOBJIDNHDV IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJIDNHDV.TextChanged, AddressOf Me.txtOBJIDNHDV_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170005B8 RID: 1464
		' (get) Token: 0x0600102F RID: 4143 RVA: 0x000C04F8 File Offset: 0x000BE6F8
		' (set) Token: 0x06001030 RID: 4144 RVA: 0x000C0510 File Offset: 0x000BE710
		Friend Overridable Property btnSendMail As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSendMail
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSendMail IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSendMail.Click, AddressOf Me.btnSendMail_Click
				End If
				Me._btnSendMail = value
				flag = Me._btnSendMail IsNot Nothing
				If flag Then
					AddHandler Me._btnSendMail.Click, AddressOf Me.btnSendMail_Click
				End If
			End Set
		End Property

		' Token: 0x170005B9 RID: 1465
		' (get) Token: 0x06001031 RID: 4145 RVA: 0x000C057C File Offset: 0x000BE77C
		' (set) Token: 0x06001032 RID: 4146 RVA: 0x000C0594 File Offset: 0x000BE794
		Friend Overridable Property cboLoaiDV As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cboLoaiDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cboLoaiDV IsNot Nothing
				If flag Then
					RemoveHandler Me._cboLoaiDV.SelectedIndexChanged, AddressOf Me.cboLoaiDV_SelectedIndexChanged
				End If
				Me._cboLoaiDV = value
				flag = Me._cboLoaiDV IsNot Nothing
				If flag Then
					AddHandler Me._cboLoaiDV.SelectedIndexChanged, AddressOf Me.cboLoaiDV_SelectedIndexChanged
				End If
			End Set
		End Property

		' Token: 0x170005BA RID: 1466
		' (get) Token: 0x06001033 RID: 4147 RVA: 0x000C0600 File Offset: 0x000BE800
		' (set) Token: 0x06001034 RID: 4148 RVA: 0x000C0618 File Offset: 0x000BE818
		Friend Overridable Property btnImportExcel2 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnImportExcel2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnImportExcel2 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnImportExcel2.Click, AddressOf Me.btnImportExcel_Click
				End If
				Me._btnImportExcel2 = value
				flag = Me._btnImportExcel2 IsNot Nothing
				If flag Then
					AddHandler Me._btnImportExcel2.Click, AddressOf Me.btnImportExcel_Click
				End If
			End Set
		End Property

		' Token: 0x170005BB RID: 1467
		' (get) Token: 0x06001035 RID: 4149 RVA: 0x000C0684 File Offset: 0x000BE884
		' (set) Token: 0x06001036 RID: 4150 RVA: 0x000C069C File Offset: 0x000BE89C
		Friend Overridable Property btnQLKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnQLKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnQLKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnQLKH.Click, AddressOf Me.btnQLKH_Click
				End If
				Me._btnQLKH = value
				flag = Me._btnQLKH IsNot Nothing
				If flag Then
					AddHandler Me._btnQLKH.Click, AddressOf Me.btnQLKH_Click
				End If
			End Set
		End Property

		' Token: 0x170005BC RID: 1468
		' (get) Token: 0x06001037 RID: 4151 RVA: 0x000C0708 File Offset: 0x000BE908
		' (set) Token: 0x06001038 RID: 4152 RVA: 0x000C0720 File Offset: 0x000BE920
		Friend Overridable Property btnIm As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnIm
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnIm IsNot Nothing
				If flag Then
					RemoveHandler Me._btnIm.Click, AddressOf Me.btnIm_Click
				End If
				Me._btnIm = value
				flag = Me._btnIm IsNot Nothing
				If flag Then
					AddHandler Me._btnIm.Click, AddressOf Me.btnIm_Click
				End If
			End Set
		End Property

		' Token: 0x170005BD RID: 1469
		' (get) Token: 0x06001039 RID: 4153 RVA: 0x000C078C File Offset: 0x000BE98C
		' (set) Token: 0x0600103A RID: 4154 RVA: 0x000C07A4 File Offset: 0x000BE9A4
		Friend Overridable Property btnEx As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnEx
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnEx IsNot Nothing
				If flag Then
					RemoveHandler Me._btnEx.Click, AddressOf Me.btnEx_Click
				End If
				Me._btnEx = value
				flag = Me._btnEx IsNot Nothing
				If flag Then
					AddHandler Me._btnEx.Click, AddressOf Me.btnEx_Click
				End If
			End Set
		End Property

		' Token: 0x170005BE RID: 1470
		' (get) Token: 0x0600103B RID: 4155 RVA: 0x000C0810 File Offset: 0x000BEA10
		' (set) Token: 0x0600103C RID: 4156 RVA: 0x000C0828 File Offset: 0x000BEA28
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170005BF RID: 1471
		' (get) Token: 0x0600103D RID: 4157 RVA: 0x000C0894 File Offset: 0x000BEA94
		' (set) Token: 0x0600103E RID: 4158 RVA: 0x00004852 File Offset: 0x00002A52
		Public Property pIntType As Short
			Get
				Return Me.mIntType
			End Get
			Set(value As Short)
				Me.mIntType = value
			End Set
		End Property

		' Token: 0x170005C0 RID: 1472
		' (get) Token: 0x0600103F RID: 4159 RVA: 0x000C08AC File Offset: 0x000BEAAC
		' (set) Token: 0x06001040 RID: 4160 RVA: 0x0000485D File Offset: 0x00002A5D
		Public Property pStrMANHOMDV As String
			Get
				Return Me.mStrMANHOMDV
			End Get
			Set(value As String)
				Me.mStrMANHOMDV = value
			End Set
		End Property

		' Token: 0x170005C1 RID: 1473
		' (get) Token: 0x06001041 RID: 4161 RVA: 0x000C08C4 File Offset: 0x000BEAC4
		' (set) Token: 0x06001042 RID: 4162 RVA: 0x00004868 File Offset: 0x00002A68
		Public Property pStrPhone As String
			Get
				Return Me.mStrPhone
			End Get
			Set(value As String)
				Me.mStrPhone = value
			End Set
		End Property

		' Token: 0x170005C2 RID: 1474
		' (get) Token: 0x06001043 RID: 4163 RVA: 0x000C08DC File Offset: 0x000BEADC
		' (set) Token: 0x06001044 RID: 4164 RVA: 0x00004873 File Offset: 0x00002A73
		Public Property pStrEmail As String
			Get
				Return Me.mStrEmail
			End Get
			Set(value As String)
				Me.mStrEmail = value
			End Set
		End Property

		' Token: 0x170005C3 RID: 1475
		' (get) Token: 0x06001045 RID: 4165 RVA: 0x000C08F4 File Offset: 0x000BEAF4
		' (set) Token: 0x06001046 RID: 4166 RVA: 0x0000487E File Offset: 0x00002A7E
		Public Property pStrContact As String
			Get
				Return Me.mStrContact
			End Get
			Set(value As String)
				Me.mStrContact = value
			End Set
		End Property

		' Token: 0x170005C4 RID: 1476
		' (get) Token: 0x06001047 RID: 4167 RVA: 0x000C090C File Offset: 0x000BEB0C
		' (set) Token: 0x06001048 RID: 4168 RVA: 0x00004889 File Offset: 0x00002A89
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x170005C5 RID: 1477
		' (get) Token: 0x06001049 RID: 4169 RVA: 0x000C0924 File Offset: 0x000BEB24
		' (set) Token: 0x0600104A RID: 4170 RVA: 0x00004894 File Offset: 0x00002A94
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x170005C6 RID: 1478
		' (get) Token: 0x0600104B RID: 4171 RVA: 0x000C093C File Offset: 0x000BEB3C
		' (set) Token: 0x0600104C RID: 4172 RVA: 0x0000489F File Offset: 0x00002A9F
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x0600104D RID: 4173 RVA: 0x000C0954 File Offset: 0x000BEB54
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				Me.mStrOBJNAME = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				Me.mStrMANHOMDV = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
				Me.mStrPhone = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MOBILE").Value, ""))
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600104E RID: 4174 RVA: 0x000C0AD4 File Offset: 0x000BECD4
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600104F RID: 4175 RVA: 0x000C0BA4 File Offset: 0x000BEDA4
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001050 RID: 4176 RVA: 0x000C0C94 File Offset: 0x000BEE94
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001051 RID: 4177 RVA: 0x000C0D78 File Offset: 0x000BEF78
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001052 RID: 4178 RVA: 0x000C0E3C File Offset: 0x000BF03C
		Private Sub frmDMDV1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDV1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001053 RID: 4179 RVA: 0x000C0ED4 File Offset: 0x000BF0D4
		Private Sub frmDMDV1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				Me.sGetPara_From_SetparaXML()
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Combo()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
				flag = mdlUIForm.gfChek_RightSale("00089", False) = 1
				If flag Then
					Me.btnQLKH.Visible = True
				End If
				Me.fGetData_4Combo_LoaiDV()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDV1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001054 RID: 4180 RVA: 0x000C1034 File Offset: 0x000BF234
		Private Function fGetData_4Combo_LoaiDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim dataTable As DataTable = New DataTable()
				dataTable.Columns.Add("GIATRI")
				dataTable.Columns.Add("TEN")
				dataTable.Rows.Add(New Object() { 0, Me.mArrStrFrmMess(51) })
				dataTable.Rows.Add(New Object() { 1, Me.mArrStrFrmMess(52) })
				dataTable.Rows.Add(New Object() { 2, Me.mArrStrFrmMess(53) })
				dataTable.Rows.Add(New Object() { 3, Me.mArrStrFrmMess(54) })
				dataTable.Rows.Add(New Object() { 4, Me.mArrStrFrmMess(55) })
				Dim cboLoaiDV As ComboBox = Me.cboLoaiDV
				cboLoaiDV.DataSource = dataTable
				cboLoaiDV.DisplayMember = "TEN"
				cboLoaiDV.ValueMember = "GIATRI"
				cboLoaiDV.SelectedIndex = 0
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo_LoaiDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001055 RID: 4181 RVA: 0x000C1220 File Offset: 0x000BF420
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001056 RID: 4182 RVA: 0x000C1328 File Offset: 0x000BF528
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001057 RID: 4183 RVA: 0x000C13C0 File Offset: 0x000BF5C0
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMDV As frmDMDV2 = New frmDMDV2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMDV.pbytFromStatus = 1
				frmDMDV.chkISCUS.Checked = True
				Dim flag As Boolean = Me.mbdsSource.Count > 0
				If flag Then
					frmDMDV.pStrStore = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				End If
				flag = Me.mblnAutoAdd_DMDV
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim num As Integer
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_GET_MAX_OBJID", num)
					flag = clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
					If flag Then
						frmDMDV.txtOBJID.Text = clsConnect.Rows(0)("OBJID").ToString()
						frmDMDV.txtOBJID.[ReadOnly] = True
						frmDMDV.txtOBJID.BackColor = frmDMDV.txtColor.BackColor
					End If
				End If
				frmDMDV.ShowDialog()
				flag = frmDMDV.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0 AndAlso Not Me.mblnAutoAdd_DMDV
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMDV.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						' The following expression was wrapped in a checked-expression
						Me.mbdsSource.Position = Me.mbdsSource.Count - 1
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					flag = frmDMDV.pblnSaveAndSelect AndAlso Me.pBytOpen_From_Menu <> 8
					If flag Then
						Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMDV.Dispose()
			End Try
		End Sub

		' Token: 0x06001058 RID: 4184 RVA: 0x000C16C4 File Offset: 0x000BF8C4
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMDV As frmDMDV2 = New frmDMDV2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMDV2 As frmDMDV2 = frmDMDV
				frmDMDV2.pbytFromStatus = 2
				frmDMDV2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMDV2.pStrStore = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMDV2.txtADDRESS.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("ADDRESS").Value, ""))
				frmDMDV2.txtTEL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TEL").Value, ""))
				frmDMDV2.txtMOBILE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MOBILE").Value, ""))
				frmDMDV2.txtCONTACT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CONTACT").Value, ""))
				frmDMDV2.txtVATCODE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("VATCODE").Value, ""))
				frmDMDV2.txtFAX.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FAX").Value, ""))
				frmDMDV2.txtEMAIL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("EMAIL").Value, ""))
				frmDMDV2.txtWEBSITE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("WEBSITE").Value, ""))
				frmDMDV2.pStrBIRTHDAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BIRTHDAY").Value, ""))
				frmDMDV2.TxtMANHOMDV.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
				frmDMDV2.txtJOB.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("JOB").Value, ""))
				frmDMDV2.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMDV2.txtTUOI.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUOI").Value, ""))
				frmDMDV2.pBytGIOITINH = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("GIOITINH").Value)
				frmDMDV2.txtCAP.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CAP").Value, ""))
				frmDMDV2.txtCHUCVU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CHUCVU").Value, ""))
				frmDMDV2.txtMucGiamGia.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MUCGIAMGIA").Value, "")), CShort(mdlVariable.gbytDECNUMAMT), ",")
				frmDMDV2.chkISCUS.Checked = False
				frmDMDV2.chkISFOR.Checked = False
				frmDMDV2.chkISORG.Checked = False
				frmDMDV2.chkISSUP.Checked = False
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISSUP").Value)
				If flag Then
					frmDMDV2.chkISSUP.Checked = True
				End If
				flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISCUS").Value)
				If flag Then
					frmDMDV2.chkISCUS.Checked = True
				End If
				flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISFOR").Value)
				If flag Then
					frmDMDV2.chkISFOR.Checked = True
				End If
				flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISORG").Value)
				If flag Then
					frmDMDV2.chkISORG.Checked = True
				End If
				frmDMDV2.txtMaUser.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAUSERLK").Value, ""))
				flag = Me.mblnAutoAdd_DMDV
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim num As Integer
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_GET_MAX_OBJID", num)
					flag = clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
					If flag Then
						frmDMDV.txtOBJID.Text = clsConnect.Rows(0)("OBJID").ToString()
						frmDMDV.txtOBJID.[ReadOnly] = True
						frmDMDV.txtOBJID.BackColor = frmDMDV.txtColor.BackColor
					End If
				End If
				frmDMDV.ShowDialog()
				flag = frmDMDV.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0 AndAlso Not Me.mblnAutoAdd_DMDV
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMDV.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						' The following expression was wrapped in a checked-expression
						Me.mbdsSource.Position = Me.mbdsSource.Count - 1
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					flag = frmDMDV.pblnSaveAndSelect AndAlso Me.pBytOpen_From_Menu <> 8
					If flag Then
						Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMDV.Dispose()
			End Try
		End Sub

		' Token: 0x06001059 RID: 4185 RVA: 0x000C1F24 File Offset: 0x000C0124
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMDV As frmDMDV2 = New frmDMDV2()
			Try
				Dim flag As Boolean = Me.dgvData.SelectedRows.Count > 1
				If flag Then
					Dim text As String = ""
					Try
						For Each obj As Object In Me.dgvData.SelectedRows
							Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
							flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
							If Not flag Then
								text = text + dataGridViewRow.Cells("OBJID").Value.ToString().Trim() + ";"
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag = TypeOf enumerator Is IDisposable
						If flag Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
					flag = text.Trim().Length > 0 AndAlso text.Trim().EndsWith(";")
					If flag Then
						' The following expression was wrapped in a checked-expression
						text = text.Trim().Substring(0, text.Trim().Length - 1)
						Dim frmDMDV2 As frmDMDV2 = frmDMDV
						frmDMDV2.pbytFromStatus = 3
						frmDMDV2.txtOBJID.Text = text
						frmDMDV2.txtOBJNAME.Text = ""
						frmDMDV2.pStrStore = ""
						frmDMDV2.txtADDRESS.Text = ""
						frmDMDV2.txtTEL.Text = ""
						frmDMDV2.txtMOBILE.Text = ""
						frmDMDV2.txtCONTACT.Text = ""
						frmDMDV2.txtVATCODE.Text = ""
						frmDMDV2.txtFAX.Text = ""
						frmDMDV2.txtEMAIL.Text = ""
						frmDMDV2.txtWEBSITE.Text = ""
						frmDMDV2.pStrBIRTHDAY = ""
						frmDMDV2.TxtMANHOMDV.Text = ""
						frmDMDV2.txtJOB.Text = ""
						frmDMDV2.txtRemark.Text = ""
						frmDMDV2.txtTUOI.Text = ""
						frmDMDV2.pBytGIOITINH = 0
						frmDMDV2.txtCAP.Text = ""
						frmDMDV2.txtCHUCVU.Text = ""
						frmDMDV2.txtMucGiamGia.Text = ""
						frmDMDV2.pStrFinger1 = ""
						frmDMDV2.pStrFinger2 = ""
						frmDMDV2.pStrFinger3 = ""
						frmDMDV2.txtCardCode.Text = ""
						frmDMDV2.pStrNgayNhanViec = ""
						frmDMDV2.pStrNgayThoiViec = ""
						Try
							frmDMDV2.pstrUIMAGE = ""
							frmDMDV2.picAnh.BackgroundImage = Nothing
						Catch ex As Exception
						End Try
						frmDMDV2.chkISSUP.Checked = True
						frmDMDV2.chkISCUS.Checked = True
						frmDMDV2.chkISFOR.Checked = True
						frmDMDV2.chkISORG.Checked = True
						frmDMDV2 = Nothing
						frmDMDV.pBlnModifyMulti = True
						frmDMDV.ShowDialog()
					End If
				Else
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
						frmDMDV.Dispose()
						Return
					End If
					flag = mdlVariable.gblnLRIGHTFORUSER AndAlso Operators.CompareString(mdlVariable.gStrUser.Trim(), Me.dgvData.CurrentRow.Cells("MAUSERUP").Value.ToString().Trim(), False) <> 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(41), MsgBoxStyle.Critical, Nothing)
						frmDMDV.Dispose()
						Return
					End If
					Dim frmDMDV3 As frmDMDV2 = frmDMDV
					frmDMDV3.pbytFromStatus = 3
					frmDMDV3.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMDV3.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMDV3.pStrStore = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
					frmDMDV3.txtADDRESS.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("ADDRESS").Value, ""))
					frmDMDV3.txtTEL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TEL").Value, ""))
					frmDMDV3.txtMOBILE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MOBILE").Value, ""))
					frmDMDV3.txtCONTACT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CONTACT").Value, ""))
					frmDMDV3.txtVATCODE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("VATCODE").Value, ""))
					frmDMDV3.txtFAX.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FAX").Value, ""))
					frmDMDV3.txtEMAIL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("EMAIL").Value, ""))
					frmDMDV3.txtWEBSITE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("WEBSITE").Value, ""))
					frmDMDV3.pStrBIRTHDAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BIRTHDAY").Value, ""))
					frmDMDV3.TxtMANHOMDV.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
					frmDMDV3.txtJOB.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("JOB").Value, ""))
					frmDMDV3.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
					frmDMDV3.txtTUOI.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUOI").Value, ""))
					frmDMDV3.pBytGIOITINH = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("GIOITINH").Value)
					frmDMDV3.txtCAP.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("CAP").Value)
					frmDMDV3.txtCHUCVU.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("CHUCVU").Value)
					frmDMDV3.txtMucGiamGia.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MUCGIAMGIA").Value, "")), CShort(mdlVariable.gbytDECNUMAMT), ",")
					frmDMDV3.pStrFinger1 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER1").Value)
					frmDMDV3.pStrFinger2 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER2").Value)
					frmDMDV3.pStrFinger3 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER3").Value)
					frmDMDV3.txtCardCode.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("CARDCODE").Value)
					frmDMDV3.pStrNgayNhanViec = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("NGAYNHANVIEC").Value, ""))
					frmDMDV3.pStrNgayThoiViec = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("NGAYTHOIVIEC").Value, ""))
					Try
						frmDMDV3.pstrUIMAGE = Me.dgvData.CurrentRow.Cells("UIMAGE").Value.ToString().Trim()
						frmDMDV3.picAnh.BackgroundImage = Image.FromFile(Me.dgvData.CurrentRow.Cells("UIMAGE").Value.ToString().Trim())
					Catch ex2 As Exception
					End Try
					frmDMDV3.chkISCUS.Checked = False
					frmDMDV3.chkISFOR.Checked = False
					frmDMDV3.chkISORG.Checked = False
					frmDMDV3.chkISSUP.Checked = False
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISSUP").Value)
					If flag Then
						frmDMDV3.chkISSUP.Checked = True
					End If
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISCUS").Value)
					If flag Then
						frmDMDV3.chkISCUS.Checked = True
					End If
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISFOR").Value)
					If flag Then
						frmDMDV3.chkISFOR.Checked = True
					End If
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISORG").Value)
					If flag Then
						frmDMDV3.chkISORG.Checked = True
					End If
					frmDMDV3.txtMaUser.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAUSERLK").Value, ""))
					frmDMDV3 = Nothing
					frmDMDV.ShowDialog()
					flag = frmDMDV.pbytSuccess = 0
					If flag Then
						Return
					End If
				End If
				Dim b As Byte = Me.fGetData_4Grid()
				flag = b = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMDV.pStrFilter)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
				flag = frmDMDV.pblnSaveAndSelect AndAlso Me.pBytOpen_From_Menu <> 8
				If flag Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex3 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex3.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDV.Dispose()
			End Try
		End Sub

		' Token: 0x0600105A RID: 4186 RVA: 0x000C2C68 File Offset: 0x000C0E68
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMDV As frmDMDV2 = New frmDMDV2()
			Try
				Dim flag As Boolean = Me.dgvData.SelectedRows.Count > 1
				Dim flag2 As Boolean
				If flag Then
					flag2 = MessageBox.Show(Me.mArrStrFrmMess(56), Me.btnDelete.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No
					If flag2 Then
						Return
					End If
					Try
						For Each obj As Object In Me.dgvData.SelectedRows
							Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
							flag2 = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
							If Not flag2 Then
								Dim frmDMDV2 As frmDMDV2 = frmDMDV
								frmDMDV2.pbytFromStatus = 4
								frmDMDV2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("OBJID").Value, ""))
								frmDMDV.pBlnAutoDel = True
								frmDMDV.ShowDialog()
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag2 = TypeOf enumerator Is IDisposable
						If flag2 Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
				Else
					flag2 = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						frmDMDV.Dispose()
						Return
					End If
					flag2 = mdlVariable.gblnLRIGHTFORUSER AndAlso Operators.CompareString(mdlVariable.gStrUser.Trim(), Me.dgvData.CurrentRow.Cells("MAUSERUP").Value.ToString().Trim(), False) <> 0
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(41), MsgBoxStyle.Critical, Nothing)
						frmDMDV.Dispose()
						Return
					End If
					Dim frmDMDV3 As frmDMDV2 = frmDMDV
					frmDMDV3.pbytFromStatus = 4
					frmDMDV3.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMDV3.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMDV3.pStrStore = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
					frmDMDV3.txtADDRESS.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("ADDRESS").Value, ""))
					frmDMDV3.txtTEL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TEL").Value, ""))
					frmDMDV3.txtMOBILE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MOBILE").Value, ""))
					frmDMDV3.txtCONTACT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("CONTACT").Value, ""))
					frmDMDV3.txtVATCODE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("VATCODE").Value, ""))
					frmDMDV3.txtFAX.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FAX").Value, ""))
					frmDMDV3.txtEMAIL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("EMAIL").Value, ""))
					frmDMDV3.txtWEBSITE.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("WEBSITE").Value, ""))
					frmDMDV3.pStrBIRTHDAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BIRTHDAY").Value, ""))
					frmDMDV3.TxtMANHOMDV.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
					frmDMDV3.txtJOB.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("JOB").Value, ""))
					frmDMDV3.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
					frmDMDV3.txtTUOI.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUOI").Value, ""))
					frmDMDV3.pBytGIOITINH = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("GIOITINH").Value)
					frmDMDV3.txtMucGiamGia.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MUCGIAMGIA").Value, "")), CShort(mdlVariable.gbytDECNUMAMT), ",")
					frmDMDV3.pStrFinger1 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER1").Value)
					frmDMDV3.pStrFinger2 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER2").Value)
					frmDMDV3.pStrFinger3 = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FINGER3").Value)
					frmDMDV3.txtCardCode.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("CARDCODE").Value)
					frmDMDV3.pStrNgayNhanViec = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("NGAYNHANVIEC").Value, ""))
					frmDMDV3.pStrNgayThoiViec = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("NGAYTHOIVIEC").Value, ""))
					frmDMDV3.chkISCUS.Checked = False
					frmDMDV3.chkISFOR.Checked = False
					frmDMDV3.chkISORG.Checked = False
					frmDMDV3.chkISSUP.Checked = False
					flag2 = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISSUP").Value)
					If flag2 Then
						frmDMDV3.chkISSUP.Checked = True
					End If
					flag2 = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISCUS").Value)
					If flag2 Then
						frmDMDV3.chkISCUS.Checked = True
					End If
					flag2 = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISFOR").Value)
					If flag2 Then
						frmDMDV3.chkISFOR.Checked = True
					End If
					flag2 = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("ISORG").Value)
					If flag2 Then
						frmDMDV3.chkISORG.Checked = True
					End If
					frmDMDV3.txtMaUser.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAUSERLK").Value, ""))
					frmDMDV.ShowDialog()
					flag2 = frmDMDV.pbytSuccess = 0
					If flag2 Then
						Return
					End If
				End If
				Dim b As Byte = Me.fGetData_4Grid()
				flag2 = b = 0
				If flag2 Then
					Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
				End If
				flag2 = b <> 0
				If flag2 Then
					b = Me.fInitGrid()
				End If
				flag2 = b <> 0
				If flag2 Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDV.Dispose()
			End Try
		End Sub

		' Token: 0x0600105B RID: 4187 RVA: 0x000C3630 File Offset: 0x000C1830
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMDV As frmDMDV2 = New frmDMDV2()
			Try
				frmDMDV.pbytFromStatus = 6
				frmDMDV.ShowDialog()
				Dim flag As Boolean = frmDMDV.pbytSuccess = 0
				If flag Then
					frmDMDV.Dispose()
				Else
					Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Me.txtOBJIDNHDV.Text.Trim(), "", False) <> 0, " AND MAKH ='" + Me.txtOBJIDNHDV.Text.Trim() + "'", ""))
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMDV.pStrFilter + text, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMDV.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDV.Dispose()
			End Try
		End Sub

		' Token: 0x0600105C RID: 4188 RVA: 0x000C387C File Offset: 0x000C1A7C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMDV As frmDMDV2 = New frmDMDV2()
			Try
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				frmDMDV.pbytFromStatus = 5
				frmDMDV.ShowDialog()
				Dim flag As Boolean = frmDMDV.pbytSuccess = 0
				If Not flag Then
					Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Me.txtOBJIDNHDV.Text.Trim(), "", False) <> 0, " AND MAKH ='" + Me.txtOBJIDNHDV.Text.Trim() + "'", ""))
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMDV.pStrFilter + text
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDV.Dispose()
			End Try
		End Sub

		' Token: 0x0600105D RID: 4189 RVA: 0x000C3A04 File Offset: 0x000C1C04
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMDV As frmDMDV2 = New frmDMDV2()
			Try
				Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Me.txtOBJIDNHDV.Text.Trim(), "", False) <> 0, " MAKH ='" + Me.txtOBJIDNHDV.Text.Trim() + "'", ""))
				Me.mbdsSource.RemoveFilter()
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0
				If flag Then
					Me.mbdsSource.Filter = text
				End If
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDV.Dispose()
			End Try
		End Sub

		' Token: 0x0600105E RID: 4190 RVA: 0x000C3B40 File Offset: 0x000C1D40
		Private Sub btnSelectNHDV_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMNHOMDV As frmDMNHOMDV1 = New frmDMNHOMDV1()
				frmDMNHOMDV.pBytOpen_From_Menu = 7
				frmDMNHOMDV.ShowDialog()
				Me.txtOBJIDNHDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNHOMDV.pStrOBJID, "", False) = 0, Me.txtOBJIDNHDV.Text, frmDMNHOMDV.pStrOBJID))
				frmDMNHOMDV.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelectNHDV_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600105F RID: 4191 RVA: 0x000C3C28 File Offset: 0x000C1E28
		Private Sub txtOBJIDNHDV_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbNHDV Is Nothing
				If Not flag Then
					Me.btnCancelFilter.Visible = False
					array(0) = Me.mclsTbNHDV.Columns("OBJID")
					Me.mclsTbNHDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbNHDV.Rows.Find(Strings.Trim(Me.txtOBJIDNHDV.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtOBJNAMENHDV.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtOBJNAMENHDV.Text = ""
					End If
					Me.sLocDuLieu()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJIDNHDV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001060 RID: 4192 RVA: 0x000C3D90 File Offset: 0x000C1F90
		Private Sub sLocDuLieu()
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mbdsSource Is Nothing
				If Not flag Then
					flag = Me.txtOBJNAMENHDV.Text.Trim().Length > 0
					Dim text As String
					If flag Then
						text = Me.txtOBJIDNHDV.Text.Trim()
					Else
						text = ""
					End If
					Dim num As Short = CShort(Me.cboLoaiDV.SelectedIndex)
					flag = Operators.CompareString(text, "", False) = 0 AndAlso num = 0S
					If flag Then
						Me.mbdsSource.RemoveFilter()
					Else
						flag = num = 0S
						If flag Then
							Me.mbdsSource.Filter = "MANHOMDV Like '" + text + "'"
						Else
							flag = Operators.CompareString(text, "", False) = 0
							If flag Then
								Select Case num
									Case 1S
										Me.mbdsSource.Filter = "ISSUP =1"
									Case 2S
										Me.mbdsSource.Filter = "ISCUS =1"
									Case 3S
										Me.mbdsSource.Filter = "ISFOR =1"
									Case 4S
										Me.mbdsSource.Filter = "ISORG =1"
								End Select
							Else
								Dim text2 As String = ""
								Select Case num
									Case 1S
										text2 = " And ISSUP =1"
									Case 2S
										text2 = " And ISCUS =1"
									Case 3S
										text2 = " And ISFOR =1"
									Case 4S
										text2 = " And ISORG =1"
								End Select
								Me.mbdsSource.Filter = "MANHOMDV Like '" + text + "'" + text2
							End If
						End If
					End If
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(New Object()), New EventArgs())
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sLocDuLieu ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001061 RID: 4193 RVA: 0x000C4014 File Offset: 0x000C2214
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x06001062 RID: 4194 RVA: 0x000C4190 File Offset: 0x000C2390
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Interaction.MsgBox(Me.mArrStrFrmMess(42), MsgBoxStyle.YesNo, Nothing) = MsgBoxResult.Yes
				If flag Then
					Dim flag2 As Boolean = Me.dgvData.RowCount <= 0
					If Not flag2 Then
						Dim b As Byte = Me.fPrintDMDVDetail(Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))))
					End If
				Else
					Dim b As Byte = Me.fPrintDMDV(Me.txtOBJIDNHDV.Text.Trim())
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001063 RID: 4195 RVA: 0x000C42AC File Offset: 0x000C24AC
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001064 RID: 4196 RVA: 0x000C435C File Offset: 0x000C255C
		Private Function fReadImage(bytarr As Byte()) As Image
			Dim image As Image = Nothing
			Try
				Dim memoryStream As MemoryStream = New MemoryStream(bytarr)
				image = Image.FromStream(memoryStream)
			Catch ex As Exception
			End Try
			Return image
		End Function

		' Token: 0x06001065 RID: 4197 RVA: 0x000C43A0 File Offset: 0x000C25A0
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMDV")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mblnAutoAdd_DMDV = xmlNode.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001066 RID: 4198 RVA: 0x000C449C File Offset: 0x000C269C
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = True
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AllowUserToResizeRows = False
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("ADDRESS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("ADDRESS").Width = 350
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("ADDRESS").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TEL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("TEL").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("TEL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MOBILE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(28))
				dgvData.Columns("MOBILE").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("MOBILE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENNHOMDV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(61))
				dgvData.Columns("TENNHOMDV").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("TENNHOMDV").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("CARDCODE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(62))
				dgvData.Columns("CARDCODE").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("CARDCODE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENUSERLK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(67))
				dgvData.Columns("TENUSERLK").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("TENUSERLK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MAKH").Visible = False
				dgvData.Columns("FIXED").Visible = False
				dgvData.Columns("BIRTHDAY").Visible = False
				dgvData.Columns("MANHOMDV").Visible = False
				dgvData.Columns("TENKH").Visible = False
				dgvData.Columns("ISSUP").Visible = False
				dgvData.Columns("ISCUS").Visible = False
				dgvData.Columns("ISFOR").Visible = False
				dgvData.Columns("ISORG").Visible = False
				dgvData.Columns("VATCODE").Visible = False
				dgvData.Columns("FAX").Visible = False
				dgvData.Columns("EMAIL").Visible = False
				dgvData.Columns("WEBSITE").Visible = False
				dgvData.Columns("CONTACT").Visible = False
				dgvData.Columns("TUOI").Visible = False
				dgvData.Columns("GIOITINH").Visible = False
				dgvData.Columns("JOB").Visible = False
				dgvData.Columns("REMARK").Visible = False
				dgvData.Columns("MAUSERUP").Visible = False
				dgvData.Columns("CAP").Visible = False
				dgvData.Columns("CHUCVU").Visible = False
				dgvData.Columns("UIMAGE").Visible = False
				dgvData.Columns("MUCGIAMGIA").Visible = False
				dgvData.Columns("FINGER1").Visible = False
				dgvData.Columns("FINGER2").Visible = False
				dgvData.Columns("FINGER3").Visible = False
				dgvData.Columns("NGAYNHANVIEC").Visible = False
				dgvData.Columns("NGAYTHOIVIEC").Visible = False
				dgvData.Columns("MAUSERLK").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001067 RID: 4199 RVA: 0x000C4B94 File Offset: 0x000C2D94
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001068 RID: 4200 RVA: 0x000C4D14 File Offset: 0x000C2F14
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@tniTYPE"
				array(0).Value = Me.mIntType
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_GET_ALL_DATA_TYPE", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001069 RID: 4201 RVA: 0x000C4E38 File Offset: 0x000C3038
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600106A RID: 4202 RVA: 0x000C4F88 File Offset: 0x000C3188
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2070400000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600106B RID: 4203 RVA: 0x000C5094 File Offset: 0x000C3294
		Private Function fGetData_4Combo() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbNHDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNHOMDV")
				Dim flag As Boolean = Me.mclsTbNHDV IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600106C RID: 4204 RVA: 0x000C5150 File Offset: 0x000C3350
		Private Sub sClear_Form()
			Try
				Me.mclsTbNHDV.Dispose()
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600106D RID: 4205 RVA: 0x000C5208 File Offset: 0x000C3408
		Private Function fPrintDMDV(pstrMANHOMDV As String) As Byte
			Dim rptDMDV As rptDMDV = New rptDMDV()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMDV, "")
				Dim text As String = "2070400000"
				mdlReport.gsSetOfficeReport(rptDMDV, text)
				mdlReport.gsSetFontReport(rptDMDV)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMANHOMDV"
				array(0).Value = pstrMANHOMDV
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_GET_DMDV", num)
				Dim flag As Boolean = num = 1
				If flag Then
					rptDMDV.SetDataSource(clsConnect)
					rptDMDV.DataDefinition.FormulaFields("fUnitCode").Text = "{dtReport.OBJID}"
					rptDMDV.DataDefinition.FormulaFields("fUnitName").Text = "{dtReport.OBJNAME}"
					rptDMDV.DataDefinition.FormulaFields("fAddress").Text = "{dtReport.ADDRESS}"
					rptDMDV.DataDefinition.FormulaFields("fTel").Text = "{dtReport.TEL}"
					rptDMDV.DataDefinition.FormulaFields("fMobile").Text = "{dtReport.MOBILE}"
					rptDMDV.DataDefinition.FormulaFields("fStoreName").Text = "{dtReport.TENNHOMDV}"
					rptDMDV.DataDefinition.FormulaFields("fEmail").Text = "{dtReport.Email}"
					rptDMDV.DataDefinition.FormulaFields("fNgaysinh").Text = "{dtReport.Ngaysinh}"
					rptDMDV.DataDefinition.FormulaFields("fCap").Text = "{dtReport.CAP}"
					rptDMDV.DataDefinition.FormulaFields("fMST").Text = "{dtReport.VATCODE}"
					rptDMDV.DataDefinition.FormulaFields("fContact").Text = "{dtReport.CONTACT}"
					mdlReport.gsSetTextReport(rptDMDV, "RPTDMDV")
					MyProject.Forms.frmReport.pSource = rptDMDV
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMDV.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					Dim textObject2 As TextObject = CType(rptDMDV.ReportDefinition.ReportObjects("txtKHO"), TextObject)
					textObject2.Text = mdlVariable.gstrStockName
					rptDMDV.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMDV.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + "mdlRepDMDV - gfPrintDMDV " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMDV.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600106E RID: 4206 RVA: 0x000C5590 File Offset: 0x000C3790
		Private Function fPrintDMDVDetail(pstrMADV As String) As Byte
			Dim rptDMDVDetail As rptDMDVDetail = New rptDMDVDetail()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMDVDetail, "")
				Dim text As String = "2070401000"
				mdlReport.gsSetOfficeReport(rptDMDVDetail, text)
				mdlReport.gsSetFontReport(rptDMDVDetail)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADV"
				array(0).Value = pstrMADV
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcNam"
				array(1).Value = Me.mArrStrFrmMess(58)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcNu"
				array(2).Value = Me.mArrStrFrmMess(59)
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_GET_DMDV_REPORT_DET", num)
				Dim flag As Boolean = num = 1
				If flag Then
					rptDMDVDetail.SetDataSource(clsConnect)
					rptDMDVDetail.DataDefinition.FormulaFields("fUnitCode").Text = "{dtReport.OBJID}"
					rptDMDVDetail.DataDefinition.FormulaFields("fUnitName").Text = "{dtReport.OBJNAME}"
					rptDMDVDetail.DataDefinition.FormulaFields("fAddress").Text = "{dtReport.ADDRESS}"
					rptDMDVDetail.DataDefinition.FormulaFields("fTel").Text = "{dtReport.TEL}"
					rptDMDVDetail.DataDefinition.FormulaFields("fMobile").Text = "{dtReport.MOBILE}"
					rptDMDVDetail.DataDefinition.FormulaFields("fStoreName").Text = "{dtReport.TENKH}"
					rptDMDVDetail.DataDefinition.FormulaFields("fBIRTHDAY").Text = "{dtReport.BIRTHDAY}"
					rptDMDVDetail.DataDefinition.FormulaFields("fVATCODE").Text = "{dtReport.VATCODE}"
					rptDMDVDetail.DataDefinition.FormulaFields("fFAX").Text = "{dtReport.FAX}"
					rptDMDVDetail.DataDefinition.FormulaFields("fEMAIL").Text = "{dtReport.EMAIL}"
					rptDMDVDetail.DataDefinition.FormulaFields("fWEBSITE").Text = "{dtReport.WEBSITE}"
					rptDMDVDetail.DataDefinition.FormulaFields("fCONTACT").Text = "{dtReport.CONTACT}"
					rptDMDVDetail.DataDefinition.FormulaFields("fTUOI").Text = "{dtReport.TUOI}"
					rptDMDVDetail.DataDefinition.FormulaFields("fJOB").Text = "{dtReport.JOB}"
					rptDMDVDetail.DataDefinition.FormulaFields("fGIOITINH").Text = "{dtReport.NAMNU}"
					rptDMDVDetail.DataDefinition.FormulaFields("fREMARK").Text = "{dtReport.REMARK}"
					rptDMDVDetail.DataDefinition.FormulaFields("fUSERUP").Text = "{dtReport.USERUP}"
					rptDMDVDetail.DataDefinition.FormulaFields("fNHOMDV").Text = "{dtReport.TENNHOMDV}"
					rptDMDVDetail.DataDefinition.FormulaFields("fCARDCODE").Text = "{dtReport.CARDCODE}"
					rptDMDVDetail.DataDefinition.FormulaFields("fCAP").Text = "{dtReport.CAP}"
					rptDMDVDetail.DataDefinition.FormulaFields("fCHUCVU").Text = "{dtReport.CHUCVU}"
					rptDMDVDetail.DataDefinition.FormulaFields("fMUCGIAMGIA").Text = "{dtReport.MUCGIAMGIA}"
					rptDMDVDetail.DataDefinition.FormulaFields("fNGAYNV").Text = "{dtReport.NGAYNHANVIEC}"
					rptDMDVDetail.DataDefinition.FormulaFields("fNGAYTV").Text = "{dtReport.NGAYTHOIVIEC}"
					Dim fieldObject As FieldObject = CType(rptDMDVDetail.ReportDefinition.ReportObjects("fMUCGIAMGIA"), FieldObject)
					fieldObject.FieldFormat.NumericFormat.DecimalPlaces = CShort(mdlVariable.gbytDECNUMAMT)
					mdlReport.gsSetTextReport(rptDMDVDetail, "RPTDMDV")
					MyProject.Forms.frmReport.pSource = rptDMDVDetail
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMDVDetail.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMDVDetail.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMDVDetail.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMDVDetail " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMDVDetail.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600106F RID: 4207 RVA: 0x000C5B14 File Offset: 0x000C3D14
		Private Sub btnSendMail_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim text As String = ""
				Dim num As Integer = 0
				Dim num2 As Integer = Me.dgvData.Rows.Count - 1
				Dim num3 As Integer = num
				Dim flag As Boolean
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						Exit For
					End If
					flag = Me.dgvData.Rows(num3).Cells("Email").Value.ToString().Trim().Length > 3
					If flag Then
						text = text + "; " + Me.dgvData.Rows(num3).Cells("Email").Value.ToString().Trim()
					End If
					num3 += 1
				End While
				flag = text.Trim().StartsWith(";")
				If flag Then
					text = text.Substring(1)
					flag = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(44), Me.mArrStrFrmMess(43), frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.Yes
					If flag Then
						Clipboard.SetText(text)
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(45), Me.mArrStrFrmMess(43), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.ThongTin)
					Else
						mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
						Me.OpenEmail(text, "", "")
						mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
					End If
				Else
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(48), Me.mArrStrFrmMess(43), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.ThongTin)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSendMail_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001070 RID: 4208 RVA: 0x000C5D30 File Offset: 0x000C3F30
		Public Function OpenEmail(EmailAddress As String, Optional Subject As String = "", Optional Body As String = "") As Boolean
			Dim flag As Boolean = True
			Dim text As String = EmailAddress
			Dim flag2 As Boolean = Operators.CompareString(Strings.LCase(Strings.Left(text, 7)), "mailto:", False) <> 0
			If flag2 Then
				text = "mailto:" + text
			End If
			flag2 = Operators.CompareString(Subject, "", False) <> 0
			If flag2 Then
				text = text + "?subject=" + Subject
			End If
			flag2 = Operators.CompareString(Body, "", False) <> 0
			If flag2 Then
				text = Conversions.ToString(Operators.ConcatenateObject(text, Interaction.IIf(Operators.CompareString(Subject, "", False) = 0, "?", "&")))
				text = text + "body=" + Body
			End If
			Try
				Process.Start(text)
			Catch ex As Exception
				flag = False
			End Try
			Return flag
		End Function

		' Token: 0x06001071 RID: 4209 RVA: 0x000048AA File Offset: 0x00002AAA
		Private Sub cboLoaiDV_SelectedIndexChanged(sender As Object, e As EventArgs)
			Me.sLocDuLieu()
		End Sub

		' Token: 0x06001072 RID: 4210 RVA: 0x000C5E10 File Offset: 0x000C4010
		Private Sub btnImportExcel_Click(sender As Object, e As EventArgs)
			Try
				Dim openFileDialog As OpenFileDialog = New OpenFileDialog()
				Dim openFileDialog2 As OpenFileDialog = openFileDialog
				openFileDialog2.Title = Me.mArrStrFrmMess(39)
				openFileDialog2.Filter = "Excel Only(*.xls)|*.xls|*.csv|*.xlsx"
				Dim flag As Boolean = openFileDialog2.ShowDialog() = DialogResult.OK
				If flag Then
					Dim frmSelectSheet As frmSelectSheet = New frmSelectSheet()
					frmSelectSheet.pstrFilename = openFileDialog2.FileName
					frmSelectSheet.ShowDialog()
					flag = frmSelectSheet.pblnOK
					If flag Then
						Me.fGetData_4Grid()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(40), vbCrLf, Me.Name, " - btnImportExcel_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001073 RID: 4211 RVA: 0x000C5F10 File Offset: 0x000C4110
		Private Sub btnQLKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmCusManage As frmCusManage = New frmCusManage()
				frmCusManage.ShowDialog()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnQLKH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001074 RID: 4212 RVA: 0x000C5FA0 File Offset: 0x000C41A0
		Private Sub btnEx_Click(sender As Object, e As EventArgs)
			Try
				Dim clsConnect As clsConnect = New clsConnect()
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMDV")
				Dim flag As Boolean = clsConnect IsNot Nothing
				If flag Then
					Dim flag2 As Boolean = mdlFile.gfExport2Excel(clsConnect, "", "") = 0
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(63), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(63), vbCrLf, Me.Name, " - btnEx_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001075 RID: 4213 RVA: 0x000C6080 File Offset: 0x000C4280
		Private Sub btnIm_Click(sender As Object, e As EventArgs)
			Try
				Dim openFileDialog As OpenFileDialog = New OpenFileDialog()
				Dim openFileDialog2 As OpenFileDialog = openFileDialog
				openFileDialog2.Title = Me.mArrStrFrmMess(39)
				openFileDialog2.Filter = "Excel Only(*.xls)|*.xls|*.csv|*.xlsx"
				Dim flag As Boolean = openFileDialog2.ShowDialog() = DialogResult.OK
				If flag Then
					Dim dataTable As DataTable = New DataTable()
					flag = mdlFile.gfImportFromExcel(openFileDialog2.FileName, dataTable, False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(64), MsgBoxStyle.Critical, Nothing)
					Else
						flag = dataTable IsNot Nothing AndAlso dataTable.Rows.Count > 0
						If flag Then
							Me.sAddFromExcel(dataTable)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(64), vbCrLf, Me.Name, " - btnIm_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001076 RID: 4214 RVA: 0x000C61A8 File Offset: 0x000C43A8
		Private Sub sAddFromExcel(ptblData As DataTable)
			Dim frmDMDV As frmDMDV2 = New frmDMDV2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim num As Integer = 0
				Dim num2 As Integer = ptblData.Rows.Count - 1
				Dim num3 As Integer = num
				Dim flag As Boolean
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						Exit For
					End If
					Dim frmDMDV2 As frmDMDV2 = frmDMDV
					frmDMDV2.pbytFromStatus = 2
					frmDMDV2.txtOBJID.Text = ptblData.Rows(num3)("OBJID").ToString() + ""
					frmDMDV2.txtOBJNAME.Text = ptblData.Rows(num3)("OBJNAME").ToString() + ""
					frmDMDV2.pStrStore = ptblData.Rows(num3)("MAKH").ToString() + ""
					frmDMDV2.txtADDRESS.Text = ptblData.Rows(num3)("ADDRESS").ToString() + ""
					frmDMDV2.txtTEL.Text = ptblData.Rows(num3)("TEL").ToString() + ""
					frmDMDV2.txtMOBILE.Text = ptblData.Rows(num3)("MOBILE").ToString() + ""
					frmDMDV2.txtCONTACT.Text = ptblData.Rows(num3)("CONTACT").ToString() + ""
					frmDMDV2.txtVATCODE.Text = ptblData.Rows(num3)("VATCODE").ToString() + ""
					frmDMDV2.txtFAX.Text = ptblData.Rows(num3)("FAX").ToString() + ""
					frmDMDV2.txtEMAIL.Text = ptblData.Rows(num3)("EMAIL").ToString() + ""
					frmDMDV2.txtWEBSITE.Text = ptblData.Rows(num3)("WEBSITE").ToString() + ""
					frmDMDV2.pStrBIRTHDAY = ptblData.Rows(num3)("BIRTHDAY").ToString() + ""
					frmDMDV2.TxtMANHOMDV.Text = ptblData.Rows(num3)("MANHOMDV").ToString() + ""
					frmDMDV2.txtJOB.Text = ptblData.Rows(num3)("JOB").ToString() + ""
					frmDMDV2.txtRemark.Text = ptblData.Rows(num3)("REMARK").ToString() + ""
					frmDMDV2.txtTUOI.Text = ptblData.Rows(num3)("TUOI").ToString() + ""
					frmDMDV2.pBytGIOITINH = Conversions.ToByte(ptblData.Rows(num3)("GIOITINH"))
					frmDMDV2.txtCAP.Text = ptblData.Rows(num3)("CAP").ToString() + ""
					frmDMDV2.txtCHUCVU.Text = ptblData.Rows(num3)("CHUCVU").ToString() + ""
					frmDMDV2.txtMucGiamGia.Text = mdlUIForm.gfFormatNumber(Conversion.Val(ptblData.Rows(num3)("MUCGIAMGIA").ToString() + ""), CShort(mdlVariable.gbytDECNUMAMT), ",")
					frmDMDV2.pStrFinger1 = Conversions.ToString(ptblData.Rows(num3)("FINGER1"))
					frmDMDV2.pStrFinger2 = Conversions.ToString(ptblData.Rows(num3)("FINGER2"))
					frmDMDV2.pStrFinger3 = Conversions.ToString(ptblData.Rows(num3)("FINGER3"))
					frmDMDV2.txtCardCode.Text = ptblData.Rows(num3)("CARDCODE").ToString() + ""
					frmDMDV2.pStrNgayNhanViec = ptblData.Rows(num3)("NGAYNHANVIEC").ToString() + ""
					frmDMDV2.pStrNgayThoiViec = ptblData.Rows(num3)("NGAYTHOIVIEC").ToString() + ""
					Try
						frmDMDV2.pstrUIMAGE = ptblData.Rows(num3)("UIMAGE").ToString() + ""
						frmDMDV2.picAnh.BackgroundImage = Image.FromFile(ptblData.Rows(num3)("UIMAGE").ToString().Trim())
					Catch ex As Exception
					End Try
					frmDMDV2.chkISCUS.Checked = False
					frmDMDV2.chkISFOR.Checked = False
					frmDMDV2.chkISORG.Checked = False
					frmDMDV2.chkISSUP.Checked = False
					flag = Conversions.ToBoolean(ptblData.Rows(num3)("ISSUP"))
					If flag Then
						frmDMDV2.chkISSUP.Checked = True
					End If
					flag = Conversions.ToBoolean(ptblData.Rows(num3)("ISCUS"))
					If flag Then
						frmDMDV2.chkISCUS.Checked = True
					End If
					flag = Conversions.ToBoolean(ptblData.Rows(num3)("ISFOR"))
					If flag Then
						frmDMDV2.chkISFOR.Checked = True
					End If
					flag = Conversions.ToBoolean(ptblData.Rows(num3)("ISORG"))
					If flag Then
						frmDMDV2.chkISORG.Checked = True
					End If
					frmDMDV2 = Nothing
					frmDMDV.gfAddNew(1)
					num3 += 1
				End While
				Dim b As Byte = Me.fGetData_4Grid()
				flag = b = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Dim objectValue As Object = RuntimeHelpers.GetObjectValue(New Object())
					Dim eventArgs As EventArgs = New EventArgs()
					Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMDV.pStrFilter)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(objectValue), eventArgs)
				End If
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAddDefault_Click ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMDV.Dispose()
			End Try
		End Sub

		' Token: 0x040006C5 RID: 1733
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040006C7 RID: 1735
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x040006C8 RID: 1736
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x040006C9 RID: 1737
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x040006CA RID: 1738
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x040006CB RID: 1739
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x040006CC RID: 1740
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x040006CD RID: 1741
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x040006CE RID: 1742
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x040006CF RID: 1743
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x040006D0 RID: 1744
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x040006D1 RID: 1745
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x040006D2 RID: 1746
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x040006D3 RID: 1747
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x040006D4 RID: 1748
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x040006D5 RID: 1749
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x040006D6 RID: 1750
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040006D7 RID: 1751
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x040006D8 RID: 1752
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040006D9 RID: 1753
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040006DA RID: 1754
		<AccessedThroughProperty("lblStore")>
		Private _lblStore As Label

		' Token: 0x040006DB RID: 1755
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040006DC RID: 1756
		<AccessedThroughProperty("txtOBJNAMENHDV")>
		Private _txtOBJNAMENHDV As TextBox

		' Token: 0x040006DD RID: 1757
		<AccessedThroughProperty("btnSelectNHDV")>
		Private _btnSelectNHDV As Button

		' Token: 0x040006DE RID: 1758
		<AccessedThroughProperty("txtOBJIDNHDV")>
		Private _txtOBJIDNHDV As TextBox

		' Token: 0x040006DF RID: 1759
		<AccessedThroughProperty("btnSendMail")>
		Private _btnSendMail As Button

		' Token: 0x040006E0 RID: 1760
		<AccessedThroughProperty("cboLoaiDV")>
		Private _cboLoaiDV As ComboBox

		' Token: 0x040006E1 RID: 1761
		<AccessedThroughProperty("btnImportExcel2")>
		Private _btnImportExcel2 As Button

		' Token: 0x040006E2 RID: 1762
		<AccessedThroughProperty("btnQLKH")>
		Private _btnQLKH As Button

		' Token: 0x040006E3 RID: 1763
		<AccessedThroughProperty("btnIm")>
		Private _btnIm As Button

		' Token: 0x040006E4 RID: 1764
		<AccessedThroughProperty("btnEx")>
		Private _btnEx As Button

		' Token: 0x040006E5 RID: 1765
		Private mArrStrFrmMess As String()

		' Token: 0x040006E6 RID: 1766
		Private mStrOBJID As String

		' Token: 0x040006E7 RID: 1767
		Private mStrOBJNAME As String

		' Token: 0x040006E8 RID: 1768
		Private mStrMANHOMDV As String

		' Token: 0x040006E9 RID: 1769
		Private mStrPhone As String

		' Token: 0x040006EA RID: 1770
		Private mStrEmail As String

		' Token: 0x040006EB RID: 1771
		Private mStrContact As String

		' Token: 0x040006EC RID: 1772
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040006ED RID: 1773
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040006EE RID: 1774
		Private marrDrFind As DataRow()

		' Token: 0x040006EF RID: 1775
		Private mintFindLastPos As Integer

		' Token: 0x040006F0 RID: 1776
		Private mclsTbNHDV As clsConnect

		' Token: 0x040006F1 RID: 1777
		Private mIntType As Short

		' Token: 0x040006F2 RID: 1778
		Private mblnAutoAdd_DMDV As Boolean
	End Class
End Namespace
