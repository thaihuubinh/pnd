﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000045 RID: 69
	<DesignerGenerated()>
	Public Partial Class frmDMDV2_RG
		Inherits Form

		' Token: 0x060011DB RID: 4571 RVA: 0x000D9694 File Offset: 0x000D7894
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMDV2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMDV2_Load
			AddHandler MyBase.KeyDown, AddressOf Me.frmDMDV2_KeyDown
			frmDMDV2_RG.__ENCList.Add(New WeakReference(Me))
			Me.mstrStore = ""
			Me.mstrUIMAGE = ""
			Me.mblnSaveAndSelect = False
			Me.mStrFinger1 = ""
			Me.mStrFinger2 = ""
			Me.mStrFinger3 = ""
			Me.mStrNgayNhanViec = ""
			Me.mStrNgayThoiViec = ""
			Me.mblnAutoAdd_DMDV = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000642 RID: 1602
		' (get) Token: 0x060011DE RID: 4574 RVA: 0x000DC94C File Offset: 0x000DAB4C
		' (set) Token: 0x060011DF RID: 4575 RVA: 0x00004BB5 File Offset: 0x00002DB5
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000643 RID: 1603
		' (get) Token: 0x060011E0 RID: 4576 RVA: 0x000DC964 File Offset: 0x000DAB64
		' (set) Token: 0x060011E1 RID: 4577 RVA: 0x000DC97C File Offset: 0x000DAB7C
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000644 RID: 1604
		' (get) Token: 0x060011E2 RID: 4578 RVA: 0x000DC9E8 File Offset: 0x000DABE8
		' (set) Token: 0x060011E3 RID: 4579 RVA: 0x00004BBF File Offset: 0x00002DBF
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x17000645 RID: 1605
		' (get) Token: 0x060011E4 RID: 4580 RVA: 0x000DCA00 File Offset: 0x000DAC00
		' (set) Token: 0x060011E5 RID: 4581 RVA: 0x000DCA18 File Offset: 0x000DAC18
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000646 RID: 1606
		' (get) Token: 0x060011E6 RID: 4582 RVA: 0x000DCA84 File Offset: 0x000DAC84
		' (set) Token: 0x060011E7 RID: 4583 RVA: 0x000DCA9C File Offset: 0x000DAC9C
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000647 RID: 1607
		' (get) Token: 0x060011E8 RID: 4584 RVA: 0x000DCB08 File Offset: 0x000DAD08
		' (set) Token: 0x060011E9 RID: 4585 RVA: 0x000DCB20 File Offset: 0x000DAD20
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000648 RID: 1608
		' (get) Token: 0x060011EA RID: 4586 RVA: 0x000DCB8C File Offset: 0x000DAD8C
		' (set) Token: 0x060011EB RID: 4587 RVA: 0x00004BC9 File Offset: 0x00002DC9
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x17000649 RID: 1609
		' (get) Token: 0x060011EC RID: 4588 RVA: 0x000DCBA4 File Offset: 0x000DADA4
		' (set) Token: 0x060011ED RID: 4589 RVA: 0x000DCBBC File Offset: 0x000DADBC
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700064A RID: 1610
		' (get) Token: 0x060011EE RID: 4590 RVA: 0x000DCC58 File Offset: 0x000DAE58
		' (set) Token: 0x060011EF RID: 4591 RVA: 0x000DCC70 File Offset: 0x000DAE70
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x1700064B RID: 1611
		' (get) Token: 0x060011F0 RID: 4592 RVA: 0x000DCD0C File Offset: 0x000DAF0C
		' (set) Token: 0x060011F1 RID: 4593 RVA: 0x00004BD3 File Offset: 0x00002DD3
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x1700064C RID: 1612
		' (get) Token: 0x060011F2 RID: 4594 RVA: 0x000DCD24 File Offset: 0x000DAF24
		' (set) Token: 0x060011F3 RID: 4595 RVA: 0x000DCD3C File Offset: 0x000DAF3C
		Friend Overridable Property chkISSUP As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkISSUP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkISSUP IsNot Nothing
				If flag Then
					RemoveHandler Me._chkISSUP.KeyPress, AddressOf Me.chkISSUP_KeyPress
				End If
				Me._chkISSUP = value
				flag = Me._chkISSUP IsNot Nothing
				If flag Then
					AddHandler Me._chkISSUP.KeyPress, AddressOf Me.chkISSUP_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700064D RID: 1613
		' (get) Token: 0x060011F4 RID: 4596 RVA: 0x000DCDA8 File Offset: 0x000DAFA8
		' (set) Token: 0x060011F5 RID: 4597 RVA: 0x00004BDD File Offset: 0x00002DDD
		Friend Overridable Property lblEMAIL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblEMAIL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblEMAIL = value
			End Set
		End Property

		' Token: 0x1700064E RID: 1614
		' (get) Token: 0x060011F6 RID: 4598 RVA: 0x000DCDC0 File Offset: 0x000DAFC0
		' (set) Token: 0x060011F7 RID: 4599 RVA: 0x00004BE7 File Offset: 0x00002DE7
		Friend Overridable Property lblWEBSITE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblWEBSITE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblWEBSITE = value
			End Set
		End Property

		' Token: 0x1700064F RID: 1615
		' (get) Token: 0x060011F8 RID: 4600 RVA: 0x000DCDD8 File Offset: 0x000DAFD8
		' (set) Token: 0x060011F9 RID: 4601 RVA: 0x000DCDF0 File Offset: 0x000DAFF0
		Friend Overridable Property cmbStore As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbStore
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbStore IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbStore.KeyPress, AddressOf Me.cmbStore_KeyPress
					RemoveHandler Me._cmbStore.GotFocus, AddressOf Me.cmbStore_GotFocus
				End If
				Me._cmbStore = value
				flag = Me._cmbStore IsNot Nothing
				If flag Then
					AddHandler Me._cmbStore.KeyPress, AddressOf Me.cmbStore_KeyPress
					AddHandler Me._cmbStore.GotFocus, AddressOf Me.cmbStore_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000650 RID: 1616
		' (get) Token: 0x060011FA RID: 4602 RVA: 0x000DCE8C File Offset: 0x000DB08C
		' (set) Token: 0x060011FB RID: 4603 RVA: 0x00004BF1 File Offset: 0x00002DF1
		Friend Overridable Property lblBRANCH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblBRANCH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblBRANCH = value
			End Set
		End Property

		' Token: 0x17000651 RID: 1617
		' (get) Token: 0x060011FC RID: 4604 RVA: 0x000DCEA4 File Offset: 0x000DB0A4
		' (set) Token: 0x060011FD RID: 4605 RVA: 0x000DCEBC File Offset: 0x000DB0BC
		Friend Overridable Property txtADDRESS As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtADDRESS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtADDRESS IsNot Nothing
				If flag Then
					RemoveHandler Me._txtADDRESS.KeyPress, AddressOf Me.txtADDRESS_KeyPress
					RemoveHandler Me._txtADDRESS.GotFocus, AddressOf Me.txtADDRESS_GotFocus
				End If
				Me._txtADDRESS = value
				flag = Me._txtADDRESS IsNot Nothing
				If flag Then
					AddHandler Me._txtADDRESS.KeyPress, AddressOf Me.txtADDRESS_KeyPress
					AddHandler Me._txtADDRESS.GotFocus, AddressOf Me.txtADDRESS_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000652 RID: 1618
		' (get) Token: 0x060011FE RID: 4606 RVA: 0x000DCF58 File Offset: 0x000DB158
		' (set) Token: 0x060011FF RID: 4607 RVA: 0x000DCF70 File Offset: 0x000DB170
		Friend Overridable Property txtTEL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTEL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTEL IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTEL.KeyPress, AddressOf Me.txtTEL_KeyPress
					RemoveHandler Me._txtTEL.GotFocus, AddressOf Me.txtTEL_GotFocus
				End If
				Me._txtTEL = value
				flag = Me._txtTEL IsNot Nothing
				If flag Then
					AddHandler Me._txtTEL.KeyPress, AddressOf Me.txtTEL_KeyPress
					AddHandler Me._txtTEL.GotFocus, AddressOf Me.txtTEL_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000653 RID: 1619
		' (get) Token: 0x06001200 RID: 4608 RVA: 0x000DD00C File Offset: 0x000DB20C
		' (set) Token: 0x06001201 RID: 4609 RVA: 0x000DD024 File Offset: 0x000DB224
		Friend Overridable Property txtMOBILE As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMOBILE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMOBILE IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMOBILE.KeyPress, AddressOf Me.txtMOBILE_KeyPress
					RemoveHandler Me._txtMOBILE.GotFocus, AddressOf Me.txtMOBILE_GotFocus
				End If
				Me._txtMOBILE = value
				flag = Me._txtMOBILE IsNot Nothing
				If flag Then
					AddHandler Me._txtMOBILE.KeyPress, AddressOf Me.txtMOBILE_KeyPress
					AddHandler Me._txtMOBILE.GotFocus, AddressOf Me.txtMOBILE_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000654 RID: 1620
		' (get) Token: 0x06001202 RID: 4610 RVA: 0x000DD0C0 File Offset: 0x000DB2C0
		' (set) Token: 0x06001203 RID: 4611 RVA: 0x000DD0D8 File Offset: 0x000DB2D8
		Friend Overridable Property txtCONTACT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCONTACT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtCONTACT IsNot Nothing
				If flag Then
					RemoveHandler Me._txtCONTACT.KeyPress, AddressOf Me.txtCONTACT_KeyPress
					RemoveHandler Me._txtCONTACT.GotFocus, AddressOf Me.txtCONTACT_GotFocus
				End If
				Me._txtCONTACT = value
				flag = Me._txtCONTACT IsNot Nothing
				If flag Then
					AddHandler Me._txtCONTACT.KeyPress, AddressOf Me.txtCONTACT_KeyPress
					AddHandler Me._txtCONTACT.GotFocus, AddressOf Me.txtCONTACT_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000655 RID: 1621
		' (get) Token: 0x06001204 RID: 4612 RVA: 0x000DD174 File Offset: 0x000DB374
		' (set) Token: 0x06001205 RID: 4613 RVA: 0x000DD18C File Offset: 0x000DB38C
		Friend Overridable Property txtVATCODE As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtVATCODE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtVATCODE IsNot Nothing
				If flag Then
					RemoveHandler Me._txtVATCODE.GotFocus, AddressOf Me.txtVATCODE_GotFocus
					RemoveHandler Me._txtVATCODE.KeyPress, AddressOf Me.txtVATCODE_KeyPress
				End If
				Me._txtVATCODE = value
				flag = Me._txtVATCODE IsNot Nothing
				If flag Then
					AddHandler Me._txtVATCODE.GotFocus, AddressOf Me.txtVATCODE_GotFocus
					AddHandler Me._txtVATCODE.KeyPress, AddressOf Me.txtVATCODE_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000656 RID: 1622
		' (get) Token: 0x06001206 RID: 4614 RVA: 0x000DD228 File Offset: 0x000DB428
		' (set) Token: 0x06001207 RID: 4615 RVA: 0x000DD240 File Offset: 0x000DB440
		Friend Overridable Property txtFAX As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtFAX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtFAX IsNot Nothing
				If flag Then
					RemoveHandler Me._txtFAX.KeyPress, AddressOf Me.txtFAX_KeyPress
					RemoveHandler Me._txtFAX.GotFocus, AddressOf Me.txtFAX_GotFocus
				End If
				Me._txtFAX = value
				flag = Me._txtFAX IsNot Nothing
				If flag Then
					AddHandler Me._txtFAX.KeyPress, AddressOf Me.txtFAX_KeyPress
					AddHandler Me._txtFAX.GotFocus, AddressOf Me.txtFAX_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000657 RID: 1623
		' (get) Token: 0x06001208 RID: 4616 RVA: 0x000DD2DC File Offset: 0x000DB4DC
		' (set) Token: 0x06001209 RID: 4617 RVA: 0x000DD2F4 File Offset: 0x000DB4F4
		Friend Overridable Property txtEMAIL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtEMAIL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtEMAIL IsNot Nothing
				If flag Then
					RemoveHandler Me._txtEMAIL.KeyPress, AddressOf Me.txtEMAIL_KeyPress
					RemoveHandler Me._txtEMAIL.GotFocus, AddressOf Me.txtEMAIL_GotFocus
				End If
				Me._txtEMAIL = value
				flag = Me._txtEMAIL IsNot Nothing
				If flag Then
					AddHandler Me._txtEMAIL.KeyPress, AddressOf Me.txtEMAIL_KeyPress
					AddHandler Me._txtEMAIL.GotFocus, AddressOf Me.txtEMAIL_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000658 RID: 1624
		' (get) Token: 0x0600120A RID: 4618 RVA: 0x000DD390 File Offset: 0x000DB590
		' (set) Token: 0x0600120B RID: 4619 RVA: 0x000DD3A8 File Offset: 0x000DB5A8
		Friend Overridable Property txtWEBSITE As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtWEBSITE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtWEBSITE IsNot Nothing
				If flag Then
					RemoveHandler Me._txtWEBSITE.KeyPress, AddressOf Me.txtWEBSITE_KeyPress
					RemoveHandler Me._txtWEBSITE.GotFocus, AddressOf Me.txtWEBSITE_GotFocus
				End If
				Me._txtWEBSITE = value
				flag = Me._txtWEBSITE IsNot Nothing
				If flag Then
					AddHandler Me._txtWEBSITE.KeyPress, AddressOf Me.txtWEBSITE_KeyPress
					AddHandler Me._txtWEBSITE.GotFocus, AddressOf Me.txtWEBSITE_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000659 RID: 1625
		' (get) Token: 0x0600120C RID: 4620 RVA: 0x000DD444 File Offset: 0x000DB644
		' (set) Token: 0x0600120D RID: 4621 RVA: 0x000DD45C File Offset: 0x000DB65C
		Friend Overridable Property chkISCUS As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkISCUS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkISCUS IsNot Nothing
				If flag Then
					RemoveHandler Me._chkISCUS.KeyPress, AddressOf Me.chkISCUS_KeyPress
				End If
				Me._chkISCUS = value
				flag = Me._chkISCUS IsNot Nothing
				If flag Then
					AddHandler Me._chkISCUS.KeyPress, AddressOf Me.chkISCUS_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700065A RID: 1626
		' (get) Token: 0x0600120E RID: 4622 RVA: 0x000DD4C8 File Offset: 0x000DB6C8
		' (set) Token: 0x0600120F RID: 4623 RVA: 0x000DD4E0 File Offset: 0x000DB6E0
		Friend Overridable Property chkISFOR As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkISFOR
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkISFOR IsNot Nothing
				If flag Then
					RemoveHandler Me._chkISFOR.KeyPress, AddressOf Me.chkISFOR_KeyPress
				End If
				Me._chkISFOR = value
				flag = Me._chkISFOR IsNot Nothing
				If flag Then
					AddHandler Me._chkISFOR.KeyPress, AddressOf Me.chkISFOR_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700065B RID: 1627
		' (get) Token: 0x06001210 RID: 4624 RVA: 0x000DD54C File Offset: 0x000DB74C
		' (set) Token: 0x06001211 RID: 4625 RVA: 0x000DD564 File Offset: 0x000DB764
		Friend Overridable Property chkISORG As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkISORG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkISORG IsNot Nothing
				If flag Then
					RemoveHandler Me._chkISORG.KeyPress, AddressOf Me.chkISORG_KeyPress
				End If
				Me._chkISORG = value
				flag = Me._chkISORG IsNot Nothing
				If flag Then
					AddHandler Me._chkISORG.KeyPress, AddressOf Me.chkISORG_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700065C RID: 1628
		' (get) Token: 0x06001212 RID: 4626 RVA: 0x000DD5D0 File Offset: 0x000DB7D0
		' (set) Token: 0x06001213 RID: 4627 RVA: 0x00004BFB File Offset: 0x00002DFB
		Friend Overridable Property lblADDRESS As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblADDRESS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblADDRESS = value
			End Set
		End Property

		' Token: 0x1700065D RID: 1629
		' (get) Token: 0x06001214 RID: 4628 RVA: 0x000DD5E8 File Offset: 0x000DB7E8
		' (set) Token: 0x06001215 RID: 4629 RVA: 0x00004C05 File Offset: 0x00002E05
		Friend Overridable Property lblTEL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTEL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTEL = value
			End Set
		End Property

		' Token: 0x1700065E RID: 1630
		' (get) Token: 0x06001216 RID: 4630 RVA: 0x000DD600 File Offset: 0x000DB800
		' (set) Token: 0x06001217 RID: 4631 RVA: 0x00004C0F File Offset: 0x00002E0F
		Friend Overridable Property lblMOBILE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMOBILE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMOBILE = value
			End Set
		End Property

		' Token: 0x1700065F RID: 1631
		' (get) Token: 0x06001218 RID: 4632 RVA: 0x000DD618 File Offset: 0x000DB818
		' (set) Token: 0x06001219 RID: 4633 RVA: 0x00004C19 File Offset: 0x00002E19
		Friend Overridable Property lblCONTACT As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCONTACT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCONTACT = value
			End Set
		End Property

		' Token: 0x17000660 RID: 1632
		' (get) Token: 0x0600121A RID: 4634 RVA: 0x000DD630 File Offset: 0x000DB830
		' (set) Token: 0x0600121B RID: 4635 RVA: 0x00004C23 File Offset: 0x00002E23
		Friend Overridable Property lblVATCODE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblVATCODE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblVATCODE = value
			End Set
		End Property

		' Token: 0x17000661 RID: 1633
		' (get) Token: 0x0600121C RID: 4636 RVA: 0x000DD648 File Offset: 0x000DB848
		' (set) Token: 0x0600121D RID: 4637 RVA: 0x00004C2D File Offset: 0x00002E2D
		Friend Overridable Property lblFAX As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFAX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFAX = value
			End Set
		End Property

		' Token: 0x17000662 RID: 1634
		' (get) Token: 0x0600121E RID: 4638 RVA: 0x000DD660 File Offset: 0x000DB860
		' (set) Token: 0x0600121F RID: 4639 RVA: 0x00004C37 File Offset: 0x00002E37
		Friend Overridable Property lblISSUP As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblISSUP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblISSUP = value
			End Set
		End Property

		' Token: 0x17000663 RID: 1635
		' (get) Token: 0x06001220 RID: 4640 RVA: 0x000DD678 File Offset: 0x000DB878
		' (set) Token: 0x06001221 RID: 4641 RVA: 0x00004C41 File Offset: 0x00002E41
		Friend Overridable Property lblISCUS As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblISCUS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblISCUS = value
			End Set
		End Property

		' Token: 0x17000664 RID: 1636
		' (get) Token: 0x06001222 RID: 4642 RVA: 0x000DD690 File Offset: 0x000DB890
		' (set) Token: 0x06001223 RID: 4643 RVA: 0x00004C4B File Offset: 0x00002E4B
		Friend Overridable Property lblISFOR As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblISFOR
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblISFOR = value
			End Set
		End Property

		' Token: 0x17000665 RID: 1637
		' (get) Token: 0x06001224 RID: 4644 RVA: 0x000DD6A8 File Offset: 0x000DB8A8
		' (set) Token: 0x06001225 RID: 4645 RVA: 0x00004C55 File Offset: 0x00002E55
		Friend Overridable Property lblISORG As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblISORG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblISORG = value
			End Set
		End Property

		' Token: 0x17000666 RID: 1638
		' (get) Token: 0x06001226 RID: 4646 RVA: 0x000DD6C0 File Offset: 0x000DB8C0
		' (set) Token: 0x06001227 RID: 4647 RVA: 0x00004C5F File Offset: 0x00002E5F
		Friend Overridable Property txtColor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtColor = value
			End Set
		End Property

		' Token: 0x17000667 RID: 1639
		' (get) Token: 0x06001228 RID: 4648 RVA: 0x000DD6D8 File Offset: 0x000DB8D8
		' (set) Token: 0x06001229 RID: 4649 RVA: 0x000DD6F0 File Offset: 0x000DB8F0
		Friend Overridable Property BtnSELECTMANHOMDV As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._BtnSELECTMANHOMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._BtnSELECTMANHOMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._BtnSELECTMANHOMDV.Click, AddressOf Me.BtnSELECTMANHOMDV_Click
				End If
				Me._BtnSELECTMANHOMDV = value
				flag = Me._BtnSELECTMANHOMDV IsNot Nothing
				If flag Then
					AddHandler Me._BtnSELECTMANHOMDV.Click, AddressOf Me.BtnSELECTMANHOMDV_Click
				End If
			End Set
		End Property

		' Token: 0x17000668 RID: 1640
		' (get) Token: 0x0600122A RID: 4650 RVA: 0x000DD75C File Offset: 0x000DB95C
		' (set) Token: 0x0600122B RID: 4651 RVA: 0x00004C69 File Offset: 0x00002E69
		Friend Overridable Property TxtTENNHOMDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._TxtTENNHOMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TxtTENNHOMDV = value
			End Set
		End Property

		' Token: 0x17000669 RID: 1641
		' (get) Token: 0x0600122C RID: 4652 RVA: 0x000DD774 File Offset: 0x000DB974
		' (set) Token: 0x0600122D RID: 4653 RVA: 0x000DD78C File Offset: 0x000DB98C
		Friend Overridable Property TxtMANHOMDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._TxtMANHOMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._TxtMANHOMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._TxtMANHOMDV.KeyPress, AddressOf Me.TxtMANHOMDV_KeyPress
					RemoveHandler Me._TxtMANHOMDV.TextChanged, AddressOf Me.TxtMANHOMDV_TextChanged
				End If
				Me._TxtMANHOMDV = value
				flag = Me._TxtMANHOMDV IsNot Nothing
				If flag Then
					AddHandler Me._TxtMANHOMDV.KeyPress, AddressOf Me.TxtMANHOMDV_KeyPress
					AddHandler Me._TxtMANHOMDV.TextChanged, AddressOf Me.TxtMANHOMDV_TextChanged
				End If
			End Set
		End Property

		' Token: 0x1700066A RID: 1642
		' (get) Token: 0x0600122E RID: 4654 RVA: 0x000DD828 File Offset: 0x000DBA28
		' (set) Token: 0x0600122F RID: 4655 RVA: 0x00004C73 File Offset: 0x00002E73
		Friend Overridable Property LblMANHOMDV As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._LblMANHOMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._LblMANHOMDV = value
			End Set
		End Property

		' Token: 0x1700066B RID: 1643
		' (get) Token: 0x06001230 RID: 4656 RVA: 0x000DD840 File Offset: 0x000DBA40
		' (set) Token: 0x06001231 RID: 4657 RVA: 0x00004C7D File Offset: 0x00002E7D
		Friend Overridable Property LblBIRTHDAY As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._LblBIRTHDAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._LblBIRTHDAY = value
			End Set
		End Property

		' Token: 0x1700066C RID: 1644
		' (get) Token: 0x06001232 RID: 4658 RVA: 0x000DD858 File Offset: 0x000DBA58
		' (set) Token: 0x06001233 RID: 4659 RVA: 0x000DD870 File Offset: 0x000DBA70
		Friend Overridable Property mtxBIRTHDAY As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxBIRTHDAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxBIRTHDAY IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxBIRTHDAY.TextChanged, AddressOf Me.mtxBIRTHDAY_TextChanged
					RemoveHandler Me._mtxBIRTHDAY.KeyPress, AddressOf Me.mtxBIRTHDAY_KeyPress
				End If
				Me._mtxBIRTHDAY = value
				flag = Me._mtxBIRTHDAY IsNot Nothing
				If flag Then
					AddHandler Me._mtxBIRTHDAY.TextChanged, AddressOf Me.mtxBIRTHDAY_TextChanged
					AddHandler Me._mtxBIRTHDAY.KeyPress, AddressOf Me.mtxBIRTHDAY_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700066D RID: 1645
		' (get) Token: 0x06001234 RID: 4660 RVA: 0x000DD90C File Offset: 0x000DBB0C
		' (set) Token: 0x06001235 RID: 4661 RVA: 0x00004C87 File Offset: 0x00002E87
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x1700066E RID: 1646
		' (get) Token: 0x06001236 RID: 4662 RVA: 0x000DD924 File Offset: 0x000DBB24
		' (set) Token: 0x06001237 RID: 4663 RVA: 0x00004C91 File Offset: 0x00002E91
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x1700066F RID: 1647
		' (get) Token: 0x06001238 RID: 4664 RVA: 0x000DD93C File Offset: 0x000DBB3C
		' (set) Token: 0x06001239 RID: 4665 RVA: 0x00004C9B File Offset: 0x00002E9B
		Friend Overridable Property txtTUOI As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTUOI
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTUOI = value
			End Set
		End Property

		' Token: 0x17000670 RID: 1648
		' (get) Token: 0x0600123A RID: 4666 RVA: 0x000DD954 File Offset: 0x000DBB54
		' (set) Token: 0x0600123B RID: 4667 RVA: 0x000DD96C File Offset: 0x000DBB6C
		Friend Overridable Property cmbGIOTINH As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbGIOTINH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbGIOTINH IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbGIOTINH.KeyPress, AddressOf Me.cmbGIOTINH_KeyPress
				End If
				Me._cmbGIOTINH = value
				flag = Me._cmbGIOTINH IsNot Nothing
				If flag Then
					AddHandler Me._cmbGIOTINH.KeyPress, AddressOf Me.cmbGIOTINH_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000671 RID: 1649
		' (get) Token: 0x0600123C RID: 4668 RVA: 0x000DD9D8 File Offset: 0x000DBBD8
		' (set) Token: 0x0600123D RID: 4669 RVA: 0x00004CA5 File Offset: 0x00002EA5
		Friend Overridable Property lblNAMGIOI As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblNAMGIOI
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblNAMGIOI = value
			End Set
		End Property

		' Token: 0x17000672 RID: 1650
		' (get) Token: 0x0600123E RID: 4670 RVA: 0x000DD9F0 File Offset: 0x000DBBF0
		' (set) Token: 0x0600123F RID: 4671 RVA: 0x00004CAF File Offset: 0x00002EAF
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000673 RID: 1651
		' (get) Token: 0x06001240 RID: 4672 RVA: 0x000DDA08 File Offset: 0x000DBC08
		' (set) Token: 0x06001241 RID: 4673 RVA: 0x00004CB9 File Offset: 0x00002EB9
		Friend Overridable Property txtJOB As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtJOB
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtJOB = value
			End Set
		End Property

		' Token: 0x17000674 RID: 1652
		' (get) Token: 0x06001242 RID: 4674 RVA: 0x000DDA20 File Offset: 0x000DBC20
		' (set) Token: 0x06001243 RID: 4675 RVA: 0x000DDA38 File Offset: 0x000DBC38
		Friend Overridable Property txtRemark As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtRemark
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtRemark IsNot Nothing
				If flag Then
					RemoveHandler Me._txtRemark.KeyPress, AddressOf Me.txtREMARK_KeyPress
				End If
				Me._txtRemark = value
				flag = Me._txtRemark IsNot Nothing
				If flag Then
					AddHandler Me._txtRemark.KeyPress, AddressOf Me.txtREMARK_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000675 RID: 1653
		' (get) Token: 0x06001244 RID: 4676 RVA: 0x000DDAA4 File Offset: 0x000DBCA4
		' (set) Token: 0x06001245 RID: 4677 RVA: 0x00004CC3 File Offset: 0x00002EC3
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x17000676 RID: 1654
		' (get) Token: 0x06001246 RID: 4678 RVA: 0x000DDABC File Offset: 0x000DBCBC
		' (set) Token: 0x06001247 RID: 4679 RVA: 0x00004CCD File Offset: 0x00002ECD
		Friend Overridable Property Panel1 As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._Panel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._Panel1 = value
			End Set
		End Property

		' Token: 0x17000677 RID: 1655
		' (get) Token: 0x06001248 RID: 4680 RVA: 0x000DDAD4 File Offset: 0x000DBCD4
		' (set) Token: 0x06001249 RID: 4681 RVA: 0x000DDAEC File Offset: 0x000DBCEC
		Friend Overridable Property picAnh As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picAnh
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Dim flag As Boolean = Me._picAnh IsNot Nothing
				If flag Then
					RemoveHandler Me._picAnh.MouseLeave, AddressOf Me.picAnh_MouseLeave
					RemoveHandler Me._picAnh.MouseHover, AddressOf Me.picAnh_MouseHover
					RemoveHandler Me._picAnh.Click, AddressOf Me.picAnh_Click
				End If
				Me._picAnh = value
				flag = Me._picAnh IsNot Nothing
				If flag Then
					AddHandler Me._picAnh.MouseLeave, AddressOf Me.picAnh_MouseLeave
					AddHandler Me._picAnh.MouseHover, AddressOf Me.picAnh_MouseHover
					AddHandler Me._picAnh.Click, AddressOf Me.picAnh_Click
				End If
			End Set
		End Property

		' Token: 0x17000678 RID: 1656
		' (get) Token: 0x0600124A RID: 4682 RVA: 0x000DDBBC File Offset: 0x000DBDBC
		' (set) Token: 0x0600124B RID: 4683 RVA: 0x00004CD7 File Offset: 0x00002ED7
		Friend Overridable Property picZoom As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picZoom
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._picZoom = value
			End Set
		End Property

		' Token: 0x17000679 RID: 1657
		' (get) Token: 0x0600124C RID: 4684 RVA: 0x000DDBD4 File Offset: 0x000DBDD4
		' (set) Token: 0x0600124D RID: 4685 RVA: 0x00004CE1 File Offset: 0x00002EE1
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x1700067A RID: 1658
		' (get) Token: 0x0600124E RID: 4686 RVA: 0x000DDBEC File Offset: 0x000DBDEC
		' (set) Token: 0x0600124F RID: 4687 RVA: 0x00004CEB File Offset: 0x00002EEB
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x1700067B RID: 1659
		' (get) Token: 0x06001250 RID: 4688 RVA: 0x000DDC04 File Offset: 0x000DBE04
		' (set) Token: 0x06001251 RID: 4689 RVA: 0x000DDC1C File Offset: 0x000DBE1C
		Friend Overridable Property txtCHUCVU As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCHUCVU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtCHUCVU IsNot Nothing
				If flag Then
					RemoveHandler Me._txtCHUCVU.KeyPress, AddressOf Me.txtCHUCVU_KeyPress
				End If
				Me._txtCHUCVU = value
				flag = Me._txtCHUCVU IsNot Nothing
				If flag Then
					AddHandler Me._txtCHUCVU.KeyPress, AddressOf Me.txtCHUCVU_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700067C RID: 1660
		' (get) Token: 0x06001252 RID: 4690 RVA: 0x000DDC88 File Offset: 0x000DBE88
		' (set) Token: 0x06001253 RID: 4691 RVA: 0x000DDCA0 File Offset: 0x000DBEA0
		Friend Overridable Property txtCAP As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCAP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtCAP IsNot Nothing
				If flag Then
					RemoveHandler Me._txtCAP.KeyPress, AddressOf Me.txtCAP_KeyPress
				End If
				Me._txtCAP = value
				flag = Me._txtCAP IsNot Nothing
				If flag Then
					AddHandler Me._txtCAP.KeyPress, AddressOf Me.txtCAP_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700067D RID: 1661
		' (get) Token: 0x06001254 RID: 4692 RVA: 0x000DDD0C File Offset: 0x000DBF0C
		' (set) Token: 0x06001255 RID: 4693 RVA: 0x000DDD24 File Offset: 0x000DBF24
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x1700067E RID: 1662
		' (get) Token: 0x06001256 RID: 4694 RVA: 0x000DDD90 File Offset: 0x000DBF90
		' (set) Token: 0x06001257 RID: 4695 RVA: 0x000DDDA8 File Offset: 0x000DBFA8
		Friend Overridable Property btnSaveAndSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSaveAndSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSaveAndSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSaveAndSelect.Click, AddressOf Me.btnSaveAndSelect_Click
				End If
				Me._btnSaveAndSelect = value
				flag = Me._btnSaveAndSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSaveAndSelect.Click, AddressOf Me.btnSaveAndSelect_Click
				End If
			End Set
		End Property

		' Token: 0x1700067F RID: 1663
		' (get) Token: 0x06001258 RID: 4696 RVA: 0x000DDE14 File Offset: 0x000DC014
		' (set) Token: 0x06001259 RID: 4697 RVA: 0x000DDE2C File Offset: 0x000DC02C
		Friend Overridable Property btnFinger As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFinger
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFinger IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFinger.Click, AddressOf Me.btnFinger_Click
				End If
				Me._btnFinger = value
				flag = Me._btnFinger IsNot Nothing
				If flag Then
					AddHandler Me._btnFinger.Click, AddressOf Me.btnFinger_Click
				End If
			End Set
		End Property

		' Token: 0x17000680 RID: 1664
		' (get) Token: 0x0600125A RID: 4698 RVA: 0x000DDE98 File Offset: 0x000DC098
		' (set) Token: 0x0600125B RID: 4699 RVA: 0x000DDEB0 File Offset: 0x000DC0B0
		Friend Overridable Property txtCardCode As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCardCode
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtCardCode IsNot Nothing
				If flag Then
					RemoveHandler Me._txtCardCode.KeyPress, AddressOf Me.txtCardCode_KeyPress
				End If
				Me._txtCardCode = value
				flag = Me._txtCardCode IsNot Nothing
				If flag Then
					AddHandler Me._txtCardCode.KeyPress, AddressOf Me.txtCardCode_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000681 RID: 1665
		' (get) Token: 0x0600125C RID: 4700 RVA: 0x000DDF1C File Offset: 0x000DC11C
		' (set) Token: 0x0600125D RID: 4701 RVA: 0x00004CF5 File Offset: 0x00002EF5
		Friend Overridable Property Label7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		' Token: 0x17000682 RID: 1666
		' (get) Token: 0x0600125E RID: 4702 RVA: 0x000DDF34 File Offset: 0x000DC134
		' (set) Token: 0x0600125F RID: 4703 RVA: 0x00004CFF File Offset: 0x00002EFF
		Friend Overridable Property mtxNgayThoiViec As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxNgayThoiViec
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxNgayThoiViec = value
			End Set
		End Property

		' Token: 0x17000683 RID: 1667
		' (get) Token: 0x06001260 RID: 4704 RVA: 0x000DDF4C File Offset: 0x000DC14C
		' (set) Token: 0x06001261 RID: 4705 RVA: 0x00004D09 File Offset: 0x00002F09
		Friend Overridable Property Label8 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label8 = value
			End Set
		End Property

		' Token: 0x17000684 RID: 1668
		' (get) Token: 0x06001262 RID: 4706 RVA: 0x000DDF64 File Offset: 0x000DC164
		' (set) Token: 0x06001263 RID: 4707 RVA: 0x00004D13 File Offset: 0x00002F13
		Friend Overridable Property mtxNgayNhanViec As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxNgayNhanViec
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxNgayNhanViec = value
			End Set
		End Property

		' Token: 0x17000685 RID: 1669
		' (get) Token: 0x06001264 RID: 4708 RVA: 0x000DDF7C File Offset: 0x000DC17C
		' (set) Token: 0x06001265 RID: 4709 RVA: 0x00004D1D File Offset: 0x00002F1D
		Friend Overridable Property Label9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label9 = value
			End Set
		End Property

		' Token: 0x17000686 RID: 1670
		' (get) Token: 0x06001266 RID: 4710 RVA: 0x000DDF94 File Offset: 0x000DC194
		' (set) Token: 0x06001267 RID: 4711 RVA: 0x00004D27 File Offset: 0x00002F27
		Public Property pStrNgayNhanViec As String
			Get
				Return Me.mStrNgayNhanViec
			End Get
			Set(value As String)
				Me.mStrNgayNhanViec = value
			End Set
		End Property

		' Token: 0x17000687 RID: 1671
		' (get) Token: 0x06001268 RID: 4712 RVA: 0x000DDFAC File Offset: 0x000DC1AC
		' (set) Token: 0x06001269 RID: 4713 RVA: 0x00004D32 File Offset: 0x00002F32
		Public Property pStrNgayThoiViec As String
			Get
				Return Me.mStrNgayThoiViec
			End Get
			Set(value As String)
				Me.mStrNgayThoiViec = value
			End Set
		End Property

		' Token: 0x17000688 RID: 1672
		' (get) Token: 0x0600126A RID: 4714 RVA: 0x000DDFC4 File Offset: 0x000DC1C4
		' (set) Token: 0x0600126B RID: 4715 RVA: 0x00004D3D File Offset: 0x00002F3D
		Public Property pStrFinger1 As String
			Get
				Return Me.mStrFinger1
			End Get
			Set(value As String)
				Me.mStrFinger1 = value
			End Set
		End Property

		' Token: 0x17000689 RID: 1673
		' (get) Token: 0x0600126C RID: 4716 RVA: 0x000DDFDC File Offset: 0x000DC1DC
		' (set) Token: 0x0600126D RID: 4717 RVA: 0x00004D48 File Offset: 0x00002F48
		Public Property pStrFinger2 As String
			Get
				Return Me.mStrFinger2
			End Get
			Set(value As String)
				Me.mStrFinger2 = value
			End Set
		End Property

		' Token: 0x1700068A RID: 1674
		' (get) Token: 0x0600126E RID: 4718 RVA: 0x000DDFF4 File Offset: 0x000DC1F4
		' (set) Token: 0x0600126F RID: 4719 RVA: 0x00004D53 File Offset: 0x00002F53
		Public Property pStrFinger3 As String
			Get
				Return Me.mStrFinger3
			End Get
			Set(value As String)
				Me.mStrFinger3 = value
			End Set
		End Property

		' Token: 0x1700068B RID: 1675
		' (get) Token: 0x06001270 RID: 4720 RVA: 0x000DE00C File Offset: 0x000DC20C
		' (set) Token: 0x06001271 RID: 4721 RVA: 0x00004D5E File Offset: 0x00002F5E
		Public Property pstrUIMAGE As String
			Get
				Return Me.mstrUIMAGE
			End Get
			Set(value As String)
				Me.mstrUIMAGE = value
			End Set
		End Property

		' Token: 0x1700068C RID: 1676
		' (get) Token: 0x06001272 RID: 4722 RVA: 0x000DE024 File Offset: 0x000DC224
		' (set) Token: 0x06001273 RID: 4723 RVA: 0x00004D69 File Offset: 0x00002F69
		Public Property pblnSaveAndSelect As Boolean
			Get
				Return Me.mblnSaveAndSelect
			End Get
			Set(value As Boolean)
				Me.mblnSaveAndSelect = value
			End Set
		End Property

		' Token: 0x1700068D RID: 1677
		' (get) Token: 0x06001274 RID: 4724 RVA: 0x000DE03C File Offset: 0x000DC23C
		' (set) Token: 0x06001275 RID: 4725 RVA: 0x00004D74 File Offset: 0x00002F74
		Public Property pBytGIOITINH As Byte
			Get
				Return Me.mbytGIOITINH
			End Get
			Set(value As Byte)
				Me.mbytGIOITINH = value
			End Set
		End Property

		' Token: 0x1700068E RID: 1678
		' (get) Token: 0x06001276 RID: 4726 RVA: 0x000DE054 File Offset: 0x000DC254
		' (set) Token: 0x06001277 RID: 4727 RVA: 0x00004D7F File Offset: 0x00002F7F
		Public Property pStrBIRTHDAY As String
			Get
				Return Me.mStrBIRTHDAY
			End Get
			Set(value As String)
				Me.mStrBIRTHDAY = value
			End Set
		End Property

		' Token: 0x1700068F RID: 1679
		' (get) Token: 0x06001278 RID: 4728 RVA: 0x000DE06C File Offset: 0x000DC26C
		' (set) Token: 0x06001279 RID: 4729 RVA: 0x00004D8A File Offset: 0x00002F8A
		Public Property pStrStore As String
			Get
				Return Me.mstrStore
			End Get
			Set(value As String)
				Me.mstrStore = value
			End Set
		End Property

		' Token: 0x17000690 RID: 1680
		' (get) Token: 0x0600127A RID: 4730 RVA: 0x000DE084 File Offset: 0x000DC284
		' (set) Token: 0x0600127B RID: 4731 RVA: 0x00004D95 File Offset: 0x00002F95
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000691 RID: 1681
		' (get) Token: 0x0600127C RID: 4732 RVA: 0x000DE09C File Offset: 0x000DC29C
		' (set) Token: 0x0600127D RID: 4733 RVA: 0x00004DA0 File Offset: 0x00002FA0
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000692 RID: 1682
		' (get) Token: 0x0600127E RID: 4734 RVA: 0x000DE0B4 File Offset: 0x000DC2B4
		' (set) Token: 0x0600127F RID: 4735 RVA: 0x00004DAB File Offset: 0x00002FAB
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06001280 RID: 4736 RVA: 0x000DE0CC File Offset: 0x000DC2CC
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001281 RID: 4737 RVA: 0x000DE178 File Offset: 0x000DC378
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001282 RID: 4738 RVA: 0x000DE220 File Offset: 0x000DC420
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.cmbStore.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001283 RID: 4739 RVA: 0x000DE2CC File Offset: 0x000DC4CC
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.TxtMANHOMDV.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001284 RID: 4740 RVA: 0x000DE370 File Offset: 0x000DC570
		Private Sub cmbStore_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbytFormStatus = 4
				If flag Then
					Me.txtADDRESS.Focus()
				Else
					Me.cmbStore.DroppedDown = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbStore_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001285 RID: 4741 RVA: 0x000DE42C File Offset: 0x000DC62C
		Private Sub cmbStore_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxBIRTHDAY.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbStore_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001286 RID: 4742 RVA: 0x000DE4D0 File Offset: 0x000DC6D0
		Private Sub txtADDRESS_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtADDRESS.[ReadOnly]
				If [readOnly] Then
					Me.txtTEL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtADDRESS_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001287 RID: 4743 RVA: 0x000DE57C File Offset: 0x000DC77C
		Private Sub txtADDRESS_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMOBILE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtADDRESS_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001288 RID: 4744 RVA: 0x000DE620 File Offset: 0x000DC820
		Private Sub txtTEL_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTEL.[ReadOnly]
				If [readOnly] Then
					Me.txtMOBILE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTEL_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001289 RID: 4745 RVA: 0x000DE6CC File Offset: 0x000DC8CC
		Private Sub txtTEL_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMOBILE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTEL_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600128A RID: 4746 RVA: 0x000DE770 File Offset: 0x000DC970
		Private Sub txtMOBILE_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMOBILE.[ReadOnly]
				If [readOnly] Then
					Me.txtCONTACT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMOBILE_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600128B RID: 4747 RVA: 0x000DE81C File Offset: 0x000DCA1C
		Private Sub txtMOBILE_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtVATCODE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMOBILE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600128C RID: 4748 RVA: 0x000DE8C0 File Offset: 0x000DCAC0
		Private Sub txtCONTACT_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtCONTACT.[ReadOnly]
				If [readOnly] Then
					Me.txtVATCODE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCONTACT_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600128D RID: 4749 RVA: 0x000DE96C File Offset: 0x000DCB6C
		Private Sub txtCONTACT_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtVATCODE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCONTACT_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600128E RID: 4750 RVA: 0x000DEA10 File Offset: 0x000DCC10
		Private Sub txtVATCODE_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtVATCODE.[ReadOnly]
				If [readOnly] Then
					Me.txtFAX.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtVATCODE_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600128F RID: 4751 RVA: 0x000DEABC File Offset: 0x000DCCBC
		Private Sub txtVATCODE_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtVATCODE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001290 RID: 4752 RVA: 0x000DEB60 File Offset: 0x000DCD60
		Private Sub txtFAX_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtFAX.[ReadOnly]
				If [readOnly] Then
					Me.txtEMAIL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtFAX_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001291 RID: 4753 RVA: 0x000DEC0C File Offset: 0x000DCE0C
		Private Sub txtFAX_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtEMAIL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtFAX_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001292 RID: 4754 RVA: 0x000DECB0 File Offset: 0x000DCEB0
		Private Sub txtEMAIL_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtEMAIL.[ReadOnly]
				If [readOnly] Then
					Me.txtWEBSITE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtEMAIL_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001293 RID: 4755 RVA: 0x000DED5C File Offset: 0x000DCF5C
		Private Sub txtEMAIL_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtWEBSITE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtEMAIL_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001294 RID: 4756 RVA: 0x000DEE00 File Offset: 0x000DD000
		Private Sub txtWEBSITE_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtWEBSITE.[ReadOnly]
				If [readOnly] Then
					Me.chkISSUP.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001295 RID: 4757 RVA: 0x000DEEAC File Offset: 0x000DD0AC
		Private Sub txtWEBSITE_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtRemark.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001296 RID: 4758 RVA: 0x000DEF50 File Offset: 0x000DD150
		Private Sub txtREMARK_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkISSUP.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtWEBSITE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001297 RID: 4759 RVA: 0x000DEFF4 File Offset: 0x000DD1F4
		Private Sub chkISSUP_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkISCUS.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkISSUP_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001298 RID: 4760 RVA: 0x000DF098 File Offset: 0x000DD298
		Private Sub chkISCUS_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkISFOR.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkISCUS_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001299 RID: 4761 RVA: 0x000DF13C File Offset: 0x000DD33C
		Private Sub chkISFOR_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkISORG.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkISFOR_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600129A RID: 4762 RVA: 0x000DF1E0 File Offset: 0x000DD3E0
		Private Sub chkISORG_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkISORG_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600129B RID: 4763 RVA: 0x000DF284 File Offset: 0x000DD484
		Private Function fGetData_DMNHOMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMNHOMDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNHOMDV")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMNHOMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600129C RID: 4764 RVA: 0x000DF330 File Offset: 0x000DD530
		Private Function fGetData_4Combo_GIOITINH() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim dataTable As DataTable = New DataTable()
				dataTable.Columns.Add("GIATRI")
				dataTable.Columns.Add("TEN")
				dataTable.Rows.Add(New Object() { 0, Me.mArrStrFrmMess(54) })
				dataTable.Rows.Add(New Object() { 1, Me.mArrStrFrmMess(55) })
				Dim cmbGIOTINH As ComboBox = Me.cmbGIOTINH
				cmbGIOTINH.DataSource = dataTable
				cmbGIOTINH.DisplayMember = "TEN"
				cmbGIOTINH.ValueMember = "GIATRI"
				cmbGIOTINH.SelectedIndex = CInt(Me.mbytGIOITINH)
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo_GIOITINH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600129D RID: 4765 RVA: 0x000DF4A0 File Offset: 0x000DD6A0
		Private Sub frmDMDV2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
				Me.TxtMANHOMDV_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDV2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600129E RID: 4766 RVA: 0x000DF55C File Offset: 0x000DD75C
		Private Sub frmDMDV2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Combo()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMNHOMDV()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Combo_GIOITINH()
				End If
				flag = Me.mbytFormStatus = 2 OrElse Me.mbytFormStatus = 1
				If flag Then
					Me.sGetMaxDocid()
				End If
				Me.sGetPara_From_SetparaXML()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDV2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600129F RID: 4767 RVA: 0x000DF66C File Offset: 0x000DD86C
		Private Sub sGetMaxDocid()
			Try
				Dim sqlCommand As SqlCommand = New SqlCommand()
				Dim array As SqlParameter() = New SqlParameter(1) {}
				Dim clsConnect As clsConnect = New clsConnect()
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchKH"
				array(0).Value = mdlVariable.gStrStockCode
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDULIEU, array, "SP_FRMPTHE2_GET_MAX_DOCID", num)
				Dim flag As Boolean = clsConnect.Rows.Count > 0
				If flag Then
					Me.txtCardCode.Text = Conversions.ToString(Conversion.Val(RuntimeHelpers.GetObjectValue(clsConnect.Rows(0)("CARDCODE"))))
				Else
					Me.txtCardCode.Text = ""
				End If
			Catch ex As Exception
				Me.txtCardCode.Text = ""
			End Try
		End Sub

		' Token: 0x060012A0 RID: 4768 RVA: 0x000DF758 File Offset: 0x000DD958
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = Operators.CompareString(Strings.Trim(Me.TxtMANHOMDV.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
							Me.TxtMANHOMDV.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.TxtMANHOMDV.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.TxtTENNHOMDV.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
								Me.TxtMANHOMDV.Focus()
							Else
								flag = (Operators.CompareString(Strings.Trim(Me.mtxBIRTHDAY.Text.Replace("/", "")), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTUOI.Text), "", False) = 0)
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(57), MsgBoxStyle.Critical, Nothing)
									Me.mtxBIRTHDAY.Focus()
								Else
									flag = Not(Me.chkISCUS.Checked Or Me.chkISFOR.Checked Or Me.chkISORG.Checked Or Me.chkISSUP.Checked)
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(44), MsgBoxStyle.Critical, Nothing)
										Me.chkISSUP.Focus()
									Else
										flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
										If flag Then
											Me.mbytSuccess = Me.fAddNew()
										Else
											flag = Me.mbytFormStatus = 3
											If flag Then
												Me.mbytSuccess = Me.fModify()
											End If
										End If
										flag = Me.mbytSuccess = 1
										If flag Then
											Me.mblnSaveAndSelect = False
											Me.Close()
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012A1 RID: 4769 RVA: 0x000DFA70 File Offset: 0x000DDC70
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012A2 RID: 4770 RVA: 0x000DFB14 File Offset: 0x000DDD14
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = "*" + Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (OBJNAME like '"), text2), "%' OR OBJNAME_REMOVE_VIET LIKE '"), text2), "%')"))
				End If
				Dim text3 As String = Strings.Mid(Me.mtxBIRTHDAY.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxBIRTHDAY.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 1, 2) })
					flag = Not Information.IsDate(text2)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
						Me.mtxBIRTHDAY.Focus()
						Return
					End If
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " BIRTHDAY ='"), Strings.Replace(Strings.Trim(Me.mtxBIRTHDAY.Text), text3, "/", 1, -1, CompareMethod.Binary)), "'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.TxtMANHOMDV.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MANHOMDV like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Trim(Conversions.ToString(Me.cmbStore.SelectedValue))
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtADDRESS.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (ADDRESS like '"), text2), "%' OR ADDRESS_REMOVE_VIET LIKE '"), text2), "%')"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtTEL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TEL like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtMOBILE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MOBILE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtCONTACT.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " CONTACT like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtVATCODE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " VATCODE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtFAX.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FAX like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtEMAIL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " EMAIL like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtWEBSITE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " WEBSITE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtRemark.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (REMARK like '"), text2), "%' OR REMARK_REMOVE_VIET LIKE '"), text2), "%')"))
				End If
				flag = Me.chkISSUP.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISSUP ="), Interaction.IIf(Me.chkISSUP.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISCUS.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISCUS ="), Interaction.IIf(Me.chkISCUS.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISFOR.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISFOR ="), Interaction.IIf(Me.chkISFOR.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISORG.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISORG ="), Interaction.IIf(Me.chkISORG.Checked, 1, 0)), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012A3 RID: 4771 RVA: 0x000E07F4 File Offset: 0x000DE9F4
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = "*" + Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (OBJNAME like '"), text2), "%' OR OBJNAME_REMOVE_VIET LIKE '"), text2), "%')"))
				End If
				Dim text3 As String = Strings.Mid(Me.mtxBIRTHDAY.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxBIRTHDAY.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxBIRTHDAY.Text), 1, 2) })
					flag = Not Information.IsDate(text2)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
						Me.mtxBIRTHDAY.Focus()
						Return
					End If
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " BIRTHDAY ='"), Strings.Replace(Strings.Trim(Me.mtxBIRTHDAY.Text), text3, "/", 1, -1, CompareMethod.Binary)), "'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.TxtMANHOMDV.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MANHOMDV like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Trim(Conversions.ToString(Me.cmbStore.SelectedValue))
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtADDRESS.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (ADDRESS like '"), text2), "%' OR ADDRESS_REMOVE_VIET LIKE '"), text2), "%')"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtTEL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TEL like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtMOBILE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MOBILE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtCONTACT.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " CONTACT like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtVATCODE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " VATCODE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtFAX.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FAX like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtEMAIL.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " EMAIL like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtWEBSITE.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " WEBSITE like '"), text2), "%'"))
				End If
				text2 = "*" + Strings.Replace(Strings.Trim(Me.txtRemark.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " (REMARK like '"), text2), "%' OR REMARK_REMOVE_VIET LIKE '"), text2), "%')"))
				End If
				flag = Me.chkISSUP.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISSUP ="), Interaction.IIf(Me.chkISSUP.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISCUS.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISCUS ="), Interaction.IIf(Me.chkISCUS.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISFOR.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISFOR ="), Interaction.IIf(Me.chkISFOR.Checked, 1, 0)), ""))
				End If
				flag = Me.chkISORG.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " ISORG ="), Interaction.IIf(Me.chkISORG.Checked, 1, 0)), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012A4 RID: 4772 RVA: 0x000E14D4 File Offset: 0x000DF6D4
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtADDRESS.[ReadOnly] = True
						Me.txtTEL.[ReadOnly] = True
						Me.txtMOBILE.[ReadOnly] = True
						Me.txtCONTACT.[ReadOnly] = True
						Me.txtVATCODE.[ReadOnly] = True
						Me.txtFAX.[ReadOnly] = True
						Me.txtEMAIL.[ReadOnly] = True
						Me.txtWEBSITE.[ReadOnly] = True
						Me.mtxBIRTHDAY.[ReadOnly] = True
						Me.TxtMANHOMDV.[ReadOnly] = True
						Me.txtTUOI.[ReadOnly] = True
						Me.txtJOB.[ReadOnly] = True
						Me.txtRemark.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.BackColor = Me.txtColor.BackColor
						Me.txtADDRESS.BackColor = Me.txtColor.BackColor
						Me.txtTEL.BackColor = Me.txtColor.BackColor
						Me.txtMOBILE.BackColor = Me.txtColor.BackColor
						Me.txtCONTACT.BackColor = Me.txtColor.BackColor
						Me.txtVATCODE.BackColor = Me.txtColor.BackColor
						Me.txtFAX.BackColor = Me.txtColor.BackColor
						Me.txtEMAIL.BackColor = Me.txtColor.BackColor
						Me.txtWEBSITE.BackColor = Me.txtColor.BackColor
						Me.cmbStore.BackColor = Me.txtColor.BackColor
						Me.mtxBIRTHDAY.BackColor = Me.txtColor.BackColor
						Me.TxtMANHOMDV.BackColor = Me.txtColor.BackColor
						Me.TxtTENNHOMDV.BackColor = Me.txtColor.BackColor
						Me.txtTUOI.BackColor = Me.txtColor.BackColor
						Me.txtJOB.BackColor = Me.txtColor.BackColor
						Me.txtRemark.BackColor = Me.txtColor.BackColor
						Me.cmbGIOTINH.Enabled = False
						Me.chkISSUP.Enabled = False
						Me.chkISCUS.Enabled = False
						Me.chkISFOR.Enabled = False
						Me.chkISORG.Enabled = False
					Case 5, 6
						Me.cmbStore.SelectedIndex = Me.cmbStore.Items.Count - 1
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060012A5 RID: 4773 RVA: 0x000E188C File Offset: 0x000DFA8C
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060012A6 RID: 4774 RVA: 0x000E1A1C File Offset: 0x000DFC1C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 20
				Me.txtOBJNAME.MaxLength = 60
				Me.txtADDRESS.MaxLength = 200
				Me.txtVATCODE.MaxLength = 20
				Me.txtTEL.MaxLength = 100
				Me.txtMOBILE.MaxLength = 100
				Me.txtFAX.MaxLength = 100
				Me.txtEMAIL.MaxLength = 200
				Me.txtWEBSITE.MaxLength = 200
				Me.txtCONTACT.MaxLength = 100
				Me.cmbStore.DropDownStyle = ComboBoxStyle.DropDownList
				Me.TxtTENNHOMDV.[ReadOnly] = True
				Me.TxtTENNHOMDV.BackColor = Me.txtColor.BackColor
				Dim flag As Boolean = (Me.mbytFormStatus = 5) Or (Me.mbytFormStatus = 6)
				If flag Then
					Me.chkISSUP.CheckState = CheckState.Indeterminate
					Me.chkISCUS.CheckState = CheckState.Indeterminate
					Me.chkISFOR.CheckState = CheckState.Indeterminate
					Me.chkISORG.CheckState = CheckState.Indeterminate
					Me.chkISSUP.ThreeState = True
					Me.chkISCUS.ThreeState = True
					Me.chkISFOR.ThreeState = True
					Me.chkISORG.ThreeState = True
				Else
					flag = Me.mbytFormStatus = 4
					If flag Then
						Me.cmbStore.DropDownStyle = ComboBoxStyle.DropDown
					End If
				End If
				Me.mtxBIRTHDAY.Mask = "00/00/0000"
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060012A7 RID: 4775 RVA: 0x000E1C60 File Offset: 0x000DFE60
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
					Me.lblBRANCH.Tag = "CB0031"
					Me.LblBIRTHDAY.Tag = "CR0012"
					Me.LblMANHOMDV.Tag = "CB0009"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060012A8 RID: 4776 RVA: 0x000E1E78 File Offset: 0x000E0078
		Private Sub sClear_Form()
			Try
				Me.mclsTbStore.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012A9 RID: 4777 RVA: 0x000E1F24 File Offset: 0x000E0124
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMDV")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mblnAutoAdd_DMDV = xmlNode.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012AA RID: 4778 RVA: 0x000E2020 File Offset: 0x000E0220
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(34) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pvchBIRTHDAY"
				array(2).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxBIRTHDAY.Text).Length <= 4, "", Strings.Trim(Me.mtxBIRTHDAY.Text)))
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchMANHOMDV"
				array(3).Value = Strings.Trim(Me.TxtMANHOMDV.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnchMAKH"
				array(4).Value = RuntimeHelpers.GetObjectValue(Me.cmbStore.SelectedValue)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcDC"
				array(5).Value = Strings.Trim(Me.txtADDRESS.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcVAT"
				array(6).Value = Strings.Trim(Me.txtVATCODE.Text)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnvcTEL"
				array(7).Value = Strings.Trim(Me.txtTEL.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnvcMOBI"
				array(8).Value = Strings.Trim(Me.txtMOBILE.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pnvcFAX"
				array(9).Value = Strings.Trim(Me.txtFAX.Text)
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pnvcEmail"
				array(10).Value = Strings.Trim(Me.txtEMAIL.Text)
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pnvcWeb"
				array(11).Value = Strings.Trim(Me.txtWEBSITE.Text)
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pnvcLH"
				array(12).Value = Strings.Trim(Me.txtCONTACT.Text)
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pbitSUP"
				array(13).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISSUP.Checked, 1, 0))
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitCUS"
				array(14).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISCUS.Checked, 1, 0))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pbitFOR"
				array(15).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISFOR.Checked, 1, 0))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pbitORG"
				array(16).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISORG.Checked, 1, 0))
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnvcTUOI"
				array(17).Value = Me.txtTUOI.Text.Trim()
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@ptniGIOITINH"
				array(18).Value = RuntimeHelpers.GetObjectValue(Me.cmbGIOTINH.SelectedValue)
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pnvcJOB"
				array(19).Value = Me.txtJOB.Text.Trim()
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = Me.txtRemark.Text.Trim()
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMAUSERUP"
				array(22).Value = mdlVariable.gStrUser
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnvcUIMAGE"
				array(23).Value = Me.mstrUIMAGE
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnvcCAP"
				array(24).Value = Me.txtCAP.Text.Trim()
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnvcCHUCVU"
				array(25).Value = Me.txtCHUCVU.Text.Trim()
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pmnyMUCGIAMGIA"
				array(26).Value = 0
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pnvcFINGER1"
				array(27).Value = Me.mStrFinger1
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pnvcFINGER2"
				array(28).Value = Me.mStrFinger2
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pnvcFINGER3"
				array(29).Value = Me.mStrFinger3
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnchCARDCODE"
				array(30).Value = Me.txtCardCode.Text.Trim()
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@pnvcNGAYNHANVIEC"
				array(31).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxNgayNhanViec.Text).Length <= 4, "", Strings.Trim(Me.mtxNgayNhanViec.Text)))
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pnvcNGAYTHOIVIEC"
				array(32).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxNgayThoiViec.Text).Length <= 4, "", Strings.Trim(Me.mtxNgayThoiViec.Text)))
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pnchMAUSERLK"
				array(33).Value = ""
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@int_Result"
				array(20).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_INSERT_DMDV", flag)
				Dim num As Integer = Conversions.ToInteger(array(20).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(65), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
							Me.txtOBJID.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060012AB RID: 4779 RVA: 0x000E2950 File Offset: 0x000E0B50
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(34) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = RuntimeHelpers.GetObjectValue(Me.cmbStore.SelectedValue)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcDC"
				array(3).Value = Strings.Trim(Me.txtADDRESS.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvcVAT"
				array(4).Value = Strings.Trim(Me.txtVATCODE.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvcTEL"
				array(5).Value = Strings.Trim(Me.txtTEL.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcMOBI"
				array(6).Value = Strings.Trim(Me.txtMOBILE.Text)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnvcFAX"
				array(7).Value = Strings.Trim(Me.txtFAX.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnvcEmail"
				array(8).Value = Strings.Trim(Me.txtEMAIL.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pnvcWeb"
				array(9).Value = Strings.Trim(Me.txtWEBSITE.Text)
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pnvcLH"
				array(10).Value = Strings.Trim(Me.txtCONTACT.Text)
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pbitSUP"
				array(11).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISSUP.Checked, 1, 0))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pbitCUS"
				array(12).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISCUS.Checked, 1, 0))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pbitFOR"
				array(13).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISFOR.Checked, 1, 0))
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pbitORG"
				array(14).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISORG.Checked, 1, 0))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pvchBIRTHDAY"
				array(15).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxBIRTHDAY.Text).Length <= 4, "", Strings.Trim(Me.mtxBIRTHDAY.Text)))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pnchMANHOMDV"
				array(16).Value = Me.TxtMANHOMDV.Text.Trim()
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnvcTUOI"
				array(17).Value = Me.txtTUOI.Text.Trim()
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@ptniGIOITINH"
				array(18).Value = RuntimeHelpers.GetObjectValue(Me.cmbGIOTINH.SelectedValue)
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pnvcJOB"
				array(19).Value = Me.txtJOB.Text.Trim()
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = Me.txtRemark.Text.Trim()
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMAUSERUP"
				array(22).Value = mdlVariable.gStrUser
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnvcUIMAGE"
				array(23).Value = Me.mstrUIMAGE
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnvcCAP"
				array(24).Value = Me.txtCAP.Text.Trim()
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnvcCHUCVU"
				array(25).Value = Me.txtCHUCVU.Text.Trim()
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pmnyMUCGIAMGIA"
				array(26).Value = 0
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pnvcFINGER1"
				array(27).Value = Me.mStrFinger1
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pnvcFINGER2"
				array(28).Value = Me.mStrFinger2
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pnvcFINGER3"
				array(29).Value = Me.mStrFinger3
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnchCARDCODE"
				array(30).Value = Me.txtCardCode.Text.Trim()
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@pnvcNGAYNHANVIEC"
				array(31).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxNgayNhanViec.Text).Length <= 4, "", Strings.Trim(Me.mtxNgayNhanViec.Text)))
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pnvcNGAYTHOIVIEC"
				array(32).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Trim(Me.mtxNgayThoiViec.Text).Length <= 4, "", Strings.Trim(Me.mtxNgayThoiViec.Text)))
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pnchMAUSERLK"
				array(33).Value = ""
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@int_Result"
				array(20).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_UPDATE_DMDV", flag)
				Dim num As Integer = Conversions.ToInteger(array(20).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(65), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060012AC RID: 4780 RVA: 0x000E3274 File Offset: 0x000E1474
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_DEL_DMDV", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Dim flag3 As Boolean = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(30), Me.btnDelete.Text, frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.Yes
							If flag3 Then
								b = Me.fDelete_Now()
							End If
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060012AD RID: 4781 RVA: 0x000E345C File Offset: 0x000E165C
		Private Function fDelete_Now() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_DEL_DMDV_NOW", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060012AE RID: 4782 RVA: 0x000E35E4 File Offset: 0x000E17E4
		Private Function fGetData_4Combo() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbStore = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = (Me.mbytFormStatus = 5) Or (Me.mbytFormStatus = 6)
				If flag Then
					Me.mclsTbStore.Rows.Add(New Object() { "", Me.mArrStrFrmMess(11) })
				End If
				flag = Me.mclsTbStore IsNot Nothing
				If flag Then
					Dim cmbStore As ComboBox = Me.cmbStore
					cmbStore.DataSource = Me.mclsTbStore
					cmbStore.DisplayMember = "OBJNAME"
					cmbStore.ValueMember = "OBJID"
					cmbStore.SelectedIndex = 0
					b = 1
				End If
				flag = Operators.CompareString(Me.mstrStore, "", False) <> 0
				If flag Then
					Me.cmbStore.SelectedValue = Me.mstrStore
					Me.cmbStore.Enabled = False
				End If
				flag = Operators.CompareString(Me.mStrBIRTHDAY, "", False) <> 0
				If flag Then
					Me.mtxBIRTHDAY.Text = Me.mStrBIRTHDAY
				End If
				Me.mtxNgayNhanViec.Text = Me.mStrNgayNhanViec.Trim()
				Me.mtxNgayThoiViec.Text = Me.mStrNgayThoiViec.Trim()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060012AF RID: 4783 RVA: 0x000E37DC File Offset: 0x000E19DC
		Private Sub BtnSELECTMANHOMDV_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMNHOMDV As frmDMNHOMDV1 = New frmDMNHOMDV1()
				frmDMNHOMDV.pBytOpen_From_Menu = 7
				frmDMNHOMDV.ShowDialog()
				Me.TxtMANHOMDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNHOMDV.pStrOBJID, "", False) = 0, Me.TxtMANHOMDV.Text, frmDMNHOMDV.pStrOBJID))
				Me.TxtTENNHOMDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNHOMDV.pStrOBJNAME, "", False) = 0, Me.TxtTENNHOMDV.Text, frmDMNHOMDV.pStrOBJNAME))
				frmDMNHOMDV.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - BtnSELECTMANHOMDV_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012B0 RID: 4784 RVA: 0x000E3900 File Offset: 0x000E1B00
		Private Sub TxtMANHOMDV_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxBIRTHDAY.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - TxtMANHOMDV_KeyPress( ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060012B1 RID: 4785 RVA: 0x000E39A4 File Offset: 0x000E1BA4
		Private Sub TxtMANHOMDV_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMNHOMDV Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMNHOMDV.Columns("OBJID")
					Me.mclsTbDMNHOMDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMNHOMDV.Rows.Find(Strings.Trim(Me.TxtMANHOMDV.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.TxtTENNHOMDV.Text = dataRow("OBJNAME").ToString()
					Else
						Me.TxtTENNHOMDV.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - TxtMANHOMDV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012B2 RID: 4786 RVA: 0x000E3AF8 File Offset: 0x000E1CF8
		Private Sub mtxBIRTHDAY_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbGIOTINH.Focus()
					Me.cmbGIOTINH.DroppedDown = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxBIRTHDAY_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060012B3 RID: 4787 RVA: 0x000E3BA8 File Offset: 0x000E1DA8
		Private Sub mtxBIRTHDAY_TextChanged(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.mtxBIRTHDAY.Text.Trim().Length <> 10
			If flag Then
				Me.txtTUOI.Text = ""
			Else
				Dim text As String = String.Concat(New String() { Strings.Mid(Me.mtxBIRTHDAY.Text, 7, 4), "/", Strings.Mid(Me.mtxBIRTHDAY.Text, 4, 2), "/", Strings.Mid(Me.mtxBIRTHDAY.Text, 1, 2) })
				flag = Information.IsDate(text)
				If flag Then
					Me.txtTUOI.Text = Conversions.ToString(Math.Round((DateAndTime.Now.[Date] - Convert.ToDateTime(text)).TotalDays / 365.0))
				End If
			End If
		End Sub

		' Token: 0x060012B4 RID: 4788 RVA: 0x000E3CA0 File Offset: 0x000E1EA0
		Private Sub picAnh_Click(sender As Object, e As EventArgs)
			Try
				Dim frmselectimage As frmselectimage = New frmselectimage()
				frmselectimage.ShowDialog()
				Dim flag As Boolean = (frmselectimage.pstrPath.Length > 2) And (Operators.CompareString(frmselectimage.pstrPath, "none", False) <> 0)
				If flag Then
					Me.picAnh.BackgroundImage = frmselectimage.pimgImage
					Me.mstrUIMAGE = frmselectimage.pstrPath
				End If
				flag = Operators.CompareString(frmselectimage.pstrPath, "none", False) = 0
				If flag Then
					Me.picAnh.BackgroundImage = frmselectimage.pimgImage
					Me.mstrUIMAGE = ""
				End If
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060012B5 RID: 4789 RVA: 0x000E3D60 File Offset: 0x000E1F60
		Private Sub picAnh_MouseHover(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.mstrUIMAGE Is Nothing OrElse Me.mstrUIMAGE.Length <= 1
			If Not flag Then
				Me.picZoom.BackgroundImage = Me.picAnh.BackgroundImage
				Me.picZoom.Visible = True
			End If
		End Sub

		' Token: 0x060012B6 RID: 4790 RVA: 0x00004DB6 File Offset: 0x00002FB6
		Private Sub picAnh_MouseLeave(sender As Object, e As EventArgs)
			Me.picZoom.Visible = False
		End Sub

		' Token: 0x060012B7 RID: 4791 RVA: 0x000E3DB8 File Offset: 0x000E1FB8
		Private Sub txtCAP_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtCHUCVU.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCAP_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060012B8 RID: 4792 RVA: 0x000E3E5C File Offset: 0x000E205C
		Private Sub txtCHUCVU_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtTEL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCHUCVU_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060012B9 RID: 4793 RVA: 0x000E3F00 File Offset: 0x000E2100
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x060012BA RID: 4794 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x060012BB RID: 4795 RVA: 0x000E3F7C File Offset: 0x000E217C
		Private Sub btnSaveAndSelect_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Not Me.mblnAutoAdd_DMDV AndAlso Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = Operators.CompareString(Strings.Trim(Me.TxtMANHOMDV.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(49), MsgBoxStyle.Critical, Nothing)
							Me.TxtMANHOMDV.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.TxtMANHOMDV.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.TxtTENNHOMDV.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
								Me.TxtMANHOMDV.Focus()
							Else
								flag = (Operators.CompareString(Strings.Trim(Me.mtxBIRTHDAY.Text.Replace("/", "")), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTUOI.Text), "", False) = 0)
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(57), MsgBoxStyle.Critical, Nothing)
									Me.mtxBIRTHDAY.Focus()
								Else
									flag = Not(Me.chkISCUS.Checked Or Me.chkISFOR.Checked Or Me.chkISORG.Checked Or Me.chkISSUP.Checked)
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(44), MsgBoxStyle.Critical, Nothing)
										Me.chkISSUP.Focus()
									Else
										flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
										If flag Then
											Me.mbytSuccess = Me.fAddNew()
										Else
											flag = Me.mbytFormStatus = 3
											If flag Then
												Me.mbytSuccess = Me.fModify()
											End If
										End If
										flag = Me.mbytSuccess = 1
										If flag Then
											Me.mblnSaveAndSelect = True
											Me.Close()
										Else
											Me.mblnSaveAndSelect = False
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSaveAndSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012BC RID: 4796 RVA: 0x000E42A8 File Offset: 0x000E24A8
		Private Sub frmDMDV2_KeyDown(sender As Object, e As KeyEventArgs)
			Dim flag As Boolean = e.KeyCode = Keys.F4
			If flag Then
				Me.btnSaveAndSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
			End If
		End Sub

		' Token: 0x060012BD RID: 4797 RVA: 0x000E42D4 File Offset: 0x000E24D4
		Private Sub cmbGIOTINH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtADDRESS.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbGIOTINH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060012BE RID: 4798 RVA: 0x000E4378 File Offset: 0x000E2578
		Private Sub btnFinger_Click(sender As Object, e As EventArgs)
			Try
				Dim frmFingerCus As frmFingerCus = New frmFingerCus()
				frmFingerCus.pStrMaDV = Me.txtOBJID.Text.Trim()
				frmFingerCus.pStrFinger1 = Me.mStrFinger1
				frmFingerCus.pStrFinger2 = Me.mStrFinger2
				frmFingerCus.pStrFinger3 = Me.mStrFinger3
				frmFingerCus.ShowDialog()
				Dim flag As Boolean = frmFingerCus.pbytsuccess = 1F
				If flag Then
					Me.mStrFinger1 = frmFingerCus.pStrFinger1
					Me.mStrFinger2 = frmFingerCus.pStrFinger2
					Me.mStrFinger3 = frmFingerCus.pStrFinger3
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFinger ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012BF RID: 4799 RVA: 0x000E448C File Offset: 0x000E268C
		Private Sub txtCardCode_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13 AndAlso mdlVariable.gblnLRemoveXChar
				If flag Then
					Me.txtCardCode.Text = Me.txtCardCode.Text.Trim().Replace("?", "").Replace(";", "")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtCardCode_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0400077E RID: 1918
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000780 RID: 1920
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000781 RID: 1921
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000782 RID: 1922
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000783 RID: 1923
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000784 RID: 1924
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000785 RID: 1925
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000786 RID: 1926
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000787 RID: 1927
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000788 RID: 1928
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000789 RID: 1929
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x0400078A RID: 1930
		<AccessedThroughProperty("chkISSUP")>
		Private _chkISSUP As CheckBox

		' Token: 0x0400078B RID: 1931
		<AccessedThroughProperty("lblEMAIL")>
		Private _lblEMAIL As Label

		' Token: 0x0400078C RID: 1932
		<AccessedThroughProperty("lblWEBSITE")>
		Private _lblWEBSITE As Label

		' Token: 0x0400078D RID: 1933
		<AccessedThroughProperty("cmbStore")>
		Private _cmbStore As ComboBox

		' Token: 0x0400078E RID: 1934
		<AccessedThroughProperty("lblBRANCH")>
		Private _lblBRANCH As Label

		' Token: 0x0400078F RID: 1935
		<AccessedThroughProperty("txtADDRESS")>
		Private _txtADDRESS As TextBox

		' Token: 0x04000790 RID: 1936
		<AccessedThroughProperty("txtTEL")>
		Private _txtTEL As TextBox

		' Token: 0x04000791 RID: 1937
		<AccessedThroughProperty("txtMOBILE")>
		Private _txtMOBILE As TextBox

		' Token: 0x04000792 RID: 1938
		<AccessedThroughProperty("txtCONTACT")>
		Private _txtCONTACT As TextBox

		' Token: 0x04000793 RID: 1939
		<AccessedThroughProperty("txtVATCODE")>
		Private _txtVATCODE As TextBox

		' Token: 0x04000794 RID: 1940
		<AccessedThroughProperty("txtFAX")>
		Private _txtFAX As TextBox

		' Token: 0x04000795 RID: 1941
		<AccessedThroughProperty("txtEMAIL")>
		Private _txtEMAIL As TextBox

		' Token: 0x04000796 RID: 1942
		<AccessedThroughProperty("txtWEBSITE")>
		Private _txtWEBSITE As TextBox

		' Token: 0x04000797 RID: 1943
		<AccessedThroughProperty("chkISCUS")>
		Private _chkISCUS As CheckBox

		' Token: 0x04000798 RID: 1944
		<AccessedThroughProperty("chkISFOR")>
		Private _chkISFOR As CheckBox

		' Token: 0x04000799 RID: 1945
		<AccessedThroughProperty("chkISORG")>
		Private _chkISORG As CheckBox

		' Token: 0x0400079A RID: 1946
		<AccessedThroughProperty("lblADDRESS")>
		Private _lblADDRESS As Label

		' Token: 0x0400079B RID: 1947
		<AccessedThroughProperty("lblTEL")>
		Private _lblTEL As Label

		' Token: 0x0400079C RID: 1948
		<AccessedThroughProperty("lblMOBILE")>
		Private _lblMOBILE As Label

		' Token: 0x0400079D RID: 1949
		<AccessedThroughProperty("lblCONTACT")>
		Private _lblCONTACT As Label

		' Token: 0x0400079E RID: 1950
		<AccessedThroughProperty("lblVATCODE")>
		Private _lblVATCODE As Label

		' Token: 0x0400079F RID: 1951
		<AccessedThroughProperty("lblFAX")>
		Private _lblFAX As Label

		' Token: 0x040007A0 RID: 1952
		<AccessedThroughProperty("lblISSUP")>
		Private _lblISSUP As Label

		' Token: 0x040007A1 RID: 1953
		<AccessedThroughProperty("lblISCUS")>
		Private _lblISCUS As Label

		' Token: 0x040007A2 RID: 1954
		<AccessedThroughProperty("lblISFOR")>
		Private _lblISFOR As Label

		' Token: 0x040007A3 RID: 1955
		<AccessedThroughProperty("lblISORG")>
		Private _lblISORG As Label

		' Token: 0x040007A4 RID: 1956
		<AccessedThroughProperty("txtColor")>
		Private _txtColor As TextBox

		' Token: 0x040007A5 RID: 1957
		<AccessedThroughProperty("BtnSELECTMANHOMDV")>
		Private _BtnSELECTMANHOMDV As Button

		' Token: 0x040007A6 RID: 1958
		<AccessedThroughProperty("TxtTENNHOMDV")>
		Private _TxtTENNHOMDV As TextBox

		' Token: 0x040007A7 RID: 1959
		<AccessedThroughProperty("TxtMANHOMDV")>
		Private _TxtMANHOMDV As TextBox

		' Token: 0x040007A8 RID: 1960
		<AccessedThroughProperty("LblMANHOMDV")>
		Private _LblMANHOMDV As Label

		' Token: 0x040007A9 RID: 1961
		<AccessedThroughProperty("LblBIRTHDAY")>
		Private _LblBIRTHDAY As Label

		' Token: 0x040007AA RID: 1962
		<AccessedThroughProperty("mtxBIRTHDAY")>
		Private _mtxBIRTHDAY As MaskedTextBox

		' Token: 0x040007AB RID: 1963
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040007AC RID: 1964
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x040007AD RID: 1965
		<AccessedThroughProperty("txtTUOI")>
		Private _txtTUOI As TextBox

		' Token: 0x040007AE RID: 1966
		<AccessedThroughProperty("cmbGIOTINH")>
		Private _cmbGIOTINH As ComboBox

		' Token: 0x040007AF RID: 1967
		<AccessedThroughProperty("lblNAMGIOI")>
		Private _lblNAMGIOI As Label

		' Token: 0x040007B0 RID: 1968
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x040007B1 RID: 1969
		<AccessedThroughProperty("txtJOB")>
		Private _txtJOB As TextBox

		' Token: 0x040007B2 RID: 1970
		<AccessedThroughProperty("txtRemark")>
		Private _txtRemark As TextBox

		' Token: 0x040007B3 RID: 1971
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x040007B4 RID: 1972
		<AccessedThroughProperty("Panel1")>
		Private _Panel1 As Panel

		' Token: 0x040007B5 RID: 1973
		<AccessedThroughProperty("picAnh")>
		Private _picAnh As PictureBox

		' Token: 0x040007B6 RID: 1974
		<AccessedThroughProperty("picZoom")>
		Private _picZoom As PictureBox

		' Token: 0x040007B7 RID: 1975
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x040007B8 RID: 1976
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x040007B9 RID: 1977
		<AccessedThroughProperty("txtCHUCVU")>
		Private _txtCHUCVU As TextBox

		' Token: 0x040007BA RID: 1978
		<AccessedThroughProperty("txtCAP")>
		Private _txtCAP As TextBox

		' Token: 0x040007BB RID: 1979
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x040007BC RID: 1980
		<AccessedThroughProperty("btnSaveAndSelect")>
		Private _btnSaveAndSelect As Button

		' Token: 0x040007BD RID: 1981
		<AccessedThroughProperty("btnFinger")>
		Private _btnFinger As Button

		' Token: 0x040007BE RID: 1982
		<AccessedThroughProperty("txtCardCode")>
		Private _txtCardCode As TextBox

		' Token: 0x040007BF RID: 1983
		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		' Token: 0x040007C0 RID: 1984
		<AccessedThroughProperty("mtxNgayThoiViec")>
		Private _mtxNgayThoiViec As MaskedTextBox

		' Token: 0x040007C1 RID: 1985
		<AccessedThroughProperty("Label8")>
		Private _Label8 As Label

		' Token: 0x040007C2 RID: 1986
		<AccessedThroughProperty("mtxNgayNhanViec")>
		Private _mtxNgayNhanViec As MaskedTextBox

		' Token: 0x040007C3 RID: 1987
		<AccessedThroughProperty("Label9")>
		Private _Label9 As Label

		' Token: 0x040007C4 RID: 1988
		Private mArrStrFrmMess As String()

		' Token: 0x040007C5 RID: 1989
		Private mbytFormStatus As Byte

		' Token: 0x040007C6 RID: 1990
		Private mbytSuccess As Byte

		' Token: 0x040007C7 RID: 1991
		Private mStrFilter As String

		' Token: 0x040007C8 RID: 1992
		Private mclsTbStore As clsConnect

		' Token: 0x040007C9 RID: 1993
		Private mclsTbDMBK As clsConnect

		' Token: 0x040007CA RID: 1994
		Private mstrStore As String

		' Token: 0x040007CB RID: 1995
		Private mStrBIRTHDAY As String

		' Token: 0x040007CC RID: 1996
		Private mclsTbDMNHOMDV As clsConnect

		' Token: 0x040007CD RID: 1997
		Private mbytGIOITINH As Byte

		' Token: 0x040007CE RID: 1998
		Private mstrUIMAGE As String

		' Token: 0x040007CF RID: 1999
		Private mblnSaveAndSelect As Boolean

		' Token: 0x040007D0 RID: 2000
		Private mStrFinger1 As String

		' Token: 0x040007D1 RID: 2001
		Private mStrFinger2 As String

		' Token: 0x040007D2 RID: 2002
		Private mStrFinger3 As String

		' Token: 0x040007D3 RID: 2003
		Private mStrNgayNhanViec As String

		' Token: 0x040007D4 RID: 2004
		Private mStrNgayThoiViec As String

		' Token: 0x040007D5 RID: 2005
		Private mblnAutoAdd_DMDV As Boolean
	End Class
End Namespace
