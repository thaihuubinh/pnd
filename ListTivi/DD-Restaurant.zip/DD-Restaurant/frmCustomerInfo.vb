﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports System.Xml
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000030 RID: 48
	<DesignerGenerated()>
	Public Partial Class frmCustomerInfo
		Inherits Form

		' Token: 0x060009A9 RID: 2473 RVA: 0x0007203C File Offset: 0x0007023C
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmCustomer_Load
			AddHandler MyBase.KeyPress, AddressOf Me.frmCustomer_KeyPress
			frmCustomerInfo.__ENCList.Add(New WeakReference(Me))
			Me.mstrMa = ""
			Me.mstrTen = ""
			Me.mstrNHOMDV = ""
			Me.mstrDiachi = ""
			Me.mstrDienthoai = ""
			Me.mdblMucGiamGia = 0.0
			Me.mdblPointMoney = 0.0
			Me.mdblTienMatScore = 0.0
			Me.mbdsSourceDMDV = New BindingSource()
			Me.mintPosDV = 0
			Me.mblnRightSelectDV = True
			Me.mintCount = 0
			Me.mintCountTruoc = 0
			Me.mblnClickSave = False
			Me.mdblSoDiemTru = 0.0
			Me.mdblTongCongBill = 0.0
			Me.mdblTienDiemSuDung = 0.0
			Me.mdblMONEY_OF_1POINT = 0.0
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700038F RID: 911
		' (get) Token: 0x060009AC RID: 2476 RVA: 0x00075140 File Offset: 0x00073340
		' (set) Token: 0x060009AD RID: 2477 RVA: 0x00075158 File Offset: 0x00073358
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._Label1 IsNot Nothing
				If flag Then
					RemoveHandler Me._Label1.Click, AddressOf Me.Label1_Click
				End If
				Me._Label1 = value
				flag = Me._Label1 IsNot Nothing
				If flag Then
					AddHandler Me._Label1.Click, AddressOf Me.Label1_Click
				End If
			End Set
		End Property

		' Token: 0x17000390 RID: 912
		' (get) Token: 0x060009AE RID: 2478 RVA: 0x000751C4 File Offset: 0x000733C4
		' (set) Token: 0x060009AF RID: 2479 RVA: 0x00003955 File Offset: 0x00001B55
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x17000391 RID: 913
		' (get) Token: 0x060009B0 RID: 2480 RVA: 0x000751DC File Offset: 0x000733DC
		' (set) Token: 0x060009B1 RID: 2481 RVA: 0x000751F4 File Offset: 0x000733F4
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000392 RID: 914
		' (get) Token: 0x060009B2 RID: 2482 RVA: 0x00075260 File Offset: 0x00073460
		' (set) Token: 0x060009B3 RID: 2483 RVA: 0x00075278 File Offset: 0x00073478
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000393 RID: 915
		' (get) Token: 0x060009B4 RID: 2484 RVA: 0x000752E4 File Offset: 0x000734E4
		' (set) Token: 0x060009B5 RID: 2485 RVA: 0x0000395F File Offset: 0x00001B5F
		Friend Overridable Property lblTen As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTen
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTen = value
			End Set
		End Property

		' Token: 0x17000394 RID: 916
		' (get) Token: 0x060009B6 RID: 2486 RVA: 0x000752FC File Offset: 0x000734FC
		' (set) Token: 0x060009B7 RID: 2487 RVA: 0x00075314 File Offset: 0x00073514
		Friend Overridable Property btnKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKH.Click, AddressOf Me.btnKH_Click
				End If
				Me._btnKH = value
				flag = Me._btnKH IsNot Nothing
				If flag Then
					AddHandler Me._btnKH.Click, AddressOf Me.btnKH_Click
				End If
			End Set
		End Property

		' Token: 0x17000395 RID: 917
		' (get) Token: 0x060009B8 RID: 2488 RVA: 0x00075380 File Offset: 0x00073580
		' (set) Token: 0x060009B9 RID: 2489 RVA: 0x00075398 File Offset: 0x00073598
		Friend Overridable Property txtMa As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMa
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMa IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMa.KeyDown, AddressOf Me.txtMa_KeyDown
					RemoveHandler Me._txtMa.TextChanged, AddressOf Me.txtMa_TextChanged
				End If
				Me._txtMa = value
				flag = Me._txtMa IsNot Nothing
				If flag Then
					AddHandler Me._txtMa.KeyDown, AddressOf Me.txtMa_KeyDown
					AddHandler Me._txtMa.TextChanged, AddressOf Me.txtMa_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000396 RID: 918
		' (get) Token: 0x060009BA RID: 2490 RVA: 0x00075434 File Offset: 0x00073634
		' (set) Token: 0x060009BB RID: 2491 RVA: 0x0007544C File Offset: 0x0007364C
		Friend Overridable Property tmrRight As Timer
			<DebuggerNonUserCode()>
			Get
				Return Me._tmrRight
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim flag As Boolean = Me._tmrRight IsNot Nothing
				If flag Then
					RemoveHandler Me._tmrRight.Tick, AddressOf Me.tmrRight_Tick
				End If
				Me._tmrRight = value
				flag = Me._tmrRight IsNot Nothing
				If flag Then
					AddHandler Me._tmrRight.Tick, AddressOf Me.tmrRight_Tick
				End If
			End Set
		End Property

		' Token: 0x17000397 RID: 919
		' (get) Token: 0x060009BC RID: 2492 RVA: 0x000754B8 File Offset: 0x000736B8
		' (set) Token: 0x060009BD RID: 2493 RVA: 0x00003969 File Offset: 0x00001B69
		Friend Overridable Property ContextMenuStrip1 As ContextMenuStrip
			<DebuggerNonUserCode()>
			Get
				Return Me._ContextMenuStrip1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ContextMenuStrip)
				Me._ContextMenuStrip1 = value
			End Set
		End Property

		' Token: 0x17000398 RID: 920
		' (get) Token: 0x060009BE RID: 2494 RVA: 0x000754D0 File Offset: 0x000736D0
		' (set) Token: 0x060009BF RID: 2495 RVA: 0x00003973 File Offset: 0x00001B73
		Friend Overridable Property lblTitle As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTitle
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTitle = value
			End Set
		End Property

		' Token: 0x17000399 RID: 921
		' (get) Token: 0x060009C0 RID: 2496 RVA: 0x000754E8 File Offset: 0x000736E8
		' (set) Token: 0x060009C1 RID: 2497 RVA: 0x0000397D File Offset: 0x00001B7D
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x1700039A RID: 922
		' (get) Token: 0x060009C2 RID: 2498 RVA: 0x00075500 File Offset: 0x00073700
		' (set) Token: 0x060009C3 RID: 2499 RVA: 0x00003987 File Offset: 0x00001B87
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x1700039B RID: 923
		' (get) Token: 0x060009C4 RID: 2500 RVA: 0x00075518 File Offset: 0x00073718
		' (set) Token: 0x060009C5 RID: 2501 RVA: 0x00003991 File Offset: 0x00001B91
		Friend Overridable Property lblDiaChi As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDiaChi
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDiaChi = value
			End Set
		End Property

		' Token: 0x1700039C RID: 924
		' (get) Token: 0x060009C6 RID: 2502 RVA: 0x00075530 File Offset: 0x00073730
		' (set) Token: 0x060009C7 RID: 2503 RVA: 0x0000399B File Offset: 0x00001B9B
		Friend Overridable Property Label6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label6 = value
			End Set
		End Property

		' Token: 0x1700039D RID: 925
		' (get) Token: 0x060009C8 RID: 2504 RVA: 0x00075548 File Offset: 0x00073748
		' (set) Token: 0x060009C9 RID: 2505 RVA: 0x000039A5 File Offset: 0x00001BA5
		Friend Overridable Property Label7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		' Token: 0x1700039E RID: 926
		' (get) Token: 0x060009CA RID: 2506 RVA: 0x00075560 File Offset: 0x00073760
		' (set) Token: 0x060009CB RID: 2507 RVA: 0x000039AF File Offset: 0x00001BAF
		Friend Overridable Property lblDauKy As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDauKy
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDauKy = value
			End Set
		End Property

		' Token: 0x1700039F RID: 927
		' (get) Token: 0x060009CC RID: 2508 RVA: 0x00075578 File Offset: 0x00073778
		' (set) Token: 0x060009CD RID: 2509 RVA: 0x000039B9 File Offset: 0x00001BB9
		Friend Overridable Property lblDienThoai As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDienThoai
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDienThoai = value
			End Set
		End Property

		' Token: 0x170003A0 RID: 928
		' (get) Token: 0x060009CE RID: 2510 RVA: 0x00075590 File Offset: 0x00073790
		' (set) Token: 0x060009CF RID: 2511 RVA: 0x000039C3 File Offset: 0x00001BC3
		Friend Overridable Property Label10 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label10 = value
			End Set
		End Property

		' Token: 0x170003A1 RID: 929
		' (get) Token: 0x060009D0 RID: 2512 RVA: 0x000755A8 File Offset: 0x000737A8
		' (set) Token: 0x060009D1 RID: 2513 RVA: 0x000039CD File Offset: 0x00001BCD
		Friend Overridable Property Label11 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label11
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label11 = value
			End Set
		End Property

		' Token: 0x170003A2 RID: 930
		' (get) Token: 0x060009D2 RID: 2514 RVA: 0x000755C0 File Offset: 0x000737C0
		' (set) Token: 0x060009D3 RID: 2515 RVA: 0x000039D7 File Offset: 0x00001BD7
		Friend Overridable Property lblCuoiKy As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCuoiKy
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCuoiKy = value
			End Set
		End Property

		' Token: 0x170003A3 RID: 931
		' (get) Token: 0x060009D4 RID: 2516 RVA: 0x000755D8 File Offset: 0x000737D8
		' (set) Token: 0x060009D5 RID: 2517 RVA: 0x000039E1 File Offset: 0x00001BE1
		Friend Overridable Property lblTrongKy As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTrongKy
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTrongKy = value
			End Set
		End Property

		' Token: 0x170003A4 RID: 932
		' (get) Token: 0x060009D6 RID: 2518 RVA: 0x000755F0 File Offset: 0x000737F0
		' (set) Token: 0x060009D7 RID: 2519 RVA: 0x000039EB File Offset: 0x00001BEB
		Friend Overridable Property Label14 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label14
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label14 = value
			End Set
		End Property

		' Token: 0x170003A5 RID: 933
		' (get) Token: 0x060009D8 RID: 2520 RVA: 0x00075608 File Offset: 0x00073808
		' (set) Token: 0x060009D9 RID: 2521 RVA: 0x00075620 File Offset: 0x00073820
		Friend Overridable Property btnCongTru As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCongTru
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._btnCongTru IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCongTru.Click, AddressOf Me.btnCongTru_Click
				End If
				Me._btnCongTru = value
				flag = Me._btnCongTru IsNot Nothing
				If flag Then
					AddHandler Me._btnCongTru.Click, AddressOf Me.btnCongTru_Click
				End If
			End Set
		End Property

		' Token: 0x170003A6 RID: 934
		' (get) Token: 0x060009DA RID: 2522 RVA: 0x0007568C File Offset: 0x0007388C
		' (set) Token: 0x060009DB RID: 2523 RVA: 0x000756A4 File Offset: 0x000738A4
		Friend Overridable Property txtDiem As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtDiem
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtDiem IsNot Nothing
				If flag Then
					RemoveHandler Me._txtDiem.KeyPress, AddressOf Me.txtDiem_KeyPress
					RemoveHandler Me._txtDiem.TextChanged, AddressOf Me.txtDiem_TextChanged
				End If
				Me._txtDiem = value
				flag = Me._txtDiem IsNot Nothing
				If flag Then
					AddHandler Me._txtDiem.KeyPress, AddressOf Me.txtDiem_KeyPress
					AddHandler Me._txtDiem.TextChanged, AddressOf Me.txtDiem_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170003A7 RID: 935
		' (get) Token: 0x060009DC RID: 2524 RVA: 0x00075740 File Offset: 0x00073940
		' (set) Token: 0x060009DD RID: 2525 RVA: 0x00075758 File Offset: 0x00073958
		Friend Overridable Property btnDiem As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDiem
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDiem IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDiem.Click, AddressOf Me.btnDiem_Click
				End If
				Me._btnDiem = value
				flag = Me._btnDiem IsNot Nothing
				If flag Then
					AddHandler Me._btnDiem.Click, AddressOf Me.btnDiem_Click
				End If
			End Set
		End Property

		' Token: 0x170003A8 RID: 936
		' (get) Token: 0x060009DE RID: 2526 RVA: 0x000757C4 File Offset: 0x000739C4
		' (set) Token: 0x060009DF RID: 2527 RVA: 0x000039F5 File Offset: 0x00001BF5
		Friend Overridable Property Label16 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label16
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label16 = value
			End Set
		End Property

		' Token: 0x170003A9 RID: 937
		' (get) Token: 0x060009E0 RID: 2528 RVA: 0x000757DC File Offset: 0x000739DC
		' (set) Token: 0x060009E1 RID: 2529 RVA: 0x000039FF File Offset: 0x00001BFF
		Friend Overridable Property lblConLai As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblConLai
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblConLai = value
			End Set
		End Property

		' Token: 0x170003AA RID: 938
		' (get) Token: 0x060009E2 RID: 2530 RVA: 0x000757F4 File Offset: 0x000739F4
		' (set) Token: 0x060009E3 RID: 2531 RVA: 0x0007580C File Offset: 0x00073A0C
		Friend Overridable Property dgvDMDV As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvDMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvDMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvDMDV.KeyDown, AddressOf Me.dgvDMDV_KeyDown
				End If
				Me._dgvDMDV = value
				flag = Me._dgvDMDV IsNot Nothing
				If flag Then
					AddHandler Me._dgvDMDV.KeyDown, AddressOf Me.dgvDMDV_KeyDown
				End If
			End Set
		End Property

		' Token: 0x170003AB RID: 939
		' (get) Token: 0x060009E4 RID: 2532 RVA: 0x00075878 File Offset: 0x00073A78
		' (set) Token: 0x060009E5 RID: 2533 RVA: 0x00003A09 File Offset: 0x00001C09
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x170003AC RID: 940
		' (get) Token: 0x060009E6 RID: 2534 RVA: 0x00075890 File Offset: 0x00073A90
		' (set) Token: 0x060009E7 RID: 2535 RVA: 0x00003A13 File Offset: 0x00001C13
		Friend Overridable Property lblCMND As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCMND
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCMND = value
			End Set
		End Property

		' Token: 0x170003AD RID: 941
		' (get) Token: 0x060009E8 RID: 2536 RVA: 0x000758A8 File Offset: 0x00073AA8
		' (set) Token: 0x060009E9 RID: 2537 RVA: 0x00003A1D File Offset: 0x00001C1D
		Friend Overridable Property Label9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label9 = value
			End Set
		End Property

		' Token: 0x170003AE RID: 942
		' (get) Token: 0x060009EA RID: 2538 RVA: 0x000758C0 File Offset: 0x00073AC0
		' (set) Token: 0x060009EB RID: 2539 RVA: 0x00003A27 File Offset: 0x00001C27
		Friend Overridable Property lblNgaySinh As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblNgaySinh
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblNgaySinh = value
			End Set
		End Property

		' Token: 0x170003AF RID: 943
		' (get) Token: 0x060009EC RID: 2540 RVA: 0x000758D8 File Offset: 0x00073AD8
		' (set) Token: 0x060009ED RID: 2541 RVA: 0x00003A31 File Offset: 0x00001C31
		Friend Overridable Property Label13 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label13
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label13 = value
			End Set
		End Property

		' Token: 0x170003B0 RID: 944
		' (get) Token: 0x060009EE RID: 2542 RVA: 0x000758F0 File Offset: 0x00073AF0
		' (set) Token: 0x060009EF RID: 2543 RVA: 0x00003A3B File Offset: 0x00001C3B
		Friend Overridable Property Label15 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label15
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label15 = value
			End Set
		End Property

		' Token: 0x170003B1 RID: 945
		' (get) Token: 0x060009F0 RID: 2544 RVA: 0x00075908 File Offset: 0x00073B08
		' (set) Token: 0x060009F1 RID: 2545 RVA: 0x00003A45 File Offset: 0x00001C45
		Friend Overridable Property lblTienNo As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTienNo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTienNo = value
			End Set
		End Property

		' Token: 0x170003B2 RID: 946
		' (get) Token: 0x060009F2 RID: 2546 RVA: 0x00075920 File Offset: 0x00073B20
		' (set) Token: 0x060009F3 RID: 2547 RVA: 0x00003A4F File Offset: 0x00001C4F
		Friend Overridable Property lblTienHoaHong As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTienHoaHong
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTienHoaHong = value
			End Set
		End Property

		' Token: 0x170003B3 RID: 947
		' (get) Token: 0x060009F4 RID: 2548 RVA: 0x00075938 File Offset: 0x00073B38
		' (set) Token: 0x060009F5 RID: 2549 RVA: 0x00003A59 File Offset: 0x00001C59
		Friend Overridable Property Label19 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label19
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label19 = value
			End Set
		End Property

		' Token: 0x170003B4 RID: 948
		' (get) Token: 0x060009F6 RID: 2550 RVA: 0x00075950 File Offset: 0x00073B50
		' (set) Token: 0x060009F7 RID: 2551 RVA: 0x00003A63 File Offset: 0x00001C63
		Friend Overridable Property lblTienDauKy As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTienDauKy
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTienDauKy = value
			End Set
		End Property

		' Token: 0x170003B5 RID: 949
		' (get) Token: 0x060009F8 RID: 2552 RVA: 0x00075968 File Offset: 0x00073B68
		' (set) Token: 0x060009F9 RID: 2553 RVA: 0x00003A6D File Offset: 0x00001C6D
		Friend Overridable Property Label21 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label21
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label21 = value
			End Set
		End Property

		' Token: 0x170003B6 RID: 950
		' (get) Token: 0x060009FA RID: 2554 RVA: 0x00075980 File Offset: 0x00073B80
		' (set) Token: 0x060009FB RID: 2555 RVA: 0x00003A77 File Offset: 0x00001C77
		Friend Overridable Property lblTienTrongKy As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTienTrongKy
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTienTrongKy = value
			End Set
		End Property

		' Token: 0x170003B7 RID: 951
		' (get) Token: 0x060009FC RID: 2556 RVA: 0x00075998 File Offset: 0x00073B98
		' (set) Token: 0x060009FD RID: 2557 RVA: 0x00003A81 File Offset: 0x00001C81
		Friend Overridable Property Label23 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label23
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label23 = value
			End Set
		End Property

		' Token: 0x170003B8 RID: 952
		' (get) Token: 0x060009FE RID: 2558 RVA: 0x000759B0 File Offset: 0x00073BB0
		' (set) Token: 0x060009FF RID: 2559 RVA: 0x00003A8B File Offset: 0x00001C8B
		Friend Overridable Property Label24 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label24
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label24 = value
			End Set
		End Property

		' Token: 0x170003B9 RID: 953
		' (get) Token: 0x06000A00 RID: 2560 RVA: 0x000759C8 File Offset: 0x00073BC8
		' (set) Token: 0x06000A01 RID: 2561 RVA: 0x000759E0 File Offset: 0x00073BE0
		Friend Overridable Property lblDiemSuDung As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDiemSuDung
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblDiemSuDung IsNot Nothing
				If flag Then
					RemoveHandler Me._lblDiemSuDung.Click, AddressOf Me.lblDiemSuDung_Click
				End If
				Me._lblDiemSuDung = value
				flag = Me._lblDiemSuDung IsNot Nothing
				If flag Then
					AddHandler Me._lblDiemSuDung.Click, AddressOf Me.lblDiemSuDung_Click
				End If
			End Set
		End Property

		' Token: 0x170003BA RID: 954
		' (get) Token: 0x06000A02 RID: 2562 RVA: 0x00075A4C File Offset: 0x00073C4C
		' (set) Token: 0x06000A03 RID: 2563 RVA: 0x00003A95 File Offset: 0x00001C95
		Friend Overridable Property lblTienSuDung As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTienSuDung
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTienSuDung = value
			End Set
		End Property

		' Token: 0x170003BB RID: 955
		' (get) Token: 0x06000A04 RID: 2564 RVA: 0x00075A64 File Offset: 0x00073C64
		' (set) Token: 0x06000A05 RID: 2565 RVA: 0x00003A9F File Offset: 0x00001C9F
		Friend Overridable Property Label27 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label27
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label27 = value
			End Set
		End Property

		' Token: 0x170003BC RID: 956
		' (get) Token: 0x06000A06 RID: 2566 RVA: 0x00075A7C File Offset: 0x00073C7C
		' (set) Token: 0x06000A07 RID: 2567 RVA: 0x00003AA9 File Offset: 0x00001CA9
		Friend Overridable Property lblTienCuoiKy As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTienCuoiKy
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTienCuoiKy = value
			End Set
		End Property

		' Token: 0x170003BD RID: 957
		' (get) Token: 0x06000A08 RID: 2568 RVA: 0x00075A94 File Offset: 0x00073C94
		' (set) Token: 0x06000A09 RID: 2569 RVA: 0x00003AB3 File Offset: 0x00001CB3
		Friend Overridable Property Label29 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label29
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label29 = value
			End Set
		End Property

		' Token: 0x170003BE RID: 958
		' (get) Token: 0x06000A0A RID: 2570 RVA: 0x00075AAC File Offset: 0x00073CAC
		' (set) Token: 0x06000A0B RID: 2571 RVA: 0x00075AC4 File Offset: 0x00073CC4
		Friend Overridable Property lblLyDo As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLyDo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._lblLyDo IsNot Nothing
				If flag Then
					RemoveHandler Me._lblLyDo.TextChanged, AddressOf Me.txtDiem_TextChanged
				End If
				Me._lblLyDo = value
				flag = Me._lblLyDo IsNot Nothing
				If flag Then
					AddHandler Me._lblLyDo.TextChanged, AddressOf Me.txtDiem_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170003BF RID: 959
		' (get) Token: 0x06000A0C RID: 2572 RVA: 0x00075B30 File Offset: 0x00073D30
		' (set) Token: 0x06000A0D RID: 2573 RVA: 0x00003ABD File Offset: 0x00001CBD
		Friend Overridable Property Label30 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label30
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label30 = value
			End Set
		End Property

		' Token: 0x170003C0 RID: 960
		' (get) Token: 0x06000A0E RID: 2574 RVA: 0x00075B48 File Offset: 0x00073D48
		' (set) Token: 0x06000A0F RID: 2575 RVA: 0x00003AC7 File Offset: 0x00001CC7
		Friend Overridable Property lblTongCong As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTongCong
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTongCong = value
			End Set
		End Property

		' Token: 0x170003C1 RID: 961
		' (get) Token: 0x06000A10 RID: 2576 RVA: 0x00075B60 File Offset: 0x00073D60
		' (set) Token: 0x06000A11 RID: 2577 RVA: 0x00003AD1 File Offset: 0x00001CD1
		Friend Overridable Property Label32 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label32
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label32 = value
			End Set
		End Property

		' Token: 0x170003C2 RID: 962
		' (get) Token: 0x06000A12 RID: 2578 RVA: 0x00075B78 File Offset: 0x00073D78
		' (set) Token: 0x06000A13 RID: 2579 RVA: 0x00003ADB File Offset: 0x00001CDB
		Friend Overridable Property lblThanhToan As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblThanhToan
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblThanhToan = value
			End Set
		End Property

		' Token: 0x170003C3 RID: 963
		' (get) Token: 0x06000A14 RID: 2580 RVA: 0x00075B90 File Offset: 0x00073D90
		' (set) Token: 0x06000A15 RID: 2581 RVA: 0x00075BA8 File Offset: 0x00073DA8
		Friend Overridable Property lblKeyLyDo As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblKeyLyDo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblKeyLyDo IsNot Nothing
				If flag Then
					RemoveHandler Me._lblKeyLyDo.Click, AddressOf Me.lblKeyLyDo_Click
				End If
				Me._lblKeyLyDo = value
				flag = Me._lblKeyLyDo IsNot Nothing
				If flag Then
					AddHandler Me._lblKeyLyDo.Click, AddressOf Me.lblKeyLyDo_Click
				End If
			End Set
		End Property

		' Token: 0x170003C4 RID: 964
		' (get) Token: 0x06000A16 RID: 2582 RVA: 0x00075C14 File Offset: 0x00073E14
		' (set) Token: 0x06000A17 RID: 2583 RVA: 0x00003AE5 File Offset: 0x00001CE5
		Friend Overridable Property Label35 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label35
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label35 = value
			End Set
		End Property

		' Token: 0x170003C5 RID: 965
		' (get) Token: 0x06000A18 RID: 2584 RVA: 0x00075C2C File Offset: 0x00073E2C
		' (set) Token: 0x06000A19 RID: 2585 RVA: 0x00003AEF File Offset: 0x00001CEF
		Friend Overridable Property Label8 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label8 = value
			End Set
		End Property

		' Token: 0x170003C6 RID: 966
		' (get) Token: 0x06000A1A RID: 2586 RVA: 0x00075C44 File Offset: 0x00073E44
		' (set) Token: 0x06000A1B RID: 2587 RVA: 0x00003AF9 File Offset: 0x00001CF9
		Friend Overridable Property Label12 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label12
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label12 = value
			End Set
		End Property

		' Token: 0x06000A1C RID: 2588
		Private Declare Ansi Function BlockInput Lib "user32" (fBlock As Long) As Long

		' Token: 0x170003C7 RID: 967
		' (get) Token: 0x06000A1D RID: 2589 RVA: 0x00075C5C File Offset: 0x00073E5C
		' (set) Token: 0x06000A1E RID: 2590 RVA: 0x00075C74 File Offset: 0x00073E74
		Private Overridable Property mbdsSourceDMDV As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceDMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceDMDV.PositionChanged, AddressOf Me.mbdsSourceDMDV_PositionChanged
				End If
				Me._mbdsSourceDMDV = value
				flag = Me._mbdsSourceDMDV IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceDMDV.PositionChanged, AddressOf Me.mbdsSourceDMDV_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170003C8 RID: 968
		' (get) Token: 0x06000A1F RID: 2591 RVA: 0x00075CE0 File Offset: 0x00073EE0
		' (set) Token: 0x06000A20 RID: 2592 RVA: 0x00003B03 File Offset: 0x00001D03
		Public Property pdblTongCongBill As Double
			Get
				Return Me.mdblTongCongBill
			End Get
			Set(value As Double)
				Me.mdblTongCongBill = value
			End Set
		End Property

		' Token: 0x170003C9 RID: 969
		' (get) Token: 0x06000A21 RID: 2593 RVA: 0x00075CF8 File Offset: 0x00073EF8
		' (set) Token: 0x06000A22 RID: 2594 RVA: 0x00003B0E File Offset: 0x00001D0E
		Public Property pdblTienDiemSuDung As Double
			Get
				Return Me.mdblTienDiemSuDung
			End Get
			Set(value As Double)
				Me.mdblTienDiemSuDung = value
			End Set
		End Property

		' Token: 0x170003CA RID: 970
		' (get) Token: 0x06000A23 RID: 2595 RVA: 0x00075D10 File Offset: 0x00073F10
		' (set) Token: 0x06000A24 RID: 2596 RVA: 0x00003B19 File Offset: 0x00001D19
		Public Property pdblTienMatScore As Double
			Get
				Return Me.mdblTienMatScore
			End Get
			Set(value As Double)
				Me.mdblTienMatScore = value
			End Set
		End Property

		' Token: 0x170003CB RID: 971
		' (get) Token: 0x06000A25 RID: 2597 RVA: 0x00075D28 File Offset: 0x00073F28
		' (set) Token: 0x06000A26 RID: 2598 RVA: 0x00003B24 File Offset: 0x00001D24
		Public Property pdblMucGiamGia As Double
			Get
				Return Me.mdblMucGiamGia
			End Get
			Set(value As Double)
				Me.mdblMucGiamGia = value
			End Set
		End Property

		' Token: 0x170003CC RID: 972
		' (get) Token: 0x06000A27 RID: 2599 RVA: 0x00075D40 File Offset: 0x00073F40
		' (set) Token: 0x06000A28 RID: 2600 RVA: 0x00003B2F File Offset: 0x00001D2F
		Public Property pdblSoDiemTru As Double
			Get
				Return Me.mdblSoDiemTru
			End Get
			Set(value As Double)
				Me.mdblSoDiemTru = value
			End Set
		End Property

		' Token: 0x170003CD RID: 973
		' (get) Token: 0x06000A29 RID: 2601 RVA: 0x00075D58 File Offset: 0x00073F58
		' (set) Token: 0x06000A2A RID: 2602 RVA: 0x00003B3A File Offset: 0x00001D3A
		Public Property pstrDienthoai As String
			Get
				Return Me.mstrDienthoai
			End Get
			Set(value As String)
				Me.mstrDienthoai = value
			End Set
		End Property

		' Token: 0x170003CE RID: 974
		' (get) Token: 0x06000A2B RID: 2603 RVA: 0x00075D70 File Offset: 0x00073F70
		' (set) Token: 0x06000A2C RID: 2604 RVA: 0x00003B45 File Offset: 0x00001D45
		Public Property pdtNgaySinh As DateTime
			Get
				Return Me.mdtNgaySinh
			End Get
			Set(value As DateTime)
				Me.mdtNgaySinh = value
			End Set
		End Property

		' Token: 0x170003CF RID: 975
		' (get) Token: 0x06000A2D RID: 2605 RVA: 0x00075D88 File Offset: 0x00073F88
		' (set) Token: 0x06000A2E RID: 2606 RVA: 0x00003B50 File Offset: 0x00001D50
		Public Property pstrDiachi As String
			Get
				Return Me.mstrDiachi
			End Get
			Set(value As String)
				Me.mstrDiachi = value
			End Set
		End Property

		' Token: 0x170003D0 RID: 976
		' (get) Token: 0x06000A2F RID: 2607 RVA: 0x00075DA0 File Offset: 0x00073FA0
		Public ReadOnly Property pblnOK As Boolean
			Get
				Return Me.mblnOK
			End Get
		End Property

		' Token: 0x170003D1 RID: 977
		' (get) Token: 0x06000A30 RID: 2608 RVA: 0x00075DB8 File Offset: 0x00073FB8
		' (set) Token: 0x06000A31 RID: 2609 RVA: 0x00003B5B File Offset: 0x00001D5B
		Public Property pstrTenDv As String
			Get
				Return Me.mstrTen
			End Get
			Set(value As String)
				Me.mstrTen = value
			End Set
		End Property

		' Token: 0x170003D2 RID: 978
		' (get) Token: 0x06000A32 RID: 2610 RVA: 0x00075DD0 File Offset: 0x00073FD0
		' (set) Token: 0x06000A33 RID: 2611 RVA: 0x00003B66 File Offset: 0x00001D66
		Public Property pstrMadv As String
			Get
				Return Me.mstrMa
			End Get
			Set(value As String)
				Me.mstrMa = value
			End Set
		End Property

		' Token: 0x170003D3 RID: 979
		' (get) Token: 0x06000A34 RID: 2612 RVA: 0x00075DE8 File Offset: 0x00073FE8
		' (set) Token: 0x06000A35 RID: 2613 RVA: 0x00003B71 File Offset: 0x00001D71
		Public Property pstrMaNHOMdv As String
			Get
				Return Me.mstrNHOMDV
			End Get
			Set(value As String)
				Me.mstrNHOMDV = value
			End Set
		End Property

		' Token: 0x06000A36 RID: 2614 RVA: 0x00075E00 File Offset: 0x00074000
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/MONEY_OF_1POINT")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mdblMONEY_OF_1POINT = Double.Parse(xmlNode.InnerText)
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - sGetPara_From_SetparaXML " + ex.Message + vbCrLf, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A37 RID: 2615 RVA: 0x00075EB8 File Offset: 0x000740B8
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = (Operators.CompareString(Me.txtMa.Text.Trim(), "", False) <> 0) And (Operators.CompareString(Me.lblTen.Text.Trim(), "", False) = 0)
			If flag Then
				MessageBox.Show(Me.mArrStrFrmMess(6), Me.mArrStrFrmMess(17), MessageBoxButtons.OK, MessageBoxIcon.Hand)
				Me.txtMa.Focus()
			Else
				flag = (Operators.CompareString(Me.txtMa.Text.Trim(), "", False) = 0) And (Operators.CompareString(Me.lblTen.Text.Trim(), "", False) = 0)
				If flag Then
					Me.txtMa.Text = ""
					Me.mblnClickSave = True
					flag = Conversion.Val(Me.txtDiem.Text.Replace(",", "")) > 0.0
					If flag Then
						Me.sDecrease_DiemKM(mdlVariable.gStrStockCode, Me.txtMa.Text.Trim(), Me.lblTen.Text.Trim(), "")
					Else
						Me.Close()
					End If
				Else
					Me.mblnOK = True
					Me.mdblTienDiemSuDung = Conversion.Val(Me.lblTienSuDung.Text.Replace(",", ""))
					Dim num As Double = Conversion.Val(Me.txtDiem.Text.Replace(",", ""))
					flag = num > 0.0
					If flag Then
						Dim flag2 As Boolean = Operators.CompareString(Me.btnCongTru.Text, "-", False) = 0 AndAlso num > Conversion.Val(Me.lblDauKy.Text.Replace(",", ""))
						If flag2 Then
							MessageBox.Show(Me.mArrStrFrmMess(24), Me.mArrStrFrmMess(17), MessageBoxButtons.OK, MessageBoxIcon.Hand)
						Else
							Me.sDecrease_DiemKM(mdlVariable.gStrStockCode, Me.mstrMa.Trim(), Me.lblTen.Text.Trim(), "")
						End If
					Else
						Me.Close()
					End If
				End If
			End If
		End Sub

		' Token: 0x06000A38 RID: 2616 RVA: 0x00003B7C File Offset: 0x00001D7C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Me.mblnOK = False
			mdlFile.gfWriteLogFile("Nhấn nút thoát form chọn khách hàng.")
			Me.Close()
		End Sub

		' Token: 0x06000A39 RID: 2617 RVA: 0x00076104 File Offset: 0x00074304
		Private Sub frmCustomer_KeyPress(sender As Object, e As KeyPressEventArgs)
			Dim flag As Boolean = Strings.Asc(e.KeyChar) = 27
			Dim flag2 As Boolean
			If flag Then
				flag2 = Me.dgvDMDV.Visible
				If flag2 Then
					Me.dgvDMDV.Visible = False
					Me.Height = 666
					Me.Width = 632
					Me.Top = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Height) / 2.0 - CDbl(Me.Height) / 2.0))
					Me.Left = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Width) / 2.0 - CDbl(Me.Width) / 2.0))
					Me.txtMa.Focus()
				Else
					Me.mblnOK = False
					Me.Close()
				End If
			End If
			flag2 = Strings.Asc(e.KeyChar) = 13
			If flag2 Then
				flag = Me.dgvDMDV.Visible
				If Not flag Then
					flag2 = Me.mblnRightSelectDV
					If Not flag2 Then
						Me.btnSave_Click(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			End If
		End Sub

		' Token: 0x06000A3A RID: 2618 RVA: 0x0007623C File Offset: 0x0007443C
		Private Sub frmCustomer_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Me.sGetPara_From_SetparaXML()
				Me.fGetData_DMDV()
				Dim flag As Boolean = mdlUIForm.gfChek_RightSale("00024", False) = 0
				If flag Then
					Me.btnKH.Visible = False
					Me.mblnRightSelectDV = False
					Me.tmrRight.Enabled = True
					Me.tmrRight.Interval = 1200
					Me.txtMa.PasswordChar = "*"c
				End If
				Me.txtMa.Text = Me.mstrMa
				Me.lblTongCong.Text = mdlUIForm.gfFormatNumber(Me.mdblTongCongBill, CShort(mdlVariable.gbytDECNUMAMT), ",")
				Me.btnCongTru.Text = ""
				flag = mdlUIForm.gfChek_RightSale("00080", False) = 1
				If flag Then
					Me.btnCongTru.Text = "-"
				End If
				flag = mdlUIForm.gfChek_RightSale("00079", False) = 1
				If flag Then
					Me.btnCongTru.Text = "+"
				End If
				Me.lblDiemSuDung.Text = mdlUIForm.gfFormatNumber(Me.mdblSoDiemTru, CShort(mdlVariable.gbytDECNUMDIEM), ",")
				Me.lblTienSuDung.Text = mdlUIForm.gfFormatNumber(Me.mdblSoDiemTru * Me.mdblMONEY_OF_1POINT, CShort(mdlVariable.gbytDECNUMAMT), ",")
				Me.lblThanhToan.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Me.lblTongCong.Text.Replace(",", "")) - Conversion.Val(Me.lblTienSuDung.Text.Replace(",", "")), CShort(mdlVariable.gbytDECNUMAMT), ",")
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - frmSplitTable_Load() " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000A3B RID: 2619 RVA: 0x00076458 File Offset: 0x00074658
		Private Sub txtMa_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMDV Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMDV.Columns("OBJID")
					Me.mclsTbDMDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMDV.Rows.Find(Strings.Trim(Me.txtMa.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.mstrMa = dataRow("OBJID").ToString()
						Me.mstrTen = dataRow("OBJNAME").ToString()
						Me.mstrNHOMDV = dataRow("MANHOMDV").ToString()
						Me.mstrDiachi = dataRow("ADDRESS").ToString()
						Me.mstrDienthoai = dataRow("TEL").ToString()
						Me.mdtNgaySinh = Conversions.ToDate(dataRow("NGAYSINH").ToString())
						Me.mdblMucGiamGia = Conversion.Val(dataRow("MUCGIAMGIA").ToString())
						Me.mdblPointMoney = Conversion.Val(dataRow("POINTMONEY").ToString())
						Me.lblTen.Text = dataRow("OBJNAME").ToString()
						Me.lblDiaChi.Text = dataRow("ADDRESS").ToString()
						Me.lblDienThoai.Text = dataRow("MOBILE").ToString()
						Me.lblCMND.Text = dataRow("VATCODE").ToString()
						Me.lblNgaySinh.Text = dataRow("BIRTHDAY").ToString()
						Dim num As Double = CDbl(Me.f_HoaHong(Me.mstrMa.Trim()))
						Dim num2 As Double = mdlPrintReceipt.gfGet_TONGNO(DateAndTime.Now.ToString("yyyyMMdd"), DateAndTime.Now.ToString("yyyyMMdd HH:mm:ss"), Me.mstrMa.Trim())
						Me.lblTienHoaHong.Text = mdlUIForm.gfFormatNumber(num, CShort(mdlVariable.gbytDECNUMAMT), ",")
						Me.lblTienNo.Text = mdlUIForm.gfFormatNumber(num2, CShort(mdlVariable.gbytDECNUMAMT), ",")
						Me.lblDauKy.Text = mdlUIForm.gfFormatNumber(Me.fGetData_SCORE_DMDV(Me.txtMa.Text.Trim()), CShort(mdlVariable.gbytDECNUMDIEM), ",")
						Me.lblTienDauKy.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Conversions.ToDouble(Me.lblDauKy.Text.Replace(",", "")) * Me.mdblMONEY_OF_1POINT), CShort(mdlVariable.gbytDECNUMDIEM), ",")
						flag = mdlVariable.gbytDECNUMDIEM = 0
						If flag Then
							Me.lblTrongKy.Text = mdlUIForm.gfFormatNumber(Math.Floor(Me.mdblTienMatScore / Me.mdblPointMoney), CShort(mdlVariable.gbytDECNUMDIEM), ",")
						Else
							Me.lblTrongKy.Text = mdlUIForm.gfFormatNumber(Me.mdblTienMatScore / Me.mdblPointMoney, CShort(mdlVariable.gbytDECNUMDIEM), ",")
						End If
						Me.lblTienTrongKy.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Conversions.ToDouble(Me.lblTrongKy.Text.Replace(",", "")) * Me.mdblMONEY_OF_1POINT), CShort(mdlVariable.gbytDECNUMDIEM), ",")
						Me.lblDiemSuDung.Text = "0"
						Me.lblTienSuDung.Text = "0"
						Dim num3 As Double = Conversion.Val(Me.lblDauKy.Text.Replace(",", "")) + Conversion.Val(Me.lblTrongKy.Text.Replace(",", ""))
						Me.lblCuoiKy.Text = mdlUIForm.gfFormatNumber(num3, CShort(mdlVariable.gbytDECNUMDIEM), ",")
						Me.lblTienCuoiKy.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Conversions.ToDouble(Me.lblCuoiKy.Text.Replace(",", "")) * Me.mdblMONEY_OF_1POINT), CShort(mdlVariable.gbytDECNUMDIEM), ",")
						Me.sTinhDiemConLai()
					Else
						Dim text As String = Strings.Trim(Me.txtMa.Text)
						flag = mdlVariable.gblnLRemoveXChar
						If flag Then
							text = text.Trim().Replace("?", "").Replace(";", "")
						End If
						flag = text.Trim().Length > 0
						If flag Then
							array(0) = Me.mclsTbDMDV.Columns("CARDCODE")
							Me.mclsTbDMDV.PrimaryKey = array
							dataRow = Me.mclsTbDMDV.Rows.Find(text)
						End If
						flag = dataRow IsNot Nothing
						If flag Then
							Me.mstrMa = dataRow("OBJID").ToString()
							Me.mstrTen = dataRow("OBJNAME").ToString()
							Me.mstrNHOMDV = dataRow("MANHOMDV").ToString()
							Me.mstrDiachi = dataRow("ADDRESS").ToString()
							Me.mstrDienthoai = dataRow("TEL").ToString()
							Me.mdtNgaySinh = Conversions.ToDate(dataRow("NGAYSINH").ToString())
							Me.mdblMucGiamGia = Conversion.Val(dataRow("MUCGIAMGIA").ToString())
							Me.mdblPointMoney = Conversion.Val(dataRow("POINTMONEY").ToString())
							Me.lblTen.Text = dataRow("OBJNAME").ToString()
							Me.lblDiaChi.Text = dataRow("ADDRESS").ToString()
							Me.lblDienThoai.Text = dataRow("MOBILE").ToString()
							Me.lblDauKy.Text = mdlUIForm.gfFormatNumber(Me.fGetData_SCORE_DMDV(Me.txtMa.Text.Trim()), CShort(mdlVariable.gbytDECNUMDIEM), ",")
							Me.lblTienDauKy.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Conversions.ToDouble(Me.lblDauKy.Text.Replace(",", "")) * Me.mdblMONEY_OF_1POINT), CShort(mdlVariable.gbytDECNUMDIEM), ",")
							flag = mdlVariable.gbytDECNUMDIEM = 0
							If flag Then
								Me.lblTrongKy.Text = mdlUIForm.gfFormatNumber(Math.Floor(Me.mdblTienMatScore / Me.mdblPointMoney), CShort(mdlVariable.gbytDECNUMDIEM), ",")
							Else
								Me.lblTrongKy.Text = mdlUIForm.gfFormatNumber(Me.mdblTienMatScore / Me.mdblPointMoney, CShort(mdlVariable.gbytDECNUMDIEM), ",")
							End If
							Me.lblTienTrongKy.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Conversions.ToDouble(Me.lblTrongKy.Text.Replace(",", "")) * Me.mdblMONEY_OF_1POINT), CShort(mdlVariable.gbytDECNUMDIEM), ",")
							Me.lblDiemSuDung.Text = "0"
							Me.lblTienSuDung.Text = "0"
							Dim num4 As Double = Conversion.Val(Me.lblDauKy.Text.Replace(",", "")) + Conversion.Val(Me.lblTrongKy.Text.Replace(",", ""))
							Me.lblCuoiKy.Text = mdlUIForm.gfFormatNumber(num4, CShort(mdlVariable.gbytDECNUMDIEM), ",")
							Me.lblTienCuoiKy.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Conversions.ToDouble(Me.lblCuoiKy.Text.Replace(",", "")) * Me.mdblMONEY_OF_1POINT), CShort(mdlVariable.gbytDECNUMDIEM), ",")
							Me.sTinhDiemConLai()
						Else
							Me.lblTen.Text = ""
							Me.lblDiaChi.Text = ""
							Me.lblDienThoai.Text = ""
							Me.lblDauKy.Text = Conversions.ToString(0)
							Me.lblTrongKy.Text = Conversions.ToString(0)
							Me.lblCuoiKy.Text = Conversions.ToString(0)
							Me.sTinhDiemConLai()
							Me.mstrMa = ""
							Me.mstrTen = ""
							Me.mstrNHOMDV = ""
							Me.mstrDiachi = ""
							Me.mstrDienthoai = ""
						End If
					End If
					Me.lblThanhToan.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Me.lblTongCong.Text.Replace(",", "")) - Conversion.Val(Me.lblTienSuDung.Text.Replace(",", "")), CShort(mdlVariable.gbytDECNUMAMT), ",")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMa_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A3C RID: 2620 RVA: 0x00076E24 File Offset: 0x00075024
		Private Sub tmrRight_Tick(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.mblnRightSelectDV And Versioned.IsNumeric(Me.txtMa.Text.Trim()) And Not Me.mblnClickSave
			If flag Then
				Me.btnExit_Click(RuntimeHelpers.GetObjectValue(sender), e)
			End If
			Me.mblnClickSave = False
		End Sub

		' Token: 0x06000A3D RID: 2621 RVA: 0x00076E78 File Offset: 0x00075078
		Private Sub btnKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDV As frmDMDV1 = New frmDMDV1()
				mdlFile.gfWriteLogFile("Nhấn chọn mở danh mục khách hàng.")
				frmDMDV.pBytOpen_From_Menu = 7
				frmDMDV.pIntType = 1S
				frmDMDV.ShowDialog()
				Me.txtMa.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJID, "", False) = 0, Me.txtMa.Text, frmDMDV.pStrOBJID))
				Me.lblTen.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJNAME, "", False) = 0, Me.lblTen.Text, frmDMDV.pStrOBJNAME))
				Me.mstrNHOMDV = frmDMDV.pStrMANHOMDV
				frmDMDV.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnSoGhe_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000A3E RID: 2622 RVA: 0x0000393D File Offset: 0x00001B3D
		Protected Overrides Sub Finalize()
			MyBase.Finalize()
		End Sub

		' Token: 0x06000A3F RID: 2623 RVA: 0x00076FA0 File Offset: 0x000751A0
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000A40 RID: 2624 RVA: 0x0007709C File Offset: 0x0007529C
		Private Function f_GetData_4GridMADV() As Byte
			' The following expression was wrapped in a checked-statement
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = Me.mclsTbDMDV Is Nothing
				If Not flag Then
					Me.Height = 666
					Me.Width = 800
					Me.Top = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Height) / 2.0 - CDbl(Me.Height) / 2.0))
					Me.Left = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Width) / 2.0 - CDbl(Me.Width) / 2.0))
					Me.dgvDMDV.Visible = True
					Me.dgvDMDV.DataSource = Nothing
					Me.dgvDMDV.ColumnHeadersVisible = True
					Me.dgvDMDV.MultiSelect = False
					Me.dgvDMDV.RowHeadersVisible = False
					Me.dgvDMDV.SelectionMode = DataGridViewSelectionMode.FullRowSelect
					Me.dgvDMDV.StandardTab = False
					Me.dgvDMDV.TabStop = False
					Me.dgvDMDV.AllowUserToAddRows = False
					Me.dgvDMDV.AllowUserToDeleteRows = False
					Me.dgvDMDV.AllowUserToOrderColumns = False
					Me.dgvDMDV.AllowUserToResizeRows = False
					Me.dgvDMDV.AllowDrop = False
					Me.dgvDMDV.RowTemplate.Height = 25
					Me.dgvDMDV.AlternatingRowsDefaultCellStyle.BackColor = mdlVariable.gobjcloOddRowGrid
					Dim text As String = Me.txtMa.Text.Trim()
					text = Conversions.ToString(NewLateBinding.LateGet(Nothing, GetType(Strings), "UCase", New Object() { RuntimeHelpers.GetObjectValue(Interaction.IIf(Operators.CompareString(Strings.Mid(text, 1, 1), "*", False) = 0, Strings.Mid(text, 2), text)) }, Nothing, Nothing, Nothing))
					Dim dataTable As DataTable = New DataTable()
					dataTable.Columns.Add("STT")
					dataTable.Columns.Add("OBJID")
					dataTable.Columns.Add("OBJNAME")
					dataTable.Columns.Add("ADDRESS")
					dataTable.Columns.Add("MOBILE")
					dataTable.Columns.Add("BIRTHDAY")
					dataTable.Columns.Add("MANHOMDV")
					dataTable.Columns.Add("TENNHOMDV")
					dataTable.Columns.Add("VATCODE")
					dataTable.Columns.Add("TEL")
					dataTable.Columns.Add("MUCGIAMGIA")
					dataTable.Columns.Add("NGAYSINH")
					dataTable.Columns.Add("POINTMONEY")
					flag = Me.mclsTbDMDV.Rows.Count > 0
					Dim flag3 As Boolean
					If flag Then
						Dim num As Integer = 0
						Dim num2 As Integer = Me.mclsTbDMDV.Rows.Count - 1
						Dim num3 As Integer = num
						While True
							Dim num4 As Integer = num3
							Dim num5 As Integer = num2
							If num4 > num5 Then
								Exit For
							End If
							Dim obj As Object = Nothing
							Dim typeFromHandle As Type = GetType(Strings)
							Dim text2 As String = "UCase"
							Dim array As Object() = New Object(0) {}
							Dim array2 As Object() = array
							Dim num6 As Integer = 0
							Dim dataRow As DataRow = Me.mclsTbDMDV.Rows(num3)
							Dim dataRow2 As DataRow = dataRow
							Dim text3 As String = "OBJID"
							array2(num6) = RuntimeHelpers.GetObjectValue(dataRow2(text3))
							Dim array3 As Object() = array
							Dim array4 As Object() = array3
							Dim array5 As String() = Nothing
							Dim array6 As Type() = Nothing
							Dim array7 As Boolean() = New Boolean() { True }
							Dim obj2 As Object = NewLateBinding.LateGet(obj, typeFromHandle, text2, array4, array5, array6, array7)
							If array7(0) Then
								dataRow(text3) = RuntimeHelpers.GetObjectValue(array3(0))
							End If
							If Strings.InStr(Conversions.ToString(obj2), text, CompareMethod.Binary) > 0 Then
								GoTo IL_0417
							End If
							Dim obj3 As Object = Nothing
							Dim typeFromHandle2 As Type = GetType(Strings)
							Dim text4 As String = "UCase"
							Dim array8 As Object() = New Object(0) {}
							Dim array9 As Object() = array8
							Dim num7 As Integer = 0
							Dim dataRow3 As DataRow = Me.mclsTbDMDV.Rows(num3)
							Dim dataRow4 As DataRow = dataRow3
							Dim text5 As String = "OBJNAME"
							array9(num7) = RuntimeHelpers.GetObjectValue(dataRow4(text5))
							Dim array10 As Object() = array8
							Dim array11 As Object() = array10
							Dim array12 As String() = Nothing
							Dim array13 As Type() = Nothing
							Dim array14 As Boolean() = New Boolean() { True }
							Dim obj4 As Object = NewLateBinding.LateGet(obj3, typeFromHandle2, text4, array11, array12, array13, array14)
							If array14(0) Then
								dataRow3(text5) = RuntimeHelpers.GetObjectValue(array10(0))
							End If
							If Strings.InStr(mdlPrintReceipt.gfRemove_signVie(Conversions.ToString(obj4)), text, CompareMethod.Binary) > 0 Then
								GoTo IL_0417
							End If
							Dim obj5 As Object = Nothing
							Dim typeFromHandle3 As Type = GetType(Strings)
							Dim text6 As String = "UCase"
							Dim array15 As Object() = New Object(0) {}
							Dim array16 As Object() = array15
							Dim num8 As Integer = 0
							Dim dataRow5 As DataRow = Me.mclsTbDMDV.Rows(num3)
							Dim dataRow6 As DataRow = dataRow5
							Dim text7 As String = "OBJNAME"
							array16(num8) = RuntimeHelpers.GetObjectValue(dataRow6(text7))
							Dim array17 As Object() = array15
							Dim array18 As Object() = array17
							Dim array19 As String() = Nothing
							Dim array20 As Type() = Nothing
							Dim array21 As Boolean() = New Boolean() { True }
							Dim obj6 As Object = NewLateBinding.LateGet(obj5, typeFromHandle3, text6, array18, array19, array20, array21)
							If array21(0) Then
								dataRow5(text7) = RuntimeHelpers.GetObjectValue(array17(0))
							End If
							If Strings.InStr(Conversions.ToString(obj6), text, CompareMethod.Binary) > 0 Then
								GoTo IL_04A5
							End If
							Dim obj7 As Object = Nothing
							Dim typeFromHandle4 As Type = GetType(Strings)
							Dim text8 As String = "UCase"
							Dim array22 As Object() = New Object(0) {}
							Dim array23 As Object() = array22
							Dim num9 As Integer = 0
							Dim dataRow7 As DataRow = Me.mclsTbDMDV.Rows(num3)
							Dim dataRow8 As DataRow = dataRow7
							Dim text9 As String = "MOBILE"
							array23(num9) = RuntimeHelpers.GetObjectValue(dataRow8(text9))
							Dim array24 As Object() = array22
							Dim array25 As Object() = array24
							Dim array26 As String() = Nothing
							Dim array27 As Type() = Nothing
							Dim array28 As Boolean() = New Boolean() { True }
							Dim obj8 As Object = NewLateBinding.LateGet(obj7, typeFromHandle4, text8, array25, array26, array27, array28)
							If array28(0) Then
								dataRow7(text9) = RuntimeHelpers.GetObjectValue(array24(0))
							End If
							If Strings.InStr(Conversions.ToString(obj8), text, CompareMethod.Binary) > 0 Then
								GoTo IL_0536
							End If
							Dim flag2 As Boolean = False
							IL_0537:
							flag3 = flag2
							If flag3 Then
								dataTable.Rows.Add(New Object(-1) {})
								dataTable.Rows(dataTable.Rows.Count - 1)("STT") = dataTable.Rows.Count
								dataTable.Rows(dataTable.Rows.Count - 1)("OBJID") = Me.mclsTbDMDV.Rows(num3)("OBJID").ToString().Trim()
								dataTable.Rows(dataTable.Rows.Count - 1)("OBJNAME") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("OBJNAME"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("ADDRESS") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("ADDRESS"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("MOBILE") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("MOBILE"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("BIRTHDAY") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("BIRTHDAY"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("MANHOMDV") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("MANHOMDV"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("TENNHOMDV") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("TENNHOMDV"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("VATCODE") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("VATCODE"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("TEL") = Operators.ConcatenateObject(Me.mclsTbDMDV.Rows(num3)("TEL"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("MUCGIAMGIA") = RuntimeHelpers.GetObjectValue(Me.mclsTbDMDV.Rows(num3)("MUCGIAMGIA"))
								dataTable.Rows(dataTable.Rows.Count - 1)("NGAYSINH") = RuntimeHelpers.GetObjectValue(Me.mclsTbDMDV.Rows(num3)("NGAYSINH"))
								dataTable.Rows(dataTable.Rows.Count - 1)("POINTMONEY") = RuntimeHelpers.GetObjectValue(Me.mclsTbDMDV.Rows(num3)("POINTMONEY"))
							End If
							num3 += 1
							Continue For
							IL_0536:
							flag2 = True
							GoTo IL_0537
							IL_04A5:
							GoTo IL_0536
							IL_0417:
							GoTo IL_04A5
						End While
					End If
					Me.mbdsSourceDMDV.DataSource = dataTable
					Me.dgvDMDV.DataSource = Me.mbdsSourceDMDV
					Me.dgvDMDV.Columns("MANHOMDV").Visible = False
					Me.dgvDMDV.Columns("VATCODE").Visible = False
					Me.dgvDMDV.Columns("TEL").Visible = False
					Me.dgvDMDV.Columns("MUCGIAMGIA").Visible = False
					Me.dgvDMDV.Columns("NGAYSINH").Visible = False
					Me.dgvDMDV.Columns("POINTMONEY").Visible = False
					Me.dgvDMDV.Columns("STT").Width = 35
					Me.dgvDMDV.Columns("STT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
					Me.dgvDMDV.Columns("STT").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
					Me.dgvDMDV.Columns("OBJID").Width = 85
					Me.dgvDMDV.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
					Me.dgvDMDV.Columns("OBJNAME").Width = Me.dgvDMDV.Width - 610
					Me.dgvDMDV.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
					Me.dgvDMDV.Columns("ADDRESS").Width = 160
					Me.dgvDMDV.Columns("ADDRESS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(28))
					Me.dgvDMDV.Columns("MOBILE").Width = 105
					Me.dgvDMDV.Columns("MOBILE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(29))
					Me.dgvDMDV.Columns("BIRTHDAY").Width = 85
					Me.dgvDMDV.Columns("BIRTHDAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(30))
					Me.dgvDMDV.Columns("BIRTHDAY").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
					Me.dgvDMDV.Columns("TENNHOMDV").Width = 120
					Me.dgvDMDV.Columns("TENNHOMDV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(31))
					flag3 = dataTable.Rows.Count > 0
					If flag3 Then
						Me.dgvDMDV.Focus()
					End If
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - f_GetData_4GridMADV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000A41 RID: 2625 RVA: 0x00077D60 File Offset: 0x00075F60
		Private Function fGetData_DMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
				Dim text As String = "SP_FRMSAL011_GET_DMDV"
				Dim flag As Boolean = Nothing
				Me.mclsTbDMDV = New clsConnect(gStrConISDANHMUC, text, flag)
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000A42 RID: 2626 RVA: 0x00077E20 File Offset: 0x00076020
		Private Function fGetData_SCORE_DMDV(strMaDV As String) As Double
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim clsConnect As clsConnect = New clsConnect()
			Dim num As Double
			Try
				num = 0.0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnvcTO"
				array(0).Value = DateAndTime.Now.ToString("yyyyMMdd")
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAKH"
				array(1).Value = mdlVariable.gStrStockCode
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMADV"
				array(2).Value = strMaDV
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@bytRetr"
				array(3).Direction = ParameterDirection.ReturnValue
				Dim num2 As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_REP_SAL60807_GET_DATA", num2)
				Dim flag As Boolean = clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
				If flag Then
					num = Conversion.Val(RuntimeHelpers.GetObjectValue(clsConnect.Rows(0)("DIEMCONLAI")))
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_SCORE_DMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return num
		End Function

		' Token: 0x06000A43 RID: 2627 RVA: 0x00077FEC File Offset: 0x000761EC
		Private Sub sTinhDiemConLai()
			Try
				Dim flag As Boolean = Operators.CompareString(Me.btnCongTru.Text.Trim(), "", False) = 0
				If Not flag Then
					Dim num As Double = Conversion.Val(Me.lblCuoiKy.Text.Replace(",", ""))
					Dim num2 As Double = Conversion.Val(Me.txtDiem.Text.Replace(",", ""))
					flag = Operators.CompareString(Me.btnCongTru.Text, "+", False) = 0
					Dim num3 As Double
					If flag Then
						num3 = num + num2
					Else
						num3 = num - num2
					End If
					Me.lblConLai.Text = mdlUIForm.gfFormatNumber(num3, CShort(mdlVariable.gbytDECNUMDIEM), ",")
				End If
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06000A44 RID: 2628 RVA: 0x000780DC File Offset: 0x000762DC
		Private Sub btnCongTru_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Me.btnCongTru.Text.Trim(), "", False) = 0
				If Not flag Then
					flag = Operators.CompareString(Me.btnCongTru.Text, "+", False) = 0
					If flag Then
						Dim flag2 As Boolean = mdlUIForm.gfChek_RightSale("00080", False) = 1
						If flag2 Then
							Me.btnCongTru.Text = "-"
						End If
					Else
						Dim flag2 As Boolean = Operators.CompareString(Me.btnCongTru.Text, "-", False) = 0
						If flag2 Then
							flag = mdlUIForm.gfChek_RightSale("00079", False) = 1
							If flag Then
								Me.btnCongTru.Text = "+"
							End If
						End If
					End If
					Me.sTinhDiemConLai()
				End If
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06000A45 RID: 2629 RVA: 0x000781C4 File Offset: 0x000763C4
		Private Sub txtDiem_TextChanged(sender As Object, e As EventArgs)
			Try
				Me.sTinhDiemConLai()
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06000A46 RID: 2630 RVA: 0x00078200 File Offset: 0x00076400
		Private Sub btnDiem_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad = New frmNumPad()
				frmNumPad.ShowDialog()
				Me.txtDiem.Text = Conversions.ToString(frmNumPad.pSglNumberReturn)
				Me.sTinhDiemConLai()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnDiem_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000A47 RID: 2631 RVA: 0x000782A4 File Offset: 0x000764A4
		Private Sub txtDiem_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_0100
					Case 13
						GoTo IL_0100
				End Select
				e.Handled = True
				IL_0100:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(21), vbCrLf, Me.Name, " - txtDiem_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000A48 RID: 2632 RVA: 0x00078434 File Offset: 0x00076634
		Private Sub sDecrease_DiemKM(pstrMAKH As String, pStrMADV As String, pStrTENDV As String, Optional pstrDk As String = "")
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Try
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				Dim text As String = ""
				Dim num As Double = Conversion.Val(Me.btnCongTru.Text.Trim() + Me.txtDiem.Text.Trim().Replace(",", ""))
				Dim text2 As String = mdlUIForm.gfFormatNumber(Math.Abs(num), CShort(mdlVariable.gbytDECNUMDIEM), ",")
				Dim flag As Boolean = pStrMADV.Trim().Length = 0
				If flag Then
					Me.mdblSoDiemTru = 0.0
					flag = Operators.CompareString(Me.btnCongTru.Text, "+", False) = 0
					If flag Then
						text = String.Concat(New String() { Me.mArrStrFrmMess(22), " ", text2, " ", Me.mArrStrFrmMess(21) })
					Else
						flag = Operators.CompareString(Me.btnCongTru.Text, "-", False) = 0
						If flag Then
							text = String.Concat(New String() { Me.mArrStrFrmMess(23), " ", text2, " ", Me.mArrStrFrmMess(21) })
						End If
					End If
				Else
					flag = Operators.CompareString(Me.btnCongTru.Text, "+", False) = 0
					If flag Then
						text = String.Concat(New String() { Me.mArrStrFrmMess(19), " '", pStrTENDV.Trim(), "' ", text2, " ", Me.mArrStrFrmMess(21) })
						Me.mdblSoDiemTru = 0.0
					Else
						flag = Operators.CompareString(Me.btnCongTru.Text, "-", False) = 0
						If flag Then
							text = String.Concat(New String() { Me.mArrStrFrmMess(20), " '", pStrTENDV.Trim(), "' ", text2, " ", Me.mArrStrFrmMess(21) })
							Me.mdblSoDiemTru = num
						End If
					End If
				End If
				flag = Operators.CompareString(text.Trim(), "", False) = 0
				If flag Then
					Me.Close()
				Else
					flag = MyProject.Forms.frmMyMessage.Show(text, Me.mArrStrFrmMess(14), frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.No
					If Not flag Then
						array(0) = sqlCommand.CreateParameter()
						array(0).ParameterName = "@pmnyPOINT"
						array(0).Value = num
						array(1) = sqlCommand.CreateParameter()
						array(1).ParameterName = "@pnchMAKH"
						array(1).Value = pstrMAKH
						array(2) = sqlCommand.CreateParameter()
						array(2).ParameterName = "@pnchMADV"
						array(2).Value = pStrMADV
						array(4) = sqlCommand.CreateParameter()
						array(4).ParameterName = "@pnvcREMARK"
						array(4).Value = Me.lblLyDo.Text.Trim()
						array(3) = sqlCommand.CreateParameter()
						array(3).ParameterName = "@bytRetr"
						array(3).Direction = ParameterDirection.ReturnValue
						Dim flag2 As Boolean
						clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_REP_SAL60807_DECREASE", flag2)
						flag = Operators.ConditionalCompareObjectEqual(array(3).Value, 0, False)
						If flag Then
							Me.Close()
						Else
							MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(18), Me.mArrStrFrmMess(17), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.ThongTin)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(20), vbCrLf, Me.Name, " - sDecrease_DiemKM ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
			End Try
		End Sub

		' Token: 0x06000A49 RID: 2633 RVA: 0x0007890C File Offset: 0x00076B0C
		Private Function f_HoaHong(strMaDV As String) As Integer
			Dim num2 As Integer
			Try
				Dim clsConnect As clsConnect = New clsConnect()
				Dim sqlCommand As SqlCommand = New SqlCommand()
				Dim array As SqlParameter() = New SqlParameter(9) {}
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnvcFROM"
				array(0).Value = DateAndTime.Now.ToString("yyyyMMdd")
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTO"
				array(1).Value = DateAndTime.Now.ToString("yyyyMMdd")
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = mdlVariable.gStrStockCodeRes
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchMANH"
				array(3).Value = ""
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnchMAUSER"
				array(4).Value = ""
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnchMADV"
				array(5).Value = strMaDV
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnchMANSX"
				array(6).Value = ""
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnchMAPL"
				array(7).Value = ""
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@bytRetr"
				array(8).Direction = ParameterDirection.ReturnValue
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_REP_SALEMODE_GET_DATA_HOAHONG_DV", num)
				Dim flag As Boolean = num = 1 AndAlso clsConnect.Rows.Count > 0
				If flag Then
					' The following expression was wrapped in a checked-expression
					num2 = CInt(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(clsConnect.Rows(0)("HOAHONG")))))
				Else
					num2 = 0
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " f_HoaHong", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return num2
		End Function

		' Token: 0x06000A4A RID: 2634 RVA: 0x00078BA0 File Offset: 0x00076DA0
		Private Sub txtMa_KeyDown(sender As Object, e As KeyEventArgs)
			Try
				Dim flag As Boolean = e.KeyCode = Keys.Down
				If flag Then
					Dim b As Byte = Me.f_GetData_4GridMADV()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADV_KeyDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000A4B RID: 2635 RVA: 0x00078C3C File Offset: 0x00076E3C
		Private Sub dgvDMDV_KeyDown(sender As Object, e As KeyEventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim keyCode As Keys = e.KeyCode
				Dim flag As Boolean = keyCode = Keys.[Return]
				If flag Then
					Dim flag2 As Boolean = Me.mbdsSourceDMDV.Count > 0
					If flag2 Then
						Me.txtMa.Text = Conversions.ToString(Me.dgvDMDV("OBJID", Me.mintPosDV).Value)
					End If
					Me.dgvDMDV.Visible = False
					Me.Height = 666
					Me.Width = 632
					Me.Top = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Height) / 2.0 - CDbl(Me.Height) / 2.0))
					Me.Left = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Width) / 2.0 - CDbl(Me.Width) / 2.0))
					Me.txtMa.Focus()
				Else
					Dim flag3 As Boolean
					If keyCode < Keys.D1 OrElse keyCode > Keys.D9 Then
						If keyCode < Keys.NumPad1 OrElse keyCode > Keys.NumPad9 Then
							flag3 = False
							GoTo IL_0125
						End If
					End If
					flag3 = True
					IL_0125:
					Dim flag2 As Boolean = flag3
					If flag2 Then
						Dim num As Integer = e.KeyCode - Keys.D0
						flag2 = num > 9
						If flag2 Then
							num -= 48
						End If
						flag2 = (Me.mbdsSourceDMDV.Count >= num) And (num > 0)
						If flag2 Then
							Me.txtMa.Text = Conversions.ToString(Me.dgvDMDV("OBJID", Me.mintPosDV).Value)
							Me.txtMa.Focus()
							Me.dgvDMDV.Visible = False
							Me.Height = 666
							Me.Width = 632
							Me.Top = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Height) / 2.0 - CDbl(Me.Height) / 2.0))
							Me.Left = CInt(Math.Round(CDbl(Screen.PrimaryScreen.WorkingArea.Width) / 2.0 - CDbl(Me.Width) / 2.0))
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvDMDV_KeyDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A4C RID: 2636 RVA: 0x00078F2C File Offset: 0x0007712C
		Private Sub mbdsSourceDMDV_PositionChanged(sender As Object, e As EventArgs)
			Try
				Me.mintPosDV = Me.mbdsSourceDMDV.Position
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceDMDV_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000A4D RID: 2637 RVA: 0x00078FD0 File Offset: 0x000771D0
		Private Sub Label1_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.mblnRightSelectDV
			If Not flag Then
				Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
				frmKeyBoard.ShowDialog()
				flag = frmKeyBoard.pBlnOK
				If flag Then
					Me.txtMa.Text = frmKeyBoard.pStrEnterText
				End If
			End If
		End Sub

		' Token: 0x06000A4E RID: 2638 RVA: 0x0007901C File Offset: 0x0007721C
		Private Sub lblDiemSuDung_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad
				Dim num As Double
				Dim num2 As Double
				While True
					frmNumPad = New frmNumPad()
					frmNumPad.ShowDialog()
					Dim flag As Boolean = frmNumPad.pbytSuccess = 1
					If Not flag Then
						GoTo IL_0202
					End If
					num = Conversion.Val(Me.lblDauKy.Text.Replace(",", ""))
					num2 = Conversion.Val(Me.lblTrongKy.Text.Replace(",", ""))
					flag = CDbl(frmNumPad.pSglNumberReturn) > num
					If flag Then
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(45), Me.mArrStrFrmMess(46), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
					Else
						flag = CDbl(frmNumPad.pSglNumberReturn) * Me.mdblMONEY_OF_1POINT > Me.mdblTongCongBill
						If Not flag Then
							Exit For
						End If
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(47), Me.mArrStrFrmMess(46), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
					End If
				End While
				Me.lblDiemSuDung.Text = mdlUIForm.gfFormatNumber(CDbl(frmNumPad.pSglNumberReturn), CShort(mdlVariable.gbytDECNUMDIEM), ",")
				Me.lblTienSuDung.Text = mdlUIForm.gfFormatNumber(CDbl(frmNumPad.pSglNumberReturn) * Me.mdblMONEY_OF_1POINT, CShort(mdlVariable.gbytDECNUMDIEM), ",")
				Dim num3 As Double = num + num2 - CDbl(frmNumPad.pSglNumberReturn)
				Me.lblCuoiKy.Text = mdlUIForm.gfFormatNumber(num3, CShort(mdlVariable.gbytDECNUMDIEM), ",")
				Me.lblTienCuoiKy.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Conversions.ToDouble(Me.lblCuoiKy.Text.Replace(",", "")) * Me.mdblMONEY_OF_1POINT), CShort(mdlVariable.gbytDECNUMDIEM), ",")
				Me.lblThanhToan.Text = mdlUIForm.gfFormatNumber(Conversion.Val(Me.lblTongCong.Text.Replace(",", "")) - Conversion.Val(Me.lblTienSuDung.Text.Replace(",", "")), CShort(mdlVariable.gbytDECNUMAMT), ",")
				Me.sTinhDiemConLai()
				IL_0202:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - lblDiemSuDung_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000A4F RID: 2639 RVA: 0x000792B8 File Offset: 0x000774B8
		Private Sub lblKeyLyDo_Click(sender As Object, e As EventArgs)
			Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
			frmKeyBoard.ShowDialog()
			Dim pBlnOK As Boolean = frmKeyBoard.pBlnOK
			If pBlnOK Then
				Me.lblLyDo.Text = frmKeyBoard.pStrEnterText
			End If
		End Sub

		' Token: 0x0400043C RID: 1084
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400043E RID: 1086
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x0400043F RID: 1087
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x04000440 RID: 1088
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000441 RID: 1089
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000442 RID: 1090
		<AccessedThroughProperty("lblTen")>
		Private _lblTen As Label

		' Token: 0x04000443 RID: 1091
		<AccessedThroughProperty("btnKH")>
		Private _btnKH As Button

		' Token: 0x04000444 RID: 1092
		<AccessedThroughProperty("txtMa")>
		Private _txtMa As TextBox

		' Token: 0x04000445 RID: 1093
		<AccessedThroughProperty("tmrRight")>
		Private _tmrRight As Timer

		' Token: 0x04000446 RID: 1094
		<AccessedThroughProperty("ContextMenuStrip1")>
		Private _ContextMenuStrip1 As ContextMenuStrip

		' Token: 0x04000447 RID: 1095
		<AccessedThroughProperty("lblTitle")>
		Private _lblTitle As Label

		' Token: 0x04000448 RID: 1096
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000449 RID: 1097
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x0400044A RID: 1098
		<AccessedThroughProperty("lblDiaChi")>
		Private _lblDiaChi As Label

		' Token: 0x0400044B RID: 1099
		<AccessedThroughProperty("Label6")>
		Private _Label6 As Label

		' Token: 0x0400044C RID: 1100
		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		' Token: 0x0400044D RID: 1101
		<AccessedThroughProperty("lblDauKy")>
		Private _lblDauKy As Label

		' Token: 0x0400044E RID: 1102
		<AccessedThroughProperty("lblDienThoai")>
		Private _lblDienThoai As Label

		' Token: 0x0400044F RID: 1103
		<AccessedThroughProperty("Label10")>
		Private _Label10 As Label

		' Token: 0x04000450 RID: 1104
		<AccessedThroughProperty("Label11")>
		Private _Label11 As Label

		' Token: 0x04000451 RID: 1105
		<AccessedThroughProperty("lblCuoiKy")>
		Private _lblCuoiKy As Label

		' Token: 0x04000452 RID: 1106
		<AccessedThroughProperty("lblTrongKy")>
		Private _lblTrongKy As Label

		' Token: 0x04000453 RID: 1107
		<AccessedThroughProperty("Label14")>
		Private _Label14 As Label

		' Token: 0x04000454 RID: 1108
		<AccessedThroughProperty("btnCongTru")>
		Private _btnCongTru As Label

		' Token: 0x04000455 RID: 1109
		<AccessedThroughProperty("txtDiem")>
		Private _txtDiem As TextBox

		' Token: 0x04000456 RID: 1110
		<AccessedThroughProperty("btnDiem")>
		Private _btnDiem As Button

		' Token: 0x04000457 RID: 1111
		<AccessedThroughProperty("Label16")>
		Private _Label16 As Label

		' Token: 0x04000458 RID: 1112
		<AccessedThroughProperty("lblConLai")>
		Private _lblConLai As Label

		' Token: 0x04000459 RID: 1113
		<AccessedThroughProperty("dgvDMDV")>
		Private _dgvDMDV As DataGridView

		' Token: 0x0400045A RID: 1114
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x0400045B RID: 1115
		<AccessedThroughProperty("lblCMND")>
		Private _lblCMND As Label

		' Token: 0x0400045C RID: 1116
		<AccessedThroughProperty("Label9")>
		Private _Label9 As Label

		' Token: 0x0400045D RID: 1117
		<AccessedThroughProperty("lblNgaySinh")>
		Private _lblNgaySinh As Label

		' Token: 0x0400045E RID: 1118
		<AccessedThroughProperty("Label13")>
		Private _Label13 As Label

		' Token: 0x0400045F RID: 1119
		<AccessedThroughProperty("Label15")>
		Private _Label15 As Label

		' Token: 0x04000460 RID: 1120
		<AccessedThroughProperty("lblTienNo")>
		Private _lblTienNo As Label

		' Token: 0x04000461 RID: 1121
		<AccessedThroughProperty("lblTienHoaHong")>
		Private _lblTienHoaHong As Label

		' Token: 0x04000462 RID: 1122
		<AccessedThroughProperty("Label19")>
		Private _Label19 As Label

		' Token: 0x04000463 RID: 1123
		<AccessedThroughProperty("lblTienDauKy")>
		Private _lblTienDauKy As Label

		' Token: 0x04000464 RID: 1124
		<AccessedThroughProperty("Label21")>
		Private _Label21 As Label

		' Token: 0x04000465 RID: 1125
		<AccessedThroughProperty("lblTienTrongKy")>
		Private _lblTienTrongKy As Label

		' Token: 0x04000466 RID: 1126
		<AccessedThroughProperty("Label23")>
		Private _Label23 As Label

		' Token: 0x04000467 RID: 1127
		<AccessedThroughProperty("Label24")>
		Private _Label24 As Label

		' Token: 0x04000468 RID: 1128
		<AccessedThroughProperty("lblDiemSuDung")>
		Private _lblDiemSuDung As Label

		' Token: 0x04000469 RID: 1129
		<AccessedThroughProperty("lblTienSuDung")>
		Private _lblTienSuDung As Label

		' Token: 0x0400046A RID: 1130
		<AccessedThroughProperty("Label27")>
		Private _Label27 As Label

		' Token: 0x0400046B RID: 1131
		<AccessedThroughProperty("lblTienCuoiKy")>
		Private _lblTienCuoiKy As Label

		' Token: 0x0400046C RID: 1132
		<AccessedThroughProperty("Label29")>
		Private _Label29 As Label

		' Token: 0x0400046D RID: 1133
		<AccessedThroughProperty("lblLyDo")>
		Private _lblLyDo As TextBox

		' Token: 0x0400046E RID: 1134
		<AccessedThroughProperty("Label30")>
		Private _Label30 As Label

		' Token: 0x0400046F RID: 1135
		<AccessedThroughProperty("lblTongCong")>
		Private _lblTongCong As Label

		' Token: 0x04000470 RID: 1136
		<AccessedThroughProperty("Label32")>
		Private _Label32 As Label

		' Token: 0x04000471 RID: 1137
		<AccessedThroughProperty("lblThanhToan")>
		Private _lblThanhToan As Label

		' Token: 0x04000472 RID: 1138
		<AccessedThroughProperty("lblKeyLyDo")>
		Private _lblKeyLyDo As Label

		' Token: 0x04000473 RID: 1139
		<AccessedThroughProperty("Label35")>
		Private _Label35 As Label

		' Token: 0x04000474 RID: 1140
		<AccessedThroughProperty("Label8")>
		Private _Label8 As Label

		' Token: 0x04000475 RID: 1141
		<AccessedThroughProperty("Label12")>
		Private _Label12 As Label

		' Token: 0x04000476 RID: 1142
		Private mstrMa As String

		' Token: 0x04000477 RID: 1143
		Private mstrTen As String

		' Token: 0x04000478 RID: 1144
		Private mstrNHOMDV As String

		' Token: 0x04000479 RID: 1145
		Private mstrDiachi As String

		' Token: 0x0400047A RID: 1146
		Private mstrDienthoai As String

		' Token: 0x0400047B RID: 1147
		Private mdtNgaySinh As DateTime

		' Token: 0x0400047C RID: 1148
		Private mdblMucGiamGia As Double

		' Token: 0x0400047D RID: 1149
		Private mdblPointMoney As Double

		' Token: 0x0400047E RID: 1150
		Private mdblTienMatScore As Double

		' Token: 0x0400047F RID: 1151
		Private mblnOK As Boolean

		' Token: 0x04000480 RID: 1152
		Private mArrStrFrmMess As String()

		' Token: 0x04000481 RID: 1153
		Private mclsTbDMDV As clsConnect

		' Token: 0x04000482 RID: 1154
		<AccessedThroughProperty("mbdsSourceDMDV")>
		Private _mbdsSourceDMDV As BindingSource

		' Token: 0x04000483 RID: 1155
		Private mintPosDV As Integer

		' Token: 0x04000484 RID: 1156
		Private mblnRightSelectDV As Boolean

		' Token: 0x04000485 RID: 1157
		Private mintCount As Integer

		' Token: 0x04000486 RID: 1158
		Private mintCountTruoc As Integer

		' Token: 0x04000487 RID: 1159
		Private mblnClickSave As Boolean

		' Token: 0x04000488 RID: 1160
		Private mdblSoDiemTru As Double

		' Token: 0x04000489 RID: 1161
		Private mdblTongCongBill As Double

		' Token: 0x0400048A RID: 1162
		Private mdblTienDiemSuDung As Double

		' Token: 0x0400048B RID: 1163
		Private mdblMONEY_OF_1POINT As Double
	End Class
End Namespace
