﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200012C RID: 300
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptACCBC04005
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600580C RID: 22540 RVA: 0x0000F26B File Offset: 0x0000D46B
		Public Sub New()
			CachedrptACCBC04005.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001FDF RID: 8159
		' (get) Token: 0x0600580D RID: 22541 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x0600580E RID: 22542 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17001FE0 RID: 8160
		' (get) Token: 0x0600580F RID: 22543 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005810 RID: 22544 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17001FE1 RID: 8161
		' (get) Token: 0x06005811 RID: 22545 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005812 RID: 22546 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005813 RID: 22547 RVA: 0x004DB0E0 File Offset: 0x004D92E0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptACCBC04005() With { .Site = Me.Site }
		End Function

		' Token: 0x06005814 RID: 22548 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002724 RID: 10020
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
