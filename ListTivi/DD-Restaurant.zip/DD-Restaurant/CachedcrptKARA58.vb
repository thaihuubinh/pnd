﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200011C RID: 284
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedcrptKARA58
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600576F RID: 22383 RVA: 0x0000EFDB File Offset: 0x0000D1DB
		Public Sub New()
			CachedcrptKARA58.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001F92 RID: 8082
		' (get) Token: 0x06005770 RID: 22384 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005771 RID: 22385 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17001F93 RID: 8083
		' (get) Token: 0x06005772 RID: 22386 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005773 RID: 22387 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17001F94 RID: 8084
		' (get) Token: 0x06005774 RID: 22388 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005775 RID: 22389 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005776 RID: 22390 RVA: 0x004DAEE0 File Offset: 0x004D90E0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New crptKARA58() With { .Site = Me.Site }
		End Function

		' Token: 0x06005777 RID: 22391 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002714 RID: 10004
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
