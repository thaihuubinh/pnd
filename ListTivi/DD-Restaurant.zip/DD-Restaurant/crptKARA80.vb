﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x0200011D RID: 285
	Public Class crptKARA80
		Inherits ReportClass

		' Token: 0x06005779 RID: 22393 RVA: 0x0000F004 File Offset: 0x0000D204
		Public Sub New()
			crptKARA80.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001F95 RID: 8085
		' (get) Token: 0x0600577A RID: 22394 RVA: 0x004DAF08 File Offset: 0x004D9108
		' (set) Token: 0x0600577B RID: 22395 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crptKARA80.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001F96 RID: 8086
		' (get) Token: 0x0600577C RID: 22396 RVA: 0x004DA738 File Offset: 0x004D8938
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section1 As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001F97 RID: 8087
		' (get) Token: 0x0600577D RID: 22397 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section2 As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001F98 RID: 8088
		' (get) Token: 0x0600577E RID: 22398 RVA: 0x004DA780 File Offset: 0x004D8980
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section3 As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001F99 RID: 8089
		' (get) Token: 0x0600577F RID: 22399 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001F9A RID: 8090
		' (get) Token: 0x06005780 RID: 22400 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section4 As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001F9B RID: 8091
		' (get) Token: 0x06005781 RID: 22401 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x04002715 RID: 10005
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
