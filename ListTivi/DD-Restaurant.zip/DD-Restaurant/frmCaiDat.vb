﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200001C RID: 28
	<DesignerGenerated()>
	Public Partial Class frmCaiDat
		Inherits Form

		' Token: 0x0600045B RID: 1115 RVA: 0x00034B9C File Offset: 0x00032D9C
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmChangeTableStatus_Load
			frmCaiDat.__ENCList.Add(New WeakReference(Me))
			Me.mintSelectIndexNhom = 0
			Me.mstrMaBan = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x170001AA RID: 426
		' (get) Token: 0x0600045E RID: 1118 RVA: 0x000355CC File Offset: 0x000337CC
		' (set) Token: 0x0600045F RID: 1119 RVA: 0x000355E4 File Offset: 0x000337E4
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170001AB RID: 427
		' (get) Token: 0x06000460 RID: 1120 RVA: 0x00035650 File Offset: 0x00033850
		' (set) Token: 0x06000461 RID: 1121 RVA: 0x00002BD3 File Offset: 0x00000DD3
		Friend Overridable Property TableLayoutPanel5 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel5 = value
			End Set
		End Property

		' Token: 0x170001AC RID: 428
		' (get) Token: 0x06000462 RID: 1122 RVA: 0x00035668 File Offset: 0x00033868
		' (set) Token: 0x06000463 RID: 1123 RVA: 0x00035680 File Offset: 0x00033880
		Friend Overridable Property btnDownNH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDownNH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDownNH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDownNH.Click, AddressOf Me.btnDownNH_Click
				End If
				Me._btnDownNH = value
				flag = Me._btnDownNH IsNot Nothing
				If flag Then
					AddHandler Me._btnDownNH.Click, AddressOf Me.btnDownNH_Click
				End If
			End Set
		End Property

		' Token: 0x170001AD RID: 429
		' (get) Token: 0x06000464 RID: 1124 RVA: 0x000356EC File Offset: 0x000338EC
		' (set) Token: 0x06000465 RID: 1125 RVA: 0x00035704 File Offset: 0x00033904
		Friend Overridable Property btnUpNH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnUpNH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnUpNH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnUpNH.Click, AddressOf Me.btnUpNH_Click
				End If
				Me._btnUpNH = value
				flag = Me._btnUpNH IsNot Nothing
				If flag Then
					AddHandler Me._btnUpNH.Click, AddressOf Me.btnUpNH_Click
				End If
			End Set
		End Property

		' Token: 0x170001AE RID: 430
		' (get) Token: 0x06000466 RID: 1126 RVA: 0x00035770 File Offset: 0x00033970
		' (set) Token: 0x06000467 RID: 1127 RVA: 0x00035788 File Offset: 0x00033988
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170001AF RID: 431
		' (get) Token: 0x06000468 RID: 1128 RVA: 0x000357F4 File Offset: 0x000339F4
		' (set) Token: 0x06000469 RID: 1129 RVA: 0x00002BDD File Offset: 0x00000DDD
		Friend Overridable Property Column2 As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._Column2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._Column2 = value
			End Set
		End Property

		' Token: 0x170001B0 RID: 432
		' (get) Token: 0x0600046A RID: 1130 RVA: 0x0003580C File Offset: 0x00033A0C
		' (set) Token: 0x0600046B RID: 1131 RVA: 0x00002BE7 File Offset: 0x00000DE7
		Friend Overridable Property Column1 As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._Column1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._Column1 = value
			End Set
		End Property

		' Token: 0x170001B1 RID: 433
		' (get) Token: 0x0600046C RID: 1132 RVA: 0x00035824 File Offset: 0x00033A24
		' (set) Token: 0x0600046D RID: 1133 RVA: 0x0003583C File Offset: 0x00033A3C
		Friend Overridable Property dtgStatus As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dtgStatus
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dtgStatus IsNot Nothing
				If flag Then
					RemoveHandler Me._dtgStatus.RowEnter, AddressOf Me.dtgStatus_RowEnter
					RemoveHandler Me._dtgStatus.DoubleClick, AddressOf Me.dtgStatus_DoubleClick
				End If
				Me._dtgStatus = value
				flag = Me._dtgStatus IsNot Nothing
				If flag Then
					AddHandler Me._dtgStatus.RowEnter, AddressOf Me.dtgStatus_RowEnter
					AddHandler Me._dtgStatus.DoubleClick, AddressOf Me.dtgStatus_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x170001B2 RID: 434
		' (get) Token: 0x0600046E RID: 1134 RVA: 0x000358D8 File Offset: 0x00033AD8
		' (set) Token: 0x0600046F RID: 1135 RVA: 0x00002BF1 File Offset: 0x00000DF1
		Friend Overridable Property dtgSetting As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dtgSetting
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dtgSetting = value
			End Set
		End Property

		' Token: 0x170001B3 RID: 435
		' (get) Token: 0x06000470 RID: 1136 RVA: 0x000358F0 File Offset: 0x00033AF0
		' (set) Token: 0x06000471 RID: 1137 RVA: 0x00002BFB File Offset: 0x00000DFB
		Public Property pstrMaBan As String
			Get
				Return Me.mstrMaBan
			End Get
			Set(value As String)
				Me.mstrMaBan = value
			End Set
		End Property

		' Token: 0x06000472 RID: 1138 RVA: 0x00002C06 File Offset: 0x00000E06
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			mdlFile.gfWriteLogFile("Thoát form cấu hình.")
			Me.Close()
		End Sub

		' Token: 0x06000473 RID: 1139 RVA: 0x00035908 File Offset: 0x00033B08
		Private Sub frmChangeTableStatus_Load(sender As Object, e As EventArgs)
			Try
				Me.fInitCaption()
				Me.dtgStatus.Rows.Add(New Object() { "0", Me.mArrStrFrmMess(5) })
				Me.dtgStatus.Rows.Add(New Object() { "1", Me.mArrStrFrmMess(6) })
				Me.dtgStatus.Rows.Add(New Object() { "2", Me.mArrStrFrmMess(7) })
				Me.dtgStatus.Rows.Add(New Object() { "3", Me.mArrStrFrmMess(8) })
				Me.dtgStatus.Rows.Add(New Object() { "4", Me.mArrStrFrmMess(9) })
				Me.dtgStatus.Rows.Add(New Object() { "5", Me.mArrStrFrmMess(10) })
				Me.dtgStatus.Rows.Add(New Object() { "6", Me.mArrStrFrmMess(11) })
				Me.dtgStatus.Rows.Add(New Object() { "7", Me.mArrStrFrmMess(12) })
				Me.dtgStatus.Rows.Add(New Object() { "8", Me.mArrStrFrmMess(13) })
				Me.dtgStatus.Rows.Add(New Object() { "9", Me.mArrStrFrmMess(14) })
				Me.dtgStatus.Rows.Add(New Object() { "10", Me.mArrStrFrmMess(15) })
				Me.dtgStatus.Rows.Add(New Object() { "11", Me.mArrStrFrmMess(16) })
				Me.dtgStatus.Rows.Add(New Object() { "12", Me.mArrStrFrmMess(17) })
				Me.dtgStatus.Rows.Add(New Object() { "13", Me.mArrStrFrmMess(18) })
				Me.dtgStatus.Columns(0).Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - frmSelectDepartment_Group_Load " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000474 RID: 1140 RVA: 0x00035C38 File Offset: 0x00033E38
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				Me.Text = Me.mArrStrFrmMess(14)
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000475 RID: 1141 RVA: 0x00035D44 File Offset: 0x00033F44
		Private Sub btnUpNH_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean = Me.dtgStatus Is Nothing OrElse Me.dtgStatus.Rows.Count = 0
				If Not flag Then
					Dim num As Integer = Me.dtgStatus.CurrentCell.RowIndex + 1
					Me.mintSelectIndexNhom = CInt(Math.Round((Conversion.Int(CDbl(num) / 7.0) - 1.0) * 7.0))
					flag = Me.mintSelectIndexNhom < 0
					If flag Then
						Me.mintSelectIndexNhom = 0
					End If
					flag = Me.dtgStatus.Rows.Count > 0
					If flag Then
						Me.dtgStatus.FirstDisplayedScrollingRowIndex = Me.mintSelectIndexNhom
						Me.dtgStatus.Rows(Me.mintSelectIndexNhom).Selected = True
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnUpManHinh_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000476 RID: 1142 RVA: 0x00035E84 File Offset: 0x00034084
		Private Sub btnDownNH_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean = Me.dtgStatus Is Nothing OrElse Me.dtgStatus.Rows.Count = 0
				If Not flag Then
					Dim num As Integer = Me.dtgStatus.CurrentCell.RowIndex + 1
					Me.mintSelectIndexNhom = CInt(Math.Round((Conversion.Int(CDbl(num) / 7.0) + 1.0) * 7.0))
					flag = Me.mintSelectIndexNhom > Me.dtgStatus.Rows.Count - 1
					If flag Then
						Me.mintSelectIndexNhom = Me.dtgStatus.Rows.Count - 1
					End If
					flag = Me.dtgStatus.Rows.Count > 0
					If flag Then
						Me.dtgStatus.FirstDisplayedScrollingRowIndex = Me.mintSelectIndexNhom
						Me.dtgStatus.Rows(Me.mintSelectIndexNhom).Selected = True
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnDownManHinh_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000477 RID: 1143 RVA: 0x00035FE8 File Offset: 0x000341E8
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.dtgStatus.SelectedRows.Count <= 0
				If flag Then
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(3), Me.mArrStrFrmMess(4), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
				Else
					Dim value As Object = Me.dtgStatus.SelectedRows(0).Cells(0).Value
					flag = Operators.ConditionalCompareObjectEqual(value, 0, False)
					If flag Then
						mdlFile.gfWriteLogFile("Mở form Đổi mật mã.")
						Dim frmChangePass As frmChangePass = New frmChangePass()
						frmChangePass.ShowDialog()
					Else
						flag = Operators.ConditionalCompareObjectEqual(value, 1, False)
						If flag Then
							mdlFile.gfWriteLogFile("Mở form Cập nhật nhóm người dùng và cấp quyền.")
							New frmUSERGROUP1() With { .pBytOpen_From_Menu = 8, .WindowState = FormWindowState.Normal, .Left = 0, .Top = 0, .Width = Screen.PrimaryScreen.Bounds.Width, .Height = Screen.PrimaryScreen.Bounds.Height }.ShowDialog()
						Else
							flag = Operators.ConditionalCompareObjectEqual(value, 2, False)
							If flag Then
								mdlFile.gfWriteLogFile("Mở form Cập nhật người dùng và cấp quyền.")
								New frmUSER1() With { .pBytOpen_From_Menu = 8, .WindowState = FormWindowState.Normal, .Left = 0, .Top = 0, .Width = Screen.PrimaryScreen.Bounds.Width, .Height = Screen.PrimaryScreen.Bounds.Height }.ShowDialog()
							Else
								flag = Operators.ConditionalCompareObjectEqual(value, 3, False)
								If flag Then
									mdlFile.gfWriteLogFile("Mở form thông số In ấn.")
									New frmParaPrint() With { .WindowState = FormWindowState.Maximized }.ShowDialog()
								Else
									flag = Operators.ConditionalCompareObjectEqual(value, 4, False)
									If flag Then
										mdlFile.gfWriteLogFile("Mở form thông số Danh mục.")
										New frmParaList() With { .WindowState = FormWindowState.Maximized }.ShowDialog()
									Else
										flag = Operators.ConditionalCompareObjectEqual(value, 5, False)
										If flag Then
											mdlFile.gfWriteLogFile("Mở form Chức danh ký báo cáo.")
											New frmParaFunc1() With { .WindowState = FormWindowState.Maximized }.ShowDialog()
										Else
											flag = Operators.ConditionalCompareObjectEqual(value, 6, False)
											If flag Then
												mdlFile.gfWriteLogFile("Mở form Số liệu đề nghị.")
												New frmParaDefault() With { .WindowState = FormWindowState.Maximized }.ShowDialog()
											Else
												flag = Operators.ConditionalCompareObjectEqual(value, 7, False)
												If flag Then
													mdlFile.gfWriteLogFile("Mở form thông số chung.")
													New frmParaControl() With { .WindowState = FormWindowState.Maximized }.ShowDialog()
												Else
													flag = Operators.ConditionalCompareObjectEqual(value, 8, False)
													If flag Then
														mdlFile.gfWriteLogFile("Mở form thông số Hóa đơn.")
														New frmParaControlBill() With { .WindowState = FormWindowState.Maximized }.ShowDialog()
													Else
														flag = Operators.ConditionalCompareObjectEqual(value, 9, False)
														If flag Then
															mdlFile.gfWriteLogFile("Mở danh mục máy tính.")
															New frmDMMAY1() With { .pBytOpen_From_Menu = 8, .WindowState = FormWindowState.Maximized }.ShowDialog()
														Else
															flag = Operators.ConditionalCompareObjectEqual(value, 10, False)
															If flag Then
																mdlFile.gfWriteLogFile("Mở danh mục máy in HĐ.")
																New frmDMMAYINHD1() With { .pBytOpen_From_Menu = 8, .WindowState = FormWindowState.Maximized }.ShowDialog()
															Else
																flag = Operators.ConditionalCompareObjectEqual(value, 11, False)
																If flag Then
																	mdlFile.gfWriteLogFile("Mở danh mục máy in bếp.")
																	New frmDMMAYINBEP1() With { .pBytOpen_From_Menu = 8, .WindowState = FormWindowState.Maximized }.ShowDialog()
																Else
																	flag = Operators.ConditionalCompareObjectEqual(value, 12, False)
																	If flag Then
																		mdlFile.gfWriteLogFile("Mở form sao lưu dữ liệu.")
																		Dim frmBackup As frmBackup = New frmBackup()
																		frmBackup.ShowDialog()
																	Else
																		flag = Operators.ConditionalCompareObjectEqual(value, 13, False)
																		If flag Then
																			mdlFile.gfWriteLogFile("Mở form phục hồi dữ liệu.")
																			Dim frmReStore As frmReStore = New frmReStore()
																			frmReStore.ShowDialog()
																		End If
																	End If
																End If
															End If
														End If
													End If
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnSelect_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000478 RID: 1144 RVA: 0x00002C1C File Offset: 0x00000E1C
		Private Sub dtgStatus_DoubleClick(sender As Object, e As EventArgs)
			Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
		End Sub

		' Token: 0x06000479 RID: 1145 RVA: 0x00002C2E File Offset: 0x00000E2E
		Private Sub dtgStatus_RowEnter(sender As Object, e As DataGridViewCellEventArgs)
			Me.mintSelectIndexNhom = e.RowIndex
		End Sub

		' Token: 0x040001E1 RID: 481
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040001E3 RID: 483
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040001E4 RID: 484
		<AccessedThroughProperty("TableLayoutPanel5")>
		Private _TableLayoutPanel5 As TableLayoutPanel

		' Token: 0x040001E5 RID: 485
		<AccessedThroughProperty("btnDownNH")>
		Private _btnDownNH As Button

		' Token: 0x040001E6 RID: 486
		<AccessedThroughProperty("btnUpNH")>
		Private _btnUpNH As Button

		' Token: 0x040001E7 RID: 487
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040001E8 RID: 488
		<AccessedThroughProperty("Column2")>
		Private _Column2 As DataGridViewTextBoxColumn

		' Token: 0x040001E9 RID: 489
		<AccessedThroughProperty("Column1")>
		Private _Column1 As DataGridViewTextBoxColumn

		' Token: 0x040001EA RID: 490
		<AccessedThroughProperty("dtgStatus")>
		Private _dtgStatus As DataGridView

		' Token: 0x040001EB RID: 491
		<AccessedThroughProperty("dtgSetting")>
		Private _dtgSetting As DataGridView

		' Token: 0x040001EC RID: 492
		Private mArrStrFrmMess As String()

		' Token: 0x040001ED RID: 493
		Private mintSelectIndexNhom As Integer

		' Token: 0x040001EE RID: 494
		Private mstrMaBan As String
	End Class
End Namespace
