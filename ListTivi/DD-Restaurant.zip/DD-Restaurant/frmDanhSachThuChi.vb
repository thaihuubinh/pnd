﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000032 RID: 50
	<DesignerGenerated()>
	Public Partial Class frmDanhSachThuChi
		Inherits Form

		' Token: 0x06000A92 RID: 2706 RVA: 0x0007CBF4 File Offset: 0x0007ADF4
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmRePrintBill_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDanhSachThuChi_Load
			frmDanhSachThuChi.__ENCList.Add(New WeakReference(Me))
			Me.mblnAutoAdd = False
			Me.mblnThu = True
			Me.InitializeComponent()
		End Sub

		' Token: 0x170003E9 RID: 1001
		' (get) Token: 0x06000A95 RID: 2709 RVA: 0x0007D498 File Offset: 0x0007B698
		' (set) Token: 0x06000A96 RID: 2710 RVA: 0x0007D4B0 File Offset: 0x0007B6B0
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x170003EA RID: 1002
		' (get) Token: 0x06000A97 RID: 2711 RVA: 0x0007D51C File Offset: 0x0007B71C
		' (set) Token: 0x06000A98 RID: 2712 RVA: 0x00003C43 File Offset: 0x00001E43
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170003EB RID: 1003
		' (get) Token: 0x06000A99 RID: 2713 RVA: 0x0007D534 File Offset: 0x0007B734
		' (set) Token: 0x06000A9A RID: 2714 RVA: 0x0007D54C File Offset: 0x0007B74C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170003EC RID: 1004
		' (get) Token: 0x06000A9B RID: 2715 RVA: 0x0007D5B8 File Offset: 0x0007B7B8
		' (set) Token: 0x06000A9C RID: 2716 RVA: 0x00003C4D File Offset: 0x00001E4D
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x170003ED RID: 1005
		' (get) Token: 0x06000A9D RID: 2717 RVA: 0x0007D5D0 File Offset: 0x0007B7D0
		' (set) Token: 0x06000A9E RID: 2718 RVA: 0x00003C57 File Offset: 0x00001E57
		Friend Overridable Property lblFilterDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFilterDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFilterDate = value
			End Set
		End Property

		' Token: 0x170003EE RID: 1006
		' (get) Token: 0x06000A9F RID: 2719 RVA: 0x0007D5E8 File Offset: 0x0007B7E8
		' (set) Token: 0x06000AA0 RID: 2720 RVA: 0x00003C61 File Offset: 0x00001E61
		Friend Overridable Property btnCancel As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnCancel = value
			End Set
		End Property

		' Token: 0x170003EF RID: 1007
		' (get) Token: 0x06000AA1 RID: 2721 RVA: 0x0007D600 File Offset: 0x0007B800
		' (set) Token: 0x06000AA2 RID: 2722 RVA: 0x0007D618 File Offset: 0x0007B818
		Friend Overridable Property mtxDATE As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxDATE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxDATE IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxDATE.MaskInputRejected, AddressOf Me.mtxDATE_MaskInputRejected
					RemoveHandler Me._mtxDATE.TextChanged, AddressOf Me.mtxDATE_TextChanged
				End If
				Me._mtxDATE = value
				flag = Me._mtxDATE IsNot Nothing
				If flag Then
					AddHandler Me._mtxDATE.MaskInputRejected, AddressOf Me.mtxDATE_MaskInputRejected
					AddHandler Me._mtxDATE.TextChanged, AddressOf Me.mtxDATE_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170003F0 RID: 1008
		' (get) Token: 0x06000AA3 RID: 2723 RVA: 0x0007D6B4 File Offset: 0x0007B8B4
		' (set) Token: 0x06000AA4 RID: 2724 RVA: 0x0007D6CC File Offset: 0x0007B8CC
		Friend Overridable Property dtpTuNgay As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpTuNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpTuNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.dtpTuNgay_ValueChanged
				End If
				Me._dtpTuNgay = value
				flag = Me._dtpTuNgay IsNot Nothing
				If flag Then
					AddHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.dtpTuNgay_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x170003F1 RID: 1009
		' (get) Token: 0x06000AA5 RID: 2725 RVA: 0x0007D738 File Offset: 0x0007B938
		' (set) Token: 0x06000AA6 RID: 2726 RVA: 0x0007D750 File Offset: 0x0007B950
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170003F2 RID: 1010
		' (get) Token: 0x06000AA7 RID: 2727 RVA: 0x0007D7BC File Offset: 0x0007B9BC
		' (set) Token: 0x06000AA8 RID: 2728 RVA: 0x00003C6B File Offset: 0x00001E6B
		Public Property pblnThu As Boolean
			Get
				Return Me.mblnThu
			End Get
			Set(value As Boolean)
				Me.mblnThu = value
			End Set
		End Property

		' Token: 0x170003F3 RID: 1011
		' (get) Token: 0x06000AA9 RID: 2729 RVA: 0x0007D7D4 File Offset: 0x0007B9D4
		' (set) Token: 0x06000AAA RID: 2730 RVA: 0x00003C76 File Offset: 0x00001E76
		Public Property pStrNGAYCT As String
			Get
				Return Me.mStrNGAYCT
			End Get
			Set(value As String)
				Me.mStrNGAYCT = value
			End Set
		End Property

		' Token: 0x170003F4 RID: 1012
		' (get) Token: 0x06000AAB RID: 2731 RVA: 0x0007D7EC File Offset: 0x0007B9EC
		' (set) Token: 0x06000AAC RID: 2732 RVA: 0x00003C81 File Offset: 0x00001E81
		Public Property pStrNGAYGS As String
			Get
				Return Me.mStrNGAYGS
			End Get
			Set(value As String)
				Me.mStrNGAYGS = value
			End Set
		End Property

		' Token: 0x170003F5 RID: 1013
		' (get) Token: 0x06000AAD RID: 2733 RVA: 0x0007D804 File Offset: 0x0007BA04
		' (set) Token: 0x06000AAE RID: 2734 RVA: 0x00003C8C File Offset: 0x00001E8C
		Public Property pStrSOCT As String
			Get
				Return Me.mStrSOCT
			End Get
			Set(value As String)
				Me.mStrSOCT = value
			End Set
		End Property

		' Token: 0x170003F6 RID: 1014
		' (get) Token: 0x06000AAF RID: 2735 RVA: 0x0007D81C File Offset: 0x0007BA1C
		' (set) Token: 0x06000AB0 RID: 2736 RVA: 0x00003C97 File Offset: 0x00001E97
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06000AB1 RID: 2737 RVA: 0x0007D834 File Offset: 0x0007BA34
		Private Sub frmRePrintBill_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmRePrintBill_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000AB2 RID: 2738 RVA: 0x0007D8CC File Offset: 0x0007BACC
		Private Sub frmDanhSachThuChi_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.gf_GetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				Me.mtxDATE.Text = String.Concat(New String() { DateAndTime.Today.Day.ToString("00"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Year.ToString("0000") })
				flag = Conversions.ToBoolean(If((Not Conversions.ToBoolean(mdlVariable.garrDrDMMAYINHD.Length > 0) OrElse Not Conversions.ToBoolean(Operators.OrObject(Operators.OrObject(Operators.CompareObjectEqual(mdlVariable.garrDrDMMAYINHD(0)("KIND"), 0, False), Operators.CompareObjectEqual(mdlVariable.garrDrDMMAYINHD(0)("KIND"), 1, False)), Operators.CompareObjectEqual(mdlVariable.garrDrDMMAYINHD(0)("KIND"), 2, False)))), False, True))
				Dim flag2 As Boolean
				If flag Then
					flag2 = mdlVariable.gsrlCOMBillport Is Nothing
					If flag2 Then
						b = mdlPrintReceipt.gfOpenSerialPort()
					End If
				Else
					b = 1
				End If
				flag2 = b = 0
				If flag2 Then
					Me.btnPreview.Enabled = False
				Else
					Me.btnPreview.Enabled = True
				End If
				flag2 = Me.mblnThu
				If flag2 Then
					Me.Text = Me.mArrStrFrmMess(26)
				Else
					Me.Text = Me.mArrStrFrmMess(27)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmRePrintBill_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000AB3 RID: 2739 RVA: 0x0007DB7C File Offset: 0x0007BD7C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				mdlPrintReceipt.gsCloseSerialPort()
				mdlFile.gfWriteLogFile("Nhấn nút Thoát khỏi form danh sách thu chi")
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000AB4 RID: 2740 RVA: 0x0007DC28 File Offset: 0x0007BE28
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.dgvData.SelectedCells.Count = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
				Else
					Dim text As String = Conversions.ToString(Interaction.IIf(Not Me.mblnThu, Me.mArrStrFrmMess(30), Me.mArrStrFrmMess(29)))
					Dim text2 As String = String.Concat(New String() { Me.mArrStrFrmMess(31), ": ", Me.dgvData.CurrentRow.Cells("NGAY").Value.ToString().Trim(), " ", Me.dgvData.CurrentRow.Cells("GIO").Value.ToString().Trim() })
					Dim text3 As String = Me.mArrStrFrmMess(34)
					Dim text4 As String = Me.mArrStrFrmMess(35)
					Dim text5 As String = Me.dgvData.CurrentRow.Cells("SOTIEN").Value.ToString().Trim()
					mdlFile.gfWriteLogFile(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("Nhấn nút in phiếu thu chi với lý do: ", Me.dgvData.CurrentRow.Cells("LYDO").Value), ", số tiền: "), text5)))
					mdlPrintReceipt.gfPrint_ThuChi(text, text2, text3, Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LYDO").Value, "")), text4, text5, String.Concat(New String() { "(", Me.mArrStrFrmMess(32), ": ", mdlReport.gfReadNumVie(text5), " ", Me.mArrStrFrmMess(33), ")" }), Me.mArrStrFrmMess(25) + ": " + Me.dgvData.CurrentRow.Cells("REMARK").Value.ToString().Trim())
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000AB5 RID: 2741 RVA: 0x0007DF18 File Offset: 0x0007C118
		Private Sub mtxDATE_TextChanged(sender As Object, e As EventArgs)
			Try
				Dim text As String = Strings.Mid(Me.mtxDATE.Text, 3, 1)
				Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtxDATE.Text, text, "", 1, -1, CompareMethod.Binary))
				Dim flag As Boolean = Strings.Len(text2) < 8
				If Not flag Then
					text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 1, 2) })
					flag = Not Information.IsDate(text2)
					If Not flag Then
						mdlVariable.gStrConISDULIEU = String.Concat(New String() { "Data Source = ", mdlVariable.gStrServer, "; Initial Catalog=ISDULIEU", Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 7, 4), Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 4, 2), "; User ID=", mdlVariable.gStrUserID, "; Password=", mdlVariable.gStrPassword })
						flag = Not mdlDatabase.gfCheck_ExistsDB("ISDULIEU" + Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 4, 2))
						If Not flag Then
							Me.gf_GetData_4Grid()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxDATE_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000AB6 RID: 2742 RVA: 0x0007E178 File Offset: 0x0007C378
		Private Sub dtpTuNgay_ValueChanged(sender As Object, e As EventArgs)
			Me.mtxDATE.Text = String.Concat(New String() { Me.dtpTuNgay.Value.Day.ToString("00"), "/", Me.dtpTuNgay.Value.Month.ToString("00"), "/", Me.dtpTuNgay.Value.Year.ToString("0000") })
		End Sub

		' Token: 0x06000AB7 RID: 2743 RVA: 0x0007E228 File Offset: 0x0007C428
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("NGAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("NGAY").Width = 90
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("NGAY").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("GIO").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("GIO").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("GIO").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENNV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("TENNV").Width = Me.Width - 540
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENNV").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SOTIEN").HeaderText = Conversions.ToString(Interaction.IIf(Me.mblnThu, Strings.Trim(Me.mArrStrFrmMess(21)), Strings.Trim(Me.mArrStrFrmMess(23))))
				dgvData.Columns("SOTIEN").Width = 90
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("SOTIEN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LYDO").HeaderText = Conversions.ToString(Interaction.IIf(Me.mblnThu, Strings.Trim(Me.mArrStrFrmMess(22)), Strings.Trim(Me.mArrStrFrmMess(24))))
				dgvData.Columns("LYDO").Width = 180
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("LYDO").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("REMARK").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MALD").Visible = False
				dgvData.Columns("STT").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000AB8 RID: 2744 RVA: 0x0007E610 File Offset: 0x0007C810
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000AB9 RID: 2745 RVA: 0x0007E6B8 File Offset: 0x0007C8B8
		Public Function gf_GetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchKH"
				array(0).Value = mdlVariable.gStrStockCode
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@intDecAmt"
				array(1).Value = mdlVariable.gbytDECNUMAMT
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@nvcNGAY"
				array(2).Value = Me.mtxDATE.Text.Trim()
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@bitTHU"
				array(3).Value = Me.mblnThu
				mdlFile.gfWriteLogFile("Lọc danh sách thu chi theo ngày: " + Me.mtxDATE.Text.Trim())
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDULIEU, array, "SP_FRMDANHSACHTHUCHI_GET_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.dgvData.DataSource = clsConnect
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gf_GetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000ABA RID: 2746 RVA: 0x0007E88C File Offset: 0x0007CA8C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Dim flag As Boolean = Me.mblnThu
				If flag Then
					Dim flag2 As Boolean = mdlUIForm.gfChek_RightSale("00059", False) = 0
					If flag2 Then
						Me.btnDelete.Visible = False
					Else
						Me.btnDelete.Visible = True
					End If
				Else
					Dim flag2 As Boolean = mdlUIForm.gfChek_RightSale("00060", False) = 0
					If flag2 Then
						Me.btnDelete.Visible = False
					Else
						Me.btnDelete.Visible = True
					End If
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000ABB RID: 2747 RVA: 0x0007E9B0 File Offset: 0x0007CBB0
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim text As String = Strings.Trim(mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMKH", "OBJID", mdlVariable.gStrStockCode, "OBJNAME"))
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, String.Concat(New String() { Me.mArrStrFrmMess(2), " [", Strings.Mid(mdlVariable.gStrSelectMonth, 5, 2), "/", Strings.Mid(mdlVariable.gStrSelectMonth, 1, 4), " ] ", Me.mArrStrFrmMess(22), " [", text, "]" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000ABC RID: 2748 RVA: 0x0007EB70 File Offset: 0x0007CD70
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000ABD RID: 2749 RVA: 0x0007EC10 File Offset: 0x0007CE10
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.dgvData.SelectedCells.Count = 0
			If flag Then
				Interaction.MsgBox(Me.mArrStrFrmMess(37), MsgBoxStyle.Critical, Nothing)
			Else
				flag = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(36), Me.mArrStrFrmMess(38), frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.No
				If Not flag Then
					Dim text As String = Me.dgvData.CurrentRow.Cells("STT").Value.ToString().Trim()
					Dim clsConnect As clsConnect = New clsConnect()
					Dim sqlCommand As SqlCommand = New SqlCommand()
					Dim array As SqlParameter() = New SqlParameter(1) {}
					Try
						array(0) = sqlCommand.CreateParameter()
						array(0).ParameterName = "@pnchSTT"
						array(0).Value = text
						Dim num As Integer
						clsConnect = New clsConnect(mdlVariable.gStrConISDULIEU, array, "SP_FRMDANHSACHTHUCHI_DELETE", num)
						mdlFile.gfWriteLogFile("Nhấn nút Xóa 1 mục thu chi với STT là: " + text)
						flag = num = 1
						If flag Then
							Me.gf_GetData_4Grid()
						End If
					Catch ex As Exception
						Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gf_GetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
					Finally
						sqlCommand.Dispose()
						clsConnect.Dispose()
					End Try
				End If
			End If
		End Sub

		' Token: 0x06000ABE RID: 2750 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub mtxDATE_MaskInputRejected(sender As Object, e As MaskInputRejectedEventArgs)
		End Sub

		' Token: 0x040004A8 RID: 1192
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040004AA RID: 1194
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x040004AB RID: 1195
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x040004AC RID: 1196
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040004AD RID: 1197
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040004AE RID: 1198
		<AccessedThroughProperty("lblFilterDate")>
		Private _lblFilterDate As Label

		' Token: 0x040004AF RID: 1199
		<AccessedThroughProperty("btnCancel")>
		Private _btnCancel As Button

		' Token: 0x040004B0 RID: 1200
		<AccessedThroughProperty("mtxDATE")>
		Private _mtxDATE As MaskedTextBox

		' Token: 0x040004B1 RID: 1201
		<AccessedThroughProperty("dtpTuNgay")>
		Private _dtpTuNgay As DateTimePicker

		' Token: 0x040004B2 RID: 1202
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x040004B3 RID: 1203
		Private mArrStrFrmMess As String()

		' Token: 0x040004B4 RID: 1204
		Private mStrSOCT As String

		' Token: 0x040004B5 RID: 1205
		Private mStrNGAYGS As String

		' Token: 0x040004B6 RID: 1206
		Private mStrNGAYCT As String

		' Token: 0x040004B7 RID: 1207
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040004B8 RID: 1208
		Private mblnAutoAdd As Boolean

		' Token: 0x040004B9 RID: 1209
		Private mbytLen_OBJID As Byte

		' Token: 0x040004BA RID: 1210
		Private mclsTbDMKH As clsConnect

		' Token: 0x040004BB RID: 1211
		Private mblnThu As Boolean
	End Class
End Namespace
