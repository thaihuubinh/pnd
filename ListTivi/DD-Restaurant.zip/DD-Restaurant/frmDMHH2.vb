﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200004F RID: 79
	<DesignerGenerated()>
	Public Partial Class frmDMHH2
		Inherits Form

		' Token: 0x060015F5 RID: 5621 RVA: 0x0010FB48 File Offset: 0x0010DD48
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmDMHH2_Load
			AddHandler MyBase.Activated, AddressOf Me.frmDMHH2_Activated
			frmDMHH2.__ENCList.Add(New WeakReference(Me))
			Me.mstrUIMAGE = ""
			Me.mblnFistLoad = True
			Me.mBlnAutoDel = False
			Me.mbytLen_OBJID = 15
			Me.mBlnModifyMulti = False
			Me.mbytNUMPRICE = 10
			Me.mstrMaHH_Copy = ""
			Me.mArrStrSelectCombo = Nothing
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000799 RID: 1945
		' (get) Token: 0x060015F8 RID: 5624 RVA: 0x001176FC File Offset: 0x001158FC
		' (set) Token: 0x060015F9 RID: 5625 RVA: 0x00117714 File Offset: 0x00115914
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x1700079A RID: 1946
		' (get) Token: 0x060015FA RID: 5626 RVA: 0x00117780 File Offset: 0x00115980
		' (set) Token: 0x060015FB RID: 5627 RVA: 0x000053E1 File Offset: 0x000035E1
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x1700079B RID: 1947
		' (get) Token: 0x060015FC RID: 5628 RVA: 0x00117798 File Offset: 0x00115998
		' (set) Token: 0x060015FD RID: 5629 RVA: 0x001177B0 File Offset: 0x001159B0
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x1700079C RID: 1948
		' (get) Token: 0x060015FE RID: 5630 RVA: 0x0011781C File Offset: 0x00115A1C
		' (set) Token: 0x060015FF RID: 5631 RVA: 0x00117834 File Offset: 0x00115A34
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x1700079D RID: 1949
		' (get) Token: 0x06001600 RID: 5632 RVA: 0x001178A0 File Offset: 0x00115AA0
		' (set) Token: 0x06001601 RID: 5633 RVA: 0x001178B8 File Offset: 0x00115AB8
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x1700079E RID: 1950
		' (get) Token: 0x06001602 RID: 5634 RVA: 0x00117924 File Offset: 0x00115B24
		' (set) Token: 0x06001603 RID: 5635 RVA: 0x000053EB File Offset: 0x000035EB
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x1700079F RID: 1951
		' (get) Token: 0x06001604 RID: 5636 RVA: 0x0011793C File Offset: 0x00115B3C
		' (set) Token: 0x06001605 RID: 5637 RVA: 0x00117954 File Offset: 0x00115B54
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
					RemoveHandler Me._txtOBJNAME.TextChanged, AddressOf Me.txtOBJNAME_TextChanged
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
					AddHandler Me._txtOBJNAME.TextChanged, AddressOf Me.txtOBJNAME_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170007A0 RID: 1952
		' (get) Token: 0x06001606 RID: 5638 RVA: 0x00117A24 File Offset: 0x00115C24
		' (set) Token: 0x06001607 RID: 5639 RVA: 0x00117A3C File Offset: 0x00115C3C
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
					RemoveHandler Me._txtOBJID.TextChanged, AddressOf Me.txtOBJID_TextChanged
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
					AddHandler Me._txtOBJID.TextChanged, AddressOf Me.txtOBJID_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170007A1 RID: 1953
		' (get) Token: 0x06001608 RID: 5640 RVA: 0x00117B0C File Offset: 0x00115D0C
		' (set) Token: 0x06001609 RID: 5641 RVA: 0x000053F5 File Offset: 0x000035F5
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x170007A2 RID: 1954
		' (get) Token: 0x0600160A RID: 5642 RVA: 0x00117B24 File Offset: 0x00115D24
		' (set) Token: 0x0600160B RID: 5643 RVA: 0x00117B3C File Offset: 0x00115D3C
		Friend Overridable Property txtMADVT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMADVT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMADVT IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMADVT.TextChanged, AddressOf Me.txtMADVT_TextChanged
					RemoveHandler Me._txtMADVT.KeyPress, AddressOf Me.txtDVT_KeyPress
					RemoveHandler Me._txtMADVT.GotFocus, AddressOf Me.txtDVT_GotFocus
				End If
				Me._txtMADVT = value
				flag = Me._txtMADVT IsNot Nothing
				If flag Then
					AddHandler Me._txtMADVT.TextChanged, AddressOf Me.txtMADVT_TextChanged
					AddHandler Me._txtMADVT.KeyPress, AddressOf Me.txtDVT_KeyPress
					AddHandler Me._txtMADVT.GotFocus, AddressOf Me.txtDVT_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007A3 RID: 1955
		' (get) Token: 0x0600160C RID: 5644 RVA: 0x00117C0C File Offset: 0x00115E0C
		' (set) Token: 0x0600160D RID: 5645 RVA: 0x000053FF File Offset: 0x000035FF
		Friend Overridable Property lblDVT As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDVT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDVT = value
			End Set
		End Property

		' Token: 0x170007A4 RID: 1956
		' (get) Token: 0x0600160E RID: 5646 RVA: 0x00117C24 File Offset: 0x00115E24
		' (set) Token: 0x0600160F RID: 5647 RVA: 0x00005409 File Offset: 0x00003609
		Friend Overridable Property lblMANH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMANH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMANH = value
			End Set
		End Property

		' Token: 0x170007A5 RID: 1957
		' (get) Token: 0x06001610 RID: 5648 RVA: 0x00117C3C File Offset: 0x00115E3C
		' (set) Token: 0x06001611 RID: 5649 RVA: 0x00117C54 File Offset: 0x00115E54
		Friend Overridable Property txtMAMT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAMT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAMT IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAMT.TextChanged, AddressOf Me.txtMAMT_TextChanged
					RemoveHandler Me._txtMAMT.KeyPress, AddressOf Me.txtMAMT_KeyPress
					RemoveHandler Me._txtMAMT.GotFocus, AddressOf Me.txtMAMT_GotFocus
				End If
				Me._txtMAMT = value
				flag = Me._txtMAMT IsNot Nothing
				If flag Then
					AddHandler Me._txtMAMT.TextChanged, AddressOf Me.txtMAMT_TextChanged
					AddHandler Me._txtMAMT.KeyPress, AddressOf Me.txtMAMT_KeyPress
					AddHandler Me._txtMAMT.GotFocus, AddressOf Me.txtMAMT_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007A6 RID: 1958
		' (get) Token: 0x06001612 RID: 5650 RVA: 0x00117D24 File Offset: 0x00115F24
		' (set) Token: 0x06001613 RID: 5651 RVA: 0x00117D3C File Offset: 0x00115F3C
		Friend Overridable Property btnDMMT As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMMT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMMT IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMMT.Click, AddressOf Me.btnDMMT_Click
				End If
				Me._btnDMMT = value
				flag = Me._btnDMMT IsNot Nothing
				If flag Then
					AddHandler Me._btnDMMT.Click, AddressOf Me.btnDMMT_Click
				End If
			End Set
		End Property

		' Token: 0x170007A7 RID: 1959
		' (get) Token: 0x06001614 RID: 5652 RVA: 0x00117DA8 File Offset: 0x00115FA8
		' (set) Token: 0x06001615 RID: 5653 RVA: 0x00117DC0 File Offset: 0x00115FC0
		Friend Overridable Property txtTENMT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENMT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENMT IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENMT.GotFocus, AddressOf Me.txtTENMT_GotFocus
				End If
				Me._txtTENMT = value
				flag = Me._txtTENMT IsNot Nothing
				If flag Then
					AddHandler Me._txtTENMT.GotFocus, AddressOf Me.txtTENMT_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007A8 RID: 1960
		' (get) Token: 0x06001616 RID: 5654 RVA: 0x00117E2C File Offset: 0x0011602C
		' (set) Token: 0x06001617 RID: 5655 RVA: 0x00117E44 File Offset: 0x00116044
		Friend Overridable Property chkLSAVE As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLSAVE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLSAVE IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLSAVE.KeyPress, AddressOf Me.chkLSAVE_KeyPress
				End If
				Me._chkLSAVE = value
				flag = Me._chkLSAVE IsNot Nothing
				If flag Then
					AddHandler Me._chkLSAVE.KeyPress, AddressOf Me.chkLSAVE_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007A9 RID: 1961
		' (get) Token: 0x06001618 RID: 5656 RVA: 0x00117EB0 File Offset: 0x001160B0
		' (set) Token: 0x06001619 RID: 5657 RVA: 0x00005413 File Offset: 0x00003613
		Friend Overridable Property lblMAMT As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAMT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAMT = value
			End Set
		End Property

		' Token: 0x170007AA RID: 1962
		' (get) Token: 0x0600161A RID: 5658 RVA: 0x00117EC8 File Offset: 0x001160C8
		' (set) Token: 0x0600161B RID: 5659 RVA: 0x0000541D File Offset: 0x0000361D
		Friend Overridable Property lblLSAVE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLSAVE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblLSAVE = value
			End Set
		End Property

		' Token: 0x170007AB RID: 1963
		' (get) Token: 0x0600161C RID: 5660 RVA: 0x00117EE0 File Offset: 0x001160E0
		' (set) Token: 0x0600161D RID: 5661 RVA: 0x00117EF8 File Offset: 0x001160F8
		Friend Overridable Property txtMANH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMANH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMANH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMANH.KeyPress, AddressOf Me.txtMANH_KeyPress
					RemoveHandler Me._txtMANH.GotFocus, AddressOf Me.txtMANH_GotFocus
					RemoveHandler Me._txtMANH.TextChanged, AddressOf Me.txtMANH_TextChanged
				End If
				Me._txtMANH = value
				flag = Me._txtMANH IsNot Nothing
				If flag Then
					AddHandler Me._txtMANH.KeyPress, AddressOf Me.txtMANH_KeyPress
					AddHandler Me._txtMANH.GotFocus, AddressOf Me.txtMANH_GotFocus
					AddHandler Me._txtMANH.TextChanged, AddressOf Me.txtMANH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170007AC RID: 1964
		' (get) Token: 0x0600161E RID: 5662 RVA: 0x00117FC8 File Offset: 0x001161C8
		' (set) Token: 0x0600161F RID: 5663 RVA: 0x00117FE0 File Offset: 0x001161E0
		Friend Overridable Property btnDMNH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMNH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMNH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMNH.Click, AddressOf Me.btnDMNH_Click
				End If
				Me._btnDMNH = value
				flag = Me._btnDMNH IsNot Nothing
				If flag Then
					AddHandler Me._btnDMNH.Click, AddressOf Me.btnDMNH_Click
				End If
			End Set
		End Property

		' Token: 0x170007AD RID: 1965
		' (get) Token: 0x06001620 RID: 5664 RVA: 0x0011804C File Offset: 0x0011624C
		' (set) Token: 0x06001621 RID: 5665 RVA: 0x00118064 File Offset: 0x00116264
		Friend Overridable Property txtTENNH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENNH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENNH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENNH.GotFocus, AddressOf Me.txtTENNH_GotFocus
				End If
				Me._txtTENNH = value
				flag = Me._txtTENNH IsNot Nothing
				If flag Then
					AddHandler Me._txtTENNH.GotFocus, AddressOf Me.txtTENNH_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007AE RID: 1966
		' (get) Token: 0x06001622 RID: 5666 RVA: 0x001180D0 File Offset: 0x001162D0
		' (set) Token: 0x06001623 RID: 5667 RVA: 0x001180E8 File Offset: 0x001162E8
		Friend Overridable Property txtREMARK As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtREMARK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtREMARK IsNot Nothing
				If flag Then
					RemoveHandler Me._txtREMARK.KeyPress, AddressOf Me.txtREMARK_KeyPress
					RemoveHandler Me._txtREMARK.GotFocus, AddressOf Me.txtREMARK_GotFocus
				End If
				Me._txtREMARK = value
				flag = Me._txtREMARK IsNot Nothing
				If flag Then
					AddHandler Me._txtREMARK.KeyPress, AddressOf Me.txtREMARK_KeyPress
					AddHandler Me._txtREMARK.GotFocus, AddressOf Me.txtREMARK_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007AF RID: 1967
		' (get) Token: 0x06001624 RID: 5668 RVA: 0x00118184 File Offset: 0x00116384
		' (set) Token: 0x06001625 RID: 5669 RVA: 0x00005427 File Offset: 0x00003627
		Friend Overridable Property lblREMARK As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblREMARK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblREMARK = value
			End Set
		End Property

		' Token: 0x170007B0 RID: 1968
		' (get) Token: 0x06001626 RID: 5670 RVA: 0x0011819C File Offset: 0x0011639C
		' (set) Token: 0x06001627 RID: 5671 RVA: 0x00005431 File Offset: 0x00003631
		Friend Overridable Property lblSUBOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblSUBOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblSUBOBJNAME = value
			End Set
		End Property

		' Token: 0x170007B1 RID: 1969
		' (get) Token: 0x06001628 RID: 5672 RVA: 0x001181B4 File Offset: 0x001163B4
		' (set) Token: 0x06001629 RID: 5673 RVA: 0x001181CC File Offset: 0x001163CC
		Friend Overridable Property txtSUBOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtSUBOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtSUBOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtSUBOBJNAME.KeyPress, AddressOf Me.txtSUBOBJNAME_KeyPress
					RemoveHandler Me._txtSUBOBJNAME.GotFocus, AddressOf Me.txtOBJSUBNAME_GotFocus
				End If
				Me._txtSUBOBJNAME = value
				flag = Me._txtSUBOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtSUBOBJNAME.KeyPress, AddressOf Me.txtSUBOBJNAME_KeyPress
					AddHandler Me._txtSUBOBJNAME.GotFocus, AddressOf Me.txtOBJSUBNAME_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007B2 RID: 1970
		' (get) Token: 0x0600162A RID: 5674 RVA: 0x00118268 File Offset: 0x00116468
		' (set) Token: 0x0600162B RID: 5675 RVA: 0x0000543B File Offset: 0x0000363B
		Friend Overridable Property lblMAPL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMAPL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMAPL = value
			End Set
		End Property

		' Token: 0x170007B3 RID: 1971
		' (get) Token: 0x0600162C RID: 5676 RVA: 0x00118280 File Offset: 0x00116480
		' (set) Token: 0x0600162D RID: 5677 RVA: 0x00118298 File Offset: 0x00116498
		Friend Overridable Property txtTENPL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENPL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENPL IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENPL.GotFocus, AddressOf Me.txtTENPL_GotFocus
				End If
				Me._txtTENPL = value
				flag = Me._txtTENPL IsNot Nothing
				If flag Then
					AddHandler Me._txtTENPL.GotFocus, AddressOf Me.txtTENPL_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007B4 RID: 1972
		' (get) Token: 0x0600162E RID: 5678 RVA: 0x00118304 File Offset: 0x00116504
		' (set) Token: 0x0600162F RID: 5679 RVA: 0x0011831C File Offset: 0x0011651C
		Friend Overridable Property btnMAPL As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnMAPL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnMAPL IsNot Nothing
				If flag Then
					RemoveHandler Me._btnMAPL.Click, AddressOf Me.btnMAPL_Click
				End If
				Me._btnMAPL = value
				flag = Me._btnMAPL IsNot Nothing
				If flag Then
					AddHandler Me._btnMAPL.Click, AddressOf Me.btnMAPL_Click
				End If
			End Set
		End Property

		' Token: 0x170007B5 RID: 1973
		' (get) Token: 0x06001630 RID: 5680 RVA: 0x00118388 File Offset: 0x00116588
		' (set) Token: 0x06001631 RID: 5681 RVA: 0x001183A0 File Offset: 0x001165A0
		Friend Overridable Property txtMAPL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAPL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAPL IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAPL.KeyPress, AddressOf Me.txtMAPL_KeyPress
					RemoveHandler Me._txtMAPL.TextChanged, AddressOf Me.txtMAPL_TextChanged
				End If
				Me._txtMAPL = value
				flag = Me._txtMAPL IsNot Nothing
				If flag Then
					AddHandler Me._txtMAPL.KeyPress, AddressOf Me.txtMAPL_KeyPress
					AddHandler Me._txtMAPL.TextChanged, AddressOf Me.txtMAPL_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170007B6 RID: 1974
		' (get) Token: 0x06001632 RID: 5682 RVA: 0x0011843C File Offset: 0x0011663C
		' (set) Token: 0x06001633 RID: 5683 RVA: 0x00005445 File Offset: 0x00003645
		Friend Overridable Property lblMANSX As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMANSX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMANSX = value
			End Set
		End Property

		' Token: 0x170007B7 RID: 1975
		' (get) Token: 0x06001634 RID: 5684 RVA: 0x00118454 File Offset: 0x00116654
		' (set) Token: 0x06001635 RID: 5685 RVA: 0x0011846C File Offset: 0x0011666C
		Friend Overridable Property txtTENNSX As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENNSX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENNSX IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENNSX.GotFocus, AddressOf Me.txtTENNSX_GotFocus
				End If
				Me._txtTENNSX = value
				flag = Me._txtTENNSX IsNot Nothing
				If flag Then
					AddHandler Me._txtTENNSX.GotFocus, AddressOf Me.txtTENNSX_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007B8 RID: 1976
		' (get) Token: 0x06001636 RID: 5686 RVA: 0x001184D8 File Offset: 0x001166D8
		' (set) Token: 0x06001637 RID: 5687 RVA: 0x001184F0 File Offset: 0x001166F0
		Friend Overridable Property btnMANSX As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnMANSX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnMANSX IsNot Nothing
				If flag Then
					RemoveHandler Me._btnMANSX.Click, AddressOf Me.btnMANSX_Click
				End If
				Me._btnMANSX = value
				flag = Me._btnMANSX IsNot Nothing
				If flag Then
					AddHandler Me._btnMANSX.Click, AddressOf Me.btnMANSX_Click
				End If
			End Set
		End Property

		' Token: 0x170007B9 RID: 1977
		' (get) Token: 0x06001638 RID: 5688 RVA: 0x0011855C File Offset: 0x0011675C
		' (set) Token: 0x06001639 RID: 5689 RVA: 0x00118574 File Offset: 0x00116774
		Friend Overridable Property txtMANSX As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMANSX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMANSX IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMANSX.KeyPress, AddressOf Me.txtMANSX_KeyPress
					RemoveHandler Me._txtMANSX.TextChanged, AddressOf Me.txtMANSX_TextChanged
				End If
				Me._txtMANSX = value
				flag = Me._txtMANSX IsNot Nothing
				If flag Then
					AddHandler Me._txtMANSX.KeyPress, AddressOf Me.txtMANSX_KeyPress
					AddHandler Me._txtMANSX.TextChanged, AddressOf Me.txtMANSX_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170007BA RID: 1978
		' (get) Token: 0x0600163A RID: 5690 RVA: 0x00118610 File Offset: 0x00116810
		' (set) Token: 0x0600163B RID: 5691 RVA: 0x0000544F File Offset: 0x0000364F
		Friend Overridable Property lblPRICE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPRICE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPRICE = value
			End Set
		End Property

		' Token: 0x170007BB RID: 1979
		' (get) Token: 0x0600163C RID: 5692 RVA: 0x00118628 File Offset: 0x00116828
		' (set) Token: 0x0600163D RID: 5693 RVA: 0x00118640 File Offset: 0x00116840
		Friend Overridable Property txtPRICE As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE.LostFocus, AddressOf Me.txtPRICE_LostFocus
					RemoveHandler Me._txtPRICE.TextChanged, AddressOf Me.txtPRICE_TextChanged
					RemoveHandler Me._txtPRICE.KeyPress, AddressOf Me.txtPRICE_KeyPress
				End If
				Me._txtPRICE = value
				flag = Me._txtPRICE IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE.LostFocus, AddressOf Me.txtPRICE_LostFocus
					AddHandler Me._txtPRICE.TextChanged, AddressOf Me.txtPRICE_TextChanged
					AddHandler Me._txtPRICE.KeyPress, AddressOf Me.txtPRICE_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007BC RID: 1980
		' (get) Token: 0x0600163E RID: 5694 RVA: 0x00118710 File Offset: 0x00116910
		' (set) Token: 0x0600163F RID: 5695 RVA: 0x00005459 File Offset: 0x00003659
		Friend Overridable Property lblPRICE2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPRICE2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPRICE2 = value
			End Set
		End Property

		' Token: 0x170007BD RID: 1981
		' (get) Token: 0x06001640 RID: 5696 RVA: 0x00118728 File Offset: 0x00116928
		' (set) Token: 0x06001641 RID: 5697 RVA: 0x00118740 File Offset: 0x00116940
		Friend Overridable Property txtPRICE2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE2 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE2.LostFocus, AddressOf Me.txtPRICE2_LostFocus
					RemoveHandler Me._txtPRICE2.KeyPress, AddressOf Me.txtPRICE2_KeyPress
				End If
				Me._txtPRICE2 = value
				flag = Me._txtPRICE2 IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE2.LostFocus, AddressOf Me.txtPRICE2_LostFocus
					AddHandler Me._txtPRICE2.KeyPress, AddressOf Me.txtPRICE2_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007BE RID: 1982
		' (get) Token: 0x06001642 RID: 5698 RVA: 0x001187DC File Offset: 0x001169DC
		' (set) Token: 0x06001643 RID: 5699 RVA: 0x00005463 File Offset: 0x00003663
		Friend Overridable Property lblPRICE3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPRICE3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPRICE3 = value
			End Set
		End Property

		' Token: 0x170007BF RID: 1983
		' (get) Token: 0x06001644 RID: 5700 RVA: 0x001187F4 File Offset: 0x001169F4
		' (set) Token: 0x06001645 RID: 5701 RVA: 0x0011880C File Offset: 0x00116A0C
		Friend Overridable Property txtPRICE3 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE3 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE3.LostFocus, AddressOf Me.txtPRICE3_LostFocus
					RemoveHandler Me._txtPRICE3.KeyPress, AddressOf Me.txtPRICE3_KeyPress
				End If
				Me._txtPRICE3 = value
				flag = Me._txtPRICE3 IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE3.LostFocus, AddressOf Me.txtPRICE3_LostFocus
					AddHandler Me._txtPRICE3.KeyPress, AddressOf Me.txtPRICE3_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007C0 RID: 1984
		' (get) Token: 0x06001646 RID: 5702 RVA: 0x001188A8 File Offset: 0x00116AA8
		' (set) Token: 0x06001647 RID: 5703 RVA: 0x0000546D File Offset: 0x0000366D
		Friend Overridable Property lblPRICE6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPRICE6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPRICE6 = value
			End Set
		End Property

		' Token: 0x170007C1 RID: 1985
		' (get) Token: 0x06001648 RID: 5704 RVA: 0x001188C0 File Offset: 0x00116AC0
		' (set) Token: 0x06001649 RID: 5705 RVA: 0x001188D8 File Offset: 0x00116AD8
		Friend Overridable Property txtPRICE6 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE6 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE6.LostFocus, AddressOf Me.txtPRICE6_LostFocus
					RemoveHandler Me._txtPRICE6.KeyPress, AddressOf Me.txtPRICE6_KeyPress
				End If
				Me._txtPRICE6 = value
				flag = Me._txtPRICE6 IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE6.LostFocus, AddressOf Me.txtPRICE6_LostFocus
					AddHandler Me._txtPRICE6.KeyPress, AddressOf Me.txtPRICE6_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007C2 RID: 1986
		' (get) Token: 0x0600164A RID: 5706 RVA: 0x00118974 File Offset: 0x00116B74
		' (set) Token: 0x0600164B RID: 5707 RVA: 0x00005477 File Offset: 0x00003677
		Friend Overridable Property lblPRICE5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPRICE5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPRICE5 = value
			End Set
		End Property

		' Token: 0x170007C3 RID: 1987
		' (get) Token: 0x0600164C RID: 5708 RVA: 0x0011898C File Offset: 0x00116B8C
		' (set) Token: 0x0600164D RID: 5709 RVA: 0x001189A4 File Offset: 0x00116BA4
		Friend Overridable Property txtPRICE5 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE5 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE5.LostFocus, AddressOf Me.txtPRICE5_LostFocus
					RemoveHandler Me._txtPRICE5.KeyPress, AddressOf Me.txtPRICE5_KeyPress
				End If
				Me._txtPRICE5 = value
				flag = Me._txtPRICE5 IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE5.LostFocus, AddressOf Me.txtPRICE5_LostFocus
					AddHandler Me._txtPRICE5.KeyPress, AddressOf Me.txtPRICE5_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007C4 RID: 1988
		' (get) Token: 0x0600164E RID: 5710 RVA: 0x00118A40 File Offset: 0x00116C40
		' (set) Token: 0x0600164F RID: 5711 RVA: 0x00005481 File Offset: 0x00003681
		Friend Overridable Property lblPRICE4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPRICE4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPRICE4 = value
			End Set
		End Property

		' Token: 0x170007C5 RID: 1989
		' (get) Token: 0x06001650 RID: 5712 RVA: 0x00118A58 File Offset: 0x00116C58
		' (set) Token: 0x06001651 RID: 5713 RVA: 0x00118A70 File Offset: 0x00116C70
		Friend Overridable Property txtPRICE4 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE4 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE4.LostFocus, AddressOf Me.txtPRICE4_LostFocus
					RemoveHandler Me._txtPRICE4.KeyPress, AddressOf Me.txtPRICE4_KeyPress
				End If
				Me._txtPRICE4 = value
				flag = Me._txtPRICE4 IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE4.LostFocus, AddressOf Me.txtPRICE4_LostFocus
					AddHandler Me._txtPRICE4.KeyPress, AddressOf Me.txtPRICE4_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007C6 RID: 1990
		' (get) Token: 0x06001652 RID: 5714 RVA: 0x00118B0C File Offset: 0x00116D0C
		' (set) Token: 0x06001653 RID: 5715 RVA: 0x0000548B File Offset: 0x0000368B
		Friend Overridable Property lblPRICE9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPRICE9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPRICE9 = value
			End Set
		End Property

		' Token: 0x170007C7 RID: 1991
		' (get) Token: 0x06001654 RID: 5716 RVA: 0x00118B24 File Offset: 0x00116D24
		' (set) Token: 0x06001655 RID: 5717 RVA: 0x00118B3C File Offset: 0x00116D3C
		Friend Overridable Property txtPRICE9 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE9 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE9.LostFocus, AddressOf Me.txtPRICE9_LostFocus
					RemoveHandler Me._txtPRICE9.KeyPress, AddressOf Me.txtPRICE9_KeyPress
				End If
				Me._txtPRICE9 = value
				flag = Me._txtPRICE9 IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE9.LostFocus, AddressOf Me.txtPRICE9_LostFocus
					AddHandler Me._txtPRICE9.KeyPress, AddressOf Me.txtPRICE9_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007C8 RID: 1992
		' (get) Token: 0x06001656 RID: 5718 RVA: 0x00118BD8 File Offset: 0x00116DD8
		' (set) Token: 0x06001657 RID: 5719 RVA: 0x00005495 File Offset: 0x00003695
		Friend Overridable Property lblPRICE8 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPRICE8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPRICE8 = value
			End Set
		End Property

		' Token: 0x170007C9 RID: 1993
		' (get) Token: 0x06001658 RID: 5720 RVA: 0x00118BF0 File Offset: 0x00116DF0
		' (set) Token: 0x06001659 RID: 5721 RVA: 0x00118C08 File Offset: 0x00116E08
		Friend Overridable Property txtPRICE8 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE8 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE8.LostFocus, AddressOf Me.txtPRICE8_LostFocus
					RemoveHandler Me._txtPRICE8.KeyPress, AddressOf Me.txtPRICE8_KeyPress
				End If
				Me._txtPRICE8 = value
				flag = Me._txtPRICE8 IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE8.LostFocus, AddressOf Me.txtPRICE8_LostFocus
					AddHandler Me._txtPRICE8.KeyPress, AddressOf Me.txtPRICE8_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007CA RID: 1994
		' (get) Token: 0x0600165A RID: 5722 RVA: 0x00118CA4 File Offset: 0x00116EA4
		' (set) Token: 0x0600165B RID: 5723 RVA: 0x0000549F File Offset: 0x0000369F
		Friend Overridable Property lblPRICE7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPRICE7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPRICE7 = value
			End Set
		End Property

		' Token: 0x170007CB RID: 1995
		' (get) Token: 0x0600165C RID: 5724 RVA: 0x00118CBC File Offset: 0x00116EBC
		' (set) Token: 0x0600165D RID: 5725 RVA: 0x00118CD4 File Offset: 0x00116ED4
		Friend Overridable Property txtPRICE7 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE7 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE7.LostFocus, AddressOf Me.txtPRICE7_LostFocus
					RemoveHandler Me._txtPRICE7.KeyPress, AddressOf Me.txtPRICE7_KeyPress
				End If
				Me._txtPRICE7 = value
				flag = Me._txtPRICE7 IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE7.LostFocus, AddressOf Me.txtPRICE7_LostFocus
					AddHandler Me._txtPRICE7.KeyPress, AddressOf Me.txtPRICE7_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007CC RID: 1996
		' (get) Token: 0x0600165E RID: 5726 RVA: 0x00118D70 File Offset: 0x00116F70
		' (set) Token: 0x0600165F RID: 5727 RVA: 0x000054A9 File Offset: 0x000036A9
		Friend Overridable Property lblPRICE10 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPRICE10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPRICE10 = value
			End Set
		End Property

		' Token: 0x170007CD RID: 1997
		' (get) Token: 0x06001660 RID: 5728 RVA: 0x00118D88 File Offset: 0x00116F88
		' (set) Token: 0x06001661 RID: 5729 RVA: 0x00118DA0 File Offset: 0x00116FA0
		Friend Overridable Property txtPRICE10 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE10 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE10.LostFocus, AddressOf Me.txtPRICE10_LostFocus
					RemoveHandler Me._txtPRICE10.KeyPress, AddressOf Me.txtPRICE10_KeyPress
				End If
				Me._txtPRICE10 = value
				flag = Me._txtPRICE10 IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE10.LostFocus, AddressOf Me.txtPRICE10_LostFocus
					AddHandler Me._txtPRICE10.KeyPress, AddressOf Me.txtPRICE10_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007CE RID: 1998
		' (get) Token: 0x06001662 RID: 5730 RVA: 0x00118E3C File Offset: 0x0011703C
		' (set) Token: 0x06001663 RID: 5731 RVA: 0x000054B3 File Offset: 0x000036B3
		Friend Overridable Property panMain As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panMain
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panMain = value
			End Set
		End Property

		' Token: 0x170007CF RID: 1999
		' (get) Token: 0x06001664 RID: 5732 RVA: 0x00118E54 File Offset: 0x00117054
		' (set) Token: 0x06001665 RID: 5733 RVA: 0x000054BD File Offset: 0x000036BD
		Friend Overridable Property panMAMT As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panMAMT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panMAMT = value
			End Set
		End Property

		' Token: 0x170007D0 RID: 2000
		' (get) Token: 0x06001666 RID: 5734 RVA: 0x00118E6C File Offset: 0x0011706C
		' (set) Token: 0x06001667 RID: 5735 RVA: 0x000054C7 File Offset: 0x000036C7
		Friend Overridable Property panMAPL_MANSX As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panMAPL_MANSX
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panMAPL_MANSX = value
			End Set
		End Property

		' Token: 0x170007D1 RID: 2001
		' (get) Token: 0x06001668 RID: 5736 RVA: 0x00118E84 File Offset: 0x00117084
		' (set) Token: 0x06001669 RID: 5737 RVA: 0x000054D1 File Offset: 0x000036D1
		Friend Overridable Property panLMATERIAL As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panLMATERIAL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panLMATERIAL = value
			End Set
		End Property

		' Token: 0x170007D2 RID: 2002
		' (get) Token: 0x0600166A RID: 5738 RVA: 0x00118E9C File Offset: 0x0011709C
		' (set) Token: 0x0600166B RID: 5739 RVA: 0x000054DB File Offset: 0x000036DB
		Friend Overridable Property panPRICE As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panPRICE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panPRICE = value
			End Set
		End Property

		' Token: 0x170007D3 RID: 2003
		' (get) Token: 0x0600166C RID: 5740 RVA: 0x00118EB4 File Offset: 0x001170B4
		' (set) Token: 0x0600166D RID: 5741 RVA: 0x000054E5 File Offset: 0x000036E5
		Friend Overridable Property panPRICE2_3_4 As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panPRICE2_3_4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panPRICE2_3_4 = value
			End Set
		End Property

		' Token: 0x170007D4 RID: 2004
		' (get) Token: 0x0600166E RID: 5742 RVA: 0x00118ECC File Offset: 0x001170CC
		' (set) Token: 0x0600166F RID: 5743 RVA: 0x000054EF File Offset: 0x000036EF
		Friend Overridable Property panPRICE5_6_7 As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panPRICE5_6_7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panPRICE5_6_7 = value
			End Set
		End Property

		' Token: 0x170007D5 RID: 2005
		' (get) Token: 0x06001670 RID: 5744 RVA: 0x00118EE4 File Offset: 0x001170E4
		' (set) Token: 0x06001671 RID: 5745 RVA: 0x000054F9 File Offset: 0x000036F9
		Friend Overridable Property panPRICE8_9_10 As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panPRICE8_9_10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panPRICE8_9_10 = value
			End Set
		End Property

		' Token: 0x170007D6 RID: 2006
		' (get) Token: 0x06001672 RID: 5746 RVA: 0x00118EFC File Offset: 0x001170FC
		' (set) Token: 0x06001673 RID: 5747 RVA: 0x00005503 File Offset: 0x00003703
		Friend Overridable Property panLSALE As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panLSALE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panLSALE = value
			End Set
		End Property

		' Token: 0x170007D7 RID: 2007
		' (get) Token: 0x06001674 RID: 5748 RVA: 0x00118F14 File Offset: 0x00117114
		' (set) Token: 0x06001675 RID: 5749 RVA: 0x0000550D File Offset: 0x0000370D
		Friend Overridable Property panButton As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panButton = value
			End Set
		End Property

		' Token: 0x170007D8 RID: 2008
		' (get) Token: 0x06001676 RID: 5750 RVA: 0x00118F2C File Offset: 0x0011712C
		' (set) Token: 0x06001677 RID: 5751 RVA: 0x00005517 File Offset: 0x00003717
		Friend Overridable Property chkLMATERIAL As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLMATERIAL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLMATERIAL = value
			End Set
		End Property

		' Token: 0x170007D9 RID: 2009
		' (get) Token: 0x06001678 RID: 5752 RVA: 0x00118F44 File Offset: 0x00117144
		' (set) Token: 0x06001679 RID: 5753 RVA: 0x00005521 File Offset: 0x00003721
		Friend Overridable Property lblLMATERIAL As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLMATERIAL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblLMATERIAL = value
			End Set
		End Property

		' Token: 0x170007DA RID: 2010
		' (get) Token: 0x0600167A RID: 5754 RVA: 0x00118F5C File Offset: 0x0011715C
		' (set) Token: 0x0600167B RID: 5755 RVA: 0x0000552B File Offset: 0x0000372B
		Friend Overridable Property panREMARK As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panREMARK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panREMARK = value
			End Set
		End Property

		' Token: 0x170007DB RID: 2011
		' (get) Token: 0x0600167C RID: 5756 RVA: 0x00118F74 File Offset: 0x00117174
		' (set) Token: 0x0600167D RID: 5757 RVA: 0x00005535 File Offset: 0x00003735
		Friend Overridable Property lblMADC As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMADC
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMADC = value
			End Set
		End Property

		' Token: 0x170007DC RID: 2012
		' (get) Token: 0x0600167E RID: 5758 RVA: 0x00118F8C File Offset: 0x0011718C
		' (set) Token: 0x0600167F RID: 5759 RVA: 0x00118FA4 File Offset: 0x001171A4
		Friend Overridable Property txtMADC As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMADC
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMADC IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMADC.KeyPress, AddressOf Me.txtMADC_KeyPress
				End If
				Me._txtMADC = value
				flag = Me._txtMADC IsNot Nothing
				If flag Then
					AddHandler Me._txtMADC.KeyPress, AddressOf Me.txtMADC_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170007DD RID: 2013
		' (get) Token: 0x06001680 RID: 5760 RVA: 0x00119010 File Offset: 0x00117210
		' (set) Token: 0x06001681 RID: 5761 RVA: 0x0000553F File Offset: 0x0000373F
		Friend Overridable Property btnMADC As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnMADC
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnMADC = value
			End Set
		End Property

		' Token: 0x170007DE RID: 2014
		' (get) Token: 0x06001682 RID: 5762 RVA: 0x00119028 File Offset: 0x00117228
		' (set) Token: 0x06001683 RID: 5763 RVA: 0x00119040 File Offset: 0x00117240
		Friend Overridable Property txtTENDC As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENDC
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENDC IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENDC.GotFocus, AddressOf Me.txtTENDC_GotFocus
				End If
				Me._txtTENDC = value
				flag = Me._txtTENDC IsNot Nothing
				If flag Then
					AddHandler Me._txtTENDC.GotFocus, AddressOf Me.txtTENDC_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007DF RID: 2015
		' (get) Token: 0x06001684 RID: 5764 RVA: 0x001190AC File Offset: 0x001172AC
		' (set) Token: 0x06001685 RID: 5765 RVA: 0x001190C4 File Offset: 0x001172C4
		Friend Overridable Property txtTENDVT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENDVT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENDVT IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENDVT.GotFocus, AddressOf Me.txtTENDVT_GotFocus
				End If
				Me._txtTENDVT = value
				flag = Me._txtTENDVT IsNot Nothing
				If flag Then
					AddHandler Me._txtTENDVT.GotFocus, AddressOf Me.txtTENDVT_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007E0 RID: 2016
		' (get) Token: 0x06001686 RID: 5766 RVA: 0x00119130 File Offset: 0x00117330
		' (set) Token: 0x06001687 RID: 5767 RVA: 0x00119148 File Offset: 0x00117348
		Friend Overridable Property btnDVT As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDVT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDVT IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDVT.Click, AddressOf Me.btnDVT_Click
				End If
				Me._btnDVT = value
				flag = Me._btnDVT IsNot Nothing
				If flag Then
					AddHandler Me._btnDVT.Click, AddressOf Me.btnDVT_Click
				End If
			End Set
		End Property

		' Token: 0x170007E1 RID: 2017
		' (get) Token: 0x06001688 RID: 5768 RVA: 0x001191B4 File Offset: 0x001173B4
		' (set) Token: 0x06001689 RID: 5769 RVA: 0x001191CC File Offset: 0x001173CC
		Friend Overridable Property txtMADV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMADV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMADV IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMADV.TextChanged, AddressOf Me.txtMADV_TextChanged
					RemoveHandler Me._txtMADV.KeyPress, AddressOf Me.txtMADV_KeyPress
					RemoveHandler Me._txtMADV.GotFocus, AddressOf Me.txtMADV_GotFocus
				End If
				Me._txtMADV = value
				flag = Me._txtMADV IsNot Nothing
				If flag Then
					AddHandler Me._txtMADV.TextChanged, AddressOf Me.txtMADV_TextChanged
					AddHandler Me._txtMADV.KeyPress, AddressOf Me.txtMADV_KeyPress
					AddHandler Me._txtMADV.GotFocus, AddressOf Me.txtMADV_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007E2 RID: 2018
		' (get) Token: 0x0600168A RID: 5770 RVA: 0x0011929C File Offset: 0x0011749C
		' (set) Token: 0x0600168B RID: 5771 RVA: 0x001192B4 File Offset: 0x001174B4
		Friend Overridable Property txtTENDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENDV IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENDV.GotFocus, AddressOf Me.txtTENDV_GotFocus
				End If
				Me._txtTENDV = value
				flag = Me._txtTENDV IsNot Nothing
				If flag Then
					AddHandler Me._txtTENDV.GotFocus, AddressOf Me.txtTENDV_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170007E3 RID: 2019
		' (get) Token: 0x0600168C RID: 5772 RVA: 0x00119320 File Offset: 0x00117520
		' (set) Token: 0x0600168D RID: 5773 RVA: 0x00119338 File Offset: 0x00117538
		Friend Overridable Property btnDMDV As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMDV.Click, AddressOf Me.btnDMDV_Click
				End If
				Me._btnDMDV = value
				flag = Me._btnDMDV IsNot Nothing
				If flag Then
					AddHandler Me._btnDMDV.Click, AddressOf Me.btnDMDV_Click
				End If
			End Set
		End Property

		' Token: 0x170007E4 RID: 2020
		' (get) Token: 0x0600168E RID: 5774 RVA: 0x001193A4 File Offset: 0x001175A4
		' (set) Token: 0x0600168F RID: 5775 RVA: 0x00005549 File Offset: 0x00003749
		Friend Overridable Property lblMADV As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMADV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMADV = value
			End Set
		End Property

		' Token: 0x170007E5 RID: 2021
		' (get) Token: 0x06001690 RID: 5776 RVA: 0x001193BC File Offset: 0x001175BC
		' (set) Token: 0x06001691 RID: 5777 RVA: 0x00005553 File Offset: 0x00003753
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170007E6 RID: 2022
		' (get) Token: 0x06001692 RID: 5778 RVA: 0x001193D4 File Offset: 0x001175D4
		' (set) Token: 0x06001693 RID: 5779 RVA: 0x0000555D File Offset: 0x0000375D
		Friend Overridable Property lblbep3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblbep3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblbep3 = value
			End Set
		End Property

		' Token: 0x170007E7 RID: 2023
		' (get) Token: 0x06001694 RID: 5780 RVA: 0x001193EC File Offset: 0x001175EC
		' (set) Token: 0x06001695 RID: 5781 RVA: 0x00119404 File Offset: 0x00117604
		Friend Overridable Property txtbep3 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtbep3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtbep3 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtbep3.TextChanged, AddressOf Me.txtbep3_TextChanged
				End If
				Me._txtbep3 = value
				flag = Me._txtbep3 IsNot Nothing
				If flag Then
					AddHandler Me._txtbep3.TextChanged, AddressOf Me.txtbep3_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170007E8 RID: 2024
		' (get) Token: 0x06001696 RID: 5782 RVA: 0x00119470 File Offset: 0x00117670
		' (set) Token: 0x06001697 RID: 5783 RVA: 0x00119488 File Offset: 0x00117688
		Friend Overridable Property btnDMBEP3 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMBEP3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMBEP3 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMBEP3.Click, AddressOf Me.btnDMBEP3_Click
				End If
				Me._btnDMBEP3 = value
				flag = Me._btnDMBEP3 IsNot Nothing
				If flag Then
					AddHandler Me._btnDMBEP3.Click, AddressOf Me.btnDMBEP3_Click
				End If
			End Set
		End Property

		' Token: 0x170007E9 RID: 2025
		' (get) Token: 0x06001698 RID: 5784 RVA: 0x001194F4 File Offset: 0x001176F4
		' (set) Token: 0x06001699 RID: 5785 RVA: 0x00005567 File Offset: 0x00003767
		Friend Overridable Property txtTENBEP3 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENBEP3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENBEP3 = value
			End Set
		End Property

		' Token: 0x170007EA RID: 2026
		' (get) Token: 0x0600169A RID: 5786 RVA: 0x0011950C File Offset: 0x0011770C
		' (set) Token: 0x0600169B RID: 5787 RVA: 0x00005571 File Offset: 0x00003771
		Friend Overridable Property lblbep2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblbep2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblbep2 = value
			End Set
		End Property

		' Token: 0x170007EB RID: 2027
		' (get) Token: 0x0600169C RID: 5788 RVA: 0x00119524 File Offset: 0x00117724
		' (set) Token: 0x0600169D RID: 5789 RVA: 0x0011953C File Offset: 0x0011773C
		Friend Overridable Property txtbep2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtbep2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtbep2 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtbep2.TextChanged, AddressOf Me.txtbep2_TextChanged
				End If
				Me._txtbep2 = value
				flag = Me._txtbep2 IsNot Nothing
				If flag Then
					AddHandler Me._txtbep2.TextChanged, AddressOf Me.txtbep2_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170007EC RID: 2028
		' (get) Token: 0x0600169E RID: 5790 RVA: 0x001195A8 File Offset: 0x001177A8
		' (set) Token: 0x0600169F RID: 5791 RVA: 0x001195C0 File Offset: 0x001177C0
		Friend Overridable Property btnDMBEP2 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMBEP2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMBEP2 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMBEP2.Click, AddressOf Me.btnDMBEP2_Click
				End If
				Me._btnDMBEP2 = value
				flag = Me._btnDMBEP2 IsNot Nothing
				If flag Then
					AddHandler Me._btnDMBEP2.Click, AddressOf Me.btnDMBEP2_Click
				End If
			End Set
		End Property

		' Token: 0x170007ED RID: 2029
		' (get) Token: 0x060016A0 RID: 5792 RVA: 0x0011962C File Offset: 0x0011782C
		' (set) Token: 0x060016A1 RID: 5793 RVA: 0x0000557B File Offset: 0x0000377B
		Friend Overridable Property txtTENBEP2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENBEP2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENBEP2 = value
			End Set
		End Property

		' Token: 0x170007EE RID: 2030
		' (get) Token: 0x060016A2 RID: 5794 RVA: 0x00119644 File Offset: 0x00117844
		' (set) Token: 0x060016A3 RID: 5795 RVA: 0x00005585 File Offset: 0x00003785
		Friend Overridable Property lblbep1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblbep1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblbep1 = value
			End Set
		End Property

		' Token: 0x170007EF RID: 2031
		' (get) Token: 0x060016A4 RID: 5796 RVA: 0x0011965C File Offset: 0x0011785C
		' (set) Token: 0x060016A5 RID: 5797 RVA: 0x00119674 File Offset: 0x00117874
		Friend Overridable Property txtbep1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtbep1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtbep1 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtbep1.TextChanged, AddressOf Me.txtbep1_TextChanged
				End If
				Me._txtbep1 = value
				flag = Me._txtbep1 IsNot Nothing
				If flag Then
					AddHandler Me._txtbep1.TextChanged, AddressOf Me.txtbep1_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170007F0 RID: 2032
		' (get) Token: 0x060016A6 RID: 5798 RVA: 0x001196E0 File Offset: 0x001178E0
		' (set) Token: 0x060016A7 RID: 5799 RVA: 0x001196F8 File Offset: 0x001178F8
		Friend Overridable Property btnDMBEP1 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMBEP1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMBEP1 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMBEP1.Click, AddressOf Me.btnDMBEP1_Click
				End If
				Me._btnDMBEP1 = value
				flag = Me._btnDMBEP1 IsNot Nothing
				If flag Then
					AddHandler Me._btnDMBEP1.Click, AddressOf Me.btnDMBEP1_Click
				End If
			End Set
		End Property

		' Token: 0x170007F1 RID: 2033
		' (get) Token: 0x060016A8 RID: 5800 RVA: 0x00119764 File Offset: 0x00117964
		' (set) Token: 0x060016A9 RID: 5801 RVA: 0x0000558F File Offset: 0x0000378F
		Friend Overridable Property txtTENBEP1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENBEP1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENBEP1 = value
			End Set
		End Property

		' Token: 0x170007F2 RID: 2034
		' (get) Token: 0x060016AA RID: 5802 RVA: 0x0011977C File Offset: 0x0011797C
		' (set) Token: 0x060016AB RID: 5803 RVA: 0x00005599 File Offset: 0x00003799
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x170007F3 RID: 2035
		' (get) Token: 0x060016AC RID: 5804 RVA: 0x00119794 File Offset: 0x00117994
		' (set) Token: 0x060016AD RID: 5805 RVA: 0x001197AC File Offset: 0x001179AC
		Friend Overridable Property chkLopen As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLopen
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLopen IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLopen.CheckedChanged, AddressOf Me.chkLopen_CheckedChanged
				End If
				Me._chkLopen = value
				flag = Me._chkLopen IsNot Nothing
				If flag Then
					AddHandler Me._chkLopen.CheckedChanged, AddressOf Me.chkLopen_CheckedChanged
				End If
			End Set
		End Property

		' Token: 0x170007F4 RID: 2036
		' (get) Token: 0x060016AE RID: 5806 RVA: 0x00119818 File Offset: 0x00117A18
		' (set) Token: 0x060016AF RID: 5807 RVA: 0x000055A3 File Offset: 0x000037A3
		Friend Overridable Property chkStopUse As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkStopUse
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkStopUse = value
			End Set
		End Property

		' Token: 0x170007F5 RID: 2037
		' (get) Token: 0x060016B0 RID: 5808 RVA: 0x00119830 File Offset: 0x00117A30
		' (set) Token: 0x060016B1 RID: 5809 RVA: 0x000055AD File Offset: 0x000037AD
		Friend Overridable Property lblStop As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblStop
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblStop = value
			End Set
		End Property

		' Token: 0x170007F6 RID: 2038
		' (get) Token: 0x060016B2 RID: 5810 RVA: 0x00119848 File Offset: 0x00117A48
		' (set) Token: 0x060016B3 RID: 5811 RVA: 0x000055B7 File Offset: 0x000037B7
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x170007F7 RID: 2039
		' (get) Token: 0x060016B4 RID: 5812 RVA: 0x00119860 File Offset: 0x00117A60
		' (set) Token: 0x060016B5 RID: 5813 RVA: 0x00119878 File Offset: 0x00117A78
		Friend Overridable Property chkCOMBO As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkCOMBO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkCOMBO IsNot Nothing
				If flag Then
					RemoveHandler Me._chkCOMBO.Click, AddressOf Me.chkCOMBO_Click
				End If
				Me._chkCOMBO = value
				flag = Me._chkCOMBO IsNot Nothing
				If flag Then
					AddHandler Me._chkCOMBO.Click, AddressOf Me.chkCOMBO_Click
				End If
			End Set
		End Property

		' Token: 0x170007F8 RID: 2040
		' (get) Token: 0x060016B6 RID: 5814 RVA: 0x001198E4 File Offset: 0x00117AE4
		' (set) Token: 0x060016B7 RID: 5815 RVA: 0x000055C1 File Offset: 0x000037C1
		Friend Overridable Property txtCOMBO As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtCOMBO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtCOMBO = value
			End Set
		End Property

		' Token: 0x170007F9 RID: 2041
		' (get) Token: 0x060016B8 RID: 5816 RVA: 0x001198FC File Offset: 0x00117AFC
		' (set) Token: 0x060016B9 RID: 5817 RVA: 0x00119914 File Offset: 0x00117B14
		Friend Overridable Property btnCOMBO As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCOMBO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCOMBO IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCOMBO.Click, AddressOf Me.btnCOMBO_Click
				End If
				Me._btnCOMBO = value
				flag = Me._btnCOMBO IsNot Nothing
				If flag Then
					AddHandler Me._btnCOMBO.Click, AddressOf Me.btnCOMBO_Click
				End If
			End Set
		End Property

		' Token: 0x170007FA RID: 2042
		' (get) Token: 0x060016BA RID: 5818 RVA: 0x00119980 File Offset: 0x00117B80
		' (set) Token: 0x060016BB RID: 5819 RVA: 0x000055CB File Offset: 0x000037CB
		Friend Overridable Property grbTONKHO As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grbTONKHO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grbTONKHO = value
			End Set
		End Property

		' Token: 0x170007FB RID: 2043
		' (get) Token: 0x060016BC RID: 5820 RVA: 0x00119998 File Offset: 0x00117B98
		' (set) Token: 0x060016BD RID: 5821 RVA: 0x000055D5 File Offset: 0x000037D5
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x170007FC RID: 2044
		' (get) Token: 0x060016BE RID: 5822 RVA: 0x001199B0 File Offset: 0x00117BB0
		' (set) Token: 0x060016BF RID: 5823 RVA: 0x001199C8 File Offset: 0x00117BC8
		Friend Overridable Property txtMAKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
				Me._txtMAKH = value
				flag = Me._txtMAKH IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170007FD RID: 2045
		' (get) Token: 0x060016C0 RID: 5824 RVA: 0x00119A34 File Offset: 0x00117C34
		' (set) Token: 0x060016C1 RID: 5825 RVA: 0x000055DF File Offset: 0x000037DF
		Friend Overridable Property btnDMKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnDMKH = value
			End Set
		End Property

		' Token: 0x170007FE RID: 2046
		' (get) Token: 0x060016C2 RID: 5826 RVA: 0x00119A4C File Offset: 0x00117C4C
		' (set) Token: 0x060016C3 RID: 5827 RVA: 0x000055E9 File Offset: 0x000037E9
		Friend Overridable Property txtTENKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENKH = value
			End Set
		End Property

		' Token: 0x170007FF RID: 2047
		' (get) Token: 0x060016C4 RID: 5828 RVA: 0x00119A64 File Offset: 0x00117C64
		' (set) Token: 0x060016C5 RID: 5829 RVA: 0x000055F3 File Offset: 0x000037F3
		Friend Overridable Property Label6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label6 = value
			End Set
		End Property

		' Token: 0x17000800 RID: 2048
		' (get) Token: 0x060016C6 RID: 5830 RVA: 0x00119A7C File Offset: 0x00117C7C
		' (set) Token: 0x060016C7 RID: 5831 RVA: 0x00119A94 File Offset: 0x00117C94
		Friend Overridable Property txtTT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTT IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTT.LostFocus, AddressOf Me.txtTT_LostFocus
					RemoveHandler Me._txtTT.KeyPress, AddressOf Me.txtTT_KeyPress
				End If
				Me._txtTT = value
				flag = Me._txtTT IsNot Nothing
				If flag Then
					AddHandler Me._txtTT.LostFocus, AddressOf Me.txtTT_LostFocus
					AddHandler Me._txtTT.KeyPress, AddressOf Me.txtTT_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000801 RID: 2049
		' (get) Token: 0x060016C8 RID: 5832 RVA: 0x00119B30 File Offset: 0x00117D30
		' (set) Token: 0x060016C9 RID: 5833 RVA: 0x000055FD File Offset: 0x000037FD
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x17000802 RID: 2050
		' (get) Token: 0x060016CA RID: 5834 RVA: 0x00119B48 File Offset: 0x00117D48
		' (set) Token: 0x060016CB RID: 5835 RVA: 0x00119B60 File Offset: 0x00117D60
		Friend Overridable Property txtDG As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtDG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtDG IsNot Nothing
				If flag Then
					RemoveHandler Me._txtDG.LostFocus, AddressOf Me.txtDG_LostFocus
					RemoveHandler Me._txtDG.KeyPress, AddressOf Me.txtDG_KeyPress
				End If
				Me._txtDG = value
				flag = Me._txtDG IsNot Nothing
				If flag Then
					AddHandler Me._txtDG.LostFocus, AddressOf Me.txtDG_LostFocus
					AddHandler Me._txtDG.KeyPress, AddressOf Me.txtDG_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000803 RID: 2051
		' (get) Token: 0x060016CC RID: 5836 RVA: 0x00119BFC File Offset: 0x00117DFC
		' (set) Token: 0x060016CD RID: 5837 RVA: 0x00005607 File Offset: 0x00003807
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x17000804 RID: 2052
		' (get) Token: 0x060016CE RID: 5838 RVA: 0x00119C14 File Offset: 0x00117E14
		' (set) Token: 0x060016CF RID: 5839 RVA: 0x00119C2C File Offset: 0x00117E2C
		Friend Overridable Property txtSL As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtSL
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtSL IsNot Nothing
				If flag Then
					RemoveHandler Me._txtSL.LostFocus, AddressOf Me.txtSL_LostFocus
					RemoveHandler Me._txtSL.KeyPress, AddressOf Me.txtSL_KeyPress
				End If
				Me._txtSL = value
				flag = Me._txtSL IsNot Nothing
				If flag Then
					AddHandler Me._txtSL.LostFocus, AddressOf Me.txtSL_LostFocus
					AddHandler Me._txtSL.KeyPress, AddressOf Me.txtSL_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000805 RID: 2053
		' (get) Token: 0x060016D0 RID: 5840 RVA: 0x00119CC8 File Offset: 0x00117EC8
		' (set) Token: 0x060016D1 RID: 5841 RVA: 0x00005611 File Offset: 0x00003811
		Friend Overridable Property lblOUTDATE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOUTDATE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOUTDATE = value
			End Set
		End Property

		' Token: 0x17000806 RID: 2054
		' (get) Token: 0x060016D2 RID: 5842 RVA: 0x00119CE0 File Offset: 0x00117EE0
		' (set) Token: 0x060016D3 RID: 5843 RVA: 0x0000561B File Offset: 0x0000381B
		Friend Overridable Property mtbOutDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtbOutDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtbOutDate = value
			End Set
		End Property

		' Token: 0x17000807 RID: 2055
		' (get) Token: 0x060016D4 RID: 5844 RVA: 0x00119CF8 File Offset: 0x00117EF8
		' (set) Token: 0x060016D5 RID: 5845 RVA: 0x00119D10 File Offset: 0x00117F10
		Friend Overridable Property btnTen As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnTen
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnTen IsNot Nothing
				If flag Then
					RemoveHandler Me._btnTen.Click, AddressOf Me.btnTen_Click
				End If
				Me._btnTen = value
				flag = Me._btnTen IsNot Nothing
				If flag Then
					AddHandler Me._btnTen.Click, AddressOf Me.btnTen_Click
				End If
			End Set
		End Property

		' Token: 0x17000808 RID: 2056
		' (get) Token: 0x060016D6 RID: 5846 RVA: 0x00119D7C File Offset: 0x00117F7C
		' (set) Token: 0x060016D7 RID: 5847 RVA: 0x00119D94 File Offset: 0x00117F94
		Friend Overridable Property btnGia1 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnGia1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnGia1 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnGia1.Click, AddressOf Me.btnGia1_Click
				End If
				Me._btnGia1 = value
				flag = Me._btnGia1 IsNot Nothing
				If flag Then
					AddHandler Me._btnGia1.Click, AddressOf Me.btnGia1_Click
				End If
			End Set
		End Property

		' Token: 0x17000809 RID: 2057
		' (get) Token: 0x060016D8 RID: 5848 RVA: 0x00119E00 File Offset: 0x00118000
		' (set) Token: 0x060016D9 RID: 5849 RVA: 0x00005625 File Offset: 0x00003825
		Friend Overridable Property Label7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		' Token: 0x1700080A RID: 2058
		' (get) Token: 0x060016DA RID: 5850 RVA: 0x00119E18 File Offset: 0x00118018
		' (set) Token: 0x060016DB RID: 5851 RVA: 0x00119E30 File Offset: 0x00118030
		Friend Overridable Property txtPURSE As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPURSE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPURSE IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPURSE.LostFocus, AddressOf Me.txtPURSE_LostFocus
					RemoveHandler Me._txtPURSE.KeyPress, AddressOf Me.txtPURSE_KeyPress
				End If
				Me._txtPURSE = value
				flag = Me._txtPURSE IsNot Nothing
				If flag Then
					AddHandler Me._txtPURSE.LostFocus, AddressOf Me.txtPURSE_LostFocus
					AddHandler Me._txtPURSE.KeyPress, AddressOf Me.txtPURSE_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700080B RID: 2059
		' (get) Token: 0x060016DC RID: 5852 RVA: 0x00119ECC File Offset: 0x001180CC
		' (set) Token: 0x060016DD RID: 5853 RVA: 0x0000562F File Offset: 0x0000382F
		Friend Overridable Property Label8 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label8 = value
			End Set
		End Property

		' Token: 0x1700080C RID: 2060
		' (get) Token: 0x060016DE RID: 5854 RVA: 0x00119EE4 File Offset: 0x001180E4
		' (set) Token: 0x060016DF RID: 5855 RVA: 0x00005639 File Offset: 0x00003839
		Friend Overridable Property chkLSETCOMBO As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLSETCOMBO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLSETCOMBO = value
			End Set
		End Property

		' Token: 0x1700080D RID: 2061
		' (get) Token: 0x060016E0 RID: 5856 RVA: 0x00119EFC File Offset: 0x001180FC
		' (set) Token: 0x060016E1 RID: 5857 RVA: 0x00005643 File Offset: 0x00003843
		Friend Overridable Property Label9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label9 = value
			End Set
		End Property

		' Token: 0x1700080E RID: 2062
		' (get) Token: 0x060016E2 RID: 5858 RVA: 0x00119F14 File Offset: 0x00118114
		' (set) Token: 0x060016E3 RID: 5859 RVA: 0x0000564D File Offset: 0x0000384D
		Friend Overridable Property chkLTON_KHACHHANG As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLTON_KHACHHANG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLTON_KHACHHANG = value
			End Set
		End Property

		' Token: 0x1700080F RID: 2063
		' (get) Token: 0x060016E4 RID: 5860 RVA: 0x00119F2C File Offset: 0x0011812C
		' (set) Token: 0x060016E5 RID: 5861 RVA: 0x00005657 File Offset: 0x00003857
		Friend Overridable Property txtPhieu As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPhieu
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtPhieu = value
			End Set
		End Property

		' Token: 0x17000810 RID: 2064
		' (get) Token: 0x060016E6 RID: 5862 RVA: 0x00119F44 File Offset: 0x00118144
		' (set) Token: 0x060016E7 RID: 5863 RVA: 0x00119F5C File Offset: 0x0011815C
		Friend Overridable Property btnPhieu As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPhieu
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPhieu IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPhieu.Click, AddressOf Me.btnPhieu_Click
				End If
				Me._btnPhieu = value
				flag = Me._btnPhieu IsNot Nothing
				If flag Then
					AddHandler Me._btnPhieu.Click, AddressOf Me.btnPhieu_Click
				End If
			End Set
		End Property

		' Token: 0x17000811 RID: 2065
		' (get) Token: 0x060016E8 RID: 5864 RVA: 0x00119FC8 File Offset: 0x001181C8
		' (set) Token: 0x060016E9 RID: 5865 RVA: 0x00005661 File Offset: 0x00003861
		Friend Overridable Property Label10 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label10 = value
			End Set
		End Property

		' Token: 0x17000812 RID: 2066
		' (get) Token: 0x060016EA RID: 5866 RVA: 0x00119FE0 File Offset: 0x001181E0
		' (set) Token: 0x060016EB RID: 5867 RVA: 0x0000566B File Offset: 0x0000386B
		Friend Overridable Property lblbep5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblbep5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblbep5 = value
			End Set
		End Property

		' Token: 0x17000813 RID: 2067
		' (get) Token: 0x060016EC RID: 5868 RVA: 0x00119FF8 File Offset: 0x001181F8
		' (set) Token: 0x060016ED RID: 5869 RVA: 0x0011A010 File Offset: 0x00118210
		Friend Overridable Property txtbep5 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtbep5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtbep5 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtbep5.TextChanged, AddressOf Me.txtbep5_TextChanged
				End If
				Me._txtbep5 = value
				flag = Me._txtbep5 IsNot Nothing
				If flag Then
					AddHandler Me._txtbep5.TextChanged, AddressOf Me.txtbep5_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000814 RID: 2068
		' (get) Token: 0x060016EE RID: 5870 RVA: 0x0011A07C File Offset: 0x0011827C
		' (set) Token: 0x060016EF RID: 5871 RVA: 0x0011A094 File Offset: 0x00118294
		Friend Overridable Property btnDMBEP5 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMBEP5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMBEP5 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMBEP5.Click, AddressOf Me.btnDMBEP5_Click
				End If
				Me._btnDMBEP5 = value
				flag = Me._btnDMBEP5 IsNot Nothing
				If flag Then
					AddHandler Me._btnDMBEP5.Click, AddressOf Me.btnDMBEP5_Click
				End If
			End Set
		End Property

		' Token: 0x17000815 RID: 2069
		' (get) Token: 0x060016F0 RID: 5872 RVA: 0x0011A100 File Offset: 0x00118300
		' (set) Token: 0x060016F1 RID: 5873 RVA: 0x00005675 File Offset: 0x00003875
		Friend Overridable Property txtTENBEP5 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENBEP5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENBEP5 = value
			End Set
		End Property

		' Token: 0x17000816 RID: 2070
		' (get) Token: 0x060016F2 RID: 5874 RVA: 0x0011A118 File Offset: 0x00118318
		' (set) Token: 0x060016F3 RID: 5875 RVA: 0x0000567F File Offset: 0x0000387F
		Friend Overridable Property lblbep4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblbep4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblbep4 = value
			End Set
		End Property

		' Token: 0x17000817 RID: 2071
		' (get) Token: 0x060016F4 RID: 5876 RVA: 0x0011A130 File Offset: 0x00118330
		' (set) Token: 0x060016F5 RID: 5877 RVA: 0x0011A148 File Offset: 0x00118348
		Friend Overridable Property txtbep4 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtbep4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtbep4 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtbep4.TextChanged, AddressOf Me.txtbep4_TextChanged
				End If
				Me._txtbep4 = value
				flag = Me._txtbep4 IsNot Nothing
				If flag Then
					AddHandler Me._txtbep4.TextChanged, AddressOf Me.txtbep4_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000818 RID: 2072
		' (get) Token: 0x060016F6 RID: 5878 RVA: 0x0011A1B4 File Offset: 0x001183B4
		' (set) Token: 0x060016F7 RID: 5879 RVA: 0x0011A1CC File Offset: 0x001183CC
		Friend Overridable Property btnDMBEP4 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMBEP4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMBEP4 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMBEP4.Click, AddressOf Me.btnDMBEP4_Click
				End If
				Me._btnDMBEP4 = value
				flag = Me._btnDMBEP4 IsNot Nothing
				If flag Then
					AddHandler Me._btnDMBEP4.Click, AddressOf Me.btnDMBEP4_Click
				End If
			End Set
		End Property

		' Token: 0x17000819 RID: 2073
		' (get) Token: 0x060016F8 RID: 5880 RVA: 0x0011A238 File Offset: 0x00118438
		' (set) Token: 0x060016F9 RID: 5881 RVA: 0x00005689 File Offset: 0x00003889
		Friend Overridable Property txtTENBEP4 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENBEP4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENBEP4 = value
			End Set
		End Property

		' Token: 0x1700081A RID: 2074
		' (get) Token: 0x060016FA RID: 5882 RVA: 0x0011A250 File Offset: 0x00118450
		' (set) Token: 0x060016FB RID: 5883 RVA: 0x00005693 File Offset: 0x00003893
		Friend Overridable Property Label11 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label11
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label11 = value
			End Set
		End Property

		' Token: 0x1700081B RID: 2075
		' (get) Token: 0x060016FC RID: 5884 RVA: 0x0011A268 File Offset: 0x00118468
		' (set) Token: 0x060016FD RID: 5885 RVA: 0x0000569D File Offset: 0x0000389D
		Friend Overridable Property lblbep6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblbep6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblbep6 = value
			End Set
		End Property

		' Token: 0x1700081C RID: 2076
		' (get) Token: 0x060016FE RID: 5886 RVA: 0x0011A280 File Offset: 0x00118480
		' (set) Token: 0x060016FF RID: 5887 RVA: 0x0011A298 File Offset: 0x00118498
		Friend Overridable Property txtbep6 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtbep6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtbep6 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtbep6.TextChanged, AddressOf Me.txtbep6_TextChanged
				End If
				Me._txtbep6 = value
				flag = Me._txtbep6 IsNot Nothing
				If flag Then
					AddHandler Me._txtbep6.TextChanged, AddressOf Me.txtbep6_TextChanged
				End If
			End Set
		End Property

		' Token: 0x1700081D RID: 2077
		' (get) Token: 0x06001700 RID: 5888 RVA: 0x0011A304 File Offset: 0x00118504
		' (set) Token: 0x06001701 RID: 5889 RVA: 0x0011A31C File Offset: 0x0011851C
		Friend Overridable Property btnDMBEP6 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMBEP6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMBEP6 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMBEP6.Click, AddressOf Me.btnDMBEP6_Click
				End If
				Me._btnDMBEP6 = value
				flag = Me._btnDMBEP6 IsNot Nothing
				If flag Then
					AddHandler Me._btnDMBEP6.Click, AddressOf Me.btnDMBEP6_Click
				End If
			End Set
		End Property

		' Token: 0x1700081E RID: 2078
		' (get) Token: 0x06001702 RID: 5890 RVA: 0x0011A388 File Offset: 0x00118588
		' (set) Token: 0x06001703 RID: 5891 RVA: 0x000056A7 File Offset: 0x000038A7
		Friend Overridable Property txtTENBEP6 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENBEP6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENBEP6 = value
			End Set
		End Property

		' Token: 0x1700081F RID: 2079
		' (get) Token: 0x06001704 RID: 5892 RVA: 0x0011A3A0 File Offset: 0x001185A0
		' (set) Token: 0x06001705 RID: 5893 RVA: 0x0011A3B8 File Offset: 0x001185B8
		Friend Overridable Property picAnh As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picAnh
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Dim flag As Boolean = Me._picAnh IsNot Nothing
				If flag Then
					RemoveHandler Me._picAnh.MouseLeave, AddressOf Me.picAnh_MouseLeave
					RemoveHandler Me._picAnh.MouseHover, AddressOf Me.picAnh_MouseHover
					RemoveHandler Me._picAnh.Click, AddressOf Me.picAnh_Click
				End If
				Me._picAnh = value
				flag = Me._picAnh IsNot Nothing
				If flag Then
					AddHandler Me._picAnh.MouseLeave, AddressOf Me.picAnh_MouseLeave
					AddHandler Me._picAnh.MouseHover, AddressOf Me.picAnh_MouseHover
					AddHandler Me._picAnh.Click, AddressOf Me.picAnh_Click
				End If
			End Set
		End Property

		' Token: 0x17000820 RID: 2080
		' (get) Token: 0x06001706 RID: 5894 RVA: 0x0011A488 File Offset: 0x00118688
		' (set) Token: 0x06001707 RID: 5895 RVA: 0x000056B1 File Offset: 0x000038B1
		Friend Overridable Property picZoom As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picZoom
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._picZoom = value
			End Set
		End Property

		' Token: 0x17000821 RID: 2081
		' (get) Token: 0x06001708 RID: 5896 RVA: 0x0011A4A0 File Offset: 0x001186A0
		' (set) Token: 0x06001709 RID: 5897 RVA: 0x0011A4B8 File Offset: 0x001186B8
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x17000822 RID: 2082
		' (get) Token: 0x0600170A RID: 5898 RVA: 0x0011A524 File Offset: 0x00118724
		' (set) Token: 0x0600170B RID: 5899 RVA: 0x000056BB File Offset: 0x000038BB
		Friend Overridable Property Label12 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label12
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label12 = value
			End Set
		End Property

		' Token: 0x17000823 RID: 2083
		' (get) Token: 0x0600170C RID: 5900 RVA: 0x0011A53C File Offset: 0x0011873C
		' (set) Token: 0x0600170D RID: 5901 RVA: 0x000056C5 File Offset: 0x000038C5
		Friend Overridable Property chkLComboPrice As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLComboPrice
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLComboPrice = value
			End Set
		End Property

		' Token: 0x17000824 RID: 2084
		' (get) Token: 0x0600170E RID: 5902 RVA: 0x0011A554 File Offset: 0x00118754
		' (set) Token: 0x0600170F RID: 5903 RVA: 0x0011A56C File Offset: 0x0011876C
		Friend Overridable Property txtOBJID_2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID_2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID_2 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID_2.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID_2.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID_2 = value
				flag = Me._txtOBJID_2 IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID_2.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID_2.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000825 RID: 2085
		' (get) Token: 0x06001710 RID: 5904 RVA: 0x0011A608 File Offset: 0x00118808
		' (set) Token: 0x06001711 RID: 5905 RVA: 0x000056CF File Offset: 0x000038CF
		Friend Overridable Property lblOBJID_2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID_2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID_2 = value
			End Set
		End Property

		' Token: 0x17000826 RID: 2086
		' (get) Token: 0x06001712 RID: 5906 RVA: 0x0011A620 File Offset: 0x00118820
		' (set) Token: 0x06001713 RID: 5907 RVA: 0x0011A638 File Offset: 0x00118838
		Friend Overridable Property txtBuocNhayGia As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBuocNhayGia
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtBuocNhayGia IsNot Nothing
				If flag Then
					RemoveHandler Me._txtBuocNhayGia.LostFocus, AddressOf Me.txtBuocNhayGia_LostFocus
					RemoveHandler Me._txtBuocNhayGia.KeyPress, AddressOf Me.txtPRICE_KeyPress
				End If
				Me._txtBuocNhayGia = value
				flag = Me._txtBuocNhayGia IsNot Nothing
				If flag Then
					AddHandler Me._txtBuocNhayGia.LostFocus, AddressOf Me.txtBuocNhayGia_LostFocus
					AddHandler Me._txtBuocNhayGia.KeyPress, AddressOf Me.txtPRICE_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000827 RID: 2087
		' (get) Token: 0x06001714 RID: 5908 RVA: 0x0011A6D4 File Offset: 0x001188D4
		' (set) Token: 0x06001715 RID: 5909 RVA: 0x000056D9 File Offset: 0x000038D9
		Friend Overridable Property lblBuocNhayGia As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblBuocNhayGia
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblBuocNhayGia = value
			End Set
		End Property

		' Token: 0x17000828 RID: 2088
		' (get) Token: 0x06001716 RID: 5910 RVA: 0x0011A6EC File Offset: 0x001188EC
		' (set) Token: 0x06001717 RID: 5911 RVA: 0x0011A704 File Offset: 0x00118904
		Friend Overridable Property txtMADVTDG As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMADVTDG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMADVTDG IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMADVTDG.TextChanged, AddressOf Me.txtMADVTDG_TextChanged
					RemoveHandler Me._txtMADVTDG.KeyPress, AddressOf Me.txtDVTDG_KeyPress
				End If
				Me._txtMADVTDG = value
				flag = Me._txtMADVTDG IsNot Nothing
				If flag Then
					AddHandler Me._txtMADVTDG.TextChanged, AddressOf Me.txtMADVTDG_TextChanged
					AddHandler Me._txtMADVTDG.KeyPress, AddressOf Me.txtDVTDG_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000829 RID: 2089
		' (get) Token: 0x06001718 RID: 5912 RVA: 0x0011A7A0 File Offset: 0x001189A0
		' (set) Token: 0x06001719 RID: 5913 RVA: 0x000056E3 File Offset: 0x000038E3
		Friend Overridable Property txtTENDVTDG As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENDVTDG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENDVTDG = value
			End Set
		End Property

		' Token: 0x1700082A RID: 2090
		' (get) Token: 0x0600171A RID: 5914 RVA: 0x0011A7B8 File Offset: 0x001189B8
		' (set) Token: 0x0600171B RID: 5915 RVA: 0x0011A7D0 File Offset: 0x001189D0
		Friend Overridable Property btnDVTDG As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDVTDG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDVTDG IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDVTDG.Click, AddressOf Me.btnDVTDG_Click
				End If
				Me._btnDVTDG = value
				flag = Me._btnDVTDG IsNot Nothing
				If flag Then
					AddHandler Me._btnDVTDG.Click, AddressOf Me.btnDVTDG_Click
				End If
			End Set
		End Property

		' Token: 0x1700082B RID: 2091
		' (get) Token: 0x0600171C RID: 5916 RVA: 0x0011A83C File Offset: 0x00118A3C
		' (set) Token: 0x0600171D RID: 5917 RVA: 0x000056ED File Offset: 0x000038ED
		Friend Overridable Property lblDVTDG As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDVTDG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDVTDG = value
			End Set
		End Property

		' Token: 0x1700082C RID: 2092
		' (get) Token: 0x0600171E RID: 5918 RVA: 0x0011A854 File Offset: 0x00118A54
		' (set) Token: 0x0600171F RID: 5919 RVA: 0x000056F7 File Offset: 0x000038F7
		Friend Overridable Property GroupBox2 As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._GroupBox2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox2 = value
			End Set
		End Property

		' Token: 0x1700082D RID: 2093
		' (get) Token: 0x06001720 RID: 5920 RVA: 0x0011A86C File Offset: 0x00118A6C
		' (set) Token: 0x06001721 RID: 5921 RVA: 0x00005701 File Offset: 0x00003901
		Friend Overridable Property txtTiLeDVT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTiLeDVT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTiLeDVT = value
			End Set
		End Property

		' Token: 0x1700082E RID: 2094
		' (get) Token: 0x06001722 RID: 5922 RVA: 0x0011A884 File Offset: 0x00118A84
		' (set) Token: 0x06001723 RID: 5923 RVA: 0x0000570B File Offset: 0x0000390B
		Friend Overridable Property lblTiLeDVT As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTiLeDVT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTiLeDVT = value
			End Set
		End Property

		' Token: 0x1700082F RID: 2095
		' (get) Token: 0x06001724 RID: 5924 RVA: 0x0011A89C File Offset: 0x00118A9C
		' (set) Token: 0x06001725 RID: 5925 RVA: 0x00005715 File Offset: 0x00003915
		Friend Overridable Property GroupBox1 As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._GroupBox1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox1 = value
			End Set
		End Property

		' Token: 0x17000830 RID: 2096
		' (get) Token: 0x06001726 RID: 5926 RVA: 0x0011A8B4 File Offset: 0x00118AB4
		' (set) Token: 0x06001727 RID: 5927 RVA: 0x0000571F File Offset: 0x0000391F
		Friend Overridable Property Label13 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label13
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label13 = value
			End Set
		End Property

		' Token: 0x17000831 RID: 2097
		' (get) Token: 0x06001728 RID: 5928 RVA: 0x0011A8CC File Offset: 0x00118ACC
		' (set) Token: 0x06001729 RID: 5929 RVA: 0x00005729 File Offset: 0x00003929
		Friend Overridable Property txtTHOIKHOANG As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTHOIKHOANG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTHOIKHOANG = value
			End Set
		End Property

		' Token: 0x17000832 RID: 2098
		' (get) Token: 0x0600172A RID: 5930 RVA: 0x0011A8E4 File Offset: 0x00118AE4
		' (set) Token: 0x0600172B RID: 5931 RVA: 0x00005733 File Offset: 0x00003933
		Friend Overridable Property Label16 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label16
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label16 = value
			End Set
		End Property

		' Token: 0x17000833 RID: 2099
		' (get) Token: 0x0600172C RID: 5932 RVA: 0x0011A8FC File Offset: 0x00118AFC
		' (set) Token: 0x0600172D RID: 5933 RVA: 0x0000573D File Offset: 0x0000393D
		Friend Overridable Property Label14 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label14
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label14 = value
			End Set
		End Property

		' Token: 0x17000834 RID: 2100
		' (get) Token: 0x0600172E RID: 5934 RVA: 0x0011A914 File Offset: 0x00118B14
		' (set) Token: 0x0600172F RID: 5935 RVA: 0x0011A92C File Offset: 0x00118B2C
		Friend Overridable Property txtHOAHONG As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtHOAHONG
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtHOAHONG IsNot Nothing
				If flag Then
					RemoveHandler Me._txtHOAHONG.Click, AddressOf Me.txtHOAHONG_Click
				End If
				Me._txtHOAHONG = value
				flag = Me._txtHOAHONG IsNot Nothing
				If flag Then
					AddHandler Me._txtHOAHONG.Click, AddressOf Me.txtHOAHONG_Click
				End If
			End Set
		End Property

		' Token: 0x17000835 RID: 2101
		' (get) Token: 0x06001730 RID: 5936 RVA: 0x0011A998 File Offset: 0x00118B98
		' (set) Token: 0x06001731 RID: 5937 RVA: 0x00005747 File Offset: 0x00003947
		Friend Overridable Property Label15 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label15
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label15 = value
			End Set
		End Property

		' Token: 0x17000836 RID: 2102
		' (get) Token: 0x06001732 RID: 5938 RVA: 0x0011A9B0 File Offset: 0x00118BB0
		' (set) Token: 0x06001733 RID: 5939 RVA: 0x0011A9C8 File Offset: 0x00118BC8
		Friend Overridable Property txtBuocNhayMa As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtBuocNhayMa
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtBuocNhayMa IsNot Nothing
				If flag Then
					RemoveHandler Me._txtBuocNhayMa.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtBuocNhayMa.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtBuocNhayMa = value
				flag = Me._txtBuocNhayMa IsNot Nothing
				If flag Then
					AddHandler Me._txtBuocNhayMa.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtBuocNhayMa.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000837 RID: 2103
		' (get) Token: 0x06001734 RID: 5940 RVA: 0x0011AA64 File Offset: 0x00118C64
		' (set) Token: 0x06001735 RID: 5941 RVA: 0x00005751 File Offset: 0x00003951
		Friend Overridable Property lblBuocNhayMa As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblBuocNhayMa
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblBuocNhayMa = value
			End Set
		End Property

		' Token: 0x17000838 RID: 2104
		' (get) Token: 0x06001736 RID: 5942 RVA: 0x0011AA7C File Offset: 0x00118C7C
		' (set) Token: 0x06001737 RID: 5943 RVA: 0x0000575B File Offset: 0x0000395B
		Friend Overridable Property GroupBox3 As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._GroupBox3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox3 = value
			End Set
		End Property

		' Token: 0x17000839 RID: 2105
		' (get) Token: 0x06001738 RID: 5944 RVA: 0x0011AA94 File Offset: 0x00118C94
		' (set) Token: 0x06001739 RID: 5945 RVA: 0x00005765 File Offset: 0x00003965
		Friend Overridable Property Label17 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label17
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label17 = value
			End Set
		End Property

		' Token: 0x1700083A RID: 2106
		' (get) Token: 0x0600173A RID: 5946 RVA: 0x0011AAAC File Offset: 0x00118CAC
		' (set) Token: 0x0600173B RID: 5947 RVA: 0x0000576F File Offset: 0x0000396F
		Friend Overridable Property txtScore As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtScore
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtScore = value
			End Set
		End Property

		' Token: 0x1700083B RID: 2107
		' (get) Token: 0x0600173C RID: 5948 RVA: 0x0011AAC4 File Offset: 0x00118CC4
		' (set) Token: 0x0600173D RID: 5949 RVA: 0x00005779 File Offset: 0x00003979
		Friend Overridable Property panMAMT2 As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panMAMT2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panMAMT2 = value
			End Set
		End Property

		' Token: 0x1700083C RID: 2108
		' (get) Token: 0x0600173E RID: 5950 RVA: 0x0011AADC File Offset: 0x00118CDC
		' (set) Token: 0x0600173F RID: 5951 RVA: 0x0011AAF4 File Offset: 0x00118CF4
		Friend Overridable Property txtMAMT2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAMT2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAMT2 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAMT2.KeyPress, AddressOf Me.txtMAMT2_KeyPress
					RemoveHandler Me._txtMAMT2.TextChanged, AddressOf Me.txtMAMT2_TextChanged
				End If
				Me._txtMAMT2 = value
				flag = Me._txtMAMT2 IsNot Nothing
				If flag Then
					AddHandler Me._txtMAMT2.KeyPress, AddressOf Me.txtMAMT2_KeyPress
					AddHandler Me._txtMAMT2.TextChanged, AddressOf Me.txtMAMT2_TextChanged
				End If
			End Set
		End Property

		' Token: 0x1700083D RID: 2109
		' (get) Token: 0x06001740 RID: 5952 RVA: 0x0011AB90 File Offset: 0x00118D90
		' (set) Token: 0x06001741 RID: 5953 RVA: 0x00005783 File Offset: 0x00003983
		Friend Overridable Property txtTENMT2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENMT2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENMT2 = value
			End Set
		End Property

		' Token: 0x1700083E RID: 2110
		' (get) Token: 0x06001742 RID: 5954 RVA: 0x0011ABA8 File Offset: 0x00118DA8
		' (set) Token: 0x06001743 RID: 5955 RVA: 0x0011ABC0 File Offset: 0x00118DC0
		Friend Overridable Property btnDMMT2 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMMT2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMMT2 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMMT2.Click, AddressOf Me.btnDMMT2_Click
				End If
				Me._btnDMMT2 = value
				flag = Me._btnDMMT2 IsNot Nothing
				If flag Then
					AddHandler Me._btnDMMT2.Click, AddressOf Me.btnDMMT2_Click
				End If
			End Set
		End Property

		' Token: 0x1700083F RID: 2111
		' (get) Token: 0x06001744 RID: 5956 RVA: 0x0011AC2C File Offset: 0x00118E2C
		' (set) Token: 0x06001745 RID: 5957 RVA: 0x0000578D File Offset: 0x0000398D
		Friend Overridable Property Label18 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label18
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label18 = value
			End Set
		End Property

		' Token: 0x17000840 RID: 2112
		' (get) Token: 0x06001746 RID: 5958 RVA: 0x0011AC44 File Offset: 0x00118E44
		' (set) Token: 0x06001747 RID: 5959 RVA: 0x00005797 File Offset: 0x00003997
		Friend Overridable Property Label19 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label19
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label19 = value
			End Set
		End Property

		' Token: 0x17000841 RID: 2113
		' (get) Token: 0x06001748 RID: 5960 RVA: 0x0011AC5C File Offset: 0x00118E5C
		' (set) Token: 0x06001749 RID: 5961 RVA: 0x000057A1 File Offset: 0x000039A1
		Friend Overridable Property chkLQTYMain As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLQTYMain
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLQTYMain = value
			End Set
		End Property

		' Token: 0x17000842 RID: 2114
		' (get) Token: 0x0600174A RID: 5962 RVA: 0x0011AC74 File Offset: 0x00118E74
		' (set) Token: 0x0600174B RID: 5963 RVA: 0x000057AB File Offset: 0x000039AB
		Friend Overridable Property Label20 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label20
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label20 = value
			End Set
		End Property

		' Token: 0x17000843 RID: 2115
		' (get) Token: 0x0600174C RID: 5964 RVA: 0x0011AC8C File Offset: 0x00118E8C
		' (set) Token: 0x0600174D RID: 5965 RVA: 0x0011ACA4 File Offset: 0x00118EA4
		Friend Overridable Property chkLAmtOpen As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLAmtOpen
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkLAmtOpen IsNot Nothing
				If flag Then
					RemoveHandler Me._chkLAmtOpen.CheckedChanged, AddressOf Me.chkLAmtopen_CheckedChanged
				End If
				Me._chkLAmtOpen = value
				flag = Me._chkLAmtOpen IsNot Nothing
				If flag Then
					AddHandler Me._chkLAmtOpen.CheckedChanged, AddressOf Me.chkLAmtopen_CheckedChanged
				End If
			End Set
		End Property

		' Token: 0x17000844 RID: 2116
		' (get) Token: 0x0600174E RID: 5966 RVA: 0x0011AD10 File Offset: 0x00118F10
		' (set) Token: 0x0600174F RID: 5967 RVA: 0x000057B5 File Offset: 0x000039B5
		Friend Overridable Property Label21 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label21
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label21 = value
			End Set
		End Property

		' Token: 0x17000845 RID: 2117
		' (get) Token: 0x06001750 RID: 5968 RVA: 0x0011AD28 File Offset: 0x00118F28
		' (set) Token: 0x06001751 RID: 5969 RVA: 0x000057BF File Offset: 0x000039BF
		Friend Overridable Property chkLSerial As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLSerial
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLSerial = value
			End Set
		End Property

		' Token: 0x17000846 RID: 2118
		' (get) Token: 0x06001752 RID: 5970 RVA: 0x0011AD40 File Offset: 0x00118F40
		' (set) Token: 0x06001753 RID: 5971 RVA: 0x0011AD58 File Offset: 0x00118F58
		Friend Overridable Property txtTienHoaHong As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTienHoaHong
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTienHoaHong IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTienHoaHong.Click, AddressOf Me.txtTienHoaHong_Click
				End If
				Me._txtTienHoaHong = value
				flag = Me._txtTienHoaHong IsNot Nothing
				If flag Then
					AddHandler Me._txtTienHoaHong.Click, AddressOf Me.txtTienHoaHong_Click
				End If
			End Set
		End Property

		' Token: 0x17000847 RID: 2119
		' (get) Token: 0x06001754 RID: 5972 RVA: 0x0011ADC4 File Offset: 0x00118FC4
		' (set) Token: 0x06001755 RID: 5973 RVA: 0x000057C9 File Offset: 0x000039C9
		Friend Overridable Property Label22 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label22
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label22 = value
			End Set
		End Property

		' Token: 0x17000848 RID: 2120
		' (get) Token: 0x06001756 RID: 5974 RVA: 0x0011ADDC File Offset: 0x00118FDC
		' (set) Token: 0x06001757 RID: 5975 RVA: 0x000057D3 File Offset: 0x000039D3
		Friend Overridable Property chkLQtyLe As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkLQtyLe
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkLQtyLe = value
			End Set
		End Property

		' Token: 0x17000849 RID: 2121
		' (get) Token: 0x06001758 RID: 5976 RVA: 0x0011ADF4 File Offset: 0x00118FF4
		' (set) Token: 0x06001759 RID: 5977 RVA: 0x000057DD File Offset: 0x000039DD
		Public Property pstrMaHH_Copy As String
			Get
				Return Me.mstrMaHH_Copy
			End Get
			Set(value As String)
				Me.mstrMaHH_Copy = value
			End Set
		End Property

		' Token: 0x1700084A RID: 2122
		' (get) Token: 0x0600175A RID: 5978 RVA: 0x0011AE0C File Offset: 0x0011900C
		' (set) Token: 0x0600175B RID: 5979 RVA: 0x000057E8 File Offset: 0x000039E8
		Public Property pBlnModifyMulti As Boolean
			Get
				Return Me.mBlnModifyMulti
			End Get
			Set(value As Boolean)
				Me.mBlnModifyMulti = value
			End Set
		End Property

		' Token: 0x1700084B RID: 2123
		' (get) Token: 0x0600175C RID: 5980 RVA: 0x0011AE24 File Offset: 0x00119024
		' (set) Token: 0x0600175D RID: 5981 RVA: 0x000057F3 File Offset: 0x000039F3
		Public Property pBlnAutoDel As Boolean
			Get
				Return Me.mBlnAutoDel
			End Get
			Set(value As Boolean)
				Me.mBlnAutoDel = value
			End Set
		End Property

		' Token: 0x1700084C RID: 2124
		' (get) Token: 0x0600175E RID: 5982 RVA: 0x0011AE3C File Offset: 0x0011903C
		' (set) Token: 0x0600175F RID: 5983 RVA: 0x000057FE File Offset: 0x000039FE
		Public Property pstrUIMAGE As String
			Get
				Return Me.mstrUIMAGE
			End Get
			Set(value As String)
				Me.mstrUIMAGE = value
			End Set
		End Property

		' Token: 0x1700084D RID: 2125
		' (get) Token: 0x06001760 RID: 5984 RVA: 0x0011AE54 File Offset: 0x00119054
		' (set) Token: 0x06001761 RID: 5985 RVA: 0x00005809 File Offset: 0x00003A09
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x1700084E RID: 2126
		' (get) Token: 0x06001762 RID: 5986 RVA: 0x0011AE6C File Offset: 0x0011906C
		' (set) Token: 0x06001763 RID: 5987 RVA: 0x00005814 File Offset: 0x00003A14
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x1700084F RID: 2127
		' (get) Token: 0x06001764 RID: 5988 RVA: 0x0011AE84 File Offset: 0x00119084
		' (set) Token: 0x06001765 RID: 5989 RVA: 0x0000581F File Offset: 0x00003A1F
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06001766 RID: 5990 RVA: 0x0011AE9C File Offset: 0x0011909C
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtSUBOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001767 RID: 5991 RVA: 0x0011AF40 File Offset: 0x00119140
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.txtSUBOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001768 RID: 5992 RVA: 0x0011AFEC File Offset: 0x001191EC
		Private Sub txtOBJSUBNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtSUBOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.txtMADVT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001769 RID: 5993 RVA: 0x0011B098 File Offset: 0x00119298
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600176A RID: 5994 RVA: 0x0011B144 File Offset: 0x00119344
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				Else
					Me.fGetData_SDBDKHO(Me.txtMAKH.Text.Trim(), Me.txtOBJID.Text.Trim(), Me.txtMADVT.Text.Trim())
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600176B RID: 5995 RVA: 0x0011B228 File Offset: 0x00119428
		Private Sub txtSUBOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMADVT.Focus()
				End If
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x0600176C RID: 5996 RVA: 0x0011B27C File Offset: 0x0011947C
		Private Sub txtDVT_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMADVT.[ReadOnly]
				If [readOnly] Then
					Me.txtMADV.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtDVT_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600176D RID: 5997 RVA: 0x0011B328 File Offset: 0x00119528
		Private Sub txtDVT_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMADVTDG.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtDVT_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600176E RID: 5998 RVA: 0x0011B3CC File Offset: 0x001195CC
		Private Sub txtDVTDG_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMADV.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtDVTDG_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600176F RID: 5999 RVA: 0x0011B470 File Offset: 0x00119670
		Private Sub txtMANH_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMANH.[ReadOnly]
				If [readOnly] Then
					Me.txtMAMT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMANH_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001770 RID: 6000 RVA: 0x0011B51C File Offset: 0x0011971C
		Private Sub txtMANH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMAMT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMANH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001771 RID: 6001 RVA: 0x0011B5C0 File Offset: 0x001197C0
		Private Sub txtMAMT_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMAMT.[ReadOnly]
				If [readOnly] Then
					Me.chkLSAVE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMT_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001772 RID: 6002 RVA: 0x0011B66C File Offset: 0x0011986C
		Private Sub txtMAMT_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMAMT2.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMT_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001773 RID: 6003 RVA: 0x0011B710 File Offset: 0x00119910
		Private Sub txtMAMT2_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMAPL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMT2_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001774 RID: 6004 RVA: 0x0011B7B4 File Offset: 0x001199B4
		Private Sub chkLSAVE_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtREMARK.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkLSAVE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001775 RID: 6005 RVA: 0x0011B858 File Offset: 0x00119A58
		Private Sub txtREMARK_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtREMARK.[ReadOnly]
				If [readOnly] Then
					Dim flag As Boolean = Me.mbytFormStatus = 5
					If flag Then
						Me.btnFilter.Focus()
					Else
						flag = Me.mbytFormStatus = 6
						If flag Then
							Me.btnFind.Focus()
						Else
							Me.btnSave.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtREMARK_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001776 RID: 6006 RVA: 0x0011B940 File Offset: 0x00119B40
		Private Sub txtREMARK_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim flag2 As Boolean = Me.mbytFormStatus = 5
					If flag2 Then
						Me.btnFilter.Focus()
					Else
						flag2 = Me.mbytFormStatus = 6
						If flag2 Then
							Me.btnFind.Focus()
						Else
							Me.btnSave.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtREMARK_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001777 RID: 6007 RVA: 0x0011BA1C File Offset: 0x00119C1C
		Private Sub frmDMHH2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
				Me.txtMAMT_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtMADVT_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtMADVTDG_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtMADV_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Dim checked As Boolean = Me.chkLSAVE.Checked
				Me.txtMANH_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.chkLSAVE.Checked = checked
				Me.txtMAPL_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtMANSX_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtMAKH_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtbep1_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtbep2_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtbep3_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtbep4_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtbep5_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtbep6_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHH2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001778 RID: 6008 RVA: 0x0011BBC0 File Offset: 0x00119DC0
		Private Sub frmDMHH2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMMT()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMNH()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMPL()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMNSX()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMDVT()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMDV()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMBEP()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMKH()
				End If
				Me.sGetPara_From_SetparaXML()
				Dim flag2 As Boolean = False
				Me.panLMATERIAL.Visible = flag2
				Select Case Me.mbytNUMPRICE
					Case 1
						Me.s_SetVisibleShowHide(Me.f_ShowHideField(""))
					Case 2
						Me.s_SetVisibleShowHide(Me.f_ShowHideField("0,3"))
					Case 3
						Me.s_SetVisibleShowHide(Me.f_ShowHideField("0,3,4"))
					Case 4
						Me.s_SetVisibleShowHide(Me.f_ShowHideField("0,3,4,5"))
					Case 5
						Me.s_SetVisibleShowHide(Me.f_ShowHideField("0,1,3,4,5,6"))
					Case 6
						Me.s_SetVisibleShowHide(Me.f_ShowHideField("0,1,3,4,5,6,7"))
					Case 7
						Me.s_SetVisibleShowHide(Me.f_ShowHideField("0,1,3,4,5,6,7,8"))
					Case 8
						Me.s_SetVisibleShowHide(Me.f_ShowHideField("0,1,2,3,4,5,6,7,8,9"))
					Case 9
						Me.s_SetVisibleShowHide(Me.f_ShowHideField("0,1,2,3,4,5,6,7,8,9,10"))
					Case 10
						Me.s_SetVisibleShowHide(Me.f_ShowHideField("0,1,2,3,4,5,6,7,8,9,10,11"))
				End Select
				flag = Operators.CompareString(mdlVariable.gStrStockCode, "", False) <> 0
				If flag Then
					Me.txtMAKH.Text = mdlVariable.gStrStockCode
					Me.txtMAKH.[ReadOnly] = True
					Me.txtMAKH.BackColor = Me.txtTENKH.BackColor
					Me.btnDMKH.Enabled = False
				End If
				flag = Not mdlVariable.gblnSTOCKDATE
				If flag Then
					Me.lblOUTDATE.Visible = False
					Me.mtbOutDate.Visible = False
				End If
				flag = Me.mBlnAutoDel
				If flag Then
					Me.btnDelete_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHH2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001779 RID: 6009 RVA: 0x0011BF08 File Offset: 0x0011A108
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean = Me.mBlnModifyMulti
				If Not flag Then
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
						Return
					End If
					flag = Me.mblnFIXMAHH AndAlso Me.txtOBJID.Text.Trim().Length <> CInt(Me.mbytLen_OBJID)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(75) + " " + Me.mbytLen_OBJID.ToString(), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
						Return
					End If
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
						Return
					End If
					flag = Operators.CompareString(Strings.Trim(Me.txtMADVT.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(56), MsgBoxStyle.Critical, Nothing)
						Me.txtMADVT.Focus()
						Return
					End If
					flag = Operators.CompareString(Strings.Trim(Me.txtMANH.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(36), MsgBoxStyle.Critical, Nothing)
						Me.txtMANH.Focus()
						Return
					End If
				End If
				flag = (Operators.CompareString(Strings.Trim(Me.txtMADVT.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENDVT.Text), "", False) = 0)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(61), MsgBoxStyle.Critical, Nothing)
					Me.txtMADVT.Focus()
				Else
					flag = (Operators.CompareString(Strings.Trim(Me.txtMADVTDG.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENDVTDG.Text), "", False) = 0)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(61), MsgBoxStyle.Critical, Nothing)
						Me.txtMADVTDG.Focus()
					Else
						flag = (Operators.CompareString(Strings.Trim(Me.txtMANH.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENNH.Text), "", False) = 0)
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(37), MsgBoxStyle.Critical, Nothing)
							Me.txtMANH.Focus()
						Else
							flag = (Operators.CompareString(Strings.Trim(Me.txtMAMT.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENMT.Text), "", False) = 0)
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(12), MsgBoxStyle.Critical, Nothing)
								Me.txtMAMT.Focus()
							Else
								flag = (Operators.CompareString(Strings.Trim(Me.txtMAMT2.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENMT2.Text), "", False) = 0)
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(12), MsgBoxStyle.Critical, Nothing)
									Me.txtMAMT2.Focus()
								Else
									flag = (Operators.CompareString(Strings.Trim(Me.txtMAPL.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENPL.Text), "", False) = 0)
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(54), MsgBoxStyle.Critical, Nothing)
										Me.txtMAPL.Focus()
									Else
										flag = (Operators.CompareString(Strings.Trim(Me.txtMANSX.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENNSX.Text), "", False) = 0)
										If flag Then
											Interaction.MsgBox(Me.mArrStrFrmMess(55), MsgBoxStyle.Critical, Nothing)
											Me.txtMANSX.Focus()
										Else
											flag = (Operators.CompareString(Strings.Trim(Me.txtMADC.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENDC.Text), "", False) = 0)
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(63), MsgBoxStyle.Critical, Nothing)
												Me.txtMADC.Focus()
											Else
												flag = (Operators.CompareString(Strings.Trim(Me.txtbep1.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENBEP1.Text), "", False) = 0)
												If flag Then
													Interaction.MsgBox(Me.mArrStrFrmMess(69), MsgBoxStyle.Critical, Nothing)
													Me.txtbep1.Focus()
												Else
													flag = (Operators.CompareString(Strings.Trim(Me.txtbep1.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENBEP1.Text), "", False) = 0)
													If flag Then
														Interaction.MsgBox(Me.mArrStrFrmMess(69), MsgBoxStyle.Critical, Nothing)
														Me.txtbep1.Focus()
													Else
														flag = (Operators.CompareString(Strings.Trim(Me.txtbep2.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENBEP2.Text), "", False) = 0)
														If flag Then
															Interaction.MsgBox(Me.mArrStrFrmMess(70), MsgBoxStyle.Critical, Nothing)
															Me.txtbep2.Focus()
														Else
															flag = (Operators.CompareString(Strings.Trim(Me.txtbep3.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENBEP3.Text), "", False) = 0)
															If flag Then
																Interaction.MsgBox(Me.mArrStrFrmMess(71), MsgBoxStyle.Critical, Nothing)
																Me.txtbep3.Focus()
															Else
																flag = (Operators.CompareString(Strings.Trim(Me.txtbep4.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENBEP4.Text), "", False) = 0)
																If flag Then
																	Interaction.MsgBox(Me.mArrStrFrmMess(93), MsgBoxStyle.Critical, Nothing)
																	Me.txtbep4.Focus()
																Else
																	flag = (Operators.CompareString(Strings.Trim(Me.txtbep5.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENBEP5.Text), "", False) = 0)
																	If flag Then
																		Interaction.MsgBox(Me.mArrStrFrmMess(94), MsgBoxStyle.Critical, Nothing)
																		Me.txtbep5.Focus()
																	Else
																		flag = (Operators.CompareString(Strings.Trim(Me.txtbep6.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTENBEP6.Text), "", False) = 0)
																		If flag Then
																			Interaction.MsgBox(Me.mArrStrFrmMess(95), MsgBoxStyle.Critical, Nothing)
																			Me.txtbep6.Focus()
																		Else
																			flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
																			Dim flag3 As Boolean
																			If flag Then
																				Dim flag2 As Boolean = Me.txtOBJID_2.Visible
																				If flag2 Then
																					flag3 = Not Versioned.IsNumeric(Me.txtOBJID.Text.Trim()) OrElse Not Versioned.IsNumeric(Me.txtOBJID_2.Text.Trim())
																					If flag3 Then
																						Interaction.MsgBox(Me.mArrStrFrmMess(99), MsgBoxStyle.Critical, Nothing)
																						Me.txtOBJID.Focus()
																						Return
																					End If
																					Dim num As Double = Conversion.Val(Me.txtOBJID.Text.Trim())
																					Dim num2 As Double = Conversion.Val(Me.txtOBJID_2.Text.Trim())
																					flag3 = num > num2
																					If flag3 Then
																						Interaction.MsgBox(Me.mArrStrFrmMess(100), MsgBoxStyle.Critical, Nothing)
																						Me.txtOBJID_2.Focus()
																						Return
																					End If
																					flag3 = Me.txtOBJID.Text.Trim().Length <> Me.txtOBJID_2.Text.Trim().Length
																					If flag3 Then
																						Interaction.MsgBox(Me.mArrStrFrmMess(101), MsgBoxStyle.Critical, Nothing)
																						Me.txtOBJID_2.Focus()
																						Return
																					End If
																					Dim length As Integer = Me.txtOBJID.Text.Trim().Length
																					Dim num3 As Double = Conversion.Val("0" + Me.txtBuocNhayGia.Text.Trim().Replace(",", ""))
																					Dim num4 As Double = Conversion.Val("0" + Me.txtBuocNhayMa.Text.Trim().Replace(",", ""))
																					flag3 = num4 <= 0.0
																					If flag3 Then
																						num4 = 1.0
																					End If
																					Dim flag4 As Boolean = False
																					Dim num5 As Double = num
																					Dim num6 As Double = num2
																					Dim num7 As Double = num4
																					Dim num8 As Double = num6
																					Dim num9 As Double = num5
																					While ObjectFlowControl.ForLoopControl.ForNextCheckR8(num9, num8, num7)
																						Me.txtOBJID.Text = num9.ToString(Strings.StrDup(length, "0"))
																						flag3 = flag4
																						If flag3 Then
																							' The following expression was wrapped in a unchecked-expression
																							Me.txtPRICE.Text = Conversions.ToString(Conversion.Val(Me.txtPRICE.Text.Replace(",", "")) + num3)
																						Else
																							flag4 = True
																						End If
																						Me.mbytSuccess = Me.gfAddNew(0)
																						flag3 = Me.mbytSuccess = 1
																						If flag3 Then
																							flag2 = Me.mArrStrSelectCombo IsNot Nothing
																							If flag2 Then
																								Dim num10 As Integer = 0
																								Dim num11 As Integer = Me.mArrStrSelectCombo.Length - 1
																								Dim num12 As Integer = num10
																								While True
																									Dim num13 As Integer = num12
																									Dim num14 As Integer = num11
																									If num13 > num14 Then
																										Exit For
																									End If
																									Me.fAdd_Combo(Me.txtOBJID.Text, Me.mArrStrSelectCombo(num12).strMAHH, Me.mArrStrSelectCombo(num12).dblQTY, Me.mArrStrSelectCombo(num12).blnAutoAdd, Me.mArrStrSelectCombo(num12).blnPrice, num12 = 0)
																									num12 += 1
																								End While
																							End If
																							Me.fAdd_SDBDKHO()
																						End If
																						flag3 = Me.mbytSuccess <> 1
																						If flag3 Then
																							Exit While
																						End If

																							num9 += num7

																					End While
																					Me.Close()
																				Else
																					Me.mbytSuccess = Me.gfAddNew(0)
																					flag3 = Me.mbytSuccess = 1
																					If flag3 Then
																						flag2 = Me.mArrStrSelectCombo IsNot Nothing
																						If flag2 Then
																							Dim num15 As Integer = 0
																							Dim num16 As Integer = Me.mArrStrSelectCombo.Length - 1
																							Dim num17 As Integer = num15
																							While True
																								Dim num18 As Integer = num17
																								Dim num14 As Integer = num16
																								If num18 > num14 Then
																									Exit For
																								End If
																								Me.fAdd_Combo(Me.txtOBJID.Text, Me.mArrStrSelectCombo(num17).strMAHH, Me.mArrStrSelectCombo(num17).dblQTY, Me.mArrStrSelectCombo(num17).blnAutoAdd, Me.mArrStrSelectCombo(num17).blnPrice, num17 = 0)
																								num17 += 1
																							End While
																						End If
																					End If
																				End If
																			Else
																				flag3 = Me.mbytFormStatus = 3
																				If flag3 Then
																					Dim flag2 As Boolean = Me.mBlnModifyMulti
																					If flag2 Then
																						Me.mbytSuccess = Me.fModifyMulti()
																						flag3 = Me.mbytSuccess = 1
																						If flag3 Then
																							flag2 = Me.mArrStrSelectCombo IsNot Nothing
																							If flag2 Then
																								Dim array As String() = Me.txtOBJID.Text.Trim().Split(New Char() { ";"c })
																								Dim num19 As Integer = 0
																								Dim num20 As Integer = array.Length - 1
																								Dim num21 As Integer = num19
																								While True
																									Dim num22 As Integer = num21
																									Dim num14 As Integer = num20
																									If num22 > num14 Then
																										Exit For
																									End If
																									Dim num23 As Integer = 0
																									Dim num24 As Integer = Me.mArrStrSelectCombo.Length - 1
																									Dim num25 As Integer = num23
																									While True
																										Dim num26 As Integer = num25
																										num14 = num24
																										If num26 > num14 Then
																											Exit For
																										End If
																										Me.fAdd_Combo(array(num21).Trim(), Me.mArrStrSelectCombo(num25).strMAHH, Me.mArrStrSelectCombo(num25).dblQTY, Me.mArrStrSelectCombo(num25).blnAutoAdd, Me.mArrStrSelectCombo(num25).blnPrice, num25 = 0)
																										num25 += 1
																									End While
																									num21 += 1
																								End While
																							End If
																						End If
																					Else
																						Me.mbytSuccess = Me.fModify()
																						flag3 = Me.mbytSuccess = 1
																						If flag3 Then
																							flag2 = Me.mArrStrSelectCombo IsNot Nothing
																							If flag2 Then
																								Dim num27 As Integer = 0
																								Dim num28 As Integer = Me.mArrStrSelectCombo.Length - 1
																								Dim num29 As Integer = num27
																								While True
																									Dim num30 As Integer = num29
																									Dim num14 As Integer = num28
																									If num30 > num14 Then
																										Exit For
																									End If
																									Me.fAdd_Combo(Me.txtOBJID.Text, Me.mArrStrSelectCombo(num29).strMAHH, Me.mArrStrSelectCombo(num29).dblQTY, Me.mArrStrSelectCombo(num29).blnAutoAdd, Me.mArrStrSelectCombo(num29).blnPrice, num29 = 0)
																									num29 += 1
																								End While
																							End If
																						End If
																					End If
																				End If
																			End If
																			flag3 = Me.mbytSuccess = 1
																			If flag3 Then
																				Me.fAdd_SDBDKHO()
																			End If
																			flag3 = Me.mbytSuccess = 1
																			If flag3 Then
																				Me.Close()
																			End If
																		End If
																	End If
																End If
															End If
														End If
													End If
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600177A RID: 6010 RVA: 0x0011CDB0 File Offset: 0x0011AFB0
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.fDelete_SDBDKHO()
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600177B RID: 6011 RVA: 0x0011CE5C File Offset: 0x0011B05C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMADVT.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MADVT like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAMT.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMT ='"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMADV.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MADV ='"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMANH.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MANH ='"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtREMARK.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtbep1.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMAYINBEP1 ='"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtbep2.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMAYINBEP2 ='"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtbep3.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMAYINBEP3 ='"), text2), "%'"))
				End If
				flag = Me.chkLSAVE.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSAVE ="), Interaction.IIf(Me.chkLSAVE.Checked, 1, 0)), ""))
				End If
				flag = Me.chkLopen.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LOPEN ="), Interaction.IIf(Me.chkLopen.Checked, 1, 0)), ""))
				End If
				flag = Me.chkLMATERIAL.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LHIDEN ="), Interaction.IIf(Me.chkLMATERIAL.Checked, 1, 0)), ""))
				End If
				flag = Me.chkStopUse.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSTOPUSE ="), Interaction.IIf(Me.chkStopUse.Checked, 1, 0)), ""))
				End If
				flag = Me.chkCOMBO.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LCOMBO ="), Interaction.IIf(Me.chkCOMBO.Checked, 1, 0)), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600177C RID: 6012 RVA: 0x0011D7B4 File Offset: 0x0011B9B4
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMADVT.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MADVT like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAMT.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMT ='"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMADV.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MADV ='"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMANH.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MANH ='"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtREMARK.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtbep1.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMAYINBEP1 ='"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtbep2.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMAYINBEP2 ='"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtbep3.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAMAYINBEP3 ='"), text2), "%'"))
				End If
				flag = Me.chkLSAVE.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSAVE ="), Interaction.IIf(Me.chkLSAVE.Checked, 1, 0)), ""))
				End If
				flag = Me.chkLopen.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LOPEN ="), Interaction.IIf(Me.chkLopen.Checked, 1, 0)), ""))
				End If
				flag = Me.chkLMATERIAL.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LHIDEN ="), Interaction.IIf(Me.chkLMATERIAL.Checked, 1, 0)), ""))
				End If
				flag = Me.chkStopUse.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LSTOPUSE ="), Interaction.IIf(Me.chkStopUse.Checked, 1, 0)), ""))
				End If
				flag = Me.chkCOMBO.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LCOMBO ="), Interaction.IIf(Me.chkCOMBO.Checked, 1, 0)), ""))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600177D RID: 6013 RVA: 0x0011E10C File Offset: 0x0011C30C
		Private Sub btnDMMT_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMT As frmDMMT1 = New frmDMMT1()
				frmDMMT.pBytOpen_From_Menu = 7
				frmDMMT.ShowDialog()
				Me.txtMAMT.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMT.pStrOBJID, "", False) = 0, Me.txtMAMT.Text, frmDMMT.pStrOBJID))
				Me.txtTENMT.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMT.pStrOBJID, "", False) = 0, Me.txtTENMT.Text, frmDMMT.pStrOBJNAME))
				frmDMMT.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMMT_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600177E RID: 6014 RVA: 0x0011E230 File Offset: 0x0011C430
		Private Sub btnDMMT2_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMT As frmDMMT1 = New frmDMMT1()
				frmDMMT.pBytOpen_From_Menu = 7
				frmDMMT.ShowDialog()
				Me.txtMAMT2.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMT.pStrOBJID, "", False) = 0, Me.txtMAMT2.Text, frmDMMT.pStrOBJID))
				Me.txtTENMT2.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMT.pStrOBJID, "", False) = 0, Me.txtTENMT2.Text, frmDMMT.pStrOBJNAME))
				frmDMMT.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMMT2_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600177F RID: 6015 RVA: 0x0011E354 File Offset: 0x0011C554
		Private Sub btnDMNH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMNH As frmDMNH1 = New frmDMNH1()
				frmDMNH.pBytOpen_From_Menu = 7
				frmDMNH.ShowDialog()
				Dim pBlnOK As Boolean = frmDMNH.pBlnOK
				If pBlnOK Then
					Me.txtMANH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNH.pStrOBJID, "", False) = 0, Me.txtMANH.Text, frmDMNH.pStrOBJID))
					Me.txtTENNH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNH.pStrOBJID, "", False) = 0, Me.txtTENNH.Text, frmDMNH.pStrOBJNAME))
					Me.txtMAMT.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNH.pStrOBJID, "", False) = 0, Me.txtMAMT.Text, frmDMNH.pStrMAMT))
					Me.chkLSAVE.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(frmDMNH.pStrOBJID, "", False) = 0, Me.chkLSAVE.Checked, frmDMNH.pBlnLSAVE))
				End If
				frmDMNH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMNH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001780 RID: 6016 RVA: 0x0011E520 File Offset: 0x0011C720
		Private Sub txtMANH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMNH Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMNH.Columns("OBJID")
					Me.mclsTbDMNH.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMNH.Rows.Find(Strings.Trim(Me.txtMANH.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENNH.Text = dataRow("OBJNAME").ToString() + "  " + dataRow("SUBOBJNAME").ToString().Trim()
						flag = Me.txtMAMT.Text.Trim().Length = 0
						If flag Then
							Me.txtMAMT.Text = dataRow("MAMT").ToString()
						End If
						Me.chkLSAVE.Checked = Conversions.ToBoolean(dataRow("LSAVE"))
					Else
						Me.txtTENNH.Text = ""
					End If
					Me.mblnFistLoad = False
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMANH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001781 RID: 6017 RVA: 0x0011E6F4 File Offset: 0x0011C8F4
		Private Sub txtMAMT_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMMT Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMMT.Columns("OBJID")
					Me.mclsTbDMMT.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMMT.Rows.Find(Strings.Trim(Me.txtMAMT.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENMT.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENMT.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMT_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001782 RID: 6018 RVA: 0x0011E848 File Offset: 0x0011CA48
		Private Sub txtMAMT2_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMMT Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMMT.Columns("OBJID")
					Me.mclsTbDMMT.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMMT.Rows.Find(Strings.Trim(Me.txtMAMT2.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENMT2.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENMT2.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAMT2_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001783 RID: 6019 RVA: 0x0011E99C File Offset: 0x0011CB9C
		Private Sub txtMAPL_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMANSX.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMANSX_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001784 RID: 6020 RVA: 0x0011EA40 File Offset: 0x0011CC40
		Private Sub txtMAPL_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMPL Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMPL.Columns("OBJID")
					Me.mclsTbDMPL.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMPL.Rows.Find(Strings.Trim(Me.txtMAPL.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENPL.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENPL.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAPL_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001785 RID: 6021 RVA: 0x0011EB94 File Offset: 0x0011CD94
		Private Sub txtMANSX_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtPRICE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADC_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001786 RID: 6022 RVA: 0x0011EC38 File Offset: 0x0011CE38
		Private Sub txtMADC_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtPRICE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMANH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001787 RID: 6023 RVA: 0x0011ECDC File Offset: 0x0011CEDC
		Private Sub txtMANSX_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMNSX Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMNSX.Columns("OBJID")
					Me.mclsTbDMNSX.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMNSX.Rows.Find(Strings.Trim(Me.txtMANSX.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENNSX.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENNSX.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMANSX_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001788 RID: 6024 RVA: 0x0011EE30 File Offset: 0x0011D030
		Private Sub txtMAKH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKH Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMKH.Columns("OBJID")
					Me.mclsTbDMKH.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKH.Rows.Find(Strings.Trim(Me.txtMAKH.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENKH.Text = dataRow("OBJNAME").ToString() + "  " + dataRow("SUBOBJNAME").ToString().Trim()
						Me.fGetData_SDBDKHO(Me.txtMAKH.Text.Trim(), Me.txtOBJID.Text.Trim(), Me.txtMADVT.Text.Trim())
					Else
						Me.txtTENKH.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001789 RID: 6025 RVA: 0x0011EFD8 File Offset: 0x0011D1D8
		Private Sub btnDVT_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDVT As frmDMDVT1 = New frmDMDVT1()
				frmDMDVT.pBytOpen_From_Menu = 7
				frmDMDVT.ShowDialog()
				Me.txtMADVT.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDVT.pStrOBJID, "", False) = 0, Me.txtMADVT.Text, frmDMDVT.pStrOBJID))
				Me.txtTENDVT.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDVT.pStrOBJID, "", False) = 0, Me.txtTENDVT.Text, frmDMDVT.pStrOBJNAME))
				Me.sHienThiTieuDeTiLeDVT()
				frmDMDVT.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMNH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600178A RID: 6026 RVA: 0x0011F104 File Offset: 0x0011D304
		Private Sub btnCOMBO_Click(sender As Object, e As EventArgs)
			Try
				Dim frmSelectHH As frmSelectHH = New frmSelectHH()
				frmSelectHH.pStrDMMA = Me.txtOBJID.Text.Trim()
				frmSelectHH.ShowDialog()
				Dim flag As Boolean = frmSelectHH.pBytSuccess = 1
				If flag Then
					Me.txtCOMBO.Text = frmSelectHH.pStrDMMA
					Me.mArrStrSelectCombo = frmSelectHH.pArrStrSelectCombo
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnCOMBO_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600178B RID: 6027 RVA: 0x0011F1E8 File Offset: 0x0011D3E8
		Private Sub btnMAPL_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMPL As frmDMPL1 = New frmDMPL1()
				frmDMPL.pBytOpen_From_Menu = 7
				frmDMPL.ShowDialog()
				Me.txtMAPL.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMPL.pStrOBJID, "", False) = 0, Me.txtMAPL.Text, frmDMPL.pStrOBJID))
				Me.txtTENPL.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMPL.pStrOBJID, "", False) = 0, Me.txtTENPL.Text, frmDMPL.pStrOBJNAME))
				frmDMPL.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMNH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600178C RID: 6028 RVA: 0x0011F30C File Offset: 0x0011D50C
		Private Sub btnMANSX_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMNSX As frmDMNSX1 = New frmDMNSX1()
				frmDMNSX.pBytOpen_From_Menu = 7
				frmDMNSX.ShowDialog()
				Me.txtMANSX.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNSX.pStrOBJID, "", False) = 0, Me.txtMANSX.Text, frmDMNSX.pStrOBJID))
				Me.txtTENNSX.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNSX.pStrOBJID, "", False) = 0, Me.txtTENNSX.Text, frmDMNSX.pStrOBJNAME))
				frmDMNSX.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMNH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600178D RID: 6029 RVA: 0x0011F430 File Offset: 0x0011D630
		Private Sub txtPRICE_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtPRICE2.Visible
					If visible Then
						Me.txtPRICE2.Focus()
					Else
						Me.chkLSAVE.Focus()
					End If
				End If
				Me.gf_AcceptOnlyNumber(Me.txtPRICE, e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtPRICE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600178E RID: 6030 RVA: 0x0011F500 File Offset: 0x0011D700
		Private Sub txtPURSE_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Me.gf_AcceptOnlyNumber(Me.txtPURSE, e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtPURSE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600178F RID: 6031 RVA: 0x0011F594 File Offset: 0x0011D794
		Private Sub txtPRICE2_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtPRICE3.Visible
					If visible Then
						Me.txtPRICE3.Focus()
					Else
						Me.chkLSAVE.Focus()
					End If
				End If
				Me.gf_AcceptOnlyNumber(Me.txtPRICE2, e)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001790 RID: 6032 RVA: 0x0011F614 File Offset: 0x0011D814
		Private Sub txtPRICE3_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtPRICE4.Visible
					If visible Then
						Me.txtPRICE4.Focus()
					Else
						Me.chkLSAVE.Focus()
					End If
				End If
				Me.gf_AcceptOnlyNumber(Me.txtPRICE3, e)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001791 RID: 6033 RVA: 0x0011F694 File Offset: 0x0011D894
		Private Sub txtPRICE4_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtPRICE5.Visible
					If visible Then
						Me.txtPRICE5.Focus()
					Else
						Me.chkLSAVE.Focus()
					End If
				End If
				Me.gf_AcceptOnlyNumber(Me.txtPRICE4, e)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001792 RID: 6034 RVA: 0x0011F714 File Offset: 0x0011D914
		Private Sub txtPRICE5_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtPRICE6.Visible
					If visible Then
						Me.txtPRICE6.Focus()
					Else
						Me.chkLSAVE.Focus()
					End If
				End If
				Me.gf_AcceptOnlyNumber(Me.txtPRICE5, e)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001793 RID: 6035 RVA: 0x0011F794 File Offset: 0x0011D994
		Private Sub txtPRICE6_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtPRICE7.Visible
					If visible Then
						Me.txtPRICE7.Focus()
					Else
						Me.chkLSAVE.Focus()
					End If
				End If
				Me.gf_AcceptOnlyNumber(Me.txtPRICE6, e)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001794 RID: 6036 RVA: 0x0011F814 File Offset: 0x0011DA14
		Private Sub txtPRICE7_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtPRICE8.Visible
					If visible Then
						Me.txtPRICE8.Focus()
					Else
						Me.chkLSAVE.Focus()
					End If
				End If
				Me.gf_AcceptOnlyNumber(Me.txtPRICE7, e)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001795 RID: 6037 RVA: 0x0011F894 File Offset: 0x0011DA94
		Private Sub txtPRICE8_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtPRICE9.Visible
					If visible Then
						Me.txtPRICE9.Focus()
					Else
						Me.chkLSAVE.Focus()
					End If
				End If
				Me.gf_AcceptOnlyNumber(Me.txtPRICE8, e)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001796 RID: 6038 RVA: 0x0011F914 File Offset: 0x0011DB14
		Private Sub txtPRICE9_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtPRICE10.Visible
					If visible Then
						Me.txtPRICE10.Focus()
					Else
						Me.chkLSAVE.Focus()
					End If
				End If
				Me.gf_AcceptOnlyNumber(Me.txtPRICE9, e)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001797 RID: 6039 RVA: 0x0011F994 File Offset: 0x0011DB94
		Private Sub txtPRICE10_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkLSAVE.Focus()
				End If
				Me.gf_AcceptOnlyNumber(Me.txtPRICE10, e)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001798 RID: 6040 RVA: 0x0011F9F4 File Offset: 0x0011DBF4
		Private Sub txtPRICE_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPRICE.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPRICE.Text = mdlUIForm.gfFomular_2_Num(Me.txtPRICE.Text).ToString()
				End If
				Me.txtPRICE.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPRICE.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x06001799 RID: 6041 RVA: 0x0011FAA0 File Offset: 0x0011DCA0
		Private Sub txtBuocNhayGia_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtBuocNhayGia.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtBuocNhayGia.Text = mdlUIForm.gfFomular_2_Num(Me.txtBuocNhayGia.Text).ToString()
				End If
				Me.txtBuocNhayGia.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtBuocNhayGia.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x0600179A RID: 6042 RVA: 0x0011FB4C File Offset: 0x0011DD4C
		Private Sub txtPURSE_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPURSE.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPURSE.Text = mdlUIForm.gfFomular_2_Num(Me.txtPURSE.Text).ToString()
				End If
				Me.txtPURSE.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPURSE.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x0600179B RID: 6043 RVA: 0x0011FBF8 File Offset: 0x0011DDF8
		Private Sub txtPRICE2_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPRICE2.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPRICE2.Text = mdlUIForm.gfFomular_2_Num(Me.txtPRICE2.Text).ToString()
				End If
				Me.txtPRICE2.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPRICE2.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x0600179C RID: 6044 RVA: 0x0011FCA4 File Offset: 0x0011DEA4
		Private Sub txtPRICE3_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPRICE3.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPRICE3.Text = mdlUIForm.gfFomular_2_Num(Me.txtPRICE3.Text).ToString()
				End If
				Me.txtPRICE3.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPRICE3.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x0600179D RID: 6045 RVA: 0x0011FD50 File Offset: 0x0011DF50
		Private Sub txtPRICE4_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPRICE4.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPRICE4.Text = mdlUIForm.gfFomular_2_Num(Me.txtPRICE4.Text).ToString()
				End If
				Me.txtPRICE4.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPRICE4.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x0600179E RID: 6046 RVA: 0x0011FDFC File Offset: 0x0011DFFC
		Private Sub txtPRICE5_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPRICE5.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPRICE5.Text = mdlUIForm.gfFomular_2_Num(Me.txtPRICE5.Text).ToString()
				End If
				Me.txtPRICE5.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPRICE5.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x0600179F RID: 6047 RVA: 0x0011FEA8 File Offset: 0x0011E0A8
		Private Sub txtPRICE6_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPRICE6.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPRICE6.Text = mdlUIForm.gfFomular_2_Num(Me.txtPRICE6.Text).ToString()
				End If
				Me.txtPRICE6.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPRICE6.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060017A0 RID: 6048 RVA: 0x0011FF54 File Offset: 0x0011E154
		Private Sub txtPRICE7_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPRICE7.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPRICE7.Text = mdlUIForm.gfFomular_2_Num(Me.txtPRICE7.Text).ToString()
				End If
				Me.txtPRICE7.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPRICE7.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060017A1 RID: 6049 RVA: 0x00120000 File Offset: 0x0011E200
		Private Sub txtPRICE8_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPRICE8.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPRICE8.Text = mdlUIForm.gfFomular_2_Num(Me.txtPRICE8.Text).ToString()
				End If
				Me.txtPRICE8.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPRICE8.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060017A2 RID: 6050 RVA: 0x001200AC File Offset: 0x0011E2AC
		Private Sub txtPRICE9_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPRICE9.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPRICE9.Text = mdlUIForm.gfFomular_2_Num(Me.txtPRICE9.Text).ToString()
				End If
				Me.txtPRICE9.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPRICE9.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060017A3 RID: 6051 RVA: 0x00120158 File Offset: 0x0011E358
		Private Sub txtPRICE10_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtPRICE10.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtPRICE10.Text = mdlUIForm.gfFomular_2_Num(Me.txtPRICE10.Text).ToString()
				End If
				Me.txtPRICE10.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Me.txtPRICE10.Text), CShort(mdlVariable.gbytDECNUM), ",")
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060017A4 RID: 6052 RVA: 0x00120204 File Offset: 0x0011E404
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.txtTENMT.[ReadOnly] = True
				Me.txtTENNH.[ReadOnly] = True
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtTENNH.BackColor
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtSUBOBJNAME.[ReadOnly] = True
						Me.txtMADVT.[ReadOnly] = True
						Me.txtMAMT.[ReadOnly] = True
						Me.txtMANH.[ReadOnly] = True
						Me.txtMAPL.[ReadOnly] = True
						Me.txtMANSX.[ReadOnly] = True
						Me.txtPRICE.[ReadOnly] = True
						Me.txtPRICE2.[ReadOnly] = True
						Me.txtPRICE3.[ReadOnly] = True
						Me.txtPRICE4.[ReadOnly] = True
						Me.txtPRICE5.[ReadOnly] = True
						Me.txtPRICE6.[ReadOnly] = True
						Me.txtPRICE7.[ReadOnly] = True
						Me.txtPRICE8.[ReadOnly] = True
						Me.txtPRICE9.[ReadOnly] = True
						Me.txtPRICE10.[ReadOnly] = True
						Me.txtPURSE.[ReadOnly] = True
						Me.txtREMARK.[ReadOnly] = True
						Me.txtMADV.[ReadOnly] = True
						Me.txtbep1.[ReadOnly] = True
						Me.txtbep2.[ReadOnly] = True
						Me.txtbep3.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtTENNH.BackColor
						Me.txtOBJNAME.BackColor = Me.txtTENNH.BackColor
						Me.txtSUBOBJNAME.BackColor = Me.txtTENNH.BackColor
						Me.txtMADVT.BackColor = Me.txtTENNH.BackColor
						Me.txtMAMT.BackColor = Me.txtTENNH.BackColor
						Me.txtMANH.BackColor = Me.txtTENNH.BackColor
						Me.txtMAPL.BackColor = Me.txtTENNH.BackColor
						Me.txtMANSX.BackColor = Me.txtTENNH.BackColor
						Me.txtPRICE.BackColor = Me.txtTENNH.BackColor
						Me.txtPRICE2.BackColor = Me.txtTENNH.BackColor
						Me.txtPRICE3.BackColor = Me.txtTENNH.BackColor
						Me.txtPRICE4.BackColor = Me.txtTENNH.BackColor
						Me.txtPRICE5.BackColor = Me.txtTENNH.BackColor
						Me.txtPRICE6.BackColor = Me.txtTENNH.BackColor
						Me.txtPRICE7.BackColor = Me.txtTENNH.BackColor
						Me.txtPRICE8.BackColor = Me.txtTENNH.BackColor
						Me.txtPRICE9.BackColor = Me.txtTENNH.BackColor
						Me.txtPRICE10.BackColor = Me.txtTENNH.BackColor
						Me.txtPURSE.BackColor = Me.txtTENNH.BackColor
						Me.txtREMARK.BackColor = Me.txtTENNH.BackColor
						Me.txtMADV.BackColor = Me.txtTENNH.BackColor
						Me.btnDMMT.Enabled = False
						Me.btnDMNH.Enabled = False
						Me.btnMANSX.Enabled = False
						Me.btnMAPL.Enabled = False
						Me.btnDMDV.Enabled = False
						Me.btnDVT.Enabled = False
						Me.chkLSAVE.Enabled = False
						Me.chkLopen.Enabled = False
						Me.chkLMATERIAL.Enabled = False
						Me.chkStopUse.Enabled = False
						Me.chkCOMBO.Enabled = False
						Me.chkLSETCOMBO.Enabled = False
						Me.chkLTON_KHACHHANG.Enabled = False
						Me.btnDMBEP1.Enabled = False
						Me.btnDMBEP2.Enabled = False
						Me.btnDMBEP3.Enabled = False
						Me.grbTONKHO.Enabled = False
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017A5 RID: 6053 RVA: 0x0012071C File Offset: 0x0011E91C
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017A6 RID: 6054 RVA: 0x001208A0 File Offset: 0x0011EAA0
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 15
				Me.txtOBJNAME.MaxLength = 60
				Me.txtMADVT.MaxLength = 10
				Me.txtMADV.MaxLength = 20
				Me.txtMANH.MaxLength = 5
				Me.txtMAMT.MaxLength = 2
				Me.txtREMARK.MaxLength = 200
				Dim flag As Boolean = (Me.mbytFormStatus = 5) Or (Me.mbytFormStatus = 6)
				If flag Then
					Me.chkLSAVE.ThreeState = True
					Me.chkLopen.ThreeState = True
					Me.chkLMATERIAL.ThreeState = True
					Me.chkStopUse.ThreeState = True
					Me.chkCOMBO.ThreeState = True
					Me.chkLSAVE.CheckState = CheckState.Indeterminate
					Me.chkLopen.CheckState = CheckState.Indeterminate
					Me.chkLMATERIAL.CheckState = CheckState.Indeterminate
					Me.chkStopUse.CheckState = CheckState.Indeterminate
					Me.chkCOMBO.CheckState = CheckState.Indeterminate
					Me.chkLSETCOMBO.CheckState = CheckState.Indeterminate
					Me.chkLTON_KHACHHANG.CheckState = CheckState.Indeterminate
				End If
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				Me.txtMANH.CharacterCasing = CharacterCasing.Upper
				Me.txtMADC.CharacterCasing = CharacterCasing.Upper
				Me.txtMANSX.CharacterCasing = CharacterCasing.Upper
				Me.txtMAPL.CharacterCasing = CharacterCasing.Upper
				Me.txtMAMT.CharacterCasing = CharacterCasing.Upper
				Me.txtMADVT.CharacterCasing = CharacterCasing.Upper
				Me.txtMADV.CharacterCasing = CharacterCasing.Upper
				Me.txtPURSE.Visible = mdlVariable.gblnLDMHHPURSE
				Me.Label7.Visible = mdlVariable.gblnLDMHHPURSE
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017A7 RID: 6055 RVA: 0x00120B08 File Offset: 0x0011ED08
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
					Me.lblDVT.Tag = "CB0031"
					Me.lblMANH.Tag = "CB0032"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017A8 RID: 6056 RVA: 0x00120D10 File Offset: 0x0011EF10
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMMT.Dispose()
				Me.mclsTbDMNH.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017A9 RID: 6057 RVA: 0x00120DC8 File Offset: 0x0011EFC8
		Public Function gfAddNew(Optional pbytNomessage As Byte = 0) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(53) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcTENPHU"
				array(2).Value = Strings.Trim(Me.txtSUBOBJNAME.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcDVT"
				array(3).Value = Strings.Trim(Me.txtMADVT.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnchMANH"
				array(4).Value = Strings.Trim(Me.txtMANH.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnchMAMT"
				array(5).Value = Strings.Trim(Me.txtMAMT.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnchMAPL"
				array(6).Value = Strings.Trim(Me.txtMAPL.Text)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnchMANSX"
				array(7).Value = Strings.Trim(Me.txtMANSX.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnchMADC"
				array(8).Value = Strings.Trim(Me.txtMADC.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pmnyPRICE"
				array(9).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE.Text.Trim(), "", False) = 0), 0, Strings.Replace(Me.txtPRICE.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pmnyPRICE2"
				array(10).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE2.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE2.Text.Trim(), "", False) = 0), 0, Strings.Replace(Me.txtPRICE2.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pmnyPRICE3"
				array(11).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE3.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE3.Text, "", False) = 0), 0, Strings.Replace(Me.txtPRICE3.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pmnyPRICE4"
				array(12).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE4.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE4.Text, "", False) = 0), 0, Strings.Replace(Me.txtPRICE4.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pmnyPRICE5"
				array(13).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE5.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE5.Text, "", False) = 0), 0, Strings.Replace(Me.txtPRICE5.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pmnyPRICE6"
				array(14).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE6.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE6.Text, "", False) = 0), 0, Strings.Replace(Me.txtPRICE6.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pmnyPRICE7"
				array(15).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE7.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE7.Text, "", False) = 0), 0, Strings.Replace(Me.txtPRICE7.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pmnyPRICE8"
				array(16).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE8.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE8.Text, "", False) = 0), 0, Strings.Replace(Me.txtPRICE8.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pmnyPRICE9"
				array(17).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE9.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE9.Text, "", False) = 0), 0, Strings.Replace(Me.txtPRICE9.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@pmnyPRICE10"
				array(18).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE10.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE10.Text, "", False) = 0), 0, Strings.Replace(Me.txtPRICE10.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pbitLMATERIAL"
				array(19).Value = 0
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@bitKHO"
				array(20).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSAVE.Checked, 1, 0))
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = Strings.Trim(Me.txtREMARK.Text)
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMADV"
				array(22).Value = Strings.Trim(Me.txtMADV.Text)
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnchMAINBEP1"
				array(23).Value = Strings.Trim(Me.txtbep1.Text)
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnchMAINBEP2"
				array(24).Value = Strings.Trim(Me.txtbep2.Text)
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnchMAINBEP3"
				array(25).Value = Strings.Trim(Me.txtbep3.Text)
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pbitLOPEN"
				array(26).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLopen.Checked, 1, 0))
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pbitLHIDEN"
				array(27).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLMATERIAL.Checked, 1, 0))
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pbitLSTOPUSE"
				array(28).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkStopUse.Checked, 1, 0))
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pbitLCOMBO"
				array(29).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCOMBO.Checked, 1, 0))
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnvcCOMBO"
				array(30).Value = Me.txtCOMBO.Text.Trim()
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@int_Result"
				array(31).Direction = ParameterDirection.ReturnValue
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pmnyPURSE"
				array(32).Value = Conversion.Val(Strings.Replace(Me.txtPURSE.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pbitLSETCOMBO"
				array(33).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSETCOMBO.Checked, 1, 0))
				array(34) = sqlCommand.CreateParameter()
				array(34).ParameterName = "@pbitLTON_KHACHHANG"
				array(34).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLTON_KHACHHANG.Checked, 1, 0))
				array(35) = sqlCommand.CreateParameter()
				array(35).ParameterName = "@pnvcPHIEU"
				array(35).Value = Me.txtPhieu.Text
				array(36) = sqlCommand.CreateParameter()
				array(36).ParameterName = "@pnchMAINBEP4"
				array(36).Value = Strings.Trim(Me.txtbep4.Text)
				array(37) = sqlCommand.CreateParameter()
				array(37).ParameterName = "@pnchMAINBEP5"
				array(37).Value = Strings.Trim(Me.txtbep5.Text)
				array(38) = sqlCommand.CreateParameter()
				array(38).ParameterName = "@pnchMAINBEP6"
				array(38).Value = Strings.Trim(Me.txtbep6.Text)
				array(39) = sqlCommand.CreateParameter()
				array(39).ParameterName = "@pnvcUIMAGE"
				array(39).Value = Me.mstrUIMAGE.Trim()
				array(40) = sqlCommand.CreateParameter()
				array(40).ParameterName = "@pbitLCOMBOPRICE"
				array(40).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLComboPrice.Checked, 1, 0))
				array(41) = sqlCommand.CreateParameter()
				array(41).ParameterName = "@pintTHOIKHOANG"
				array(41).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtTHOIKHOANG.Text = Nothing) Or (Operators.CompareString(Me.txtTHOIKHOANG.Text.Trim(), "", False) = 0), 0, Strings.Replace(Me.txtTHOIKHOANG.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(42) = sqlCommand.CreateParameter()
				array(42).ParameterName = "@ptniHOAHONG"
				array(42).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtTienHoaHong.Text = Nothing) Or (Operators.CompareString(Me.txtTienHoaHong.Text.Trim(), "", False) = 0), 0, Strings.Replace(Me.txtTienHoaHong.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(43) = sqlCommand.CreateParameter()
				array(43).ParameterName = "@pnvcDVTDG"
				array(43).Value = Strings.Trim(Me.txtMADVTDG.Text)
				array(44) = sqlCommand.CreateParameter()
				array(44).ParameterName = "@pdblTILEDVT"
				array(44).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtTiLeDVT.Text = Nothing) Or (Operators.CompareString(Me.txtTiLeDVT.Text.Trim(), "", False) = 0), 1, Strings.Replace(Me.txtTiLeDVT.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(45) = sqlCommand.CreateParameter()
				array(45).ParameterName = "@pdecSCORE"
				array(45).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtScore.Text = Nothing) Or (Operators.CompareString(Me.txtScore.Text.Trim(), "", False) = 0), 0, Strings.Replace(Me.txtScore.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(46) = sqlCommand.CreateParameter()
				array(46).ParameterName = "@pnchMAMT2"
				array(46).Value = Strings.Trim(Me.txtMAMT2.Text)
				array(47) = sqlCommand.CreateParameter()
				array(47).ParameterName = "@pbitLQTYMAIN"
				array(47).Value = Me.chkLQTYMain.Checked
				array(48) = sqlCommand.CreateParameter()
				array(48).ParameterName = "@pbitLAMTOPEN"
				array(48).Value = Me.chkLAmtOpen.Checked
				array(49) = sqlCommand.CreateParameter()
				array(49).ParameterName = "@pbitLSERIAL"
				array(49).Value = Me.chkLSerial.Checked
				array(50) = sqlCommand.CreateParameter()
				array(50).ParameterName = "@pbitLNotCheckFRKey"
				array(50).Value = False
				array(51) = sqlCommand.CreateParameter()
				array(51).ParameterName = "@pnchMAHH_COPY"
				array(51).Value = Me.mstrMaHH_Copy.Trim()
				array(52) = sqlCommand.CreateParameter()
				array(52).ParameterName = "@pbitLQTYLE"
				array(52).Value = Me.chkLQtyLe.Checked
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHH_INSERT_DMHH", flag)
				Dim num As Integer = Conversions.ToInteger(array(31).Value)
				Dim flag2 As Boolean = pbytNomessage = 1
				If flag2 Then
					Dim flag3 As Boolean = num = 1
					If flag3 Then
						Me.fModify()
					End If
				Else
					Dim flag3 As Boolean = num = 0
					If flag3 Then
						Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
						b = 1
					Else
						flag3 = num = 1
						If flag3 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
							Me.txtOBJID.Focus()
						Else
							flag3 = num = 2
							If flag3 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(61), MsgBoxStyle.Critical, Nothing)
								Me.txtMADVT.Focus()
							Else
								flag3 = num = 3
								If flag3 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(37), MsgBoxStyle.Critical, Nothing)
									Me.txtMANH.Focus()
								Else
									flag3 = num = 4
									If flag3 Then
										Interaction.MsgBox(Me.mArrStrFrmMess(64), MsgBoxStyle.Critical, Nothing)
										Me.txtMADV.Focus()
									Else
										flag3 = num = 5
										If flag3 Then
											Interaction.MsgBox(Me.mArrStrFrmMess(65), MsgBoxStyle.Critical, Nothing)
											Me.txtMAMT.Focus()
										Else
											flag3 = num = 6
											If flag3 Then
												Interaction.MsgBox(Me.mArrStrFrmMess(54), MsgBoxStyle.Critical, Nothing)
												Me.txtMAPL.Focus()
											Else
												flag3 = num = 7
												If flag3 Then
													Interaction.MsgBox(Me.mArrStrFrmMess(55), MsgBoxStyle.Critical, Nothing)
													Me.txtMANSX.Focus()
												Else
													flag3 = num = 8
													If flag3 Then
														Interaction.MsgBox(Me.mArrStrFrmMess(63), MsgBoxStyle.Critical, Nothing)
														Me.txtMADC.Focus()
													Else
														Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
														Me.txtOBJID.Focus()
													End If
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gfAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060017AA RID: 6058 RVA: 0x0012210C File Offset: 0x0012030C
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(52) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcTENPHU"
				array(2).Value = Strings.Trim(Me.txtSUBOBJNAME.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcDVT"
				array(3).Value = Strings.Trim(Me.txtMADVT.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnchMANH"
				array(4).Value = Strings.Trim(Me.txtMANH.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnchMAMT"
				array(5).Value = Strings.Trim(Me.txtMAMT.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnchMAPL"
				array(6).Value = Strings.Trim(Me.txtMAPL.Text)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnchMANSX"
				array(7).Value = Strings.Trim(Me.txtMANSX.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnchMADC"
				array(8).Value = Strings.Trim(Me.txtMADC.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pmnyPRICE"
				array(9).Value = Conversion.Val(Strings.Replace(Conversions.ToString(Interaction.IIf((Me.txtPRICE.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE.Text, "", False) = 0), 0, Me.txtPRICE.Text.Trim())), ",", "", 1, -1, CompareMethod.Binary))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pmnyPRICE2"
				array(10).Value = Conversion.Val(Strings.Replace(Conversions.ToString(Interaction.IIf((Me.txtPRICE2.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE2.Text, "", False) = 0), 0, Me.txtPRICE2.Text.Trim())), ",", "", 1, -1, CompareMethod.Binary))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pmnyPRICE3"
				array(11).Value = Conversion.Val(Strings.Replace(Conversions.ToString(Interaction.IIf((Me.txtPRICE3.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE3.Text, "", False) = 0), 0, Me.txtPRICE3.Text.Trim())), ",", "", 1, -1, CompareMethod.Binary))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pmnyPRICE4"
				array(12).Value = Conversion.Val(Strings.Replace(Conversions.ToString(Interaction.IIf((Me.txtPRICE4.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE4.Text, "", False) = 0), 0, Me.txtPRICE4.Text.Trim())), ",", "", 1, -1, CompareMethod.Binary))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pmnyPRICE5"
				array(13).Value = Conversion.Val(Strings.Replace(Conversions.ToString(Interaction.IIf((Me.txtPRICE5.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE5.Text, "", False) = 0), 0, Me.txtPRICE5.Text.Trim())), ",", "", 1, -1, CompareMethod.Binary))
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pmnyPRICE6"
				array(14).Value = Conversion.Val(Strings.Replace(Conversions.ToString(Interaction.IIf((Me.txtPRICE6.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE6.Text, "", False) = 0), 0, Me.txtPRICE6.Text.Trim())), ",", "", 1, -1, CompareMethod.Binary))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pmnyPRICE7"
				array(15).Value = Conversion.Val(Strings.Replace(Conversions.ToString(Interaction.IIf((Me.txtPRICE7.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE7.Text, "", False) = 0), 0, Me.txtPRICE7.Text.Trim())), ",", "", 1, -1, CompareMethod.Binary))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pmnyPRICE8"
				array(16).Value = Conversion.Val(Strings.Replace(Conversions.ToString(Interaction.IIf((Me.txtPRICE8.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE8.Text, "", False) = 0), 0, Me.txtPRICE8.Text.Trim())), ",", "", 1, -1, CompareMethod.Binary))
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pmnyPRICE9"
				array(17).Value = Conversion.Val(Strings.Replace(Conversions.ToString(Interaction.IIf((Me.txtPRICE9.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE9.Text, "", False) = 0), 0, Me.txtPRICE9.Text.Trim())), ",", "", 1, -1, CompareMethod.Binary))
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@pmnyPRICE10"
				array(18).Value = Conversion.Val(Strings.Replace(Conversions.ToString(Interaction.IIf((Me.txtPRICE10.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE10.Text, "", False) = 0), 0, Me.txtPRICE10.Text.Trim())), ",", "", 1, -1, CompareMethod.Binary))
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pbitLMATERIAL"
				array(19).Value = 0
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@bitKHO"
				array(20).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSAVE.Checked, 1, 0))
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = Strings.Trim(Me.txtREMARK.Text)
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMADV"
				array(22).Value = Strings.Trim(Me.txtMADV.Text)
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnchMAINBEP1"
				array(23).Value = Strings.Trim(Me.txtbep1.Text)
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnchMAINBEP2"
				array(24).Value = Strings.Trim(Me.txtbep2.Text)
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnchMAINBEP3"
				array(25).Value = Strings.Trim(Me.txtbep3.Text)
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pbitLOPEN"
				array(26).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLopen.Checked, 1, 0))
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pbitLHIDEN"
				array(27).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLMATERIAL.Checked, 1, 0))
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pbitLSTOPUSE"
				array(28).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkStopUse.Checked, 1, 0))
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pbitLCOMBO"
				array(29).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCOMBO.Checked, 1, 0))
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnvcCOMBO"
				array(30).Value = Me.txtCOMBO.Text.Trim()
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@int_Result"
				array(31).Direction = ParameterDirection.ReturnValue
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pmnyPURSE"
				array(32).Value = Conversion.Val(Strings.Replace(Me.txtPURSE.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pbitLSETCOMBO"
				array(33).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSETCOMBO.Checked, 1, 0))
				array(34) = sqlCommand.CreateParameter()
				array(34).ParameterName = "@pbitLTON_KHACHHANG"
				array(34).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLTON_KHACHHANG.Checked, 1, 0))
				array(35) = sqlCommand.CreateParameter()
				array(35).ParameterName = "@pnvcPHIEU"
				array(35).Value = Me.txtPhieu.Text
				array(36) = sqlCommand.CreateParameter()
				array(36).ParameterName = "@pnchMAINBEP4"
				array(36).Value = Strings.Trim(Me.txtbep4.Text)
				array(37) = sqlCommand.CreateParameter()
				array(37).ParameterName = "@pnchMAINBEP5"
				array(37).Value = Strings.Trim(Me.txtbep5.Text)
				array(38) = sqlCommand.CreateParameter()
				array(38).ParameterName = "@pnchMAINBEP6"
				array(38).Value = Strings.Trim(Me.txtbep6.Text)
				array(39) = sqlCommand.CreateParameter()
				array(39).ParameterName = "@pnvcUIMAGE"
				array(39).Value = Me.mstrUIMAGE.Trim()
				array(40) = sqlCommand.CreateParameter()
				array(40).ParameterName = "@pbitLCOMBOPRICE"
				array(40).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLComboPrice.Checked, 1, 0))
				array(41) = sqlCommand.CreateParameter()
				array(41).ParameterName = "@pintTHOIKHOANG"
				array(41).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtTHOIKHOANG.Text = Nothing) Or (Operators.CompareString(Me.txtTHOIKHOANG.Text.Trim(), "", False) = 0), 0, Strings.Replace(Me.txtTHOIKHOANG.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(42) = sqlCommand.CreateParameter()
				array(42).ParameterName = "@ptniHOAHONG"
				array(42).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtTienHoaHong.Text = Nothing) Or (Operators.CompareString(Me.txtTienHoaHong.Text.Trim(), "", False) = 0), 0, Strings.Replace(Me.txtTienHoaHong.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(43) = sqlCommand.CreateParameter()
				array(43).ParameterName = "@pnvcDVTDG"
				array(43).Value = Strings.Trim(Me.txtMADVTDG.Text)
				array(44) = sqlCommand.CreateParameter()
				array(44).ParameterName = "@pdblTILEDVT"
				array(44).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtTiLeDVT.Text = Nothing) Or (Operators.CompareString(Me.txtTiLeDVT.Text.Trim(), "", False) = 0), 1, Strings.Replace(Me.txtTiLeDVT.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(45) = sqlCommand.CreateParameter()
				array(45).ParameterName = "@pdecSCORE"
				array(45).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtScore.Text = Nothing) Or (Operators.CompareString(Me.txtScore.Text.Trim(), "", False) = 0), 0, Strings.Replace(Me.txtScore.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(46) = sqlCommand.CreateParameter()
				array(46).ParameterName = "@pnchMAMT2"
				array(46).Value = Strings.Trim(Me.txtMAMT2.Text)
				array(47) = sqlCommand.CreateParameter()
				array(47).ParameterName = "@pbitLQTYMAIN"
				array(47).Value = Me.chkLQTYMain.Checked
				array(48) = sqlCommand.CreateParameter()
				array(48).ParameterName = "@pbitLAMTOPEN"
				array(48).Value = Me.chkLAmtOpen.Checked
				array(49) = sqlCommand.CreateParameter()
				array(49).ParameterName = "@pbitLSERIAL"
				array(49).Value = Me.chkLSerial.Checked
				array(50) = sqlCommand.CreateParameter()
				array(50).ParameterName = "@pbitLNotCheckFRKey"
				array(50).Value = False
				array(51) = sqlCommand.CreateParameter()
				array(51).ParameterName = "@pbitLQTYLE"
				array(51).Value = Me.chkLQtyLe.Checked
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHH_UPDATE_DMHH", flag)
				Dim num As Integer = Conversions.ToInteger(array(31).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(61), MsgBoxStyle.Critical, Nothing)
							Me.txtMADVT.Focus()
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(37), MsgBoxStyle.Critical, Nothing)
								Me.txtMANH.Focus()
							Else
								flag2 = num = 4
								If flag2 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(64), MsgBoxStyle.Critical, Nothing)
									Me.txtMADV.Focus()
								Else
									flag2 = num = 5
									If flag2 Then
										Interaction.MsgBox(Me.mArrStrFrmMess(65), MsgBoxStyle.Critical, Nothing)
										Me.txtMAMT.Focus()
									Else
										flag2 = num = 6
										If flag2 Then
											Interaction.MsgBox(Me.mArrStrFrmMess(54), MsgBoxStyle.Critical, Nothing)
											Me.txtMAPL.Focus()
										Else
											flag2 = num = 7
											If flag2 Then
												Interaction.MsgBox(Me.mArrStrFrmMess(55), MsgBoxStyle.Critical, Nothing)
												Me.txtMANSX.Focus()
											Else
												flag2 = num = 8
												If flag2 Then
													Interaction.MsgBox(Me.mArrStrFrmMess(63), MsgBoxStyle.Critical, Nothing)
													Me.txtMADC.Focus()
												Else
													Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
													Me.txtOBJID.Focus()
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060017AB RID: 6059 RVA: 0x001233FC File Offset: 0x001215FC
		Private Function fModifyMulti() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(51) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcTENPHU"
				array(2).Value = Strings.Trim(Me.txtSUBOBJNAME.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcDVT"
				array(3).Value = Strings.Trim(Me.txtMADVT.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnchMANH"
				array(4).Value = Strings.Trim(Me.txtMANH.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnchMAMT"
				array(5).Value = Strings.Trim(Me.txtMAMT.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnchMAPL"
				array(6).Value = Strings.Trim(Me.txtMAPL.Text)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnchMANSX"
				array(7).Value = Strings.Trim(Me.txtMANSX.Text)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnchMADC"
				array(8).Value = Strings.Trim(Me.txtMADC.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pmnyPRICE"
				array(9).DbType = DbType.Currency
				array(9).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPRICE.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pmnyPRICE2"
				array(10).DbType = DbType.Currency
				array(10).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE2.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE2.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPRICE2.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pmnyPRICE3"
				array(11).DbType = DbType.Currency
				array(11).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE3.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE3.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPRICE3.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pmnyPRICE4"
				array(12).DbType = DbType.Currency
				array(12).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE4.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE4.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPRICE4.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pmnyPRICE5"
				array(13).DbType = DbType.Currency
				array(13).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE5.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE5.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPRICE5.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pmnyPRICE6"
				array(14).DbType = DbType.Currency
				array(14).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE6.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE6.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPRICE6.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pmnyPRICE7"
				array(15).DbType = DbType.Currency
				array(15).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE7.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE7.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPRICE7.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pmnyPRICE8"
				array(16).DbType = DbType.Currency
				array(16).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE8.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE8.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPRICE8.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pmnyPRICE9"
				array(17).DbType = DbType.Currency
				array(17).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE9.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE9.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPRICE9.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@pmnyPRICE10"
				array(18).DbType = DbType.Currency
				array(18).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPRICE10.Text = Nothing) Or (Operators.CompareString(Me.txtPRICE10.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPRICE10.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pbitLMATERIAL"
				array(19).DbType = DbType.[Boolean]
				array(19).Value = 0
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@pbitKHO"
				array(20).DbType = DbType.[Boolean]
				array(20).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSAVE.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkLSAVE.Checked))
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = Strings.Trim(Me.txtREMARK.Text)
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMADV"
				array(22).Value = Strings.Trim(Me.txtMADV.Text)
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnchMAINBEP1"
				array(23).Value = Strings.Trim(Me.txtbep1.Text)
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnchMAINBEP2"
				array(24).Value = Strings.Trim(Me.txtbep2.Text)
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnchMAINBEP3"
				array(25).Value = Strings.Trim(Me.txtbep3.Text)
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pbitLOPEN"
				array(26).DbType = DbType.[Boolean]
				array(26).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLopen.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkLopen.Checked))
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pbitLHIDEN"
				array(27).DbType = DbType.[Boolean]
				array(27).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLMATERIAL.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkLMATERIAL.Checked))
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pbitLSTOPUSE"
				array(28).DbType = DbType.[Boolean]
				array(28).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkStopUse.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkStopUse.Checked))
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pbitLCOMBO"
				array(29).DbType = DbType.[Boolean]
				array(29).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCOMBO.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkCOMBO.Checked))
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnvcCOMBO"
				array(30).Value = Me.txtCOMBO.Text.Trim()
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@int_Result"
				array(31).Direction = ParameterDirection.ReturnValue
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pmnyPURSE"
				array(32).DbType = DbType.Currency
				array(32).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtPURSE.Text = Nothing) Or (Operators.CompareString(Me.txtPURSE.Text, "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtPURSE.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pbitLSETCOMBO"
				array(33).DbType = DbType.[Boolean]
				array(33).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSETCOMBO.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkLSETCOMBO.Checked))
				array(34) = sqlCommand.CreateParameter()
				array(34).ParameterName = "@pbitLTON_KHACHHANG"
				array(34).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLTON_KHACHHANG.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkLTON_KHACHHANG.Checked))
				array(35) = sqlCommand.CreateParameter()
				array(35).ParameterName = "@pnvcPHIEU"
				array(35).Value = Me.txtPhieu.Text
				array(36) = sqlCommand.CreateParameter()
				array(36).ParameterName = "@pnchMAINBEP4"
				array(36).Value = Strings.Trim(Me.txtbep4.Text)
				array(37) = sqlCommand.CreateParameter()
				array(37).ParameterName = "@pnchMAINBEP5"
				array(37).Value = Strings.Trim(Me.txtbep5.Text)
				array(38) = sqlCommand.CreateParameter()
				array(38).ParameterName = "@pnchMAINBEP6"
				array(38).Value = Strings.Trim(Me.txtbep6.Text)
				array(39) = sqlCommand.CreateParameter()
				array(39).ParameterName = "@pnvcUIMAGE"
				array(39).Value = Me.mstrUIMAGE.Trim()
				array(40) = sqlCommand.CreateParameter()
				array(40).ParameterName = "@pbitLCOMBOPRICE"
				array(40).DbType = DbType.[Boolean]
				array(40).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLComboPrice.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkLComboPrice.Checked))
				array(41) = sqlCommand.CreateParameter()
				array(41).ParameterName = "@pintTHOIKHOANG"
				array(41).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtTHOIKHOANG.Text = Nothing) Or (Operators.CompareString(Me.txtTHOIKHOANG.Text.Trim(), "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtTHOIKHOANG.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(42) = sqlCommand.CreateParameter()
				array(42).ParameterName = "@ptniHOAHONG"
				array(42).DbType = DbType.[Byte]
				array(42).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtHOAHONG.Text = Nothing) Or (Operators.CompareString(Me.txtHOAHONG.Text.Trim(), "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtHOAHONG.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(43) = sqlCommand.CreateParameter()
				array(43).ParameterName = "@pnvcDVTDG"
				array(43).Value = Strings.Trim(Me.txtMADVTDG.Text)
				array(44) = sqlCommand.CreateParameter()
				array(44).ParameterName = "@pdblTILEDVT"
				array(44).DbType = DbType.[Decimal]
				array(44).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtTiLeDVT.Text = Nothing) Or (Operators.CompareString(Me.txtTiLeDVT.Text.Trim(), "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtTiLeDVT.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(45) = sqlCommand.CreateParameter()
				array(45).ParameterName = "@pdecSCORE"
				array(45).DbType = DbType.[Decimal]
				array(45).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf((Me.txtScore.Text = Nothing) Or (Operators.CompareString(Me.txtScore.Text.Trim(), "", False) = 0), DBNull.Value, Conversion.Val(Strings.Replace(Me.txtScore.Text.Trim(), ",", "", 1, -1, CompareMethod.Binary))))
				array(46) = sqlCommand.CreateParameter()
				array(46).ParameterName = "@pnchMAMT2"
				array(46).Value = Strings.Trim(Me.txtMAMT2.Text)
				array(47) = sqlCommand.CreateParameter()
				array(47).ParameterName = "@pbitLQTYMAIN"
				array(47).DbType = DbType.[Boolean]
				array(47).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLQTYMain.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkLQTYMain.Checked))
				array(48) = sqlCommand.CreateParameter()
				array(48).ParameterName = "@pbitLAMTOPEN"
				array(48).DbType = DbType.[Boolean]
				array(48).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLAmtOpen.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkLAmtOpen.Checked))
				array(49) = sqlCommand.CreateParameter()
				array(49).ParameterName = "@pbitLSERIAL"
				array(49).DbType = DbType.[Boolean]
				array(49).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLSerial.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkLSerial.Checked))
				array(50) = sqlCommand.CreateParameter()
				array(50).ParameterName = "@pbitLQTYLE"
				array(50).DbType = DbType.[Boolean]
				array(50).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkLQtyLe.CheckState = CheckState.Indeterminate, DBNull.Value, Me.chkLQtyLe.Checked))
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHH_UPDATE_MULTI_DMHH", flag)
				Dim num As Integer = Conversions.ToInteger(array(31).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(61), MsgBoxStyle.Critical, Nothing)
							Me.txtMADVT.Focus()
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(37), MsgBoxStyle.Critical, Nothing)
								Me.txtMANH.Focus()
							Else
								flag2 = num = 4
								If flag2 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(64), MsgBoxStyle.Critical, Nothing)
									Me.txtMADV.Focus()
								Else
									flag2 = num = 5
									If flag2 Then
										Interaction.MsgBox(Me.mArrStrFrmMess(65), MsgBoxStyle.Critical, Nothing)
										Me.txtMAMT.Focus()
									Else
										flag2 = num = 6
										If flag2 Then
											Interaction.MsgBox(Me.mArrStrFrmMess(54), MsgBoxStyle.Critical, Nothing)
											Me.txtMAPL.Focus()
										Else
											flag2 = num = 7
											If flag2 Then
												Interaction.MsgBox(Me.mArrStrFrmMess(55), MsgBoxStyle.Critical, Nothing)
												Me.txtMANSX.Focus()
											Else
												flag2 = num = 8
												If flag2 Then
													Interaction.MsgBox(Me.mArrStrFrmMess(63), MsgBoxStyle.Critical, Nothing)
													Me.txtMADC.Focus()
												Else
													Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
													Me.txtOBJID.Focus()
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060017AC RID: 6060 RVA: 0x001248F4 File Offset: 0x00122AF4
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHH_DEL_DMHH", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Dim flag3 As Boolean = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(30), Me.mArrStrFrmMess(97), frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.CanhBao) = DialogResult.Yes
							If flag3 Then
								Dim clsConnect2 As clsConnect = New clsConnect()
								Dim sqlCommand2 As SqlCommand = New SqlCommand()
								Dim array2 As SqlParameter() = New SqlParameter(2) {}
								array2(0) = sqlCommand.CreateParameter()
								array2(0).ParameterName = "@pnchMA"
								array2(0).Value = Strings.Trim(Me.txtOBJID.Text)
								array2(1) = sqlCommand.CreateParameter()
								array2(1).ParameterName = "@int_Result"
								array2(1).Direction = ParameterDirection.ReturnValue
								Dim flag4 As Boolean
								clsConnect2 = New clsConnect(mdlVariable.gStrConISDANHMUC, array2, "SP_FRMDMHH_DEL_DMHH_NO_CONSTRAINT", flag4)
								Dim num2 As Integer = Conversions.ToInteger(array2(1).Value)
								flag3 = num2 = 0
								If flag3 Then
									b = 1
								Else
									Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
								End If
							End If
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060017AD RID: 6061 RVA: 0x00124B98 File Offset: 0x00122D98
		Private Function fAdd_Combo(strMaHH_M As String, strMaHH_C As String, dblQty As Double, blnLAutoAdd As Boolean, blnLPrice As Boolean, blnDeleteFrist As Boolean) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(7) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAHH_M"
				array(0).Value = strMaHH_M
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHH_C"
				array(1).Value = strMaHH_C
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pmnyQTY"
				array(2).Value = dblQty
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pbitLAUTOADD"
				array(3).Value = blnLAutoAdd
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pbitLPRICE"
				array(4).Value = blnLPrice
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pbitLDELETE_FRIST"
				array(5).Value = blnDeleteFrist
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@int_Result"
				array(6).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHH_INSERT_SETCOMBO", flag)
				Dim num As Integer = Conversions.ToInteger(array(6).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox("Mã hàng: " + strMaHH_M + " không tồn tại", MsgBoxStyle.Critical, Nothing)
						Me.txtCOMBO.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox("Mã hàng: " + strMaHH_C + " không tồn tại", MsgBoxStyle.Critical, Nothing)
							Me.txtCOMBO.Focus()
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
							Me.txtCOMBO.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAdd_Combo ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060017AE RID: 6062 RVA: 0x00124E48 File Offset: 0x00123048
		Private Function fGetData_DMNH() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMNH = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNH")
				Dim flag As Boolean = Me.mclsTbDMNH IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMNH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017AF RID: 6063 RVA: 0x00124F04 File Offset: 0x00123104
		Private Function fGetData_DMMT() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMMT = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMT")
				Dim flag As Boolean = Me.mclsTbDMMT IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMMT ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017B0 RID: 6064 RVA: 0x00124FC0 File Offset: 0x001231C0
		Private Function fGetData_DMDVT() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMDVT = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMDVT")
				Dim flag As Boolean = Me.mclsTbDMDVT IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMDVT ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017B1 RID: 6065 RVA: 0x0012507C File Offset: 0x0012327C
		Private Function fGetData_DMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMDV")
				Dim flag As Boolean = Me.mclsTbDMDVT IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMDVT ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017B2 RID: 6066 RVA: 0x00125138 File Offset: 0x00123338
		Private Function fGetData_DMBEP() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMBEP1 = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMAYINBEP")
				Me.mclsTbDMBEP2 = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMAYINBEP")
				Me.mclsTbDMBEP3 = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMAYINBEP")
				Me.mclsTbDMBEP4 = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMAYINBEP")
				Me.mclsTbDMBEP5 = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMAYINBEP")
				Me.mclsTbDMBEP6 = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMAYINBEP")
				Dim flag As Boolean = Me.mclsTbDMDVT IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMBEP ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017B3 RID: 6067 RVA: 0x0012525C File Offset: 0x0012345C
		Private Function fGetData_DMPL() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMPL = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMPL")
				Dim flag As Boolean = Me.mclsTbDMPL IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMPL ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017B4 RID: 6068 RVA: 0x00125318 File Offset: 0x00123518
		Private Function fGetData_DMKH() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKH = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = Me.mclsTbDMKH IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMKH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017B5 RID: 6069 RVA: 0x001253D4 File Offset: 0x001235D4
		Private Function fGetData_DMNSX() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMNSX = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNSX")
				Dim flag As Boolean = Me.mclsTbDMMT IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMNSX ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060017B6 RID: 6070 RVA: 0x00125490 File Offset: 0x00123690
		Public Sub s_SetVisibleShowHide(arrBool As Boolean())
			Try
				Me.panPRICE2_3_4.Visible = arrBool(0)
				Me.panPRICE5_6_7.Visible = arrBool(1)
				Me.panPRICE8_9_10.Visible = arrBool(2)
				Me.lblPRICE2.Visible = arrBool(3)
				Me.txtPRICE2.Visible = arrBool(3)
				Me.lblPRICE3.Visible = arrBool(4)
				Me.txtPRICE3.Visible = arrBool(4)
				Me.lblPRICE4.Visible = arrBool(5)
				Me.txtPRICE4.Visible = arrBool(5)
				Me.lblPRICE5.Visible = arrBool(6)
				Me.txtPRICE5.Visible = arrBool(6)
				Me.lblPRICE6.Visible = arrBool(7)
				Me.txtPRICE6.Visible = arrBool(7)
				Me.lblPRICE7.Visible = arrBool(8)
				Me.txtPRICE7.Visible = arrBool(8)
				Me.lblPRICE8.Visible = arrBool(9)
				Me.txtPRICE8.Visible = arrBool(9)
				Me.lblPRICE9.Visible = arrBool(10)
				Me.txtPRICE9.Visible = arrBool(10)
				Me.lblPRICE10.Visible = arrBool(11)
				Me.txtPRICE10.Visible = arrBool(11)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060017B7 RID: 6071 RVA: 0x00125610 File Offset: 0x00123810
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMHHMAX")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mbytLen_OBJID = Byte.Parse(xmlNode.InnerText)
				End If
				Dim xmlNodeList2 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/FIXMAHH")
				flag = xmlNodeList2.Count > 0
				If flag Then
					Dim xmlNode2 As XmlNode = xmlNodeList2.Item(0)
					Me.mblnFIXMAHH = xmlNode2.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
				Dim xmlNodeList3 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/NUMPRICE")
				flag = xmlNodeList3.Count > 0
				If flag Then
					Dim xmlNode3 As XmlNode = xmlNodeList3.Item(0)
					Me.mbytNUMPRICE = Byte.Parse(xmlNode3.InnerText)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017B8 RID: 6072 RVA: 0x00125798 File Offset: 0x00123998
		Public Function f_ShowHideField(arrField As String) As Boolean()
			Dim array As String() = arrField.Split(New Char() { ","c })
			Dim array2 As Boolean() = New Boolean(11) {}
			Try
				Dim flag As Boolean = (arrField = Nothing) Or (Operators.CompareString(arrField, "", False) = 0)
				If flag Then
					Return array2
				End If
				Dim num As Integer = 0
				Dim num2 As Integer = array.Length - 1
				Dim num3 As Integer = num
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						Exit For
					End If
					array2(Conversions.ToInteger(array(num3))) = True
					num3 += 1
				End While
			Catch ex As Exception
			End Try
			Return array2
		End Function

		' Token: 0x060017B9 RID: 6073 RVA: 0x00125830 File Offset: 0x00123A30
		Private Sub txtMADV_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMADVT.[ReadOnly]
				If [readOnly] Then
					Me.txtMANH.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADV_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017BA RID: 6074 RVA: 0x001258DC File Offset: 0x00123ADC
		Private Sub txtMADV_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMANH.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADV_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060017BB RID: 6075 RVA: 0x00125980 File Offset: 0x00123B80
		Private Sub txtTENDVT_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENDVT.[ReadOnly]
				If [readOnly] Then
					Me.txtMADV.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENDVT_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017BC RID: 6076 RVA: 0x00125A2C File Offset: 0x00123C2C
		Private Sub txtTENDV_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENDV.[ReadOnly]
				If [readOnly] Then
					Me.txtMANH.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENDV_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017BD RID: 6077 RVA: 0x00125AD8 File Offset: 0x00123CD8
		Private Sub txtTENNH_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENNH.[ReadOnly]
				If [readOnly] Then
					Me.txtMAMT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENNH_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017BE RID: 6078 RVA: 0x00125B84 File Offset: 0x00123D84
		Private Sub txtTENMT_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENMT.[ReadOnly]
				If [readOnly] Then
					Me.txtMAPL.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENMT_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017BF RID: 6079 RVA: 0x00125C30 File Offset: 0x00123E30
		Private Sub txtTENPL_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENPL.[ReadOnly]
				If [readOnly] Then
					Me.txtMANSX.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENPL_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017C0 RID: 6080 RVA: 0x00125CDC File Offset: 0x00123EDC
		Private Sub txtTENNSX_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENNSX.[ReadOnly]
				If [readOnly] Then
					Me.txtMADC.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENNSX_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017C1 RID: 6081 RVA: 0x00125D88 File Offset: 0x00123F88
		Private Sub txtTENDC_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENDC.[ReadOnly]
				If [readOnly] Then
					Me.txtPRICE.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENDC_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017C2 RID: 6082 RVA: 0x00125E34 File Offset: 0x00124034
		Private Sub btnDMDV_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDV As frmDMDV1 = New frmDMDV1()
				frmDMDV.pBytOpen_From_Menu = 7
				frmDMDV.ShowDialog()
				Me.txtMADV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJID, "", False) = 0, Me.txtMADV.Text, frmDMDV.pStrOBJID))
				Me.txtTENDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJID, "", False) = 0, Me.txtTENDV.Text, frmDMDV.pStrOBJNAME))
				frmDMDV.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMDV_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017C3 RID: 6083 RVA: 0x00125F58 File Offset: 0x00124158
		Private Sub btnDMBEP1_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAYINBEP As frmDMMAYINBEP1 = New frmDMMAYINBEP1()
				frmDMMAYINBEP.pBytOpen_From_Menu = 7
				frmDMMAYINBEP.ShowDialog()
				Me.txtbep1.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtbep1.Text, frmDMMAYINBEP.pStrOBJID))
				Me.txtTENBEP1.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtTENBEP1.Text, frmDMMAYINBEP.pStrOBJNAME))
				frmDMMAYINBEP.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMBEP1_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017C4 RID: 6084 RVA: 0x0012607C File Offset: 0x0012427C
		Private Sub btnDMBEP2_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAYINBEP As frmDMMAYINBEP1 = New frmDMMAYINBEP1()
				frmDMMAYINBEP.pBytOpen_From_Menu = 7
				frmDMMAYINBEP.ShowDialog()
				Me.txtbep2.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtbep2.Text, frmDMMAYINBEP.pStrOBJID))
				Me.txtTENBEP2.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtTENBEP2.Text, frmDMMAYINBEP.pStrOBJNAME))
				frmDMMAYINBEP.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMBEP2_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017C5 RID: 6085 RVA: 0x001261A0 File Offset: 0x001243A0
		Private Sub btnDMBEP3_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAYINBEP As frmDMMAYINBEP1 = New frmDMMAYINBEP1()
				frmDMMAYINBEP.pBytOpen_From_Menu = 7
				frmDMMAYINBEP.ShowDialog()
				Me.txtbep3.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtbep3.Text, frmDMMAYINBEP.pStrOBJID))
				Me.txtTENBEP3.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtTENBEP3.Text, frmDMMAYINBEP.pStrOBJNAME))
				frmDMMAYINBEP.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMBEP3_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017C6 RID: 6086 RVA: 0x001262C4 File Offset: 0x001244C4
		Private Sub txtMADVT_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMDVT Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMDVT.Columns("OBJID")
					Me.mclsTbDMDVT.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMDVT.Rows.Find(Strings.Trim(Me.txtMADVT.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENDVT.Text = dataRow("OBJNAME").ToString() + "  " + dataRow("SUBOBJNAME").ToString().Trim()
						Me.fGetData_SDBDKHO(Me.txtMAKH.Text.Trim(), Me.txtOBJID.Text.Trim(), Me.txtMADVT.Text.Trim())
					Else
						Me.txtTENDVT.Text = ""
					End If
					Me.sHienThiTieuDeTiLeDVT()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADVT_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017C7 RID: 6087 RVA: 0x00126474 File Offset: 0x00124674
		Private Sub txtMADV_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMDV Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMDV.Columns("OBJID")
					Me.mclsTbDMDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMDV.Rows.Find(Strings.Trim(Me.txtMADV.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENDV.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENDV.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017C8 RID: 6088 RVA: 0x001265C8 File Offset: 0x001247C8
		Private Sub txtbep1_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMBEP1 Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMBEP1.Columns("OBJID")
					Me.mclsTbDMBEP1.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMBEP1.Rows.Find(Strings.Trim(Me.txtbep1.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENBEP1.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENBEP1.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtbep1_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017C9 RID: 6089 RVA: 0x0012671C File Offset: 0x0012491C
		Private Sub txtbep2_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMBEP2 Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMBEP2.Columns("OBJID")
					Me.mclsTbDMBEP2.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMBEP2.Rows.Find(Strings.Trim(Me.txtbep2.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENBEP2.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENBEP2.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtbep2_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017CA RID: 6090 RVA: 0x00126870 File Offset: 0x00124A70
		Private Sub txtbep3_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMBEP3 Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMBEP3.Columns("OBJID")
					Me.mclsTbDMBEP3.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMBEP3.Rows.Find(Strings.Trim(Me.txtbep3.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENBEP3.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENBEP3.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtbep3_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017CB RID: 6091 RVA: 0x0000582A File Offset: 0x00003A2A
		Private Sub chkCOMBO_Click(sender As Object, e As EventArgs)
			Me.txtCOMBO.Visible = Me.chkCOMBO.Checked
			Me.btnCOMBO.Visible = Me.chkCOMBO.Checked
		End Sub

		' Token: 0x060017CC RID: 6092 RVA: 0x001269C4 File Offset: 0x00124BC4
		Private Sub txtSL_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txtDG.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtSL_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060017CD RID: 6093 RVA: 0x00126B60 File Offset: 0x00124D60
		Private Sub txtSL_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtSL.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtSL.Text = mdlUIForm.gfFomular_2_Num(Me.txtSL.Text).ToString()
				End If
				Dim text As String = Strings.Replace(Strings.Trim(Me.txtSL.Text), ",", "", 1, -1, CompareMethod.Binary)
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtDG.Text), ",", "", 1, -1, CompareMethod.Binary)
				flag = Versioned.IsNumeric(text) And Versioned.IsNumeric(text2)
				If flag Then
					Me.txtTT.Text = mdlUIForm.gfFormatNumber(Conversion.Val(text) * Conversion.Val(text2), CShort(mdlVariable.gbytDECNUM), ",")
					Me.txtDG.Text = mdlUIForm.gfFormatNumber(Conversion.Val(text2), CShort(mdlVariable.gbytDECNUM), ",")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtSL_LostFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017CE RID: 6094 RVA: 0x00126D04 File Offset: 0x00124F04
		Private Sub txtDG_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txtTT.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtDG_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060017CF RID: 6095 RVA: 0x00126EA0 File Offset: 0x001250A0
		Private Sub txtDG_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Mid(Me.txtDG.Text.Trim(), 1, 1), "=", False) = 0
				If flag Then
					Me.txtDG.Text = mdlUIForm.gfFomular_2_Num(Me.txtDG.Text).ToString()
				End If
				Dim text As String = Strings.Replace(Strings.Trim(Me.txtSL.Text), ",", "", 1, -1, CompareMethod.Binary)
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtDG.Text), ",", "", 1, -1, CompareMethod.Binary)
				flag = Versioned.IsNumeric(text) And Versioned.IsNumeric(text2)
				If flag Then
					Me.txtTT.Text = mdlUIForm.gfFormatNumber(Conversion.Val(text) * Conversion.Val(text2), CShort(mdlVariable.gbytDECNUM), ",")
					Me.txtDG.Text = mdlUIForm.gfFormatNumber(Conversion.Val(text2), CShort(mdlVariable.gbytDECNUM), ",")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtDG_LostFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017D0 RID: 6096 RVA: 0x00127044 File Offset: 0x00125244
		Private Sub txtTT_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_0148
					Case 13
						Dim flag As Boolean = Me.mbytFormStatus = 5
						If flag Then
							Me.btnFilter.Focus()
						Else
							flag = Me.mbytFormStatus = 6
							If flag Then
								Me.btnFind.Focus()
							Else
								Me.btnSave.Focus()
							End If
						End If
						GoTo IL_0148
				End Select
				e.Handled = True
				IL_0148:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTT_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060017D1 RID: 6097 RVA: 0x0012721C File Offset: 0x0012541C
		Private Sub txtTT_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
				Dim flag2 As Boolean
				If flag Then
					flag2 = (Operators.CompareString(Me.txtSL.Text, "", False) = 0) Or (Operators.CompareString(Me.txtSL.Text, "0", False) = 0) Or (Operators.CompareString(Me.txtTT.Text, "", False) = 0)
					If flag2 Then
						Me.txtTT.Text = ""
					Else
						Me.txtDG.Text = Conversions.ToString(Conversions.ToDouble(Strings.Replace(Me.txtTT.Text, ",", "", 1, -1, CompareMethod.Binary)) / Conversions.ToDouble(Strings.Replace(Me.txtSL.Text, ",", "", 1, -1, CompareMethod.Binary)))
						Me.txtTT.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Strings.Replace(Me.txtTT.Text, ",", "", 1, -1, CompareMethod.Binary)), CShort(mdlVariable.gbytDECNUM), ",")
						Me.txtSL.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Strings.Replace(Me.txtSL.Text, ",", "", 1, -1, CompareMethod.Binary)), CShort(mdlVariable.gbytDECNUMQTY), ",")
						Me.txtDG.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Strings.Replace(Me.txtDG.Text, ",", "", 1, -1, CompareMethod.Binary)), CShort(mdlVariable.gbytDECNUM), ",")
					End If
				End If
				flag2 = Me.mbytFormStatus = 3
				If flag2 Then
					flag = (Operators.CompareString(Me.txtTT.Text, "", False) = 0) Or (Operators.CompareString(Me.txtSL.Text, "", False) = 0)
					If flag Then
						Me.txtTT.Text = ""
					Else
						Me.txtDG.Text = Conversions.ToString(Conversions.ToDouble(Strings.Replace(Me.txtTT.Text, ",", "", 1, -1, CompareMethod.Binary)) / Conversions.ToDouble(Strings.Replace(Me.txtSL.Text, ",", "", 1, -1, CompareMethod.Binary)))
						Me.txtTT.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Strings.Replace(Me.txtTT.Text, ",", "", 1, -1, CompareMethod.Binary)), CShort(mdlVariable.gbytDECNUM), ",")
						Me.txtSL.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Strings.Replace(Me.txtSL.Text, ",", "", 1, -1, CompareMethod.Binary)), CShort(mdlVariable.gbytDECNUMQTY), ",")
						Me.txtDG.Text = mdlUIForm.gfFormatNumber(Conversions.ToDouble(Strings.Replace(Me.txtDG.Text, ",", "", 1, -1, CompareMethod.Binary)), CShort(mdlVariable.gbytDECNUM), ",")
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTT_LostFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060017D2 RID: 6098 RVA: 0x001275AC File Offset: 0x001257AC
		Public Function fGetData_SDBDKHO(pstrMAKH As String, pstrMAHH As String, pstrMADVT As String) As Byte
			Dim flag As Boolean
			If Operators.CompareString(pstrMAKH, "", False) <> 0 AndAlso Operators.CompareString(pstrMAHH, "", False) <> 0 Then
				If Operators.CompareString(pstrMADVT, "", False) <> 0 Then
					flag = False
					GoTo IL_0034
				End If
			End If
			flag = True
			IL_0034:
			Dim flag2 As Boolean = flag
			Dim b As Byte
			If Not flag2 Then
				Dim clsConnect As clsConnect = New clsConnect()
				Dim array As SqlParameter() = New SqlParameter(4) {}
				Dim sqlCommand As SqlCommand = New SqlCommand()
				Try
					b = 0
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@gBytDecAmtUSD"
					array(0).Value = mdlVariable.gbytDECNUM
					array(1) = sqlCommand.CreateParameter()
					array(1).ParameterName = "@nchMAKH"
					array(1).Value = mdlVariable.gStrStockCode
					array(2) = sqlCommand.CreateParameter()
					array(2).ParameterName = "@nchMAHH"
					array(2).Value = Me.txtOBJID.Text.Trim()
					array(3) = sqlCommand.CreateParameter()
					array(3).ParameterName = "@nchMADVT"
					array(3).Value = Me.txtMADVT.Text.Trim()
					Dim num As Integer
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMSDBDKHO_GET_ONE_DATA", num)
					flag2 = num = 1 AndAlso clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
					If flag2 Then
						Me.txtSL.Text = clsConnect.Rows(0)("SOLUONG").ToString()
						Me.txtDG.Text = clsConnect.Rows(0)("DONGIA").ToString()
						Me.txtTT.Text = clsConnect.Rows(0)("THANHTIEN").ToString()
						Me.mtbOutDate.Text = clsConnect.Rows(0)("OUTDATE").ToString()
					Else
						Me.txtSL.Text = "0"
						Me.txtDG.Text = "0"
						Me.txtTT.Text = "0"
						Me.mtbOutDate.Text = "01/01/2100"
					End If
					b = 1
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
					clsConnect.Dispose()
				End Try
			End If
			Return b
		End Function

		' Token: 0x060017D3 RID: 6099 RVA: 0x0012788C File Offset: 0x00125A8C
		Private Function fAdd_SDBDKHO() As Byte
			Dim flag As Boolean = Conversion.Val(Strings.Replace(Strings.Trim(Me.txtSL.Text), ",", "", 1, -1, CompareMethod.Binary)) <= 0.0 OrElse Operators.CompareString(Me.txtMAKH.Text.Trim(), "", False) = 0
			Dim b As Byte
			If Not flag Then
				flag = mdlVariable.gblnSTOCKDATE
				If flag Then
					Dim text As String = Strings.Mid(Me.mtbOutDate.Text, 3, 1)
					Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtbOutDate.Text, text, "", 1, -1, CompareMethod.Binary))
					flag = Strings.Len(text2) > 0
					If flag Then
						text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtbOutDate.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtbOutDate.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtbOutDate.Text), 1, 2) })
						flag = Not Information.IsDate(text2)
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(85), MsgBoxStyle.Critical, Nothing)
							Me.mtbOutDate.Focus()
							Return b
						End If
					End If
				End If
				Dim clsConnect As clsConnect = New clsConnect()
				Dim sqlCommand As SqlCommand = New SqlCommand()
				Dim array As SqlParameter() = New SqlParameter(8) {}
				Try
					b = 0
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pnchMAKHO"
					array(0).Value = Strings.Trim(Me.txtMAKH.Text)
					array(1) = sqlCommand.CreateParameter()
					array(1).ParameterName = "@pnchMAHH"
					array(1).Value = Strings.Trim(Me.txtOBJID.Text)
					array(2) = sqlCommand.CreateParameter()
					array(2).ParameterName = "@pnchMALH"
					array(2).Value = "01"
					array(3) = sqlCommand.CreateParameter()
					array(3).ParameterName = "@pnchOUTDATE"
					array(3).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(mdlVariable.gblnSTOCKDATE, RuntimeHelpers.GetObjectValue(Interaction.IIf(Strings.Len(Strings.Trim(Me.mtbOutDate.Text)) > 4, Me.mtbOutDate.Text, "01/01/2100")), "01/01/2100"))
					array(4) = sqlCommand.CreateParameter()
					array(4).ParameterName = "@pnchQTY"
					array(4).Value = Conversion.Val(Strings.Replace(Strings.Trim(Me.txtSL.Text), ",", "", 1, -1, CompareMethod.Binary))
					array(5) = sqlCommand.CreateParameter()
					array(5).ParameterName = "@pnchDUNO"
					array(5).Value = Conversion.Val(Strings.Replace(Strings.Trim(Me.txtTT.Text), ",", "", 1, -1, CompareMethod.Binary))
					array(6) = sqlCommand.CreateParameter()
					array(6).ParameterName = "@pnchMADVT"
					array(6).Value = Me.txtMADVT.Text
					array(7) = sqlCommand.CreateParameter()
					array(7).ParameterName = "@int_Result"
					array(7).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMSDBDKHO_INS_UP_DMHH", flag2)
					Dim num As Integer = Conversions.ToInteger(array(7).Value)
					flag = num = 0
					If flag Then
						b = 1
					Else
						flag = num = 1
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(83), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKH.Focus()
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(84), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKH.Focus()
						End If
					End If
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAdd_SDBDKHO ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
					sqlCommand.Dispose()
					clsConnect.Dispose()
				End Try
			End If
			Return b
		End Function

		' Token: 0x060017D4 RID: 6100 RVA: 0x00127D4C File Offset: 0x00125F4C
		Private Function fDelete_SDBDKHO() As Byte
			Dim flag As Boolean = Operators.CompareString(mdlGeneral.gfCheck_Start("L"), "", False) <> 0
			Dim b As Byte
			If Not flag Then
				Dim clsConnect As clsConnect = New clsConnect()
				Dim sqlCommand As SqlCommand = New SqlCommand()
				Dim array As SqlParameter() = New SqlParameter(6) {}
				Try
					b = 0
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pnchMAKHO"
					array(0).Value = Strings.Trim(Me.txtMAKH.Text)
					array(1) = sqlCommand.CreateParameter()
					array(1).ParameterName = "@pnchMALH"
					array(1).Value = "01"
					array(2) = sqlCommand.CreateParameter()
					array(2).ParameterName = "@pnchMAHH"
					array(2).Value = Strings.Trim(Me.txtOBJID.Text)
					array(3) = sqlCommand.CreateParameter()
					array(3).ParameterName = "@pnchoutdate"
					array(3).Value = Strings.Trim(Me.mtbOutDate.Text)
					array(4) = sqlCommand.CreateParameter()
					array(4).ParameterName = "@pnchMADVT"
					array(4).Value = Strings.Trim(Me.txtMADVT.Text)
					array(5) = sqlCommand.CreateParameter()
					array(5).ParameterName = "@int_Result"
					array(5).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMSDBDKHO_DELETE_SDBDKHO", flag2)
					Dim num As Integer = Conversions.ToInteger(array(5).Value)
					flag = num = 0
					If flag Then
						b = 1
					Else
						flag = num = 1
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(83), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKH.Focus()
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(86), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKH.Focus()
						End If
					End If
				Catch ex As Exception
					b = 0
				Finally
					sqlCommand.Dispose()
					clsConnect.Dispose()
				End Try
			End If
			Return b
		End Function

		' Token: 0x060017D5 RID: 6101 RVA: 0x00127FF8 File Offset: 0x001261F8
		Private Function fRutGonTenHH(strInput As String) As String
			' The following expression was wrapped in a checked-statement
			Dim text As String
			Try
				text = ""
				Dim text2 As String = ""
				Dim array As String() = strInput.Split(New Char() { " "c })
				Dim num As Integer = 0
				Dim num2 As Integer = array.Length - 1
				Dim num3 As Integer = num
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						Exit For
					End If
					text2 += array(num3).Trim().Substring(0, 1)
					num3 += 1
				End While
				text = text2.Trim()
			Catch ex As Exception
				text = ""
			End Try
			Return text
		End Function

		' Token: 0x060017D6 RID: 6102 RVA: 0x00128088 File Offset: 0x00126288
		Private Sub btnTen_Click(sender As Object, e As EventArgs)
			Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
			frmKeyBoard.pStrEnterText = Me.txtOBJNAME.Text.Trim()
			frmKeyBoard.ShowDialog()
			Me.txtOBJNAME.Text = frmKeyBoard.pStrEnterText
			frmKeyBoard.Dispose()
		End Sub

		' Token: 0x060017D7 RID: 6103 RVA: 0x001280D4 File Offset: 0x001262D4
		Private Sub btnGia1_Click(sender As Object, e As EventArgs)
			Dim frmNumPad As frmNumPad = New frmNumPad()
			frmNumPad.ShowDialog()
			Dim flag As Boolean = frmNumPad.pbytSuccess = 1
			If flag Then
				Me.txtPRICE.Text = Conversions.ToString(frmNumPad.pSglNumberReturn)
			End If
			frmNumPad.Dispose()
		End Sub

		' Token: 0x060017D8 RID: 6104 RVA: 0x0012811C File Offset: 0x0012631C
		Private Sub btnPhieu_Click(sender As Object, e As EventArgs)
			Dim frmDMHH As frmDMHH1 = New frmDMHH1()
			frmDMHH.pBytOpen_From_Menu = 0
			frmDMHH.pStrOBJID = Me.txtPhieu.Text
			frmDMHH.ShowDialog()
			Me.txtPhieu.Text = frmDMHH.pStrOBJID.Trim()
		End Sub

		' Token: 0x060017D9 RID: 6105 RVA: 0x0012816C File Offset: 0x0012636C
		Private Sub txtOBJNAME_TextChanged(sender As Object, e As EventArgs)
			Dim gblnLTENHHPHURUTGON As Boolean = mdlVariable.gblnLTENHHPHURUTGON
			If gblnLTENHHPHURUTGON Then
				Me.txtSUBOBJNAME.Text = Me.fRutGonTenHH(Me.txtOBJNAME.Text.Trim())
			End If
		End Sub

		' Token: 0x060017DA RID: 6106 RVA: 0x001281A8 File Offset: 0x001263A8
		Private Sub txtbep4_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMBEP4 Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMBEP4.Columns("OBJID")
					Me.mclsTbDMBEP4.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMBEP4.Rows.Find(Strings.Trim(Me.txtbep4.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENBEP4.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENBEP4.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtbep4_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017DB RID: 6107 RVA: 0x001282FC File Offset: 0x001264FC
		Private Sub txtbep5_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMBEP5 Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMBEP5.Columns("OBJID")
					Me.mclsTbDMBEP5.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMBEP5.Rows.Find(Strings.Trim(Me.txtbep5.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENBEP5.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENBEP5.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtbep5_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017DC RID: 6108 RVA: 0x00128450 File Offset: 0x00126650
		Private Sub txtbep6_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMBEP6 Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMBEP6.Columns("OBJID")
					Me.mclsTbDMBEP6.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMBEP6.Rows.Find(Strings.Trim(Me.txtbep6.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENBEP6.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENBEP6.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtbep6_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017DD RID: 6109 RVA: 0x001285A4 File Offset: 0x001267A4
		Private Sub btnDMBEP4_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAYINBEP As frmDMMAYINBEP1 = New frmDMMAYINBEP1()
				frmDMMAYINBEP.pBytOpen_From_Menu = 7
				frmDMMAYINBEP.ShowDialog()
				Me.txtbep4.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtbep4.Text, frmDMMAYINBEP.pStrOBJID))
				Me.txtTENBEP4.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtTENBEP4.Text, frmDMMAYINBEP.pStrOBJNAME))
				frmDMMAYINBEP.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMBEP4_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017DE RID: 6110 RVA: 0x001286C8 File Offset: 0x001268C8
		Private Sub btnDMBEP5_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAYINBEP As frmDMMAYINBEP1 = New frmDMMAYINBEP1()
				frmDMMAYINBEP.pBytOpen_From_Menu = 7
				frmDMMAYINBEP.ShowDialog()
				Me.txtbep5.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtbep5.Text, frmDMMAYINBEP.pStrOBJID))
				Me.txtTENBEP5.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtTENBEP5.Text, frmDMMAYINBEP.pStrOBJNAME))
				frmDMMAYINBEP.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMBEP5_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017DF RID: 6111 RVA: 0x001287EC File Offset: 0x001269EC
		Private Sub btnDMBEP6_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAYINBEP As frmDMMAYINBEP1 = New frmDMMAYINBEP1()
				frmDMMAYINBEP.pBytOpen_From_Menu = 7
				frmDMMAYINBEP.ShowDialog()
				Me.txtbep6.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtbep6.Text, frmDMMAYINBEP.pStrOBJID))
				Me.txtTENBEP6.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAYINBEP.pStrOBJID, "", False) = 0, Me.txtTENBEP6.Text, frmDMMAYINBEP.pStrOBJNAME))
				frmDMMAYINBEP.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMBEP6_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017E0 RID: 6112 RVA: 0x00128910 File Offset: 0x00126B10
		Private Sub picAnh_Click(sender As Object, e As EventArgs)
			Try
				Dim frmselectimage As frmselectimage = New frmselectimage()
				frmselectimage.ShowDialog()
				Dim flag As Boolean = (frmselectimage.pstrPath.Length > 2) And (Operators.CompareString(frmselectimage.pstrPath, "none", False) <> 0)
				If flag Then
					Me.picAnh.BackgroundImage = frmselectimage.pimgImage
					Me.mstrUIMAGE = frmselectimage.pstrPath.Trim()
				End If
				flag = Operators.CompareString(frmselectimage.pstrPath, "none", False) = 0
				If flag Then
					Me.picAnh.BackgroundImage = frmselectimage.pimgImage
					Me.mstrUIMAGE = ""
				End If
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060017E1 RID: 6113 RVA: 0x001289D4 File Offset: 0x00126BD4
		Private Sub picAnh_MouseHover(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.mstrUIMAGE Is Nothing OrElse Me.mstrUIMAGE.Length <= 1
			If Not flag Then
				Me.picZoom.BackgroundImage = Me.picAnh.BackgroundImage
				Me.picZoom.Visible = True
			End If
		End Sub

		' Token: 0x060017E2 RID: 6114 RVA: 0x0000585C File Offset: 0x00003A5C
		Private Sub picAnh_MouseLeave(sender As Object, e As EventArgs)
			Me.picZoom.Visible = False
		End Sub

		' Token: 0x060017E3 RID: 6115 RVA: 0x00128A2C File Offset: 0x00126C2C
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x060017E4 RID: 6116 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x060017E5 RID: 6117 RVA: 0x00128AA8 File Offset: 0x00126CA8
		Private Sub txtOBJID_TextChanged(sender As Object, e As EventArgs)
			Try
				Me.txtOBJID_2.Text = Me.txtOBJID.Text
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017E6 RID: 6118 RVA: 0x0000586D File Offset: 0x00003A6D
		Private Sub sHienThiTieuDeTiLeDVT()
			Me.lblTiLeDVT.Text = "1 " + Me.txtTENDVTDG.Text.Trim() + " = ? " + Me.txtTENDVT.Text
		End Sub

		' Token: 0x060017E7 RID: 6119 RVA: 0x00128B50 File Offset: 0x00126D50
		Private Sub txtMADVTDG_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMDVT Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMDVT.Columns("OBJID")
					Me.mclsTbDMDVT.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMDVT.Rows.Find(Strings.Trim(Me.txtMADVTDG.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENDVTDG.Text = dataRow("OBJNAME").ToString() + "  " + dataRow("SUBOBJNAME").ToString().Trim()
					Else
						Me.txtTENDVTDG.Text = ""
					End If
					Me.sHienThiTieuDeTiLeDVT()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADVTDG_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017E8 RID: 6120 RVA: 0x00128CC8 File Offset: 0x00126EC8
		Private Sub btnDVTDG_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDVT As frmDMDVT1 = New frmDMDVT1()
				frmDMDVT.pBytOpen_From_Menu = 7
				frmDMDVT.ShowDialog()
				Me.txtMADVTDG.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDVT.pStrOBJID, "", False) = 0, Me.txtMADVTDG.Text, frmDMDVT.pStrOBJID))
				Me.txtTENDVTDG.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDVT.pStrOBJID, "", False) = 0, Me.txtTENDVTDG.Text, frmDMDVT.pStrOBJNAME))
				Me.sHienThiTieuDeTiLeDVT()
				frmDMDVT.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDVTDG_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060017E9 RID: 6121 RVA: 0x00128DF4 File Offset: 0x00126FF4
		Private Sub chkLopen_CheckedChanged(sender As Object, e As EventArgs)
			Try
				Dim checked As Boolean = Me.chkLopen.Checked
				If checked Then
					Me.chkLAmtOpen.Checked = False
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkLopen_CheckedChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060017EA RID: 6122 RVA: 0x00128E94 File Offset: 0x00127094
		Private Sub chkLAmtopen_CheckedChanged(sender As Object, e As EventArgs)
			Try
				Dim checked As Boolean = Me.chkLAmtOpen.Checked
				If checked Then
					Me.chkLopen.Checked = False
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkLAmtopen_CheckedChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060017EB RID: 6123 RVA: 0x00128F34 File Offset: 0x00127134
		Private Function gf_AcceptOnlyNumber(Obj As Object, ev As KeyPressEventArgs) As KeyPressEventArgs
			Try
				Dim text As String = "0123456789.,"
				Dim flag As Boolean = ev.KeyChar <> vbBack
				If flag Then
					Dim flag2 As Boolean = Strings.InStr(text, Conversions.ToString(Strings.Chr(CInt(ev.KeyChar))), CompareMethod.Binary) = 0
					If flag2 Then
						ev.KeyChar = vbNullChar
						Return ev
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - gfFomular_2_Num" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			End Try
			Return ev
		End Function

		' Token: 0x060017EC RID: 6124 RVA: 0x00128FD0 File Offset: 0x001271D0
		Private Sub txtHOAHONG_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad = New frmNumPad()
				frmNumPad.pblnString = True
				frmNumPad.ShowDialog()
				Dim flag As Boolean = frmNumPad.pbytSuccess = 1
				If flag Then
					Me.txtHOAHONG.Text = mdlUIForm.gfFormatNumber(CDbl(frmNumPad.pSglNumberReturn), 3S, ",")
					Dim num As Double = Conversion.Val(Me.txtPRICE.Text.Replace(",", ""))
					Dim num2 As Double = Conversion.Val(Me.txtHOAHONG.Text.Replace(",", ""))
					Dim num3 As Double = num * (num2 / 100.0)
					Me.txtTienHoaHong.Text = mdlUIForm.gfFormatNumber(num3, CShort(mdlVariable.gbytDECNUMAMT), ",")
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - txtHOAHONG_Click" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060017ED RID: 6125 RVA: 0x001290D4 File Offset: 0x001272D4
		Private Sub txtTienHoaHong_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad = New frmNumPad()
				frmNumPad.ShowDialog()
				Dim flag As Boolean = frmNumPad.pbytSuccess = 1
				If flag Then
					Me.txtTienHoaHong.Text = mdlUIForm.gfFormatNumber(CDbl(frmNumPad.pSglNumberReturn), CShort(mdlVariable.gbytDECNUMAMT), ",")
					Dim num As Double = Conversion.Val(Me.txtPRICE.Text.Replace(",", ""))
					Dim num2 As Double = Conversion.Val(Me.txtTienHoaHong.Text.Replace(",", ""))
					Dim num3 As Double = num2 * 100.0 / num
					Me.txtHOAHONG.Text = mdlUIForm.gfFormatNumber(num3, 3S, ",")
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - txtTienHoaHong_Click" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060017EE RID: 6126 RVA: 0x001291D0 File Offset: 0x001273D0
		Private Sub txtPRICE_TextChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Versioned.IsNumeric(Me.txtPRICE.Text.Replace(",", ""))
				If flag Then
					Dim num As Double = Conversion.Val(Me.txtPRICE.Text.Replace(",", ""))
					Dim num2 As Double = Conversion.Val(Me.txtHOAHONG.Text.Replace(",", ""))
					Dim num3 As Double = num * (num2 / 100.0)
					Me.txtTienHoaHong.Text = mdlUIForm.gfFormatNumber(num3, CShort(mdlVariable.gbytDECNUMAMT), ",")
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - txtPRICE_TextChanged" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0400091E RID: 2334
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000920 RID: 2336
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000921 RID: 2337
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000922 RID: 2338
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000923 RID: 2339
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000924 RID: 2340
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000925 RID: 2341
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000926 RID: 2342
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000927 RID: 2343
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000928 RID: 2344
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000929 RID: 2345
		<AccessedThroughProperty("txtMADVT")>
		Private _txtMADVT As TextBox

		' Token: 0x0400092A RID: 2346
		<AccessedThroughProperty("lblDVT")>
		Private _lblDVT As Label

		' Token: 0x0400092B RID: 2347
		<AccessedThroughProperty("lblMANH")>
		Private _lblMANH As Label

		' Token: 0x0400092C RID: 2348
		<AccessedThroughProperty("txtMAMT")>
		Private _txtMAMT As TextBox

		' Token: 0x0400092D RID: 2349
		<AccessedThroughProperty("btnDMMT")>
		Private _btnDMMT As Button

		' Token: 0x0400092E RID: 2350
		<AccessedThroughProperty("txtTENMT")>
		Private _txtTENMT As TextBox

		' Token: 0x0400092F RID: 2351
		<AccessedThroughProperty("chkLSAVE")>
		Private _chkLSAVE As CheckBox

		' Token: 0x04000930 RID: 2352
		<AccessedThroughProperty("lblMAMT")>
		Private _lblMAMT As Label

		' Token: 0x04000931 RID: 2353
		<AccessedThroughProperty("lblLSAVE")>
		Private _lblLSAVE As Label

		' Token: 0x04000932 RID: 2354
		<AccessedThroughProperty("txtMANH")>
		Private _txtMANH As TextBox

		' Token: 0x04000933 RID: 2355
		<AccessedThroughProperty("btnDMNH")>
		Private _btnDMNH As Button

		' Token: 0x04000934 RID: 2356
		<AccessedThroughProperty("txtTENNH")>
		Private _txtTENNH As TextBox

		' Token: 0x04000935 RID: 2357
		<AccessedThroughProperty("txtREMARK")>
		Private _txtREMARK As TextBox

		' Token: 0x04000936 RID: 2358
		<AccessedThroughProperty("lblREMARK")>
		Private _lblREMARK As Label

		' Token: 0x04000937 RID: 2359
		<AccessedThroughProperty("lblSUBOBJNAME")>
		Private _lblSUBOBJNAME As Label

		' Token: 0x04000938 RID: 2360
		<AccessedThroughProperty("txtSUBOBJNAME")>
		Private _txtSUBOBJNAME As TextBox

		' Token: 0x04000939 RID: 2361
		<AccessedThroughProperty("lblMAPL")>
		Private _lblMAPL As Label

		' Token: 0x0400093A RID: 2362
		<AccessedThroughProperty("txtTENPL")>
		Private _txtTENPL As TextBox

		' Token: 0x0400093B RID: 2363
		<AccessedThroughProperty("btnMAPL")>
		Private _btnMAPL As Button

		' Token: 0x0400093C RID: 2364
		<AccessedThroughProperty("txtMAPL")>
		Private _txtMAPL As TextBox

		' Token: 0x0400093D RID: 2365
		<AccessedThroughProperty("lblMANSX")>
		Private _lblMANSX As Label

		' Token: 0x0400093E RID: 2366
		<AccessedThroughProperty("txtTENNSX")>
		Private _txtTENNSX As TextBox

		' Token: 0x0400093F RID: 2367
		<AccessedThroughProperty("btnMANSX")>
		Private _btnMANSX As Button

		' Token: 0x04000940 RID: 2368
		<AccessedThroughProperty("txtMANSX")>
		Private _txtMANSX As TextBox

		' Token: 0x04000941 RID: 2369
		<AccessedThroughProperty("lblPRICE")>
		Private _lblPRICE As Label

		' Token: 0x04000942 RID: 2370
		<AccessedThroughProperty("txtPRICE")>
		Private _txtPRICE As TextBox

		' Token: 0x04000943 RID: 2371
		<AccessedThroughProperty("lblPRICE2")>
		Private _lblPRICE2 As Label

		' Token: 0x04000944 RID: 2372
		<AccessedThroughProperty("txtPRICE2")>
		Private _txtPRICE2 As TextBox

		' Token: 0x04000945 RID: 2373
		<AccessedThroughProperty("lblPRICE3")>
		Private _lblPRICE3 As Label

		' Token: 0x04000946 RID: 2374
		<AccessedThroughProperty("txtPRICE3")>
		Private _txtPRICE3 As TextBox

		' Token: 0x04000947 RID: 2375
		<AccessedThroughProperty("lblPRICE6")>
		Private _lblPRICE6 As Label

		' Token: 0x04000948 RID: 2376
		<AccessedThroughProperty("txtPRICE6")>
		Private _txtPRICE6 As TextBox

		' Token: 0x04000949 RID: 2377
		<AccessedThroughProperty("lblPRICE5")>
		Private _lblPRICE5 As Label

		' Token: 0x0400094A RID: 2378
		<AccessedThroughProperty("txtPRICE5")>
		Private _txtPRICE5 As TextBox

		' Token: 0x0400094B RID: 2379
		<AccessedThroughProperty("lblPRICE4")>
		Private _lblPRICE4 As Label

		' Token: 0x0400094C RID: 2380
		<AccessedThroughProperty("txtPRICE4")>
		Private _txtPRICE4 As TextBox

		' Token: 0x0400094D RID: 2381
		<AccessedThroughProperty("lblPRICE9")>
		Private _lblPRICE9 As Label

		' Token: 0x0400094E RID: 2382
		<AccessedThroughProperty("txtPRICE9")>
		Private _txtPRICE9 As TextBox

		' Token: 0x0400094F RID: 2383
		<AccessedThroughProperty("lblPRICE8")>
		Private _lblPRICE8 As Label

		' Token: 0x04000950 RID: 2384
		<AccessedThroughProperty("txtPRICE8")>
		Private _txtPRICE8 As TextBox

		' Token: 0x04000951 RID: 2385
		<AccessedThroughProperty("lblPRICE7")>
		Private _lblPRICE7 As Label

		' Token: 0x04000952 RID: 2386
		<AccessedThroughProperty("txtPRICE7")>
		Private _txtPRICE7 As TextBox

		' Token: 0x04000953 RID: 2387
		<AccessedThroughProperty("lblPRICE10")>
		Private _lblPRICE10 As Label

		' Token: 0x04000954 RID: 2388
		<AccessedThroughProperty("txtPRICE10")>
		Private _txtPRICE10 As TextBox

		' Token: 0x04000955 RID: 2389
		<AccessedThroughProperty("panMain")>
		Private _panMain As Panel

		' Token: 0x04000956 RID: 2390
		<AccessedThroughProperty("panMAMT")>
		Private _panMAMT As Panel

		' Token: 0x04000957 RID: 2391
		<AccessedThroughProperty("panMAPL_MANSX")>
		Private _panMAPL_MANSX As Panel

		' Token: 0x04000958 RID: 2392
		<AccessedThroughProperty("panLMATERIAL")>
		Private _panLMATERIAL As Panel

		' Token: 0x04000959 RID: 2393
		<AccessedThroughProperty("panPRICE")>
		Private _panPRICE As Panel

		' Token: 0x0400095A RID: 2394
		<AccessedThroughProperty("panPRICE2_3_4")>
		Private _panPRICE2_3_4 As Panel

		' Token: 0x0400095B RID: 2395
		<AccessedThroughProperty("panPRICE5_6_7")>
		Private _panPRICE5_6_7 As Panel

		' Token: 0x0400095C RID: 2396
		<AccessedThroughProperty("panPRICE8_9_10")>
		Private _panPRICE8_9_10 As Panel

		' Token: 0x0400095D RID: 2397
		<AccessedThroughProperty("panLSALE")>
		Private _panLSALE As Panel

		' Token: 0x0400095E RID: 2398
		<AccessedThroughProperty("panButton")>
		Private _panButton As Panel

		' Token: 0x0400095F RID: 2399
		<AccessedThroughProperty("chkLMATERIAL")>
		Private _chkLMATERIAL As CheckBox

		' Token: 0x04000960 RID: 2400
		<AccessedThroughProperty("lblLMATERIAL")>
		Private _lblLMATERIAL As Label

		' Token: 0x04000961 RID: 2401
		<AccessedThroughProperty("panREMARK")>
		Private _panREMARK As Panel

		' Token: 0x04000962 RID: 2402
		<AccessedThroughProperty("lblMADC")>
		Private _lblMADC As Label

		' Token: 0x04000963 RID: 2403
		<AccessedThroughProperty("txtMADC")>
		Private _txtMADC As TextBox

		' Token: 0x04000964 RID: 2404
		<AccessedThroughProperty("btnMADC")>
		Private _btnMADC As Button

		' Token: 0x04000965 RID: 2405
		<AccessedThroughProperty("txtTENDC")>
		Private _txtTENDC As TextBox

		' Token: 0x04000966 RID: 2406
		<AccessedThroughProperty("txtTENDVT")>
		Private _txtTENDVT As TextBox

		' Token: 0x04000967 RID: 2407
		<AccessedThroughProperty("btnDVT")>
		Private _btnDVT As Button

		' Token: 0x04000968 RID: 2408
		<AccessedThroughProperty("txtMADV")>
		Private _txtMADV As TextBox

		' Token: 0x04000969 RID: 2409
		<AccessedThroughProperty("txtTENDV")>
		Private _txtTENDV As TextBox

		' Token: 0x0400096A RID: 2410
		<AccessedThroughProperty("btnDMDV")>
		Private _btnDMDV As Button

		' Token: 0x0400096B RID: 2411
		<AccessedThroughProperty("lblMADV")>
		Private _lblMADV As Label

		' Token: 0x0400096C RID: 2412
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x0400096D RID: 2413
		<AccessedThroughProperty("lblbep3")>
		Private _lblbep3 As Label

		' Token: 0x0400096E RID: 2414
		<AccessedThroughProperty("txtbep3")>
		Private _txtbep3 As TextBox

		' Token: 0x0400096F RID: 2415
		<AccessedThroughProperty("btnDMBEP3")>
		Private _btnDMBEP3 As Button

		' Token: 0x04000970 RID: 2416
		<AccessedThroughProperty("txtTENBEP3")>
		Private _txtTENBEP3 As TextBox

		' Token: 0x04000971 RID: 2417
		<AccessedThroughProperty("lblbep2")>
		Private _lblbep2 As Label

		' Token: 0x04000972 RID: 2418
		<AccessedThroughProperty("txtbep2")>
		Private _txtbep2 As TextBox

		' Token: 0x04000973 RID: 2419
		<AccessedThroughProperty("btnDMBEP2")>
		Private _btnDMBEP2 As Button

		' Token: 0x04000974 RID: 2420
		<AccessedThroughProperty("txtTENBEP2")>
		Private _txtTENBEP2 As TextBox

		' Token: 0x04000975 RID: 2421
		<AccessedThroughProperty("lblbep1")>
		Private _lblbep1 As Label

		' Token: 0x04000976 RID: 2422
		<AccessedThroughProperty("txtbep1")>
		Private _txtbep1 As TextBox

		' Token: 0x04000977 RID: 2423
		<AccessedThroughProperty("btnDMBEP1")>
		Private _btnDMBEP1 As Button

		' Token: 0x04000978 RID: 2424
		<AccessedThroughProperty("txtTENBEP1")>
		Private _txtTENBEP1 As TextBox

		' Token: 0x04000979 RID: 2425
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x0400097A RID: 2426
		<AccessedThroughProperty("chkLopen")>
		Private _chkLopen As CheckBox

		' Token: 0x0400097B RID: 2427
		<AccessedThroughProperty("chkStopUse")>
		Private _chkStopUse As CheckBox

		' Token: 0x0400097C RID: 2428
		<AccessedThroughProperty("lblStop")>
		Private _lblStop As Label

		' Token: 0x0400097D RID: 2429
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x0400097E RID: 2430
		<AccessedThroughProperty("chkCOMBO")>
		Private _chkCOMBO As CheckBox

		' Token: 0x0400097F RID: 2431
		<AccessedThroughProperty("txtCOMBO")>
		Private _txtCOMBO As TextBox

		' Token: 0x04000980 RID: 2432
		<AccessedThroughProperty("btnCOMBO")>
		Private _btnCOMBO As Button

		' Token: 0x04000981 RID: 2433
		<AccessedThroughProperty("grbTONKHO")>
		Private _grbTONKHO As GroupBox

		' Token: 0x04000982 RID: 2434
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x04000983 RID: 2435
		<AccessedThroughProperty("txtMAKH")>
		Private _txtMAKH As TextBox

		' Token: 0x04000984 RID: 2436
		<AccessedThroughProperty("btnDMKH")>
		Private _btnDMKH As Button

		' Token: 0x04000985 RID: 2437
		<AccessedThroughProperty("txtTENKH")>
		Private _txtTENKH As TextBox

		' Token: 0x04000986 RID: 2438
		<AccessedThroughProperty("Label6")>
		Private _Label6 As Label

		' Token: 0x04000987 RID: 2439
		<AccessedThroughProperty("txtTT")>
		Private _txtTT As TextBox

		' Token: 0x04000988 RID: 2440
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x04000989 RID: 2441
		<AccessedThroughProperty("txtDG")>
		Private _txtDG As TextBox

		' Token: 0x0400098A RID: 2442
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x0400098B RID: 2443
		<AccessedThroughProperty("txtSL")>
		Private _txtSL As TextBox

		' Token: 0x0400098C RID: 2444
		<AccessedThroughProperty("lblOUTDATE")>
		Private _lblOUTDATE As Label

		' Token: 0x0400098D RID: 2445
		<AccessedThroughProperty("mtbOutDate")>
		Private _mtbOutDate As MaskedTextBox

		' Token: 0x0400098E RID: 2446
		<AccessedThroughProperty("btnTen")>
		Private _btnTen As Button

		' Token: 0x0400098F RID: 2447
		<AccessedThroughProperty("btnGia1")>
		Private _btnGia1 As Button

		' Token: 0x04000990 RID: 2448
		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		' Token: 0x04000991 RID: 2449
		<AccessedThroughProperty("txtPURSE")>
		Private _txtPURSE As TextBox

		' Token: 0x04000992 RID: 2450
		<AccessedThroughProperty("Label8")>
		Private _Label8 As Label

		' Token: 0x04000993 RID: 2451
		<AccessedThroughProperty("chkLSETCOMBO")>
		Private _chkLSETCOMBO As CheckBox

		' Token: 0x04000994 RID: 2452
		<AccessedThroughProperty("Label9")>
		Private _Label9 As Label

		' Token: 0x04000995 RID: 2453
		<AccessedThroughProperty("chkLTON_KHACHHANG")>
		Private _chkLTON_KHACHHANG As CheckBox

		' Token: 0x04000996 RID: 2454
		<AccessedThroughProperty("txtPhieu")>
		Private _txtPhieu As TextBox

		' Token: 0x04000997 RID: 2455
		<AccessedThroughProperty("btnPhieu")>
		Private _btnPhieu As Button

		' Token: 0x04000998 RID: 2456
		<AccessedThroughProperty("Label10")>
		Private _Label10 As Label

		' Token: 0x04000999 RID: 2457
		<AccessedThroughProperty("lblbep5")>
		Private _lblbep5 As Label

		' Token: 0x0400099A RID: 2458
		<AccessedThroughProperty("txtbep5")>
		Private _txtbep5 As TextBox

		' Token: 0x0400099B RID: 2459
		<AccessedThroughProperty("btnDMBEP5")>
		Private _btnDMBEP5 As Button

		' Token: 0x0400099C RID: 2460
		<AccessedThroughProperty("txtTENBEP5")>
		Private _txtTENBEP5 As TextBox

		' Token: 0x0400099D RID: 2461
		<AccessedThroughProperty("lblbep4")>
		Private _lblbep4 As Label

		' Token: 0x0400099E RID: 2462
		<AccessedThroughProperty("txtbep4")>
		Private _txtbep4 As TextBox

		' Token: 0x0400099F RID: 2463
		<AccessedThroughProperty("btnDMBEP4")>
		Private _btnDMBEP4 As Button

		' Token: 0x040009A0 RID: 2464
		<AccessedThroughProperty("txtTENBEP4")>
		Private _txtTENBEP4 As TextBox

		' Token: 0x040009A1 RID: 2465
		<AccessedThroughProperty("Label11")>
		Private _Label11 As Label

		' Token: 0x040009A2 RID: 2466
		<AccessedThroughProperty("lblbep6")>
		Private _lblbep6 As Label

		' Token: 0x040009A3 RID: 2467
		<AccessedThroughProperty("txtbep6")>
		Private _txtbep6 As TextBox

		' Token: 0x040009A4 RID: 2468
		<AccessedThroughProperty("btnDMBEP6")>
		Private _btnDMBEP6 As Button

		' Token: 0x040009A5 RID: 2469
		<AccessedThroughProperty("txtTENBEP6")>
		Private _txtTENBEP6 As TextBox

		' Token: 0x040009A6 RID: 2470
		<AccessedThroughProperty("picAnh")>
		Private _picAnh As PictureBox

		' Token: 0x040009A7 RID: 2471
		<AccessedThroughProperty("picZoom")>
		Private _picZoom As PictureBox

		' Token: 0x040009A8 RID: 2472
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x040009A9 RID: 2473
		<AccessedThroughProperty("Label12")>
		Private _Label12 As Label

		' Token: 0x040009AA RID: 2474
		<AccessedThroughProperty("chkLComboPrice")>
		Private _chkLComboPrice As CheckBox

		' Token: 0x040009AB RID: 2475
		<AccessedThroughProperty("txtOBJID_2")>
		Private _txtOBJID_2 As TextBox

		' Token: 0x040009AC RID: 2476
		<AccessedThroughProperty("lblOBJID_2")>
		Private _lblOBJID_2 As Label

		' Token: 0x040009AD RID: 2477
		<AccessedThroughProperty("txtBuocNhayGia")>
		Private _txtBuocNhayGia As TextBox

		' Token: 0x040009AE RID: 2478
		<AccessedThroughProperty("lblBuocNhayGia")>
		Private _lblBuocNhayGia As Label

		' Token: 0x040009AF RID: 2479
		<AccessedThroughProperty("txtMADVTDG")>
		Private _txtMADVTDG As TextBox

		' Token: 0x040009B0 RID: 2480
		<AccessedThroughProperty("txtTENDVTDG")>
		Private _txtTENDVTDG As TextBox

		' Token: 0x040009B1 RID: 2481
		<AccessedThroughProperty("btnDVTDG")>
		Private _btnDVTDG As Button

		' Token: 0x040009B2 RID: 2482
		<AccessedThroughProperty("lblDVTDG")>
		Private _lblDVTDG As Label

		' Token: 0x040009B3 RID: 2483
		<AccessedThroughProperty("GroupBox2")>
		Private _GroupBox2 As GroupBox

		' Token: 0x040009B4 RID: 2484
		<AccessedThroughProperty("txtTiLeDVT")>
		Private _txtTiLeDVT As TextBox

		' Token: 0x040009B5 RID: 2485
		<AccessedThroughProperty("lblTiLeDVT")>
		Private _lblTiLeDVT As Label

		' Token: 0x040009B6 RID: 2486
		<AccessedThroughProperty("GroupBox1")>
		Private _GroupBox1 As GroupBox

		' Token: 0x040009B7 RID: 2487
		<AccessedThroughProperty("Label13")>
		Private _Label13 As Label

		' Token: 0x040009B8 RID: 2488
		<AccessedThroughProperty("txtTHOIKHOANG")>
		Private _txtTHOIKHOANG As TextBox

		' Token: 0x040009B9 RID: 2489
		<AccessedThroughProperty("Label16")>
		Private _Label16 As Label

		' Token: 0x040009BA RID: 2490
		<AccessedThroughProperty("Label14")>
		Private _Label14 As Label

		' Token: 0x040009BB RID: 2491
		<AccessedThroughProperty("txtHOAHONG")>
		Private _txtHOAHONG As TextBox

		' Token: 0x040009BC RID: 2492
		<AccessedThroughProperty("Label15")>
		Private _Label15 As Label

		' Token: 0x040009BD RID: 2493
		<AccessedThroughProperty("txtBuocNhayMa")>
		Private _txtBuocNhayMa As TextBox

		' Token: 0x040009BE RID: 2494
		<AccessedThroughProperty("lblBuocNhayMa")>
		Private _lblBuocNhayMa As Label

		' Token: 0x040009BF RID: 2495
		<AccessedThroughProperty("GroupBox3")>
		Private _GroupBox3 As GroupBox

		' Token: 0x040009C0 RID: 2496
		<AccessedThroughProperty("Label17")>
		Private _Label17 As Label

		' Token: 0x040009C1 RID: 2497
		<AccessedThroughProperty("txtScore")>
		Private _txtScore As TextBox

		' Token: 0x040009C2 RID: 2498
		<AccessedThroughProperty("panMAMT2")>
		Private _panMAMT2 As Panel

		' Token: 0x040009C3 RID: 2499
		<AccessedThroughProperty("txtMAMT2")>
		Private _txtMAMT2 As TextBox

		' Token: 0x040009C4 RID: 2500
		<AccessedThroughProperty("txtTENMT2")>
		Private _txtTENMT2 As TextBox

		' Token: 0x040009C5 RID: 2501
		<AccessedThroughProperty("btnDMMT2")>
		Private _btnDMMT2 As Button

		' Token: 0x040009C6 RID: 2502
		<AccessedThroughProperty("Label18")>
		Private _Label18 As Label

		' Token: 0x040009C7 RID: 2503
		<AccessedThroughProperty("Label19")>
		Private _Label19 As Label

		' Token: 0x040009C8 RID: 2504
		<AccessedThroughProperty("chkLQTYMain")>
		Private _chkLQTYMain As CheckBox

		' Token: 0x040009C9 RID: 2505
		<AccessedThroughProperty("Label20")>
		Private _Label20 As Label

		' Token: 0x040009CA RID: 2506
		<AccessedThroughProperty("chkLAmtOpen")>
		Private _chkLAmtOpen As CheckBox

		' Token: 0x040009CB RID: 2507
		<AccessedThroughProperty("Label21")>
		Private _Label21 As Label

		' Token: 0x040009CC RID: 2508
		<AccessedThroughProperty("chkLSerial")>
		Private _chkLSerial As CheckBox

		' Token: 0x040009CD RID: 2509
		<AccessedThroughProperty("txtTienHoaHong")>
		Private _txtTienHoaHong As TextBox

		' Token: 0x040009CE RID: 2510
		<AccessedThroughProperty("Label22")>
		Private _Label22 As Label

		' Token: 0x040009CF RID: 2511
		<AccessedThroughProperty("chkLQtyLe")>
		Private _chkLQtyLe As CheckBox

		' Token: 0x040009D0 RID: 2512
		Private mArrStrFrmMess As String()

		' Token: 0x040009D1 RID: 2513
		Private mbytFormStatus As Byte

		' Token: 0x040009D2 RID: 2514
		Private mbytSuccess As Byte

		' Token: 0x040009D3 RID: 2515
		Private mStrFilter As String

		' Token: 0x040009D4 RID: 2516
		Private mclsTbDMMT As clsConnect

		' Token: 0x040009D5 RID: 2517
		Private mclsTbDMNH As clsConnect

		' Token: 0x040009D6 RID: 2518
		Private mclsTbDMPL As clsConnect

		' Token: 0x040009D7 RID: 2519
		Private mclsTbDMNSX As clsConnect

		' Token: 0x040009D8 RID: 2520
		Private mclsTbDMDVT As clsConnect

		' Token: 0x040009D9 RID: 2521
		Private mclsTbDMDV As clsConnect

		' Token: 0x040009DA RID: 2522
		Private mclsTbDMKH As clsConnect

		' Token: 0x040009DB RID: 2523
		Private mclsTbDMBEP1 As clsConnect

		' Token: 0x040009DC RID: 2524
		Private mclsTbDMBEP2 As clsConnect

		' Token: 0x040009DD RID: 2525
		Private mclsTbDMBEP3 As clsConnect

		' Token: 0x040009DE RID: 2526
		Private mclsTbDMBEP4 As clsConnect

		' Token: 0x040009DF RID: 2527
		Private mclsTbDMBEP5 As clsConnect

		' Token: 0x040009E0 RID: 2528
		Private mclsTbDMBEP6 As clsConnect

		' Token: 0x040009E1 RID: 2529
		Private mstrUIMAGE As String

		' Token: 0x040009E2 RID: 2530
		Private mblnFistLoad As Boolean

		' Token: 0x040009E3 RID: 2531
		Private mBlnAutoDel As Boolean

		' Token: 0x040009E4 RID: 2532
		Private mbytLen_OBJID As Byte

		' Token: 0x040009E5 RID: 2533
		Private mblnFIXMAHH As Boolean

		' Token: 0x040009E6 RID: 2534
		Private mBlnModifyMulti As Boolean

		' Token: 0x040009E7 RID: 2535
		Private mbytNUMPRICE As Byte

		' Token: 0x040009E8 RID: 2536
		Private Const mconStrStockDate As String = "01/01/2100"

		' Token: 0x040009E9 RID: 2537
		Private mstrMaHH_Copy As String

		' Token: 0x040009EA RID: 2538
		Private mArrStrSelectCombo As mdlVariable.struSelectCombo()
	End Class
End Namespace
