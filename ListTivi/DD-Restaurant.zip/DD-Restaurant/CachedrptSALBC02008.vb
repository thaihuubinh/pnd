﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000308 RID: 776
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptSALBC02008
		Inherits Component
		Implements ICachedReport

		' Token: 0x060070B3 RID: 28851 RVA: 0x00013EA7 File Offset: 0x000120A7
		Public Sub New()
			CachedrptSALBC02008.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002F3A RID: 12090
		' (get) Token: 0x060070B4 RID: 28852 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060070B5 RID: 28853 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002F3B RID: 12091
		' (get) Token: 0x060070B6 RID: 28854 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060070B7 RID: 28855 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002F3C RID: 12092
		' (get) Token: 0x060070B8 RID: 28856 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060070B9 RID: 28857 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x060070BA RID: 28858 RVA: 0x004DF344 File Offset: 0x004DD544
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptSALBC02008() With { .Site = Me.Site }
		End Function

		' Token: 0x060070BB RID: 28859 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002900 RID: 10496
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
