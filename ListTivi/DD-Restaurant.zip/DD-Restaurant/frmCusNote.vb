﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200002C RID: 44
	<DesignerGenerated()>
	Public Partial Class frmCusNote
		Inherits Form

		' Token: 0x06000872 RID: 2162 RVA: 0x00062108 File Offset: 0x00060308
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmCusNote_FormClosing
			AddHandler MyBase.KeyPress, AddressOf Me.frmCusNote_KeyPress
			AddHandler MyBase.Load, AddressOf Me.frmCusNote_Load
			frmCusNote.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mbdsSourceDMDV = New BindingSource()
			Me.mintPosDV = 0
			Me.mstrFilterPrint = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000331 RID: 817
		' (get) Token: 0x06000875 RID: 2165 RVA: 0x00063C10 File Offset: 0x00061E10
		' (set) Token: 0x06000876 RID: 2166 RVA: 0x0000373D File Offset: 0x0000193D
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000332 RID: 818
		' (get) Token: 0x06000877 RID: 2167 RVA: 0x00063C28 File Offset: 0x00061E28
		' (set) Token: 0x06000878 RID: 2168 RVA: 0x00063C40 File Offset: 0x00061E40
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x17000333 RID: 819
		' (get) Token: 0x06000879 RID: 2169 RVA: 0x00063CAC File Offset: 0x00061EAC
		' (set) Token: 0x0600087A RID: 2170 RVA: 0x00063CC4 File Offset: 0x00061EC4
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000334 RID: 820
		' (get) Token: 0x0600087B RID: 2171 RVA: 0x00063D30 File Offset: 0x00061F30
		' (set) Token: 0x0600087C RID: 2172 RVA: 0x00063D48 File Offset: 0x00061F48
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000335 RID: 821
		' (get) Token: 0x0600087D RID: 2173 RVA: 0x00063DB4 File Offset: 0x00061FB4
		' (set) Token: 0x0600087E RID: 2174 RVA: 0x00063DCC File Offset: 0x00061FCC
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000336 RID: 822
		' (get) Token: 0x0600087F RID: 2175 RVA: 0x00063E38 File Offset: 0x00062038
		' (set) Token: 0x06000880 RID: 2176 RVA: 0x00063E50 File Offset: 0x00062050
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000337 RID: 823
		' (get) Token: 0x06000881 RID: 2177 RVA: 0x00063EBC File Offset: 0x000620BC
		' (set) Token: 0x06000882 RID: 2178 RVA: 0x00063ED4 File Offset: 0x000620D4
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000338 RID: 824
		' (get) Token: 0x06000883 RID: 2179 RVA: 0x00063F40 File Offset: 0x00062140
		' (set) Token: 0x06000884 RID: 2180 RVA: 0x00063F58 File Offset: 0x00062158
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000339 RID: 825
		' (get) Token: 0x06000885 RID: 2181 RVA: 0x00063FC4 File Offset: 0x000621C4
		' (set) Token: 0x06000886 RID: 2182 RVA: 0x00003747 File Offset: 0x00001947
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x1700033A RID: 826
		' (get) Token: 0x06000887 RID: 2183 RVA: 0x00063FDC File Offset: 0x000621DC
		' (set) Token: 0x06000888 RID: 2184 RVA: 0x00063FF4 File Offset: 0x000621F4
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x1700033B RID: 827
		' (get) Token: 0x06000889 RID: 2185 RVA: 0x00064060 File Offset: 0x00062260
		' (set) Token: 0x0600088A RID: 2186 RVA: 0x00064078 File Offset: 0x00062278
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x1700033C RID: 828
		' (get) Token: 0x0600088B RID: 2187 RVA: 0x000640E4 File Offset: 0x000622E4
		' (set) Token: 0x0600088C RID: 2188 RVA: 0x000640FC File Offset: 0x000622FC
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x1700033D RID: 829
		' (get) Token: 0x0600088D RID: 2189 RVA: 0x00064168 File Offset: 0x00062368
		' (set) Token: 0x0600088E RID: 2190 RVA: 0x00003751 File Offset: 0x00001951
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x1700033E RID: 830
		' (get) Token: 0x0600088F RID: 2191 RVA: 0x00064180 File Offset: 0x00062380
		' (set) Token: 0x06000890 RID: 2192 RVA: 0x00064198 File Offset: 0x00062398
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x1700033F RID: 831
		' (get) Token: 0x06000891 RID: 2193 RVA: 0x00064204 File Offset: 0x00062404
		' (set) Token: 0x06000892 RID: 2194 RVA: 0x0006421C File Offset: 0x0006241C
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x17000340 RID: 832
		' (get) Token: 0x06000893 RID: 2195 RVA: 0x00064288 File Offset: 0x00062488
		' (set) Token: 0x06000894 RID: 2196 RVA: 0x000642A0 File Offset: 0x000624A0
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000341 RID: 833
		' (get) Token: 0x06000895 RID: 2197 RVA: 0x0006430C File Offset: 0x0006250C
		' (set) Token: 0x06000896 RID: 2198 RVA: 0x00064324 File Offset: 0x00062524
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000342 RID: 834
		' (get) Token: 0x06000897 RID: 2199 RVA: 0x00064390 File Offset: 0x00062590
		' (set) Token: 0x06000898 RID: 2200 RVA: 0x000643A8 File Offset: 0x000625A8
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.CellEndEdit, AddressOf Me.dgvData_CellEndEdit
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.CellEndEdit, AddressOf Me.dgvData_CellEndEdit
				End If
			End Set
		End Property

		' Token: 0x17000343 RID: 835
		' (get) Token: 0x06000899 RID: 2201 RVA: 0x00064414 File Offset: 0x00062614
		' (set) Token: 0x0600089A RID: 2202 RVA: 0x0000375B File Offset: 0x0000195B
		Friend Overridable Property lblFilterDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFilterDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFilterDate = value
			End Set
		End Property

		' Token: 0x17000344 RID: 836
		' (get) Token: 0x0600089B RID: 2203 RVA: 0x0006442C File Offset: 0x0006262C
		' (set) Token: 0x0600089C RID: 2204 RVA: 0x00064444 File Offset: 0x00062644
		Friend Overridable Property btnCancel As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancel IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancel.Click, AddressOf Me.btnCancel_Click
				End If
				Me._btnCancel = value
				flag = Me._btnCancel IsNot Nothing
				If flag Then
					AddHandler Me._btnCancel.Click, AddressOf Me.btnCancel_Click
				End If
			End Set
		End Property

		' Token: 0x17000345 RID: 837
		' (get) Token: 0x0600089D RID: 2205 RVA: 0x000644B0 File Offset: 0x000626B0
		' (set) Token: 0x0600089E RID: 2206 RVA: 0x000644C8 File Offset: 0x000626C8
		Friend Overridable Property mtxDATE As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxDATE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxDATE IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxDATE.TextChanged, AddressOf Me.mtxDATE_TextChanged
				End If
				Me._mtxDATE = value
				flag = Me._mtxDATE IsNot Nothing
				If flag Then
					AddHandler Me._mtxDATE.TextChanged, AddressOf Me.mtxDATE_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000346 RID: 838
		' (get) Token: 0x0600089F RID: 2207 RVA: 0x00064534 File Offset: 0x00062734
		' (set) Token: 0x060008A0 RID: 2208 RVA: 0x00003765 File Offset: 0x00001965
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000347 RID: 839
		' (get) Token: 0x060008A1 RID: 2209 RVA: 0x0006454C File Offset: 0x0006274C
		' (set) Token: 0x060008A2 RID: 2210 RVA: 0x00064564 File Offset: 0x00062764
		Friend Overridable Property dtpTuNgay As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpTuNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpTuNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.dtpTuNgay_ValueChanged
				End If
				Me._dtpTuNgay = value
				flag = Me._dtpTuNgay IsNot Nothing
				If flag Then
					AddHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.dtpTuNgay_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x17000348 RID: 840
		' (get) Token: 0x060008A3 RID: 2211 RVA: 0x000645D0 File Offset: 0x000627D0
		' (set) Token: 0x060008A4 RID: 2212 RVA: 0x0000376F File Offset: 0x0000196F
		Friend Overridable Property lblMA1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMA1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMA1 = value
			End Set
		End Property

		' Token: 0x17000349 RID: 841
		' (get) Token: 0x060008A5 RID: 2213 RVA: 0x000645E8 File Offset: 0x000627E8
		' (set) Token: 0x060008A6 RID: 2214 RVA: 0x00003779 File Offset: 0x00001979
		Friend Overridable Property txtTEN1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTEN1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTEN1 = value
			End Set
		End Property

		' Token: 0x1700034A RID: 842
		' (get) Token: 0x060008A7 RID: 2215 RVA: 0x00064600 File Offset: 0x00062800
		' (set) Token: 0x060008A8 RID: 2216 RVA: 0x00064618 File Offset: 0x00062818
		Friend Overridable Property btnDM1 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDM1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDM1 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDM1.Click, AddressOf Me.btnDM1_Click
				End If
				Me._btnDM1 = value
				flag = Me._btnDM1 IsNot Nothing
				If flag Then
					AddHandler Me._btnDM1.Click, AddressOf Me.btnDM1_Click
				End If
			End Set
		End Property

		' Token: 0x1700034B RID: 843
		' (get) Token: 0x060008A9 RID: 2217 RVA: 0x00064684 File Offset: 0x00062884
		' (set) Token: 0x060008AA RID: 2218 RVA: 0x0006469C File Offset: 0x0006289C
		Friend Overridable Property txtMA1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMA1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMA1 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMA1.TextChanged, AddressOf Me.txtMA1_TextChanged
					RemoveHandler Me._txtMA1.KeyDown, AddressOf Me.txtMA1_KeyDown
				End If
				Me._txtMA1 = value
				flag = Me._txtMA1 IsNot Nothing
				If flag Then
					AddHandler Me._txtMA1.TextChanged, AddressOf Me.txtMA1_TextChanged
					AddHandler Me._txtMA1.KeyDown, AddressOf Me.txtMA1_KeyDown
				End If
			End Set
		End Property

		' Token: 0x1700034C RID: 844
		' (get) Token: 0x060008AB RID: 2219 RVA: 0x00064738 File Offset: 0x00062938
		' (set) Token: 0x060008AC RID: 2220 RVA: 0x00003783 File Offset: 0x00001983
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x1700034D RID: 845
		' (get) Token: 0x060008AD RID: 2221 RVA: 0x00064750 File Offset: 0x00062950
		' (set) Token: 0x060008AE RID: 2222 RVA: 0x00064768 File Offset: 0x00062968
		Friend Overridable Property mtxTODATE As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxTODATE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxTODATE IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxTODATE.TextChanged, AddressOf Me.mtxTODATE_TextChanged
				End If
				Me._mtxTODATE = value
				flag = Me._mtxTODATE IsNot Nothing
				If flag Then
					AddHandler Me._mtxTODATE.TextChanged, AddressOf Me.mtxTODATE_TextChanged
				End If
			End Set
		End Property

		' Token: 0x1700034E RID: 846
		' (get) Token: 0x060008AF RID: 2223 RVA: 0x000647D4 File Offset: 0x000629D4
		' (set) Token: 0x060008B0 RID: 2224 RVA: 0x000647EC File Offset: 0x000629EC
		Friend Overridable Property dtpDenNgay As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpDenNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpDenNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpDenNgay.ValueChanged, AddressOf Me.dtpDenNgay_ValueChanged
				End If
				Me._dtpDenNgay = value
				flag = Me._dtpDenNgay IsNot Nothing
				If flag Then
					AddHandler Me._dtpDenNgay.ValueChanged, AddressOf Me.dtpDenNgay_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x1700034F RID: 847
		' (get) Token: 0x060008B1 RID: 2225 RVA: 0x00064858 File Offset: 0x00062A58
		' (set) Token: 0x060008B2 RID: 2226 RVA: 0x00064870 File Offset: 0x00062A70
		Friend Overridable Property dgvDMDV As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvDMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvDMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvDMDV.KeyDown, AddressOf Me.dgvDMDV_KeyDown
				End If
				Me._dgvDMDV = value
				flag = Me._dgvDMDV IsNot Nothing
				If flag Then
					AddHandler Me._dgvDMDV.KeyDown, AddressOf Me.dgvDMDV_KeyDown
				End If
			End Set
		End Property

		' Token: 0x17000350 RID: 848
		' (get) Token: 0x060008B3 RID: 2227 RVA: 0x000648DC File Offset: 0x00062ADC
		' (set) Token: 0x060008B4 RID: 2228 RVA: 0x000648F4 File Offset: 0x00062AF4
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000351 RID: 849
		' (get) Token: 0x060008B5 RID: 2229 RVA: 0x00064960 File Offset: 0x00062B60
		' (set) Token: 0x060008B6 RID: 2230 RVA: 0x00064978 File Offset: 0x00062B78
		Private Overridable Property mbdsSourceDMDV As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDMDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceDMDV IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceDMDV.PositionChanged, AddressOf Me.mbdsSourceDMDV_PositionChanged
				End If
				Me._mbdsSourceDMDV = value
				flag = Me._mbdsSourceDMDV IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceDMDV.PositionChanged, AddressOf Me.mbdsSourceDMDV_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000352 RID: 850
		' (get) Token: 0x060008B7 RID: 2231 RVA: 0x000649E4 File Offset: 0x00062BE4
		' (set) Token: 0x060008B8 RID: 2232 RVA: 0x0000378D File Offset: 0x0000198D
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060008B9 RID: 2233 RVA: 0x000649FC File Offset: 0x00062BFC
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData("NGAY", Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008BA RID: 2234 RVA: 0x00064AD0 File Offset: 0x00062CD0
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData("NGAY", Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008BB RID: 2235 RVA: 0x00064BC4 File Offset: 0x00062DC4
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData("NGAY", Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008BC RID: 2236 RVA: 0x00064CAC File Offset: 0x00062EAC
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData("NGAY", Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008BD RID: 2237 RVA: 0x00064D74 File Offset: 0x00062F74
		Private Sub frmCusNote_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmCusNote_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008BE RID: 2238 RVA: 0x00064E0C File Offset: 0x0006300C
		Private Sub frmCusNote_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 27
				If flag Then
					Dim visible As Boolean = Me.dgvDMDV.Visible
					If visible Then
						Me.dgvDMDV.Visible = False
						Me.txtMA1.Focus()
					Else
						Me.Close()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(20), vbCrLf, Me.Name, " - frmCusNote_KeyPress " & vbCrLf, ex.Message }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060008BF RID: 2239 RVA: 0x00064ED0 File Offset: 0x000630D0
		Private Sub frmCusNote_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				Me.mtxTODATE.Text = String.Concat(New String() { DateAndTime.Today.Day.ToString("00"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Year.ToString("0000") })
				Me.mtxDATE.Text = String.Concat(New String() { DateAndTime.Today.Day.ToString("00"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Year.ToString("0000") })
				flag = b <> 0
				If flag Then
					b = Me.gf_GetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMDV()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMDV_Grid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
				Me.txtMA1.Focus()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmCusNote_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008C0 RID: 2240 RVA: 0x00065158 File Offset: 0x00063358
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008C1 RID: 2241 RVA: 0x00065260 File Offset: 0x00063460
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008C2 RID: 2242 RVA: 0x000652F8 File Offset: 0x000634F8
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.dgvData.SelectedRows.Count > 0
				If flag Then
					Dim frmAddCusNote As frmAddCusNote = New frmAddCusNote()
					frmAddCusNote.mtxDATE.Text = Me.dgvData.CurrentRow.Cells("NGAY").Value.ToString()
					frmAddCusNote.txtMA1.Text = Me.dgvData.CurrentRow.Cells("MADV").Value.ToString()
					frmAddCusNote.txtNoiDung.Text = Me.dgvData.CurrentRow.Cells("NOIDUNG").Value.ToString()
					frmAddCusNote.lblSTT.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("STT").Value)
					frmAddCusNote.pstrIMG1 = Me.dgvData.CurrentRow.Cells("IMG1").Value.ToString()
					frmAddCusNote.pstrIMG2 = Me.dgvData.CurrentRow.Cells("IMG2").Value.ToString()
					frmAddCusNote.pstrIMG3 = Me.dgvData.CurrentRow.Cells("IMG3").Value.ToString()
					frmAddCusNote.ShowDialog()
					flag = frmAddCusNote.pblnOK
					If flag Then
						Me.txtMA1.Text = frmAddCusNote.pStrMaDV
						Me.gf_GetData_4Grid()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060008C3 RID: 2243 RVA: 0x00065514 File Offset: 0x00063714
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.dgvData.SelectedRows.Count > 0
				If flag Then
					Dim flag2 As Boolean = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(29), Me.mArrStrFrmMess(30), frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.Yes
					If flag2 Then
						Dim flag3 As Boolean = Me.fDelete_CusNote() = 1
						If flag3 Then
							Me.gf_GetData_4Grid()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060008C4 RID: 2244 RVA: 0x000655F4 File Offset: 0x000637F4
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmAddCusNote As frmAddCusNote = New frmAddCusNote()
			Try
				frmAddCusNote.pbytFromStatus = 6
				frmAddCusNote.txtMA1.Text = Me.txtMA1.Text
				frmAddCusNote.ShowDialog()
				Dim flag As Boolean = Not frmAddCusNote.pblnOK
				If flag Then
					frmAddCusNote.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmAddCusNote.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(33), MsgBoxStyle.Critical, Nothing)
						frmAddCusNote.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("STT", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("STT")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData("NGAY", num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmAddCusNote.Dispose()
			End Try
		End Sub

		' Token: 0x060008C5 RID: 2245 RVA: 0x00065804 File Offset: 0x00063A04
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmAddCusNote As frmAddCusNote = New frmAddCusNote()
			Try
				Me.btnFindNext.Visible = False
				frmAddCusNote.pbytFromStatus = 5
				frmAddCusNote.txtMA1.Text = Me.txtMA1.Text
				frmAddCusNote.ShowDialog()
				Dim flag As Boolean = Not frmAddCusNote.pblnOK
				If Not flag Then
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmAddCusNote.pStrFilter
					Me.mstrFilterPrint = frmAddCusNote.pStrFilterPrint
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmAddCusNote.Dispose()
			End Try
		End Sub

		' Token: 0x060008C6 RID: 2246 RVA: 0x00065930 File Offset: 0x00063B30
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mstrFilterPrint = ""
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnCancelFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008C7 RID: 2247 RVA: 0x000659F4 File Offset: 0x00063BF4
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CF
						End If
						num6 = Me.mbdsSource.Find("STT", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("STT")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData("NGAY", num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CF:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x060008C8 RID: 2248 RVA: 0x00065B74 File Offset: 0x00063D74
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fPrintCusNote()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008C9 RID: 2249 RVA: 0x00065C0C File Offset: 0x00063E0C
		Private Sub btnCancel_Click(sender As Object, e As EventArgs)
			Try
				Me.mtxDATE.Text = DateAndTime.Now.ToString("dd/MM/yyyy")
				Me.mtxTODATE.Text = DateAndTime.Now.ToString("dd/MM/yyyy")
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnCancel_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008CA RID: 2250 RVA: 0x00065CE8 File Offset: 0x00063EE8
		Private Sub dtpTuNgay_ValueChanged(sender As Object, e As EventArgs)
			Me.mtxDATE.Text = String.Concat(New String() { Me.dtpTuNgay.Value.Day.ToString("00"), "/", Me.dtpTuNgay.Value.Month.ToString("00"), "/", Me.dtpTuNgay.Value.Year.ToString("0000") })
		End Sub

		' Token: 0x060008CB RID: 2251 RVA: 0x00065D98 File Offset: 0x00063F98
		Private Sub mtxDATE_TextChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource Is Nothing
				If Not flag Then
					Dim text As String = Strings.Mid(Me.mtxDATE.Text, 3, 1)
					Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtxDATE.Text, text, "", 1, -1, CompareMethod.Binary))
					flag = Strings.Len(text2) < 8
					If flag Then
						Me.mbdsSource.RemoveFilter()
						Me.mstrFilterPrint = ""
					Else
						text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 1, 2) })
						flag = Not Information.IsDate(text2)
						If flag Then
							Me.mbdsSource.RemoveFilter()
							Me.mstrFilterPrint = ""
						Else
							flag = Me.gf_GetData_4Grid() = 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
							End If
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxDATE_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008CC RID: 2252 RVA: 0x00065F90 File Offset: 0x00064190
		Private Sub btnDetail_Click(sender As Object, e As EventArgs)
			Try
				Dim frmSAL As frmSAL023 = New frmSAL023()
				Dim frmSAL2 As frmSAL023 = frmSAL
				frmSAL2.pbdsSource = Me.mbdsSource
				frmSAL2.pdgvMaster = Me.dgvData
				frmSAL.ShowDialog()
				Me.gf_GetData_4Grid()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDetail_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008CD RID: 2253 RVA: 0x00066054 File Offset: 0x00064254
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = True
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("NGAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("NGAY").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("NGAY").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NGAY").[ReadOnly] = True
				dgvData.Columns("MADV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(34))
				dgvData.Columns("MADV").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("MADV").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MADV").[ReadOnly] = True
				dgvData.Columns("TENDV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(35))
				dgvData.Columns("TENDV").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("TENDV").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENDV").[ReadOnly] = True
				dgvData.Columns("TENDV").DefaultCellStyle.WrapMode = DataGridViewTriState.[True]
				dgvData.Columns("NOIDUNG").HeaderText = Strings.Trim(Me.mArrStrFrmMess(21))
				dgvData.Columns("NOIDUNG").Width = Me.dgvData.Width - 428 - 600
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
				dgvData.Columns("NOIDUNG").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NOIDUNG").[ReadOnly] = True
				dgvData.Columns("NOIDUNG").DefaultCellStyle.WrapMode = DataGridViewTriState.[True]
				dgvData.Columns("IMG_ANH1").HeaderText = Strings.Trim(Me.mArrStrFrmMess(36))
				dgvData.Columns("IMG_ANH1").Width = 200
				dgvData.Columns("IMG_ANH2").HeaderText = Strings.Trim(Me.mArrStrFrmMess(37))
				dgvData.Columns("IMG_ANH2").Width = 200
				dgvData.Columns("IMG_ANH3").HeaderText = Strings.Trim(Me.mArrStrFrmMess(38))
				dgvData.Columns("IMG_ANH3").Width = 200
				dgvData.Columns("STT").Visible = False
				dgvData.Columns("IMG1").Visible = False
				dgvData.Columns("IMG2").Visible = False
				dgvData.Columns("IMG3").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060008CE RID: 2254 RVA: 0x000664C4 File Offset: 0x000646C4
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060008CF RID: 2255 RVA: 0x00066644 File Offset: 0x00064844
		Public Function gf_GetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nvcFROM"
				array(0).Value = Me.mtxDATE.Text.Trim().Substring(6) + Me.mtxDATE.Text.Trim().Substring(3, 2) + Me.mtxDATE.Text.Trim().Substring(0, 2)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nvcTO"
				array(1).Value = Me.mtxTODATE.Text.Trim().Substring(6) + Me.mtxTODATE.Text.Trim().Substring(3, 2) + Me.mtxTODATE.Text.Trim().Substring(0, 2)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@nchMADV"
				array(2).Value = Me.txtMA1.Text.Trim()
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCUSNOTE_GET_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					clsConnect.Columns.Add("IMG_ANH1", GetType(Image))
					clsConnect.Columns.Add("IMG_ANH2", GetType(Image))
					clsConnect.Columns.Add("IMG_ANH3", GetType(Image))
					Try
						For Each obj As Object In clsConnect.Rows
							Dim dataRow As DataRow = CType(obj, DataRow)
							flag = dataRow("IMG1").ToString().Trim().Length > 4
							If flag Then
								Dim text As String = dataRow("IMG1").ToString()
								flag = File.Exists(text)
								If flag Then
									Dim image As Image = Image.FromFile(text)
									Dim size As Size = Me.fGetThumbnailSize(image)
									dataRow("IMG_ANH1") = image.GetThumbnailImage(size.Width, size.Height, CType([Delegate].Combine(New [Delegate](-1) {}), Image.GetThumbnailImageAbort), IntPtr.Zero)
								Else
									Dim size2 As Size = Me.fGetThumbnailSize(Resources.imgnot)
									dataRow("IMG_ANH1") = Resources.imgnot.GetThumbnailImage(size2.Width, size2.Height, CType([Delegate].Combine(New [Delegate](-1) {}), Image.GetThumbnailImageAbort), IntPtr.Zero)
								End If
							End If
							flag = dataRow("IMG2").ToString().Trim().Length > 4
							If flag Then
								Dim text2 As String = dataRow("IMG2").ToString()
								flag = File.Exists(text2)
								If flag Then
									Dim image2 As Image = Image.FromFile(text2)
									Dim size3 As Size = Me.fGetThumbnailSize(image2)
									dataRow("IMG_ANH2") = image2.GetThumbnailImage(size3.Width, size3.Height, CType([Delegate].Combine(New [Delegate](-1) {}), Image.GetThumbnailImageAbort), IntPtr.Zero)
								Else
									Dim size4 As Size = Me.fGetThumbnailSize(Resources.imgnot)
									dataRow("IMG_ANH2") = Resources.imgnot.GetThumbnailImage(size4.Width, size4.Height, CType([Delegate].Combine(New [Delegate](-1) {}), Image.GetThumbnailImageAbort), IntPtr.Zero)
								End If
							End If
							flag = dataRow("IMG3").ToString().Trim().Length > 4
							If flag Then
								Dim text3 As String = dataRow("IMG3").ToString()
								flag = File.Exists(text3)
								If flag Then
									Dim image3 As Image = Image.FromFile(text3)
									Dim size5 As Size = Me.fGetThumbnailSize(image3)
									dataRow("IMG_ANH3") = image3.GetThumbnailImage(size5.Width, size5.Height, CType([Delegate].Combine(New [Delegate](-1) {}), Image.GetThumbnailImageAbort), IntPtr.Zero)
								Else
									Dim size6 As Size = Me.fGetThumbnailSize(Resources.imgnot)
									dataRow("IMG_ANH3") = Resources.imgnot.GetThumbnailImage(size6.Width, size6.Height, CType([Delegate].Combine(New [Delegate](-1) {}), Image.GetThumbnailImageAbort), IntPtr.Zero)
								End If
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag = TypeOf enumerator Is IDisposable
						If flag Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gf_GetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060008D0 RID: 2256 RVA: 0x00066BBC File Offset: 0x00064DBC
		Private Function fGetThumbnailSize(original As Image) As Size
			Dim width As Integer = original.Width
			Dim height As Integer = original.Height
			Dim flag As Boolean = width > height
			Dim num As Double
			If flag Then
				num = 200.0 / CDbl(width)
			Else
				num = 200.0 / CDbl(height)
			End If
			Dim size As Size = New Size(CInt(Math.Round(CDbl(width) * num)), CInt(Math.Round(CDbl(height) * num)))
			Return size
		End Function

		' Token: 0x060008D1 RID: 2257 RVA: 0x00066C24 File Offset: 0x00064E24
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Me.btnAdd.Visible = True
				Me.btnAddDefault.Visible = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060008D2 RID: 2258 RVA: 0x00066D00 File Offset: 0x00064F00
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, String.Concat(New String() { Me.mArrStrFrmMess(2), " [", Strings.Mid(mdlVariable.gStrSelectMonth, 5, 2), "/", Strings.Mid(mdlVariable.gStrSelectMonth, 1, 4), " ] ", Me.mArrStrFrmMess(22), " [", mdlVariable.gstrStockName, "]" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "6070100000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060008D3 RID: 2259 RVA: 0x00066E9C File Offset: 0x0006509C
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008D4 RID: 2260 RVA: 0x00066F48 File Offset: 0x00065148
		Private Sub txtMA1_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMDV Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMDV.Columns("OBJID")
					Me.mclsTbDMDV.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMDV.Rows.Find(Strings.Trim(Me.txtMA1.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTEN1.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTEN1.Text = ""
					End If
					Me.gf_GetData_4Grid()
					Me.btnCancelFilter.Visible = False
					Me.btnFindNext.Visible = False
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMADV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008D5 RID: 2261 RVA: 0x000670BC File Offset: 0x000652BC
		Private Sub btnDM1_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDV As frmDMDV1 = New frmDMDV1()
				frmDMDV.pBytOpen_From_Menu = 7
				frmDMDV.pIntType = 4S
				frmDMDV.ShowDialog()
				Me.txtMA1.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJID, "", False) = 0, Me.txtMA1.Text, frmDMDV.pStrOBJID))
				Me.txtTEN1.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJNAME, "", False) = 0, Me.txtTEN1.Text, frmDMDV.pStrOBJNAME))
				Me.fGetData_DMDV()
				frmDMDV.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMDV_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008D6 RID: 2262 RVA: 0x00067208 File Offset: 0x00065408
		Private Function fGetData_DMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMDV")
				Dim flag As Boolean = Me.mclsTbDMDV IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060008D7 RID: 2263 RVA: 0x000672C4 File Offset: 0x000654C4
		Private Function fGetData_DMDV_Grid() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
				Dim text As String = "SP_FRMSAL011_GET_DMDV"
				Dim flag As Boolean = Nothing
				Me.mclsTbDMDV_Grid = New clsConnect(gStrConISDANHMUC, text, flag)
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMDV_Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060008D8 RID: 2264 RVA: 0x00067384 File Offset: 0x00065584
		Private Sub dgvData_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs)
			Try
				Me.fSaveLDaGiao(Me.dgvData.Rows(e.RowIndex).Cells("DOCID").Value.ToString(), Conversions.ToBoolean(Me.dgvData.Rows(e.RowIndex).Cells("LDAGIAO").Value))
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_CellEndEdit ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008D9 RID: 2265 RVA: 0x0006747C File Offset: 0x0006567C
		Private Function fSaveLDaGiao(strDocID As String, blnLDaGiao As Boolean) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchDOCID"
				array(0).Value = strDocID
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pbitLDAGIAO"
				array(1).Value = blnLDaGiao
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDULIEU, array, "SP_FRMSAL02_UPDATE_LDAGIAO", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(53), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fSaveLDaGiao ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060008DA RID: 2266 RVA: 0x00067630 File Offset: 0x00065830
		Private Sub dtpDenNgay_ValueChanged(sender As Object, e As EventArgs)
			Me.mtxTODATE.Text = String.Concat(New String() { Me.dtpDenNgay.Value.Day.ToString("00"), "/", Me.dtpDenNgay.Value.Month.ToString("00"), "/", Me.dtpDenNgay.Value.Year.ToString("0000") })
		End Sub

		' Token: 0x060008DB RID: 2267 RVA: 0x00065D98 File Offset: 0x00063F98
		Private Sub mtxTODATE_TextChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource Is Nothing
				If Not flag Then
					Dim text As String = Strings.Mid(Me.mtxDATE.Text, 3, 1)
					Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtxDATE.Text, text, "", 1, -1, CompareMethod.Binary))
					flag = Strings.Len(text2) < 8
					If flag Then
						Me.mbdsSource.RemoveFilter()
						Me.mstrFilterPrint = ""
					Else
						text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxDATE.Text), 1, 2) })
						flag = Not Information.IsDate(text2)
						If flag Then
							Me.mbdsSource.RemoveFilter()
							Me.mstrFilterPrint = ""
						Else
							flag = Me.gf_GetData_4Grid() = 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
							End If
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxDATE_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008DC RID: 2268 RVA: 0x000676E0 File Offset: 0x000658E0
		Private Function f_GetData_4GridMADV() As Byte
			' The following expression was wrapped in a checked-statement
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = Me.mclsTbDMDV_Grid Is Nothing
				If Not flag Then
					Me.dgvDMDV.Top = Me.txtMA1.Top + Me.txtMA1.Height + 3
					Me.dgvDMDV.Left = CInt(Math.Round(CDbl(Me.dgvData.Left) + CDbl(Me.dgvData.Width) / 4.0))
					Me.dgvDMDV.Width = CInt(Math.Round(CDbl(Me.dgvData.Width) - CDbl(Me.dgvData.Width) / 4.0))
					Me.dgvDMDV.Height = CInt(Math.Round(CDbl(Me.dgvData.Height) - CDbl(Me.dgvData.Height) / 3.0))
					Me.dgvDMDV.Visible = True
					Me.dgvDMDV.DataSource = Nothing
					Me.dgvDMDV.ColumnHeadersVisible = True
					Me.dgvDMDV.MultiSelect = False
					Me.dgvDMDV.RowHeadersVisible = False
					Me.dgvDMDV.SelectionMode = DataGridViewSelectionMode.FullRowSelect
					Me.dgvDMDV.StandardTab = False
					Me.dgvDMDV.TabStop = False
					Me.dgvDMDV.AllowUserToAddRows = False
					Me.dgvDMDV.AllowUserToDeleteRows = False
					Me.dgvDMDV.AllowUserToOrderColumns = False
					Me.dgvDMDV.AllowUserToResizeRows = False
					Me.dgvDMDV.AllowDrop = False
					Me.dgvDMDV.RowTemplate.Height = 25
					Me.dgvDMDV.AlternatingRowsDefaultCellStyle.BackColor = mdlVariable.gobjcloOddRowGrid
					Dim text As String = Me.txtMA1.Text.Trim()
					text = Conversions.ToString(NewLateBinding.LateGet(Nothing, GetType(Strings), "UCase", New Object() { RuntimeHelpers.GetObjectValue(Interaction.IIf(Operators.CompareString(Strings.Mid(text, 1, 1), "*", False) = 0, Strings.Mid(text, 2), text)) }, Nothing, Nothing, Nothing))
					Dim dataTable As DataTable = New DataTable()
					dataTable.Columns.Add("STT")
					dataTable.Columns.Add("OBJID")
					dataTable.Columns.Add("OBJNAME")
					dataTable.Columns.Add("ADDRESS")
					dataTable.Columns.Add("MOBILE")
					dataTable.Columns.Add("BIRTHDAY")
					dataTable.Columns.Add("MANHOMDV")
					dataTable.Columns.Add("TENNHOMDV")
					dataTable.Columns.Add("VATCODE")
					dataTable.Columns.Add("TEL")
					dataTable.Columns.Add("MUCGIAMGIA")
					flag = Me.mclsTbDMDV_Grid.Rows.Count > 0
					Dim flag3 As Boolean
					If flag Then
						Dim num As Integer = 0
						Dim num2 As Integer = Me.mclsTbDMDV_Grid.Rows.Count - 1
						Dim num3 As Integer = num
						While True
							Dim num4 As Integer = num3
							Dim num5 As Integer = num2
							If num4 > num5 Then
								Exit For
							End If
							Dim obj As Object = Nothing
							Dim typeFromHandle As Type = GetType(Strings)
							Dim text2 As String = "UCase"
							Dim array As Object() = New Object(0) {}
							Dim array2 As Object() = array
							Dim num6 As Integer = 0
							Dim dataRow As DataRow = Me.mclsTbDMDV_Grid.Rows(num3)
							Dim dataRow2 As DataRow = dataRow
							Dim text3 As String = "OBJID"
							array2(num6) = RuntimeHelpers.GetObjectValue(dataRow2(text3))
							Dim array3 As Object() = array
							Dim array4 As Object() = array3
							Dim array5 As String() = Nothing
							Dim array6 As Type() = Nothing
							Dim array7 As Boolean() = New Boolean() { True }
							Dim obj2 As Object = NewLateBinding.LateGet(obj, typeFromHandle, text2, array4, array5, array6, array7)
							If array7(0) Then
								dataRow(text3) = RuntimeHelpers.GetObjectValue(array3(0))
							End If
							If Strings.InStr(Conversions.ToString(obj2), text, CompareMethod.Binary) > 0 Then
								GoTo IL_0427
							End If
							Dim obj3 As Object = Nothing
							Dim typeFromHandle2 As Type = GetType(Strings)
							Dim text4 As String = "UCase"
							Dim array8 As Object() = New Object(0) {}
							Dim array9 As Object() = array8
							Dim num7 As Integer = 0
							Dim dataRow3 As DataRow = Me.mclsTbDMDV_Grid.Rows(num3)
							Dim dataRow4 As DataRow = dataRow3
							Dim text5 As String = "OBJNAME"
							array9(num7) = RuntimeHelpers.GetObjectValue(dataRow4(text5))
							Dim array10 As Object() = array8
							Dim array11 As Object() = array10
							Dim array12 As String() = Nothing
							Dim array13 As Type() = Nothing
							Dim array14 As Boolean() = New Boolean() { True }
							Dim obj4 As Object = NewLateBinding.LateGet(obj3, typeFromHandle2, text4, array11, array12, array13, array14)
							If array14(0) Then
								dataRow3(text5) = RuntimeHelpers.GetObjectValue(array10(0))
							End If
							If Strings.InStr(mdlPrintReceipt.gfRemove_signVie(Conversions.ToString(obj4)), text, CompareMethod.Binary) > 0 Then
								GoTo IL_0427
							End If
							Dim obj5 As Object = Nothing
							Dim typeFromHandle3 As Type = GetType(Strings)
							Dim text6 As String = "UCase"
							Dim array15 As Object() = New Object(0) {}
							Dim array16 As Object() = array15
							Dim num8 As Integer = 0
							Dim dataRow5 As DataRow = Me.mclsTbDMDV_Grid.Rows(num3)
							Dim dataRow6 As DataRow = dataRow5
							Dim text7 As String = "OBJNAME"
							array16(num8) = RuntimeHelpers.GetObjectValue(dataRow6(text7))
							Dim array17 As Object() = array15
							Dim array18 As Object() = array17
							Dim array19 As String() = Nothing
							Dim array20 As Type() = Nothing
							Dim array21 As Boolean() = New Boolean() { True }
							Dim obj6 As Object = NewLateBinding.LateGet(obj5, typeFromHandle3, text6, array18, array19, array20, array21)
							If array21(0) Then
								dataRow5(text7) = RuntimeHelpers.GetObjectValue(array17(0))
							End If
							If Strings.InStr(Conversions.ToString(obj6), text, CompareMethod.Binary) > 0 Then
								GoTo IL_04B5
							End If
							Dim obj7 As Object = Nothing
							Dim typeFromHandle4 As Type = GetType(Strings)
							Dim text8 As String = "UCase"
							Dim array22 As Object() = New Object(0) {}
							Dim array23 As Object() = array22
							Dim num9 As Integer = 0
							Dim dataRow7 As DataRow = Me.mclsTbDMDV_Grid.Rows(num3)
							Dim dataRow8 As DataRow = dataRow7
							Dim text9 As String = "MOBILE"
							array23(num9) = RuntimeHelpers.GetObjectValue(dataRow8(text9))
							Dim array24 As Object() = array22
							Dim array25 As Object() = array24
							Dim array26 As String() = Nothing
							Dim array27 As Type() = Nothing
							Dim array28 As Boolean() = New Boolean() { True }
							Dim obj8 As Object = NewLateBinding.LateGet(obj7, typeFromHandle4, text8, array25, array26, array27, array28)
							If array28(0) Then
								dataRow7(text9) = RuntimeHelpers.GetObjectValue(array24(0))
							End If
							If Strings.InStr(Conversions.ToString(obj8), text, CompareMethod.Binary) > 0 Then
								GoTo IL_0546
							End If
							Dim flag2 As Boolean = False
							IL_0547:
							flag3 = flag2
							If flag3 Then
								dataTable.Rows.Add(New Object(-1) {})
								dataTable.Rows(dataTable.Rows.Count - 1)("STT") = dataTable.Rows.Count
								dataTable.Rows(dataTable.Rows.Count - 1)("OBJID") = Me.mclsTbDMDV_Grid.Rows(num3)("OBJID").ToString().Trim()
								dataTable.Rows(dataTable.Rows.Count - 1)("OBJNAME") = Operators.ConcatenateObject(Me.mclsTbDMDV_Grid.Rows(num3)("OBJNAME"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("ADDRESS") = Operators.ConcatenateObject(Me.mclsTbDMDV_Grid.Rows(num3)("ADDRESS"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("MOBILE") = Operators.ConcatenateObject(Me.mclsTbDMDV_Grid.Rows(num3)("MOBILE"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("BIRTHDAY") = Operators.ConcatenateObject(Me.mclsTbDMDV_Grid.Rows(num3)("BIRTHDAY"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("MANHOMDV") = Operators.ConcatenateObject(Me.mclsTbDMDV_Grid.Rows(num3)("MANHOMDV"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("TENNHOMDV") = Operators.ConcatenateObject(Me.mclsTbDMDV_Grid.Rows(num3)("TENNHOMDV"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("VATCODE") = Operators.ConcatenateObject(Me.mclsTbDMDV_Grid.Rows(num3)("VATCODE"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("TEL") = Operators.ConcatenateObject(Me.mclsTbDMDV_Grid.Rows(num3)("TEL"), "")
								dataTable.Rows(dataTable.Rows.Count - 1)("MUCGIAMGIA") = RuntimeHelpers.GetObjectValue(Me.mclsTbDMDV_Grid.Rows(num3)("MUCGIAMGIA"))
							End If
							num3 += 1
							Continue For
							IL_0546:
							flag2 = True
							GoTo IL_0547
							IL_04B5:
							GoTo IL_0546
							IL_0427:
							GoTo IL_04B5
						End While
					End If
					Me.mbdsSourceDMDV.DataSource = dataTable
					Me.dgvDMDV.DataSource = Me.mbdsSourceDMDV
					Me.dgvDMDV.Columns("MANHOMDV").Visible = False
					Me.dgvDMDV.Columns("VATCODE").Visible = False
					Me.dgvDMDV.Columns("TEL").Visible = False
					Me.dgvDMDV.Columns("MUCGIAMGIA").Visible = False
					Me.dgvDMDV.Columns("STT").Width = 35
					Me.dgvDMDV.Columns("STT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(22))
					Me.dgvDMDV.Columns("STT").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
					Me.dgvDMDV.Columns("OBJID").Width = 85
					Me.dgvDMDV.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(23))
					Me.dgvDMDV.Columns("OBJNAME").Width = Me.dgvDMDV.Width - 610
					Me.dgvDMDV.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(24))
					Me.dgvDMDV.Columns("ADDRESS").Width = 160
					Me.dgvDMDV.Columns("ADDRESS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
					Me.dgvDMDV.Columns("MOBILE").Width = 105
					Me.dgvDMDV.Columns("MOBILE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
					Me.dgvDMDV.Columns("BIRTHDAY").Width = 85
					Me.dgvDMDV.Columns("BIRTHDAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
					Me.dgvDMDV.Columns("BIRTHDAY").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
					Me.dgvDMDV.Columns("TENNHOMDV").Width = 120
					Me.dgvDMDV.Columns("TENNHOMDV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(28))
					flag3 = dataTable.Rows.Count > 0
					If flag3 Then
						Me.dgvDMDV.Focus()
					End If
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - f_GetData_4GridMADV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060008DD RID: 2269 RVA: 0x000682F8 File Offset: 0x000664F8
		Private Sub txtMA1_KeyDown(sender As Object, e As KeyEventArgs)
			Try
				Dim flag As Boolean = e.KeyCode = Keys.Down
				If flag Then
					Me.f_GetData_4GridMADV()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(20), vbCrLf, Me.Name, " - txtMA1_KeyDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060008DE RID: 2270 RVA: 0x00068394 File Offset: 0x00066594
		Private Sub mbdsSourceDMDV_PositionChanged(sender As Object, e As EventArgs)
			Try
				Me.mintPosDV = Me.mbdsSourceDMDV.Position
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceDMDV_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008DF RID: 2271 RVA: 0x00068438 File Offset: 0x00066638
		Private Sub dgvDMDV_KeyDown(sender As Object, e As KeyEventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim keyCode As Keys = e.KeyCode
				Dim flag As Boolean = keyCode = Keys.[Return]
				If flag Then
					Dim flag2 As Boolean = Me.mbdsSourceDMDV.Count > 0
					If flag2 Then
						Me.txtMA1.Text = Conversions.ToString(Me.dgvDMDV("OBJID", Me.mintPosDV).Value)
					End If
					Me.dgvDMDV.Visible = False
					Me.txtMA1.Focus()
				Else
					Dim flag3 As Boolean
					If keyCode < Keys.D1 OrElse keyCode > Keys.D9 Then
						If keyCode < Keys.NumPad1 OrElse keyCode > Keys.NumPad9 Then
							flag3 = False
							GoTo IL_0092
						End If
					End If
					flag3 = True
					IL_0092:
					Dim flag2 As Boolean = flag3
					If flag2 Then
						Dim num As Integer = e.KeyCode - Keys.D0
						flag2 = num > 9
						If flag2 Then
							num -= 48
						End If
						flag2 = (Me.mbdsSourceDMDV.Count >= num) And (num > 0)
						If flag2 Then
							Me.txtMA1.Text = Conversions.ToString(Me.dgvDMDV("OBJID", Me.mintPosDV).Value)
							Me.txtMA1.Focus()
							Me.dgvDMDV.Visible = False
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvDMDV_KeyDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060008E0 RID: 2272 RVA: 0x000685F4 File Offset: 0x000667F4
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Try
				Dim frmAddCusNote As frmAddCusNote = New frmAddCusNote()
				frmAddCusNote.mtxDATE.Text = DateAndTime.Now.ToString("dd/MM/yyyy")
				frmAddCusNote.txtMA1.Text = Me.txtMA1.Text
				frmAddCusNote.txtNoiDung.Text = ""
				frmAddCusNote.lblSTT.Text = ""
				frmAddCusNote.ShowDialog()
				Dim pblnOK As Boolean = frmAddCusNote.pblnOK
				If pblnOK Then
					Me.txtMA1.Text = frmAddCusNote.pStrMaDV
					Me.gf_GetData_4Grid()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060008E1 RID: 2273 RVA: 0x00068704 File Offset: 0x00066904
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.dgvData.SelectedRows.Count > 0
				If flag Then
					Dim frmAddCusNote As frmAddCusNote = New frmAddCusNote()
					frmAddCusNote.mtxDATE.Text = Me.dgvData.CurrentRow.Cells("NGAY").Value.ToString()
					frmAddCusNote.txtMA1.Text = Me.dgvData.CurrentRow.Cells("MADV").Value.ToString()
					frmAddCusNote.txtNoiDung.Text = Me.dgvData.CurrentRow.Cells("NOIDUNG").Value.ToString()
					frmAddCusNote.lblSTT.Text = ""
					frmAddCusNote.ShowDialog()
					flag = frmAddCusNote.pblnOK
					If flag Then
						Me.txtMA1.Text = frmAddCusNote.pStrMaDV
						Me.gf_GetData_4Grid()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060008E2 RID: 2274 RVA: 0x00068874 File Offset: 0x00066A74
		Private Function fDelete_CusNote() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@intSTT"
				array(0).Value = Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("STT").Value))
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCUSNOTE_DEL_CUSNOTE", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(31), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(32), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060008E3 RID: 2275 RVA: 0x00068A38 File Offset: 0x00066C38
		Private Function fPrintCusNote() As Byte
			Dim rptCUSNOTE As rptCUSNOTE = New rptCUSNOTE()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptCUSNOTE, "")
				Dim text As String = "2070403000"
				mdlReport.gsSetOfficeReport(rptCUSNOTE, text)
				mdlReport.gsSetFontReport(rptCUSNOTE)
				Dim textObject As TextObject = CType(rptCUSNOTE.ReportDefinition.ReportObjects("txtKhachHang"), TextObject)
				textObject.Text = Me.txtMA1.Text.Trim() + " - " + Me.txtTEN1.Text.Trim()
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nvcFROM"
				array(0).Value = Me.mtxDATE.Text.Trim().Substring(6) + Me.mtxDATE.Text.Trim().Substring(3, 2) + Me.mtxDATE.Text.Trim().Substring(0, 2)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nvcTO"
				array(1).Value = Me.mtxTODATE.Text.Trim().Substring(6) + Me.mtxTODATE.Text.Trim().Substring(3, 2) + Me.mtxTODATE.Text.Trim().Substring(0, 2)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@nchMADV"
				array(2).Value = Me.txtMA1.Text.Trim()
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCUSNOTE_GET_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					rptCUSNOTE.SetDataSource(clsConnect)
					rptCUSNOTE.RecordSelectionFormula = Me.mstrFilterPrint
					rptCUSNOTE.DataDefinition.FormulaFields("fNGAY").Text = "{dtReport.NGAY}"
					rptCUSNOTE.DataDefinition.FormulaFields("fNote").Text = "{dtReport.NOIDUNG}"
					mdlReport.gsSetTextReport(rptCUSNOTE, "RPTCUSNOTE")
					MyProject.Forms.frmReport.pSource = rptCUSNOTE
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject2 As TextObject = CType(rptCUSNOTE.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject2.Text
					rptCUSNOTE.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptCUSNOTE.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintCusNote " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptCUSNOTE.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x040003B5 RID: 949
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040003B7 RID: 951
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x040003B8 RID: 952
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x040003B9 RID: 953
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x040003BA RID: 954
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x040003BB RID: 955
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x040003BC RID: 956
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x040003BD RID: 957
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x040003BE RID: 958
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x040003BF RID: 959
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x040003C0 RID: 960
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x040003C1 RID: 961
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x040003C2 RID: 962
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x040003C3 RID: 963
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x040003C4 RID: 964
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x040003C5 RID: 965
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x040003C6 RID: 966
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040003C7 RID: 967
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x040003C8 RID: 968
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040003C9 RID: 969
		<AccessedThroughProperty("lblFilterDate")>
		Private _lblFilterDate As Label

		' Token: 0x040003CA RID: 970
		<AccessedThroughProperty("btnCancel")>
		Private _btnCancel As Button

		' Token: 0x040003CB RID: 971
		<AccessedThroughProperty("mtxDATE")>
		Private _mtxDATE As MaskedTextBox

		' Token: 0x040003CC RID: 972
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040003CD RID: 973
		<AccessedThroughProperty("dtpTuNgay")>
		Private _dtpTuNgay As DateTimePicker

		' Token: 0x040003CE RID: 974
		<AccessedThroughProperty("lblMA1")>
		Private _lblMA1 As Label

		' Token: 0x040003CF RID: 975
		<AccessedThroughProperty("txtTEN1")>
		Private _txtTEN1 As TextBox

		' Token: 0x040003D0 RID: 976
		<AccessedThroughProperty("btnDM1")>
		Private _btnDM1 As Button

		' Token: 0x040003D1 RID: 977
		<AccessedThroughProperty("txtMA1")>
		Private _txtMA1 As TextBox

		' Token: 0x040003D2 RID: 978
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x040003D3 RID: 979
		<AccessedThroughProperty("mtxTODATE")>
		Private _mtxTODATE As MaskedTextBox

		' Token: 0x040003D4 RID: 980
		<AccessedThroughProperty("dtpDenNgay")>
		Private _dtpDenNgay As DateTimePicker

		' Token: 0x040003D5 RID: 981
		<AccessedThroughProperty("dgvDMDV")>
		Private _dgvDMDV As DataGridView

		' Token: 0x040003D6 RID: 982
		Private mArrStrFrmMess As String()

		' Token: 0x040003D7 RID: 983
		Private mStrSOCT As String

		' Token: 0x040003D8 RID: 984
		Private mStrNGAYGS As String

		' Token: 0x040003D9 RID: 985
		Private mStrNGAYCT As String

		' Token: 0x040003DA RID: 986
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040003DB RID: 987
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040003DC RID: 988
		Private marrDrFind As DataRow()

		' Token: 0x040003DD RID: 989
		Private mintFindLastPos As Integer

		' Token: 0x040003DE RID: 990
		Private mclsTbDMDV As clsConnect

		' Token: 0x040003DF RID: 991
		Private mclsTbDMDV_Grid As clsConnect

		' Token: 0x040003E0 RID: 992
		<AccessedThroughProperty("mbdsSourceDMDV")>
		Private _mbdsSourceDMDV As BindingSource

		' Token: 0x040003E1 RID: 993
		Private mintPosDV As Integer

		' Token: 0x040003E2 RID: 994
		Private mstrFilterPrint As String
	End Class
End Namespace
