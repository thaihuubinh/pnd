﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000024 RID: 36
	<DesignerGenerated()>
	Public Partial Class frmChangeTableStatus
		Inherits Form

		' Token: 0x0600068D RID: 1677 RVA: 0x0004DDD4 File Offset: 0x0004BFD4
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmChangeTableStatus_Load
			frmChangeTableStatus.__ENCList.Add(New WeakReference(Me))
			Me.mintSelectIndexNhom = 0
			Me.mstrMaBan = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700027D RID: 637
		' (get) Token: 0x06000690 RID: 1680 RVA: 0x0004E81C File Offset: 0x0004CA1C
		' (set) Token: 0x06000691 RID: 1681 RVA: 0x0004E834 File Offset: 0x0004CA34
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700027E RID: 638
		' (get) Token: 0x06000692 RID: 1682 RVA: 0x0004E8A0 File Offset: 0x0004CAA0
		' (set) Token: 0x06000693 RID: 1683 RVA: 0x000031D1 File Offset: 0x000013D1
		Friend Overridable Property TableLayoutPanel5 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel5 = value
			End Set
		End Property

		' Token: 0x1700027F RID: 639
		' (get) Token: 0x06000694 RID: 1684 RVA: 0x0004E8B8 File Offset: 0x0004CAB8
		' (set) Token: 0x06000695 RID: 1685 RVA: 0x0004E8D0 File Offset: 0x0004CAD0
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000280 RID: 640
		' (get) Token: 0x06000696 RID: 1686 RVA: 0x0004E93C File Offset: 0x0004CB3C
		' (set) Token: 0x06000697 RID: 1687 RVA: 0x0004E954 File Offset: 0x0004CB54
		Friend Overridable Property dtgStatus As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dtgStatus
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dtgStatus IsNot Nothing
				If flag Then
					RemoveHandler Me._dtgStatus.RowEnter, AddressOf Me.dtgStatus_RowEnter
					RemoveHandler Me._dtgStatus.DoubleClick, AddressOf Me.dtgStatus_DoubleClick
				End If
				Me._dtgStatus = value
				flag = Me._dtgStatus IsNot Nothing
				If flag Then
					AddHandler Me._dtgStatus.RowEnter, AddressOf Me.dtgStatus_RowEnter
					AddHandler Me._dtgStatus.DoubleClick, AddressOf Me.dtgStatus_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x17000281 RID: 641
		' (get) Token: 0x06000698 RID: 1688 RVA: 0x0004E9F0 File Offset: 0x0004CBF0
		' (set) Token: 0x06000699 RID: 1689 RVA: 0x000031DB File Offset: 0x000013DB
		Friend Overridable Property Column1 As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._Column1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._Column1 = value
			End Set
		End Property

		' Token: 0x17000282 RID: 642
		' (get) Token: 0x0600069A RID: 1690 RVA: 0x0004EA08 File Offset: 0x0004CC08
		' (set) Token: 0x0600069B RID: 1691 RVA: 0x000031E5 File Offset: 0x000013E5
		Friend Overridable Property Column2 As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._Column2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._Column2 = value
			End Set
		End Property

		' Token: 0x17000283 RID: 643
		' (get) Token: 0x0600069C RID: 1692 RVA: 0x0004EA20 File Offset: 0x0004CC20
		' (set) Token: 0x0600069D RID: 1693 RVA: 0x0004EA38 File Offset: 0x0004CC38
		Friend Overridable Property btnColor As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnColor IsNot Nothing
				If flag Then
					RemoveHandler Me._btnColor.Click, AddressOf Me.btnColor_Click
				End If
				Me._btnColor = value
				flag = Me._btnColor IsNot Nothing
				If flag Then
					AddHandler Me._btnColor.Click, AddressOf Me.btnColor_Click
				End If
			End Set
		End Property

		' Token: 0x17000284 RID: 644
		' (get) Token: 0x0600069E RID: 1694 RVA: 0x0004EAA4 File Offset: 0x0004CCA4
		' (set) Token: 0x0600069F RID: 1695 RVA: 0x000031EF File Offset: 0x000013EF
		Friend Overridable Property lblColor As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblColor = value
			End Set
		End Property

		' Token: 0x17000285 RID: 645
		' (get) Token: 0x060006A0 RID: 1696 RVA: 0x0004EABC File Offset: 0x0004CCBC
		' (set) Token: 0x060006A1 RID: 1697 RVA: 0x000031F9 File Offset: 0x000013F9
		Public Property pstrMaBan As String
			Get
				Return Me.mstrMaBan
			End Get
			Set(value As String)
				Me.mstrMaBan = value
			End Set
		End Property

		' Token: 0x060006A2 RID: 1698 RVA: 0x00003204 File Offset: 0x00001404
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			mdlFile.gfWriteLogFile("Nhấn nút Thoát khỏi form đổi trạng thái bàn.")
			Me.Close()
		End Sub

		' Token: 0x060006A3 RID: 1699 RVA: 0x0004EAD4 File Offset: 0x0004CCD4
		Private Sub frmChangeTableStatus_Load(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Me.fInitCaption()
				Me.dtgStatus.Rows.Add(New Object() { "0", Me.mArrStrFrmMess(5) })
				Me.dtgStatus.Rows.Add(New Object() { "1", Me.mArrStrFrmMess(6) })
				Me.dtgStatus.Rows.Add(New Object() { "2", Me.mArrStrFrmMess(7) })
				Me.dtgStatus.Rows.Add(New Object() { "3", Me.mArrStrFrmMess(8) })
				Me.dtgStatus.Rows.Add(New Object() { "4", Me.mArrStrFrmMess(9) })
				Me.dtgStatus.Rows.Add(New Object() { "5", Me.mArrStrFrmMess(12) })
				Me.dtgStatus.Rows.Add(New Object() { "6", Me.mArrStrFrmMess(13) })
				Dim clsConnect As clsConnect = New clsConnect()
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMBAN_STATUSMAU")
				Dim flag As Boolean = clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
				If flag Then
					Dim num As Integer = 0
					Dim num2 As Integer = clsConnect.Rows.Count - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						Me.lblColor.BackColor = Color.FromArgb(Conversions.ToInteger(clsConnect.Rows(num3)("BACKCOLORRED")), Conversions.ToInteger(clsConnect.Rows(num3)("BACKCOLORGREEN")), Conversions.ToInteger(clsConnect.Rows(num3)("BACKCOLORBLUE")))
						Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
						dataGridViewCellStyle.BackColor = Me.lblColor.BackColor
						Me.dtgStatus.Rows(num3).DefaultCellStyle = dataGridViewCellStyle
						num3 += 1
					End While
				End If
				clsConnect.Dispose()
				Me.dtgStatus.Columns(0).Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - frmSelectDepartment_Group_Load " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060006A4 RID: 1700 RVA: 0x0004EDD4 File Offset: 0x0004CFD4
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060006A5 RID: 1701 RVA: 0x0004EED0 File Offset: 0x0004D0D0
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean = Me.dtgStatus.SelectedRows.Count <= 0
				If flag Then
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(3), Me.mArrStrFrmMess(4), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
				Else
					Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
					Dim num As Integer = 0
					Dim num2 As Integer = Me.dtgStatus.Rows.Count - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						dataGridViewCellStyle = Me.dtgStatus.Rows(num3).DefaultCellStyle
						Me.lblColor.BackColor = dataGridViewCellStyle.BackColor
						Me.fUpdate(num3 + 1, "", Me.lblColor.BackColor.R, Me.lblColor.BackColor.G, Me.lblColor.BackColor.B)
						num3 += 1
					End While
					mdlVariable.gfrmSaleMode.gsLoadColorTable()
					mdlVariable.gfrmSaleMode.gsUpdateTableStatus(Me.mstrMaBan.Trim(), Conversions.ToByte(Me.dtgStatus.SelectedRows(0).Cells(0).Value), False)
					mdlFile.gfWriteLogFile(Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("Nhấn nút Lưu thay đổi bảng màu và cập nhật trạng thái là: ", Me.dtgStatus.SelectedRows(0).Cells(0).Value), " cho bàn có mã: "), Me.mstrMaBan.Trim())))
					flag = Not mdlVariable.gblnUMASTER
					If flag Then
						mdlVariable.gfrmSaleMode.gs_SalMode_LoadTable_Info()
					End If
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnSelect_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060006A6 RID: 1702 RVA: 0x0000321A File Offset: 0x0000141A
		Private Sub dtgStatus_DoubleClick(sender As Object, e As EventArgs)
			Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
		End Sub

		' Token: 0x060006A7 RID: 1703 RVA: 0x0000322C File Offset: 0x0000142C
		Private Sub dtgStatus_RowEnter(sender As Object, e As DataGridViewCellEventArgs)
			Me.mintSelectIndexNhom = e.RowIndex
		End Sub

		' Token: 0x060006A8 RID: 1704 RVA: 0x0004F0FC File Offset: 0x0004D2FC
		Private Sub btnColor_Click(sender As Object, e As EventArgs)
			Try
				Dim frmcolorsetting As frmcolorsetting = New frmcolorsetting()
				frmcolorsetting.ShowDialog()
				Dim pblnresult As Boolean = frmcolorsetting.pblnresult
				If pblnresult Then
					Me.lblColor.BackColor = Color.FromArgb(Conversions.ToInteger(frmcolorsetting.pbytColorDefred), Conversions.ToInteger(frmcolorsetting.pbytColorDefgreen), Conversions.ToInteger(frmcolorsetting.pbytColorDefblue))
					Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
					dataGridViewCellStyle.BackColor = Me.lblColor.BackColor
					Me.dtgStatus.Rows(Me.dtgStatus.CurrentRow.Index).DefaultCellStyle = dataGridViewCellStyle
					mdlFile.gfWriteLogFile("Chọn màu: " + Me.lblColor.BackColor.ToString() + " cho " + Me.dtgStatus.Rows(Me.dtgStatus.CurrentRow.Index).Cells(1).Value.ToString())
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnColor_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060006A9 RID: 1705 RVA: 0x0004F26C File Offset: 0x0004D46C
		Private Function fUpdate(pintOJID As Integer, pStrName As String, pbytRed As Byte, pbytGreen As Byte, pbytBlue As Byte) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(6) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnvcOBJID"
				array(0).Value = pintOJID
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nvcOBJNAME"
				array(1).Value = pStrName.Trim()
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@tniBACKCOLORRED"
				array(2).Value = pbytRed
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@tniBACKCOLORGREEN"
				array(3).Value = pbytGreen
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@tniBACKCOLORBLUE"
				array(4).Value = pbytBlue
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@int_Result"
				array(5).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMBAN_STATUSMAU_UPDATE", flag)
				Dim num As Integer = Conversions.ToInteger(array(5).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(11), "", frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(11), vbCrLf, Me.Name, " - fUpdate ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x040002D8 RID: 728
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040002DA RID: 730
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040002DB RID: 731
		<AccessedThroughProperty("TableLayoutPanel5")>
		Private _TableLayoutPanel5 As TableLayoutPanel

		' Token: 0x040002DC RID: 732
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040002DD RID: 733
		<AccessedThroughProperty("dtgStatus")>
		Private _dtgStatus As DataGridView

		' Token: 0x040002DE RID: 734
		<AccessedThroughProperty("Column1")>
		Private _Column1 As DataGridViewTextBoxColumn

		' Token: 0x040002DF RID: 735
		<AccessedThroughProperty("Column2")>
		Private _Column2 As DataGridViewTextBoxColumn

		' Token: 0x040002E0 RID: 736
		<AccessedThroughProperty("btnColor")>
		Private _btnColor As Button

		' Token: 0x040002E1 RID: 737
		<AccessedThroughProperty("lblColor")>
		Private _lblColor As Label

		' Token: 0x040002E2 RID: 738
		Private mArrStrFrmMess As String()

		' Token: 0x040002E3 RID: 739
		Private mintSelectIndexNhom As Integer

		' Token: 0x040002E4 RID: 740
		Private mstrMaBan As String
	End Class
End Namespace
