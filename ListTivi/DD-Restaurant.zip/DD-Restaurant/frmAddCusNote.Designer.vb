﻿Namespace prjIS_SalesPOS
	' Token: 0x02000016 RID: 22
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmAddCusNote
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600028E RID: 654 RVA: 0x00020EC0 File Offset: 0x0001F0C0
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600028F RID: 655 RVA: 0x00020EF8 File Offset: 0x0001F0F8
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Global.System.ComponentModel.Container()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmAddCusNote))
			Me.txtNoiDung = New Global.System.Windows.Forms.TextBox()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.lblMA1 = New Global.System.Windows.Forms.Label()
			Me.txtTEN1 = New Global.System.Windows.Forms.TextBox()
			Me.btnDM1 = New Global.System.Windows.Forms.Button()
			Me.txtMA1 = New Global.System.Windows.Forms.TextBox()
			Me.dtpTuNgay = New Global.System.Windows.Forms.DateTimePicker()
			Me.mtxDATE = New Global.System.Windows.Forms.MaskedTextBox()
			Me.lblFilterDate = New Global.System.Windows.Forms.Label()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.lblSTT = New Global.System.Windows.Forms.Label()
			Me.picIMG1 = New Global.System.Windows.Forms.PictureBox()
			Me.picIMG2 = New Global.System.Windows.Forms.PictureBox()
			Me.picIMG3 = New Global.System.Windows.Forms.PictureBox()
			Me.btnDelIMG1 = New Global.System.Windows.Forms.Button()
			Me.btnDelIMG2 = New Global.System.Windows.Forms.Button()
			Me.btnDelIMG3 = New Global.System.Windows.Forms.Button()
			Me.ToolTip1 = New Global.System.Windows.Forms.ToolTip(Me.components)
			CType(Me.picIMG1, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.picIMG2, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.picIMG3, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.txtNoiDung.Font = New Global.System.Drawing.Font("Arial", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtNoiDung As Global.System.Windows.Forms.Control = Me.txtNoiDung
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(8, 105)
			txtNoiDung.Location = point
			Me.txtNoiDung.MaxLength = 1000
			Me.txtNoiDung.Multiline = True
			Me.txtNoiDung.Name = "txtNoiDung"
			Dim txtNoiDung2 As Global.System.Windows.Forms.Control = Me.txtNoiDung
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(440, 157)
			txtNoiDung2.Size = size
			Me.txtNoiDung.TabIndex = 2
			Me.txtNoiDung.Tag = ""
			Me.btnExit.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(336, 435)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(111, 41)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 4
			Me.btnExit.Tag = "C00002"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = False
			Me.btnSave.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnSave.BackgroundImage = CType(componentResourceManager.GetObject("btnSave.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnSave.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnSave.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnSave.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Me.btnSave.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(7, 435)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(111, 41)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 3
			Me.btnSave.Tag = "C00001"
			Me.btnSave.Text = "Lưu"
			Me.btnSave.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = False
			Me.lblMA1.AutoSize = True
			Me.lblMA1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMA As Global.System.Windows.Forms.Control = Me.lblMA1
			point = New Global.System.Drawing.Point(8, 51)
			lblMA.Location = point
			Me.lblMA1.Name = "lblMA1"
			Dim lblMA2 As Global.System.Windows.Forms.Control = Me.lblMA1
			size = New Global.System.Drawing.Size(84, 16)
			lblMA2.Size = size
			Me.lblMA1.TabIndex = 64
			Me.lblMA1.Tag = "CR0012"
			Me.lblMA1.Text = "Khách hàng"
			Me.txtTEN1.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.txtTEN1.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtTEN As Global.System.Windows.Forms.Control = Me.txtTEN1
			point = New Global.System.Drawing.Point(219, 45)
			txtTEN.Location = point
			Me.txtTEN1.Name = "txtTEN1"
			Dim txtTEN2 As Global.System.Windows.Forms.Control = Me.txtTEN1
			size = New Global.System.Drawing.Size(229, 29)
			txtTEN2.Size = size
			Me.txtTEN1.TabIndex = 63
			Me.txtTEN1.Tag = ""
			Me.btnDM1.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnDM1.Image = CType(componentResourceManager.GetObject("btnDM1.Image"), Global.System.Drawing.Image)
			Dim btnDM As Global.System.Windows.Forms.Control = Me.btnDM1
			point = New Global.System.Drawing.Point(185, 44)
			btnDM.Location = point
			Me.btnDM1.Name = "btnDM1"
			Dim btnDM2 As Global.System.Windows.Forms.Control = Me.btnDM1
			size = New Global.System.Drawing.Size(34, 31)
			btnDM2.Size = size
			Me.btnDM1.TabIndex = 5
			Me.btnDM1.Tag = ""
			Me.btnDM1.UseVisualStyleBackColor = True
			Me.txtMA1.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtMA1.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtMA As Global.System.Windows.Forms.Control = Me.txtMA1
			point = New Global.System.Drawing.Point(106, 45)
			txtMA.Location = point
			Me.txtMA1.Name = "txtMA1"
			Dim txtMA2 As Global.System.Windows.Forms.Control = Me.txtMA1
			size = New Global.System.Drawing.Size(79, 29)
			txtMA2.Size = size
			Me.txtMA1.TabIndex = 1
			Me.txtMA1.Tag = ""
			Me.dtpTuNgay.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim dtpTuNgay As Global.System.Windows.Forms.Control = Me.dtpTuNgay
			point = New Global.System.Drawing.Point(234, 9)
			dtpTuNgay.Location = point
			Me.dtpTuNgay.Name = "dtpTuNgay"
			Dim dtpTuNgay2 As Global.System.Windows.Forms.Control = Me.dtpTuNgay
			size = New Global.System.Drawing.Size(20, 29)
			dtpTuNgay2.Size = size
			Me.dtpTuNgay.TabIndex = 68
			Me.mtxDATE.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim mtxDATE As Global.System.Windows.Forms.Control = Me.mtxDATE
			point = New Global.System.Drawing.Point(106, 9)
			mtxDATE.Location = point
			Me.mtxDATE.Mask = "00/00/0000"
			Me.mtxDATE.Name = "mtxDATE"
			Me.mtxDATE.PromptChar = "-"c
			Dim mtxDATE2 As Global.System.Windows.Forms.Control = Me.mtxDATE
			size = New Global.System.Drawing.Size(129, 29)
			mtxDATE2.Size = size
			Me.mtxDATE.TabIndex = 0
			Me.mtxDATE.Tag = ""
			Me.mtxDATE.ValidatingType = GetType(Global.System.DateTime)
			Me.lblFilterDate.AutoSize = True
			Me.lblFilterDate.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFilterDate As Global.System.Windows.Forms.Control = Me.lblFilterDate
			point = New Global.System.Drawing.Point(8, 18)
			lblFilterDate.Location = point
			Me.lblFilterDate.Name = "lblFilterDate"
			Dim lblFilterDate2 As Global.System.Windows.Forms.Control = Me.lblFilterDate
			size = New Global.System.Drawing.Size(40, 16)
			lblFilterDate2.Size = size
			Me.lblFilterDate.TabIndex = 66
			Me.lblFilterDate.Tag = "CR0003"
			Me.lblFilterDate.Text = "Ngày"
			Me.Label1.AutoSize = True
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(8, 83)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(65, 16)
			label2.Size = size
			Me.Label1.TabIndex = 64
			Me.Label1.Tag = "CR0013"
			Me.Label1.Text = "Nội dung"
			Me.Label2.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label2.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(-9, 429)
			label3.Location = point
			Me.Label2.Name = "Label2"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(466, 1)
			label4.Size = size
			Me.Label2.TabIndex = 64
			Me.Label2.Tag = ""
			Me.lblSTT.AutoSize = True
			Me.lblSTT.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblSTT As Global.System.Windows.Forms.Control = Me.lblSTT
			point = New Global.System.Drawing.Point(277, 17)
			lblSTT.Location = point
			Me.lblSTT.Name = "lblSTT"
			Dim lblSTT2 As Global.System.Windows.Forms.Control = Me.lblSTT
			size = New Global.System.Drawing.Size(33, 16)
			lblSTT2.Size = size
			Me.lblSTT.TabIndex = 66
			Me.lblSTT.Tag = ""
			Me.lblSTT.Text = "STT"
			Me.lblSTT.Visible = False
			Me.picIMG1.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.picIMG1.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Dim picIMG As Global.System.Windows.Forms.Control = Me.picIMG1
			point = New Global.System.Drawing.Point(7, 268)
			picIMG.Location = point
			Me.picIMG1.Name = "picIMG1"
			Dim picIMG2 As Global.System.Windows.Forms.Control = Me.picIMG1
			size = New Global.System.Drawing.Size(147, 158)
			picIMG2.Size = size
			Me.picIMG1.TabIndex = 69
			Me.picIMG1.TabStop = False
			Me.picIMG2.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.picIMG2.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Dim picIMG3 As Global.System.Windows.Forms.Control = Me.picIMG2
			point = New Global.System.Drawing.Point(155, 268)
			picIMG3.Location = point
			Me.picIMG2.Name = "picIMG2"
			Dim picIMG4 As Global.System.Windows.Forms.Control = Me.picIMG2
			size = New Global.System.Drawing.Size(147, 158)
			picIMG4.Size = size
			Me.picIMG2.TabIndex = 69
			Me.picIMG2.TabStop = False
			Me.picIMG3.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.picIMG3.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Dim picIMG5 As Global.System.Windows.Forms.Control = Me.picIMG3
			point = New Global.System.Drawing.Point(303, 268)
			picIMG5.Location = point
			Me.picIMG3.Name = "picIMG3"
			Dim picIMG6 As Global.System.Windows.Forms.Control = Me.picIMG3
			size = New Global.System.Drawing.Size(147, 158)
			picIMG6.Size = size
			Me.picIMG3.TabIndex = 69
			Me.picIMG3.TabStop = False
			Me.btnDelIMG1.FlatAppearance.BorderColor = Global.System.Drawing.Color.DarkRed
			Me.btnDelIMG1.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btnDelIMG1.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 9F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnDelIMG1.ForeColor = Global.System.Drawing.Color.Red
			Dim btnDelIMG As Global.System.Windows.Forms.Control = Me.btnDelIMG1
			point = New Global.System.Drawing.Point(125, 400)
			btnDelIMG.Location = point
			Me.btnDelIMG1.Name = "btnDelIMG1"
			Dim btnDelIMG2 As Global.System.Windows.Forms.Control = Me.btnDelIMG1
			size = New Global.System.Drawing.Size(28, 25)
			btnDelIMG2.Size = size
			Me.btnDelIMG1.TabIndex = 70
			Me.btnDelIMG1.Text = "X"
			Me.btnDelIMG1.UseVisualStyleBackColor = True
			Me.btnDelIMG2.FlatAppearance.BorderColor = Global.System.Drawing.Color.DarkRed
			Me.btnDelIMG2.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btnDelIMG2.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 9F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnDelIMG2.ForeColor = Global.System.Drawing.Color.Red
			Dim btnDelIMG3 As Global.System.Windows.Forms.Control = Me.btnDelIMG2
			point = New Global.System.Drawing.Point(274, 400)
			btnDelIMG3.Location = point
			Me.btnDelIMG2.Name = "btnDelIMG2"
			Dim btnDelIMG4 As Global.System.Windows.Forms.Control = Me.btnDelIMG2
			size = New Global.System.Drawing.Size(28, 25)
			btnDelIMG4.Size = size
			Me.btnDelIMG2.TabIndex = 70
			Me.btnDelIMG2.Text = "X"
			Me.btnDelIMG2.UseVisualStyleBackColor = True
			Me.btnDelIMG3.FlatAppearance.BorderColor = Global.System.Drawing.Color.DarkRed
			Me.btnDelIMG3.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btnDelIMG3.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 9F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnDelIMG3.ForeColor = Global.System.Drawing.Color.Red
			Dim btnDelIMG5 As Global.System.Windows.Forms.Control = Me.btnDelIMG3
			point = New Global.System.Drawing.Point(421, 400)
			btnDelIMG5.Location = point
			Me.btnDelIMG3.Name = "btnDelIMG3"
			Dim btnDelIMG6 As Global.System.Windows.Forms.Control = Me.btnDelIMG3
			size = New Global.System.Drawing.Size(28, 25)
			btnDelIMG6.Size = size
			Me.btnDelIMG3.TabIndex = 70
			Me.btnDelIMG3.Text = "X"
			Me.btnDelIMG3.UseVisualStyleBackColor = True
			Me.ToolTip1.IsBalloon = True
			Me.ToolTip1.ToolTipIcon = Global.System.Windows.Forms.ToolTipIcon.Info
			Me.ToolTip1.ToolTipTitle = "Image path"
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(8F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(455, 479)
			Me.ClientSize = size
			Me.Controls.Add(Me.btnDelIMG3)
			Me.Controls.Add(Me.btnDelIMG2)
			Me.Controls.Add(Me.btnDelIMG1)
			Me.Controls.Add(Me.picIMG3)
			Me.Controls.Add(Me.picIMG2)
			Me.Controls.Add(Me.picIMG1)
			Me.Controls.Add(Me.dtpTuNgay)
			Me.Controls.Add(Me.mtxDATE)
			Me.Controls.Add(Me.lblSTT)
			Me.Controls.Add(Me.lblFilterDate)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.lblMA1)
			Me.Controls.Add(Me.txtTEN1)
			Me.Controls.Add(Me.btnDM1)
			Me.Controls.Add(Me.txtMA1)
			Me.Controls.Add(Me.btnExit)
			Me.Controls.Add(Me.btnSave)
			Me.Controls.Add(Me.txtNoiDung)
			Me.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 10F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(4)
			Me.Margin = padding
			Me.Name = "frmAddCusNote"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Ghi chú"
			CType(Me.picIMG1, Global.System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.picIMG2, Global.System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.picIMG3, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x04000119 RID: 281
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
