﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000108 RID: 264
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedcrpKitchenK58ChuyenBan
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005637 RID: 22071 RVA: 0x0000ECA7 File Offset: 0x0000CEA7
		Public Sub New()
			CachedcrpKitchenK58ChuyenBan.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001EBE RID: 7870
		' (get) Token: 0x06005638 RID: 22072 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005639 RID: 22073 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17001EBF RID: 7871
		' (get) Token: 0x0600563A RID: 22074 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x0600563B RID: 22075 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17001EC0 RID: 7872
		' (get) Token: 0x0600563C RID: 22076 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x0600563D RID: 22077 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x0600563E RID: 22078 RVA: 0x004DAC60 File Offset: 0x004D8E60
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New crpKitchenK58ChuyenBan() With { .Site = Me.Site }
		End Function

		' Token: 0x0600563F RID: 22079 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002700 RID: 9984
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
