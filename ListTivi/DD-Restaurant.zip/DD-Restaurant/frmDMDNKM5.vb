﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000041 RID: 65
	<DesignerGenerated()>
	Public Partial Class frmDMDNKM5
		Inherits Form

		' Token: 0x06000FBC RID: 4028 RVA: 0x000BB2F4 File Offset: 0x000B94F4
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMBP2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMBP2_Load
			frmDMDNKM5.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mbytAllData = 0
			Me.mbtySingle = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700058E RID: 1422
		' (get) Token: 0x06000FBF RID: 4031 RVA: 0x000BBCC8 File Offset: 0x000B9EC8
		' (set) Token: 0x06000FC0 RID: 4032 RVA: 0x00004795 File Offset: 0x00002995
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x1700058F RID: 1423
		' (get) Token: 0x06000FC1 RID: 4033 RVA: 0x000BBCE0 File Offset: 0x000B9EE0
		' (set) Token: 0x06000FC2 RID: 4034 RVA: 0x000BBCF8 File Offset: 0x000B9EF8
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000590 RID: 1424
		' (get) Token: 0x06000FC3 RID: 4035 RVA: 0x000BBD64 File Offset: 0x000B9F64
		' (set) Token: 0x06000FC4 RID: 4036 RVA: 0x000BBD7C File Offset: 0x000B9F7C
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000591 RID: 1425
		' (get) Token: 0x06000FC5 RID: 4037 RVA: 0x000BBDE8 File Offset: 0x000B9FE8
		' (set) Token: 0x06000FC6 RID: 4038 RVA: 0x000BBE00 File Offset: 0x000BA000
		Friend Overridable Property btnThemAll As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnThemAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnThemAll IsNot Nothing
				If flag Then
					RemoveHandler Me._btnThemAll.Click, AddressOf Me.btnThemAll_Click
				End If
				Me._btnThemAll = value
				flag = Me._btnThemAll IsNot Nothing
				If flag Then
					AddHandler Me._btnThemAll.Click, AddressOf Me.btnThemAll_Click
				End If
			End Set
		End Property

		' Token: 0x17000592 RID: 1426
		' (get) Token: 0x06000FC7 RID: 4039 RVA: 0x000BBE6C File Offset: 0x000BA06C
		' (set) Token: 0x06000FC8 RID: 4040 RVA: 0x000BBE84 File Offset: 0x000BA084
		Friend Overridable Property btnThem1MH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnThem1MH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnThem1MH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnThem1MH.Click, AddressOf Me.btnThem1MH_Click
				End If
				Me._btnThem1MH = value
				flag = Me._btnThem1MH IsNot Nothing
				If flag Then
					AddHandler Me._btnThem1MH.Click, AddressOf Me.btnThem1MH_Click
				End If
			End Set
		End Property

		' Token: 0x17000593 RID: 1427
		' (get) Token: 0x06000FC9 RID: 4041 RVA: 0x000BBEF0 File Offset: 0x000BA0F0
		' (set) Token: 0x06000FCA RID: 4042 RVA: 0x000BBF08 File Offset: 0x000BA108
		Friend Overridable Property btnGobo As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnGobo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnGobo IsNot Nothing
				If flag Then
					RemoveHandler Me._btnGobo.Click, AddressOf Me.btnGobo_Click
				End If
				Me._btnGobo = value
				flag = Me._btnGobo IsNot Nothing
				If flag Then
					AddHandler Me._btnGobo.Click, AddressOf Me.btnGobo_Click
				End If
			End Set
		End Property

		' Token: 0x17000594 RID: 1428
		' (get) Token: 0x06000FCB RID: 4043 RVA: 0x000BBF74 File Offset: 0x000BA174
		' (set) Token: 0x06000FCC RID: 4044 RVA: 0x0000479F File Offset: 0x0000299F
		Friend Overridable Property lstHanghoaThemAll As ListBox
			<DebuggerNonUserCode()>
			Get
				Return Me._lstHanghoaThemAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Me._lstHanghoaThemAll = value
			End Set
		End Property

		' Token: 0x17000595 RID: 1429
		' (get) Token: 0x06000FCD RID: 4045 RVA: 0x000BBF8C File Offset: 0x000BA18C
		' (set) Token: 0x06000FCE RID: 4046 RVA: 0x000047A9 File Offset: 0x000029A9
		Friend Overridable Property lstHangHoaSur As ListBox
			<DebuggerNonUserCode()>
			Get
				Return Me._lstHangHoaSur
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Me._lstHangHoaSur = value
			End Set
		End Property

		' Token: 0x17000596 RID: 1430
		' (get) Token: 0x06000FCF RID: 4047 RVA: 0x000BBFA4 File Offset: 0x000BA1A4
		' (set) Token: 0x06000FD0 RID: 4048 RVA: 0x000BBFBC File Offset: 0x000BA1BC
		Friend Overridable Property btnGoboHHSur As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnGoboHHSur
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnGoboHHSur IsNot Nothing
				If flag Then
					RemoveHandler Me._btnGoboHHSur.Click, AddressOf Me.btnGoboHHSur_Click
				End If
				Me._btnGoboHHSur = value
				flag = Me._btnGoboHHSur IsNot Nothing
				If flag Then
					AddHandler Me._btnGoboHHSur.Click, AddressOf Me.btnGoboHHSur_Click
				End If
			End Set
		End Property

		' Token: 0x17000597 RID: 1431
		' (get) Token: 0x06000FD1 RID: 4049 RVA: 0x000BC028 File Offset: 0x000BA228
		' (set) Token: 0x06000FD2 RID: 4050 RVA: 0x000BC040 File Offset: 0x000BA240
		Friend Overridable Property btnThem1HHSur As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnThem1HHSur
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnThem1HHSur IsNot Nothing
				If flag Then
					RemoveHandler Me._btnThem1HHSur.Click, AddressOf Me.btnThem1HHSur_Click
				End If
				Me._btnThem1HHSur = value
				flag = Me._btnThem1HHSur IsNot Nothing
				If flag Then
					AddHandler Me._btnThem1HHSur.Click, AddressOf Me.btnThem1HHSur_Click
				End If
			End Set
		End Property

		' Token: 0x17000598 RID: 1432
		' (get) Token: 0x06000FD3 RID: 4051 RVA: 0x000BC0AC File Offset: 0x000BA2AC
		' (set) Token: 0x06000FD4 RID: 4052 RVA: 0x000047B3 File Offset: 0x000029B3
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000599 RID: 1433
		' (get) Token: 0x06000FD5 RID: 4053 RVA: 0x000BC0C4 File Offset: 0x000BA2C4
		' (set) Token: 0x06000FD6 RID: 4054 RVA: 0x000047BD File Offset: 0x000029BD
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Me._mbdsSource = value
			End Set
		End Property

		' Token: 0x1700059A RID: 1434
		' (get) Token: 0x06000FD7 RID: 4055 RVA: 0x000BC0DC File Offset: 0x000BA2DC
		' (set) Token: 0x06000FD8 RID: 4056 RVA: 0x000047C7 File Offset: 0x000029C7
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x1700059B RID: 1435
		' (get) Token: 0x06000FD9 RID: 4057 RVA: 0x000BC0F4 File Offset: 0x000BA2F4
		' (set) Token: 0x06000FDA RID: 4058 RVA: 0x000047D2 File Offset: 0x000029D2
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x1700059C RID: 1436
		' (get) Token: 0x06000FDB RID: 4059 RVA: 0x000BC10C File Offset: 0x000BA30C
		' (set) Token: 0x06000FDC RID: 4060 RVA: 0x000047DD File Offset: 0x000029DD
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x1700059D RID: 1437
		' (get) Token: 0x06000FDD RID: 4061 RVA: 0x000BC124 File Offset: 0x000BA324
		' (set) Token: 0x06000FDE RID: 4062 RVA: 0x000047E8 File Offset: 0x000029E8
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x1700059E RID: 1438
		' (get) Token: 0x06000FDF RID: 4063 RVA: 0x000BC13C File Offset: 0x000BA33C
		' (set) Token: 0x06000FE0 RID: 4064 RVA: 0x000047F3 File Offset: 0x000029F3
		Public Property pStrMAHHSALE As String
			Get
				Return Me.mStrMAHHSALE
			End Get
			Set(value As String)
				Me.mStrMAHHSALE = value
			End Set
		End Property

		' Token: 0x1700059F RID: 1439
		' (get) Token: 0x06000FE1 RID: 4065 RVA: 0x000BC154 File Offset: 0x000BA354
		' (set) Token: 0x06000FE2 RID: 4066 RVA: 0x000047FE File Offset: 0x000029FE
		Public Property pStrMAHHSUR As String
			Get
				Return Me.mStrMAHHSUR
			End Get
			Set(value As String)
				Me.mStrMAHHSUR = value
			End Set
		End Property

		' Token: 0x06000FE3 RID: 4067 RVA: 0x000BC16C File Offset: 0x000BA36C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FE4 RID: 4068 RVA: 0x000BC1F8 File Offset: 0x000BA3F8
		Private Sub frmDMBP2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000FE5 RID: 4069 RVA: 0x000BC290 File Offset: 0x000BA490
		Private Sub frmDMBP2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000FE6 RID: 4070 RVA: 0x000BC350 File Offset: 0x000BA550
		Private Sub btnGobo_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytFlag = 3
				Me.fGetData_4ListBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnGobo_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FE7 RID: 4071 RVA: 0x000BC3E4 File Offset: 0x000BA5E4
		Private Sub btnThem1HHSur_Click(sender As Object, e As EventArgs)
			Try
				Me.sGetData_4ListBoxSur()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnGoboHHSur_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FE8 RID: 4072 RVA: 0x000BC470 File Offset: 0x000BA670
		Private Sub btnGoboHHSur_Click(sender As Object, e As EventArgs)
			Try
				Me.sGobo_ListBoxSur()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnGoboHHSur_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FE9 RID: 4073 RVA: 0x000BC4FC File Offset: 0x000BA6FC
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.lstHanghoaThemAll.Items.Count = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(13) + vbCrLf & vbCrLf, MsgBoxStyle.Critical, Nothing)
					Me.lstHanghoaThemAll.Focus()
				Else
					flag = Me.lstHangHoaSur.Items.Count = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(14) + vbCrLf & vbCrLf, MsgBoxStyle.Critical, Nothing)
						Me.lstHangHoaSur.Focus()
					Else
						flag = Me.lstHanghoaThemAll.Items.Count > 0
						Dim flag3 As Boolean
						If flag Then
							Dim flag2 As Boolean = Me.lstHangHoaSur.Items.Count > 1
							If flag2 Then
								flag3 = Me.lstHanghoaThemAll.Items.Count <> Me.lstHangHoaSur.Items.Count
								If flag3 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(15) + vbCrLf & vbCrLf, MsgBoxStyle.Critical, Nothing)
									Me.btnThem1HHSur.Focus()
									Return
								End If
							End If
						End If
						flag3 = Me.mbytFormStatus = 1
						If flag3 Then
							Me.sAdd()
						Else
							flag3 = (Me.mbytFormStatus = 3) Or (Me.mbytFormStatus = 4)
							If flag3 Then
								Me.mbytSuccess = Me.fModify()
								Me.sAdd()
							End If
						End If
						flag3 = Me.mbytSuccess = 1
						If flag3 Then
							Me.Close()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000FEA RID: 4074 RVA: 0x000BC718 File Offset: 0x000BA918
		Private Sub btnThemAll_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytFlag = 1
				Me.fGetData_4ListBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnThemAll_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FEB RID: 4075 RVA: 0x000BC7AC File Offset: 0x000BA9AC
		Private Sub btnThem1MH_Click(sender As Object, e As EventArgs)
			Me.mbytFlag = 2
			Try
				Dim frmDMHH As frmDMHH1 = New frmDMHH1()
				frmDMHH.pBytOpen_From_Menu = 7
				frmDMHH.ShowDialog()
				Me.mstrMAHH = ""
				Me.mstrTENHH = ""
				Me.mstrMAHH = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMHH.pStrOBJID, "", False) = 0, Me.mstrMAHH, frmDMHH.pStrOBJID))
				Me.mstrTENHH = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMHH.pStrOBJNAME, "", False) = 0, Me.mstrTENHH, frmDMHH.pStrOBJNAME))
				frmDMHH.Dispose()
				Dim flag As Boolean = (Operators.CompareString(Me.mstrMAHH, "", False) <> 0) And (Operators.CompareString(Me.mstrTENHH, "", False) <> 0)
				If flag Then
					Me.fGetData_4ListBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnThem1MH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000FEC RID: 4076 RVA: 0x000BC92C File Offset: 0x000BAB2C
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 4
						Me.sDisplay_Moddelete()
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000FED RID: 4077 RVA: 0x000BC9F4 File Offset: 0x000BABF4
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnSave.Enabled = False
				Me.btnExit.Enabled = True
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
					Case 4
						Me.btnSave.Enabled = True
						Me.btnExit.Focus()
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return b
		End Function

		' Token: 0x06000FEE RID: 4078 RVA: 0x000BCB04 File Offset: 0x000BAD04
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.lstHanghoaThemAll.SelectionMode = SelectionMode.MultiSimple
				Me.lstHangHoaSur.SelectionMode = SelectionMode.MultiSimple
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000FEF RID: 4079 RVA: 0x000BCBC8 File Offset: 0x000BADC8
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(5))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(6))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(7))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return b
		End Function

		' Token: 0x06000FF0 RID: 4080 RVA: 0x000BCD10 File Offset: 0x000BAF10
		Private Sub sClear_Form()
			Try
				Me.mclsTBHHThemAll.Dispose()
				Me.mclsTBHHSur.Dispose()
				Me.mclsTemp.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FF1 RID: 4081 RVA: 0x000BCDC8 File Offset: 0x000BAFC8
		Private Function fAddNew(strPara1 As String, strPara2 As String, strPara3 As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(4) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADNKM"
				array(0).Value = strPara1
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchMAHHSAL"
				array(1).Value = strPara2
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAHHSUR"
				array(2).Value = strPara3
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@int_Result"
				array(3).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_INSERT_DETAIL", flag)
				Dim num As Integer = Conversions.ToInteger(array(3).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(8), MsgBoxStyle.Critical, Nothing)
						Me.btnExit.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(9), MsgBoxStyle.Critical, Nothing)
							Me.btnExit.Focus()
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(10), MsgBoxStyle.Critical, Nothing)
								Me.btnExit.Focus()
							Else
								flag2 = num = 4
								If flag2 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(11), MsgBoxStyle.Critical, Nothing)
									Me.btnExit.Focus()
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000FF2 RID: 4082 RVA: 0x000BD018 File Offset: 0x000BB218
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADNKM"
				array(0).Value = Me.mStrOBJID
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_DEL_DETAIL", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000FF3 RID: 4083 RVA: 0x000BD168 File Offset: 0x000BB368
		Private Function fGetData_4ListBox() As Byte
			' The following expression was wrapped in a checked-statement
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = Me.mbytFlag = 1
				If flag Then
					Me.mclsTBHHThemAll = Nothing
					Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
					Me.sRefesh_ListBox()
				Else
					flag = Me.mbytFlag = 2
					If flag Then
						Dim array As DataColumn() = New DataColumn(0) {}
						flag = Me.lstHanghoaThemAll.Items.Count = 0
						If flag Then
							Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
							Me.mclsTBHHThemAll.Rows.Clear()
						End If
						flag = Me.mclsTBHHThemAll Is Nothing
						If flag Then
							Return b
						End If
						array(0) = Me.mclsTBHHThemAll.Columns("OBJID")
						Me.mclsTBHHThemAll.PrimaryKey = array
						Dim dataRow As DataRow = Me.mclsTBHHThemAll.Rows.Find(Me.mstrMAHH)
						flag = dataRow IsNot Nothing
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(12) + vbCrLf & vbCrLf, MsgBoxStyle.Critical, Nothing)
							Return b
						End If
						Me.mclsTBHHThemAll.Rows.Add(New Object() { Me.mstrMAHH, Me.mstrTENHH })
						Me.sRefesh_ListBox()
					Else
						flag = Me.mbytFlag = 3
						If flag Then
							Dim flag2 As Boolean = False
							Dim num As Integer = 0
							Dim num2 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
							Dim num3 As Integer = num
							While True
								Dim num4 As Integer = num3
								Dim num5 As Integer = num2
								If num4 > num5 Then
									GoTo IL_01AA
								End If
								flag = Me.lstHanghoaThemAll.GetSelected(num3)
								If flag Then
									Exit For
								End If
								num3 += 1
							End While
							flag2 = True
							IL_01AA:
							flag = flag2
							If flag Then
								Try
									Dim num6 As Integer = 0
									Dim num7 As Integer = 0
									Dim num8 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
									num3 = num7
									While True
										Dim num9 As Integer = num3
										Dim num5 As Integer = num8
										If num9 > num5 Then
											Exit For
										End If
										flag = Me.lstHanghoaThemAll.GetSelected(num3)
										If flag Then
											num6 += 1
										End If
										num3 += 1
									End While
									Dim array2 As DataRow() = New DataRow(num6 + 1 - 1) {}
									num6 = 0
									Dim num10 As Integer = 0
									Dim num11 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
									num3 = num10
									While True
										Dim num12 As Integer = num3
										Dim num5 As Integer = num11
										If num12 > num5 Then
											Exit For
										End If
										flag = Me.lstHanghoaThemAll.GetSelected(num3)
										If flag Then
											Dim dataRowView As DataRowView = CType(Me.lstHanghoaThemAll.Items(num3), DataRowView)
											Dim row As DataRow = dataRowView.Row
											array2(num6) = row
											num6 += 1
										End If
										num3 += 1
									End While
									Dim num13 As Integer = 0
									Dim num14 As Integer = num6
									num3 = num13
									While True
										Dim num15 As Integer = num3
										Dim num5 As Integer = num14
										If num15 > num5 Then
											Exit For
										End If
										Me.mclsTBHHThemAll.Rows.Remove(array2(num3))
										num3 += 1
									End While
								Catch ex As Exception
								End Try
								Me.lstHanghoaThemAll.DataSource = Nothing
								Me.sRefesh_ListBox()
							Else
								Me.lstHanghoaThemAll.DataSource = Nothing
							End If
						End If
					End If
				End If
				b = 1
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4ListBox ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000FF4 RID: 4084 RVA: 0x000BD514 File Offset: 0x000BB714
		Private Sub sRefesh_ListBox()
			Try
				Dim lstHanghoaThemAll As ListBox = Me.lstHanghoaThemAll
				lstHanghoaThemAll.DataSource = Me.mclsTBHHThemAll
				lstHanghoaThemAll.DisplayMember = "OBJNAME"
				lstHanghoaThemAll.ValueMember = "OBJID"
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sRefesh_ListBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FF5 RID: 4085 RVA: 0x000BD5C8 File Offset: 0x000BB7C8
		Private Sub sRefesh_ListBoxSur()
			Try
				Dim lstHangHoaSur As ListBox = Me.lstHangHoaSur
				lstHangHoaSur.DataSource = Me.mclsTBHHSur
				lstHangHoaSur.DisplayMember = "OBJNAME"
				lstHangHoaSur.ValueMember = "OBJID"
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sRefesh_ListBoxSur ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FF6 RID: 4086 RVA: 0x000BD67C File Offset: 0x000BB87C
		Private Sub sAdd()
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean = Me.lstHangHoaSur.Items.Count = 1
				If flag Then
					Dim num As Integer = 0
					Dim num2 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						Dim text As String = Conversions.ToString(NewLateBinding.LateIndexGet(Me.lstHanghoaThemAll.Items(num3), New Object() { "OBJID" }, Nothing))
						Dim text2 As String = Conversions.ToString(NewLateBinding.LateIndexGet(Me.lstHangHoaSur.Items(0), New Object() { "OBJID" }, Nothing))
						Me.mbytSuccess = Me.fAddNew(Me.mStrOBJID, Strings.Trim(text), Strings.Trim(text2))
						num3 += 1
					End While
				Else
					Dim num6 As Integer = 0
					Dim num7 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
					Dim num3 As Integer = num6
					While True
						Dim num8 As Integer = num3
						Dim num5 As Integer = num7
						If num8 > num5 Then
							Exit For
						End If
						Dim text As String = Conversions.ToString(NewLateBinding.LateIndexGet(Me.lstHanghoaThemAll.Items(num3), New Object() { "OBJID" }, Nothing))
						Dim text2 As String = Conversions.ToString(NewLateBinding.LateIndexGet(Me.lstHangHoaSur.Items(num3), New Object() { "OBJID" }, Nothing))
						Me.mbytSuccess = Me.fAddNew(Me.mStrOBJID, Strings.Trim(text), Strings.Trim(text2))
						num3 += 1
					End While
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sAdd ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FF7 RID: 4087 RVA: 0x000BD890 File Offset: 0x000BBA90
		Private Function fGetNameHH(strMAHH As String) As String
			Dim array As DataColumn() = New DataColumn(0) {}
			Dim text As String = ""
			Try
				Me.mclsTemp = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
				array(0) = Me.mclsTemp.Columns("OBJID")
				Me.mclsTemp.PrimaryKey = array
				Dim dataRow As DataRow = Me.mclsTemp.Rows.Find(strMAHH)
				Dim text2 As String = dataRow("OBJNAME").ToString()
				text = text2
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetNameHH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return text
		End Function

		' Token: 0x06000FF8 RID: 4088 RVA: 0x000BD994 File Offset: 0x000BBB94
		Private Sub sDisplay_Moddelete()
			Dim dataSet As DataSet = New DataSet()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim array2 As DataColumn() = New DataColumn(0) {}
			Try
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADNKM"
				array(0).Value = Me.mStrOBJID
				Dim num As Integer
				dataSet = New clsMyDataset(mdlVariable.gStrConISDANHMUC, array, "SP_frmDMDNKM5_GET_DATA", num)
				Dim flag As Boolean = Me.lstHanghoaThemAll.Items.Count = 0
				If flag Then
					Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
					Me.mclsTBHHThemAll.Rows.Clear()
				End If
				flag = Me.lstHangHoaSur.Items.Count = 0
				If flag Then
					Me.mclsTBHHSur = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
					Me.mclsTBHHSur.Rows.Clear()
				End If
				Dim num2 As Integer = dataSet.Tables(0).Rows.Count
				Dim array3 As String() = New String(num2 + 1 - 1) {}
				Dim num3 As Integer = 0
				Dim num4 As Integer = dataSet.Tables(0).Rows.Count - 1
				num2 = num3
				While True
					Dim num5 As Integer = num2
					Dim num6 As Integer = num4
					If num5 > num6 Then
						Exit For
					End If
					array3(num2) = Conversions.ToString(dataSet.Tables(0).Rows(num2)("MAHHSALE"))
					Dim text As String = array3(num2)
					Dim text2 As String = Me.fGetNameHH(Strings.Trim(text))
					Dim text3 As String = Conversions.ToString(dataSet.Tables(0).Rows(num2)("MAHHSUR"))
					Dim text4 As String = Me.fGetNameHH(Strings.Trim(text3))
					array2(0) = Me.mclsTBHHSur.Columns("OBJID")
					Me.mclsTBHHSur.PrimaryKey = array2
					Dim dataRow As DataRow = Me.mclsTBHHSur.Rows.Find(text3)
					Me.mclsTBHHThemAll.Rows.Add(New Object() { Strings.Trim(text), Strings.Trim(text2) })
					flag = dataRow IsNot Nothing
					If Not flag Then
						Me.mclsTBHHSur.Rows.Add(New Object() { Strings.Trim(text3), Strings.Trim(text4) })
					End If
					num2 += 1
				End While
				Me.sRefesh_ListBox()
				Me.sRefesh_ListBoxSur()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sDisplay_Moddelete ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000FF9 RID: 4089 RVA: 0x000BDCA0 File Offset: 0x000BBEA0
		Private Sub sGetData_4ListBoxSur()
			Dim frmDMHH As frmDMHH1 = New frmDMHH1()
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				frmDMHH.pBytOpen_From_Menu = 7
				frmDMHH.ShowDialog()
				Dim text As String = ""
				Dim text2 As String = ""
				text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMHH.pStrOBJID, "", False) = 0, text, frmDMHH.pStrOBJID))
				text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMHH.pStrOBJNAME, "", False) = 0, text2, frmDMHH.pStrOBJNAME))
				frmDMHH.Dispose()
				Dim flag As Boolean = Me.lstHangHoaSur.Items.Count = 0
				If flag Then
					Me.mclsTBHHSur = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
					Me.mclsTBHHSur.Rows.Clear()
				End If
				flag = Me.mclsTBHHSur Is Nothing
				If Not flag Then
					array(0) = Me.mclsTBHHSur.Columns("OBJID")
					Me.mclsTBHHSur.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTBHHSur.Rows.Find(text)
					flag = dataRow IsNot Nothing
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(12) + vbCrLf & vbCrLf, MsgBoxStyle.Critical, Nothing)
					Else
						flag = (Operators.CompareString(text, "", False) <> 0) And (Operators.CompareString(text2, "", False) <> 0)
						If flag Then
							Me.mclsTBHHSur.Rows.Add(New Object() { text, text2 })
							Me.sRefesh_ListBoxSur()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnThem1MH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000FFA RID: 4090 RVA: 0x000BDEEC File Offset: 0x000BC0EC
		Private Sub sGobo_ListBoxSur()
			Dim flag As Boolean = False
			Try
				Dim num As Integer = 0
				Dim num2 As Integer = Me.lstHangHoaSur.Items.Count - 1
				Dim num3 As Integer = num
				Dim flag2 As Boolean
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						GoTo IL_0042
					End If
					flag2 = Me.lstHangHoaSur.GetSelected(num3)
					If flag2 Then
						Exit For
					End If
					num3 += 1
				End While
				flag = True
				IL_0042:
				flag2 = flag
				If flag2 Then
					Try
						Dim num6 As Integer = 0
						Dim num7 As Integer = 0
						Dim num8 As Integer = Me.lstHangHoaSur.Items.Count - 1
						num3 = num7
						While True
							Dim num9 As Integer = num3
							Dim num5 As Integer = num8
							If num9 > num5 Then
								Exit For
							End If
							flag2 = Me.lstHangHoaSur.GetSelected(num3)
							If flag2 Then
								num6 += 1
							End If
							num3 += 1
						End While
						Dim array As DataRow() = New DataRow(num6 + 1 - 1) {}
						num6 = 0
						Dim num10 As Integer = 0
						Dim num11 As Integer = Me.lstHangHoaSur.Items.Count - 1
						num3 = num10
						While True
							Dim num12 As Integer = num3
							Dim num5 As Integer = num11
							If num12 > num5 Then
								Exit For
							End If
							flag2 = Me.lstHangHoaSur.GetSelected(num3)
							If flag2 Then
								Dim dataRowView As DataRowView = CType(Me.lstHangHoaSur.Items(num3), DataRowView)
								Dim row As DataRow = dataRowView.Row
								array(num6) = row
								num6 += 1
							End If
							num3 += 1
						End While
						Dim num13 As Integer = 0
						Dim num14 As Integer = num6
						num3 = num13
						While True
							Dim num15 As Integer = num3
							Dim num5 As Integer = num14
							If num15 > num5 Then
								Exit For
							End If
							Me.mclsTBHHSur.Rows.Remove(array(num3))
							num3 += 1
						End While
					Catch ex As Exception
					End Try
					Me.lstHangHoaSur.DataSource = Nothing
					Me.sRefesh_ListBoxSur()
				Else
					Me.lstHangHoaSur.DataSource = Nothing
				End If
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGobo_ListBoxSur ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x040006A8 RID: 1704
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040006AA RID: 1706
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x040006AB RID: 1707
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040006AC RID: 1708
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x040006AD RID: 1709
		<AccessedThroughProperty("btnThemAll")>
		Private _btnThemAll As Button

		' Token: 0x040006AE RID: 1710
		<AccessedThroughProperty("btnThem1MH")>
		Private _btnThem1MH As Button

		' Token: 0x040006AF RID: 1711
		<AccessedThroughProperty("btnGobo")>
		Private _btnGobo As Button

		' Token: 0x040006B0 RID: 1712
		<AccessedThroughProperty("lstHanghoaThemAll")>
		Private _lstHanghoaThemAll As ListBox

		' Token: 0x040006B1 RID: 1713
		<AccessedThroughProperty("lstHangHoaSur")>
		Private _lstHangHoaSur As ListBox

		' Token: 0x040006B2 RID: 1714
		<AccessedThroughProperty("btnGoboHHSur")>
		Private _btnGoboHHSur As Button

		' Token: 0x040006B3 RID: 1715
		<AccessedThroughProperty("btnThem1HHSur")>
		Private _btnThem1HHSur As Button

		' Token: 0x040006B4 RID: 1716
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040006B5 RID: 1717
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040006B6 RID: 1718
		Private mArrStrFrmMess As String()

		' Token: 0x040006B7 RID: 1719
		Private mbytFormStatus As Byte

		' Token: 0x040006B8 RID: 1720
		Private mbytSuccess As Byte

		' Token: 0x040006B9 RID: 1721
		Private mStrFilter As String

		' Token: 0x040006BA RID: 1722
		Private mStrOBJID As String

		' Token: 0x040006BB RID: 1723
		Private mStrMAHHSALE As String

		' Token: 0x040006BC RID: 1724
		Private mStrMAHHSUR As String

		' Token: 0x040006BD RID: 1725
		Private mclsTBHHThemAll As clsConnect

		' Token: 0x040006BE RID: 1726
		Private mclsTBHHSur As clsConnect

		' Token: 0x040006BF RID: 1727
		Private mclsTemp As clsConnect

		' Token: 0x040006C0 RID: 1728
		Private mbytFlag As Byte

		' Token: 0x040006C1 RID: 1729
		Private mstrMAHH As String

		' Token: 0x040006C2 RID: 1730
		Private mstrTENHH As String

		' Token: 0x040006C3 RID: 1731
		Private mbytAllData As Byte

		' Token: 0x040006C4 RID: 1732
		Private mbtySingle As Byte
	End Class
End Namespace
