﻿Namespace prjIS_SalesPOS
	' Token: 0x02000037 RID: 55
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMAUTOPRICE4
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000C52 RID: 3154 RVA: 0x00090E84 File Offset: 0x0008F084
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000C53 RID: 3155 RVA: 0x00090EBC File Offset: 0x0008F0BC
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMAUTOPRICE4))
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.lblMAHH = New Global.System.Windows.Forms.Label()
			Me.txtTENHH = New Global.System.Windows.Forms.TextBox()
			Me.btnSelDMHH = New Global.System.Windows.Forms.Button()
			Me.txtMAHH = New Global.System.Windows.Forms.TextBox()
			Me.lblDONGIA = New Global.System.Windows.Forms.Label()
			Me.cmbPrice = New Global.System.Windows.Forms.ComboBox()
			Me.txtTENDVT = New Global.System.Windows.Forms.TextBox()
			Me.btnDMDVT = New Global.System.Windows.Forms.Button()
			Me.txtMADVT = New Global.System.Windows.Forms.TextBox()
			Me.lblDVTinh = New Global.System.Windows.Forms.Label()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.SuspendLayout()
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(3, 369)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(113, 118)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 2
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 3)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(113, 116)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 0
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 125)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(113, 116)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 1
			Me.btnDelete.Tag = "CR0004"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.lblMAHH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAHH As Global.System.Windows.Forms.Control = Me.lblMAHH
			point = New Global.System.Drawing.Point(9, 11)
			lblMAHH.Location = point
			Me.lblMAHH.Name = "lblMAHH"
			Dim lblMAHH2 As Global.System.Windows.Forms.Control = Me.lblMAHH
			size = New Global.System.Drawing.Size(154, 21)
			lblMAHH2.Size = size
			Me.lblMAHH.TabIndex = 33
			Me.lblMAHH.Tag = "CR0007"
			Me.lblMAHH.Text = "Mã hàng hóa"
			Me.txtTENHH.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Dim txtTENHH As Global.System.Windows.Forms.Control = Me.txtTENHH
			point = New Global.System.Drawing.Point(304, 12)
			txtTENHH.Location = point
			Me.txtTENHH.Name = "txtTENHH"
			Me.txtTENHH.[ReadOnly] = True
			Dim txtTENHH2 As Global.System.Windows.Forms.Control = Me.txtTENHH
			size = New Global.System.Drawing.Size(226, 22)
			txtTENHH2.Size = size
			Me.txtTENHH.TabIndex = 2
			Me.txtTENHH.Tag = "0R0000"
			Dim btnSelDMHH As Global.System.Windows.Forms.Control = Me.btnSelDMHH
			point = New Global.System.Drawing.Point(263, 12)
			btnSelDMHH.Location = point
			Me.btnSelDMHH.Name = "btnSelDMHH"
			Dim btnSelDMHH2 As Global.System.Windows.Forms.Control = Me.btnSelDMHH
			size = New Global.System.Drawing.Size(35, 22)
			btnSelDMHH2.Size = size
			Me.btnSelDMHH.TabIndex = 1
			Me.btnSelDMHH.Tag = "CB0011"
			Me.btnSelDMHH.UseVisualStyleBackColor = True
			Me.txtMAHH.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAHH As Global.System.Windows.Forms.Control = Me.txtMAHH
			point = New Global.System.Drawing.Point(125, 12)
			txtMAHH.Location = point
			Me.txtMAHH.Name = "txtMAHH"
			Dim txtMAHH2 As Global.System.Windows.Forms.Control = Me.txtMAHH
			size = New Global.System.Drawing.Size(132, 22)
			txtMAHH2.Size = size
			Me.txtMAHH.TabIndex = 0
			Me.txtMAHH.Tag = "0R0000"
			Me.lblDONGIA.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblDONGIA As Global.System.Windows.Forms.Control = Me.lblDONGIA
			point = New Global.System.Drawing.Point(9, 73)
			lblDONGIA.Location = point
			Me.lblDONGIA.Name = "lblDONGIA"
			Dim lblDONGIA2 As Global.System.Windows.Forms.Control = Me.lblDONGIA
			size = New Global.System.Drawing.Size(110, 21)
			lblDONGIA2.Size = size
			Me.lblDONGIA.TabIndex = 76
			Me.lblDONGIA.Tag = "CR0009"
			Me.lblDONGIA.Text = "Đơn giá bán"
			Me.cmbPrice.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbPrice.FormattingEnabled = True
			Dim cmbPrice As Global.System.Windows.Forms.Control = Me.cmbPrice
			point = New Global.System.Drawing.Point(125, 68)
			cmbPrice.Location = point
			Me.cmbPrice.Name = "cmbPrice"
			Dim cmbPrice2 As Global.System.Windows.Forms.Control = Me.cmbPrice
			size = New Global.System.Drawing.Size(65, 24)
			cmbPrice2.Size = size
			Me.cmbPrice.TabIndex = 4
			Me.cmbPrice.Tag = "0R0000"
			Me.txtTENDVT.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Dim txtTENDVT As Global.System.Windows.Forms.Control = Me.txtTENDVT
			point = New Global.System.Drawing.Point(304, 40)
			txtTENDVT.Location = point
			Me.txtTENDVT.Name = "txtTENDVT"
			Me.txtTENDVT.[ReadOnly] = True
			Dim txtTENDVT2 As Global.System.Windows.Forms.Control = Me.txtTENDVT
			size = New Global.System.Drawing.Size(226, 22)
			txtTENDVT2.Size = size
			Me.txtTENDVT.TabIndex = 7
			Me.txtTENDVT.Tag = "0R0000"
			Dim btnDMDVT As Global.System.Windows.Forms.Control = Me.btnDMDVT
			point = New Global.System.Drawing.Point(263, 40)
			btnDMDVT.Location = point
			Me.btnDMDVT.Name = "btnDMDVT"
			Dim btnDMDVT2 As Global.System.Windows.Forms.Control = Me.btnDMDVT
			size = New Global.System.Drawing.Size(35, 22)
			btnDMDVT2.Size = size
			Me.btnDMDVT.TabIndex = 3
			Me.btnDMDVT.Tag = "CB0011"
			Me.btnDMDVT.UseVisualStyleBackColor = True
			Me.txtMADVT.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMADVT As Global.System.Windows.Forms.Control = Me.txtMADVT
			point = New Global.System.Drawing.Point(125, 40)
			txtMADVT.Location = point
			Me.txtMADVT.Name = "txtMADVT"
			Dim txtMADVT2 As Global.System.Windows.Forms.Control = Me.txtMADVT
			size = New Global.System.Drawing.Size(132, 22)
			txtMADVT2.Size = size
			Me.txtMADVT.TabIndex = 2
			Me.txtMADVT.Tag = "0R0000"
			Me.lblDVTinh.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblDVTinh As Global.System.Windows.Forms.Control = Me.lblDVTinh
			point = New Global.System.Drawing.Point(9, 39)
			lblDVTinh.Location = point
			Me.lblDVTinh.Name = "lblDVTinh"
			Dim lblDVTinh2 As Global.System.Windows.Forms.Control = Me.lblDVTinh
			size = New Global.System.Drawing.Size(154, 21)
			lblDVTinh2.Size = size
			Me.lblDVTinh.TabIndex = 128
			Me.lblDVTinh.Tag = "CR0008"
			Me.lblDVTinh.Text = "Mã DVt"
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Absolute, 20F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 1)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(536, 0)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 4
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(119, 490)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 129
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(655, 490)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.TableLayoutPanel1)
			Me.Controls.Add(Me.txtTENDVT)
			Me.Controls.Add(Me.btnDMDVT)
			Me.Controls.Add(Me.txtMADVT)
			Me.Controls.Add(Me.lblDVTinh)
			Me.Controls.Add(Me.cmbPrice)
			Me.Controls.Add(Me.txtTENHH)
			Me.Controls.Add(Me.btnSelDMHH)
			Me.Controls.Add(Me.txtMAHH)
			Me.Controls.Add(Me.lblDONGIA)
			Me.Controls.Add(Me.lblMAHH)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMAUTOPRICE4"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "frmDOCUMENT024"
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x04000557 RID: 1367
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
