﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200026E RID: 622
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60606_TheoGio
		Inherits Component
		Implements ICachedReport

		' Token: 0x060065DB RID: 26075 RVA: 0x000125FD File Offset: 0x000107FD
		Public Sub New()
			CachedrptRepBC60606_TheoGio.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002764 RID: 10084
		' (get) Token: 0x060065DC RID: 26076 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060065DD RID: 26077 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002765 RID: 10085
		' (get) Token: 0x060065DE RID: 26078 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060065DF RID: 26079 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002766 RID: 10086
		' (get) Token: 0x060065E0 RID: 26080 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060065E1 RID: 26081 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x060065E2 RID: 26082 RVA: 0x004DD920 File Offset: 0x004DBB20
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60606_TheoGio() With { .Site = Me.Site }
		End Function

		' Token: 0x060065E3 RID: 26083 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002866 RID: 10342
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
