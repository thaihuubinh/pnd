﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000052 RID: 82
	<DesignerGenerated()>
	Public Partial Class frmDMHTTT2
		Inherits Form

		' Token: 0x0600186F RID: 6255 RVA: 0x0012F80C File Offset: 0x0012DA0C
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMHTTT2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMHTTT2_Load
			frmDMHTTT2.__ENCList.Add(New WeakReference(Me))
			Me.mblnFix = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000874 RID: 2164
		' (get) Token: 0x06001872 RID: 6258 RVA: 0x001307E4 File Offset: 0x0012E9E4
		' (set) Token: 0x06001873 RID: 6259 RVA: 0x00005962 File Offset: 0x00003B62
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x17000875 RID: 2165
		' (get) Token: 0x06001874 RID: 6260 RVA: 0x001307FC File Offset: 0x0012E9FC
		' (set) Token: 0x06001875 RID: 6261 RVA: 0x00130814 File Offset: 0x0012EA14
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000876 RID: 2166
		' (get) Token: 0x06001876 RID: 6262 RVA: 0x00130880 File Offset: 0x0012EA80
		' (set) Token: 0x06001877 RID: 6263 RVA: 0x00130898 File Offset: 0x0012EA98
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000877 RID: 2167
		' (get) Token: 0x06001878 RID: 6264 RVA: 0x00130934 File Offset: 0x0012EB34
		' (set) Token: 0x06001879 RID: 6265 RVA: 0x0000596C File Offset: 0x00003B6C
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x17000878 RID: 2168
		' (get) Token: 0x0600187A RID: 6266 RVA: 0x0013094C File Offset: 0x0012EB4C
		' (set) Token: 0x0600187B RID: 6267 RVA: 0x00005976 File Offset: 0x00003B76
		Friend Overridable Property chkISSUP As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkISSUP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Me._chkISSUP = value
			End Set
		End Property

		' Token: 0x17000879 RID: 2169
		' (get) Token: 0x0600187C RID: 6268 RVA: 0x00130964 File Offset: 0x0012EB64
		' (set) Token: 0x0600187D RID: 6269 RVA: 0x00005980 File Offset: 0x00003B80
		Friend Overridable Property lblBRANCH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblBRANCH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblBRANCH = value
			End Set
		End Property

		' Token: 0x1700087A RID: 2170
		' (get) Token: 0x0600187E RID: 6270 RVA: 0x0013097C File Offset: 0x0012EB7C
		' (set) Token: 0x0600187F RID: 6271 RVA: 0x0000598A File Offset: 0x00003B8A
		Friend Overridable Property lblADDRESS As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblADDRESS
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblADDRESS = value
			End Set
		End Property

		' Token: 0x1700087B RID: 2171
		' (get) Token: 0x06001880 RID: 6272 RVA: 0x00130994 File Offset: 0x0012EB94
		' (set) Token: 0x06001881 RID: 6273 RVA: 0x00005994 File Offset: 0x00003B94
		Friend Overridable Property txtColor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtColor = value
			End Set
		End Property

		' Token: 0x1700087C RID: 2172
		' (get) Token: 0x06001882 RID: 6274 RVA: 0x001309AC File Offset: 0x0012EBAC
		' (set) Token: 0x06001883 RID: 6275 RVA: 0x001309C4 File Offset: 0x0012EBC4
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x1700087D RID: 2173
		' (get) Token: 0x06001884 RID: 6276 RVA: 0x00130A30 File Offset: 0x0012EC30
		' (set) Token: 0x06001885 RID: 6277 RVA: 0x00130A48 File Offset: 0x0012EC48
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x1700087E RID: 2174
		' (get) Token: 0x06001886 RID: 6278 RVA: 0x00130AB4 File Offset: 0x0012ECB4
		' (set) Token: 0x06001887 RID: 6279 RVA: 0x00130ACC File Offset: 0x0012ECCC
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x1700087F RID: 2175
		' (get) Token: 0x06001888 RID: 6280 RVA: 0x00130B38 File Offset: 0x0012ED38
		' (set) Token: 0x06001889 RID: 6281 RVA: 0x0000599E File Offset: 0x00003B9E
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x17000880 RID: 2176
		' (get) Token: 0x0600188A RID: 6282 RVA: 0x00130B50 File Offset: 0x0012ED50
		' (set) Token: 0x0600188B RID: 6283 RVA: 0x00130B68 File Offset: 0x0012ED68
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000881 RID: 2177
		' (get) Token: 0x0600188C RID: 6284 RVA: 0x00130BD4 File Offset: 0x0012EDD4
		' (set) Token: 0x0600188D RID: 6285 RVA: 0x000059A8 File Offset: 0x00003BA8
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000882 RID: 2178
		' (get) Token: 0x0600188E RID: 6286 RVA: 0x00130BEC File Offset: 0x0012EDEC
		' (set) Token: 0x0600188F RID: 6287 RVA: 0x00130C04 File Offset: 0x0012EE04
		Friend Overridable Property txtREMARK As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtREMARK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtREMARK IsNot Nothing
				If flag Then
					RemoveHandler Me._txtREMARK.KeyPress, AddressOf Me.txtREMARK_KeyPress
				End If
				Me._txtREMARK = value
				flag = Me._txtREMARK IsNot Nothing
				If flag Then
					AddHandler Me._txtREMARK.KeyPress, AddressOf Me.txtREMARK_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000883 RID: 2179
		' (get) Token: 0x06001890 RID: 6288 RVA: 0x00130C70 File Offset: 0x0012EE70
		' (set) Token: 0x06001891 RID: 6289 RVA: 0x000059B2 File Offset: 0x00003BB2
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000884 RID: 2180
		' (get) Token: 0x06001892 RID: 6290 RVA: 0x00130C88 File Offset: 0x0012EE88
		' (set) Token: 0x06001893 RID: 6291 RVA: 0x000059BC File Offset: 0x00003BBC
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000885 RID: 2181
		' (get) Token: 0x06001894 RID: 6292 RVA: 0x00130CA0 File Offset: 0x0012EEA0
		' (set) Token: 0x06001895 RID: 6293 RVA: 0x000059C6 File Offset: 0x00003BC6
		Friend Overridable Property txtSUBOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtSUBOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtSUBOBJNAME = value
			End Set
		End Property

		' Token: 0x17000886 RID: 2182
		' (get) Token: 0x06001896 RID: 6294 RVA: 0x00130CB8 File Offset: 0x0012EEB8
		' (set) Token: 0x06001897 RID: 6295 RVA: 0x00130CD0 File Offset: 0x0012EED0
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x17000887 RID: 2183
		' (get) Token: 0x06001898 RID: 6296 RVA: 0x00130D3C File Offset: 0x0012EF3C
		' (set) Token: 0x06001899 RID: 6297 RVA: 0x000059D0 File Offset: 0x00003BD0
		Public Property pblnFix As Boolean
			Get
				Return Me.mblnFix
			End Get
			Set(value As Boolean)
				Me.mblnFix = value
			End Set
		End Property

		' Token: 0x17000888 RID: 2184
		' (get) Token: 0x0600189A RID: 6298 RVA: 0x00130D54 File Offset: 0x0012EF54
		' (set) Token: 0x0600189B RID: 6299 RVA: 0x000059DB File Offset: 0x00003BDB
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000889 RID: 2185
		' (get) Token: 0x0600189C RID: 6300 RVA: 0x00130D6C File Offset: 0x0012EF6C
		' (set) Token: 0x0600189D RID: 6301 RVA: 0x000059E6 File Offset: 0x00003BE6
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x1700088A RID: 2186
		' (get) Token: 0x0600189E RID: 6302 RVA: 0x00130D84 File Offset: 0x0012EF84
		' (set) Token: 0x0600189F RID: 6303 RVA: 0x000059F1 File Offset: 0x00003BF1
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x060018A0 RID: 6304 RVA: 0x00130D9C File Offset: 0x0012EF9C
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018A1 RID: 6305 RVA: 0x00130E48 File Offset: 0x0012F048
		Private Sub txtREMARK_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060018A2 RID: 6306 RVA: 0x00130EEC File Offset: 0x0012F0EC
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtREMARK.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060018A3 RID: 6307 RVA: 0x00130F90 File Offset: 0x0012F190
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060018A4 RID: 6308 RVA: 0x00131038 File Offset: 0x0012F238
		Private Sub frmDMHTTT2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHTTT2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018A5 RID: 6309 RVA: 0x001310E4 File Offset: 0x0012F2E4
		Private Sub frmDMHTTT2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHTTT2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018A6 RID: 6310 RVA: 0x00131190 File Offset: 0x0012F390
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
						If flag Then
							Me.mbytSuccess = Me.fcheckAddNew()
						Else
							flag = Me.mbytFormStatus = 3
							If flag Then
								Me.mbytSuccess = Me.fcheckModiy()
							End If
						End If
						flag = Me.mbytSuccess = 1
						If flag Then
							Me.Close()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018A7 RID: 6311 RVA: 0x0013131C File Offset: 0x0012F51C
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018A8 RID: 6312 RVA: 0x001313C0 File Offset: 0x0012F5C0
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJname like '" + text2 + "%'"
				End If
				flag = Me.chkISSUP.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LDEBT ="), Interaction.IIf(Me.chkISSUP.Checked, 1, 0)), ""))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtREMARK.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " remark like '" + text2 + "%'"
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018A9 RID: 6313 RVA: 0x00131680 File Offset: 0x0012F880
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " OBJname like '" + text2 + "%'"
				End If
				flag = Me.chkISSUP.CheckState <> CheckState.Indeterminate
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " LDEBT ="), Interaction.IIf(Me.chkISSUP.Checked, 1, 0)), ""))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtREMARK.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text2 = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Mid(text2, 1, 1), "*", False) = 0, "%" + Strings.Mid(text2, 2), text2))
					text = " remark like '" + text2 + "%'"
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018AA RID: 6314 RVA: 0x00131940 File Offset: 0x0012FB40
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtSUBOBJNAME.[ReadOnly] = True
						Me.txtREMARK.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.BackColor = Me.txtColor.BackColor
						Me.txtSUBOBJNAME.BackColor = Me.txtColor.BackColor
						Me.txtREMARK.BackColor = Me.txtColor.BackColor
						Me.chkISSUP.Enabled = False
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060018AB RID: 6315 RVA: 0x00131AEC File Offset: 0x0012FCEC
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060018AC RID: 6316 RVA: 0x00131C7C File Offset: 0x0012FE7C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 2
				Me.txtOBJNAME.MaxLength = 100
				Dim flag As Boolean = (Me.mbytFormStatus = 5) Or (Me.mbytFormStatus = 6)
				If flag Then
					Me.chkISSUP.CheckState = CheckState.Indeterminate
				Else
					flag = Me.mbytFormStatus = 4
					If flag Then
						Me.txtREMARK.Enabled = False
					End If
				End If
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060018AD RID: 6317 RVA: 0x00131D90 File Offset: 0x0012FF90
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060018AE RID: 6318 RVA: 0x00131F74 File Offset: 0x00130174
		Private Sub sClear_Form()
			Try
				Me.mclsTbStore.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060018AF RID: 6319 RVA: 0x00132020 File Offset: 0x00130220
		Private Function fcheckName() As Integer
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim clsConnect As clsConnect = New clsConnect()
			Dim num2 As Integer
			Try
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnvcTEN"
				array(0).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHTTT_TRUNGTEN_DMHTTT", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				num2 = num
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return num2
		End Function

		' Token: 0x060018B0 RID: 6320 RVA: 0x00132160 File Offset: 0x00130360
		Private Function fcheckAddNew() As Byte
			Dim b As Byte
			Try
				Me.fcheckName()
				b = 0
				Dim flag As Boolean = Me.fcheckName() = 1
				If flag Then
					Select Case MessageBox.Show(Me.mArrStrFrmMess(34), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
						Case DialogResult.Yes
							Me.fAddNew()
							b = 1
						Case DialogResult.No
							Me.txtOBJNAME.Text = ""
							Me.txtOBJNAME.Focus()
					End Select
				Else
					Me.fAddNew()
					b = 1
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060018B1 RID: 6321 RVA: 0x00132280 File Offset: 0x00130480
		Private Function fcheckModiy() As Byte
			Me.fcheckName()
			Dim b As Byte = 0
			Try
				Dim flag As Boolean = Me.fcheckName() = 1
				If flag Then
					Select Case MessageBox.Show(Me.mArrStrFrmMess(34), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
						Case DialogResult.Yes
							Me.fModify()
							b = 1
						Case DialogResult.No
							Me.txtOBJNAME.Text = ""
							Me.txtOBJNAME.Focus()
					End Select
				Else
					Me.fModify()
					b = 1
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060018B2 RID: 6322 RVA: 0x001323A0 File Offset: 0x001305A0
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(7) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnvcMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pbitSUP"
				array(2).Value = Me.chkISSUP.Checked
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcGC"
				array(3).Value = Strings.Trim(Me.txtREMARK.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvcFIXED"
				array(4).Value = "0"
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcSUBOBJNAME"
				array(6).Value = Me.txtSUBOBJNAME.Text.Trim()
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@int_Result"
				array(5).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHTTT_INSERT_DMHTTT", flag)
				Dim num As Integer = Conversions.ToInteger(array(5).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060018B3 RID: 6323 RVA: 0x00132644 File Offset: 0x00130844
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(7) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnchTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pbitSUP"
				array(2).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkISSUP.Checked, 1, 0))
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchREMARK"
				array(3).Value = Strings.Trim(Me.txtREMARK.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnvcSUBOBJNAME"
				array(6).Value = Me.txtSUBOBJNAME.Text.Trim()
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pbitFIX"
				array(5).Value = Me.mblnFix
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@int_Result"
				array(4).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHTTT_UPDATE_DMHTTT", flag)
				Dim num As Integer = Conversions.ToInteger(array(4).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060018B4 RID: 6324 RVA: 0x00132910 File Offset: 0x00130B10
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHTTT_DEL_DMHTTT", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060018B5 RID: 6325 RVA: 0x00132AA0 File Offset: 0x00130CA0
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x060018B6 RID: 6326 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x04000A22 RID: 2594
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000A24 RID: 2596
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000A25 RID: 2597
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000A26 RID: 2598
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000A27 RID: 2599
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000A28 RID: 2600
		<AccessedThroughProperty("chkISSUP")>
		Private _chkISSUP As CheckBox

		' Token: 0x04000A29 RID: 2601
		<AccessedThroughProperty("lblBRANCH")>
		Private _lblBRANCH As Label

		' Token: 0x04000A2A RID: 2602
		<AccessedThroughProperty("lblADDRESS")>
		Private _lblADDRESS As Label

		' Token: 0x04000A2B RID: 2603
		<AccessedThroughProperty("txtColor")>
		Private _txtColor As TextBox

		' Token: 0x04000A2C RID: 2604
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000A2D RID: 2605
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000A2E RID: 2606
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000A2F RID: 2607
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000A30 RID: 2608
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000A31 RID: 2609
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000A32 RID: 2610
		<AccessedThroughProperty("txtREMARK")>
		Private _txtREMARK As TextBox

		' Token: 0x04000A33 RID: 2611
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000A34 RID: 2612
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000A35 RID: 2613
		<AccessedThroughProperty("txtSUBOBJNAME")>
		Private _txtSUBOBJNAME As TextBox

		' Token: 0x04000A36 RID: 2614
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000A37 RID: 2615
		Private mArrStrFrmMess As String()

		' Token: 0x04000A38 RID: 2616
		Private mbytFormStatus As Byte

		' Token: 0x04000A39 RID: 2617
		Private mbytSuccess As Byte

		' Token: 0x04000A3A RID: 2618
		Private mStrFilter As String

		' Token: 0x04000A3B RID: 2619
		Private pStrStore As String

		' Token: 0x04000A3C RID: 2620
		Private mclsTbStore As clsConnect

		' Token: 0x04000A3D RID: 2621
		Private mclsTbDMBK As clsConnect

		' Token: 0x04000A3E RID: 2622
		Private mblnFix As Boolean
	End Class
End Namespace
