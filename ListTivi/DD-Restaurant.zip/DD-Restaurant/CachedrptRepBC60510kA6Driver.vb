﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000212 RID: 530
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60510kA6Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006172 RID: 24946 RVA: 0x00011741 File Offset: 0x0000F941
		Public Sub New()
			CachedrptRepBC60510kA6Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170024C7 RID: 9415
		' (get) Token: 0x06006173 RID: 24947 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006174 RID: 24948 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170024C8 RID: 9416
		' (get) Token: 0x06006175 RID: 24949 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006176 RID: 24950 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170024C9 RID: 9417
		' (get) Token: 0x06006177 RID: 24951 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006178 RID: 24952 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006179 RID: 24953 RVA: 0x004DCDA0 File Offset: 0x004DAFA0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60510kA6Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x0600617A RID: 24954 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x0400280A RID: 10250
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
