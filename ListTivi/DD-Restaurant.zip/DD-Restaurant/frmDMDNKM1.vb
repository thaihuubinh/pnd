﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200003D RID: 61
	<DesignerGenerated()>
	Public Partial Class frmDMDNKM1
		Inherits Form

		' Token: 0x06000E03 RID: 3587 RVA: 0x000A512C File Offset: 0x000A332C
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmDMDNKM1_Load
			AddHandler MyBase.Activated, AddressOf Me.frmDMDNKM1_Activated
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMDNKM1_FormClosing
			frmDMDNKM1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.InitializeComponent()
		End Sub

		' Token: 0x170004FD RID: 1277
		' (get) Token: 0x06000E06 RID: 3590 RVA: 0x000A6730 File Offset: 0x000A4930
		' (set) Token: 0x06000E07 RID: 3591 RVA: 0x00004451 File Offset: 0x00002651
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x170004FE RID: 1278
		' (get) Token: 0x06000E08 RID: 3592 RVA: 0x000A6748 File Offset: 0x000A4948
		' (set) Token: 0x06000E09 RID: 3593 RVA: 0x000A6760 File Offset: 0x000A4960
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x170004FF RID: 1279
		' (get) Token: 0x06000E0A RID: 3594 RVA: 0x000A67CC File Offset: 0x000A49CC
		' (set) Token: 0x06000E0B RID: 3595 RVA: 0x000A67E4 File Offset: 0x000A49E4
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000500 RID: 1280
		' (get) Token: 0x06000E0C RID: 3596 RVA: 0x000A6850 File Offset: 0x000A4A50
		' (set) Token: 0x06000E0D RID: 3597 RVA: 0x000A6868 File Offset: 0x000A4A68
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000501 RID: 1281
		' (get) Token: 0x06000E0E RID: 3598 RVA: 0x000A68D4 File Offset: 0x000A4AD4
		' (set) Token: 0x06000E0F RID: 3599 RVA: 0x000A68EC File Offset: 0x000A4AEC
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000502 RID: 1282
		' (get) Token: 0x06000E10 RID: 3600 RVA: 0x000A6958 File Offset: 0x000A4B58
		' (set) Token: 0x06000E11 RID: 3601 RVA: 0x000A6970 File Offset: 0x000A4B70
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000503 RID: 1283
		' (get) Token: 0x06000E12 RID: 3602 RVA: 0x000A69DC File Offset: 0x000A4BDC
		' (set) Token: 0x06000E13 RID: 3603 RVA: 0x000A69F4 File Offset: 0x000A4BF4
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000504 RID: 1284
		' (get) Token: 0x06000E14 RID: 3604 RVA: 0x000A6A60 File Offset: 0x000A4C60
		' (set) Token: 0x06000E15 RID: 3605 RVA: 0x000A6A78 File Offset: 0x000A4C78
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000505 RID: 1285
		' (get) Token: 0x06000E16 RID: 3606 RVA: 0x000A6AE4 File Offset: 0x000A4CE4
		' (set) Token: 0x06000E17 RID: 3607 RVA: 0x0000445B File Offset: 0x0000265B
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000506 RID: 1286
		' (get) Token: 0x06000E18 RID: 3608 RVA: 0x000A6AFC File Offset: 0x000A4CFC
		' (set) Token: 0x06000E19 RID: 3609 RVA: 0x000A6B14 File Offset: 0x000A4D14
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000507 RID: 1287
		' (get) Token: 0x06000E1A RID: 3610 RVA: 0x000A6B80 File Offset: 0x000A4D80
		' (set) Token: 0x06000E1B RID: 3611 RVA: 0x000A6B98 File Offset: 0x000A4D98
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x17000508 RID: 1288
		' (get) Token: 0x06000E1C RID: 3612 RVA: 0x000A6C04 File Offset: 0x000A4E04
		' (set) Token: 0x06000E1D RID: 3613 RVA: 0x000A6C1C File Offset: 0x000A4E1C
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000509 RID: 1289
		' (get) Token: 0x06000E1E RID: 3614 RVA: 0x000A6C88 File Offset: 0x000A4E88
		' (set) Token: 0x06000E1F RID: 3615 RVA: 0x00004465 File Offset: 0x00002665
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x1700050A RID: 1290
		' (get) Token: 0x06000E20 RID: 3616 RVA: 0x000A6CA0 File Offset: 0x000A4EA0
		' (set) Token: 0x06000E21 RID: 3617 RVA: 0x000A6CB8 File Offset: 0x000A4EB8
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x1700050B RID: 1291
		' (get) Token: 0x06000E22 RID: 3618 RVA: 0x000A6D24 File Offset: 0x000A4F24
		' (set) Token: 0x06000E23 RID: 3619 RVA: 0x000A6D3C File Offset: 0x000A4F3C
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x1700050C RID: 1292
		' (get) Token: 0x06000E24 RID: 3620 RVA: 0x000A6DA8 File Offset: 0x000A4FA8
		' (set) Token: 0x06000E25 RID: 3621 RVA: 0x000A6DC0 File Offset: 0x000A4FC0
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700050D RID: 1293
		' (get) Token: 0x06000E26 RID: 3622 RVA: 0x000A6E2C File Offset: 0x000A502C
		' (set) Token: 0x06000E27 RID: 3623 RVA: 0x000A6E44 File Offset: 0x000A5044
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x1700050E RID: 1294
		' (get) Token: 0x06000E28 RID: 3624 RVA: 0x000A6EB0 File Offset: 0x000A50B0
		' (set) Token: 0x06000E29 RID: 3625 RVA: 0x0000446F File Offset: 0x0000266F
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x1700050F RID: 1295
		' (get) Token: 0x06000E2A RID: 3626 RVA: 0x000A6EC8 File Offset: 0x000A50C8
		' (set) Token: 0x06000E2B RID: 3627 RVA: 0x00004479 File Offset: 0x00002679
		Friend Overridable Property lblMANH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMANH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMANH = value
			End Set
		End Property

		' Token: 0x17000510 RID: 1296
		' (get) Token: 0x06000E2C RID: 3628 RVA: 0x000A6EE0 File Offset: 0x000A50E0
		' (set) Token: 0x06000E2D RID: 3629 RVA: 0x00004483 File Offset: 0x00002683
		Friend Overridable Property txtOBJNAMEKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAMEKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAMEKH = value
			End Set
		End Property

		' Token: 0x17000511 RID: 1297
		' (get) Token: 0x06000E2E RID: 3630 RVA: 0x000A6EF8 File Offset: 0x000A50F8
		' (set) Token: 0x06000E2F RID: 3631 RVA: 0x000A6F10 File Offset: 0x000A5110
		Friend Overridable Property btnSelectKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelectKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelectKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelectKH.Click, AddressOf Me.btnSelectKH_Click
				End If
				Me._btnSelectKH = value
				flag = Me._btnSelectKH IsNot Nothing
				If flag Then
					AddHandler Me._btnSelectKH.Click, AddressOf Me.btnSelectKH_Click
				End If
			End Set
		End Property

		' Token: 0x17000512 RID: 1298
		' (get) Token: 0x06000E30 RID: 3632 RVA: 0x000A6F7C File Offset: 0x000A517C
		' (set) Token: 0x06000E31 RID: 3633 RVA: 0x000A6F94 File Offset: 0x000A5194
		Friend Overridable Property txtMAKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
				Me._txtMAKH = value
				flag = Me._txtMAKH IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000513 RID: 1299
		' (get) Token: 0x06000E32 RID: 3634 RVA: 0x000A7000 File Offset: 0x000A5200
		' (set) Token: 0x06000E33 RID: 3635 RVA: 0x000A7018 File Offset: 0x000A5218
		Friend Overridable Property btnDetail As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDetail
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDetail IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDetail.Click, AddressOf Me.btnDetail_Click
				End If
				Me._btnDetail = value
				flag = Me._btnDetail IsNot Nothing
				If flag Then
					AddHandler Me._btnDetail.Click, AddressOf Me.btnDetail_Click
				End If
			End Set
		End Property

		' Token: 0x17000514 RID: 1300
		' (get) Token: 0x06000E34 RID: 3636 RVA: 0x000A7084 File Offset: 0x000A5284
		' (set) Token: 0x06000E35 RID: 3637 RVA: 0x0000448D File Offset: 0x0000268D
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000515 RID: 1301
		' (get) Token: 0x06000E36 RID: 3638 RVA: 0x000A709C File Offset: 0x000A529C
		' (set) Token: 0x06000E37 RID: 3639 RVA: 0x000A70B4 File Offset: 0x000A52B4
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000516 RID: 1302
		' (get) Token: 0x06000E38 RID: 3640 RVA: 0x000A7120 File Offset: 0x000A5320
		' (set) Token: 0x06000E39 RID: 3641 RVA: 0x00004497 File Offset: 0x00002697
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x17000517 RID: 1303
		' (get) Token: 0x06000E3A RID: 3642 RVA: 0x000A7138 File Offset: 0x000A5338
		' (set) Token: 0x06000E3B RID: 3643 RVA: 0x000044A2 File Offset: 0x000026A2
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000518 RID: 1304
		' (get) Token: 0x06000E3C RID: 3644 RVA: 0x000A7150 File Offset: 0x000A5350
		' (set) Token: 0x06000E3D RID: 3645 RVA: 0x000044AD File Offset: 0x000026AD
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06000E3E RID: 3646 RVA: 0x000A7168 File Offset: 0x000A5368
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E3F RID: 3647 RVA: 0x000A7238 File Offset: 0x000A5438
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E40 RID: 3648 RVA: 0x000A7328 File Offset: 0x000A5528
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E41 RID: 3649 RVA: 0x000A740C File Offset: 0x000A560C
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E42 RID: 3650 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub frmDMDNKM1_Activated(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06000E43 RID: 3651 RVA: 0x000A74D0 File Offset: 0x000A56D0
		Private Sub frmDMDNKM1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E44 RID: 3652 RVA: 0x000A7568 File Offset: 0x000A5768
		Private Sub frmDMDNKM1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				Me.sGetDMKH()
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E45 RID: 3653 RVA: 0x000A7678 File Offset: 0x000A5878
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E46 RID: 3654 RVA: 0x000A7780 File Offset: 0x000A5980
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E47 RID: 3655 RVA: 0x000A7818 File Offset: 0x000A5A18
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMDNKM As frmDMDNKM2 = New frmDMDNKM2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMDNKM.pbytFromStatus = 1
				frmDMDNKM.pStrFromDate = String.Concat(New String() { DateAndTime.Today.Day.ToString("00"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Year.ToString("0000") })
				frmDMDNKM.pStrToDate = String.Concat(New String() { DateAndTime.Today.Day.ToString("00"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Year.ToString("0000") })
				frmDMDNKM.pStrFromTime = "00:00"
				frmDMDNKM.pStrToTime = "23:59"
				frmDMDNKM.gsCheckDate()
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pintResult"
				array(0).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_GET_MAX_OBJID", flag)
				Dim flag2 As Boolean = flag
				If flag2 Then
					Select Case Strings.Len(array(0).Value.ToString())
						Case 1
							frmDMDNKM.txtOBJID.Text = "000000000" + array(0).Value.ToString()
						Case 2
							frmDMDNKM.txtOBJID.Text = "00000000" + array(0).Value.ToString()
						Case 3
							frmDMDNKM.txtOBJID.Text = "0000000" + array(0).Value.ToString()
						Case 4
							frmDMDNKM.txtOBJID.Text = "000000" + array(0).Value.ToString()
						Case 5
							frmDMDNKM.txtOBJID.Text = "00000" + array(0).Value.ToString()
						Case 6
							frmDMDNKM.txtOBJID.Text = "0000" + array(0).Value.ToString()
						Case 7
							frmDMDNKM.txtOBJID.Text = "000" + array(0).Value.ToString()
						Case 8
							frmDMDNKM.txtOBJID.Text = "00" + array(0).Value.ToString()
						Case 9
							frmDMDNKM.txtOBJID.Text = "0" + array(0).Value.ToString()
						Case 10
							frmDMDNKM.txtOBJID.Text = array(0).Value.ToString()
					End Select
					frmDMDNKM.txtOBJID.Focus()
					frmDMDNKM.txtMAKH.Text = mdlVariable.gStrStockCode
				End If
				frmDMDNKM.ShowDialog()
				flag2 = frmDMDNKM.pbytSuccess = 0
				If Not flag2 Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag2 = b = 0
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag2 = b <> 0
					If flag2 Then
						b = Me.fInitGrid()
					End If
					flag2 = b <> 0
					If flag2 Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMDNKM.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnDetail_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
				frmDMDNKM.Dispose()
			End Try
		End Sub

		' Token: 0x06000E48 RID: 3656 RVA: 0x000A7D1C File Offset: 0x000A5F1C
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMDNKM As frmDMDNKM2 = New frmDMDNKM2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMDNKM2 As frmDMDNKM2 = frmDMDNKM
				frmDMDNKM2.pbytFromStatus = 2
				Dim flag As Boolean = Me.dgvData.RowCount > 0
				If flag Then
					frmDMDNKM2.pbytFromStatus = 2
					frmDMDNKM2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMDNKM2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMDNKM2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
					frmDMDNKM2.pStrKHU = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKHU").Value, ""))
					frmDMDNKM2.pStrMANHOMDV = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
					frmDMDNKM2.pStrHTKM = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKM").Value, ""))
					frmDMDNKM2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENNGAY").Value, ""))
					frmDMDNKM2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUNGAY").Value, ""))
					frmDMDNKM2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUGIO").Value, ""))
					frmDMDNKM2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENGIO").Value, ""))
					frmDMDNKM2.txtQty1.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SOLUONG1").Value, ""))
					frmDMDNKM2.txtQty2.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SOLUONG2").Value, ""))
					frmDMDNKM2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
					frmDMDNKM2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
					frmDMDNKM2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
					frmDMDNKM2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
					frmDMDNKM2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
					frmDMDNKM2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
					frmDMDNKM2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
					frmDMDNKM2.chkL02Per.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("L02PER").Value, ""), True, False), True, False))
				End If
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pintResult"
				array(0).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_GET_MAX_OBJID", flag2)
				flag = flag2
				If flag Then
					Select Case Strings.Len(array(0).Value.ToString())
						Case 1
							frmDMDNKM.txtOBJID.Text = "000000000" + array(0).Value.ToString()
						Case 2
							frmDMDNKM.txtOBJID.Text = "00000000" + array(0).Value.ToString()
						Case 3
							frmDMDNKM.txtOBJID.Text = "0000000" + array(0).Value.ToString()
						Case 4
							frmDMDNKM.txtOBJID.Text = "000000" + array(0).Value.ToString()
						Case 5
							frmDMDNKM.txtOBJID.Text = "00000" + array(0).Value.ToString()
						Case 6
							frmDMDNKM.txtOBJID.Text = "0000" + array(0).Value.ToString()
						Case 7
							frmDMDNKM.txtOBJID.Text = "000" + array(0).Value.ToString()
						Case 8
							frmDMDNKM.txtOBJID.Text = "00" + array(0).Value.ToString()
						Case 9
							frmDMDNKM.txtOBJID.Text = "0" + array(0).Value.ToString()
						Case 10
							frmDMDNKM.txtOBJID.Text = array(0).Value.ToString()
					End Select
					frmDMDNKM.txtOBJID.Focus()
					frmDMDNKM.txtMAKH.Text = mdlVariable.gStrStockCode
				End If
				frmDMDNKM.ShowDialog()
				flag = frmDMDNKM.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMDNKM.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnDetail_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMDNKM.Dispose()
			End Try
		End Sub

		' Token: 0x06000E49 RID: 3657 RVA: 0x000A8670 File Offset: 0x000A6870
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMDNKM As frmDMDNKM2 = New frmDMDNKM2()
			Try
				Dim frmDMDNKM2 As frmDMDNKM2 = frmDMDNKM
				frmDMDNKM2.pbytFromStatus = 3
				frmDMDNKM2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMDNKM2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMDNKM2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMDNKM2.pStrKHU = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKHU").Value, ""))
				frmDMDNKM2.pStrMANHOMDV = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
				frmDMDNKM2.pStrHTKM = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKM").Value, ""))
				frmDMDNKM2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMDNKM2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMDNKM2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMDNKM2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMDNKM2.txtQty1.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SOLUONG1").Value, ""))
				frmDMDNKM2.txtQty2.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SOLUONG2").Value, ""))
				frmDMDNKM2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
				frmDMDNKM2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
				frmDMDNKM2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
				frmDMDNKM2.chkL02Per.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("L02PER").Value, ""), True, False), True, False))
				frmDMDNKM.ShowDialog()
				Dim flag As Boolean = frmDMDNKM.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMDNKM.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDNKM.Dispose()
			End Try
		End Sub

		' Token: 0x06000E4A RID: 3658 RVA: 0x000A8D18 File Offset: 0x000A6F18
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMDNKM As frmDMDNKM2 = New frmDMDNKM2()
			Try
				Dim frmDMDNKM2 As frmDMDNKM2 = frmDMDNKM
				frmDMDNKM2.pbytFromStatus = 4
				frmDMDNKM2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMDNKM2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMDNKM2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMDNKM2.pStrKHU = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKHU").Value, ""))
				frmDMDNKM2.pStrMANHOMDV = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value, ""))
				frmDMDNKM2.pStrHTKM = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKM").Value, ""))
				frmDMDNKM2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMDNKM2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMDNKM2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMDNKM2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMDNKM2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY2").Value, True, False), True, False))
				frmDMDNKM2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY3").Value, True, False), True, False))
				frmDMDNKM2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY4").Value, True, False), True, False))
				frmDMDNKM2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY5").Value, True, False), True, False))
				frmDMDNKM2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY6").Value, True, False), True, False))
				frmDMDNKM2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY7").Value, True, False), True, False))
				frmDMDNKM2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY8").Value, True, False), True, False))
				frmDMDNKM2.chkL02Per.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("L02PER").Value, ""), True, False), True, False))
				frmDMDNKM2.txtQty1.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SOLUONG1").Value, ""))
				frmDMDNKM2.txtQty2.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SOLUONG2").Value, ""))
				frmDMDNKM.ShowDialog()
				Dim flag As Boolean = frmDMDNKM.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDNKM.Dispose()
			End Try
		End Sub

		' Token: 0x06000E4B RID: 3659 RVA: 0x000A9358 File Offset: 0x000A7558
		Private Sub txtMAKH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Dim flag As Boolean = Me.mclsTbDMKHO Is Nothing
			If Not flag Then
				array(0) = Me.mclsTbDMKHO.Columns("OBJID")
				Me.mclsTbDMKHO.PrimaryKey = array
				Dim dataRow As DataRow = Me.mclsTbDMKHO.Rows.Find(Strings.Trim(Me.txtMAKH.Text))
				flag = dataRow IsNot Nothing
				If flag Then
					Me.txtOBJNAMEKH.Text = dataRow("OBJNAME").ToString()
				Else
					Me.txtOBJNAMEKH.Text = ""
				End If
				flag = Me.mbdsSource Is Nothing
				If Not flag Then
					flag = Strings.Len(Strings.Trim(Me.txtMAKH.Text)) = 0
					If flag Then
						Me.mbdsSource.RemoveFilter()
					Else
						Me.mbdsSource.Filter = "MAKH like '" + Strings.Trim(Me.txtMAKH.Text) + "'"
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			End If
		End Sub

		' Token: 0x06000E4C RID: 3660 RVA: 0x000A9480 File Offset: 0x000A7680
		Private Sub sGetDMKH()
			Try
				Me.mclsTbDMKHO = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetDMKH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E4D RID: 3661 RVA: 0x000A9528 File Offset: 0x000A7728
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMDNKM As frmDMDNKM2 = New frmDMDNKM2()
			Try
				frmDMDNKM.pbytFromStatus = 6
				frmDMDNKM.ShowDialog()
				Dim flag As Boolean = frmDMDNKM.pbytSuccess = 0
				If flag Then
					frmDMDNKM.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMDNKM.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						frmDMDNKM.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("KHOACHINH", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("KHOACHINH")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDNKM.Dispose()
			End Try
		End Sub

		' Token: 0x06000E4E RID: 3662 RVA: 0x000A971C File Offset: 0x000A791C
		Private Sub btnSelectKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKH As frmDMKH1 = New frmDMKH1()
				frmDMKH.pBytOpen_From_Menu = 7
				frmDMKH.ShowDialog()
				Me.txtMAKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJID, "", False) = 0, Me.txtMAKH.Text, frmDMKH.pStrOBJID))
				Me.txtOBJNAMEKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJNAME, "", False) = 0, Me.txtOBJNAMEKH.Text, frmDMKH.pStrOBJNAME))
				frmDMKH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E4F RID: 3663 RVA: 0x000A9840 File Offset: 0x000A7A40
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMDNKM As frmDMDNKM2 = New frmDMDNKM2()
			Try
				Me.btnFindNext.Visible = False
				frmDMDNKM.pbytFromStatus = 5
				frmDMDNKM.ShowDialog()
				Dim flag As Boolean = frmDMDNKM.pbytSuccess = 0
				If Not flag Then
					Me.mbdsSource.Filter = frmDMDNKM.pStrFilter
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDNKM.Dispose()
			End Try
		End Sub

		' Token: 0x06000E50 RID: 3664 RVA: 0x000A9948 File Offset: 0x000A7B48
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x06000E51 RID: 3665 RVA: 0x000A9A10 File Offset: 0x000A7C10
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("KHOACHINH", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("KHOACHINH")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x06000E52 RID: 3666 RVA: 0x000A9B8C File Offset: 0x000A7D8C
		Private Sub btnDetail_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDNKM As frmDMDNKM3 = New frmDMDNKM3()
				Dim frmDMDNKM2 As frmDMDNKM3 = frmDMDNKM
				frmDMDNKM2.pbdsSource = Me.mbdsSource
				frmDMDNKM2.pdgvMaster = Me.dgvData
				frmDMDNKM.ShowDialog()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDetail_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000E53 RID: 3667 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06000E54 RID: 3668 RVA: 0x000A9C48 File Offset: 0x000A7E48
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = Me.Width - 510 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TUNGAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("TUNGAY").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TUNGAY").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DENNGAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(21))
				dgvData.Columns("DENNGAY").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("DENNGAY").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TUGIO").HeaderText = Strings.Trim(Me.mArrStrFrmMess(22))
				dgvData.Columns("TUGIO").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TUGIO").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DENGIO").HeaderText = Strings.Trim(Me.mArrStrFrmMess(23))
				dgvData.Columns("DENGIO").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("DENGIO").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MAKH").Visible = False
				dgvData.Columns("MAKM").Visible = False
				dgvData.Columns("LDAY2").Visible = False
				dgvData.Columns("LDAY3").Visible = False
				dgvData.Columns("LDAY4").Visible = False
				dgvData.Columns("LDAY5").Visible = False
				dgvData.Columns("LDAY6").Visible = False
				dgvData.Columns("LDAY7").Visible = False
				dgvData.Columns("LDAY8").Visible = False
				dgvData.Columns("SOLUONG1").Visible = False
				dgvData.Columns("SOLUONG2").Visible = False
				dgvData.Columns("MANHOMDV").Visible = False
				dgvData.Columns("KHOACHINH").Visible = False
				dgvData.Columns("MAKHU").Visible = False
				dgvData.Columns("L02PER").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000E55 RID: 3669 RVA: 0x000AA134 File Offset: 0x000A8334
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				Me.btnDetail.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000E56 RID: 3670 RVA: 0x000AA2C4 File Offset: 0x000A84C4
		Public Function gfGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "SP_FRMDMDNKM1_GET_DATA", flag)
				Dim flag2 As Boolean = flag
				If flag2 Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gfGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000E57 RID: 3671 RVA: 0x000AA3BC File Offset: 0x000A85BC
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000E58 RID: 3672 RVA: 0x000AA4E4 File Offset: 0x000A86E4
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000E59 RID: 3673 RVA: 0x000AA5F0 File Offset: 0x000A87F0
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x040005F9 RID: 1529
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040005FB RID: 1531
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x040005FC RID: 1532
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x040005FD RID: 1533
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x040005FE RID: 1534
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x040005FF RID: 1535
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000600 RID: 1536
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000601 RID: 1537
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000602 RID: 1538
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000603 RID: 1539
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000604 RID: 1540
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000605 RID: 1541
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000606 RID: 1542
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000607 RID: 1543
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000608 RID: 1544
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000609 RID: 1545
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x0400060A RID: 1546
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x0400060B RID: 1547
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x0400060C RID: 1548
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x0400060D RID: 1549
		<AccessedThroughProperty("lblMANH")>
		Private _lblMANH As Label

		' Token: 0x0400060E RID: 1550
		<AccessedThroughProperty("txtOBJNAMEKH")>
		Private _txtOBJNAMEKH As TextBox

		' Token: 0x0400060F RID: 1551
		<AccessedThroughProperty("btnSelectKH")>
		Private _btnSelectKH As Button

		' Token: 0x04000610 RID: 1552
		<AccessedThroughProperty("txtMAKH")>
		Private _txtMAKH As TextBox

		' Token: 0x04000611 RID: 1553
		<AccessedThroughProperty("btnDetail")>
		Private _btnDetail As Button

		' Token: 0x04000612 RID: 1554
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000613 RID: 1555
		Private mArrStrFrmMess As String()

		' Token: 0x04000614 RID: 1556
		Private mStrOBJID As String

		' Token: 0x04000615 RID: 1557
		Private mStrOBJNAME As String

		' Token: 0x04000616 RID: 1558
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000617 RID: 1559
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000618 RID: 1560
		Private marrDrFind As DataRow()

		' Token: 0x04000619 RID: 1561
		Private mintFindLastPos As Integer

		' Token: 0x0400061A RID: 1562
		Private mclsTbDMKHO As clsConnect
	End Class
End Namespace
