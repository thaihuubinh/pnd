﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000348 RID: 840
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptThuChi
		Inherits Component
		Implements ICachedReport

		' Token: 0x06007331 RID: 29489 RVA: 0x000148E7 File Offset: 0x00012AE7
		Public Sub New()
			CachedrptThuChi.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17003078 RID: 12408
		' (get) Token: 0x06007332 RID: 29490 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06007333 RID: 29491 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17003079 RID: 12409
		' (get) Token: 0x06007334 RID: 29492 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06007335 RID: 29493 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700307A RID: 12410
		' (get) Token: 0x06007336 RID: 29494 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06007337 RID: 29495 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06007338 RID: 29496 RVA: 0x004DFB44 File Offset: 0x004DDD44
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptThuChi() With { .Site = Me.Site }
		End Function

		' Token: 0x06007339 RID: 29497 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002940 RID: 10560
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
