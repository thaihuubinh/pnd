﻿Namespace prjIS_SalesPOS
	' Token: 0x02000044 RID: 68
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMDV2
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060010E1 RID: 4321 RVA: 0x000CD2C0 File Offset: 0x000CB4C0
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060010E2 RID: 4322 RVA: 0x000CD2F8 File Offset: 0x000CB4F8
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMDV2))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnFinger = New Global.System.Windows.Forms.Button()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.Panel1 = New Global.System.Windows.Forms.Panel()
			Me.picAnh = New Global.System.Windows.Forms.PictureBox()
			Me.btnSaveAndSelect = New Global.System.Windows.Forms.Button()
			Me.lblOBJNAME = New Global.System.Windows.Forms.Label()
			Me.txtOBJNAME = New Global.System.Windows.Forms.TextBox()
			Me.txtOBJID = New Global.System.Windows.Forms.TextBox()
			Me.lblOBJID = New Global.System.Windows.Forms.Label()
			Me.chkISSUP = New Global.System.Windows.Forms.CheckBox()
			Me.lblEMAIL = New Global.System.Windows.Forms.Label()
			Me.lblWEBSITE = New Global.System.Windows.Forms.Label()
			Me.cmbStore = New Global.System.Windows.Forms.ComboBox()
			Me.lblBRANCH = New Global.System.Windows.Forms.Label()
			Me.txtADDRESS = New Global.System.Windows.Forms.TextBox()
			Me.txtTEL = New Global.System.Windows.Forms.TextBox()
			Me.txtMOBILE = New Global.System.Windows.Forms.TextBox()
			Me.txtCONTACT = New Global.System.Windows.Forms.TextBox()
			Me.txtVATCODE = New Global.System.Windows.Forms.TextBox()
			Me.txtFAX = New Global.System.Windows.Forms.TextBox()
			Me.txtEMAIL = New Global.System.Windows.Forms.TextBox()
			Me.txtWEBSITE = New Global.System.Windows.Forms.TextBox()
			Me.chkISCUS = New Global.System.Windows.Forms.CheckBox()
			Me.chkISFOR = New Global.System.Windows.Forms.CheckBox()
			Me.chkISORG = New Global.System.Windows.Forms.CheckBox()
			Me.lblADDRESS = New Global.System.Windows.Forms.Label()
			Me.lblTEL = New Global.System.Windows.Forms.Label()
			Me.lblMOBILE = New Global.System.Windows.Forms.Label()
			Me.lblCONTACT = New Global.System.Windows.Forms.Label()
			Me.lblVATCODE = New Global.System.Windows.Forms.Label()
			Me.lblFAX = New Global.System.Windows.Forms.Label()
			Me.lblISSUP = New Global.System.Windows.Forms.Label()
			Me.lblISCUS = New Global.System.Windows.Forms.Label()
			Me.lblISFOR = New Global.System.Windows.Forms.Label()
			Me.lblISORG = New Global.System.Windows.Forms.Label()
			Me.txtColor = New Global.System.Windows.Forms.TextBox()
			Me.BtnSELECTMANHOMDV = New Global.System.Windows.Forms.Button()
			Me.TxtTENNHOMDV = New Global.System.Windows.Forms.TextBox()
			Me.TxtMANHOMDV = New Global.System.Windows.Forms.TextBox()
			Me.LblMANHOMDV = New Global.System.Windows.Forms.Label()
			Me.LblBIRTHDAY = New Global.System.Windows.Forms.Label()
			Me.mtxBIRTHDAY = New Global.System.Windows.Forms.MaskedTextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.txtTUOI = New Global.System.Windows.Forms.TextBox()
			Me.cmbGIOTINH = New Global.System.Windows.Forms.ComboBox()
			Me.lblNAMGIOI = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.txtJOB = New Global.System.Windows.Forms.TextBox()
			Me.txtRemark = New Global.System.Windows.Forms.TextBox()
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.picZoom = New Global.System.Windows.Forms.PictureBox()
			Me.Label5 = New Global.System.Windows.Forms.Label()
			Me.Label4 = New Global.System.Windows.Forms.Label()
			Me.txtCHUCVU = New Global.System.Windows.Forms.TextBox()
			Me.txtCAP = New Global.System.Windows.Forms.TextBox()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.Label6 = New Global.System.Windows.Forms.Label()
			Me.txtMucGiamGia = New Global.System.Windows.Forms.TextBox()
			Me.btnMucGiamGia = New Global.System.Windows.Forms.Button()
			Me.txtCardCode = New Global.System.Windows.Forms.TextBox()
			Me.Label7 = New Global.System.Windows.Forms.Label()
			Me.mtxNgayThoiViec = New Global.System.Windows.Forms.MaskedTextBox()
			Me.Label8 = New Global.System.Windows.Forms.Label()
			Me.mtxNgayNhanViec = New Global.System.Windows.Forms.MaskedTextBox()
			Me.Label9 = New Global.System.Windows.Forms.Label()
			Me.Label10 = New Global.System.Windows.Forms.Label()
			Me.txtTenUser = New Global.System.Windows.Forms.TextBox()
			Me.txtMaUser = New Global.System.Windows.Forms.TextBox()
			Me.btnMaUser = New Global.System.Windows.Forms.Button()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.Panel1.SuspendLayout()
			CType(Me.picAnh, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.picZoom, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(530, 0)
			grpButton.Location = point
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(0)
			grpButton2.Margin = padding
			Me.grpButton.Name = "grpButton"
			Dim grpButton3 As Global.System.Windows.Forms.Control = Me.grpButton
			padding = New Global.System.Windows.Forms.Padding(1)
			grpButton3.Padding = padding
			Dim grpButton4 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 526)
			grpButton4.Size = size
			Me.grpButton.TabIndex = 20
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnFinger, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 7)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 2)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 6)
			Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSaveAndSelect, 0, 3)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(1, 16)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 8
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 23F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(117, 509)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnFinger.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFinger.Image = Global.prjIS_SalesPOS.My.Resources.Resources.loginicon
			Dim btnFinger As Global.System.Windows.Forms.Control = Me.btnFinger
			point = New Global.System.Drawing.Point(3, 120)
			btnFinger.Location = point
			Me.btnFinger.Name = "btnFinger"
			Dim btnFinger2 As Global.System.Windows.Forms.Control = Me.btnFinger
			size = New Global.System.Drawing.Size(111, 49)
			btnFinger2.Size = size
			Me.btnFinger.TabIndex = 100
			Me.btnFinger.Tag = "CR0065"
			Me.btnFinger.Text = "Vân tay"
			Me.btnFinger.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFinger.UseVisualStyleBackColor = True
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 340)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(111, 49)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 6
			Me.btnFilter.Tag = "CR0005"
			Me.btnFilter.Text = "Lọ&c"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 450)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(111, 56)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 175)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(111, 49)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 4
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 285)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(111, 49)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 5
			Me.btnDelete.Tag = "CR0004"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 395)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(111, 49)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 7
			Me.btnFind.Tag = "CR0006"
			Me.btnFind.Text = "&Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.Panel1.Controls.Add(Me.picAnh)
			Me.Panel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim panel As Global.System.Windows.Forms.Control = Me.Panel1
			point = New Global.System.Drawing.Point(3, 3)
			panel.Location = point
			Me.Panel1.Name = "Panel1"
			Dim panel2 As Global.System.Windows.Forms.Control = Me.Panel1
			size = New Global.System.Drawing.Size(111, 111)
			panel2.Size = size
			Me.Panel1.TabIndex = 9
			Me.picAnh.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.picAnh.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.picAnh.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim picAnh As Global.System.Windows.Forms.Control = Me.picAnh
			point = New Global.System.Drawing.Point(0, 0)
			picAnh.Location = point
			Me.picAnh.Name = "picAnh"
			Dim picAnh2 As Global.System.Windows.Forms.Control = Me.picAnh
			size = New Global.System.Drawing.Size(111, 111)
			picAnh2.Size = size
			Me.picAnh.TabIndex = 0
			Me.picAnh.TabStop = False
			Me.btnSaveAndSelect.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSaveAndSelect.Image = Global.prjIS_SalesPOS.My.Resources.Resources.saveandselect
			Dim btnSaveAndSelect As Global.System.Windows.Forms.Control = Me.btnSaveAndSelect
			point = New Global.System.Drawing.Point(3, 230)
			btnSaveAndSelect.Location = point
			Me.btnSaveAndSelect.Name = "btnSaveAndSelect"
			Dim btnSaveAndSelect2 As Global.System.Windows.Forms.Control = Me.btnSaveAndSelect
			size = New Global.System.Drawing.Size(111, 49)
			btnSaveAndSelect2.Size = size
			Me.btnSaveAndSelect.TabIndex = 4
			Me.btnSaveAndSelect.Tag = "CR0060"
			Me.btnSaveAndSelect.Text = "Lưu và chọn"
			Me.btnSaveAndSelect.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSaveAndSelect.UseVisualStyleBackColor = True
			Me.lblOBJNAME.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJNAME As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			point = New Global.System.Drawing.Point(3, 31)
			lblOBJNAME.Location = point
			Me.lblOBJNAME.Name = "lblOBJNAME"
			Dim lblOBJNAME2 As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			size = New Global.System.Drawing.Size(124, 21)
			lblOBJNAME2.Size = size
			Me.lblOBJNAME.TabIndex = 34
			Me.lblOBJNAME.Tag = "CR0008"
			Me.lblOBJNAME.Text = "Tên đơn vị"
			Me.txtOBJNAME.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJNAME As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			point = New Global.System.Drawing.Point(130, 31)
			txtOBJNAME.Location = point
			Me.txtOBJNAME.Name = "txtOBJNAME"
			Dim txtOBJNAME2 As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			size = New Global.System.Drawing.Size(397, 22)
			txtOBJNAME2.Size = size
			Me.txtOBJNAME.TabIndex = 1
			Me.txtOBJNAME.Tag = "0R0000"
			Me.txtOBJID.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJID As Global.System.Windows.Forms.Control = Me.txtOBJID
			point = New Global.System.Drawing.Point(130, 6)
			txtOBJID.Location = point
			Me.txtOBJID.Name = "txtOBJID"
			Dim txtOBJID2 As Global.System.Windows.Forms.Control = Me.txtOBJID
			size = New Global.System.Drawing.Size(156, 22)
			txtOBJID2.Size = size
			Me.txtOBJID.TabIndex = 0
			Me.txtOBJID.Tag = "0R0000"
			Me.lblOBJID.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJID As Global.System.Windows.Forms.Control = Me.lblOBJID
			point = New Global.System.Drawing.Point(3, 7)
			lblOBJID.Location = point
			Me.lblOBJID.Name = "lblOBJID"
			Dim lblOBJID2 As Global.System.Windows.Forms.Control = Me.lblOBJID
			size = New Global.System.Drawing.Size(124, 21)
			lblOBJID2.Size = size
			Me.lblOBJID.TabIndex = 33
			Me.lblOBJID.Tag = "CR0007"
			Me.lblOBJID.Text = "Mã đơn vị"
			Me.chkISSUP.AutoSize = True
			Me.chkISSUP.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkISSUP As Global.System.Windows.Forms.Control = Me.chkISSUP
			point = New Global.System.Drawing.Point(43, 483)
			chkISSUP.Location = point
			Me.chkISSUP.Name = "chkISSUP"
			Dim chkISSUP2 As Global.System.Windows.Forms.Control = Me.chkISSUP
			size = New Global.System.Drawing.Size(15, 14)
			chkISSUP2.Size = size
			Me.chkISSUP.TabIndex = 16
			Me.chkISSUP.Tag = "0R0000"
			Me.chkISSUP.UseVisualStyleBackColor = True
			Me.lblEMAIL.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblEMAIL As Global.System.Windows.Forms.Control = Me.lblEMAIL
			point = New Global.System.Drawing.Point(3, 308)
			lblEMAIL.Location = point
			Me.lblEMAIL.Name = "lblEMAIL"
			Dim lblEMAIL2 As Global.System.Windows.Forms.Control = Me.lblEMAIL
			size = New Global.System.Drawing.Size(124, 21)
			lblEMAIL2.Size = size
			Me.lblEMAIL.TabIndex = 39
			Me.lblEMAIL.Tag = "CR0038"
			Me.lblEMAIL.Text = "Email"
			Me.lblWEBSITE.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblWEBSITE As Global.System.Windows.Forms.Control = Me.lblWEBSITE
			point = New Global.System.Drawing.Point(3, 336)
			lblWEBSITE.Location = point
			Me.lblWEBSITE.Name = "lblWEBSITE"
			Dim lblWEBSITE2 As Global.System.Windows.Forms.Control = Me.lblWEBSITE
			size = New Global.System.Drawing.Size(124, 21)
			lblWEBSITE2.Size = size
			Me.lblWEBSITE.TabIndex = 40
			Me.lblWEBSITE.Tag = "CR0039"
			Me.lblWEBSITE.Text = "Website"
			Me.cmbStore.FormattingEnabled = True
			Dim cmbStore As Global.System.Windows.Forms.Control = Me.cmbStore
			point = New Global.System.Drawing.Point(130, 80)
			cmbStore.Location = point
			Me.cmbStore.Name = "cmbStore"
			Dim cmbStore2 As Global.System.Windows.Forms.Control = Me.cmbStore
			size = New Global.System.Drawing.Size(156, 24)
			cmbStore2.Size = size
			Me.cmbStore.TabIndex = 3
			Me.cmbStore.Tag = "0R0000"
			Me.lblBRANCH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblBRANCH As Global.System.Windows.Forms.Control = Me.lblBRANCH
			point = New Global.System.Drawing.Point(3, 82)
			lblBRANCH.Location = point
			Me.lblBRANCH.Name = "lblBRANCH"
			Dim lblBRANCH2 As Global.System.Windows.Forms.Control = Me.lblBRANCH
			size = New Global.System.Drawing.Size(124, 21)
			lblBRANCH2.Size = size
			Me.lblBRANCH.TabIndex = 42
			Me.lblBRANCH.Tag = "CR0031"
			Me.lblBRANCH.Text = "Kho trực thuộc"
			Me.txtADDRESS.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtADDRESS As Global.System.Windows.Forms.Control = Me.txtADDRESS
			point = New Global.System.Drawing.Point(130, 159)
			txtADDRESS.Location = point
			Me.txtADDRESS.Name = "txtADDRESS"
			Dim txtADDRESS2 As Global.System.Windows.Forms.Control = Me.txtADDRESS
			size = New Global.System.Drawing.Size(397, 22)
			txtADDRESS2.Size = size
			Me.txtADDRESS.TabIndex = 6
			Me.txtADDRESS.Tag = "0R0000"
			Me.txtTEL.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtTEL As Global.System.Windows.Forms.Control = Me.txtTEL
			point = New Global.System.Drawing.Point(130, 209)
			txtTEL.Location = point
			Me.txtTEL.Name = "txtTEL"
			Dim txtTEL2 As Global.System.Windows.Forms.Control = Me.txtTEL
			size = New Global.System.Drawing.Size(116, 22)
			txtTEL2.Size = size
			Me.txtTEL.TabIndex = 7
			Me.txtTEL.Tag = "0R0000"
			Me.txtMOBILE.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMOBILE As Global.System.Windows.Forms.Control = Me.txtMOBILE
			point = New Global.System.Drawing.Point(369, 209)
			txtMOBILE.Location = point
			Me.txtMOBILE.Name = "txtMOBILE"
			Dim txtMOBILE2 As Global.System.Windows.Forms.Control = Me.txtMOBILE
			size = New Global.System.Drawing.Size(159, 22)
			txtMOBILE2.Size = size
			Me.txtMOBILE.TabIndex = 8
			Me.txtMOBILE.Tag = "0R0000"
			Me.txtCONTACT.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtCONTACT As Global.System.Windows.Forms.Control = Me.txtCONTACT
			point = New Global.System.Drawing.Point(130, 259)
			txtCONTACT.Location = point
			Me.txtCONTACT.Name = "txtCONTACT"
			Dim txtCONTACT2 As Global.System.Windows.Forms.Control = Me.txtCONTACT
			size = New Global.System.Drawing.Size(397, 22)
			txtCONTACT2.Size = size
			Me.txtCONTACT.TabIndex = 10
			Me.txtCONTACT.Tag = "0R0000"
			Me.txtVATCODE.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtVATCODE As Global.System.Windows.Forms.Control = Me.txtVATCODE
			point = New Global.System.Drawing.Point(130, 284)
			txtVATCODE.Location = point
			Me.txtVATCODE.Name = "txtVATCODE"
			Dim txtVATCODE2 As Global.System.Windows.Forms.Control = Me.txtVATCODE
			size = New Global.System.Drawing.Size(116, 22)
			txtVATCODE2.Size = size
			Me.txtVATCODE.TabIndex = 11
			Me.txtVATCODE.Tag = "0R0000"
			Me.txtFAX.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtFAX As Global.System.Windows.Forms.Control = Me.txtFAX
			point = New Global.System.Drawing.Point(369, 284)
			txtFAX.Location = point
			Me.txtFAX.Name = "txtFAX"
			Dim txtFAX2 As Global.System.Windows.Forms.Control = Me.txtFAX
			size = New Global.System.Drawing.Size(158, 22)
			txtFAX2.Size = size
			Me.txtFAX.TabIndex = 12
			Me.txtFAX.Tag = "0R0000"
			Me.txtEMAIL.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtEMAIL As Global.System.Windows.Forms.Control = Me.txtEMAIL
			point = New Global.System.Drawing.Point(130, 309)
			txtEMAIL.Location = point
			Me.txtEMAIL.Name = "txtEMAIL"
			Dim txtEMAIL2 As Global.System.Windows.Forms.Control = Me.txtEMAIL
			size = New Global.System.Drawing.Size(397, 22)
			txtEMAIL2.Size = size
			Me.txtEMAIL.TabIndex = 13
			Me.txtEMAIL.Tag = "0R0000"
			Me.txtWEBSITE.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtWEBSITE As Global.System.Windows.Forms.Control = Me.txtWEBSITE
			point = New Global.System.Drawing.Point(130, 334)
			txtWEBSITE.Location = point
			Me.txtWEBSITE.Name = "txtWEBSITE"
			Dim txtWEBSITE2 As Global.System.Windows.Forms.Control = Me.txtWEBSITE
			size = New Global.System.Drawing.Size(397, 22)
			txtWEBSITE2.Size = size
			Me.txtWEBSITE.TabIndex = 14
			Me.txtWEBSITE.Tag = "0R0000"
			Me.chkISCUS.AutoSize = True
			Me.chkISCUS.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkISCUS As Global.System.Windows.Forms.Control = Me.chkISCUS
			point = New Global.System.Drawing.Point(43, 507)
			chkISCUS.Location = point
			Me.chkISCUS.Name = "chkISCUS"
			Dim chkISCUS2 As Global.System.Windows.Forms.Control = Me.chkISCUS
			size = New Global.System.Drawing.Size(15, 14)
			chkISCUS2.Size = size
			Me.chkISCUS.TabIndex = 17
			Me.chkISCUS.Tag = "0R0000"
			Me.chkISCUS.UseVisualStyleBackColor = True
			Me.chkISFOR.AutoSize = True
			Me.chkISFOR.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkISFOR As Global.System.Windows.Forms.Control = Me.chkISFOR
			point = New Global.System.Drawing.Point(241, 483)
			chkISFOR.Location = point
			Me.chkISFOR.Name = "chkISFOR"
			Dim chkISFOR2 As Global.System.Windows.Forms.Control = Me.chkISFOR
			size = New Global.System.Drawing.Size(15, 14)
			chkISFOR2.Size = size
			Me.chkISFOR.TabIndex = 20
			Me.chkISFOR.Tag = "0R0000"
			Me.chkISFOR.UseVisualStyleBackColor = True
			Me.chkISORG.AutoSize = True
			Me.chkISORG.CheckAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Dim chkISORG As Global.System.Windows.Forms.Control = Me.chkISORG
			point = New Global.System.Drawing.Point(241, 507)
			chkISORG.Location = point
			Me.chkISORG.Name = "chkISORG"
			Dim chkISORG2 As Global.System.Windows.Forms.Control = Me.chkISORG
			size = New Global.System.Drawing.Size(15, 14)
			chkISORG2.Size = size
			Me.chkISORG.TabIndex = 21
			Me.chkISORG.Tag = "0R0000"
			Me.chkISORG.UseVisualStyleBackColor = True
			Me.lblADDRESS.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblADDRESS As Global.System.Windows.Forms.Control = Me.lblADDRESS
			point = New Global.System.Drawing.Point(3, 160)
			lblADDRESS.Location = point
			Me.lblADDRESS.Name = "lblADDRESS"
			Dim lblADDRESS2 As Global.System.Windows.Forms.Control = Me.lblADDRESS
			size = New Global.System.Drawing.Size(124, 21)
			lblADDRESS2.Size = size
			Me.lblADDRESS.TabIndex = 54
			Me.lblADDRESS.Tag = "CR0032"
			Me.lblADDRESS.Text = "Địa chỉ"
			Me.lblTEL.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblTEL As Global.System.Windows.Forms.Control = Me.lblTEL
			point = New Global.System.Drawing.Point(3, 211)
			lblTEL.Location = point
			Me.lblTEL.Name = "lblTEL"
			Dim lblTEL2 As Global.System.Windows.Forms.Control = Me.lblTEL
			size = New Global.System.Drawing.Size(124, 21)
			lblTEL2.Size = size
			Me.lblTEL.TabIndex = 55
			Me.lblTEL.Tag = "CR0033"
			Me.lblTEL.Text = "Điện thoại bàn"
			Me.lblMOBILE.AutoSize = True
			Me.lblMOBILE.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMOBILE As Global.System.Windows.Forms.Control = Me.lblMOBILE
			point = New Global.System.Drawing.Point(250, 211)
			lblMOBILE.Location = point
			Me.lblMOBILE.Name = "lblMOBILE"
			Dim lblMOBILE2 As Global.System.Windows.Forms.Control = Me.lblMOBILE
			size = New Global.System.Drawing.Size(112, 16)
			lblMOBILE2.Size = size
			Me.lblMOBILE.TabIndex = 56
			Me.lblMOBILE.Tag = "CR0034"
			Me.lblMOBILE.Text = "Điện thoại di động"
			Me.lblCONTACT.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblCONTACT As Global.System.Windows.Forms.Control = Me.lblCONTACT
			point = New Global.System.Drawing.Point(3, 261)
			lblCONTACT.Location = point
			Me.lblCONTACT.Name = "lblCONTACT"
			Dim lblCONTACT2 As Global.System.Windows.Forms.Control = Me.lblCONTACT
			size = New Global.System.Drawing.Size(124, 21)
			lblCONTACT2.Size = size
			Me.lblCONTACT.TabIndex = 57
			Me.lblCONTACT.Tag = "CR0035"
			Me.lblCONTACT.Text = "Tên người liên hệ"
			Me.lblVATCODE.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblVATCODE As Global.System.Windows.Forms.Control = Me.lblVATCODE
			point = New Global.System.Drawing.Point(3, 286)
			lblVATCODE.Location = point
			Me.lblVATCODE.Name = "lblVATCODE"
			Dim lblVATCODE2 As Global.System.Windows.Forms.Control = Me.lblVATCODE
			size = New Global.System.Drawing.Size(124, 21)
			lblVATCODE2.Size = size
			Me.lblVATCODE.TabIndex = 58
			Me.lblVATCODE.Tag = "CR0036"
			Me.lblVATCODE.Text = "Mã số thuế/CMND"
			Me.lblFAX.AutoSize = True
			Me.lblFAX.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFAX As Global.System.Windows.Forms.Control = Me.lblFAX
			point = New Global.System.Drawing.Point(295, 286)
			lblFAX.Location = point
			Me.lblFAX.Name = "lblFAX"
			Dim lblFAX2 As Global.System.Windows.Forms.Control = Me.lblFAX
			size = New Global.System.Drawing.Size(30, 16)
			lblFAX2.Size = size
			Me.lblFAX.TabIndex = 59
			Me.lblFAX.Tag = "CR0037"
			Me.lblFAX.Text = "Fax"
			Me.lblISSUP.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblISSUP As Global.System.Windows.Forms.Control = Me.lblISSUP
			point = New Global.System.Drawing.Point(85, 481)
			lblISSUP.Location = point
			Me.lblISSUP.Name = "lblISSUP"
			Dim lblISSUP2 As Global.System.Windows.Forms.Control = Me.lblISSUP
			size = New Global.System.Drawing.Size(156, 21)
			lblISSUP2.Size = size
			Me.lblISSUP.TabIndex = 16
			Me.lblISSUP.Tag = "CR0040"
			Me.lblISSUP.Text = "Đơn vị là nhà cung cấp"
			Me.lblISCUS.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblISCUS As Global.System.Windows.Forms.Control = Me.lblISCUS
			point = New Global.System.Drawing.Point(85, 503)
			lblISCUS.Location = point
			Me.lblISCUS.Name = "lblISCUS"
			Dim lblISCUS2 As Global.System.Windows.Forms.Control = Me.lblISCUS
			size = New Global.System.Drawing.Size(154, 21)
			lblISCUS2.Size = size
			Me.lblISCUS.TabIndex = 18
			Me.lblISCUS.Tag = "CR0041"
			Me.lblISCUS.Text = "Đơn vị là khách hàng"
			Me.lblISFOR.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblISFOR As Global.System.Windows.Forms.Control = Me.lblISFOR
			point = New Global.System.Drawing.Point(283, 483)
			lblISFOR.Location = point
			Me.lblISFOR.Name = "lblISFOR"
			Dim lblISFOR2 As Global.System.Windows.Forms.Control = Me.lblISFOR
			size = New Global.System.Drawing.Size(211, 21)
			lblISFOR2.Size = size
			Me.lblISFOR.TabIndex = 17
			Me.lblISFOR.Tag = "CR0042"
			Me.lblISFOR.Text = "Đơn vị là đối tác nước ngoài"
			Me.lblISORG.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblISORG As Global.System.Windows.Forms.Control = Me.lblISORG
			point = New Global.System.Drawing.Point(283, 503)
			lblISORG.Location = point
			Me.lblISORG.Name = "lblISORG"
			Dim lblISORG2 As Global.System.Windows.Forms.Control = Me.lblISORG
			size = New Global.System.Drawing.Size(214, 21)
			lblISORG2.Size = size
			Me.lblISORG.TabIndex = 19
			Me.lblISORG.Tag = "CR0043"
			Me.lblISORG.Text = "Đơn vị là một bộ phận của công ty"
			Me.txtColor.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Dim txtColor As Global.System.Windows.Forms.Control = Me.txtColor
			point = New Global.System.Drawing.Point(455, 110)
			txtColor.Location = point
			Me.txtColor.Name = "txtColor"
			Dim txtColor2 As Global.System.Windows.Forms.Control = Me.txtColor
			size = New Global.System.Drawing.Size(69, 22)
			txtColor2.Size = size
			Me.txtColor.TabIndex = 64
			Me.txtColor.Tag = "0R0000"
			Me.txtColor.Visible = False
			Me.BtnSELECTMANHOMDV.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnSELECTMANHOMDV As Global.System.Windows.Forms.Control = Me.BtnSELECTMANHOMDV
			point = New Global.System.Drawing.Point(288, 53)
			btnSELECTMANHOMDV.Location = point
			Me.BtnSELECTMANHOMDV.Name = "BtnSELECTMANHOMDV"
			Dim btnSELECTMANHOMDV2 As Global.System.Windows.Forms.Control = Me.BtnSELECTMANHOMDV
			size = New Global.System.Drawing.Size(44, 28)
			btnSELECTMANHOMDV2.Size = size
			Me.BtnSELECTMANHOMDV.TabIndex = 66
			Me.BtnSELECTMANHOMDV.Tag = ""
			Me.BtnSELECTMANHOMDV.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.BtnSELECTMANHOMDV.UseVisualStyleBackColor = True
			Me.TxtTENNHOMDV.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtTENNHOMDV As Global.System.Windows.Forms.Control = Me.TxtTENNHOMDV
			point = New Global.System.Drawing.Point(336, 56)
			txtTENNHOMDV.Location = point
			Me.TxtTENNHOMDV.Name = "TxtTENNHOMDV"
			Me.TxtTENNHOMDV.[ReadOnly] = True
			Dim txtTENNHOMDV2 As Global.System.Windows.Forms.Control = Me.TxtTENNHOMDV
			size = New Global.System.Drawing.Size(191, 22)
			txtTENNHOMDV2.Size = size
			Me.TxtTENNHOMDV.TabIndex = 67
			Me.TxtTENNHOMDV.Tag = "0R0000"
			Me.TxtMANHOMDV.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMANHOMDV As Global.System.Windows.Forms.Control = Me.TxtMANHOMDV
			point = New Global.System.Drawing.Point(130, 56)
			txtMANHOMDV.Location = point
			Me.TxtMANHOMDV.Name = "TxtMANHOMDV"
			Dim txtMANHOMDV2 As Global.System.Windows.Forms.Control = Me.TxtMANHOMDV
			size = New Global.System.Drawing.Size(156, 22)
			txtMANHOMDV2.Size = size
			Me.TxtMANHOMDV.TabIndex = 2
			Me.TxtMANHOMDV.Tag = "0R0000"
			Me.LblMANHOMDV.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMANHOMDV As Global.System.Windows.Forms.Control = Me.LblMANHOMDV
			point = New Global.System.Drawing.Point(3, 56)
			lblMANHOMDV.Location = point
			Me.LblMANHOMDV.Name = "LblMANHOMDV"
			Dim lblMANHOMDV2 As Global.System.Windows.Forms.Control = Me.LblMANHOMDV
			size = New Global.System.Drawing.Size(124, 21)
			lblMANHOMDV2.Size = size
			Me.LblMANHOMDV.TabIndex = 69
			Me.LblMANHOMDV.Tag = "CR0009"
			Me.LblMANHOMDV.Text = "Mã nhóm đơn vị"
			Me.LblBIRTHDAY.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblBIRTHDAY As Global.System.Windows.Forms.Control = Me.LblBIRTHDAY
			point = New Global.System.Drawing.Point(3, 110)
			lblBIRTHDAY.Location = point
			Me.LblBIRTHDAY.Name = "LblBIRTHDAY"
			Dim lblBIRTHDAY2 As Global.System.Windows.Forms.Control = Me.LblBIRTHDAY
			size = New Global.System.Drawing.Size(124, 21)
			lblBIRTHDAY2.Size = size
			Me.LblBIRTHDAY.TabIndex = 70
			Me.LblBIRTHDAY.Tag = "CR0008"
			Me.LblBIRTHDAY.Text = "Ngày sinh"
			Dim mtxBIRTHDAY As Global.System.Windows.Forms.Control = Me.mtxBIRTHDAY
			point = New Global.System.Drawing.Point(130, 107)
			mtxBIRTHDAY.Location = point
			Me.mtxBIRTHDAY.Mask = "00/00/0000"
			Me.mtxBIRTHDAY.Name = "mtxBIRTHDAY"
			Me.mtxBIRTHDAY.PromptChar = " "c
			Dim mtxBIRTHDAY2 As Global.System.Windows.Forms.Control = Me.mtxBIRTHDAY
			size = New Global.System.Drawing.Size(156, 22)
			mtxBIRTHDAY2.Size = size
			Me.mtxBIRTHDAY.TabIndex = 4
			Me.mtxBIRTHDAY.Tag = "CR0000"
			Me.mtxBIRTHDAY.ValidatingType = GetType(Global.System.DateTime)
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(292, 110)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(41, 21)
			label2.Size = size
			Me.Label1.TabIndex = 72
			Me.Label1.Tag = "CR0051"
			Me.Label1.Text = "Tuoi"
			Me.txtTUOI.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Dim txtTUOI As Global.System.Windows.Forms.Control = Me.txtTUOI
			point = New Global.System.Drawing.Point(336, 107)
			txtTUOI.Location = point
			Me.txtTUOI.Name = "txtTUOI"
			Me.txtTUOI.[ReadOnly] = True
			Dim txtTUOI2 As Global.System.Windows.Forms.Control = Me.txtTUOI
			size = New Global.System.Drawing.Size(50, 22)
			txtTUOI2.Size = size
			Me.txtTUOI.TabIndex = 5
			Me.txtTUOI.Tag = "0R0000"
			Me.txtTUOI.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.cmbGIOTINH.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbGIOTINH.FormattingEnabled = True
			Dim cmbGIOTINH As Global.System.Windows.Forms.Control = Me.cmbGIOTINH
			point = New Global.System.Drawing.Point(130, 132)
			cmbGIOTINH.Location = point
			Me.cmbGIOTINH.Name = "cmbGIOTINH"
			Dim cmbGIOTINH2 As Global.System.Windows.Forms.Control = Me.cmbGIOTINH
			size = New Global.System.Drawing.Size(156, 24)
			cmbGIOTINH2.Size = size
			Me.cmbGIOTINH.TabIndex = 5
			Me.lblNAMGIOI.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblNAMGIOI As Global.System.Windows.Forms.Control = Me.lblNAMGIOI
			point = New Global.System.Drawing.Point(3, 135)
			lblNAMGIOI.Location = point
			Me.lblNAMGIOI.Name = "lblNAMGIOI"
			Dim lblNAMGIOI2 As Global.System.Windows.Forms.Control = Me.lblNAMGIOI
			size = New Global.System.Drawing.Size(100, 21)
			lblNAMGIOI2.Size = size
			Me.lblNAMGIOI.TabIndex = 88
			Me.lblNAMGIOI.Tag = "CR0052"
			Me.lblNAMGIOI.Text = "Giới tính"
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(3, 234)
			label3.Location = point
			Me.Label2.Name = "Label2"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(124, 21)
			label4.Size = size
			Me.Label2.TabIndex = 90
			Me.Label2.Tag = "CR0053"
			Me.Label2.Text = "nghe nghiep"
			Me.txtJOB.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtJOB As Global.System.Windows.Forms.Control = Me.txtJOB
			point = New Global.System.Drawing.Point(130, 234)
			txtJOB.Location = point
			Me.txtJOB.Name = "txtJOB"
			Dim txtJOB2 As Global.System.Windows.Forms.Control = Me.txtJOB
			size = New Global.System.Drawing.Size(397, 22)
			txtJOB2.Size = size
			Me.txtJOB.TabIndex = 9
			Me.txtJOB.Tag = "0R0000"
			Me.txtRemark.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtRemark As Global.System.Windows.Forms.Control = Me.txtRemark
			point = New Global.System.Drawing.Point(130, 357)
			txtRemark.Location = point
			Me.txtRemark.Multiline = True
			Me.txtRemark.Name = "txtRemark"
			Dim txtRemark2 As Global.System.Windows.Forms.Control = Me.txtRemark
			size = New Global.System.Drawing.Size(397, 21)
			txtRemark2.Size = size
			Me.txtRemark.TabIndex = 15
			Me.txtRemark.Tag = "0R0000"
			Me.Label3.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(3, 359)
			label5.Location = point
			Me.Label3.Name = "Label3"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(124, 21)
			label6.Size = size
			Me.Label3.TabIndex = 92
			Me.Label3.Tag = "CR0056"
			Me.Label3.Text = "ghi chu"
			Me.picZoom.BackColor = Global.System.Drawing.Color.White
			Me.picZoom.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.picZoom.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Dim picZoom As Global.System.Windows.Forms.Control = Me.picZoom
			point = New Global.System.Drawing.Point(345, 5)
			picZoom.Location = point
			Me.picZoom.Name = "picZoom"
			Dim picZoom2 As Global.System.Windows.Forms.Control = Me.picZoom
			size = New Global.System.Drawing.Size(183, 273)
			picZoom2.Size = size
			Me.picZoom.TabIndex = 93
			Me.picZoom.TabStop = False
			Me.picZoom.Visible = False
			Me.Label5.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label7 As Global.System.Windows.Forms.Control = Me.Label5
			point = New Global.System.Drawing.Point(248, 185)
			label7.Location = point
			Me.Label5.Name = "Label5"
			Dim label8 As Global.System.Windows.Forms.Control = Me.Label5
			size = New Global.System.Drawing.Size(74, 21)
			label8.Size = size
			Me.Label5.TabIndex = 96
			Me.Label5.Tag = "CR0059"
			Me.Label5.Text = "CHUC VU"
			Me.Label4.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label9 As Global.System.Windows.Forms.Control = Me.Label4
			point = New Global.System.Drawing.Point(3, 185)
			label9.Location = point
			Me.Label4.Name = "Label4"
			Dim label10 As Global.System.Windows.Forms.Control = Me.Label4
			size = New Global.System.Drawing.Size(124, 21)
			label10.Size = size
			Me.Label4.TabIndex = 97
			Me.Label4.Tag = "CR0058"
			Me.Label4.Text = "CAP"
			Me.txtCHUCVU.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtCHUCVU As Global.System.Windows.Forms.Control = Me.txtCHUCVU
			point = New Global.System.Drawing.Point(369, 184)
			txtCHUCVU.Location = point
			Me.txtCHUCVU.Name = "txtCHUCVU"
			Dim txtCHUCVU2 As Global.System.Windows.Forms.Control = Me.txtCHUCVU
			size = New Global.System.Drawing.Size(158, 22)
			txtCHUCVU2.Size = size
			Me.txtCHUCVU.TabIndex = 94
			Me.txtCHUCVU.Tag = "0R0000"
			Me.txtCAP.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtCAP As Global.System.Windows.Forms.Control = Me.txtCAP
			point = New Global.System.Drawing.Point(130, 184)
			txtCAP.Location = point
			Me.txtCAP.Name = "txtCAP"
			Dim txtCAP2 As Global.System.Windows.Forms.Control = Me.txtCAP
			size = New Global.System.Drawing.Size(116, 22)
			txtCAP2.Size = size
			Me.txtCAP.TabIndex = 95
			Me.txtCAP.Tag = "0R0000"
			Me.btnKeyboard.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(288, 1)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(42, 30)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 98
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Me.Label6.AutoSize = True
			Me.Label6.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label11 As Global.System.Windows.Forms.Control = Me.Label6
			point = New Global.System.Drawing.Point(3, 382)
			label11.Location = point
			Me.Label6.Name = "Label6"
			Dim label12 As Global.System.Windows.Forms.Control = Me.Label6
			size = New Global.System.Drawing.Size(125, 14)
			label12.Size = size
			Me.Label6.TabIndex = 92
			Me.Label6.Tag = "CR0063"
			Me.Label6.Text = "Mức giảm giá trong ngày"
			Me.txtMucGiamGia.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMucGiamGia As Global.System.Windows.Forms.Control = Me.txtMucGiamGia
			point = New Global.System.Drawing.Point(130, 380)
			txtMucGiamGia.Location = point
			Me.txtMucGiamGia.Multiline = True
			Me.txtMucGiamGia.Name = "txtMucGiamGia"
			Dim txtMucGiamGia2 As Global.System.Windows.Forms.Control = Me.txtMucGiamGia
			size = New Global.System.Drawing.Size(116, 21)
			txtMucGiamGia2.Size = size
			Me.txtMucGiamGia.TabIndex = 15
			Me.txtMucGiamGia.Tag = "0R0000"
			Me.txtMucGiamGia.Text = "0"
			Me.txtMucGiamGia.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Dim btnMucGiamGia As Global.System.Windows.Forms.Control = Me.btnMucGiamGia
			point = New Global.System.Drawing.Point(247, 378)
			btnMucGiamGia.Location = point
			Me.btnMucGiamGia.Name = "btnMucGiamGia"
			Dim btnMucGiamGia2 As Global.System.Windows.Forms.Control = Me.btnMucGiamGia
			size = New Global.System.Drawing.Size(38, 25)
			btnMucGiamGia2.Size = size
			Me.btnMucGiamGia.TabIndex = 99
			Me.btnMucGiamGia.Text = "..."
			Me.btnMucGiamGia.UseVisualStyleBackColor = True
			Me.txtCardCode.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtCardCode As Global.System.Windows.Forms.Control = Me.txtCardCode
			point = New Global.System.Drawing.Point(385, 6)
			txtCardCode.Location = point
			Me.txtCardCode.Name = "txtCardCode"
			Dim txtCardCode2 As Global.System.Windows.Forms.Control = Me.txtCardCode
			size = New Global.System.Drawing.Size(143, 22)
			txtCardCode2.Size = size
			Me.txtCardCode.TabIndex = 0
			Me.txtCardCode.Tag = "0R0000"
			Me.Label7.AutoSize = True
			Me.Label7.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label13 As Global.System.Windows.Forms.Control = Me.Label7
			point = New Global.System.Drawing.Point(332, 8)
			label13.Location = point
			Me.Label7.Name = "Label7"
			Dim label14 As Global.System.Windows.Forms.Control = Me.Label7
			size = New Global.System.Drawing.Size(48, 16)
			label14.Size = size
			Me.Label7.TabIndex = 33
			Me.Label7.Tag = "CR0066"
			Me.Label7.Text = "Mã thẻ"
			Dim mtxNgayThoiViec As Global.System.Windows.Forms.Control = Me.mtxNgayThoiViec
			point = New Global.System.Drawing.Point(130, 429)
			mtxNgayThoiViec.Location = point
			Me.mtxNgayThoiViec.Mask = "00/00/0000"
			Me.mtxNgayThoiViec.Name = "mtxNgayThoiViec"
			Me.mtxNgayThoiViec.PromptChar = " "c
			Dim mtxNgayThoiViec2 As Global.System.Windows.Forms.Control = Me.mtxNgayThoiViec
			size = New Global.System.Drawing.Size(116, 22)
			mtxNgayThoiViec2.Size = size
			Me.mtxNgayThoiViec.TabIndex = 101
			Me.mtxNgayThoiViec.Tag = "CR0000"
			Me.mtxNgayThoiViec.ValidatingType = GetType(Global.System.DateTime)
			Me.Label8.AutoSize = True
			Me.Label8.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label15 As Global.System.Windows.Forms.Control = Me.Label8
			point = New Global.System.Drawing.Point(3, 430)
			label15.Location = point
			Me.Label8.Name = "Label8"
			Dim label16 As Global.System.Windows.Forms.Control = Me.Label8
			size = New Global.System.Drawing.Size(89, 16)
			label16.Size = size
			Me.Label8.TabIndex = 103
			Me.Label8.Tag = "CR0069"
			Me.Label8.Text = "Ngày thôi việc"
			Dim mtxNgayNhanViec As Global.System.Windows.Forms.Control = Me.mtxNgayNhanViec
			point = New Global.System.Drawing.Point(130, 405)
			mtxNgayNhanViec.Location = point
			Me.mtxNgayNhanViec.Mask = "00/00/0000"
			Me.mtxNgayNhanViec.Name = "mtxNgayNhanViec"
			Me.mtxNgayNhanViec.PromptChar = " "c
			Dim mtxNgayNhanViec2 As Global.System.Windows.Forms.Control = Me.mtxNgayNhanViec
			size = New Global.System.Drawing.Size(116, 22)
			mtxNgayNhanViec2.Size = size
			Me.mtxNgayNhanViec.TabIndex = 100
			Me.mtxNgayNhanViec.Tag = "CR0000"
			Me.mtxNgayNhanViec.ValidatingType = GetType(Global.System.DateTime)
			Me.Label9.AutoSize = True
			Me.Label9.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label17 As Global.System.Windows.Forms.Control = Me.Label9
			point = New Global.System.Drawing.Point(3, 406)
			label17.Location = point
			Me.Label9.Name = "Label9"
			Dim label18 As Global.System.Windows.Forms.Control = Me.Label9
			size = New Global.System.Drawing.Size(96, 16)
			label18.Size = size
			Me.Label9.TabIndex = 102
			Me.Label9.Tag = "CR0068"
			Me.Label9.Text = "Ngày nhận việc"
			Me.Label10.AutoSize = True
			Me.Label10.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label19 As Global.System.Windows.Forms.Control = Me.Label10
			point = New Global.System.Drawing.Point(3, 457)
			label19.Location = point
			Me.Label10.Name = "Label10"
			Dim label20 As Global.System.Windows.Forms.Control = Me.Label10
			size = New Global.System.Drawing.Size(84, 16)
			label20.Size = size
			Me.Label10.TabIndex = 114
			Me.Label10.Tag = "CR0072"
			Me.Label10.Text = "Mã nhân viên"
			Me.txtTenUser.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTenUser As Global.System.Windows.Forms.Control = Me.txtTenUser
			point = New Global.System.Drawing.Point(291, 454)
			txtTenUser.Location = point
			Me.txtTenUser.Name = "txtTenUser"
			Me.txtTenUser.[ReadOnly] = True
			Dim txtTenUser2 As Global.System.Windows.Forms.Control = Me.txtTenUser
			size = New Global.System.Drawing.Size(234, 22)
			txtTenUser2.Size = size
			Me.txtTenUser.TabIndex = 113
			Me.txtTenUser.Tag = "0R0000"
			Me.txtMaUser.BackColor = Global.System.Drawing.Color.White
			Dim txtMaUser As Global.System.Windows.Forms.Control = Me.txtMaUser
			point = New Global.System.Drawing.Point(130, 454)
			txtMaUser.Location = point
			Me.txtMaUser.Name = "txtMaUser"
			Dim txtMaUser2 As Global.System.Windows.Forms.Control = Me.txtMaUser
			size = New Global.System.Drawing.Size(116, 22)
			txtMaUser2.Size = size
			Me.txtMaUser.TabIndex = 112
			Me.txtMaUser.Tag = "0R0000"
			Me.btnMaUser.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnMaUser As Global.System.Windows.Forms.Control = Me.btnMaUser
			point = New Global.System.Drawing.Point(247, 453)
			btnMaUser.Location = point
			Me.btnMaUser.Name = "btnMaUser"
			Dim btnMaUser2 As Global.System.Windows.Forms.Control = Me.btnMaUser
			size = New Global.System.Drawing.Size(38, 23)
			btnMaUser2.Size = size
			Me.btnMaUser.TabIndex = 115
			Me.btnMaUser.Tag = "CB0011"
			Me.btnMaUser.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(649, 526)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.btnMaUser)
			Me.Controls.Add(Me.Label10)
			Me.Controls.Add(Me.txtTenUser)
			Me.Controls.Add(Me.txtMaUser)
			Me.Controls.Add(Me.mtxNgayThoiViec)
			Me.Controls.Add(Me.Label8)
			Me.Controls.Add(Me.mtxNgayNhanViec)
			Me.Controls.Add(Me.Label9)
			Me.Controls.Add(Me.btnMucGiamGia)
			Me.Controls.Add(Me.btnKeyboard)
			Me.Controls.Add(Me.picZoom)
			Me.Controls.Add(Me.Label5)
			Me.Controls.Add(Me.Label4)
			Me.Controls.Add(Me.txtCHUCVU)
			Me.Controls.Add(Me.txtCAP)
			Me.Controls.Add(Me.txtMucGiamGia)
			Me.Controls.Add(Me.Label6)
			Me.Controls.Add(Me.txtRemark)
			Me.Controls.Add(Me.Label3)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.txtJOB)
			Me.Controls.Add(Me.cmbGIOTINH)
			Me.Controls.Add(Me.lblNAMGIOI)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.txtTUOI)
			Me.Controls.Add(Me.mtxBIRTHDAY)
			Me.Controls.Add(Me.LblBIRTHDAY)
			Me.Controls.Add(Me.LblMANHOMDV)
			Me.Controls.Add(Me.TxtMANHOMDV)
			Me.Controls.Add(Me.TxtTENNHOMDV)
			Me.Controls.Add(Me.BtnSELECTMANHOMDV)
			Me.Controls.Add(Me.txtColor)
			Me.Controls.Add(Me.lblISORG)
			Me.Controls.Add(Me.lblISFOR)
			Me.Controls.Add(Me.lblISCUS)
			Me.Controls.Add(Me.lblISSUP)
			Me.Controls.Add(Me.lblFAX)
			Me.Controls.Add(Me.lblVATCODE)
			Me.Controls.Add(Me.lblCONTACT)
			Me.Controls.Add(Me.lblMOBILE)
			Me.Controls.Add(Me.lblTEL)
			Me.Controls.Add(Me.lblADDRESS)
			Me.Controls.Add(Me.chkISORG)
			Me.Controls.Add(Me.chkISFOR)
			Me.Controls.Add(Me.chkISCUS)
			Me.Controls.Add(Me.txtWEBSITE)
			Me.Controls.Add(Me.txtEMAIL)
			Me.Controls.Add(Me.txtFAX)
			Me.Controls.Add(Me.txtVATCODE)
			Me.Controls.Add(Me.txtCONTACT)
			Me.Controls.Add(Me.txtMOBILE)
			Me.Controls.Add(Me.txtTEL)
			Me.Controls.Add(Me.txtADDRESS)
			Me.Controls.Add(Me.cmbStore)
			Me.Controls.Add(Me.lblBRANCH)
			Me.Controls.Add(Me.lblWEBSITE)
			Me.Controls.Add(Me.lblEMAIL)
			Me.Controls.Add(Me.chkISSUP)
			Me.Controls.Add(Me.lblOBJNAME)
			Me.Controls.Add(Me.txtOBJNAME)
			Me.Controls.Add(Me.txtCardCode)
			Me.Controls.Add(Me.txtOBJID)
			Me.Controls.Add(Me.Label7)
			Me.Controls.Add(Me.lblOBJID)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Me.KeyPreview = True
			padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMDV2"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Chi tiết DMDV"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.Panel1.ResumeLayout(False)
			CType(Me.picAnh, Global.System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.picZoom, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x0400071D RID: 1821
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
