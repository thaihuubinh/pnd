﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200006D RID: 109
	<DesignerGenerated()>
	Public Partial Class frmDMNH1
		Inherits Form

		' Token: 0x0600224B RID: 8779 RVA: 0x001A86FC File Offset: 0x001A68FC
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMNH1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMNH1_Load
			frmDMNH1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd_DMNH = False
			Me.mblnOK = False
			Me.mBlnMultiSel = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000BB5 RID: 2997
		' (get) Token: 0x0600224E RID: 8782 RVA: 0x001A9A54 File Offset: 0x001A7C54
		' (set) Token: 0x0600224F RID: 8783 RVA: 0x00006CD5 File Offset: 0x00004ED5
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000BB6 RID: 2998
		' (get) Token: 0x06002250 RID: 8784 RVA: 0x001A9A6C File Offset: 0x001A7C6C
		' (set) Token: 0x06002251 RID: 8785 RVA: 0x001A9A84 File Offset: 0x001A7C84
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x17000BB7 RID: 2999
		' (get) Token: 0x06002252 RID: 8786 RVA: 0x001A9AF0 File Offset: 0x001A7CF0
		' (set) Token: 0x06002253 RID: 8787 RVA: 0x001A9B08 File Offset: 0x001A7D08
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000BB8 RID: 3000
		' (get) Token: 0x06002254 RID: 8788 RVA: 0x001A9B74 File Offset: 0x001A7D74
		' (set) Token: 0x06002255 RID: 8789 RVA: 0x001A9B8C File Offset: 0x001A7D8C
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000BB9 RID: 3001
		' (get) Token: 0x06002256 RID: 8790 RVA: 0x001A9BF8 File Offset: 0x001A7DF8
		' (set) Token: 0x06002257 RID: 8791 RVA: 0x001A9C10 File Offset: 0x001A7E10
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000BBA RID: 3002
		' (get) Token: 0x06002258 RID: 8792 RVA: 0x001A9C7C File Offset: 0x001A7E7C
		' (set) Token: 0x06002259 RID: 8793 RVA: 0x001A9C94 File Offset: 0x001A7E94
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000BBB RID: 3003
		' (get) Token: 0x0600225A RID: 8794 RVA: 0x001A9D00 File Offset: 0x001A7F00
		' (set) Token: 0x0600225B RID: 8795 RVA: 0x001A9D18 File Offset: 0x001A7F18
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000BBC RID: 3004
		' (get) Token: 0x0600225C RID: 8796 RVA: 0x001A9D84 File Offset: 0x001A7F84
		' (set) Token: 0x0600225D RID: 8797 RVA: 0x001A9D9C File Offset: 0x001A7F9C
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000BBD RID: 3005
		' (get) Token: 0x0600225E RID: 8798 RVA: 0x001A9E08 File Offset: 0x001A8008
		' (set) Token: 0x0600225F RID: 8799 RVA: 0x00006CDF File Offset: 0x00004EDF
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000BBE RID: 3006
		' (get) Token: 0x06002260 RID: 8800 RVA: 0x001A9E20 File Offset: 0x001A8020
		' (set) Token: 0x06002261 RID: 8801 RVA: 0x001A9E38 File Offset: 0x001A8038
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000BBF RID: 3007
		' (get) Token: 0x06002262 RID: 8802 RVA: 0x001A9EA4 File Offset: 0x001A80A4
		' (set) Token: 0x06002263 RID: 8803 RVA: 0x001A9EBC File Offset: 0x001A80BC
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x17000BC0 RID: 3008
		' (get) Token: 0x06002264 RID: 8804 RVA: 0x001A9F28 File Offset: 0x001A8128
		' (set) Token: 0x06002265 RID: 8805 RVA: 0x001A9F40 File Offset: 0x001A8140
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000BC1 RID: 3009
		' (get) Token: 0x06002266 RID: 8806 RVA: 0x001A9FAC File Offset: 0x001A81AC
		' (set) Token: 0x06002267 RID: 8807 RVA: 0x00006CE9 File Offset: 0x00004EE9
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x17000BC2 RID: 3010
		' (get) Token: 0x06002268 RID: 8808 RVA: 0x001A9FC4 File Offset: 0x001A81C4
		' (set) Token: 0x06002269 RID: 8809 RVA: 0x001A9FDC File Offset: 0x001A81DC
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x17000BC3 RID: 3011
		' (get) Token: 0x0600226A RID: 8810 RVA: 0x001AA048 File Offset: 0x001A8248
		' (set) Token: 0x0600226B RID: 8811 RVA: 0x001AA060 File Offset: 0x001A8260
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x17000BC4 RID: 3012
		' (get) Token: 0x0600226C RID: 8812 RVA: 0x001AA0CC File Offset: 0x001A82CC
		' (set) Token: 0x0600226D RID: 8813 RVA: 0x001AA0E4 File Offset: 0x001A82E4
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000BC5 RID: 3013
		' (get) Token: 0x0600226E RID: 8814 RVA: 0x001AA150 File Offset: 0x001A8350
		' (set) Token: 0x0600226F RID: 8815 RVA: 0x001AA168 File Offset: 0x001A8368
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000BC6 RID: 3014
		' (get) Token: 0x06002270 RID: 8816 RVA: 0x001AA1D4 File Offset: 0x001A83D4
		' (set) Token: 0x06002271 RID: 8817 RVA: 0x001AA1EC File Offset: 0x001A83EC
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000BC7 RID: 3015
		' (get) Token: 0x06002272 RID: 8818 RVA: 0x001AA258 File Offset: 0x001A8458
		' (set) Token: 0x06002273 RID: 8819 RVA: 0x001AA270 File Offset: 0x001A8470
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x17000BC8 RID: 3016
		' (get) Token: 0x06002274 RID: 8820 RVA: 0x001AA2DC File Offset: 0x001A84DC
		' (set) Token: 0x06002275 RID: 8821 RVA: 0x00006CF3 File Offset: 0x00004EF3
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000BC9 RID: 3017
		' (get) Token: 0x06002276 RID: 8822 RVA: 0x001AA2F4 File Offset: 0x001A84F4
		' (set) Token: 0x06002277 RID: 8823 RVA: 0x001AA30C File Offset: 0x001A850C
		Friend Overridable Property chkCheckAll As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkCheckAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkCheckAll IsNot Nothing
				If flag Then
					RemoveHandler Me._chkCheckAll.CheckedChanged, AddressOf Me.chkCheckAll_CheckedChanged
				End If
				Me._chkCheckAll = value
				flag = Me._chkCheckAll IsNot Nothing
				If flag Then
					AddHandler Me._chkCheckAll.CheckedChanged, AddressOf Me.chkCheckAll_CheckedChanged
				End If
			End Set
		End Property

		' Token: 0x17000BCA RID: 3018
		' (get) Token: 0x06002278 RID: 8824 RVA: 0x001AA378 File Offset: 0x001A8578
		' (set) Token: 0x06002279 RID: 8825 RVA: 0x001AA390 File Offset: 0x001A8590
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000BCB RID: 3019
		' (get) Token: 0x0600227A RID: 8826 RVA: 0x001AA3FC File Offset: 0x001A85FC
		' (set) Token: 0x0600227B RID: 8827 RVA: 0x00006CFD File Offset: 0x00004EFD
		Public Property pBlnMultiSel As Boolean
			Get
				Return Me.mBlnMultiSel
			End Get
			Set(value As Boolean)
				Me.mBlnMultiSel = value
			End Set
		End Property

		' Token: 0x17000BCC RID: 3020
		' (get) Token: 0x0600227C RID: 8828 RVA: 0x001AA414 File Offset: 0x001A8614
		' (set) Token: 0x0600227D RID: 8829 RVA: 0x00006D08 File Offset: 0x00004F08
		Public Property pBlnLSAVE As Boolean
			Get
				Return Me.mBlnLSAVE
			End Get
			Set(value As Boolean)
				Me.mBlnLSAVE = value
			End Set
		End Property

		' Token: 0x17000BCD RID: 3021
		' (get) Token: 0x0600227E RID: 8830 RVA: 0x001AA42C File Offset: 0x001A862C
		' (set) Token: 0x0600227F RID: 8831 RVA: 0x00006D13 File Offset: 0x00004F13
		Public Property pBlnOK As Boolean
			Get
				Return Me.mblnOK
			End Get
			Set(value As Boolean)
				Me.mblnOK = value
			End Set
		End Property

		' Token: 0x17000BCE RID: 3022
		' (get) Token: 0x06002280 RID: 8832 RVA: 0x001AA444 File Offset: 0x001A8644
		' (set) Token: 0x06002281 RID: 8833 RVA: 0x00006D1E File Offset: 0x00004F1E
		Public Property pStrMANCHU As String
			Get
				Return Me.mStrMANCHU
			End Get
			Set(value As String)
				Me.mStrMANCHU = value
			End Set
		End Property

		' Token: 0x17000BCF RID: 3023
		' (get) Token: 0x06002282 RID: 8834 RVA: 0x001AA45C File Offset: 0x001A865C
		' (set) Token: 0x06002283 RID: 8835 RVA: 0x00006D29 File Offset: 0x00004F29
		Public Property pStrMAMT As String
			Get
				Return Me.mStrMAMT
			End Get
			Set(value As String)
				Me.mStrMAMT = value
			End Set
		End Property

		' Token: 0x17000BD0 RID: 3024
		' (get) Token: 0x06002284 RID: 8836 RVA: 0x001AA474 File Offset: 0x001A8674
		' (set) Token: 0x06002285 RID: 8837 RVA: 0x00006D34 File Offset: 0x00004F34
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x17000BD1 RID: 3025
		' (get) Token: 0x06002286 RID: 8838 RVA: 0x001AA48C File Offset: 0x001A868C
		' (set) Token: 0x06002287 RID: 8839 RVA: 0x00006D3F File Offset: 0x00004F3F
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000BD2 RID: 3026
		' (get) Token: 0x06002288 RID: 8840 RVA: 0x001AA4A4 File Offset: 0x001A86A4
		' (set) Token: 0x06002289 RID: 8841 RVA: 0x00006D4A File Offset: 0x00004F4A
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x0600228A RID: 8842 RVA: 0x001AA4BC File Offset: 0x001A86BC
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Me.mStrOBJID = ""
				Me.mStrOBJNAME = ""
				Dim flag As Boolean = Me.mBlnMultiSel
				Dim flag2 As Boolean
				If flag Then
					Try
						For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
							Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
							flag2 = Conversions.ToBoolean(dataGridViewRow.Cells("chkSelect").Value)
							If flag2 Then
								Me.mStrOBJID = Me.mStrOBJID + dataGridViewRow.Cells("OBJID").Value.ToString().Trim() + ","
								Me.mStrOBJNAME = Me.mStrOBJNAME + dataGridViewRow.Cells("OBJNAME").Value.ToString().Trim() + ","
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag2 = TypeOf enumerator Is IDisposable
						If flag2 Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
				Else
					Me.mStrOBJID = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
					Me.mStrOBJNAME = Me.dgvData.CurrentRow.Cells("OBJNAME").Value.ToString().Trim() + "  " + Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value.ToString().Trim()
				End If
				flag2 = Me.mStrOBJID.Trim().EndsWith(",")
				If flag2 Then
					Me.mStrOBJID = Me.mStrOBJID.Trim().Substring(0, Me.mStrOBJID.Trim().Length - 1)
					Me.mStrOBJNAME = Me.mStrOBJNAME.Trim().Substring(0, Me.mStrOBJNAME.Trim().Length - 1)
				End If
				flag2 = Me.dgvData.CurrentRow IsNot Nothing
				If flag2 Then
					Me.mStrMAMT = Conversions.ToString(Me.dgvData.CurrentRow.Cells("MAMT").Value)
					Me.mBlnLSAVE = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSAVE").Value)
					Me.mStrMANCHU = Conversions.ToString(Me.dgvData.CurrentRow.Cells("MANCHU").Value)
				End If
				Me.mblnOK = True
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600228B RID: 8843 RVA: 0x001AA828 File Offset: 0x001A8A28
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600228C RID: 8844 RVA: 0x001AA8F8 File Offset: 0x001A8AF8
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600228D RID: 8845 RVA: 0x001AA9E8 File Offset: 0x001A8BE8
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600228E RID: 8846 RVA: 0x001AAACC File Offset: 0x001A8CCC
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600228F RID: 8847 RVA: 0x001AAB90 File Offset: 0x001A8D90
		Private Sub frmDMNH1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMNH1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002290 RID: 8848 RVA: 0x001AAC28 File Offset: 0x001A8E28
		Private Sub frmDMNH1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				Me.sGetPara_From_SetparaXML()
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMNH1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002291 RID: 8849 RVA: 0x001AAD38 File Offset: 0x001A8F38
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002292 RID: 8850 RVA: 0x001AAE40 File Offset: 0x001A9040
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.mblnOK = False
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002293 RID: 8851 RVA: 0x001AAEE0 File Offset: 0x001A90E0
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMNH As frmDMNH2 = New frmDMNH2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMNH.pbytFromStatus = 1
				Dim flag As Boolean = Me.mblnAutoAdd_DMNH
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNH_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMNH.txtOBJID.Text = Strings.Right("00000" + array(0).Value.ToString(), 5)
						frmDMNH.txtOBJID.[ReadOnly] = True
						frmDMNH.txtOBJID.BackColor = frmDMNH.txtAccName.BackColor
					End If
				End If
				frmDMNH.ShowDialog()
				flag = frmDMNH.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMNH.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMNH.Dispose()
			End Try
		End Sub

		' Token: 0x06002294 RID: 8852 RVA: 0x001AB118 File Offset: 0x001A9318
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMNH As frmDMNH2 = New frmDMNH2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMNH2 As frmDMNH2 = frmDMNH
				frmDMNH2.pbytFromStatus = 2
				frmDMNH2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMNH2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
				frmDMNH2.txtMAMT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMT").Value, ""))
				frmDMNH2.txtAccName.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENTHUE").Value, ""))
				frmDMNH2.txtMANCHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANCHU").Value, ""))
				frmDMNH2.chkLSAVE.Checked = False
				frmDMNH2.txtQtyChild.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("QTYCHILD").Value, ""))
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("TYPECHILD").Value)
				If flag Then
					frmDMNH2.radTypeChild1.Checked = True
				Else
					frmDMNH2.radTypeChild0.Checked = True
				End If
				flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSAVE").Value)
				If flag Then
					frmDMNH2.chkLSAVE.Checked = True
				End If
				flag = Me.mblnAutoAdd_DMNH
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNH_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMNH.txtOBJID.Text = Strings.Right("00000" + array(0).Value.ToString(), 5)
						frmDMNH.txtOBJID.[ReadOnly] = True
						frmDMNH.txtOBJID.BackColor = frmDMNH.txtAccName.BackColor
					End If
				End If
				frmDMNH.ShowDialog()
				flag = frmDMNH.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMNH.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAddDefault_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMNH.Dispose()
			End Try
		End Sub

		' Token: 0x06002295 RID: 8853 RVA: 0x001AB54C File Offset: 0x001A974C
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMNH As frmDMNH2 = New frmDMNH2()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					frmDMNH.Dispose()
				Else
					Dim frmDMNH2 As frmDMNH2 = frmDMNH
					frmDMNH2.pbytFromStatus = 3
					frmDMNH2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMNH2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMNH2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
					frmDMNH2.txtMAMT.Text = Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMT").Value, "")))
					frmDMNH2.txtAccName.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENTHUE").Value, ""))
					frmDMNH2.txtMANCHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANCHU").Value, ""))
					frmDMNH2.chkLSAVE.Checked = False
					frmDMNH2.txtQtyChild.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("QTYCHILD").Value, ""))
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("TYPECHILD").Value)
					If flag Then
						frmDMNH2.radTypeChild1.Checked = True
					Else
						frmDMNH2.radTypeChild0.Checked = True
					End If
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSAVE").Value)
					If flag Then
						frmDMNH2.chkLSAVE.Checked = True
					End If
					frmDMNH.ShowDialog()
					flag = frmDMNH.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMNH.pStrFilter)
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMNH.Dispose()
			End Try
		End Sub

		' Token: 0x06002296 RID: 8854 RVA: 0x001AB91C File Offset: 0x001A9B1C
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMNH As frmDMNH2 = New frmDMNH2()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
					frmDMNH.Dispose()
				Else
					Dim frmDMNH2 As frmDMNH2 = frmDMNH
					frmDMNH2.pbytFromStatus = 4
					frmDMNH2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMNH2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMNH2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
					frmDMNH2.txtMAMT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMT").Value, ""))
					frmDMNH2.txtAccName.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENTHUE").Value, ""))
					frmDMNH2.txtMANCHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MANCHU").Value, ""))
					frmDMNH2.chkLSAVE.Checked = False
					frmDMNH2.txtQtyChild.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("QTYCHILD").Value, ""))
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("TYPECHILD").Value)
					If flag Then
						frmDMNH2.radTypeChild1.Checked = True
					Else
						frmDMNH2.radTypeChild0.Checked = True
					End If
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSAVE").Value)
					If flag Then
						frmDMNH2.chkLSAVE.Checked = True
					End If
					frmDMNH.ShowDialog()
					flag = frmDMNH.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMNH.Dispose()
			End Try
		End Sub

		' Token: 0x06002297 RID: 8855 RVA: 0x001ABCC8 File Offset: 0x001A9EC8
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMNH As frmDMNH2 = New frmDMNH2()
			Try
				frmDMNH.pbytFromStatus = 6
				frmDMNH.txtMAMT.Text = ""
				frmDMNH.txtMANCHU.Text = ""
				frmDMNH.txtAccName.Text = ""
				frmDMNH.ShowDialog()
				Dim flag As Boolean = frmDMNH.pbytSuccess = 0
				If flag Then
					frmDMNH.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMNH.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMNH.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMNH.Dispose()
			End Try
		End Sub

		' Token: 0x06002298 RID: 8856 RVA: 0x001ABEF0 File Offset: 0x001AA0F0
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMNH As frmDMNH2 = New frmDMNH2()
			Try
				Me.btnFindNext.Visible = False
				frmDMNH.pbytFromStatus = 5
				frmDMNH.txtMAMT.Text = ""
				frmDMNH.txtMANCHU.Text = ""
				frmDMNH.txtAccName.Text = ""
				frmDMNH.ShowDialog()
				Dim flag As Boolean = frmDMNH.pbytSuccess = 0
				If Not flag Then
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMNH.pStrFilter
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMNH.Dispose()
			End Try
		End Sub

		' Token: 0x06002299 RID: 8857 RVA: 0x001AC02C File Offset: 0x001AA22C
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMNH As frmDMNH2 = New frmDMNH2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMNH.Dispose()
			End Try
		End Sub

		' Token: 0x0600229A RID: 8858 RVA: 0x001AC0F4 File Offset: 0x001AA2F4
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x0600229B RID: 8859 RVA: 0x001AC270 File Offset: 0x001AA470
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fPrintDMNH()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600229C RID: 8860 RVA: 0x001AC308 File Offset: 0x001AA508
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600229D RID: 8861 RVA: 0x001AC3B8 File Offset: 0x001AA5B8
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMNH")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mblnAutoAdd_DMNH = xmlNode.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600229E RID: 8862 RVA: 0x001AC4B4 File Offset: 0x001AA6B4
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("chkSelect").Visible = Me.mBlnMultiSel
				Me.chkCheckAll.Visible = Me.mBlnMultiSel
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SUBOBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("SUBOBJNAME").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("SUBOBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENTHUE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("TENTHUE").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENTHUE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENNCHU").HeaderText = Strings.Trim(Me.mArrStrFrmMess(17))
				dgvData.Columns("TENNCHU").Width = Me.Width - Me.grpControl.Width - 660
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENNCHU").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LSAVE").Visible = False
				dgvData.Columns("MAMT").Visible = False
				dgvData.Columns("FIXED").Visible = False
				dgvData.Columns("MANCHU").Visible = False
				dgvData.Columns("TONKHO").Visible = False
				dgvData.Columns("QTYCHILD").Visible = False
				dgvData.Columns("TYPECHILD").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600229F RID: 8863 RVA: 0x001AC8B0 File Offset: 0x001AAAB0
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060022A0 RID: 8864 RVA: 0x001ACA30 File Offset: 0x001AAC30
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNH_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					Dim dataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn = New DataGridViewCheckBoxColumn()
					dataGridViewCheckBoxColumn.[ReadOnly] = False
					dataGridViewCheckBoxColumn.Name = "chkSelect"
					dataGridViewCheckBoxColumn.HeaderText = Me.mArrStrFrmMess(28)
					Me.dgvData.Columns.Insert(0, dataGridViewCheckBoxColumn)
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060022A1 RID: 8865 RVA: 0x001ACB64 File Offset: 0x001AAD64
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.mBytOpen_FromMenu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060022A2 RID: 8866 RVA: 0x001ACCB4 File Offset: 0x001AAEB4
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2060300000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060022A3 RID: 8867 RVA: 0x001ACDC0 File Offset: 0x001AAFC0
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060022A4 RID: 8868 RVA: 0x001ACE6C File Offset: 0x001AB06C
		Private Function fPrintDMNH() As Byte
			Dim rptDMNH As rptDMNH = New rptDMNH()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMNH, "")
				Dim text As String = "2060300000"
				mdlReport.gsSetOfficeReport(rptDMNH, text)
				mdlReport.gsSetFontReport(rptDMNH)
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "SP_FRMDMNH_GET_ALL_DATA", flag)
				Dim flag2 As Boolean = flag
				If flag2 Then
					Dim num As Integer = 0
					Dim num2 As Integer = clsConnect.Rows.Count - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						Dim flag3 As Boolean = Operators.ConditionalCompareObjectEqual(clsConnect.Rows(num3)("LSAVE"), True, False)
						If flag3 Then
							clsConnect.Rows(num3)("TONKHO") = Me.mArrStrFrmMess(26)
						Else
							clsConnect.Rows(num3)("TONKHO") = Me.mArrStrFrmMess(27)
						End If
						num3 += 1
					End While
					rptDMNH.SetDataSource(clsConnect)
					rptDMNH.DataDefinition.FormulaFields("fGroupCode").Text = "{dtReport.OBJID}"
					rptDMNH.DataDefinition.FormulaFields("fGroupName").Text = "{dtReport.OBJNAME}"
					rptDMNH.DataDefinition.FormulaFields("fTaxName").Text = "{dtReport.TENTHUE}"
					rptDMNH.DataDefinition.FormulaFields("fInventory").Text = "{dtReport.TONKHO}"
					rptDMNH.DataDefinition.FormulaFields("fGroupMain").Text = "{dtReport.MANCHU}"
					rptDMNH.DataDefinition.FormulaFields("fNameGroupMain").Text = "{dtReport.TENNCHU}"
					mdlReport.gsSetTextReport(rptDMNH, "RPTDMNH")
					MyProject.Forms.frmReport.pSource = rptDMNH
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMNH.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMNH.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMNH.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMNH " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMNH.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060022A5 RID: 8869 RVA: 0x001AD184 File Offset: 0x001AB384
		Private Sub chkCheckAll_CheckedChanged(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.chkCheckAll.Checked
			If flag Then
				Try
					For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
						Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
						dataGridViewRow.Cells("chkSelect").Value = True
					Next
				Finally
					Dim enumerator As IEnumerator
					flag = TypeOf enumerator Is IDisposable
					If flag Then
						TryCast(enumerator, IDisposable).Dispose()
					End If
				End Try
			Else
				Try
					For Each obj2 As Object In CType(Me.dgvData.Rows, IEnumerable)
						Dim dataGridViewRow2 As DataGridViewRow = CType(obj2, DataGridViewRow)
						dataGridViewRow2.Cells("chkSelect").Value = False
					Next
				Finally
					Dim enumerator2 As IEnumerator
					flag = TypeOf enumerator2 Is IDisposable
					If flag Then
						TryCast(enumerator2, IDisposable).Dispose()
					End If
				End Try
			End If
		End Sub

		' Token: 0x04000DF7 RID: 3575
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000DF9 RID: 3577
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000DFA RID: 3578
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000DFB RID: 3579
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000DFC RID: 3580
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000DFD RID: 3581
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000DFE RID: 3582
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000DFF RID: 3583
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000E00 RID: 3584
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000E01 RID: 3585
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000E02 RID: 3586
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000E03 RID: 3587
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000E04 RID: 3588
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000E05 RID: 3589
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000E06 RID: 3590
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000E07 RID: 3591
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000E08 RID: 3592
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000E09 RID: 3593
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000E0A RID: 3594
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000E0B RID: 3595
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000E0C RID: 3596
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000E0D RID: 3597
		<AccessedThroughProperty("chkCheckAll")>
		Private _chkCheckAll As CheckBox

		' Token: 0x04000E0E RID: 3598
		Private mArrStrFrmMess As String()

		' Token: 0x04000E0F RID: 3599
		Private mStrOBJID As String

		' Token: 0x04000E10 RID: 3600
		Private mStrOBJNAME As String

		' Token: 0x04000E11 RID: 3601
		Private mStrMAMT As String

		' Token: 0x04000E12 RID: 3602
		Private mBlnLSAVE As Boolean

		' Token: 0x04000E13 RID: 3603
		Private mStrMANCHU As String

		' Token: 0x04000E14 RID: 3604
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000E15 RID: 3605
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000E16 RID: 3606
		Private marrDrFind As DataRow()

		' Token: 0x04000E17 RID: 3607
		Private mintFindLastPos As Integer

		' Token: 0x04000E18 RID: 3608
		Private mblnAutoAdd_DMNH As Boolean

		' Token: 0x04000E19 RID: 3609
		Private mblnOK As Boolean

		' Token: 0x04000E1A RID: 3610
		Private mBlnMultiSel As Boolean
	End Class
End Namespace
