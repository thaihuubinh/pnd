﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x02000107 RID: 263
	Public Class crpKitchenK58ChuyenBan
		Inherits ReportClass

		' Token: 0x06005620 RID: 22048 RVA: 0x0000EC7E File Offset: 0x0000CE7E
		Public Sub New()
			crpKitchenK58ChuyenBan.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001EAA RID: 7850
		' (get) Token: 0x06005621 RID: 22049 RVA: 0x004DAC48 File Offset: 0x004D8E48
		' (set) Token: 0x06005622 RID: 22050 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crpKitchenK58ChuyenBan.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001EAB RID: 7851
		' (get) Token: 0x06005623 RID: 22051 RVA: 0x004DA738 File Offset: 0x004D8938
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsTitle As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001EAC RID: 7852
		' (get) Token: 0x06005624 RID: 22052 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsLien As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001EAD RID: 7853
		' (get) Token: 0x06005625 RID: 22053 RVA: 0x004DA780 File Offset: 0x004D8980
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsCall As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001EAE RID: 7854
		' (get) Token: 0x06005626 RID: 22054 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsBill As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001EAF RID: 7855
		' (get) Token: 0x06005627 RID: 22055 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsTable As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001EB0 RID: 7856
		' (get) Token: 0x06005628 RID: 22056 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsCashier As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x17001EB1 RID: 7857
		' (get) Token: 0x06005629 RID: 22057 RVA: 0x004DA810 File Offset: 0x004D8A10
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsService As Section
			Get
				Return Me.ReportDefinition.Sections(6)
			End Get
		End Property

		' Token: 0x17001EB2 RID: 7858
		' (get) Token: 0x0600562A RID: 22058 RVA: 0x004DA834 File Offset: 0x004D8A34
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsCus As Section
			Get
				Return Me.ReportDefinition.Sections(7)
			End Get
		End Property

		' Token: 0x17001EB3 RID: 7859
		' (get) Token: 0x0600562B RID: 22059 RVA: 0x004DA858 File Offset: 0x004D8A58
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property phsTieude1 As Section
			Get
				Return Me.ReportDefinition.Sections(8)
			End Get
		End Property

		' Token: 0x17001EB4 RID: 7860
		' (get) Token: 0x0600562C RID: 22060 RVA: 0x004DA87C File Offset: 0x004D8A7C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property phsTieude2 As Section
			Get
				Return Me.ReportDefinition.Sections(9)
			End Get
		End Property

		' Token: 0x17001EB5 RID: 7861
		' (get) Token: 0x0600562D RID: 22061 RVA: 0x004DA8A0 File Offset: 0x004D8AA0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section3 As Section
			Get
				Return Me.ReportDefinition.Sections(10)
			End Get
		End Property

		' Token: 0x17001EB6 RID: 7862
		' (get) Token: 0x0600562E RID: 22062 RVA: 0x004DA8C4 File Offset: 0x004D8AC4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsTen As Section
			Get
				Return Me.ReportDefinition.Sections(11)
			End Get
		End Property

		' Token: 0x17001EB7 RID: 7863
		' (get) Token: 0x0600562F RID: 22063 RVA: 0x004DA8E8 File Offset: 0x004D8AE8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsSL As Section
			Get
				Return Me.ReportDefinition.Sections(12)
			End Get
		End Property

		' Token: 0x17001EB8 RID: 7864
		' (get) Token: 0x06005630 RID: 22064 RVA: 0x004DA90C File Offset: 0x004D8B0C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property dsPrice As Section
			Get
				Return Me.ReportDefinition.Sections(13)
			End Get
		End Property

		' Token: 0x17001EB9 RID: 7865
		' (get) Token: 0x06005631 RID: 22065 RVA: 0x004DA930 File Offset: 0x004D8B30
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(14)
			End Get
		End Property

		' Token: 0x17001EBA RID: 7866
		' (get) Token: 0x06005632 RID: 22066 RVA: 0x004DA954 File Offset: 0x004D8B54
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(15)
			End Get
		End Property

		' Token: 0x17001EBB RID: 7867
		' (get) Token: 0x06005633 RID: 22067 RVA: 0x004DA978 File Offset: 0x004D8B78
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property sNgay2 As Section
			Get
				Return Me.ReportDefinition.Sections(16)
			End Get
		End Property

		' Token: 0x17001EBC RID: 7868
		' (get) Token: 0x06005634 RID: 22068 RVA: 0x004DA99C File Offset: 0x004D8B9C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property sNgay As Section
			Get
				Return Me.ReportDefinition.Sections(17)
			End Get
		End Property

		' Token: 0x17001EBD RID: 7869
		' (get) Token: 0x06005635 RID: 22069 RVA: 0x004DA9C0 File Offset: 0x004D8BC0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(18)
			End Get
		End Property

		' Token: 0x040026FF RID: 9983
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
