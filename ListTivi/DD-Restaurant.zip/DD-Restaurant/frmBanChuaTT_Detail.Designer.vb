﻿Namespace prjIS_SalesPOS
	' Token: 0x0200001B RID: 27
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmBanChuaTT_Detail
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000402 RID: 1026 RVA: 0x000307D4 File Offset: 0x0002E9D4
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000403 RID: 1027 RVA: 0x0003080C File Offset: 0x0002EA0C
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmBanChuaTT_Detail))
			Me.lblPosition = New Global.System.Windows.Forms.Label()
			Me.btnLast = New Global.System.Windows.Forms.Button()
			Me.btnNext = New Global.System.Windows.Forms.Button()
			Me.grpNavigater = New Global.System.Windows.Forms.GroupBox()
			Me.btnFirst = New Global.System.Windows.Forms.Button()
			Me.btnPrevious = New Global.System.Windows.Forms.Button()
			Me.grpControl = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.dgvData = New Global.System.Windows.Forms.DataGridView()
			Me.lblMADV = New Global.System.Windows.Forms.Label()
			Me.txtMADV = New Global.System.Windows.Forms.TextBox()
			Me.lblREMARK = New Global.System.Windows.Forms.Label()
			Me.txtREMARK = New Global.System.Windows.Forms.TextBox()
			Me.btnPrintMas = New Global.System.Windows.Forms.Button()
			Me.btnDelMas = New Global.System.Windows.Forms.Button()
			Me.btnEditMas = New Global.System.Windows.Forms.Button()
			Me.btnFirstMas = New Global.System.Windows.Forms.Button()
			Me.btnPreMas = New Global.System.Windows.Forms.Button()
			Me.btnNextMas = New Global.System.Windows.Forms.Button()
			Me.btnLastMas = New Global.System.Windows.Forms.Button()
			Me.txtMAKH = New Global.System.Windows.Forms.TextBox()
			Me.lblMAKH = New Global.System.Windows.Forms.Label()
			Me.grpNavigater.SuspendLayout()
			Me.grpControl.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.lblPosition.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.lblPosition.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblPosition.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPosition As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(84, 14)
			lblPosition.Location = point
			Me.lblPosition.Name = "lblPosition"
			Dim lblPosition2 As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(93, 35)
			lblPosition2.Size = size
			Me.lblPosition.TabIndex = 6
			Me.lblPosition.Tag = "0R0000"
			Me.lblPosition.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btnLast.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi_1
			Dim btnLast As Global.System.Windows.Forms.Control = Me.btnLast
			point = New Global.System.Drawing.Point(215, 14)
			btnLast.Location = point
			Me.btnLast.Name = "btnLast"
			Dim btnLast2 As Global.System.Windows.Forms.Control = Me.btnLast
			size = New Global.System.Drawing.Size(40, 35)
			btnLast2.Size = size
			Me.btnLast.TabIndex = 5
			Me.btnLast.UseVisualStyleBackColor = True
			Me.btnNext.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi
			Dim btnNext As Global.System.Windows.Forms.Control = Me.btnNext
			point = New Global.System.Drawing.Point(176, 14)
			btnNext.Location = point
			Me.btnNext.Name = "btnNext"
			Dim btnNext2 As Global.System.Windows.Forms.Control = Me.btnNext
			size = New Global.System.Drawing.Size(40, 35)
			btnNext2.Size = size
			Me.btnNext.TabIndex = 4
			Me.btnNext.UseVisualStyleBackColor = True
			Me.grpNavigater.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom
			Me.grpNavigater.Controls.Add(Me.lblPosition)
			Me.grpNavigater.Controls.Add(Me.btnFirst)
			Me.grpNavigater.Controls.Add(Me.btnPrevious)
			Me.grpNavigater.Controls.Add(Me.btnLast)
			Me.grpNavigater.Controls.Add(Me.btnNext)
			Dim grpNavigater As Global.System.Windows.Forms.Control = Me.grpNavigater
			point = New Global.System.Drawing.Point(315, 427)
			grpNavigater.Location = point
			Me.grpNavigater.Name = "grpNavigater"
			Dim grpNavigater2 As Global.System.Windows.Forms.Control = Me.grpNavigater
			size = New Global.System.Drawing.Size(262, 59)
			grpNavigater2.Size = size
			Me.grpNavigater.TabIndex = 8
			Me.grpNavigater.TabStop = False
			Me.btnFirst.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui_1
			Dim btnFirst As Global.System.Windows.Forms.Control = Me.btnFirst
			point = New Global.System.Drawing.Point(6, 14)
			btnFirst.Location = point
			Me.btnFirst.Name = "btnFirst"
			Dim btnFirst2 As Global.System.Windows.Forms.Control = Me.btnFirst
			size = New Global.System.Drawing.Size(40, 35)
			btnFirst2.Size = size
			Me.btnFirst.TabIndex = 2
			Me.btnFirst.UseVisualStyleBackColor = True
			Me.btnPrevious.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui
			Dim btnPrevious As Global.System.Windows.Forms.Control = Me.btnPrevious
			point = New Global.System.Drawing.Point(45, 14)
			btnPrevious.Location = point
			Me.btnPrevious.Name = "btnPrevious"
			Dim btnPrevious2 As Global.System.Windows.Forms.Control = Me.btnPrevious
			size = New Global.System.Drawing.Size(40, 35)
			btnPrevious2.Size = size
			Me.btnPrevious.TabIndex = 3
			Me.btnPrevious.UseVisualStyleBackColor = True
			Me.grpControl.Controls.Add(Me.TableLayoutPanel1)
			Me.grpControl.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpControl As Global.System.Windows.Forms.Control = Me.grpControl
			point = New Global.System.Drawing.Point(881, 0)
			grpControl.Location = point
			Me.grpControl.Name = "grpControl"
			Dim grpControl2 As Global.System.Windows.Forms.Control = Me.grpControl
			size = New Global.System.Drawing.Size(119, 500)
			grpControl2.Size = size
			Me.grpControl.TabIndex = 0
			Me.grpControl.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 8)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 9
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11.11111F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11.11111F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11.11111F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11.11111F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11.11111F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11.11111F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11.11111F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11.11111F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 11.11111F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 479)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 427)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 49)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 12
			Me.btnExit.Tag = "CR0003"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.dgvData.AllowUserToAddRows = False
			Me.dgvData.AllowUserToDeleteRows = False
			Me.dgvData.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvData.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvData.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvData As Global.System.Windows.Forms.Control = Me.dgvData
			point = New Global.System.Drawing.Point(0, 115)
			dgvData.Location = point
			Me.dgvData.Name = "dgvData"
			Me.dgvData.[ReadOnly] = True
			Me.dgvData.RowTemplate.DefaultCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim dgvData2 As Global.System.Windows.Forms.Control = Me.dgvData
			size = New Global.System.Drawing.Size(875, 308)
			dgvData2.Size = size
			Me.dgvData.TabIndex = 9
			Me.lblMADV.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMADV As Global.System.Windows.Forms.Control = Me.lblMADV
			point = New Global.System.Drawing.Point(12, 18)
			lblMADV.Location = point
			Me.lblMADV.Name = "lblMADV"
			Dim lblMADV2 As Global.System.Windows.Forms.Control = Me.lblMADV
			size = New Global.System.Drawing.Size(137, 21)
			lblMADV2.Size = size
			Me.lblMADV.TabIndex = 62
			Me.lblMADV.Tag = "CR0034"
			Me.lblMADV.Text = "Nhà cung cấp"
			Me.txtMADV.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtMADV As Global.System.Windows.Forms.Control = Me.txtMADV
			point = New Global.System.Drawing.Point(155, 15)
			txtMADV.Location = point
			Me.txtMADV.Name = "txtMADV"
			Dim txtMADV2 As Global.System.Windows.Forms.Control = Me.txtMADV
			size = New Global.System.Drawing.Size(599, 22)
			txtMADV2.Size = size
			Me.txtMADV.TabIndex = 59
			Me.txtMADV.Tag = "0R0000"
			Me.lblREMARK.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblREMARK As Global.System.Windows.Forms.Control = Me.lblREMARK
			point = New Global.System.Drawing.Point(12, 74)
			lblREMARK.Location = point
			Me.lblREMARK.Name = "lblREMARK"
			Dim lblREMARK2 As Global.System.Windows.Forms.Control = Me.lblREMARK
			size = New Global.System.Drawing.Size(137, 21)
			lblREMARK2.Size = size
			Me.lblREMARK.TabIndex = 66
			Me.lblREMARK.Tag = "CR0037"
			Me.lblREMARK.Text = "Ghi chú"
			Me.txtREMARK.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtREMARK As Global.System.Windows.Forms.Control = Me.txtREMARK
			point = New Global.System.Drawing.Point(155, 71)
			txtREMARK.Location = point
			Me.txtREMARK.Name = "txtREMARK"
			Dim txtREMARK2 As Global.System.Windows.Forms.Control = Me.txtREMARK
			size = New Global.System.Drawing.Size(599, 22)
			txtREMARK2.Size = size
			Me.txtREMARK.TabIndex = 65
			Me.txtREMARK.Tag = "0R0000"
			Me.btnPrintMas.Image = Global.prjIS_SalesPOS.My.Resources.Resources._in
			Dim btnPrintMas As Global.System.Windows.Forms.Control = Me.btnPrintMas
			point = New Global.System.Drawing.Point(796, 75)
			btnPrintMas.Location = point
			Me.btnPrintMas.Name = "btnPrintMas"
			Dim btnPrintMas2 As Global.System.Windows.Forms.Control = Me.btnPrintMas
			size = New Global.System.Drawing.Size(80, 35)
			btnPrintMas2.Size = size
			Me.btnPrintMas.TabIndex = 7
			Me.btnPrintMas.Tag = "CR0032"
			Me.btnPrintMas.Text = "In"
			Me.btnPrintMas.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnPrintMas.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnPrintMas.UseVisualStyleBackColor = True
			Me.btnDelMas.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelMas As Global.System.Windows.Forms.Control = Me.btnDelMas
			point = New Global.System.Drawing.Point(796, 7)
			btnDelMas.Location = point
			Me.btnDelMas.Name = "btnDelMas"
			Dim btnDelMas2 As Global.System.Windows.Forms.Control = Me.btnDelMas
			size = New Global.System.Drawing.Size(80, 35)
			btnDelMas2.Size = size
			Me.btnDelMas.TabIndex = 5
			Me.btnDelMas.Tag = "CR0030"
			Me.btnDelMas.Text = "Xóa"
			Me.btnDelMas.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnDelMas.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelMas.UseVisualStyleBackColor = True
			Me.btnEditMas.Image = Global.prjIS_SalesPOS.My.Resources.Resources.sua
			Dim btnEditMas As Global.System.Windows.Forms.Control = Me.btnEditMas
			point = New Global.System.Drawing.Point(796, 41)
			btnEditMas.Location = point
			Me.btnEditMas.Name = "btnEditMas"
			Dim btnEditMas2 As Global.System.Windows.Forms.Control = Me.btnEditMas
			size = New Global.System.Drawing.Size(80, 35)
			btnEditMas2.Size = size
			Me.btnEditMas.TabIndex = 6
			Me.btnEditMas.Tag = "CR0031"
			Me.btnEditMas.Text = "Sửa"
			Me.btnEditMas.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnEditMas.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnEditMas.UseVisualStyleBackColor = True
			Me.btnFirstMas.Image = CType(componentResourceManager.GetObject("btnFirstMas.Image"), Global.System.Drawing.Image)
			Dim btnFirstMas As Global.System.Windows.Forms.Control = Me.btnFirstMas
			point = New Global.System.Drawing.Point(759, 0)
			btnFirstMas.Location = point
			Me.btnFirstMas.Name = "btnFirstMas"
			Dim btnFirstMas2 As Global.System.Windows.Forms.Control = Me.btnFirstMas
			size = New Global.System.Drawing.Size(31, 28)
			btnFirstMas2.Size = size
			Me.btnFirstMas.TabIndex = 1
			Me.btnFirstMas.UseVisualStyleBackColor = True
			Me.btnPreMas.Image = CType(componentResourceManager.GetObject("btnPreMas.Image"), Global.System.Drawing.Image)
			Dim btnPreMas As Global.System.Windows.Forms.Control = Me.btnPreMas
			point = New Global.System.Drawing.Point(759, 28)
			btnPreMas.Location = point
			Me.btnPreMas.Name = "btnPreMas"
			Dim btnPreMas2 As Global.System.Windows.Forms.Control = Me.btnPreMas
			size = New Global.System.Drawing.Size(31, 28)
			btnPreMas2.Size = size
			Me.btnPreMas.TabIndex = 2
			Me.btnPreMas.UseVisualStyleBackColor = True
			Me.btnNextMas.Image = CType(componentResourceManager.GetObject("btnNextMas.Image"), Global.System.Drawing.Image)
			Dim btnNextMas As Global.System.Windows.Forms.Control = Me.btnNextMas
			point = New Global.System.Drawing.Point(760, 56)
			btnNextMas.Location = point
			Me.btnNextMas.Name = "btnNextMas"
			Dim btnNextMas2 As Global.System.Windows.Forms.Control = Me.btnNextMas
			size = New Global.System.Drawing.Size(31, 28)
			btnNextMas2.Size = size
			Me.btnNextMas.TabIndex = 3
			Me.btnNextMas.UseVisualStyleBackColor = True
			Me.btnLastMas.Image = CType(componentResourceManager.GetObject("btnLastMas.Image"), Global.System.Drawing.Image)
			Dim btnLastMas As Global.System.Windows.Forms.Control = Me.btnLastMas
			point = New Global.System.Drawing.Point(760, 84)
			btnLastMas.Location = point
			Me.btnLastMas.Name = "btnLastMas"
			Dim btnLastMas2 As Global.System.Windows.Forms.Control = Me.btnLastMas
			size = New Global.System.Drawing.Size(31, 28)
			btnLastMas2.Size = size
			Me.btnLastMas.TabIndex = 4
			Me.btnLastMas.UseVisualStyleBackColor = True
			Me.txtMAKH.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtMAKH As Global.System.Windows.Forms.Control = Me.txtMAKH
			point = New Global.System.Drawing.Point(155, 43)
			txtMAKH.Location = point
			Me.txtMAKH.Name = "txtMAKH"
			Dim txtMAKH2 As Global.System.Windows.Forms.Control = Me.txtMAKH
			size = New Global.System.Drawing.Size(599, 22)
			txtMAKH2.Size = size
			Me.txtMAKH.TabIndex = 61
			Me.txtMAKH.Tag = "0R0000"
			Me.lblMAKH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAKH As Global.System.Windows.Forms.Control = Me.lblMAKH
			point = New Global.System.Drawing.Point(12, 46)
			lblMAKH.Location = point
			Me.lblMAKH.Name = "lblMAKH"
			Dim lblMAKH2 As Global.System.Windows.Forms.Control = Me.lblMAKH
			size = New Global.System.Drawing.Size(137, 21)
			lblMAKH2.Size = size
			Me.lblMAKH.TabIndex = 64
			Me.lblMAKH.Tag = "CR0036"
			Me.lblMAKH.Text = "Kho nhập"
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(1000, 500)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.btnLastMas)
			Me.Controls.Add(Me.btnNextMas)
			Me.Controls.Add(Me.btnPreMas)
			Me.Controls.Add(Me.btnFirstMas)
			Me.Controls.Add(Me.btnPrintMas)
			Me.Controls.Add(Me.btnDelMas)
			Me.Controls.Add(Me.btnEditMas)
			Me.Controls.Add(Me.lblREMARK)
			Me.Controls.Add(Me.txtREMARK)
			Me.Controls.Add(Me.lblMAKH)
			Me.Controls.Add(Me.txtMAKH)
			Me.Controls.Add(Me.lblMADV)
			Me.Controls.Add(Me.txtMADV)
			Me.Controls.Add(Me.dgvData)
			Me.Controls.Add(Me.grpNavigater)
			Me.Controls.Add(Me.grpControl)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmBanChuaTT_Detail"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "frmDOCUMENT023"
			Me.grpNavigater.ResumeLayout(False)
			Me.grpControl.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x040001C0 RID: 448
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
