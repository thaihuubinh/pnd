﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002EA RID: 746
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBCPrintReceiptKA5_5
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006EDF RID: 28383 RVA: 0x000139D9 File Offset: 0x00011BD9
		Public Sub New()
			CachedrptRepBCPrintReceiptKA5_5.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002DFC RID: 11772
		' (get) Token: 0x06006EE0 RID: 28384 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006EE1 RID: 28385 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002DFD RID: 11773
		' (get) Token: 0x06006EE2 RID: 28386 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006EE3 RID: 28387 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002DFE RID: 11774
		' (get) Token: 0x06006EE4 RID: 28388 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006EE5 RID: 28389 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006EE6 RID: 28390 RVA: 0x004DEF84 File Offset: 0x004DD184
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBCPrintReceiptKA5_5() With { .Site = Me.Site }
		End Function

		' Token: 0x06006EE7 RID: 28391 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028E2 RID: 10466
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
