﻿Namespace prjIS_SalesPOS
	' Token: 0x02000021 RID: 33
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCC
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000609 RID: 1545 RVA: 0x00048ABC File Offset: 0x00046CBC
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600060A RID: 1546 RVA: 0x00048AF4 File Offset: 0x00046CF4
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Global.System.ComponentModel.Container()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCC))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.lblOBJNAME = New Global.System.Windows.Forms.Label()
			Me.txtMANV = New Global.System.Windows.Forms.TextBox()
			Me.txtTENNV = New Global.System.Windows.Forms.TextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.txtDate = New Global.System.Windows.Forms.TextBox()
			Me.txtDisplay = New Global.System.Windows.Forms.TextBox()
			Me.tmrTime = New Global.System.Windows.Forms.Timer(Me.components)
			Me.tmrCount = New Global.System.Windows.Forms.Timer(Me.components)
			Me.txtPass = New Global.System.Windows.Forms.TextBox()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.grpButton.SuspendLayout()
			Me.SuspendLayout()
			Me.grpButton.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.grpButton.Controls.Add(Me.btnKeyboard)
			Me.grpButton.Controls.Add(Me.btnExit)
			Me.grpButton.Controls.Add(Me.btnSave)
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(4, 183)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(431, 62)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 7
			Me.grpButton.TabStop = False
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnKeyboard.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(161, 12)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(103, 43)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 124
			Me.btnKeyboard.Text = "Keyboard"
			Me.btnKeyboard.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Me.btnExit.Anchor = Global.System.Windows.Forms.AnchorStyles.None
			Me.btnExit.Image = CType(componentResourceManager.GetObject("btnExit.Image"), Global.System.Drawing.Image)
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(317, 12)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(108, 43)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "NC017R0003"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Image = CType(componentResourceManager.GetObject("btnSave.Image"), Global.System.Drawing.Image)
			Me.btnSave.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(6, 12)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(103, 43)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 4
			Me.btnSave.Tag = "NC017R0004"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.lblOBJNAME.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJNAME As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			point = New Global.System.Drawing.Point(12, 12)
			lblOBJNAME.Location = point
			Me.lblOBJNAME.Name = "lblOBJNAME"
			Dim lblOBJNAME2 As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			size = New Global.System.Drawing.Size(181, 29)
			lblOBJNAME2.Size = size
			Me.lblOBJNAME.TabIndex = 34
			Me.lblOBJNAME.Tag = "NC017B0008"
			Me.lblOBJNAME.Text = "Mã nhân viên"
			Me.txtMANV.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtMANV.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtMANV As Global.System.Windows.Forms.Control = Me.txtMANV
			point = New Global.System.Drawing.Point(199, 12)
			txtMANV.Location = point
			Me.txtMANV.Name = "txtMANV"
			Dim txtMANV2 As Global.System.Windows.Forms.Control = Me.txtMANV
			size = New Global.System.Drawing.Size(236, 29)
			txtMANV2.Size = size
			Me.txtMANV.TabIndex = 30
			Me.txtMANV.Tag = "N0017R0000"
			Me.txtTENNV.BackColor = Global.System.Drawing.Color.FromArgb(192, 255, 255)
			Me.txtTENNV.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtTENNV As Global.System.Windows.Forms.Control = Me.txtTENNV
			point = New Global.System.Drawing.Point(199, 82)
			txtTENNV.Location = point
			Me.txtTENNV.Name = "txtTENNV"
			Me.txtTENNV.[ReadOnly] = True
			Dim txtTENNV2 As Global.System.Windows.Forms.Control = Me.txtTENNV
			size = New Global.System.Drawing.Size(236, 29)
			txtTENNV2.Size = size
			Me.txtTENNV.TabIndex = 41
			Me.txtTENNV.Tag = "N0017R0000"
			Me.Label1.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(9, 82)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(184, 32)
			label2.Size = size
			Me.Label1.TabIndex = 42
			Me.Label1.Tag = "NC017B0009"
			Me.Label1.Text = "Tên nhân viên"
			Me.txtDate.BackColor = Global.System.Drawing.Color.FromArgb(192, 255, 255)
			Me.txtDate.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtDate As Global.System.Windows.Forms.Control = Me.txtDate
			point = New Global.System.Drawing.Point(10, 117)
			txtDate.Location = point
			Me.txtDate.Name = "txtDate"
			Dim txtDate2 As Global.System.Windows.Forms.Control = Me.txtDate
			size = New Global.System.Drawing.Size(425, 29)
			txtDate2.Size = size
			Me.txtDate.TabIndex = 43
			Me.txtDate.Tag = "N0017R0000"
			Me.txtDate.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.txtDisplay.BackColor = Global.System.Drawing.Color.FromArgb(192, 255, 255)
			Me.txtDisplay.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtDisplay As Global.System.Windows.Forms.Control = Me.txtDisplay
			point = New Global.System.Drawing.Point(10, 152)
			txtDisplay.Location = point
			Me.txtDisplay.Name = "txtDisplay"
			Dim txtDisplay2 As Global.System.Windows.Forms.Control = Me.txtDisplay
			size = New Global.System.Drawing.Size(425, 29)
			txtDisplay2.Size = size
			Me.txtDisplay.TabIndex = 44
			Me.txtDisplay.Tag = "N0017R0000"
			Me.txtDisplay.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.tmrCount.Interval = 5000
			Me.txtPass.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtPass.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtPass As Global.System.Windows.Forms.Control = Me.txtPass
			point = New Global.System.Drawing.Point(199, 47)
			txtPass.Location = point
			Me.txtPass.Name = "txtPass"
			Me.txtPass.PasswordChar = "*"c
			Dim txtPass2 As Global.System.Windows.Forms.Control = Me.txtPass
			size = New Global.System.Drawing.Size(236, 29)
			txtPass2.Size = size
			Me.txtPass.TabIndex = 30
			Me.txtPass.Tag = "N0017R0000"
			Me.Label2.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(12, 47)
			label3.Location = point
			Me.Label2.Name = "Label2"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(181, 29)
			label4.Size = size
			Me.Label2.TabIndex = 34
			Me.Label2.Tag = "NC017B0015"
			Me.Label2.Text = "mat ma"
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(447, 250)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.txtDisplay)
			Me.Controls.Add(Me.txtDate)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.txtTENNV)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.lblOBJNAME)
			Me.Controls.Add(Me.txtPass)
			Me.Controls.Add(Me.txtMANV)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmCC"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "frmPCC"
			Me.grpButton.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x040002A5 RID: 677
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
