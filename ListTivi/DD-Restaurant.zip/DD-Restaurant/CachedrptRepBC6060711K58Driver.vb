﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200027A RID: 634
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC6060711K58Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006664 RID: 26212 RVA: 0x000127E9 File Offset: 0x000109E9
		Public Sub New()
			CachedrptRepBC6060711K58Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170027B1 RID: 10161
		' (get) Token: 0x06006665 RID: 26213 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006666 RID: 26214 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170027B2 RID: 10162
		' (get) Token: 0x06006667 RID: 26215 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006668 RID: 26216 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170027B3 RID: 10163
		' (get) Token: 0x06006669 RID: 26217 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x0600666A RID: 26218 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x0600666B RID: 26219 RVA: 0x004DDAA0 File Offset: 0x004DBCA0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC6060711K58Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x0600666C RID: 26220 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002872 RID: 10354
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
