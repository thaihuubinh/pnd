﻿Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Threading
Imports System.Windows.Forms
Imports System.Xml
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200004E RID: 78
	<DesignerGenerated()>
	Public Partial Class frmDMHH1
		Inherits Form

		' Token: 0x06001543 RID: 5443 RVA: 0x00101CF8 File Offset: 0x000FFEF8
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMHH1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMHH1_Load
			frmDMHH1.__ENCList.Add(New WeakReference(Me))
			Me.mBlnSelect = False
			Me.mStrFilter = ""
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd_DMHH = False
			Me.mbytLen_OBJID = 15
			Me.marrDblPrice = New Double(9) {}
			Me.mblnSelectRow = False
			Me.dicSelected = New Dictionary(Of String, Integer)()
			Me.mStrLabelPath = ""
			Me.mStrLabelFont = "Times New Roman"
			Me.mStrChar1000 = ","
			Me.mStrCharLe = "."
			Me.mStrCharMoney = ""
			Me.mBytCharMoneyPos = 1
			Me.mStrLabelFileName = "Temp.xls"
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000760 RID: 1888
		' (get) Token: 0x06001546 RID: 5446 RVA: 0x001040B0 File Offset: 0x001022B0
		' (set) Token: 0x06001547 RID: 5447 RVA: 0x000052A8 File Offset: 0x000034A8
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000761 RID: 1889
		' (get) Token: 0x06001548 RID: 5448 RVA: 0x001040C8 File Offset: 0x001022C8
		' (set) Token: 0x06001549 RID: 5449 RVA: 0x001040E0 File Offset: 0x001022E0
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x17000762 RID: 1890
		' (get) Token: 0x0600154A RID: 5450 RVA: 0x0010414C File Offset: 0x0010234C
		' (set) Token: 0x0600154B RID: 5451 RVA: 0x00104164 File Offset: 0x00102364
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000763 RID: 1891
		' (get) Token: 0x0600154C RID: 5452 RVA: 0x001041D0 File Offset: 0x001023D0
		' (set) Token: 0x0600154D RID: 5453 RVA: 0x001041E8 File Offset: 0x001023E8
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000764 RID: 1892
		' (get) Token: 0x0600154E RID: 5454 RVA: 0x00104254 File Offset: 0x00102454
		' (set) Token: 0x0600154F RID: 5455 RVA: 0x0010426C File Offset: 0x0010246C
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000765 RID: 1893
		' (get) Token: 0x06001550 RID: 5456 RVA: 0x001042D8 File Offset: 0x001024D8
		' (set) Token: 0x06001551 RID: 5457 RVA: 0x001042F0 File Offset: 0x001024F0
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000766 RID: 1894
		' (get) Token: 0x06001552 RID: 5458 RVA: 0x0010435C File Offset: 0x0010255C
		' (set) Token: 0x06001553 RID: 5459 RVA: 0x00104374 File Offset: 0x00102574
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000767 RID: 1895
		' (get) Token: 0x06001554 RID: 5460 RVA: 0x001043E0 File Offset: 0x001025E0
		' (set) Token: 0x06001555 RID: 5461 RVA: 0x001043F8 File Offset: 0x001025F8
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000768 RID: 1896
		' (get) Token: 0x06001556 RID: 5462 RVA: 0x00104464 File Offset: 0x00102664
		' (set) Token: 0x06001557 RID: 5463 RVA: 0x000052B2 File Offset: 0x000034B2
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000769 RID: 1897
		' (get) Token: 0x06001558 RID: 5464 RVA: 0x0010447C File Offset: 0x0010267C
		' (set) Token: 0x06001559 RID: 5465 RVA: 0x00104494 File Offset: 0x00102694
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x1700076A RID: 1898
		' (get) Token: 0x0600155A RID: 5466 RVA: 0x00104500 File Offset: 0x00102700
		' (set) Token: 0x0600155B RID: 5467 RVA: 0x00104518 File Offset: 0x00102718
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x1700076B RID: 1899
		' (get) Token: 0x0600155C RID: 5468 RVA: 0x00104584 File Offset: 0x00102784
		' (set) Token: 0x0600155D RID: 5469 RVA: 0x0010459C File Offset: 0x0010279C
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x1700076C RID: 1900
		' (get) Token: 0x0600155E RID: 5470 RVA: 0x00104608 File Offset: 0x00102808
		' (set) Token: 0x0600155F RID: 5471 RVA: 0x000052BC File Offset: 0x000034BC
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x1700076D RID: 1901
		' (get) Token: 0x06001560 RID: 5472 RVA: 0x00104620 File Offset: 0x00102820
		' (set) Token: 0x06001561 RID: 5473 RVA: 0x00104638 File Offset: 0x00102838
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x1700076E RID: 1902
		' (get) Token: 0x06001562 RID: 5474 RVA: 0x001046A4 File Offset: 0x001028A4
		' (set) Token: 0x06001563 RID: 5475 RVA: 0x001046BC File Offset: 0x001028BC
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x1700076F RID: 1903
		' (get) Token: 0x06001564 RID: 5476 RVA: 0x00104728 File Offset: 0x00102928
		' (set) Token: 0x06001565 RID: 5477 RVA: 0x00104740 File Offset: 0x00102940
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000770 RID: 1904
		' (get) Token: 0x06001566 RID: 5478 RVA: 0x001047AC File Offset: 0x001029AC
		' (set) Token: 0x06001567 RID: 5479 RVA: 0x001047C4 File Offset: 0x001029C4
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000771 RID: 1905
		' (get) Token: 0x06001568 RID: 5480 RVA: 0x00104830 File Offset: 0x00102A30
		' (set) Token: 0x06001569 RID: 5481 RVA: 0x00104848 File Offset: 0x00102A48
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000772 RID: 1906
		' (get) Token: 0x0600156A RID: 5482 RVA: 0x001048B4 File Offset: 0x00102AB4
		' (set) Token: 0x0600156B RID: 5483 RVA: 0x001048CC File Offset: 0x00102ACC
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.SelectionChanged, AddressOf Me.dgvData_SelectionChanged
					RemoveHandler Me._dgvData.CellMouseUp, AddressOf Me.dgvData_CellMouseUp
					RemoveHandler Me._dgvData.CellEndEdit, AddressOf Me.dgvData_CellEndEdit
					RemoveHandler Me._dgvData.CellMouseDown, AddressOf Me.dgvData_CellMouseDown
					RemoveHandler Me._dgvData.CellClick, AddressOf Me.dgvData_CellClick
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.SelectionChanged, AddressOf Me.dgvData_SelectionChanged
					AddHandler Me._dgvData.CellMouseUp, AddressOf Me.dgvData_CellMouseUp
					AddHandler Me._dgvData.CellEndEdit, AddressOf Me.dgvData_CellEndEdit
					AddHandler Me._dgvData.CellMouseDown, AddressOf Me.dgvData_CellMouseDown
					AddHandler Me._dgvData.CellClick, AddressOf Me.dgvData_CellClick
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x17000773 RID: 1907
		' (get) Token: 0x0600156C RID: 5484 RVA: 0x00104A38 File Offset: 0x00102C38
		' (set) Token: 0x0600156D RID: 5485 RVA: 0x000052C6 File Offset: 0x000034C6
		Friend Overridable Property lblMANH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMANH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMANH = value
			End Set
		End Property

		' Token: 0x17000774 RID: 1908
		' (get) Token: 0x0600156E RID: 5486 RVA: 0x00104A50 File Offset: 0x00102C50
		' (set) Token: 0x0600156F RID: 5487 RVA: 0x000052D0 File Offset: 0x000034D0
		Friend Overridable Property txtOBJNAMENH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAMENH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAMENH = value
			End Set
		End Property

		' Token: 0x17000775 RID: 1909
		' (get) Token: 0x06001570 RID: 5488 RVA: 0x00104A68 File Offset: 0x00102C68
		' (set) Token: 0x06001571 RID: 5489 RVA: 0x00104A80 File Offset: 0x00102C80
		Friend Overridable Property btnSelectNH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelectNH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelectNH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelectNH.GotFocus, AddressOf Me.txtOBJIDNH_GotFocus
					RemoveHandler Me._btnSelectNH.Click, AddressOf Me.btnSelectNH_Click
				End If
				Me._btnSelectNH = value
				flag = Me._btnSelectNH IsNot Nothing
				If flag Then
					AddHandler Me._btnSelectNH.GotFocus, AddressOf Me.txtOBJIDNH_GotFocus
					AddHandler Me._btnSelectNH.Click, AddressOf Me.btnSelectNH_Click
				End If
			End Set
		End Property

		' Token: 0x17000776 RID: 1910
		' (get) Token: 0x06001572 RID: 5490 RVA: 0x00104B1C File Offset: 0x00102D1C
		' (set) Token: 0x06001573 RID: 5491 RVA: 0x00104B34 File Offset: 0x00102D34
		Friend Overridable Property txtOBJIDNH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJIDNH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJIDNH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJIDNH.GotFocus, AddressOf Me.txtOBJIDNH_GotFocus
					RemoveHandler Me._txtOBJIDNH.TextChanged, AddressOf Me.txtOBJIDNH_TextChanged
				End If
				Me._txtOBJIDNH = value
				flag = Me._txtOBJIDNH IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJIDNH.GotFocus, AddressOf Me.txtOBJIDNH_GotFocus
					AddHandler Me._txtOBJIDNH.TextChanged, AddressOf Me.txtOBJIDNH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000777 RID: 1911
		' (get) Token: 0x06001574 RID: 5492 RVA: 0x00104BD0 File Offset: 0x00102DD0
		' (set) Token: 0x06001575 RID: 5493 RVA: 0x000052DA File Offset: 0x000034DA
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000778 RID: 1912
		' (get) Token: 0x06001576 RID: 5494 RVA: 0x00104BE8 File Offset: 0x00102DE8
		' (set) Token: 0x06001577 RID: 5495 RVA: 0x000052E4 File Offset: 0x000034E4
		Friend Overridable Property tblpLuoi As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._tblpLuoi
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._tblpLuoi = value
			End Set
		End Property

		' Token: 0x17000779 RID: 1913
		' (get) Token: 0x06001578 RID: 5496 RVA: 0x00104C00 File Offset: 0x00102E00
		' (set) Token: 0x06001579 RID: 5497 RVA: 0x00104C18 File Offset: 0x00102E18
		Friend Overridable Property btnEx As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnEx
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnEx IsNot Nothing
				If flag Then
					RemoveHandler Me._btnEx.Click, AddressOf Me.btnEx_Click
				End If
				Me._btnEx = value
				flag = Me._btnEx IsNot Nothing
				If flag Then
					AddHandler Me._btnEx.Click, AddressOf Me.btnEx_Click
				End If
			End Set
		End Property

		' Token: 0x1700077A RID: 1914
		' (get) Token: 0x0600157A RID: 5498 RVA: 0x00104C84 File Offset: 0x00102E84
		' (set) Token: 0x0600157B RID: 5499 RVA: 0x00104C9C File Offset: 0x00102E9C
		Friend Overridable Property btnIm As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnIm
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnIm IsNot Nothing
				If flag Then
					RemoveHandler Me._btnIm.Click, AddressOf Me.btnIm_Click
				End If
				Me._btnIm = value
				flag = Me._btnIm IsNot Nothing
				If flag Then
					AddHandler Me._btnIm.Click, AddressOf Me.btnIm_Click
				End If
			End Set
		End Property

		' Token: 0x1700077B RID: 1915
		' (get) Token: 0x0600157C RID: 5500 RVA: 0x00104D08 File Offset: 0x00102F08
		' (set) Token: 0x0600157D RID: 5501 RVA: 0x00104D20 File Offset: 0x00102F20
		Friend Overridable Property btnSendData As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSendData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSendData IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSendData.Click, AddressOf Me.btnSendData_Click
				End If
				Me._btnSendData = value
				flag = Me._btnSendData IsNot Nothing
				If flag Then
					AddHandler Me._btnSendData.Click, AddressOf Me.btnSendData_Click
				End If
			End Set
		End Property

		' Token: 0x1700077C RID: 1916
		' (get) Token: 0x0600157E RID: 5502 RVA: 0x00104D8C File Offset: 0x00102F8C
		' (set) Token: 0x0600157F RID: 5503 RVA: 0x00104DA4 File Offset: 0x00102FA4
		Friend Overridable Property btnAddDefault2 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault2 IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault2.Click, AddressOf Me.btnAddDefault2_Click
				End If
				Me._btnAddDefault2 = value
				flag = Me._btnAddDefault2 IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault2.Click, AddressOf Me.btnAddDefault2_Click
				End If
			End Set
		End Property

		' Token: 0x1700077D RID: 1917
		' (get) Token: 0x06001580 RID: 5504 RVA: 0x00104E10 File Offset: 0x00103010
		' (set) Token: 0x06001581 RID: 5505 RVA: 0x00104E28 File Offset: 0x00103028
		Friend Overridable Property txtLoc As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtLoc
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtLoc IsNot Nothing
				If flag Then
					RemoveHandler Me._txtLoc.KeyPress, AddressOf Me.txtLoc_KeyPress
					RemoveHandler Me._txtLoc.GotFocus, AddressOf Me.txtLoc_GotFocus
				End If
				Me._txtLoc = value
				flag = Me._txtLoc IsNot Nothing
				If flag Then
					AddHandler Me._txtLoc.KeyPress, AddressOf Me.txtLoc_KeyPress
					AddHandler Me._txtLoc.GotFocus, AddressOf Me.txtLoc_GotFocus
				End If
			End Set
		End Property

		' Token: 0x1700077E RID: 1918
		' (get) Token: 0x06001582 RID: 5506 RVA: 0x00104EC4 File Offset: 0x001030C4
		' (set) Token: 0x06001583 RID: 5507 RVA: 0x000052EE File Offset: 0x000034EE
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x1700077F RID: 1919
		' (get) Token: 0x06001584 RID: 5508 RVA: 0x00104EDC File Offset: 0x001030DC
		' (set) Token: 0x06001585 RID: 5509 RVA: 0x00104EF4 File Offset: 0x001030F4
		Friend Overridable Property cboSLIn As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cboSLIn
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cboSLIn IsNot Nothing
				If flag Then
					RemoveHandler Me._cboSLIn.SelectedIndexChanged, AddressOf Me.cboSLIn_SelectedIndexChanged
					RemoveHandler Me._cboSLIn.GotFocus, AddressOf Me.cboSLIn_GotFocus
				End If
				Me._cboSLIn = value
				flag = Me._cboSLIn IsNot Nothing
				If flag Then
					AddHandler Me._cboSLIn.SelectedIndexChanged, AddressOf Me.cboSLIn_SelectedIndexChanged
					AddHandler Me._cboSLIn.GotFocus, AddressOf Me.cboSLIn_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000780 RID: 1920
		' (get) Token: 0x06001586 RID: 5510 RVA: 0x00104F90 File Offset: 0x00103190
		' (set) Token: 0x06001587 RID: 5511 RVA: 0x00104FA8 File Offset: 0x001031A8
		Friend Overridable Property txtSLIn As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtSLIn
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtSLIn IsNot Nothing
				If flag Then
					RemoveHandler Me._txtSLIn.KeyPress, AddressOf Me.txtSLIn_KeyPress
					RemoveHandler Me._txtSLIn.TextChanged, AddressOf Me.txtOBJIDNH_TextChanged
				End If
				Me._txtSLIn = value
				flag = Me._txtSLIn IsNot Nothing
				If flag Then
					AddHandler Me._txtSLIn.KeyPress, AddressOf Me.txtSLIn_KeyPress
					AddHandler Me._txtSLIn.TextChanged, AddressOf Me.txtOBJIDNH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000781 RID: 1921
		' (get) Token: 0x06001588 RID: 5512 RVA: 0x00105044 File Offset: 0x00103244
		' (set) Token: 0x06001589 RID: 5513 RVA: 0x000052F8 File Offset: 0x000034F8
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000782 RID: 1922
		' (get) Token: 0x0600158A RID: 5514 RVA: 0x0010505C File Offset: 0x0010325C
		' (set) Token: 0x0600158B RID: 5515 RVA: 0x00105074 File Offset: 0x00103274
		Friend Overridable Property btnSLIn As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSLIn
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSLIn IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSLIn.Click, AddressOf Me.btnSLIn_Click
				End If
				Me._btnSLIn = value
				flag = Me._btnSLIn IsNot Nothing
				If flag Then
					AddHandler Me._btnSLIn.Click, AddressOf Me.btnSLIn_Click
				End If
			End Set
		End Property

		' Token: 0x17000783 RID: 1923
		' (get) Token: 0x0600158C RID: 5516 RVA: 0x001050E0 File Offset: 0x001032E0
		' (set) Token: 0x0600158D RID: 5517 RVA: 0x00005302 File Offset: 0x00003502
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x17000784 RID: 1924
		' (get) Token: 0x0600158E RID: 5518 RVA: 0x001050F8 File Offset: 0x001032F8
		' (set) Token: 0x0600158F RID: 5519 RVA: 0x00105110 File Offset: 0x00103310
		Friend Overridable Property btnSelAll As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelAll IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelAll.Click, AddressOf Me.btnSelAll_Click
				End If
				Me._btnSelAll = value
				flag = Me._btnSelAll IsNot Nothing
				If flag Then
					AddHandler Me._btnSelAll.Click, AddressOf Me.btnSelAll_Click
				End If
			End Set
		End Property

		' Token: 0x17000785 RID: 1925
		' (get) Token: 0x06001590 RID: 5520 RVA: 0x0010517C File Offset: 0x0010337C
		' (set) Token: 0x06001591 RID: 5521 RVA: 0x00105194 File Offset: 0x00103394
		Friend Overridable Property btnUnSelAll As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnUnSelAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnUnSelAll IsNot Nothing
				If flag Then
					RemoveHandler Me._btnUnSelAll.Click, AddressOf Me.btnUnSelAll_Click
				End If
				Me._btnUnSelAll = value
				flag = Me._btnUnSelAll IsNot Nothing
				If flag Then
					AddHandler Me._btnUnSelAll.Click, AddressOf Me.btnUnSelAll_Click
				End If
			End Set
		End Property

		' Token: 0x17000786 RID: 1926
		' (get) Token: 0x06001592 RID: 5522 RVA: 0x00105200 File Offset: 0x00103400
		' (set) Token: 0x06001593 RID: 5523 RVA: 0x0000530C File Offset: 0x0000350C
		Friend Overridable Property ToolTip1 As ToolTip
			<DebuggerNonUserCode()>
			Get
				Return Me._ToolTip1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolTip)
				Me._ToolTip1 = value
			End Set
		End Property

		' Token: 0x17000787 RID: 1927
		' (get) Token: 0x06001594 RID: 5524 RVA: 0x00105218 File Offset: 0x00103418
		' (set) Token: 0x06001595 RID: 5525 RVA: 0x00005316 File Offset: 0x00003516
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x17000788 RID: 1928
		' (get) Token: 0x06001596 RID: 5526 RVA: 0x00105230 File Offset: 0x00103430
		' (set) Token: 0x06001597 RID: 5527 RVA: 0x00005320 File Offset: 0x00003520
		Friend Overridable Property txtTongSLIn As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTongSLIn
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTongSLIn = value
			End Set
		End Property

		' Token: 0x17000789 RID: 1929
		' (get) Token: 0x06001598 RID: 5528 RVA: 0x00105248 File Offset: 0x00103448
		' (set) Token: 0x06001599 RID: 5529 RVA: 0x00105260 File Offset: 0x00103460
		Friend Overridable Property btnPrintBarcode As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrintBarcode
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrintBarcode IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrintBarcode.Click, AddressOf Me.btnPrintBarcode_Click
				End If
				Me._btnPrintBarcode = value
				flag = Me._btnPrintBarcode IsNot Nothing
				If flag Then
					AddHandler Me._btnPrintBarcode.Click, AddressOf Me.btnPrintBarcode_Click
				End If
			End Set
		End Property

		' Token: 0x1700078A RID: 1930
		' (get) Token: 0x0600159A RID: 5530 RVA: 0x001052CC File Offset: 0x001034CC
		' (set) Token: 0x0600159B RID: 5531 RVA: 0x001052E4 File Offset: 0x001034E4
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x1700078B RID: 1931
		' (get) Token: 0x0600159C RID: 5532 RVA: 0x00105350 File Offset: 0x00103550
		' (set) Token: 0x0600159D RID: 5533 RVA: 0x0000532A File Offset: 0x0000352A
		Public Property pBlnSelect As Boolean
			Get
				Return Me.mBlnSelect
			End Get
			Set(value As Boolean)
				Me.mBlnSelect = value
			End Set
		End Property

		' Token: 0x1700078C RID: 1932
		' (get) Token: 0x0600159E RID: 5534 RVA: 0x00105368 File Offset: 0x00103568
		' (set) Token: 0x0600159F RID: 5535 RVA: 0x00005335 File Offset: 0x00003535
		Public Property pArrOBJID As String()
			Get
				Return Me.mArrOBJID
			End Get
			Set(value As String())
				Me.mArrOBJID = value
			End Set
		End Property

		' Token: 0x1700078D RID: 1933
		' (get) Token: 0x060015A0 RID: 5536 RVA: 0x00105380 File Offset: 0x00103580
		' (set) Token: 0x060015A1 RID: 5537 RVA: 0x00005340 File Offset: 0x00003540
		Public Property pArrOBJNAME As String()
			Get
				Return Me.mArrOBJNAME
			End Get
			Set(value As String())
				Me.mArrOBJNAME = value
			End Set
		End Property

		' Token: 0x1700078E RID: 1934
		' (get) Token: 0x060015A2 RID: 5538 RVA: 0x00105398 File Offset: 0x00103598
		' (set) Token: 0x060015A3 RID: 5539 RVA: 0x0000534B File Offset: 0x0000354B
		Public Property pbytImage As Byte()
			Get
				Return Me.mbytImage
			End Get
			Set(value As Byte())
				Me.mbytImage = value
			End Set
		End Property

		' Token: 0x1700078F RID: 1935
		' (get) Token: 0x060015A4 RID: 5540 RVA: 0x001053B0 File Offset: 0x001035B0
		' (set) Token: 0x060015A5 RID: 5541 RVA: 0x00005356 File Offset: 0x00003556
		Public Property parrDblPrice As Double()
			Get
				Return Me.marrDblPrice
			End Get
			Set(value As Double())
				Me.marrDblPrice = value
			End Set
		End Property

		' Token: 0x17000790 RID: 1936
		' (get) Token: 0x060015A6 RID: 5542 RVA: 0x001053C8 File Offset: 0x001035C8
		' (set) Token: 0x060015A7 RID: 5543 RVA: 0x00005361 File Offset: 0x00003561
		Public Property pbytRATE As Byte
			Get
				Return Me.mbytRATE
			End Get
			Set(value As Byte)
				Me.mbytRATE = value
			End Set
		End Property

		' Token: 0x17000791 RID: 1937
		' (get) Token: 0x060015A8 RID: 5544 RVA: 0x001053E0 File Offset: 0x001035E0
		' (set) Token: 0x060015A9 RID: 5545 RVA: 0x0000536C File Offset: 0x0000356C
		Public Property pblnLSAVE As Boolean
			Get
				Return Me.mblnLSAVE
			End Get
			Set(value As Boolean)
				Me.mblnLSAVE = value
			End Set
		End Property

		' Token: 0x17000792 RID: 1938
		' (get) Token: 0x060015AA RID: 5546 RVA: 0x001053F8 File Offset: 0x001035F8
		' (set) Token: 0x060015AB RID: 5547 RVA: 0x00005377 File Offset: 0x00003577
		Public Property pStrPRICE1 As String
			Get
				Return Me.mStrPRICE1
			End Get
			Set(value As String)
				Me.mStrPRICE1 = value
			End Set
		End Property

		' Token: 0x17000793 RID: 1939
		' (get) Token: 0x060015AC RID: 5548 RVA: 0x00105410 File Offset: 0x00103610
		' (set) Token: 0x060015AD RID: 5549 RVA: 0x00005382 File Offset: 0x00003582
		Public Property pStrTENDVT As String
			Get
				Return Me.mStrTENDVT
			End Get
			Set(value As String)
				Me.mStrTENDVT = value
			End Set
		End Property

		' Token: 0x17000794 RID: 1940
		' (get) Token: 0x060015AE RID: 5550 RVA: 0x00105428 File Offset: 0x00103628
		' (set) Token: 0x060015AF RID: 5551 RVA: 0x0000538D File Offset: 0x0000358D
		Public Property pStrDVT As String
			Get
				Return Me.mStrMADVT
			End Get
			Set(value As String)
				Me.mStrMADVT = value
			End Set
		End Property

		' Token: 0x17000795 RID: 1941
		' (get) Token: 0x060015B0 RID: 5552 RVA: 0x00105440 File Offset: 0x00103640
		' (set) Token: 0x060015B1 RID: 5553 RVA: 0x00005398 File Offset: 0x00003598
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x17000796 RID: 1942
		' (get) Token: 0x060015B2 RID: 5554 RVA: 0x00105458 File Offset: 0x00103658
		' (set) Token: 0x060015B3 RID: 5555 RVA: 0x000053A3 File Offset: 0x000035A3
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x17000797 RID: 1943
		' (get) Token: 0x060015B4 RID: 5556 RVA: 0x00105470 File Offset: 0x00103670
		' (set) Token: 0x060015B5 RID: 5557 RVA: 0x000053AE File Offset: 0x000035AE
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000798 RID: 1944
		' (get) Token: 0x060015B6 RID: 5558 RVA: 0x00105488 File Offset: 0x00103688
		' (set) Token: 0x060015B7 RID: 5559 RVA: 0x000053B9 File Offset: 0x000035B9
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060015B8 RID: 5560 RVA: 0x001054A0 File Offset: 0x001036A0
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim text As String = ""
				Try
					For Each keyValuePair As KeyValuePair(Of String, Integer) In Me.dicSelected
						text += keyValuePair.Key.Trim()
					Next
				Finally
					Dim enumerator As Dictionary(Of String, Integer).Enumerator
					CType(enumerator, IDisposable).Dispose()
				End Try
				Dim dataGridViewRow As DataGridViewRow = Nothing
				Dim flag As Boolean = text.Trim().Length > 0
				If flag Then
					Dim dgvData As DataGridView = Me.dgvData
					Dim dataGridViewRow2 As DataGridViewRow = Me.fFindRowDataGrid(dgvData, text.Trim())
					Me.dgvData = dgvData
					dataGridViewRow = dataGridViewRow2
				End If
				flag = dataGridViewRow Is Nothing
				If Not flag Then
					Me.mStrOBJID = Conversions.ToString(dataGridViewRow.Cells("OBJID").Value)
					Me.mStrOBJNAME = dataGridViewRow.Cells("OBJNAME").Value.ToString().Trim() + "  " + dataGridViewRow.Cells("SUBOBJNAME").Value.ToString().Trim()
					Me.mStrMADVT = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADVT").Value, ""))
					Me.mStrTENDVT = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENDVT").Value, ""))
					Me.mStrPRICE1 = Conversions.ToString(dataGridViewRow.Cells("PRICE1").Value)
					Me.mblnLSAVE = Conversions.ToBoolean(dataGridViewRow.Cells("LSAVE").Value)
					Me.mbytRATE = CByte(Math.Round(Conversion.Val(Operators.ConcatenateObject(dataGridViewRow.Cells("RATE").Value, ""))))
					Dim b As Byte = 0
					Dim b2 As Byte
					Dim b3 As Byte
					Do
						Me.marrDblPrice(CInt(b)) = Conversion.Val(Strings.Replace(Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE" + CInt((b + 1)).ToString()).Value, "")), ",", "", 1, -1, CompareMethod.Binary))

							b += 1
							b2 = b
							b3 = 9

					Loop While b2 <= b3
					Array.Resize(Of String)(Me.mArrOBJID, Me.dicSelected.Keys.Count)
					Array.Resize(Of String)(Me.mArrOBJNAME, Me.dicSelected.Keys.Count)
					Dim num As Integer = 0
					Try
						For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
							Dim dataGridViewRow3 As DataGridViewRow = CType(obj, DataGridViewRow)
							flag = Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow3.Cells("QTYIN").Value)) <= 0.0
							If Not flag Then
								Me.mArrOBJID(num) = dataGridViewRow3.Cells("OBJID").Value.ToString()
								Me.mArrOBJNAME(num) = dataGridViewRow3.Cells("OBJNAME").Value.ToString()
								num += 1
							End If
						Next
					Finally
						Dim enumerator2 As IEnumerator
						flag = TypeOf enumerator2 Is IDisposable
						If flag Then
							TryCast(enumerator2, IDisposable).Dispose()
						End If
					End Try
					Me.mBlnSelect = True
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015B9 RID: 5561 RVA: 0x001058DC File Offset: 0x00103ADC
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015BA RID: 5562 RVA: 0x001059AC File Offset: 0x00103BAC
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015BB RID: 5563 RVA: 0x00105A9C File Offset: 0x00103C9C
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015BC RID: 5564 RVA: 0x00105B80 File Offset: 0x00103D80
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015BD RID: 5565 RVA: 0x00105C44 File Offset: 0x00103E44
		Private Sub btnSelectNH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMNH As frmDMNH1 = New frmDMNH1()
				frmDMNH.pBytOpen_From_Menu = 7
				frmDMNH.ShowDialog()
				Me.txtOBJIDNH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNH.pStrOBJID, "", False) = 0, Me.txtOBJIDNH.Text, frmDMNH.pStrOBJID))
				frmDMNH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelectNH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015BE RID: 5566 RVA: 0x00105D2C File Offset: 0x00103F2C
		Private Sub txtSLIn_KeyPress(sender As Object, e As KeyPressEventArgs)
			Select Case Strings.Asc(e.KeyChar)
				Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
					Return
				Case 13
					Me.dgvData.Focus()
					Return
			End Select
			e.Handled = True
		End Sub

		' Token: 0x060015BF RID: 5567 RVA: 0x00105E48 File Offset: 0x00104048
		Private Sub txtOBJIDNH_GotFocus(sender As Object, e As EventArgs)
			Try
				Me.txtLoc.Text = ""
				Me.cboSLIn.SelectedIndex = 0
				Me.txtOBJIDNH.Focus()
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060015C0 RID: 5568 RVA: 0x00105EA4 File Offset: 0x001040A4
		Private Sub txtOBJIDNH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMNH Is Nothing
				If Not flag Then
					Me.btnCancelFilter.Visible = False
					array(0) = Me.mclsTbDMNH.Columns("OBJID")
					Me.mclsTbDMNH.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMNH.Rows.Find(Strings.Trim(Me.txtOBJIDNH.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtOBJNAMENH.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtOBJNAMENH.Text = ""
					End If
					Me.sLocDuLieu()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJIDNH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015C1 RID: 5569 RVA: 0x0010600C File Offset: 0x0010420C
		Private Sub frmDMHH1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHH1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015C2 RID: 5570 RVA: 0x001060A4 File Offset: 0x001042A4
		Private Sub frmDMHH1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Filter()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
				Me.btnAddDefault2.Visible = Me.btnAddDefault.Visible
				Me.cboSLIn.Items.Add(Me.mArrStrFrmMess(50))
				Me.cboSLIn.Items.Add(Me.mArrStrFrmMess(51))
				Me.cboSLIn.Items.Add(Me.mArrStrFrmMess(52))
				Me.cboSLIn.SelectedIndex = 0
				Me.sGetPara_From_SetparaXML()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHH1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015C3 RID: 5571 RVA: 0x0010626C File Offset: 0x0010446C
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015C4 RID: 5572 RVA: 0x00106374 File Offset: 0x00104574
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.mBlnSelect = False
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015C5 RID: 5573 RVA: 0x00106414 File Offset: 0x00104614
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMHH As frmDMHH2 = New frmDMHH2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMHH.pbytFromStatus = 1
				frmDMHH.chkLSAVE.Checked = True
				frmDMHH.grbTONKHO.Visible = True
				frmDMHH.txtTiLeDVT.Text = "1"
				Dim flag As Boolean = Me.mblnAutoAdd_DMHH
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHH_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMHH.txtOBJID.Text = Strings.Right("0000000000000000" + array(0).Value.ToString(), CInt(Me.mbytLen_OBJID))
						frmDMHH.txtOBJID.[ReadOnly] = True
						frmDMHH.txtOBJID.BackColor = frmDMHH.txtTENNH.BackColor
					End If
				End If
				frmDMHH.ShowDialog()
				flag = frmDMHH.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMHH.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMHH.Dispose()
			End Try
		End Sub

		' Token: 0x060015C6 RID: 5574 RVA: 0x00106680 File Offset: 0x00104880
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMHH As frmDMHH2 = New frmDMHH2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim text As String = ""
				Try
					For Each keyValuePair As KeyValuePair(Of String, Integer) In Me.dicSelected
						text += keyValuePair.Key.Trim()
					Next
				Finally
					Dim enumerator As Dictionary(Of String, Integer).Enumerator
					CType(enumerator, IDisposable).Dispose()
				End Try
				Dim dataGridViewRow As DataGridViewRow = Nothing
				Dim flag As Boolean = text.Trim().Length > 0
				If flag Then
					Dim dgvData As DataGridView = Me.dgvData
					Dim dataGridViewRow2 As DataGridViewRow = Me.fFindRowDataGrid(dgvData, text.Trim())
					Me.dgvData = dgvData
					dataGridViewRow = dataGridViewRow2
				End If
				flag = dataGridViewRow Is Nothing
				If flag Then
					dataGridViewRow = Me.dgvData.CurrentRow
				End If
				flag = dataGridViewRow Is Nothing
				If Not flag Then
					Dim frmDMHH2 As frmDMHH2 = frmDMHH
					frmDMHH2.pbytFromStatus = 2
					frmDMHH2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("OBJID").Value, ""))
					frmDMHH2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("OBJNAME").Value, ""))
					frmDMHH2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("SUBOBJNAME").Value, ""))
					frmDMHH2.txtMADVT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADVT").Value, ""))
					frmDMHH2.txtMADV.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADV").Value, ""))
					frmDMHH2.txtMAMT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMT").Value, ""))
					frmDMHH2.txtMAMT2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMT2").Value, ""))
					frmDMHH2.txtMAPL.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAPL").Value, ""))
					frmDMHH2.txtMANSX.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MANSX").Value, ""))
					frmDMHH2.txtTENMT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENTHUE").Value, ""))
					frmDMHH2.txtTENMT2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENTHUE2").Value, ""))
					frmDMHH2.txtMANH.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MANH").Value, ""))
					frmDMHH2.txtTENNH.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENNH").Value, ""))
					frmDMHH2.txtTENPL.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENPL").Value, ""))
					frmDMHH2.txtTENNSX.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENNSX").Value, ""))
					frmDMHH2.txtPRICE.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE1").Value, ""))
					frmDMHH2.txtPRICE2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE2").Value, ""))
					frmDMHH2.txtPRICE3.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE3").Value, ""))
					frmDMHH2.txtPRICE4.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE4").Value, ""))
					frmDMHH2.txtPRICE5.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE5").Value, ""))
					frmDMHH2.txtPRICE6.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE6").Value, ""))
					frmDMHH2.txtPRICE7.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE7").Value, ""))
					frmDMHH2.txtPRICE8.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE8").Value, ""))
					frmDMHH2.txtPRICE9.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE9").Value, ""))
					frmDMHH2.txtPRICE10.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE10").Value, ""))
					frmDMHH2.txtPURSE.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PURSE").Value, ""))
					frmDMHH2.txtMADVTDG.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADVTDG").Value, ""))
					frmDMHH2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("REMARK").Value, ""))
					frmDMHH2.txtbep1.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP1").Value, ""))
					frmDMHH2.txtbep2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP2").Value, ""))
					frmDMHH2.txtbep3.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP3").Value, ""))
					frmDMHH2.chkLSAVE.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSAVE").Value)
					frmDMHH2.chkLopen.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LOPEN").Value)
					frmDMHH2.chkLMATERIAL.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LHIDEN").Value)
					frmDMHH2.chkStopUse.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSTOPUSE").Value)
					frmDMHH2.chkCOMBO.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LCOMBO").Value)
					frmDMHH2.txtCOMBO.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("COMBO").Value, ""))
					frmDMHH2.chkLSETCOMBO.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSETCOMBO").Value)
					frmDMHH2.chkLTON_KHACHHANG.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LTON_KHACHHANG").Value)
					frmDMHH2.grbTONKHO.Visible = True
					frmDMHH2.txtbep4.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP4").Value, ""))
					frmDMHH2.txtbep5.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP5").Value, ""))
					frmDMHH2.txtbep6.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP6").Value, ""))
					frmDMHH2.chkLComboPrice.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LCOMBOPRICE").Value)
					frmDMHH2.txtTHOIKHOANG.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("THOIKHOANG").Value, ""))
					frmDMHH2.txtTienHoaHong.Text = mdlUIForm.gfFormatNumber(Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("HOAHONG").Value)), CShort(mdlVariable.gbytDECNUMAMT), ",")
					Dim num As Double = Conversion.Val(frmDMHH2.txtPRICE.Text.Replace(",", ""))
					Dim num2 As Double = Conversion.Val(frmDMHH2.txtTienHoaHong.Text.Replace(",", ""))
					Dim num3 As Double = num2 * 100.0 / num
					frmDMHH2.txtHOAHONG.Text = mdlUIForm.gfFormatNumber(num3, 3S, ",")
					frmDMHH2.txtTiLeDVT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TILEDVT").Value, ""))
					frmDMHH2.txtScore.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("SCORE").Value, ""))
					frmDMHH2.chkLQTYMain.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LQTYMain").Value)
					frmDMHH2.chkLAmtOpen.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LAMTOPEN").Value)
					frmDMHH2.chkLSerial.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSERIAL").Value)
					frmDMHH2.pstrMaHH_Copy = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("OBJID").Value, ""))
					frmDMHH2.chkLQtyLe.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LQTYLE").Value)
					flag = Me.mblnAutoAdd_DMHH
					If flag Then
						array(0) = sqlCommand.CreateParameter()
						array(0).ParameterName = "@pintResult"
						array(0).Direction = ParameterDirection.ReturnValue
						Dim flag2 As Boolean
						clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHH_GET_MAX_OBJID", flag2)
						flag = flag2
						If flag Then
							frmDMHH.txtOBJID.Text = Strings.Right("0000000000000000" + array(0).Value.ToString(), CInt(Me.mbytLen_OBJID))
							frmDMHH.txtOBJID.[ReadOnly] = True
							frmDMHH.txtOBJID.BackColor = frmDMHH.txtTENNH.BackColor
						End If
					End If
					frmDMHH.ShowDialog()
					flag = frmDMHH.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMHH.pStrFilter)
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
						Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAddDefault_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				array = Nothing
				clsConnect.Dispose()
				frmDMHH.Dispose()
			End Try
		End Sub

		' Token: 0x060015C7 RID: 5575 RVA: 0x001073C8 File Offset: 0x001055C8
		Private Sub btnAddDefault2_Click(sender As Object, e As EventArgs)
			Dim frmDMHH As frmDMHH2 = New frmDMHH2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim text As String = ""
				Try
					For Each keyValuePair As KeyValuePair(Of String, Integer) In Me.dicSelected
						text += keyValuePair.Key.Trim()
					Next
				Finally
					Dim enumerator As Dictionary(Of String, Integer).Enumerator
					CType(enumerator, IDisposable).Dispose()
				End Try
				Dim dataGridViewRow As DataGridViewRow = Nothing
				Dim flag As Boolean = text.Trim().Length > 0
				If flag Then
					Dim dgvData As DataGridView = Me.dgvData
					Dim dataGridViewRow2 As DataGridViewRow = Me.fFindRowDataGrid(dgvData, text.Trim())
					Me.dgvData = dgvData
					dataGridViewRow = dataGridViewRow2
				End If
				flag = dataGridViewRow Is Nothing
				If Not flag Then
					Dim frmDMHH2 As frmDMHH2 = frmDMHH
					frmDMHH2.pbytFromStatus = 2
					frmDMHH2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("OBJID").Value, ""))
					frmDMHH2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("OBJNAME").Value, ""))
					frmDMHH2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("SUBOBJNAME").Value, ""))
					frmDMHH2.txtMADVT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADVT").Value, ""))
					frmDMHH2.txtMADV.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADV").Value, ""))
					frmDMHH2.txtMAMT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMT").Value, ""))
					frmDMHH2.txtMAMT2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMT2").Value, ""))
					frmDMHH2.txtMAPL.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAPL").Value, ""))
					frmDMHH2.txtMANSX.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MANSX").Value, ""))
					frmDMHH2.txtTENMT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENTHUE").Value, ""))
					frmDMHH2.txtTENMT2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENTHUE2").Value, ""))
					frmDMHH2.txtMANH.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MANH").Value, ""))
					frmDMHH2.txtTENNH.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENNH").Value, ""))
					frmDMHH2.txtTENPL.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENPL").Value, ""))
					frmDMHH2.txtTENNSX.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENNSX").Value, ""))
					frmDMHH2.txtPRICE.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE1").Value, ""))
					frmDMHH2.txtPRICE2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE2").Value, ""))
					frmDMHH2.txtPRICE3.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE3").Value, ""))
					frmDMHH2.txtPRICE4.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE4").Value, ""))
					frmDMHH2.txtPRICE5.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE5").Value, ""))
					frmDMHH2.txtPRICE6.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE6").Value, ""))
					frmDMHH2.txtPRICE7.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE7").Value, ""))
					frmDMHH2.txtPRICE8.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE8").Value, ""))
					frmDMHH2.txtPRICE9.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE9").Value, ""))
					frmDMHH2.txtPRICE10.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE10").Value, ""))
					frmDMHH2.txtPURSE.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PURSE").Value, ""))
					frmDMHH2.txtMADVTDG.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADVTDG").Value, ""))
					frmDMHH2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("REMARK").Value, ""))
					frmDMHH2.txtbep1.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP1").Value, ""))
					frmDMHH2.txtbep2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP2").Value, ""))
					frmDMHH2.txtbep3.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP3").Value, ""))
					frmDMHH2.chkLSAVE.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSAVE").Value)
					frmDMHH2.chkLopen.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LOPEN").Value)
					frmDMHH2.chkLMATERIAL.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LHIDEN").Value)
					frmDMHH2.chkStopUse.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSTOPUSE").Value)
					frmDMHH2.chkCOMBO.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LCOMBO").Value)
					frmDMHH2.txtCOMBO.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("COMBO").Value, ""))
					frmDMHH2.chkLSETCOMBO.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSETCOMBO").Value)
					frmDMHH2.chkLTON_KHACHHANG.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LTON_KHACHHANG").Value)
					frmDMHH2.grbTONKHO.Visible = True
					frmDMHH2.txtbep4.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP4").Value, ""))
					frmDMHH2.txtbep5.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP5").Value, ""))
					frmDMHH2.txtbep6.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP6").Value, ""))
					frmDMHH2.chkLComboPrice.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LCOMBOPRICE").Value)
					frmDMHH2.txtTHOIKHOANG.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("THOIKHOANG").Value, ""))
					frmDMHH2.txtTienHoaHong.Text = mdlUIForm.gfFormatNumber(Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("HOAHONG").Value)), CShort(mdlVariable.gbytDECNUMAMT), ",")
					Dim num As Double = Conversion.Val(frmDMHH2.txtPRICE.Text.Replace(",", ""))
					Dim num2 As Double = Conversion.Val(frmDMHH2.txtTienHoaHong.Text.Replace(",", ""))
					Dim num3 As Double = num2 * 100.0 / num
					frmDMHH2.txtHOAHONG.Text = mdlUIForm.gfFormatNumber(num3, 3S, ",")
					frmDMHH2.txtTiLeDVT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TILEDVT").Value, ""))
					frmDMHH2.txtScore.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("SCORE").Value, ""))
					frmDMHH2.chkLQTYMain.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LQTYMain").Value)
					frmDMHH2.chkLAmtOpen.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LAMTOPEN").Value)
					frmDMHH2.chkLSerial.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSERIAL").Value)
					frmDMHH2.pstrMaHH_Copy = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("OBJID").Value, ""))
					frmDMHH2.chkLQtyLe.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LQTYLE").Value)
					flag = Not Me.mblnAutoAdd_DMHH
					If flag Then
						frmDMHH2.lblOBJID_2.Visible = True
						frmDMHH2.txtOBJID_2.Visible = True
						frmDMHH2.txtOBJID_2.Text = frmDMHH2.txtOBJID.Text
						frmDMHH2.lblBuocNhayGia.Visible = True
						frmDMHH2.txtBuocNhayGia.Visible = True
						frmDMHH2.lblBuocNhayMa.Visible = True
						frmDMHH2.txtBuocNhayMa.Visible = True
						frmDMHH2.txtBuocNhayMa.Text = Conversions.ToString(1)
					End If
					flag = Me.mblnAutoAdd_DMHH
					If flag Then
						array(0) = sqlCommand.CreateParameter()
						array(0).ParameterName = "@pintResult"
						array(0).Direction = ParameterDirection.ReturnValue
						Dim flag2 As Boolean
						clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHH_GET_MAX_OBJID", flag2)
						flag = flag2
						If flag Then
							frmDMHH.txtOBJID.Text = Strings.Right("0000000000000000" + array(0).Value.ToString(), CInt(Me.mbytLen_OBJID))
							frmDMHH.txtOBJID.[ReadOnly] = True
							frmDMHH.txtOBJID.BackColor = frmDMHH.txtTENNH.BackColor
						End If
					End If
					frmDMHH.ShowDialog()
					flag = frmDMHH.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMHH.pStrFilter)
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAddDefault2_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				array = Nothing
				clsConnect.Dispose()
				frmDMHH.Dispose()
			End Try
		End Sub

		' Token: 0x060015C8 RID: 5576 RVA: 0x0010817C File Offset: 0x0010637C
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMHH As frmDMHH2 = New frmDMHH2()
			Try
				Dim flag As Boolean = Me.dicSelected.Keys.Count > 1
				If flag Then
					Dim text As String = ""
					Try
						For Each keyValuePair As KeyValuePair(Of String, Integer) In Me.dicSelected
							text = text + keyValuePair.Key.Trim() + ";"
						Next
					Finally
						Dim enumerator As Dictionary(Of String, Integer).Enumerator
						CType(enumerator, IDisposable).Dispose()
					End Try
					flag = text.Trim().Length > 0 AndAlso text.Trim().EndsWith(";")
					If flag Then
						' The following expression was wrapped in a checked-expression
						text = text.Trim().Substring(0, text.Trim().Length - 1)
						Dim frmDMHH2 As frmDMHH2 = frmDMHH
						frmDMHH2.pbytFromStatus = 3
						frmDMHH2.txtOBJID.Text = text
						frmDMHH2.txtOBJNAME.Text = ""
						frmDMHH2.txtSUBOBJNAME.Text = ""
						frmDMHH2.txtMADVT.Text = ""
						frmDMHH2.txtMADV.Text = ""
						frmDMHH2.txtMAMT.Text = ""
						frmDMHH2.txtMAMT2.Text = ""
						frmDMHH2.txtMAPL.Text = ""
						frmDMHH2.txtMANSX.Text = ""
						frmDMHH2.txtTENMT.Text = ""
						frmDMHH2.txtTENMT2.Text = ""
						frmDMHH2.txtMANH.Text = ""
						frmDMHH2.txtTENNH.Text = ""
						frmDMHH2.txtTENPL.Text = ""
						frmDMHH2.txtTENNSX.Text = ""
						frmDMHH2.txtPRICE.Text = ""
						frmDMHH2.txtPRICE2.Text = ""
						frmDMHH2.txtPRICE3.Text = ""
						frmDMHH2.txtPRICE4.Text = ""
						frmDMHH2.txtPRICE5.Text = ""
						frmDMHH2.txtPRICE6.Text = ""
						frmDMHH2.txtPRICE7.Text = ""
						frmDMHH2.txtPRICE8.Text = ""
						frmDMHH2.txtPRICE9.Text = ""
						frmDMHH2.txtPRICE10.Text = ""
						frmDMHH2.txtPURSE.Text = ""
						frmDMHH2.txtREMARK.Text = ""
						frmDMHH2.chkLSAVE.CheckState = CheckState.Indeterminate
						frmDMHH2.chkLopen.CheckState = CheckState.Indeterminate
						frmDMHH2.chkLMATERIAL.CheckState = CheckState.Indeterminate
						frmDMHH2.chkStopUse.CheckState = CheckState.Indeterminate
						frmDMHH2.chkCOMBO.CheckState = CheckState.Indeterminate
						frmDMHH2.txtMADVTDG.Text = ""
						frmDMHH2.txtbep1.Text = ""
						frmDMHH2.txtbep2.Text = ""
						frmDMHH2.txtbep3.Text = ""
						frmDMHH2.txtCOMBO.Text = ""
						frmDMHH2.chkLSETCOMBO.CheckState = CheckState.Indeterminate
						frmDMHH2.chkLTON_KHACHHANG.CheckState = CheckState.Indeterminate
						frmDMHH2.txtPhieu.Text = ""
						frmDMHH2.grbTONKHO.Visible = True
						frmDMHH2.txtbep4.Text = ""
						frmDMHH2.txtbep5.Text = ""
						frmDMHH2.txtbep6.Text = ""
						frmDMHH2.chkLComboPrice.CheckState = CheckState.Indeterminate
						frmDMHH2.txtTHOIKHOANG.Text = ""
						frmDMHH2.txtHOAHONG.Text = ""
						frmDMHH2.txtTiLeDVT.Text = ""
						frmDMHH2.txtScore.Text = ""
						frmDMHH2.chkLQTYMain.CheckState = CheckState.Indeterminate
						frmDMHH2.chkLAmtOpen.CheckState = CheckState.Indeterminate
						frmDMHH2.chkLSerial.CheckState = CheckState.Indeterminate
						frmDMHH2.chkLQtyLe.CheckState = CheckState.Indeterminate
						Try
							frmDMHH2.pstrUIMAGE = ""
						Catch ex As Exception
						End Try
						frmDMHH.pBlnModifyMulti = True
						frmDMHH.ShowDialog()
					End If
				Else
					Dim text2 As String = ""
					Try
						For Each keyValuePair2 As KeyValuePair(Of String, Integer) In Me.dicSelected
							text2 += keyValuePair2.Key.Trim()
						Next
					Finally
						Dim enumerator2 As Dictionary(Of String, Integer).Enumerator
						CType(enumerator2, IDisposable).Dispose()
					End Try
					Dim dataGridViewRow As DataGridViewRow = Nothing
					flag = text2.Trim().Length > 0
					If flag Then
						Dim dgvData As DataGridView = Me.dgvData
						Dim dataGridViewRow2 As DataGridViewRow = Me.fFindRowDataGrid(dgvData, text2.Trim())
						Me.dgvData = dgvData
						dataGridViewRow = dataGridViewRow2
					End If
					flag = dataGridViewRow Is Nothing
					If flag Then
						Return
					End If
					flag = Conversions.ToBoolean(dataGridViewRow.Cells("FIXED").Value)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
						frmDMHH.Dispose()
						Return
					End If
					Dim frmDMHH3 As frmDMHH2 = frmDMHH
					frmDMHH3.pbytFromStatus = 3
					frmDMHH3.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("OBJID").Value, ""))
					frmDMHH3.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("OBJNAME").Value, ""))
					frmDMHH3.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("SUBOBJNAME").Value, ""))
					frmDMHH3.txtMADVT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADVT").Value, ""))
					frmDMHH3.txtMADV.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADV").Value, ""))
					frmDMHH3.txtMAMT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMT").Value, ""))
					frmDMHH3.txtMAMT2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMT2").Value, ""))
					frmDMHH3.txtMAPL.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAPL").Value, ""))
					frmDMHH3.txtMANSX.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MANSX").Value, ""))
					frmDMHH3.txtTENMT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENTHUE").Value, ""))
					frmDMHH3.txtTENMT2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENTHUE2").Value, ""))
					frmDMHH3.txtMANH.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MANH").Value, ""))
					frmDMHH3.txtTENNH.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENNH").Value, ""))
					frmDMHH3.txtTENPL.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENPL").Value, ""))
					frmDMHH3.txtTENNSX.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TENNSX").Value, ""))
					frmDMHH3.txtPRICE.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE1").Value, ""))
					frmDMHH3.txtPRICE2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE2").Value, ""))
					frmDMHH3.txtPRICE3.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE3").Value, ""))
					frmDMHH3.txtPRICE4.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE4").Value, ""))
					frmDMHH3.txtPRICE5.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE5").Value, ""))
					frmDMHH3.txtPRICE6.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE6").Value, ""))
					frmDMHH3.txtPRICE7.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE7").Value, ""))
					frmDMHH3.txtPRICE8.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE8").Value, ""))
					frmDMHH3.txtPRICE9.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE9").Value, ""))
					frmDMHH3.txtPRICE10.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PRICE10").Value, ""))
					frmDMHH3.txtPURSE.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PURSE").Value, ""))
					frmDMHH3.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("REMARK").Value, ""))
					frmDMHH3.chkLSAVE.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSAVE").Value)
					frmDMHH3.chkLopen.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LOPEN").Value)
					frmDMHH3.chkLMATERIAL.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LHIDEN").Value)
					frmDMHH3.chkStopUse.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSTOPUSE").Value)
					frmDMHH3.chkCOMBO.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LCOMBO").Value)
					frmDMHH3.txtMADVTDG.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADVTDG").Value, ""))
					frmDMHH3.txtbep1.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP1").Value, ""))
					frmDMHH3.txtbep2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP2").Value, ""))
					frmDMHH3.txtbep3.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP3").Value, ""))
					frmDMHH3.txtCOMBO.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("COMBO").Value, ""))
					frmDMHH3.chkLSETCOMBO.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSETCOMBO").Value)
					frmDMHH3.chkLTON_KHACHHANG.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LTON_KHACHHANG").Value)
					frmDMHH3.txtPhieu.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("PHIEU").Value, ""))
					frmDMHH3.grbTONKHO.Visible = True
					frmDMHH3.txtbep4.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP4").Value, ""))
					frmDMHH3.txtbep5.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP5").Value, ""))
					frmDMHH3.txtbep6.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MAMAYINBEP6").Value, ""))
					frmDMHH3.chkLComboPrice.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LCOMBOPRICE").Value)
					frmDMHH3.txtTHOIKHOANG.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("THOIKHOANG").Value, ""))
					frmDMHH3.txtTienHoaHong.Text = mdlUIForm.gfFormatNumber(Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("HOAHONG").Value)), CShort(mdlVariable.gbytDECNUMAMT), ",")
					Dim num As Double = Conversion.Val(frmDMHH3.txtPRICE.Text.Replace(",", ""))
					Dim num2 As Double = Conversion.Val(frmDMHH3.txtTienHoaHong.Text.Replace(",", ""))
					Dim num3 As Double = num2 * 100.0 / num
					frmDMHH3.txtHOAHONG.Text = mdlUIForm.gfFormatNumber(num3, 3S, ",")
					frmDMHH3.txtTiLeDVT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("TILEDVT").Value, ""))
					frmDMHH3.txtScore.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("SCORE").Value, ""))
					frmDMHH3.chkLQTYMain.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LQTYMain").Value)
					frmDMHH3.chkLAmtOpen.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LAMTOPEN").Value)
					frmDMHH3.chkLSerial.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LSERIAL").Value)
					frmDMHH3.chkLQtyLe.Checked = Conversions.ToBoolean(dataGridViewRow.Cells("LQTYLE").Value)
					Try
						frmDMHH3.pstrUIMAGE = dataGridViewRow.Cells("UIMAGE").Value.ToString().Trim()
						frmDMHH3.picAnh.BackgroundImage = Image.FromFile(dataGridViewRow.Cells("UIMAGE").Value.ToString().Trim())
					Catch ex2 As Exception
					End Try
					frmDMHH.ShowDialog()
					flag = frmDMHH.pbytSuccess = 0
					If flag Then
						Return
					End If
				End If
				Dim b As Byte = Me.fGetData_4Grid()
				flag = b = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMHH.pStrFilter)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex3 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex3.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMHH.Dispose()
			End Try
		End Sub

		' Token: 0x060015C9 RID: 5577 RVA: 0x00109344 File Offset: 0x00107544
		Private Function fFindRowDataGrid(ByRef dgv As DataGridView, strObjid As Object) As DataGridViewRow
			Dim dataGridViewRow2 As DataGridViewRow
			Try
				Try
					For Each obj As Object In CType(dgv.Rows, IEnumerable)
						Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
						Dim flag As Boolean = Operators.ConditionalCompareObjectEqual(dataGridViewRow.Cells("OBJID").Value.ToString().Trim().ToUpper(), NewLateBinding.LateGet(NewLateBinding.LateGet(strObjid, Nothing, "Trim", New Object(-1) {}, Nothing, Nothing, Nothing), Nothing, "ToUpper", New Object(-1) {}, Nothing, Nothing, Nothing), False)
						If flag Then
							Return dataGridViewRow
						End If
					Next
				Finally
					Dim enumerator As IEnumerator
					Dim flag As Boolean = TypeOf enumerator Is IDisposable
					If flag Then
						TryCast(enumerator, IDisposable).Dispose()
					End If
				End Try
				dataGridViewRow2 = Nothing
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				dataGridViewRow2 = Nothing
			End Try
			Return dataGridViewRow2
		End Function

		' Token: 0x060015CA RID: 5578 RVA: 0x00109498 File Offset: 0x00107698
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMHH As frmDMHH2 = New frmDMHH2()
			Try
				Dim flag As Boolean = Me.dicSelected.Keys.Count > 1
				Dim flag2 As Boolean
				If flag Then
					flag2 = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(46), Me.btnDelete.Text, frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.No
					If flag2 Then
						Return
					End If
					Try
						For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
							Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
							flag2 = Conversions.ToBoolean(If((Conversions.ToBoolean(Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("QTYIN").Value)) = 0.0) OrElse Conversions.ToBoolean(dataGridViewRow.Cells("FIXED").Value)), True, False))
							If Not flag2 Then
								Dim frmDMHH2 As frmDMHH2 = frmDMHH
								frmDMHH2.pbytFromStatus = 4
								frmDMHH2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("OBJID").Value, ""))
								frmDMHH2.txtMADVT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADVT").Value, ""))
								frmDMHH2.txtMADVTDG.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow.Cells("MADVTDG").Value, ""))
								frmDMHH.pBlnAutoDel = True
								frmDMHH.ShowDialog()
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag2 = TypeOf enumerator Is IDisposable
						If flag2 Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
				Else
					Dim text As String = ""
					Try
						For Each keyValuePair As KeyValuePair(Of String, Integer) In Me.dicSelected
							text += keyValuePair.Key.Trim()
						Next
					Finally
						Dim enumerator2 As Dictionary(Of String, Integer).Enumerator
						CType(enumerator2, IDisposable).Dispose()
					End Try
					Dim dataGridViewRow2 As DataGridViewRow = Nothing
					flag2 = text.Trim().Length > 0
					If flag2 Then
						Dim dgvData As DataGridView = Me.dgvData
						Dim dataGridViewRow3 As DataGridViewRow = Me.fFindRowDataGrid(dgvData, text.Trim())
						Me.dgvData = dgvData
						dataGridViewRow2 = dataGridViewRow3
					End If
					flag2 = dataGridViewRow2 Is Nothing
					If flag2 Then
						Return
					End If
					flag2 = Conversions.ToBoolean(dataGridViewRow2.Cells("FIXED").Value)
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						frmDMHH.Dispose()
						Return
					End If
					Dim frmDMHH3 As frmDMHH2 = frmDMHH
					frmDMHH3.pbytFromStatus = 4
					frmDMHH3.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("OBJID").Value, ""))
					frmDMHH3.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("OBJNAME").Value, ""))
					frmDMHH3.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("SUBOBJNAME").Value, ""))
					frmDMHH3.txtMADVT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MADVT").Value, ""))
					frmDMHH3.txtMADV.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MADV").Value, ""))
					frmDMHH3.txtMAMT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MAMT").Value, ""))
					frmDMHH3.txtMAPL.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MAPL").Value, ""))
					frmDMHH3.txtMANSX.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MANSX").Value, ""))
					frmDMHH3.txtTENMT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("TENTHUE").Value, ""))
					frmDMHH3.txtMANH.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MANH").Value, ""))
					frmDMHH3.txtTENNH.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("TENNH").Value, ""))
					frmDMHH3.txtTENPL.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("TENPL").Value, ""))
					frmDMHH3.txtTENNSX.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("TENNSX").Value, ""))
					frmDMHH3.txtPRICE.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PRICE1").Value, ""))
					frmDMHH3.txtPRICE2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PRICE2").Value, ""))
					frmDMHH3.txtPRICE3.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PRICE3").Value, ""))
					frmDMHH3.txtPRICE4.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PRICE4").Value, ""))
					frmDMHH3.txtPRICE5.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PRICE5").Value, ""))
					frmDMHH3.txtPRICE6.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PRICE6").Value, ""))
					frmDMHH3.txtPRICE7.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PRICE7").Value, ""))
					frmDMHH3.txtPRICE8.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PRICE8").Value, ""))
					frmDMHH3.txtPRICE9.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PRICE9").Value, ""))
					frmDMHH3.txtPRICE10.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PRICE10").Value, ""))
					frmDMHH3.txtPURSE.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("PURSE").Value, ""))
					frmDMHH3.txtMADVTDG.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MADVTDG").Value, ""))
					frmDMHH3.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("REMARK").Value, ""))
					frmDMHH3.chkLSAVE.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LSAVE").Value)
					frmDMHH3.chkStopUse.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LSTOPUSE").Value)
					frmDMHH3.chkCOMBO.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LCOMBO").Value)
					frmDMHH3.txtbep1.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MAMAYINBEP1").Value, ""))
					frmDMHH3.txtbep2.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MAMAYINBEP2").Value, ""))
					frmDMHH3.txtbep3.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MAMAYINBEP3").Value, ""))
					frmDMHH3.chkLopen.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LOPEN").Value)
					frmDMHH3.chkLMATERIAL.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LHIDEN").Value)
					frmDMHH3.txtCOMBO.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("COMBO").Value, ""))
					frmDMHH3.chkLSETCOMBO.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LSETCOMBO").Value)
					frmDMHH3.chkLTON_KHACHHANG.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LTON_KHACHHANG").Value)
					frmDMHH3.grbTONKHO.Visible = True
					frmDMHH3.txtbep4.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MAMAYINBEP4").Value, ""))
					frmDMHH3.txtbep5.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MAMAYINBEP5").Value, ""))
					frmDMHH3.txtbep6.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("MAMAYINBEP6").Value, ""))
					frmDMHH3.chkLComboPrice.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LCOMBOPRICE").Value)
					frmDMHH3.txtTHOIKHOANG.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("THOIKHOANG").Value, ""))
					frmDMHH3.txtTienHoaHong.Text = mdlUIForm.gfFormatNumber(Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow2.Cells("HOAHONG").Value)), CShort(mdlVariable.gbytDECNUMAMT), ",")
					Dim num As Double = Conversion.Val(frmDMHH3.txtPRICE.Text.Replace(",", ""))
					Dim num2 As Double = Conversion.Val(frmDMHH3.txtTienHoaHong.Text.Replace(",", ""))
					Dim num3 As Double = num2 * 100.0 / num
					frmDMHH3.txtHOAHONG.Text = mdlUIForm.gfFormatNumber(num3, 3S, ",")
					frmDMHH3.txtTiLeDVT.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("TILEDVT").Value, ""))
					frmDMHH3.txtScore.Text = Conversions.ToString(Operators.ConcatenateObject(dataGridViewRow2.Cells("SCORE").Value, ""))
					frmDMHH3.chkLQTYMain.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LQTYMain").Value)
					frmDMHH3.chkLAmtOpen.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LAMTOPEN").Value)
					frmDMHH3.chkLSerial.Checked = Conversions.ToBoolean(dataGridViewRow2.Cells("LSERIAL").Value)
					frmDMHH.ShowDialog()
					flag2 = frmDMHH.pbytSuccess = 0
					If flag2 Then
						Return
					End If
				End If
				Dim b As Byte = Me.fGetData_4Grid()
				flag2 = b = 0
				If flag2 Then
					Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
				End If
				flag2 = b <> 0
				If flag2 Then
					b = Me.fInitGrid()
				End If
				flag2 = b <> 0
				If flag2 Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMHH.Dispose()
			End Try
		End Sub

		' Token: 0x060015CB RID: 5579 RVA: 0x0010A208 File Offset: 0x00108408
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMHH As frmDMHH2 = New frmDMHH2()
			Try
				frmDMHH.pbytFromStatus = 6
				frmDMHH.ShowDialog()
				Dim flag As Boolean = frmDMHH.pbytSuccess = 0
				If flag Then
					frmDMHH.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMHH.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMHH.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						Me.btnUnSelAll_Click(RuntimeHelpers.GetObjectValue(sender), e)
						Me.dgvData.Rows(num).DefaultCellStyle.BackColor = SystemColors.Highlight
						Me.dgvData.Rows(num).Cells("QTYIN").Value = Me.txtSLIn.Text.Replace(",", "")
						Dim text As String = Me.dgvData.Rows(num).Cells("OBJID").Value.ToString().Trim()
						Dim num2 As Integer = CInt(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.Rows(num).Cells("QTYIN").Value))))
						flag = Me.dicSelected.ContainsKey(text)
						If flag Then
							Me.dicSelected(text) = num2
						Else
							Me.dicSelected.Add(text, num2)
						End If
						Me.sTinhTongSoLuongIn()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMHH.Dispose()
			End Try
		End Sub

		' Token: 0x060015CC RID: 5580 RVA: 0x0010A510 File Offset: 0x00108710
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMHH As frmDMHH2 = New frmDMHH2()
			Try
				Me.btnFindNext.Visible = False
				frmDMHH.pbytFromStatus = 5
				frmDMHH.ShowDialog()
				Dim flag As Boolean = frmDMHH.pbytSuccess = 0
				If Not flag Then
					Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Me.txtOBJIDNH.Text.Trim(), "", False) <> 0, " AND MANH like '%" + Me.txtOBJIDNH.Text.Trim() + "%'", ""))
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMHH.pStrFilter + text
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMHH.Dispose()
			End Try
		End Sub

		' Token: 0x060015CD RID: 5581 RVA: 0x0010A688 File Offset: 0x00108888
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMHH As frmDMHH2 = New frmDMHH2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMHH.Dispose()
			End Try
		End Sub

		' Token: 0x060015CE RID: 5582 RVA: 0x0010A750 File Offset: 0x00108950
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_01DE
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					Me.btnUnSelAll_Click(RuntimeHelpers.GetObjectValue(sender), e)
					Me.dgvData.Rows(num6).DefaultCellStyle.BackColor = SystemColors.Highlight
					Me.dgvData.Rows(num6).Cells("QTYIN").Value = Me.txtSLIn.Text.Replace(",", "")
					Dim text As String = Me.dgvData.Rows(num6).Cells("OBJID").Value.ToString().Trim()
					Dim num7 As Integer = CInt(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.Rows(num6).Cells("QTYIN").Value))))
					flag = Me.dicSelected.ContainsKey(text)
					If flag Then
						Me.dicSelected(text) = num7
					Else
						Me.dicSelected.Add(text, num7)
					End If
					Me.sTinhTongSoLuongIn()
					IL_01DE:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x060015CF RID: 5583 RVA: 0x0010A9E0 File Offset: 0x00108BE0
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = Strings.Trim(Me.txtOBJIDNH.Text)
				Dim b As Byte = Me.fPrintDMHH(text)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015D0 RID: 5584 RVA: 0x0010AA8C File Offset: 0x00108C8C
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015D1 RID: 5585 RVA: 0x0010AB3C File Offset: 0x00108D3C
		Private Sub btnEx_Click(sender As Object, e As EventArgs)
			Try
				Dim clsConnect As clsConnect = New clsConnect()
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
				Dim flag As Boolean = clsConnect IsNot Nothing
				If flag Then
					Dim flag2 As Boolean = mdlFile.gfExport2Excel(clsConnect, "", "") = 0
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(38), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(38), vbCrLf, Me.Name, " - btnEx_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015D2 RID: 5586 RVA: 0x0010AC1C File Offset: 0x00108E1C
		Private Sub btnIm_Click(sender As Object, e As EventArgs)
			Try
				Dim openFileDialog As OpenFileDialog = New OpenFileDialog()
				Dim openFileDialog2 As OpenFileDialog = openFileDialog
				openFileDialog2.Title = Me.mArrStrFrmMess(39)
				openFileDialog2.Filter = "Excel Only(*.xls)|*.xls|*.csv|*.xlsx"
				Dim flag As Boolean = openFileDialog2.ShowDialog() = DialogResult.OK
				If flag Then
					Dim dataTable As DataTable = New DataTable()
					flag = mdlFile.gfImportFromExcel(openFileDialog2.FileName, dataTable, False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(40), MsgBoxStyle.Critical, Nothing)
					Else
						flag = dataTable IsNot Nothing AndAlso dataTable.Rows.Count > 0
						If flag Then
							Me.sAddFromExcel(dataTable)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(40), vbCrLf, Me.Name, " - btnIm_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015D3 RID: 5587 RVA: 0x0010AD44 File Offset: 0x00108F44
		Private Sub sAddFromExcel(ptblData As DataTable)
			Dim frmDMHH As frmDMHH2 = New frmDMHH2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim num As Integer = 0
				Dim num2 As Integer = ptblData.Rows.Count - 1
				Dim num3 As Integer = num
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						Exit For
					End If
					Dim frmDMHH2 As frmDMHH2 = frmDMHH
					frmDMHH2.pbytFromStatus = 2
					frmDMHH2.txtOBJID.Text = ptblData.Rows(num3)("OBJID").ToString() + ""
					frmDMHH2.txtOBJNAME.Text = ptblData.Rows(num3)("OBJNAME").ToString() + ""
					frmDMHH2.txtSUBOBJNAME.Text = ptblData.Rows(num3)("SUBOBJNAME").ToString() + ""
					frmDMHH2.txtMADVT.Text = ptblData.Rows(num3)("MADVT").ToString() + ""
					frmDMHH2.txtMADVTDG.Text = ptblData.Rows(num3)("MADVTDG").ToString() + ""
					frmDMHH2.txtMADV.Text = ptblData.Rows(num3)("MADV").ToString() + ""
					frmDMHH2.txtMAMT.Text = ptblData.Rows(num3)("MAMT").ToString() + ""
					frmDMHH2.txtMAMT2.Text = ptblData.Rows(num3)("MAMT2").ToString() + ""
					frmDMHH2.txtMAPL.Text = ptblData.Rows(num3)("MAPL").ToString() + ""
					frmDMHH2.txtMANSX.Text = ptblData.Rows(num3)("MANSX").ToString() + ""
					frmDMHH2.txtMANH.Text = ptblData.Rows(num3)("MANH").ToString() + ""
					frmDMHH2.txtPRICE.Text = Conversions.ToString(Conversion.Val(ptblData.Rows(num3)("PRICE1").ToString()))
					frmDMHH2.txtPRICE2.Text = Conversions.ToString(Conversion.Val(ptblData.Rows(num3)("PRICE2").ToString()))
					frmDMHH2.txtPRICE3.Text = Conversions.ToString(Conversion.Val(ptblData.Rows(num3)("PRICE3").ToString()))
					frmDMHH2.txtPRICE4.Text = Conversions.ToString(Conversion.Val(ptblData.Rows(num3)("PRICE4").ToString()))
					frmDMHH2.txtPRICE5.Text = Conversions.ToString(Conversion.Val(ptblData.Rows(num3)("PRICE5").ToString()))
					frmDMHH2.txtPRICE6.Text = Conversions.ToString(Conversion.Val(ptblData.Rows(num3)("PRICE6").ToString()))
					frmDMHH2.txtPRICE7.Text = Conversions.ToString(Conversion.Val(ptblData.Rows(num3)("PRICE7").ToString()))
					frmDMHH2.txtPRICE8.Text = Conversions.ToString(Conversion.Val(ptblData.Rows(num3)("PRICE8").ToString()))
					frmDMHH2.txtPRICE9.Text = Conversions.ToString(Conversion.Val(ptblData.Rows(num3)("PRICE9").ToString()))
					frmDMHH2.txtPRICE10.Text = Conversions.ToString(Conversion.Val(ptblData.Rows(num3)("PRICE10").ToString()))
					frmDMHH2.txtPURSE.Text = ptblData.Rows(num3)("PURSEHH").ToString() + ""
					frmDMHH2.txtREMARK.Text = ptblData.Rows(num3)("REMARK").ToString() + ""
					frmDMHH2.txtbep1.Text = ptblData.Rows(num3)("MAMAYINBEP1").ToString() + ""
					frmDMHH2.txtbep2.Text = ptblData.Rows(num3)("MAMAYINBEP2").ToString() + ""
					frmDMHH2.txtbep3.Text = ptblData.Rows(num3)("MAMAYINBEP3").ToString() + ""
					frmDMHH2.txtbep4.Text = ptblData.Rows(num3)("MAMAYINBEP4").ToString() + ""
					frmDMHH2.txtbep5.Text = ptblData.Rows(num3)("MAMAYINBEP5").ToString() + ""
					frmDMHH2.txtbep6.Text = ptblData.Rows(num3)("MAMAYINBEP6").ToString() + ""
					frmDMHH2.chkLSAVE.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(Strings.UCase(ptblData.Rows(num3)("LSAVE").ToString()), "TRUE", False) = 0, True, False))
					frmDMHH2.chkLopen.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(Strings.UCase(ptblData.Rows(num3)("LOPEN").ToString()), "TRUE", False) = 0, True, False))
					frmDMHH2.chkLMATERIAL.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(Strings.UCase(ptblData.Rows(num3)("LHIDEN").ToString()), "TRUE", False) = 0, True, False))
					frmDMHH2.chkStopUse.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(Strings.UCase(ptblData.Rows(num3)("LSTOPUSE").ToString()), "TRUE", False) = 0, True, False))
					frmDMHH2.chkCOMBO.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(Strings.UCase(ptblData.Rows(num3)("LCOMBO").ToString()), "TRUE", False) = 0, True, False))
					frmDMHH2.chkLComboPrice.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(Strings.UCase(ptblData.Rows(num3)("LCOMBOPRICE").ToString()), "TRUE", False) = 0, True, False))
					frmDMHH2.txtTHOIKHOANG.Text = ptblData.Rows(num3)("THOIKHOANG").ToString() + ""
					frmDMHH2.txtHOAHONG.Text = ptblData.Rows(num3)("HOAHONG").ToString() + ""
					frmDMHH2.txtTiLeDVT.Text = ptblData.Rows(num3)("TILEDVT").ToString() + ""
					frmDMHH2.txtScore.Text = ptblData.Rows(num3)("SCORE").ToString() + ""
					frmDMHH2.chkLQTYMain.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(Strings.UCase(ptblData.Rows(num3)("LQTYMain").ToString()), "TRUE", False) = 0, True, False))
					frmDMHH2.chkLTON_KHACHHANG.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(Strings.UCase(ptblData.Rows(num3)("LTON_KHACHHANG").ToString()), "TRUE", False) = 0, True, False))
					frmDMHH2.txtCOMBO.Text = ptblData.Rows(num3)("COMBO").ToString() + ""
					frmDMHH2.chkLSETCOMBO.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(Strings.UCase(ptblData.Rows(num3)("LSETCOMBO").ToString()), "TRUE", False) = 0, True, False))
					frmDMHH2.pstrUIMAGE = ptblData.Rows(num3)("UIMAGE").ToString() + ""
					frmDMHH2.grbTONKHO.Visible = True
					frmDMHH.gfAddNew(1)
					num3 += 1
				End While
				Dim b As Byte = Me.fGetData_4Grid()
				Dim flag As Boolean = b = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Dim objectValue As Object = RuntimeHelpers.GetObjectValue(New Object())
					Dim eventArgs As EventArgs = New EventArgs()
					Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMHH.pStrFilter)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(objectValue), eventArgs)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAddDefault_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMHH.Dispose()
			End Try
		End Sub

		' Token: 0x060015D4 RID: 5588 RVA: 0x0010B8E4 File Offset: 0x00109AE4
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMHH")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mblnAutoAdd_DMHH = xmlNode.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
				Dim xmlNodeList2 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMHHMAX")
				flag = xmlNodeList2.Count > 0
				If flag Then
					Dim xmlNode2 As XmlNode = xmlNodeList2.Item(0)
					Me.mbytLen_OBJID = Byte.Parse(xmlNode2.InnerText)
				End If
				Dim xmlNodeList3 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/LABELPATH")
				flag = xmlNodeList3.Count > 0
				If flag Then
					Dim xmlNode3 As XmlNode = xmlNodeList3.Item(0)
					Me.mStrLabelPath = xmlNode3.InnerText.Trim()
				End If
				Dim xmlNodeList4 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/LABELFONT")
				flag = xmlNodeList4.Count > 0
				If flag Then
					Dim xmlNode4 As XmlNode = xmlNodeList4.Item(0)
					Me.mStrLabelFont = xmlNode4.InnerText.Trim()
				End If
				Dim xmlNodeList5 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/CHAR1000")
				flag = xmlNodeList5.Count > 0
				If flag Then
					Dim xmlNode5 As XmlNode = xmlNodeList5.Item(0)
					Me.mStrChar1000 = xmlNode5.InnerText
				End If
				Dim xmlNodeList6 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/CHARLE")
				flag = xmlNodeList6.Count > 0
				If flag Then
					Dim xmlNode6 As XmlNode = xmlNodeList6.Item(0)
					Me.mStrCharLe = xmlNode6.InnerText
				End If
				Dim xmlNodeList7 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/CHARMONEY")
				flag = xmlNodeList7.Count > 0
				If flag Then
					Dim xmlNode7 As XmlNode = xmlNodeList7.Item(0)
					Me.mStrCharMoney = xmlNode7.InnerText
				End If
				Dim xmlNodeList8 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/CHARMONEYPOS")
				flag = xmlNodeList8.Count > 0
				If flag Then
					Dim xmlNode8 As XmlNode = xmlNodeList8.Item(0)
					Me.mBytCharMoneyPos = Conversions.ToByte(Interaction.IIf(xmlNode8.InnerText.Trim().ToUpper().Equals("TRUE"), 1, 0))
				End If
				Dim xmlNodeList9 As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/FILENAMEEXCEL")
				flag = xmlNodeList9.Count > 0
				If flag Then
					Dim xmlNode9 As XmlNode = xmlNodeList9.Item(0)
					Me.mStrLabelFileName = xmlNode9.InnerText.Trim()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015D5 RID: 5589 RVA: 0x0010BBDC File Offset: 0x00109DDC
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = True
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.[ReadOnly] = False
				dgvData.EditMode = DataGridViewEditMode.EditOnEnter
				dgvData.AllowUserToResizeRows = False
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJID").[ReadOnly] = True
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").[ReadOnly] = True
				dgvData.Columns("SUBOBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(41))
				dgvData.Columns("SUBOBJNAME").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("SUBOBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SUBOBJNAME").[ReadOnly] = True
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 7
				If flag Then
					dgvData.Columns("SUBOBJNAME").Width = 0
				End If
				dgvData.Columns("TENDVT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("TENDVT").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("TENDVT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENDVT").[ReadOnly] = True
				dgvData.Columns("PRICE1").HeaderText = Strings.Trim(Me.mArrStrFrmMess(29))
				dgvData.Columns("PRICE1").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("PRICE1").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("PRICE1").[ReadOnly] = True
				dgvData.Columns("LSAVE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(21))
				dgvData.Columns("LSAVE").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("LSAVE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LSAVE").[ReadOnly] = True
				dgvData.Columns("QTYIN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(53))
				dgvData.Columns("QTYIN").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("QTYIN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("QTYIN").DefaultCellStyle.Font = New Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point)
				dgvData.Columns("QTYIN").[ReadOnly] = False
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("REMARK").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").[ReadOnly] = True
				dgvData.Columns("TENNH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("TENNH").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENNH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENNH").[ReadOnly] = True
				dgvData.Columns("TENPL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(31))
				dgvData.Columns("TENPL").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENPL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENPL").[ReadOnly] = True
				dgvData.Columns("TENNSX").HeaderText = Strings.Trim(Me.mArrStrFrmMess(32))
				dgvData.Columns("TENNSX").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENNSX").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENNSX").[ReadOnly] = True
				dgvData.Columns("LOPEN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(33))
				dgvData.Columns("LOPEN").Width = 60
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("LOPEN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LOPEN").[ReadOnly] = True
				dgvData.Columns("LHIDEN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(34))
				dgvData.Columns("LHIDEN").Width = 60
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("LHIDEN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LHIDEN").[ReadOnly] = True
				dgvData.Columns("LSTOPUSE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(35))
				dgvData.Columns("LSTOPUSE").Width = 60
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
				dgvData.Columns("LSTOPUSE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LSTOPUSE").[ReadOnly] = True
				flag = Operators.CompareString(mdlVariable.gStrLanguage, "VIE", False) = 0
				If flag Then
					dgvData.Columns("SUBOBJNAME").Visible = True
				End If
				dgvData.Columns("THOIKHOANG").HeaderText = Strings.Trim(Me.mArrStrFrmMess(44))
				dgvData.Columns("THOIKHOANG").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
				dgvData.Columns("THOIKHOANG").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("THOIKHOANG").[ReadOnly] = True
				dgvData.Columns("HOAHONG").HeaderText = Strings.Trim(Me.mArrStrFrmMess(45))
				dgvData.Columns("HOAHONG").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
				dgvData.Columns("HOAHONG").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("HOAHONG").[ReadOnly] = True
				dgvData.Columns("TENTHUE").Visible = False
				dgvData.Columns("TENTHUE2").Visible = False
				dgvData.Columns("MAPL").Visible = False
				dgvData.Columns("MADV").Visible = False
				dgvData.Columns("TENDV").Visible = False
				dgvData.Columns("MANSX").Visible = False
				dgvData.Columns("MADVT").Visible = False
				dgvData.Columns("MADC").Visible = False
				dgvData.Columns("PRICE2").Visible = False
				dgvData.Columns("PRICE3").Visible = False
				dgvData.Columns("PRICE4").Visible = False
				dgvData.Columns("PRICE5").Visible = False
				dgvData.Columns("PRICE6").Visible = False
				dgvData.Columns("PRICE7").Visible = False
				dgvData.Columns("PRICE8").Visible = False
				dgvData.Columns("PRICE9").Visible = False
				dgvData.Columns("PRICE10").Visible = False
				dgvData.Columns("MAMT").Visible = False
				dgvData.Columns("MAMT2").Visible = False
				dgvData.Columns("MANH").Visible = False
				dgvData.Columns("LMATERIAL").Visible = False
				dgvData.Columns("FIXED").Visible = False
				dgvData.Columns("RATE").Visible = False
				dgvData.Columns("RATE2").Visible = False
				dgvData.Columns("MAMAYINBEP1").Visible = False
				dgvData.Columns("MAMAYINBEP2").Visible = False
				dgvData.Columns("MAMAYINBEP3").Visible = False
				dgvData.Columns("LCOMBO").Visible = False
				dgvData.Columns("COMBO").Visible = False
				dgvData.Columns("PURSE").Visible = False
				dgvData.Columns("LSETCOMBO").Visible = False
				dgvData.Columns("LTON_KHACHHANG").Visible = False
				dgvData.Columns("PHIEU").Visible = False
				dgvData.Columns("MAMAYINBEP4").Visible = False
				dgvData.Columns("MAMAYINBEP5").Visible = False
				dgvData.Columns("MAMAYINBEP6").Visible = False
				dgvData.Columns("UIMAGE").Visible = False
				dgvData.Columns("LCOMBOPRICE").Visible = False
				dgvData.Columns("MADVTDG").Visible = False
				dgvData.Columns("TENDVTDG").Visible = False
				dgvData.Columns("TILEDVT").Visible = False
				dgvData.Columns("SCORE").Visible = False
				dgvData.Columns("LQTYMAIN").Visible = False
				dgvData.Columns("PRICE1_S").Visible = False
				dgvData.Columns("LAMTOPEN").Visible = False
				dgvData.Columns("LSERIAL").Visible = False
				dgvData.Columns("OBJNAME2").Visible = False
				dgvData.Columns("LQTYLE").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060015D6 RID: 5590 RVA: 0x0010C9F4 File Offset: 0x0010ABF4
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060015D7 RID: 5591 RVA: 0x0010CB74 File Offset: 0x0010AD74
		Private Function fGetData_4Filter() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMNH = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNH")
				Dim flag As Boolean = Me.mclsTbDMNH IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Filter ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060015D8 RID: 5592 RVA: 0x0010CC30 File Offset: 0x0010AE30
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@gBytDecAmtUSD"
				Dim text As String = Conversions.ToString(Interaction.IIf(mdlVariable.gStrMoneyUnit.Length > 1, mdlVariable.gStrMoneyUnit, "VN"))
				Dim flag As Boolean = Operators.CompareString(text.Substring(0, 2), "VN", False) = 0
				If flag Then
					array(0).Value = mdlVariable.gbytDECNUMAMT
				Else
					array(0).Value = mdlVariable.gbytDECNUMFOR
				End If
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pbitOnlyLSAVE"
				array(1).Value = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHH_GET_ALL_DATA", num)
				flag = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
					If flag Then
						Me.mbdsSource.Filter = Me.mStrFilter
					End If
					Me.dicSelected.Clear()
					Me.txtTongSLIn.Text = "0"
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060015D9 RID: 5593 RVA: 0x0010CE38 File Offset: 0x0010B038
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060015DA RID: 5594 RVA: 0x0010CF88 File Offset: 0x0010B188
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2060400000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060015DB RID: 5595 RVA: 0x0010D094 File Offset: 0x0010B294
		Private Sub sClear_Form()
			Try
				Dim flag As Boolean = Me.mbdsSource IsNot Nothing
				If flag Then
					Me.mbdsSource.Dispose()
				End If
				flag = Me.mclsTbDMNH IsNot Nothing
				If flag Then
					Me.mclsTbDMNH.Dispose()
				End If
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060015DC RID: 5596 RVA: 0x0010D16C File Offset: 0x0010B36C
		Private Sub btnSendData_Click(sender As Object, e As EventArgs)
			Dim frmSendData As frmSendData = New frmSendData()
			frmSendData.ShowDialog()
		End Sub

		' Token: 0x060015DD RID: 5597 RVA: 0x0010D188 File Offset: 0x0010B388
		Private Sub dgvData_CellClick(sender As Object, e As DataGridViewCellEventArgs)
			Try
				Dim flag As Boolean = e.RowIndex < 0
				If Not flag Then
					flag = Me.dgvData.Rows(e.RowIndex).DefaultCellStyle.BackColor = SystemColors.Highlight
					If flag Then
						Me.dgvData.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.White
						Me.dgvData.Rows(e.RowIndex).Cells("QTYIN").Value = "0"
						Me.dicSelected.Remove(Me.dgvData.Rows(e.RowIndex).Cells("OBJID").Value.ToString().Trim())
					Else
						Me.dgvData.Rows(e.RowIndex).DefaultCellStyle.BackColor = SystemColors.Highlight
						Me.dgvData.Rows(e.RowIndex).Cells("QTYIN").Value = Me.txtSLIn.Text.Replace(",", "")
						Dim text As String = Me.dgvData.Rows(e.RowIndex).Cells("OBJID").Value.ToString().Trim()
						Dim num As Integer = CInt(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.Rows(e.RowIndex).Cells("QTYIN").Value))))
						flag = Me.dicSelected.ContainsKey(Me.dgvData.Rows(e.RowIndex).Cells("OBJID").Value.ToString())
						If flag Then
							Me.dicSelected(text) = num
						Else
							Me.dicSelected.Add(text, num)
						End If
					End If
					Me.sTinhTongSoLuongIn()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_CellClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060015DE RID: 5598 RVA: 0x0010D440 File Offset: 0x0010B640
		Private Sub dgvData_CellMouseDown(sender As Object, e As DataGridViewCellMouseEventArgs)
			Try
				Dim flag As Boolean = e.RowIndex < 0
				If Not flag Then
					flag = Control.ModifierKeys = Keys.Shift
					If Not flag Then
						flag = Me.dgvData.Rows(e.RowIndex).DefaultCellStyle.BackColor = SystemColors.Highlight
						If flag Then
							Me.mblnSelectRow = False
						Else
							Me.mblnSelectRow = True
						End If
						Me.mintMouseDown = e.RowIndex
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_CellMouseDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060015DF RID: 5599 RVA: 0x0010D53C File Offset: 0x0010B73C
		Private Sub dgvData_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs)
			Try
				Dim flag As Boolean = Not Versioned.IsNumeric(RuntimeHelpers.GetObjectValue(Me.dgvData.Rows(e.RowIndex).Cells("QTYIN").Value))
				If flag Then
					MessageBox.Show(Me.mArrStrFrmMess(56), Me.mArrStrFrmMess(57), MessageBoxButtons.OK, MessageBoxIcon.Hand)
					Me.dgvData.Rows(e.RowIndex).Cells("QTYIN").Value = Me.txtSLIn.Text.Replace(",", "")
				End If
				flag = Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.Rows(e.RowIndex).Cells("QTYIN").Value)) > 0.0
				If flag Then
					Me.dgvData.Rows(e.RowIndex).DefaultCellStyle.BackColor = SystemColors.Highlight
					Dim text As String = Me.dgvData.Rows(e.RowIndex).Cells("OBJID").Value.ToString().Trim()
					Dim num As Integer = CInt(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.Rows(e.RowIndex).Cells("QTYIN").Value))))
					flag = Me.dicSelected.ContainsKey(text)
					If flag Then
						Me.dicSelected(text) = num
					Else
						Me.dicSelected.Add(text, num)
					End If
				Else
					Me.dgvData.Rows(e.RowIndex).DefaultCellStyle.BackColor = Color.White
					Me.dicSelected.Remove(Me.dgvData.Rows(e.RowIndex).Cells("OBJID").Value.ToString().Trim())
				End If
				Me.sTinhTongSoLuongIn()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_CellEndEdit ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060015E0 RID: 5600 RVA: 0x0010D7EC File Offset: 0x0010B9EC
		Private Sub dgvData_CellMouseUp(sender As Object, e As DataGridViewCellMouseEventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean = e.RowIndex < 0
				If Not flag Then
					Me.mintMouseUp = e.RowIndex
					flag = Control.ModifierKeys = Keys.Shift
					If flag Then
						Dim num As Integer = Math.Min(Me.mintMouseDown, Me.mintMouseUp)
						Dim num2 As Integer = Math.Max(Me.mintMouseDown, Me.mintMouseUp)
						Dim num3 As Integer = num
						While True
							Dim num4 As Integer = num3
							Dim num5 As Integer = num2
							If num4 > num5 Then
								Exit For
							End If
							Me.dgvData.Rows(num3).DefaultCellStyle.BackColor = SystemColors.Highlight
							Me.dgvData.Rows(num3).Cells("QTYIN").Value = Me.txtSLIn.Text.Replace(",", "")
							Dim text As String = Me.dgvData.Rows(num3).Cells("OBJID").Value.ToString().Trim()
							Dim num6 As Integer = CInt(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.Rows(num3).Cells("QTYIN").Value))))
							flag = Me.dicSelected.ContainsKey(text)
							If flag Then
								Me.dicSelected(text) = num6
							Else
								Me.dicSelected.Add(text, num6)
							End If
							num3 += 1
						End While
						Me.sTinhTongSoLuongIn()
					Else
						flag = Me.mintMouseDown = Me.mintMouseUp
						If Not flag Then
							Dim num7 As Integer = Math.Min(Me.mintMouseDown, Me.mintMouseUp)
							Dim num8 As Integer = Math.Max(Me.mintMouseDown, Me.mintMouseUp)
							Dim num9 As Integer = num7
							While True
								Dim num10 As Integer = num9
								Dim num5 As Integer = num8
								If num10 > num5 Then
									Exit For
								End If
								flag = Me.mblnSelectRow
								If flag Then
									Me.dgvData.Rows(num9).DefaultCellStyle.BackColor = SystemColors.Highlight
									Me.dgvData.Rows(num9).Cells("QTYIN").Value = Me.txtSLIn.Text.Replace(",", "")
									Dim text2 As String = Me.dgvData.Rows(num9).Cells("OBJID").Value.ToString().Trim()
									Dim num11 As Integer = CInt(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.Rows(num9).Cells("QTYIN").Value))))
									flag = Me.dicSelected.ContainsKey(text2)
									If flag Then
										Me.dicSelected(text2) = num11
									Else
										Me.dicSelected.Add(text2, num11)
									End If
								Else
									Me.dgvData.Rows(num9).DefaultCellStyle.BackColor = Color.White
									Me.dgvData.Rows(num9).Cells("QTYIN").Value = "0"
									Me.dicSelected.Remove(Me.dgvData.Rows(num9).Cells("OBJID").Value.ToString().Trim())
								End If
								num9 += 1
							End While
							Me.sTinhTongSoLuongIn()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - DGV1_CellMouseUp ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060015E1 RID: 5601 RVA: 0x000053C4 File Offset: 0x000035C4
		Private Sub dgvData_SelectionChanged(sender As Object, e As EventArgs)
			Me.dgvData.ClearSelection()
		End Sub

		' Token: 0x060015E2 RID: 5602 RVA: 0x0010DBF8 File Offset: 0x0010BDF8
		Private Sub txtLoc_GotFocus(sender As Object, e As EventArgs)
			Try
				Me.txtOBJIDNH.Text = ""
				Me.cboSLIn.SelectedIndex = 0
				Me.txtLoc.Focus()
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060015E3 RID: 5603 RVA: 0x0010DC54 File Offset: 0x0010BE54
		Private Sub txtLoc_KeyPress(sender As Object, e As KeyPressEventArgs)
			Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
			If flag Then
				Me.sLocDuLieu()
			End If
		End Sub

		' Token: 0x060015E4 RID: 5604 RVA: 0x0010DC80 File Offset: 0x0010BE80
		Private Sub sLocDuLieu()
			' The following expression was wrapped in a checked-statement
			Try
				Dim text As String = ""
				Dim text2 As String = ""
				Dim text3 As String = ""
				Dim flag As Boolean = Me.txtOBJNAMENH.Text.Trim().Length > 0
				If flag Then
					text = "MANH like '" + Strings.Replace(Strings.Trim(Me.txtOBJIDNH.Text), "'", "''", 1, -1, CompareMethod.Binary) + "'"
				End If
				flag = Me.txtLoc.Text.Trim().Length > 0
				If flag Then
					text2 = "OBJID Like '%" + Strings.Replace(Strings.Trim(Me.txtLoc.Text), "'", "''", 1, -1, CompareMethod.Binary) + "%'"
					text2 = text2 + " Or OBJNAME Like '%" + Strings.Replace(Strings.Trim(Me.txtLoc.Text), "'", "''", 1, -1, CompareMethod.Binary) + "%'"
					text2 = text2 + " Or OBJNAME2 Like '%" + Strings.Replace(Strings.Trim(Me.txtLoc.Text), "'", "''", 1, -1, CompareMethod.Binary) + "%'"
					text2 = text2 + " Or SUBOBJNAME Like '%" + Strings.Replace(Strings.Trim(Me.txtLoc.Text), "'", "''", 1, -1, CompareMethod.Binary) + "%'"
				End If
				flag = text.Trim().Length > 0
				If flag Then
					text3 = text
				End If
				flag = text2.Trim().Length > 0
				If flag Then
					text3 = Conversions.ToString(Interaction.IIf(text.Trim().Length > 0, text + " And " + text2, text2))
				End If
				flag = text3.Trim().Length > 0
				If flag Then
					Me.mbdsSource.Filter = text3
				Else
					Me.mbdsSource.RemoveFilter()
				End If
				Me.mbdsSource_PositionChanged(Me, New EventArgs())
				Dim num As Integer = 0
				Dim num2 As Integer = Me.dgvData.Rows.Count - 1
				Dim num3 As Integer = num
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						Exit For
					End If
					flag = Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.Rows(num3).Cells("QTYIN").Value)) > 0.0
					If flag Then
						Me.dgvData.Rows(num3).DefaultCellStyle.BackColor = SystemColors.Highlight
					End If
					num3 += 1
				End While
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sLocDuLieu ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060015E5 RID: 5605 RVA: 0x0010DF84 File Offset: 0x0010C184
		Private Sub btnSLIn_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad = New frmNumPad()
				frmNumPad.ShowDialog()
				Dim flag As Boolean = frmNumPad.pbytSuccess = 1
				If flag Then
					Me.txtSLIn.Text = Conversions.ToString(frmNumPad.pSglNumberReturn)
				End If
				frmNumPad.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSLIn_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060015E6 RID: 5606 RVA: 0x0010E040 File Offset: 0x0010C240
		Private Sub cboSLIn_GotFocus(sender As Object, e As EventArgs)
			Try
				Me.txtOBJIDNH.Text = ""
				Me.txtLoc.Text = ""
				Me.cboSLIn.Focus()
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060015E7 RID: 5607 RVA: 0x0010E0A0 File Offset: 0x0010C2A0
		Private Sub cboSLIn_SelectedIndexChanged(sender As Object, e As EventArgs)
			Try
				Me.txtOBJIDNH.Text = ""
				Me.txtLoc.Text = ""
				Me.sLocDuLieu()
				Select Case Me.cboSLIn.SelectedIndex
					Case 0
						Try
							For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
								Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
								dataGridViewRow.Visible = True
							Next
						Finally
							Dim enumerator As IEnumerator
							Dim flag As Boolean = TypeOf enumerator Is IDisposable
							If flag Then
								TryCast(enumerator, IDisposable).Dispose()
							End If
						End Try
					Case 1
						Me.dgvData.CurrentCell = Nothing
						Try
							For Each obj2 As Object In CType(Me.dgvData.Rows, IEnumerable)
								Dim dataGridViewRow2 As DataGridViewRow = CType(obj2, DataGridViewRow)
								dataGridViewRow2.Visible = True
								Dim flag As Boolean = Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow2.Cells("QTYIN").Value)) = 0.0
								If flag Then
									dataGridViewRow2.Visible = False
								End If
							Next
						Finally
							Dim enumerator2 As IEnumerator
							Dim flag As Boolean = TypeOf enumerator2 Is IDisposable
							If flag Then
								TryCast(enumerator2, IDisposable).Dispose()
							End If
						End Try
					Case 2
						Me.dgvData.CurrentCell = Nothing
						Try
							For Each obj3 As Object In CType(Me.dgvData.Rows, IEnumerable)
								Dim dataGridViewRow3 As DataGridViewRow = CType(obj3, DataGridViewRow)
								dataGridViewRow3.Visible = True
								Dim flag As Boolean = Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow3.Cells("QTYIN").Value)) > 0.0
								If flag Then
									dataGridViewRow3.Visible = False
								End If
							Next
						Finally
							Dim enumerator3 As IEnumerator
							Dim flag As Boolean = TypeOf enumerator3 Is IDisposable
							If flag Then
								TryCast(enumerator3, IDisposable).Dispose()
							End If
						End Try
				End Select
				Me.sTinhTongSoLuongIn()
				Me.dgvData.Focus()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cboSLIn_SelectedIndexChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060015E8 RID: 5608 RVA: 0x0010E394 File Offset: 0x0010C594
		Private Sub btnSelAll_Click(sender As Object, e As EventArgs)
			Try
				Try
					For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
						Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
						Dim flag As Boolean = dataGridViewRow.Visible
						If flag Then
							dataGridViewRow.Cells("QTYIN").Value = Me.txtSLIn.Text.Replace(",", "")
							dataGridViewRow.DefaultCellStyle.BackColor = SystemColors.Highlight
							Dim text As String = dataGridViewRow.Cells("OBJID").Value.ToString().Trim()
							Dim num As Integer = CInt(Math.Round(Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("QTYIN").Value))))
							flag = Me.dicSelected.ContainsKey(text)
							If flag Then
								Me.dicSelected(text) = num
							Else
								Me.dicSelected.Add(text, num)
							End If
						End If
					Next
				Finally
					Dim enumerator As IEnumerator
					Dim flag As Boolean = TypeOf enumerator Is IDisposable
					If flag Then
						TryCast(enumerator, IDisposable).Dispose()
					End If
				End Try
				Me.sTinhTongSoLuongIn()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelAll_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060015E9 RID: 5609 RVA: 0x0010E570 File Offset: 0x0010C770
		Private Sub btnUnSelAll_Click(sender As Object, e As EventArgs)
			Try
				Try
					For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
						Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
						Dim flag As Boolean = dataGridViewRow.Visible And (Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("QTYIN").Value)) > 0.0)
						If flag Then
							dataGridViewRow.Cells("QTYIN").Value = "0"
							dataGridViewRow.DefaultCellStyle.BackColor = Color.White
						End If
						Me.dicSelected.Remove(dataGridViewRow.Cells("OBJID").Value.ToString().Trim())
					Next
				Finally
					Dim enumerator As IEnumerator
					Dim flag As Boolean = TypeOf enumerator Is IDisposable
					If flag Then
						TryCast(enumerator, IDisposable).Dispose()
					End If
				End Try
				Me.sTinhTongSoLuongIn()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnUnSelAll_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060015EA RID: 5610 RVA: 0x0010E6EC File Offset: 0x0010C8EC
		Private Sub sTinhTongSoLuongIn()
			' The following expression was wrapped in a checked-statement
			Try
				Dim num As Integer = 0
				Try
					For Each keyValuePair As KeyValuePair(Of String, Integer) In Me.dicSelected
						num += keyValuePair.Value
					Next
				Finally
					Dim enumerator As Dictionary(Of String, Integer).Enumerator
					CType(enumerator, IDisposable).Dispose()
				End Try
				Me.txtTongSLIn.Text = mdlUIForm.gfFormatNumber(CDbl(num), 0S, ",")
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sTinhTongSoLuongIn ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060015EB RID: 5611 RVA: 0x0010E7E0 File Offset: 0x0010C9E0
		Private Sub btnPrintBarcode_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.dicSelected.Keys.Count = 0
				If Not flag Then
					Me.Cursor = Cursors.WaitCursor
					Me.txtOBJIDNH.Text = ""
					Me.txtLoc.Text = ""
					Dim keyPressEventArgs As KeyPressEventArgs = New KeyPressEventArgs(vbCr)
					Me.txtLoc_KeyPress(RuntimeHelpers.GetObjectValue(sender), keyPressEventArgs)
					Me.cboSLIn.SelectedIndex = 1
					Thread.Sleep(100)
					Dim dataTable As DataTable = New DataTable()
					dataTable.Columns.Add("MaHang", Type.[GetType]("System.String"))
					dataTable.Columns.Add("TenHang", Type.[GetType]("System.String"))
					dataTable.Columns.Add("TenPhu", Type.[GetType]("System.String"))
					dataTable.Columns.Add("DVT", Type.[GetType]("System.String"))
					dataTable.Columns.Add("Gia1", Type.[GetType]("System.Double"))
					dataTable.Columns.Add("Gia2", Type.[GetType]("System.Double"))
					dataTable.Columns.Add("NhomHang", Type.[GetType]("System.String"))
					dataTable.Columns.Add("GhiChu", Type.[GetType]("System.String"))
					dataTable.Columns.Add("SoLuongIn", Type.[GetType]("System.Double"))
					Try
						For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
							Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
							flag = Conversion.Val(RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("QTYIN").Value)) <= 0.0
							If Not flag Then
								Dim dataRow As DataRow = dataTable.NewRow()
								dataRow("MaHang") = RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("OBJID").Value)
								dataRow("TenHang") = RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("OBJNAME").Value)
								dataRow("TenPhu") = RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("SUBOBJNAME").Value)
								dataRow("DVT") = RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("TENDVT").Value)
								dataRow("Gia1") = RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("PRICE1").Value)
								dataRow("Gia2") = RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("PRICE2").Value)
								dataRow("NhomHang") = RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("MANH").Value)
								dataRow("GhiChu") = RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("REMARK").Value)
								dataRow("SoLuongIn") = RuntimeHelpers.GetObjectValue(dataGridViewRow.Cells("QTYIN").Value)
								dataTable.Rows.Add(dataRow)
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag = TypeOf enumerator Is IDisposable
						If flag Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
					Dim text As String = ""
					flag = Me.mStrLabelPath.Trim().Contains("\") AndAlso Me.mStrLabelPath.Trim().ToLower().EndsWith(".exe")
					If flag Then
						' The following expression was wrapped in a checked-expression
						text = Me.mStrLabelPath.Trim().Substring(0, Me.mStrLabelPath.Trim().LastIndexOf("\") + 1) + Me.mStrLabelFileName
					End If
					flag = dataTable IsNot Nothing
					If flag Then
						Dim flag2 As Boolean = Me.fExport2Excel(dataTable, text, Me.mStrLabelFont) = 0
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(38), MsgBoxStyle.Critical, Nothing)
						Else
							Me.StartOrShowProcess(Me.mStrLabelPath)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrintBarcode_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				Me.Cursor = Cursors.[Default]
			End Try
		End Sub

		' Token: 0x060015EC RID: 5612
		Private Declare Function SetForegroundWindow Lib "User32.dll" (handle As IntPtr) As Boolean

		' Token: 0x060015ED RID: 5613
		Private Declare Function ShowWindow Lib "User32.dll" (handle As IntPtr, nCmdShow As Integer) As Boolean

		' Token: 0x060015EE RID: 5614
		Private Declare Function IsIconic Lib "User32.dll" (handle As IntPtr) As Boolean

		' Token: 0x060015EF RID: 5615 RVA: 0x0010ECF4 File Offset: 0x0010CEF4
		Private Sub StartOrShowProcess(strProcessName As String)
			Try
				Dim process As Process = Process.Start(strProcessName)
				Thread.Sleep(2000)
				Dim mainWindowHandle As IntPtr = process.MainWindowHandle
				Dim flag As Boolean = frmDMHH1.IsIconic(mainWindowHandle)
				If flag Then
					frmDMHH1.ShowWindow(mainWindowHandle, 9)
				End If
				frmDMHH1.SetForegroundWindow(mainWindowHandle)
			Catch ex As Exception
			End Try
		End Sub

		' Token: 0x060015F0 RID: 5616 RVA: 0x0010ED5C File Offset: 0x0010CF5C
		Private Function fExport2Excel(ptblData As DataTable, Optional pstrPath As String = "", Optional pstrFontname As String = "") As Byte
			Dim b As Byte = 0
			Dim obj As Object = RuntimeHelpers.GetObjectValue(Interaction.CreateObject("Excel.Application", ""))
			Try
				Dim flag As Boolean = obj Is Nothing
				If flag Then
					Interaction.MsgBox(mdlVariable.gArrStrMess(62), MsgBoxStyle.OkOnly, Nothing)
				Else
					Dim obj2 As Object = obj
					NewLateBinding.LateSet(obj2, Nothing, "SheetsInNewWorkbook", New Object() { 1 }, Nothing, Nothing)
					NewLateBinding.LateCall(NewLateBinding.LateGet(obj2, Nothing, "Workbooks", New Object(-1) {}, Nothing, Nothing, Nothing), Nothing, "Add", New Object(-1) {}, Nothing, Nothing, Nothing, True)
					NewLateBinding.LateCall(NewLateBinding.LateGet(obj2, Nothing, "Worksheets", New Object() { 1 }, Nothing, Nothing, Nothing), Nothing, "Select", New Object(-1) {}, Nothing, Nothing, Nothing, True)
					Dim num As Integer = 0
					Dim num2 As Integer = 0
					Try
						For Each obj3 As Object In ptblData.Columns
							Dim dataColumn As DataColumn = CType(obj3, DataColumn)
							num += 1
							flag = pstrFontname.Trim().ToUpper().StartsWith("VNI")
							If flag Then
								NewLateBinding.LateSet(obj, Nothing, "Cells", New Object() { 1, num, mdlUIForm.gFontUNI_To_VNI(dataColumn.ColumnName).Trim() }, Nothing, Nothing)
							Else
								NewLateBinding.LateSet(obj, Nothing, "Cells", New Object() { 1, num, dataColumn.ColumnName.Trim() }, Nothing, Nothing)
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag = TypeOf enumerator Is IDisposable
						If flag Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
					Dim flag2 As Boolean
					Try
						For Each obj4 As Object In ptblData.Rows
							Dim dataRow As DataRow = CType(obj4, DataRow)
							num2 += 1
							num = 0
							Try
								For Each obj5 As Object In ptblData.Columns
									Dim dataColumn As DataColumn = CType(obj5, DataColumn)
									num += 1
									flag = Operators.CompareString(dataColumn.DataType.Name, "String", False) = 0
									If flag Then
										flag2 = pstrFontname.Trim().ToUpper().StartsWith("VNI")
										If flag2 Then
											NewLateBinding.LateSet(obj, Nothing, "Cells", New Object() { num2 + 1, num, "'" + mdlUIForm.gFontUNI_To_VNI(Conversions.ToString(dataRow(dataColumn.ColumnName))).Trim() }, Nothing, Nothing)
										Else
											NewLateBinding.LateSet(obj, Nothing, "Cells", New Object() { num2 + 1, num, "'" + dataRow(dataColumn.ColumnName).ToString().Trim() }, Nothing, Nothing)
										End If
									Else
										flag2 = pstrFontname.Trim().ToUpper().StartsWith("VNI")
										If flag2 Then
											flag = Operators.CompareString(dataColumn.ColumnName, "Gia1", False) = 0 OrElse Operators.CompareString(dataColumn.ColumnName, "Gia2", False) = 0
											If flag Then
												Dim num3 As Double = Conversion.Val(RuntimeHelpers.GetObjectValue(dataRow(dataColumn.ColumnName)))
												Dim text As String = Me.fFormatNumber(num3, CShort(mdlVariable.gbytDECNUMAMT))
												NewLateBinding.LateSet(obj, Nothing, "Cells", New Object() { num2 + 1, num, "'" + mdlUIForm.gFontUNI_To_VNI(text).Trim() }, Nothing, Nothing)
											Else
												NewLateBinding.LateSet(obj, Nothing, "Cells", New Object() { num2 + 1, num, mdlUIForm.gFontUNI_To_VNI(Conversions.ToString(dataRow(dataColumn.ColumnName))).Trim() }, Nothing, Nothing)
											End If
										Else
											flag2 = Operators.CompareString(dataColumn.ColumnName, "Gia1", False) = 0 OrElse Operators.CompareString(dataColumn.ColumnName, "Gia2", False) = 0
											If flag2 Then
												Dim num4 As Double = Conversion.Val(RuntimeHelpers.GetObjectValue(dataRow(dataColumn.ColumnName)))
												Dim text2 As String = Me.fFormatNumber(num4, CShort(mdlVariable.gbytDECNUMAMT))
												NewLateBinding.LateSet(obj, Nothing, "Cells", New Object() { num2 + 1, num, "'" + mdlUIForm.gFontUNI_To_VNI(text2).Trim() }, Nothing, Nothing)
											Else
												NewLateBinding.LateSet(obj, Nothing, "Cells", New Object() { num2 + 1, num, mdlUIForm.gFontUNI_To_VNI(Conversions.ToString(dataRow(dataColumn.ColumnName))).Trim() }, Nothing, Nothing)
											End If
										End If
									End If
								Next
							Finally
								Dim enumerator3 As IEnumerator
								flag2 = TypeOf enumerator3 Is IDisposable
								If flag2 Then
									TryCast(enumerator3, IDisposable).Dispose()
								End If
							End Try
						Next
					Finally
						Dim enumerator2 As IEnumerator
						flag2 = TypeOf enumerator2 Is IDisposable
						If flag2 Then
							TryCast(enumerator2, IDisposable).Dispose()
						End If
					End Try
					NewLateBinding.LateCall(NewLateBinding.LateGet(NewLateBinding.LateGet(obj2, Nothing, "Worksheets", New Object() { 1 }, Nothing, Nothing, Nothing), Nothing, "Columns", New Object(-1) {}, Nothing, Nothing, Nothing), Nothing, "AutoFit", New Object(-1) {}, Nothing, Nothing, Nothing, True)
					flag2 = pstrFontname.Trim().Length > 3
					If flag2 Then
						NewLateBinding.LateSetComplex(NewLateBinding.LateGet(NewLateBinding.LateGet(NewLateBinding.LateGet(obj2, Nothing, "Worksheets", New Object() { 1 }, Nothing, Nothing, Nothing), Nothing, "UsedRange", New Object(-1) {}, Nothing, Nothing, Nothing), Nothing, "Font", New Object(-1) {}, Nothing, Nothing, Nothing), Nothing, "Name", New Object() { pstrFontname.Trim() }, Nothing, Nothing, False, True)
					End If
					flag2 = pstrPath.Trim().Length = 0
					If flag2 Then
						NewLateBinding.LateSet(obj2, Nothing, "Visible", New Object() { True }, Nothing, Nothing)
					Else
						NewLateBinding.LateSet(obj2, Nothing, "DisplayAlerts", New Object() { False }, Nothing, Nothing)
						NewLateBinding.LateCall(NewLateBinding.LateGet(obj2, Nothing, "ActiveWorkbook", New Object(-1) {}, Nothing, Nothing, Nothing), Nothing, "SaveAs", New Object() { pstrPath.Trim() }, Nothing, Nothing, Nothing, True)
						NewLateBinding.LateCall(NewLateBinding.LateGet(obj2, Nothing, "ActiveWorkbook", New Object(-1) {}, Nothing, Nothing, Nothing), Nothing, "Close", New Object(-1) {}, Nothing, Nothing, Nothing, True)
						GC.Collect()
					End If
					obj2 = Nothing
					NewLateBinding.LateCall(NewLateBinding.LateGet(obj, Nothing, "Workbooks", New Object(-1) {}, Nothing, Nothing, Nothing), Nothing, "Close", New Object(-1) {}, Nothing, Nothing, Nothing, True)
					NewLateBinding.LateCall(obj, Nothing, "quit", New Object(-1) {}, Nothing, Nothing, Nothing, True)
					obj = Nothing
					Me.releaseObject(RuntimeHelpers.GetObjectValue(obj))
					b = 1
				End If
			Catch ex As Exception
				Dim flag2 As Boolean = ex.Message.StartsWith("Cannot access")
				If flag2 Then
					MessageBox.Show(pstrPath.Trim() + " " + mdlVariable.gArrStrMess(170), ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Hand)
				Else
					Interaction.MsgBox(mdlVariable.gArrStrMess(1) + vbCrLf & "frmDMHH1 - fExport2Excel " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
				End If
			Finally
				Dim flag2 As Boolean = obj IsNot Nothing
				If flag2 Then
					NewLateBinding.LateCall(NewLateBinding.LateGet(obj, Nothing, "Workbooks", New Object(-1) {}, Nothing, Nothing, Nothing), Nothing, "Close", New Object(-1) {}, Nothing, Nothing, Nothing, True)
					NewLateBinding.LateCall(obj, Nothing, "quit", New Object(-1) {}, Nothing, Nothing, Nothing, True)
					obj = Nothing
					Me.releaseObject(RuntimeHelpers.GetObjectValue(obj))
				End If
			End Try
			Return b
		End Function

		' Token: 0x060015F1 RID: 5617 RVA: 0x0010F664 File Offset: 0x0010D864
		Private Function fFormatNumber(pdblNumber As Double, pbytDec As Short) As String
			Dim text As String = ""
			Dim text2 As String = ""
			Try
				Dim text3 As String = ("N" + pbytDec.ToString()).Trim()
				Dim text4 As String = Math.Round(pdblNumber, CInt(pbytDec)).ToString(text3)
				Dim flag As Boolean = text4.IndexOf(".") > -1
				Dim text5 As String
				If flag Then
					text5 = text4.Substring(0, text4.IndexOf("."))
					text2 = text4.Substring(text4.IndexOf("."))
				Else
					text5 = text4
				End If
				text4 = text5.Replace(",", Me.mStrChar1000) + text2.Replace(".", Me.mStrCharLe)
				flag = Me.mBytCharMoneyPos = 1
				If flag Then
					text4 += Me.mStrCharMoney
				Else
					text4 = Me.mStrCharMoney + text4
				End If
				text = text4
			Catch ex As Exception
				Interaction.MsgBox(mdlVariable.gArrStrMess(2) + vbCrLf & "frmDMHH1 - fFormatNumber" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return text
		End Function

		' Token: 0x060015F2 RID: 5618 RVA: 0x0010F7A0 File Offset: 0x0010D9A0
		Private Sub releaseObject(obj As Object)
			Try
				Marshal.ReleaseComObject(RuntimeHelpers.GetObjectValue(obj))
				obj = Nothing
			Catch ex As Exception
				obj = Nothing
			Finally
				GC.Collect()
			End Try
		End Sub

		' Token: 0x060015F3 RID: 5619 RVA: 0x0010F7F8 File Offset: 0x0010D9F8
		Private Function fPrintDMHH(pstrMANH As String) As Byte
			Dim rptDMHH As rptDMHH = New rptDMHH()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMHH, "")
				Dim text As String = "2060400000"
				mdlReport.gsSetOfficeReport(rptDMHH, text)
				mdlReport.gsSetFontReport(rptDMHH)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMANH"
				array(0).Value = pstrMANH
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_GET_DMHH", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Dim num2 As Integer = 0
					Dim num3 As Integer = clsConnect.Rows.Count - 1
					Dim num4 As Integer = num2
					While True
						Dim num5 As Integer = num4
						Dim num6 As Integer = num3
						If num5 > num6 Then
							Exit For
						End If
						Dim flag2 As Boolean = Operators.ConditionalCompareObjectEqual(clsConnect.Rows(num4)("LSAVE"), True, False)
						If flag2 Then
							clsConnect.Rows(num4)("TONKHO") = Me.mArrStrFrmMess(58)
						Else
							clsConnect.Rows(num4)("TONKHO") = Me.mArrStrFrmMess(59)
						End If
						num4 += 1
					End While
					rptDMHH.SetDataSource(clsConnect)
					rptDMHH.DataDefinition.FormulaFields("fPluCode").Text = "{dtReport.OBJID}"
					rptDMHH.DataDefinition.FormulaFields("fPluName").Text = "{dtReport.OBJNAME}"
					rptDMHH.DataDefinition.FormulaFields("fUnit").Text = "{dtReport.TENDVT}"
					rptDMHH.DataDefinition.FormulaFields("fTaxName").Text = "{dtReport.TENTHUE}"
					rptDMHH.DataDefinition.FormulaFields("fInventory").Text = "{dtReport.TONKHO}"
					rptDMHH.DataDefinition.FormulaFields("fGroupName").Text = "{dtReport.TENNH}"
					mdlReport.gsSetTextReport(rptDMHH, "RPTDMHH")
					MyProject.Forms.frmReport.pSource = rptDMHH
					MyProject.Forms.frmReport.MaximizeBox = True
					Dim textObject As TextObject = CType(rptDMHH.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					rptDMHH.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMHH.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMHH " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMHH.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x040008D1 RID: 2257
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040008D3 RID: 2259
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x040008D4 RID: 2260
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x040008D5 RID: 2261
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x040008D6 RID: 2262
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x040008D7 RID: 2263
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x040008D8 RID: 2264
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x040008D9 RID: 2265
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x040008DA RID: 2266
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x040008DB RID: 2267
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x040008DC RID: 2268
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x040008DD RID: 2269
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x040008DE RID: 2270
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x040008DF RID: 2271
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x040008E0 RID: 2272
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x040008E1 RID: 2273
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x040008E2 RID: 2274
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040008E3 RID: 2275
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x040008E4 RID: 2276
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040008E5 RID: 2277
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040008E6 RID: 2278
		<AccessedThroughProperty("lblMANH")>
		Private _lblMANH As Label

		' Token: 0x040008E7 RID: 2279
		<AccessedThroughProperty("txtOBJNAMENH")>
		Private _txtOBJNAMENH As TextBox

		' Token: 0x040008E8 RID: 2280
		<AccessedThroughProperty("btnSelectNH")>
		Private _btnSelectNH As Button

		' Token: 0x040008E9 RID: 2281
		<AccessedThroughProperty("txtOBJIDNH")>
		Private _txtOBJIDNH As TextBox

		' Token: 0x040008EA RID: 2282
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040008EB RID: 2283
		<AccessedThroughProperty("tblpLuoi")>
		Private _tblpLuoi As TableLayoutPanel

		' Token: 0x040008EC RID: 2284
		<AccessedThroughProperty("btnEx")>
		Private _btnEx As Button

		' Token: 0x040008ED RID: 2285
		<AccessedThroughProperty("btnIm")>
		Private _btnIm As Button

		' Token: 0x040008EE RID: 2286
		<AccessedThroughProperty("btnSendData")>
		Private _btnSendData As Button

		' Token: 0x040008EF RID: 2287
		<AccessedThroughProperty("btnAddDefault2")>
		Private _btnAddDefault2 As Button

		' Token: 0x040008F0 RID: 2288
		<AccessedThroughProperty("txtLoc")>
		Private _txtLoc As TextBox

		' Token: 0x040008F1 RID: 2289
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x040008F2 RID: 2290
		<AccessedThroughProperty("cboSLIn")>
		Private _cboSLIn As ComboBox

		' Token: 0x040008F3 RID: 2291
		<AccessedThroughProperty("txtSLIn")>
		Private _txtSLIn As TextBox

		' Token: 0x040008F4 RID: 2292
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x040008F5 RID: 2293
		<AccessedThroughProperty("btnSLIn")>
		Private _btnSLIn As Button

		' Token: 0x040008F6 RID: 2294
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x040008F7 RID: 2295
		<AccessedThroughProperty("btnSelAll")>
		Private _btnSelAll As Button

		' Token: 0x040008F8 RID: 2296
		<AccessedThroughProperty("btnUnSelAll")>
		Private _btnUnSelAll As Button

		' Token: 0x040008F9 RID: 2297
		<AccessedThroughProperty("ToolTip1")>
		Private _ToolTip1 As ToolTip

		' Token: 0x040008FA RID: 2298
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x040008FB RID: 2299
		<AccessedThroughProperty("txtTongSLIn")>
		Private _txtTongSLIn As TextBox

		' Token: 0x040008FC RID: 2300
		<AccessedThroughProperty("btnPrintBarcode")>
		Private _btnPrintBarcode As Button

		' Token: 0x040008FD RID: 2301
		Private mArrOBJID As String()

		' Token: 0x040008FE RID: 2302
		Private mArrOBJNAME As String()

		' Token: 0x040008FF RID: 2303
		Private mBlnSelect As Boolean

		' Token: 0x04000900 RID: 2304
		Private mArrStrFrmMess As String()

		' Token: 0x04000901 RID: 2305
		Private mStrOBJID As String

		' Token: 0x04000902 RID: 2306
		Private mStrOBJNAME As String

		' Token: 0x04000903 RID: 2307
		Private mStrMADVT As String

		' Token: 0x04000904 RID: 2308
		Private mStrTENDVT As String

		' Token: 0x04000905 RID: 2309
		Private mStrPRICE1 As String

		' Token: 0x04000906 RID: 2310
		Private mblnLSAVE As Boolean

		' Token: 0x04000907 RID: 2311
		Private mbytRATE As Byte

		' Token: 0x04000908 RID: 2312
		Private mStrFilter As String

		' Token: 0x04000909 RID: 2313
		Private mBytOpen_FromMenu As Byte

		' Token: 0x0400090A RID: 2314
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x0400090B RID: 2315
		Private marrDrFind As DataRow()

		' Token: 0x0400090C RID: 2316
		Private mintFindLastPos As Integer

		' Token: 0x0400090D RID: 2317
		Private mblnAutoAdd_DMHH As Boolean

		' Token: 0x0400090E RID: 2318
		Private mbytLen_OBJID As Byte

		' Token: 0x0400090F RID: 2319
		Private mclsTbDMNH As clsConnect

		' Token: 0x04000910 RID: 2320
		Private marrDblPrice As Double()

		' Token: 0x04000911 RID: 2321
		Private mbytImage As Byte()

		' Token: 0x04000912 RID: 2322
		Private mintMouseDown As Integer

		' Token: 0x04000913 RID: 2323
		Private mintMouseUp As Integer

		' Token: 0x04000914 RID: 2324
		Private mblnSelectRow As Boolean

		' Token: 0x04000915 RID: 2325
		Private dicSelected As Dictionary(Of String, Integer)

		' Token: 0x04000916 RID: 2326
		Private mStrLabelPath As String

		' Token: 0x04000917 RID: 2327
		Private mStrLabelFont As String

		' Token: 0x04000918 RID: 2328
		Private mStrChar1000 As String

		' Token: 0x04000919 RID: 2329
		Private mStrCharLe As String

		' Token: 0x0400091A RID: 2330
		Private mStrCharMoney As String

		' Token: 0x0400091B RID: 2331
		Private mBytCharMoneyPos As Byte

		' Token: 0x0400091C RID: 2332
		Private mStrLabelFileName As String

		' Token: 0x0400091D RID: 2333
		Private Const SW_RESTORE As Integer = 9
	End Class
End Namespace
