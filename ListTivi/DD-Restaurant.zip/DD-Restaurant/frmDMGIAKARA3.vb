﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200004B RID: 75
	<DesignerGenerated()>
	Public Partial Class frmDMGIAKARA3
		Inherits Form

		' Token: 0x06001461 RID: 5217 RVA: 0x000F808C File Offset: 0x000F628C
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMDNKM3_Activated
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMDNKM3_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMDNKM3_Load
			frmDMGIAKARA3.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSourceMas = New BindingSource()
			Me.mbdsSourceDel = New BindingSource()
			Me.mdgvMaster = New DataGridView()
			Me.mstrStockName = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000715 RID: 1813
		' (get) Token: 0x06001464 RID: 5220 RVA: 0x000F9924 File Offset: 0x000F7B24
		' (set) Token: 0x06001465 RID: 5221 RVA: 0x00005093 File Offset: 0x00003293
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000716 RID: 1814
		' (get) Token: 0x06001466 RID: 5222 RVA: 0x000F993C File Offset: 0x000F7B3C
		' (set) Token: 0x06001467 RID: 5223 RVA: 0x000F9954 File Offset: 0x000F7B54
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000717 RID: 1815
		' (get) Token: 0x06001468 RID: 5224 RVA: 0x000F99C0 File Offset: 0x000F7BC0
		' (set) Token: 0x06001469 RID: 5225 RVA: 0x000F99D8 File Offset: 0x000F7BD8
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000718 RID: 1816
		' (get) Token: 0x0600146A RID: 5226 RVA: 0x000F9A44 File Offset: 0x000F7C44
		' (set) Token: 0x0600146B RID: 5227 RVA: 0x000F9A5C File Offset: 0x000F7C5C
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000719 RID: 1817
		' (get) Token: 0x0600146C RID: 5228 RVA: 0x000F9AC8 File Offset: 0x000F7CC8
		' (set) Token: 0x0600146D RID: 5229 RVA: 0x0000509D File Offset: 0x0000329D
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x1700071A RID: 1818
		' (get) Token: 0x0600146E RID: 5230 RVA: 0x000F9AE0 File Offset: 0x000F7CE0
		' (set) Token: 0x0600146F RID: 5231 RVA: 0x000F9AF8 File Offset: 0x000F7CF8
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x1700071B RID: 1819
		' (get) Token: 0x06001470 RID: 5232 RVA: 0x000F9B64 File Offset: 0x000F7D64
		' (set) Token: 0x06001471 RID: 5233 RVA: 0x000F9B7C File Offset: 0x000F7D7C
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x1700071C RID: 1820
		' (get) Token: 0x06001472 RID: 5234 RVA: 0x000F9BE8 File Offset: 0x000F7DE8
		' (set) Token: 0x06001473 RID: 5235 RVA: 0x000050A7 File Offset: 0x000032A7
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x1700071D RID: 1821
		' (get) Token: 0x06001474 RID: 5236 RVA: 0x000F9C00 File Offset: 0x000F7E00
		' (set) Token: 0x06001475 RID: 5237 RVA: 0x000F9C18 File Offset: 0x000F7E18
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x1700071E RID: 1822
		' (get) Token: 0x06001476 RID: 5238 RVA: 0x000F9C84 File Offset: 0x000F7E84
		' (set) Token: 0x06001477 RID: 5239 RVA: 0x000F9C9C File Offset: 0x000F7E9C
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x1700071F RID: 1823
		' (get) Token: 0x06001478 RID: 5240 RVA: 0x000F9D08 File Offset: 0x000F7F08
		' (set) Token: 0x06001479 RID: 5241 RVA: 0x000F9D20 File Offset: 0x000F7F20
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000720 RID: 1824
		' (get) Token: 0x0600147A RID: 5242 RVA: 0x000F9D8C File Offset: 0x000F7F8C
		' (set) Token: 0x0600147B RID: 5243 RVA: 0x000050B1 File Offset: 0x000032B1
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x17000721 RID: 1825
		' (get) Token: 0x0600147C RID: 5244 RVA: 0x000F9DA4 File Offset: 0x000F7FA4
		' (set) Token: 0x0600147D RID: 5245 RVA: 0x000050BB File Offset: 0x000032BB
		Friend Overridable Property lblFromTime As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFromTime = value
			End Set
		End Property

		' Token: 0x17000722 RID: 1826
		' (get) Token: 0x0600147E RID: 5246 RVA: 0x000F9DBC File Offset: 0x000F7FBC
		' (set) Token: 0x0600147F RID: 5247 RVA: 0x000050C5 File Offset: 0x000032C5
		Friend Overridable Property lblTungay As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTungay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTungay = value
			End Set
		End Property

		' Token: 0x17000723 RID: 1827
		' (get) Token: 0x06001480 RID: 5248 RVA: 0x000F9DD4 File Offset: 0x000F7FD4
		' (set) Token: 0x06001481 RID: 5249 RVA: 0x000050CF File Offset: 0x000032CF
		Friend Overridable Property lblTen As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTen
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTen = value
			End Set
		End Property

		' Token: 0x17000724 RID: 1828
		' (get) Token: 0x06001482 RID: 5250 RVA: 0x000F9DEC File Offset: 0x000F7FEC
		' (set) Token: 0x06001483 RID: 5251 RVA: 0x000050D9 File Offset: 0x000032D9
		Friend Overridable Property txtTen As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTen
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTen = value
			End Set
		End Property

		' Token: 0x17000725 RID: 1829
		' (get) Token: 0x06001484 RID: 5252 RVA: 0x000F9E04 File Offset: 0x000F8004
		' (set) Token: 0x06001485 RID: 5253 RVA: 0x000F9E1C File Offset: 0x000F801C
		Friend Overridable Property btnPrintMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrintMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrintMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrintMas.Click, AddressOf Me.btnPrintMas_Click
				End If
				Me._btnPrintMas = value
				flag = Me._btnPrintMas IsNot Nothing
				If flag Then
					AddHandler Me._btnPrintMas.Click, AddressOf Me.btnPrintMas_Click
				End If
			End Set
		End Property

		' Token: 0x17000726 RID: 1830
		' (get) Token: 0x06001486 RID: 5254 RVA: 0x000F9E88 File Offset: 0x000F8088
		' (set) Token: 0x06001487 RID: 5255 RVA: 0x000F9EA0 File Offset: 0x000F80A0
		Friend Overridable Property btnDelMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelMas.Click, AddressOf Me.btnDelMas_Click
				End If
				Me._btnDelMas = value
				flag = Me._btnDelMas IsNot Nothing
				If flag Then
					AddHandler Me._btnDelMas.Click, AddressOf Me.btnDelMas_Click
				End If
			End Set
		End Property

		' Token: 0x17000727 RID: 1831
		' (get) Token: 0x06001488 RID: 5256 RVA: 0x000F9F0C File Offset: 0x000F810C
		' (set) Token: 0x06001489 RID: 5257 RVA: 0x000F9F24 File Offset: 0x000F8124
		Friend Overridable Property btnEditMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnEditMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnEditMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnEditMas.Click, AddressOf Me.btnEditMas_Click
				End If
				Me._btnEditMas = value
				flag = Me._btnEditMas IsNot Nothing
				If flag Then
					AddHandler Me._btnEditMas.Click, AddressOf Me.btnEditMas_Click
				End If
			End Set
		End Property

		' Token: 0x17000728 RID: 1832
		' (get) Token: 0x0600148A RID: 5258 RVA: 0x000F9F90 File Offset: 0x000F8190
		' (set) Token: 0x0600148B RID: 5259 RVA: 0x000F9FA8 File Offset: 0x000F81A8
		Friend Overridable Property btnFirstMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirstMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirstMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirstMas.Click, AddressOf Me.btnFirstMas_Click
				End If
				Me._btnFirstMas = value
				flag = Me._btnFirstMas IsNot Nothing
				If flag Then
					AddHandler Me._btnFirstMas.Click, AddressOf Me.btnFirstMas_Click
				End If
			End Set
		End Property

		' Token: 0x17000729 RID: 1833
		' (get) Token: 0x0600148C RID: 5260 RVA: 0x000FA014 File Offset: 0x000F8214
		' (set) Token: 0x0600148D RID: 5261 RVA: 0x000FA02C File Offset: 0x000F822C
		Friend Overridable Property btnPreMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreMas.Click, AddressOf Me.btnPreMas_Click
				End If
				Me._btnPreMas = value
				flag = Me._btnPreMas IsNot Nothing
				If flag Then
					AddHandler Me._btnPreMas.Click, AddressOf Me.btnPreMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700072A RID: 1834
		' (get) Token: 0x0600148E RID: 5262 RVA: 0x000FA098 File Offset: 0x000F8298
		' (set) Token: 0x0600148F RID: 5263 RVA: 0x000FA0B0 File Offset: 0x000F82B0
		Friend Overridable Property btnNextMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNextMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNextMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNextMas.Click, AddressOf Me.btnNextMas_Click
				End If
				Me._btnNextMas = value
				flag = Me._btnNextMas IsNot Nothing
				If flag Then
					AddHandler Me._btnNextMas.Click, AddressOf Me.btnNextMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700072B RID: 1835
		' (get) Token: 0x06001490 RID: 5264 RVA: 0x000FA11C File Offset: 0x000F831C
		' (set) Token: 0x06001491 RID: 5265 RVA: 0x000FA134 File Offset: 0x000F8334
		Friend Overridable Property btnLastMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLastMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLastMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLastMas.Click, AddressOf Me.btnLastMas_Click
				End If
				Me._btnLastMas = value
				flag = Me._btnLastMas IsNot Nothing
				If flag Then
					AddHandler Me._btnLastMas.Click, AddressOf Me.btnLastMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700072C RID: 1836
		' (get) Token: 0x06001492 RID: 5266 RVA: 0x000FA1A0 File Offset: 0x000F83A0
		' (set) Token: 0x06001493 RID: 5267 RVA: 0x000050E3 File Offset: 0x000032E3
		Friend Overridable Property lblDengio As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDengio
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDengio = value
			End Set
		End Property

		' Token: 0x1700072D RID: 1837
		' (get) Token: 0x06001494 RID: 5268 RVA: 0x000FA1B8 File Offset: 0x000F83B8
		' (set) Token: 0x06001495 RID: 5269 RVA: 0x000050ED File Offset: 0x000032ED
		Friend Overridable Property lblDenngay As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDenngay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDenngay = value
			End Set
		End Property

		' Token: 0x1700072E RID: 1838
		' (get) Token: 0x06001496 RID: 5270 RVA: 0x000FA1D0 File Offset: 0x000F83D0
		' (set) Token: 0x06001497 RID: 5271 RVA: 0x000050F7 File Offset: 0x000032F7
		Friend Overridable Property mtxFromDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxFromDate = value
			End Set
		End Property

		' Token: 0x1700072F RID: 1839
		' (get) Token: 0x06001498 RID: 5272 RVA: 0x000FA1E8 File Offset: 0x000F83E8
		' (set) Token: 0x06001499 RID: 5273 RVA: 0x00005101 File Offset: 0x00003301
		Friend Overridable Property mtxToDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxToDate = value
			End Set
		End Property

		' Token: 0x17000730 RID: 1840
		' (get) Token: 0x0600149A RID: 5274 RVA: 0x000FA200 File Offset: 0x000F8400
		' (set) Token: 0x0600149B RID: 5275 RVA: 0x0000510B File Offset: 0x0000330B
		Friend Overridable Property mtxFromTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxFromTime = value
			End Set
		End Property

		' Token: 0x17000731 RID: 1841
		' (get) Token: 0x0600149C RID: 5276 RVA: 0x000FA218 File Offset: 0x000F8418
		' (set) Token: 0x0600149D RID: 5277 RVA: 0x00005115 File Offset: 0x00003315
		Friend Overridable Property mtxToTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxToTime = value
			End Set
		End Property

		' Token: 0x17000732 RID: 1842
		' (get) Token: 0x0600149E RID: 5278 RVA: 0x000FA230 File Offset: 0x000F8430
		' (set) Token: 0x0600149F RID: 5279 RVA: 0x0000511F File Offset: 0x0000331F
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000733 RID: 1843
		' (get) Token: 0x060014A0 RID: 5280 RVA: 0x000FA248 File Offset: 0x000F8448
		' (set) Token: 0x060014A1 RID: 5281 RVA: 0x000FA260 File Offset: 0x000F8460
		Private Overridable Property mbdsSourceMas As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceMas IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceMas.PositionChanged, AddressOf Me.mbdsSourceMas_PositionChanged
				End If
				Me._mbdsSourceMas = value
				flag = Me._mbdsSourceMas IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceMas.PositionChanged, AddressOf Me.mbdsSourceMas_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000734 RID: 1844
		' (get) Token: 0x060014A2 RID: 5282 RVA: 0x000FA2CC File Offset: 0x000F84CC
		' (set) Token: 0x060014A3 RID: 5283 RVA: 0x000FA2E4 File Offset: 0x000F84E4
		Private Overridable Property mbdsSourceDel As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceDel IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceDel.PositionChanged, AddressOf Me.mbdsSourceDel_PositionChanged
				End If
				Me._mbdsSourceDel = value
				flag = Me._mbdsSourceDel IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceDel.PositionChanged, AddressOf Me.mbdsSourceDel_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000735 RID: 1845
		' (get) Token: 0x060014A4 RID: 5284 RVA: 0x000FA350 File Offset: 0x000F8550
		' (set) Token: 0x060014A5 RID: 5285 RVA: 0x00005129 File Offset: 0x00003329
		Public Property pdgvMaster As DataGridView
			Get
				Return Me.mdgvMaster
			End Get
			Set(value As DataGridView)
				Me.mdgvMaster = value
			End Set
		End Property

		' Token: 0x17000736 RID: 1846
		' (get) Token: 0x060014A6 RID: 5286 RVA: 0x000FA368 File Offset: 0x000F8568
		' (set) Token: 0x060014A7 RID: 5287 RVA: 0x00005134 File Offset: 0x00003334
		Public Property pbdsSource As BindingSource
			Get
				Return Me.mbdsSourceMas
			End Get
			Set(value As BindingSource)
				Me.mbdsSourceMas = value
			End Set
		End Property

		' Token: 0x17000737 RID: 1847
		' (get) Token: 0x060014A8 RID: 5288 RVA: 0x000FA380 File Offset: 0x000F8580
		' (set) Token: 0x060014A9 RID: 5289 RVA: 0x00005140 File Offset: 0x00003340
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000738 RID: 1848
		' (get) Token: 0x060014AA RID: 5290 RVA: 0x000FA398 File Offset: 0x000F8598
		' (set) Token: 0x060014AB RID: 5291 RVA: 0x0000514B File Offset: 0x0000334B
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060014AC RID: 5292 RVA: 0x000FA3B0 File Offset: 0x000F85B0
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014AD RID: 5293 RVA: 0x000FA480 File Offset: 0x000F8680
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceDel.Position
				Dim flag As Boolean = position < Me.mbdsSourceDel.Count - 1
				If flag Then
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					mbdsSourceDel.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014AE RID: 5294 RVA: 0x000FA570 File Offset: 0x000F8770
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceDel.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					mbdsSourceDel.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014AF RID: 5295 RVA: 0x000FA654 File Offset: 0x000F8854
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSourceDel.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014B0 RID: 5296 RVA: 0x000FA718 File Offset: 0x000F8918
		Private Sub btnLastMas_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSourceMas.Position = Me.mbdsSourceMas.Count - 1
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLastMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014B1 RID: 5297 RVA: 0x000FA7CC File Offset: 0x000F89CC
		Private Sub btnNextMas_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceMas.Position
				Dim flag As Boolean = position < Me.mbdsSourceMas.Count - 1
				If flag Then
					Dim mbdsSourceMas As BindingSource = Me.mbdsSourceMas
					mbdsSourceMas.Position += 1
				End If
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNextMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014B2 RID: 5298 RVA: 0x000FA8A8 File Offset: 0x000F8AA8
		Private Sub btnPreMas_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceMas.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSourceMas As BindingSource = Me.mbdsSourceMas
					mbdsSourceMas.Position -= 1
				End If
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014B3 RID: 5299 RVA: 0x000FA978 File Offset: 0x000F8B78
		Private Sub btnFirstMas_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSourceMas.Position = 0
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirstMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014B4 RID: 5300 RVA: 0x00005156 File Offset: 0x00003356
		Private Sub frmDMDNKM3_Activated(sender As Object, e As EventArgs)
			Me.fGetData_4Grid()
			Me.fShow_DatainText()
		End Sub

		' Token: 0x060014B5 RID: 5301 RVA: 0x000FAA20 File Offset: 0x000F8C20
		Private Sub frmDMDNKM3_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM3_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014B6 RID: 5302 RVA: 0x000FAAB8 File Offset: 0x000F8CB8
		Private Sub frmDMDNKM3_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mbdsSourceMas_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					b = Me.fShow_DatainText()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM3_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014B7 RID: 5303 RVA: 0x000FABD4 File Offset: 0x000F8DD4
		Private Sub mbdsSourceDel_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSourceDel.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					Me.lblPosition.Text = (mbdsSourceDel.Position + 1).ToString() + " / " + mbdsSourceDel.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceDel_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014B8 RID: 5304 RVA: 0x000FACDC File Offset: 0x000F8EDC
		Private Sub mbdsSourceMas_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSourceMas.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButtonMas(True)
				Else
					Dim b As Byte = Me.fDisableButtonMas(False)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceMas_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014B9 RID: 5305 RVA: 0x000FAD98 File Offset: 0x000F8F98
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014BA RID: 5306 RVA: 0x000FAE30 File Offset: 0x000F9030
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = Me.fAdd_frmDOCUMENT4()
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0
				If flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Find("KHOACHINH", text)
						Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060014BB RID: 5307 RVA: 0x000FAF64 File Offset: 0x000F9164
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim frmDMGIAKARA As frmDMGIAKARA5 = New frmDMGIAKARA5()
			Try
				frmDMGIAKARA.txtOBJID.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
				frmDMGIAKARA.txtOBJNAME.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJNAME").Value)
				frmDMGIAKARA.txtPRICE.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("GIATIEN").Value)
				Dim flag As Boolean = Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("TIMEKINDORG").Value, 0, False)
				If flag Then
					frmDMGIAKARA.txtPRICE.Text = Conversions.ToString(NewLateBinding.LateGet(Nothing, GetType(Math), "Round", New Object() { Operators.MultiplyObject(Me.dgvData.CurrentRow.Cells("GIATIEN").Value, 60) }, Nothing, Nothing, Nothing))
				End If
				frmDMGIAKARA.txtPrice12.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("GIATIEN12").Value)
				frmDMGIAKARA.txtTimeFrom.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TIMEFROM").Value)
				frmDMGIAKARA.txttimeTo.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TIMETO").Value)
				frmDMGIAKARA.txtLOTMM.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("LOTMM").Value)
				frmDMGIAKARA.pbytTimeKind = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("TIMEKINDORG").Value)
				frmDMGIAKARA.pbytFromStatus = 3
				frmDMGIAKARA.pStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMGIAKARA.ShowDialog()
				flag = frmDMGIAKARA.pbytSuccess = 0
				If flag Then
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnsua ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x060014BC RID: 5308 RVA: 0x000FB2A0 File Offset: 0x000F94A0
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim frmDMGIAKARA As frmDMGIAKARA5 = New frmDMGIAKARA5()
			Try
				frmDMGIAKARA.txtOBJID.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
				frmDMGIAKARA.txtOBJNAME.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJNAME").Value)
				frmDMGIAKARA.txtPRICE.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("GIATIEN").Value)
				frmDMGIAKARA.txtPrice12.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("GIATIEN12").Value)
				frmDMGIAKARA.txtTimeFrom.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TIMEFROM").Value)
				frmDMGIAKARA.txttimeTo.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TIMETO").Value)
				frmDMGIAKARA.txtLOTMM.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("LOTMM").Value)
				frmDMGIAKARA.pbytTimeKind = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("TIMEKINDORG").Value)
				frmDMGIAKARA.pbytFromStatus = 4
				frmDMGIAKARA.pStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMGIAKARA.ShowDialog()
				Dim flag As Boolean = frmDMGIAKARA.pbytSuccess = 0
				If flag Then
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btn xoa ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x060014BD RID: 5309 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnPrintMas_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x060014BE RID: 5310 RVA: 0x000FB53C File Offset: 0x000F973C
		Private Sub btnDelMas_Click(sender As Object, e As EventArgs)
			Dim frmDMGIAKARA As frmDMGIAKARA2 = New frmDMGIAKARA2()
			Try
				Dim frmDMGIAKARA2 As frmDMGIAKARA2 = frmDMGIAKARA
				frmDMGIAKARA2.pbytFromStatus = 4
				frmDMGIAKARA2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMGIAKARA2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMGIAKARA2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("MAKH").Value, ""))
				frmDMGIAKARA2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMGIAKARA2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMGIAKARA2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMGIAKARA2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMGIAKARA2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
				frmDMGIAKARA.ShowDialog()
				Dim flag As Boolean = frmDMGIAKARA.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = mdlVariable.gfrmDMGIAKARA1.gfGetData_4Grid()
					flag = b <> 0
					If flag Then
						Me.fShow_DatainText()
					End If
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x060014BF RID: 5311 RVA: 0x000FBA28 File Offset: 0x000F9C28
		Private Sub btnEditMas_Click(sender As Object, e As EventArgs)
			Dim frmDMGIAKARA As frmDMGIAKARA2 = New frmDMGIAKARA2()
			Try
				Dim frmDMGIAKARA2 As frmDMGIAKARA2 = frmDMGIAKARA
				frmDMGIAKARA2.pbytFromStatus = 3
				frmDMGIAKARA2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMGIAKARA2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMGIAKARA2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("MAKH").Value, ""))
				frmDMGIAKARA2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMGIAKARA2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMGIAKARA2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMGIAKARA2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMGIAKARA2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
				frmDMGIAKARA.ShowDialog()
				Dim flag As Boolean = frmDMGIAKARA.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = mdlVariable.gfrmDMGIAKARA1.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						Me.fShow_DatainText()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x060014C0 RID: 5312 RVA: 0x000FBF2C File Offset: 0x000FA12C
		Private Function fAdd_frmDOCUMENT4() As String
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim frmDMGIAKARA As frmDMGIAKARA5 = New frmDMGIAKARA5()
			Dim text As String = ""
			Try
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAGIAKARA"
				array(0).Value = Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, "")
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pintResult"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMGIAKARA2_GET_MAX_OBJID", flag)
				Dim flag2 As Boolean = flag
				If flag2 Then
					frmDMGIAKARA.txtOBJID.Text = Strings.Right("000" + array(1).Value.ToString(), 3)
				End If
				frmDMGIAKARA.pbytFromStatus = 1
				frmDMGIAKARA.pStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMGIAKARA.ShowDialog()
				flag2 = frmDMGIAKARA.pbytSuccess = 0
				If flag2 Then
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAdd_frmDOCUMENT4 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMGIAKARA.Dispose()
			End Try
			Return text
		End Function

		' Token: 0x060014C1 RID: 5313 RVA: 0x000FC118 File Offset: 0x000FA318
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.Columns("MAGIAKARA").Visible = False
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("OBJID").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("OBJNAME").Width = Me.Width - 310 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("GIATIEN").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("GIATIEN").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("GIATIEN").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TIMEKIND").HeaderText = Strings.Trim(Me.mArrStrFrmMess(28))
				dgvData.Columns("TIMEKIND").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TIMEKIND").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TIMEFROM").HeaderText = Strings.Trim(Me.mArrStrFrmMess(39))
				dgvData.Columns("TIMEFROM").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("TIMEFROM").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TIMETO").HeaderText = Strings.Trim(Me.mArrStrFrmMess(40))
				dgvData.Columns("TIMETO").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("TIMETO").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LOTMM").HeaderText = Strings.Trim(Me.mArrStrFrmMess(41))
				dgvData.Columns("LOTMM").Width = 300
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("LOTMM").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TIMEKINDORG").Visible = False
				dgvData.Columns("GIATIEN12").Visible = False
				dgvData.Columns("LOTMM").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060014C2 RID: 5314 RVA: 0x000FC530 File Offset: 0x000FA730
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060014C3 RID: 5315 RVA: 0x000FC638 File Offset: 0x000FA838
		Private Function fDisableButtonMas(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirstMas.Enabled = Not pblnDisable
				Me.btnLastMas.Enabled = Not pblnDisable
				Me.btnPreMas.Enabled = Not pblnDisable
				Me.btnNextMas.Enabled = Not pblnDisable
				Me.btnPrintMas.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButtonMas ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060014C4 RID: 5316 RVA: 0x000FC720 File Offset: 0x000FA920
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@PNVCHPHUT"
				array(0).Value = Me.mArrStrFrmMess(35).ToString()
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@PNVCHGIO"
				array(1).Value = Me.mArrStrFrmMess(36).ToString()
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@PNVCHNGAY"
				array(2).Value = Me.mArrStrFrmMess(37).ToString()
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@PNVCHTHANG"
				array(3).Value = Me.mArrStrFrmMess(38).ToString()
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@PNVCHGIORIENG"
				array(4).Value = Me.mArrStrFrmMess(42).ToString()
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "GET_DATA_DMGIAKARA2", num)
				Me.mbdsSourceDel.DataSource = clsConnect
				Me.dgvData.DataSource = Me.mbdsSourceDel
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060014C5 RID: 5317 RVA: 0x000FC920 File Offset: 0x000FAB20
		Private Function fShow_DatainText() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.txtTen.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJNAME").Value, ""))
				Me.mtxFromDate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("TUNGAY").Value, ""))
				Me.mtxToDate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("DENNGAY").Value, ""))
				Me.mtxFromTime.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("TUGIO").Value, ""))
				Me.mtxToTime.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("DENGIO").Value, ""))
				Me.mbdsSourceDel.Filter = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("MAGIAKARA ='", Me.mdgvMaster.CurrentRow.Cells("OBJID").Value), ""), "'"))
				mdlUIForm.gsSetCap_2Form(Me, String.Concat(New String() { Me.mArrStrFrmMess(2), " ", Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))), Me.mArrStrFrmMess(16), " [", Me.mstrStockName, "]" }))
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fShow_DatainText ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060014C6 RID: 5318 RVA: 0x000FCBC8 File Offset: 0x000FADC8
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.txtTen.[ReadOnly] = True
				Me.mtxFromDate.[ReadOnly] = True
				Me.mtxToDate.[ReadOnly] = True
				Me.mtxFromTime.[ReadOnly] = True
				Me.mtxToTime.[ReadOnly] = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060014C7 RID: 5319 RVA: 0x000FCCBC File Offset: 0x000FAEBC
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mstrStockName = Strings.Trim(mdlDatabase.gfGetNameFromID(mdlVariable.gStrConISDANHMUC, "DMKH", "OBJID", Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("MAKH").Value, "")), "OBJNAME"))
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, String.Concat(New String() { Me.mArrStrFrmMess(2), " ", Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))), Me.mArrStrFrmMess(16), " [", Me.mstrStockName, "]" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060014C8 RID: 5320 RVA: 0x000FCEAC File Offset: 0x000FB0AC
		Private Sub sClear_Form()
			Try
				Me.mbdsSourceDel.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x04000873 RID: 2163
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000875 RID: 2165
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000876 RID: 2166
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000877 RID: 2167
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000878 RID: 2168
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000879 RID: 2169
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x0400087A RID: 2170
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x0400087B RID: 2171
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x0400087C RID: 2172
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x0400087D RID: 2173
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x0400087E RID: 2174
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x0400087F RID: 2175
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000880 RID: 2176
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000881 RID: 2177
		<AccessedThroughProperty("lblFromTime")>
		Private _lblFromTime As Label

		' Token: 0x04000882 RID: 2178
		<AccessedThroughProperty("lblTungay")>
		Private _lblTungay As Label

		' Token: 0x04000883 RID: 2179
		<AccessedThroughProperty("lblTen")>
		Private _lblTen As Label

		' Token: 0x04000884 RID: 2180
		<AccessedThroughProperty("txtTen")>
		Private _txtTen As TextBox

		' Token: 0x04000885 RID: 2181
		<AccessedThroughProperty("btnPrintMas")>
		Private _btnPrintMas As Button

		' Token: 0x04000886 RID: 2182
		<AccessedThroughProperty("btnDelMas")>
		Private _btnDelMas As Button

		' Token: 0x04000887 RID: 2183
		<AccessedThroughProperty("btnEditMas")>
		Private _btnEditMas As Button

		' Token: 0x04000888 RID: 2184
		<AccessedThroughProperty("btnFirstMas")>
		Private _btnFirstMas As Button

		' Token: 0x04000889 RID: 2185
		<AccessedThroughProperty("btnPreMas")>
		Private _btnPreMas As Button

		' Token: 0x0400088A RID: 2186
		<AccessedThroughProperty("btnNextMas")>
		Private _btnNextMas As Button

		' Token: 0x0400088B RID: 2187
		<AccessedThroughProperty("btnLastMas")>
		Private _btnLastMas As Button

		' Token: 0x0400088C RID: 2188
		<AccessedThroughProperty("lblDengio")>
		Private _lblDengio As Label

		' Token: 0x0400088D RID: 2189
		<AccessedThroughProperty("lblDenngay")>
		Private _lblDenngay As Label

		' Token: 0x0400088E RID: 2190
		<AccessedThroughProperty("mtxFromDate")>
		Private _mtxFromDate As MaskedTextBox

		' Token: 0x0400088F RID: 2191
		<AccessedThroughProperty("mtxToDate")>
		Private _mtxToDate As MaskedTextBox

		' Token: 0x04000890 RID: 2192
		<AccessedThroughProperty("mtxFromTime")>
		Private _mtxFromTime As MaskedTextBox

		' Token: 0x04000891 RID: 2193
		<AccessedThroughProperty("mtxToTime")>
		Private _mtxToTime As MaskedTextBox

		' Token: 0x04000892 RID: 2194
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000893 RID: 2195
		Private mArrStrFrmMess As String()

		' Token: 0x04000894 RID: 2196
		Private mStrOBJID As String

		' Token: 0x04000895 RID: 2197
		Private mStrMAKM As String

		' Token: 0x04000896 RID: 2198
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000897 RID: 2199
		<AccessedThroughProperty("mbdsSourceMas")>
		Private _mbdsSourceMas As BindingSource

		' Token: 0x04000898 RID: 2200
		<AccessedThroughProperty("mbdsSourceDel")>
		Private _mbdsSourceDel As BindingSource

		' Token: 0x04000899 RID: 2201
		Private mdgvMaster As DataGridView

		' Token: 0x0400089A RID: 2202
		Private marrDrFind As DataRow()

		' Token: 0x0400089B RID: 2203
		Private mintFindLastPos As Integer

		' Token: 0x0400089C RID: 2204
		Private mstrStockName As String
	End Class
End Namespace
