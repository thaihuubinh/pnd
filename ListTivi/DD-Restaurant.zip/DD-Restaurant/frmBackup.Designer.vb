﻿Namespace prjIS_SalesPOS
	' Token: 0x02000019 RID: 25
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmBackup
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600037A RID: 890 RVA: 0x0002A938 File Offset: 0x00028B38
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600037B RID: 891 RVA: 0x0002A970 File Offset: 0x00028B70
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmBackup))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.grpSelect = New Global.System.Windows.Forms.GroupBox()
			Me.radNone = New Global.System.Windows.Forms.RadioButton()
			Me.cmbWeek = New Global.System.Windows.Forms.ComboBox()
			Me.radMonth = New Global.System.Windows.Forms.RadioButton()
			Me.radWeek = New Global.System.Windows.Forms.RadioButton()
			Me.radTurnOff = New Global.System.Windows.Forms.RadioButton()
			Me.nupDay = New Global.System.Windows.Forms.NumericUpDown()
			Me.btnPath = New Global.System.Windows.Forms.Button()
			Me.lblPath = New Global.System.Windows.Forms.Label()
			Me.txtPath = New Global.System.Windows.Forms.TextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.txtNumBackup = New Global.System.Windows.Forms.TextBox()
			Me.btnNumAll = New Global.System.Windows.Forms.Button()
			Me.btnNum0 = New Global.System.Windows.Forms.Button()
			Me.btnNumKey = New Global.System.Windows.Forms.Button()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.grpSelect.SuspendLayout()
			CType(Me.nupDay, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(573, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 520)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 4
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 0)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 5
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 499)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 399)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 97)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 3)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(107, 93)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 4
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.grpSelect.Controls.Add(Me.radNone)
			Me.grpSelect.Controls.Add(Me.cmbWeek)
			Me.grpSelect.Controls.Add(Me.radMonth)
			Me.grpSelect.Controls.Add(Me.radWeek)
			Me.grpSelect.Controls.Add(Me.radTurnOff)
			Me.grpSelect.Controls.Add(Me.nupDay)
			Me.grpSelect.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.grpSelect.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim grpSelect As Global.System.Windows.Forms.Control = Me.grpSelect
			point = New Global.System.Drawing.Point(17, 0)
			grpSelect.Location = point
			Dim grpSelect2 As Global.System.Windows.Forms.Control = Me.grpSelect
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			grpSelect2.Margin = padding
			Me.grpSelect.Name = "grpSelect"
			Dim grpSelect3 As Global.System.Windows.Forms.Control = Me.grpSelect
			padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			grpSelect3.Padding = padding
			Dim grpSelect4 As Global.System.Windows.Forms.Control = Me.grpSelect
			size = New Global.System.Drawing.Size(553, 213)
			grpSelect4.Size = size
			Me.grpSelect.TabIndex = 0
			Me.grpSelect.TabStop = False
			Me.radNone.AutoSize = True
			Dim radNone As Global.System.Windows.Forms.Control = Me.radNone
			point = New Global.System.Drawing.Point(12, 17)
			radNone.Location = point
			Me.radNone.Name = "radNone"
			Dim radNone2 As Global.System.Windows.Forms.Control = Me.radNone
			size = New Global.System.Drawing.Size(114, 20)
			radNone2.Size = size
			Me.radNone.TabIndex = 0
			Me.radNone.TabStop = True
			Me.radNone.Tag = "CR0012"
			Me.radNone.Text = "Sao lưu tức thì"
			Me.radNone.UseVisualStyleBackColor = True
			Me.cmbWeek.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbWeek.Font = New Global.System.Drawing.Font("Arial", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.cmbWeek.FormattingEnabled = True
			Dim cmbWeek As Global.System.Windows.Forms.Control = Me.cmbWeek
			point = New Global.System.Drawing.Point(262, 109)
			cmbWeek.Location = point
			Me.cmbWeek.Name = "cmbWeek"
			Dim cmbWeek2 As Global.System.Windows.Forms.Control = Me.cmbWeek
			size = New Global.System.Drawing.Size(110, 27)
			cmbWeek2.Size = size
			Me.cmbWeek.TabIndex = 3
			Me.radMonth.AutoSize = True
			Dim radMonth As Global.System.Windows.Forms.Control = Me.radMonth
			point = New Global.System.Drawing.Point(12, 166)
			radMonth.Location = point
			Me.radMonth.Name = "radMonth"
			Dim radMonth2 As Global.System.Windows.Forms.Control = Me.radMonth
			size = New Global.System.Drawing.Size(195, 20)
			radMonth2.Size = size
			Me.radMonth.TabIndex = 4
			Me.radMonth.TabStop = True
			Me.radMonth.Tag = "CR0009"
			Me.radMonth.Text = "Sao lưu hàng tháng vào ngày"
			Me.radMonth.UseVisualStyleBackColor = True
			Me.radWeek.AutoSize = True
			Dim radWeek As Global.System.Windows.Forms.Control = Me.radWeek
			point = New Global.System.Drawing.Point(12, 113)
			radWeek.Location = point
			Me.radWeek.Name = "radWeek"
			Dim radWeek2 As Global.System.Windows.Forms.Control = Me.radWeek
			size = New Global.System.Drawing.Size(180, 20)
			radWeek2.Size = size
			Me.radWeek.TabIndex = 2
			Me.radWeek.TabStop = True
			Me.radWeek.Tag = "CR0008"
			Me.radWeek.Text = "Sao lưu hàng tuần vào thứ"
			Me.radWeek.UseVisualStyleBackColor = True
			Me.radTurnOff.AutoSize = True
			Dim radTurnOff As Global.System.Windows.Forms.Control = Me.radTurnOff
			point = New Global.System.Drawing.Point(12, 63)
			radTurnOff.Location = point
			Me.radTurnOff.Name = "radTurnOff"
			Dim radTurnOff2 As Global.System.Windows.Forms.Control = Me.radTurnOff
			size = New Global.System.Drawing.Size(177, 20)
			radTurnOff2.Size = size
			Me.radTurnOff.TabIndex = 1
			Me.radTurnOff.TabStop = True
			Me.radTurnOff.Tag = "CR0007"
			Me.radTurnOff.Text = "Sao lưu lúc tắt phần mềm"
			Me.radTurnOff.UseVisualStyleBackColor = True
			Me.nupDay.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.nupDay.ImeMode = Global.System.Windows.Forms.ImeMode.NoControl
			Dim nupDay As Global.System.Windows.Forms.Control = Me.nupDay
			point = New Global.System.Drawing.Point(262, 160)
			nupDay.Location = point
			Dim nupDay2 As Global.System.Windows.Forms.NumericUpDown = Me.nupDay
			Dim num As Decimal = New Decimal(New Integer() { 12, 0, 0, 0 })
			nupDay2.Maximum = num
			Dim nupDay3 As Global.System.Windows.Forms.NumericUpDown = Me.nupDay
			num = New Decimal(New Integer() { 1, 0, 0, 0 })
			nupDay3.Minimum = num
			Me.nupDay.Name = "nupDay"
			Dim nupDay4 As Global.System.Windows.Forms.Control = Me.nupDay
			size = New Global.System.Drawing.Size(110, 35)
			nupDay4.Size = size
			Me.nupDay.TabIndex = 5
			Me.nupDay.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Dim nupDay5 As Global.System.Windows.Forms.NumericUpDown = Me.nupDay
			num = New Decimal(New Integer() { 1, 0, 0, 0 })
			nupDay5.Value = num
			Me.btnPath.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnPath As Global.System.Windows.Forms.Control = Me.btnPath
			point = New Global.System.Drawing.Point(531, 347)
			btnPath.Location = point
			Me.btnPath.Name = "btnPath"
			Dim btnPath2 As Global.System.Windows.Forms.Control = Me.btnPath
			size = New Global.System.Drawing.Size(40, 31)
			btnPath2.Size = size
			Me.btnPath.TabIndex = 3
			Me.btnPath.Tag = "CB0011"
			Me.btnPath.UseVisualStyleBackColor = True
			Me.lblPath.AutoSize = True
			Me.lblPath.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPath As Global.System.Windows.Forms.Control = Me.lblPath
			point = New Global.System.Drawing.Point(14, 328)
			lblPath.Location = point
			Me.lblPath.Name = "lblPath"
			Dim lblPath2 As Global.System.Windows.Forms.Control = Me.lblPath
			size = New Global.System.Drawing.Size(91, 16)
			lblPath2.Size = size
			Me.lblPath.TabIndex = 1
			Me.lblPath.Tag = "CB0010"
			Me.lblPath.Text = "Chọn nơi lưu"
			Me.txtPath.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtPath.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtPath As Global.System.Windows.Forms.Control = Me.txtPath
			point = New Global.System.Drawing.Point(17, 349)
			txtPath.Location = point
			Me.txtPath.Name = "txtPath"
			Dim txtPath2 As Global.System.Windows.Forms.Control = Me.txtPath
			size = New Global.System.Drawing.Size(514, 26)
			txtPath2.Size = size
			Me.txtPath.TabIndex = 2
			Me.txtPath.Tag = "0R0000"
			Me.Label1.AutoSize = True
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(17, 377)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(295, 30)
			label2.Size = size
			Me.Label1.TabIndex = 6
			Me.Label1.Text = "(Có thể nhập nhiều đường dẫn, cách nhau bởi dấu * " & vbCrLf & "Ví dụ: D:\Backup*C:\Backup*\\Server-PC\Backup )" & vbCrLf
			Me.Label2.AutoSize = True
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(14, 248)
			label3.Location = point
			Me.Label2.Name = "Label2"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(216, 16)
			label4.Size = size
			Me.Label2.TabIndex = 1
			Me.Label2.Tag = "CB0039"
			Me.Label2.Text = "Số tháng gần nhất muốn sao lưu"
			Me.txtNumBackup.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtNumBackup As Global.System.Windows.Forms.Control = Me.txtNumBackup
			point = New Global.System.Drawing.Point(279, 238)
			txtNumBackup.Location = point
			Me.txtNumBackup.Name = "txtNumBackup"
			Dim txtNumBackup2 As Global.System.Windows.Forms.Control = Me.txtNumBackup
			size = New Global.System.Drawing.Size(110, 35)
			txtNumBackup2.Size = size
			Me.txtNumBackup.TabIndex = 7
			Me.txtNumBackup.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.btnNumAll.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btnNumAll As Global.System.Windows.Forms.Control = Me.btnNumAll
			point = New Global.System.Drawing.Point(391, 231)
			btnNumAll.Location = point
			Me.btnNumAll.Name = "btnNumAll"
			Dim btnNumAll2 As Global.System.Windows.Forms.Control = Me.btnNumAll
			size = New Global.System.Drawing.Size(117, 24)
			btnNumAll2.Size = size
			Me.btnNumAll.TabIndex = 8
			Me.btnNumAll.Tag = "CR0040"
			Me.btnNumAll.Text = "[-1] Tất cả"
			Me.btnNumAll.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnNumAll.UseVisualStyleBackColor = True
			Me.btnNum0.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim btnNum As Global.System.Windows.Forms.Control = Me.btnNum0
			point = New Global.System.Drawing.Point(391, 256)
			btnNum.Location = point
			Me.btnNum0.Name = "btnNum0"
			Dim btnNum2 As Global.System.Windows.Forms.Control = Me.btnNum0
			size = New Global.System.Drawing.Size(117, 24)
			btnNum2.Size = size
			Me.btnNum0.TabIndex = 8
			Me.btnNum0.Tag = "CR0041"
			Me.btnNum0.Text = "[0] Chỉ danh mục"
			Me.btnNum0.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnNum0.UseVisualStyleBackColor = True
			Me.btnNumKey.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnNumKey.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Dim btnNumKey As Global.System.Windows.Forms.Control = Me.btnNumKey
			point = New Global.System.Drawing.Point(509, 231)
			btnNumKey.Location = point
			Me.btnNumKey.Name = "btnNumKey"
			Dim btnNumKey2 As Global.System.Windows.Forms.Control = Me.btnNumKey
			size = New Global.System.Drawing.Size(61, 49)
			btnNumKey2.Size = size
			Me.btnNumKey.TabIndex = 8
			Me.btnNumKey.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnNumKey.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(692, 520)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.btnNumKey)
			Me.Controls.Add(Me.btnNum0)
			Me.Controls.Add(Me.btnNumAll)
			Me.Controls.Add(Me.txtNumBackup)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.lblPath)
			Me.Controls.Add(Me.txtPath)
			Me.Controls.Add(Me.btnPath)
			Me.Controls.Add(Me.grpSelect)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmBackup"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterParent
			Me.Text = "Sao lưu dữ liệu"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.grpSelect.ResumeLayout(False)
			Me.grpSelect.PerformLayout()
			CType(Me.nupDay, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x04000182 RID: 386
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
