﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000294 RID: 660
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60615k58Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006788 RID: 26504 RVA: 0x00012C13 File Offset: 0x00010E13
		Public Sub New()
			CachedrptRepBC60615k58Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002853 RID: 10323
		' (get) Token: 0x06006789 RID: 26505 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x0600678A RID: 26506 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002854 RID: 10324
		' (get) Token: 0x0600678B RID: 26507 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x0600678C RID: 26508 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002855 RID: 10325
		' (get) Token: 0x0600678D RID: 26509 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x0600678E RID: 26510 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x0600678F RID: 26511 RVA: 0x004DDDE0 File Offset: 0x004DBFE0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60615k58Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x06006790 RID: 26512 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x0400288C RID: 10380
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
