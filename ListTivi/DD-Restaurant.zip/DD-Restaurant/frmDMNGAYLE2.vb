﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200006C RID: 108
	<DesignerGenerated()>
	Public Partial Class frmDMNGAYLE2
		Inherits Form

		' Token: 0x06002216 RID: 8726 RVA: 0x001A6270 File Offset: 0x001A4470
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMLN2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMLN2_Load
			frmDMNGAYLE2.__ENCList.Add(New WeakReference(Me))
			Me.mblnFix = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000BA5 RID: 2981
		' (get) Token: 0x06002219 RID: 8729 RVA: 0x001A6D58 File Offset: 0x001A4F58
		' (set) Token: 0x0600221A RID: 8730 RVA: 0x00006C60 File Offset: 0x00004E60
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000BA6 RID: 2982
		' (get) Token: 0x0600221B RID: 8731 RVA: 0x001A6D70 File Offset: 0x001A4F70
		' (set) Token: 0x0600221C RID: 8732 RVA: 0x001A6D88 File Offset: 0x001A4F88
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000BA7 RID: 2983
		' (get) Token: 0x0600221D RID: 8733 RVA: 0x001A6DF4 File Offset: 0x001A4FF4
		' (set) Token: 0x0600221E RID: 8734 RVA: 0x00006C6A File Offset: 0x00004E6A
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x17000BA8 RID: 2984
		' (get) Token: 0x0600221F RID: 8735 RVA: 0x001A6E0C File Offset: 0x001A500C
		' (set) Token: 0x06002220 RID: 8736 RVA: 0x001A6E24 File Offset: 0x001A5024
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000BA9 RID: 2985
		' (get) Token: 0x06002221 RID: 8737 RVA: 0x001A6E90 File Offset: 0x001A5090
		' (set) Token: 0x06002222 RID: 8738 RVA: 0x001A6EA8 File Offset: 0x001A50A8
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000BAA RID: 2986
		' (get) Token: 0x06002223 RID: 8739 RVA: 0x001A6F14 File Offset: 0x001A5114
		' (set) Token: 0x06002224 RID: 8740 RVA: 0x001A6F2C File Offset: 0x001A512C
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000BAB RID: 2987
		' (get) Token: 0x06002225 RID: 8741 RVA: 0x001A6F98 File Offset: 0x001A5198
		' (set) Token: 0x06002226 RID: 8742 RVA: 0x00006C74 File Offset: 0x00004E74
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x17000BAC RID: 2988
		' (get) Token: 0x06002227 RID: 8743 RVA: 0x001A6FB0 File Offset: 0x001A51B0
		' (set) Token: 0x06002228 RID: 8744 RVA: 0x001A6FC8 File Offset: 0x001A51C8
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000BAD RID: 2989
		' (get) Token: 0x06002229 RID: 8745 RVA: 0x001A7064 File Offset: 0x001A5264
		' (set) Token: 0x0600222A RID: 8746 RVA: 0x00006C7E File Offset: 0x00004E7E
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x17000BAE RID: 2990
		' (get) Token: 0x0600222B RID: 8747 RVA: 0x001A707C File Offset: 0x001A527C
		' (set) Token: 0x0600222C RID: 8748 RVA: 0x00006C88 File Offset: 0x00004E88
		Friend Overridable Property txtColor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtColor = value
			End Set
		End Property

		' Token: 0x17000BAF RID: 2991
		' (get) Token: 0x0600222D RID: 8749 RVA: 0x001A7094 File Offset: 0x001A5294
		' (set) Token: 0x0600222E RID: 8750 RVA: 0x00006C92 File Offset: 0x00004E92
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000BB0 RID: 2992
		' (get) Token: 0x0600222F RID: 8751 RVA: 0x001A70AC File Offset: 0x001A52AC
		' (set) Token: 0x06002230 RID: 8752 RVA: 0x001A70C4 File Offset: 0x001A52C4
		Friend Overridable Property mtbOBJID As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtbOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtbOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._mtbOBJID.KeyPress, AddressOf Me.mtbOBJID_KeyPress
				End If
				Me._mtbOBJID = value
				flag = Me._mtbOBJID IsNot Nothing
				If flag Then
					AddHandler Me._mtbOBJID.KeyPress, AddressOf Me.mtbOBJID_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000BB1 RID: 2993
		' (get) Token: 0x06002231 RID: 8753 RVA: 0x001A7130 File Offset: 0x001A5330
		' (set) Token: 0x06002232 RID: 8754 RVA: 0x00006C9C File Offset: 0x00004E9C
		Public Property pblnFix As Boolean
			Get
				Return Me.mblnFix
			End Get
			Set(value As Boolean)
				Me.mblnFix = value
			End Set
		End Property

		' Token: 0x17000BB2 RID: 2994
		' (get) Token: 0x06002233 RID: 8755 RVA: 0x001A7148 File Offset: 0x001A5348
		' (set) Token: 0x06002234 RID: 8756 RVA: 0x00006CA7 File Offset: 0x00004EA7
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000BB3 RID: 2995
		' (get) Token: 0x06002235 RID: 8757 RVA: 0x001A7160 File Offset: 0x001A5360
		' (set) Token: 0x06002236 RID: 8758 RVA: 0x00006CB2 File Offset: 0x00004EB2
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000BB4 RID: 2996
		' (get) Token: 0x06002237 RID: 8759 RVA: 0x001A7178 File Offset: 0x001A5378
		' (set) Token: 0x06002238 RID: 8760 RVA: 0x00006CBD File Offset: 0x00004EBD
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06002239 RID: 8761 RVA: 0x001A7190 File Offset: 0x001A5390
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim flag2 As Boolean = Me.mbytFormStatus = 5
					If flag2 Then
						Me.btnFilter.Focus()
					Else
						flag2 = Me.mbytFormStatus = 6
						If flag2 Then
							Me.btnFind.Focus()
						Else
							Me.btnSave.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600223A RID: 8762 RVA: 0x001A726C File Offset: 0x001A546C
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.btnExit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600223B RID: 8763 RVA: 0x001A7318 File Offset: 0x001A5518
		Private Sub frmDMLN2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLN2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600223C RID: 8764 RVA: 0x001A73C4 File Offset: 0x001A55C4
		Private Sub mtbOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean
				If num < 48 OrElse num > 57 Then
					If num <> 8 Then
						flag = False
						GoTo IL_0024
					End If
				End If
				flag = True
				IL_0024:
				Dim flag2 As Boolean = flag
				If Not flag2 Then
					flag2 = num = 13
					If flag2 Then
						Me.txtOBJNAME.Focus()
					Else
						e.Handled = True
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600223D RID: 8765 RVA: 0x001A7494 File Offset: 0x001A5694
		Private Sub frmDMLN2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLN2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600223E RID: 8766 RVA: 0x001A7540 File Offset: 0x001A5740
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mtbOBJID.Text.Trim().Length < 10
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.mtbOBJID.Focus()
				Else
					Dim text As String = String.Concat(New String() { Strings.Mid(Me.mtbOBJID.Text.Trim(), 7, 4), "/", Strings.Mid(Me.mtbOBJID.Text.Trim(), 4, 2), "/", Strings.Mid(Me.mtbOBJID.Text.Trim(), 1, 2) })
					flag = Not Information.IsDate(text)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
						Me.mtbOBJID.Focus()
					Else
						flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
							Me.txtOBJNAME.Focus()
						Else
							flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
							If flag Then
								Me.mbytSuccess = Me.fAddNew()
							Else
								flag = Me.mbytFormStatus = 3
								If flag Then
									Me.mbytSuccess = Me.fModify()
								End If
							End If
							flag = Me.mbytSuccess = 1
							If flag Then
								Me.Close()
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600223F RID: 8767 RVA: 0x001A7768 File Offset: 0x001A5968
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002240 RID: 8768 RVA: 0x001A780C File Offset: 0x001A5A0C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.mtbOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) = 10
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002241 RID: 8769 RVA: 0x001A79AC File Offset: 0x001A5BAC
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.mtbOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) = 10
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002242 RID: 8770 RVA: 0x001A7B4C File Offset: 0x001A5D4C
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.mtbOBJID.[ReadOnly] = True
						Me.mtbOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.Focus()
					Case 4
						Me.mtbOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.mtbOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.BackColor = Me.txtColor.BackColor
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002243 RID: 8771 RVA: 0x001A7C7C File Offset: 0x001A5E7C
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.mtbOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002244 RID: 8772 RVA: 0x001A7E0C File Offset: 0x001A600C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJNAME.MaxLength = 100
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002245 RID: 8773 RVA: 0x001A7EC4 File Offset: 0x001A60C4
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2040100000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002246 RID: 8774 RVA: 0x001A80A8 File Offset: 0x001A62A8
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002247 RID: 8775 RVA: 0x001A8148 File Offset: 0x001A6348
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.mtbOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNGAYLE_INSERT", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.mtbOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.mtbOBJID.Focus()
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						Me.mtbOBJID.Focus()
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06002248 RID: 8776 RVA: 0x001A8348 File Offset: 0x001A6548
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.mtbOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pvchTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNGAYLE_UPDATE", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.mtbOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06002249 RID: 8777 RVA: 0x001A8538 File Offset: 0x001A6738
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.mtbOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNGAYLE_DEL", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x04000DE4 RID: 3556
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000DE6 RID: 3558
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000DE7 RID: 3559
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000DE8 RID: 3560
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000DE9 RID: 3561
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000DEA RID: 3562
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000DEB RID: 3563
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000DEC RID: 3564
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000DED RID: 3565
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000DEE RID: 3566
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000DEF RID: 3567
		<AccessedThroughProperty("txtColor")>
		Private _txtColor As TextBox

		' Token: 0x04000DF0 RID: 3568
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000DF1 RID: 3569
		<AccessedThroughProperty("mtbOBJID")>
		Private _mtbOBJID As MaskedTextBox

		' Token: 0x04000DF2 RID: 3570
		Private mArrStrFrmMess As String()

		' Token: 0x04000DF3 RID: 3571
		Private mbytFormStatus As Byte

		' Token: 0x04000DF4 RID: 3572
		Private mbytSuccess As Byte

		' Token: 0x04000DF5 RID: 3573
		Private mStrFilter As String

		' Token: 0x04000DF6 RID: 3574
		Private mblnFix As Boolean
	End Class
End Namespace
