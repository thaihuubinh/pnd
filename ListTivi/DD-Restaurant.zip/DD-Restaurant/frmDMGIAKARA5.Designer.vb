﻿Namespace prjIS_SalesPOS
	' Token: 0x0200004D RID: 77
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMGIAKARA5
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06001501 RID: 5377 RVA: 0x000FF260 File Offset: 0x000FD460
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06001502 RID: 5378 RVA: 0x000FF298 File Offset: 0x000FD498
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMGIAKARA5))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.lbMATK = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.txtOBJNAME = New Global.System.Windows.Forms.TextBox()
			Me.txtPRICE = New Global.System.Windows.Forms.TextBox()
			Me.txtOBJID = New Global.System.Windows.Forms.TextBox()
			Me.cmbType = New Global.System.Windows.Forms.ComboBox()
			Me.txtTimeFrom = New Global.System.Windows.Forms.TextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.txttimeTo = New Global.System.Windows.Forms.TextBox()
			Me.Label4 = New Global.System.Windows.Forms.Label()
			Me.txtLOTMM = New Global.System.Windows.Forms.TextBox()
			Me.txtPrice12 = New Global.System.Windows.Forms.TextBox()
			Me.Label5 = New Global.System.Windows.Forms.Label()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(536, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 490)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 7
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 0)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 5
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 469)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 375)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 91)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 3)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(107, 87)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 4
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.lbMATK.AutoSize = True
			Dim lbMATK As Global.System.Windows.Forms.Control = Me.lbMATK
			point = New Global.System.Drawing.Point(24, 45)
			lbMATK.Location = point
			Me.lbMATK.Name = "lbMATK"
			Dim lbMATK2 As Global.System.Windows.Forms.Control = Me.lbMATK
			size = New Global.System.Drawing.Size(97, 16)
			lbMATK2.Size = size
			Me.lbMATK.TabIndex = 8
			Me.lbMATK.Tag = "CB0017"
			Me.lbMATK.Text = "Ma thoi khoang"
			Me.Label2.AutoSize = True
			Dim label As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(24, 76)
			label.Location = point
			Me.Label2.Name = "Label2"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(99, 16)
			label2.Size = size
			Me.Label2.TabIndex = 9
			Me.Label2.Tag = "CB0018"
			Me.Label2.Text = "Ten thoi khoang"
			Me.Label3.AutoSize = True
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(24, 106)
			label3.Location = point
			Me.Label3.Name = "Label3"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(28, 16)
			label4.Size = size
			Me.Label3.TabIndex = 10
			Me.Label3.Tag = "CB0019"
			Me.Label3.Text = "Gia"
			Dim txtOBJNAME As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			point = New Global.System.Drawing.Point(162, 73)
			txtOBJNAME.Location = point
			Me.txtOBJNAME.Name = "txtOBJNAME"
			Dim txtOBJNAME2 As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			size = New Global.System.Drawing.Size(368, 22)
			txtOBJNAME2.Size = size
			Me.txtOBJNAME.TabIndex = 11
			Dim txtPRICE As Global.System.Windows.Forms.Control = Me.txtPRICE
			point = New Global.System.Drawing.Point(162, 103)
			txtPRICE.Location = point
			Me.txtPRICE.Name = "txtPRICE"
			Dim txtPRICE2 As Global.System.Windows.Forms.Control = Me.txtPRICE
			size = New Global.System.Drawing.Size(144, 22)
			txtPRICE2.Size = size
			Me.txtPRICE.TabIndex = 12
			Me.txtPRICE.Text = "0"
			Me.txtPRICE.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Dim txtOBJID As Global.System.Windows.Forms.Control = Me.txtOBJID
			point = New Global.System.Drawing.Point(162, 45)
			txtOBJID.Location = point
			Me.txtOBJID.Name = "txtOBJID"
			Dim txtOBJID2 As Global.System.Windows.Forms.Control = Me.txtOBJID
			size = New Global.System.Drawing.Size(144, 22)
			txtOBJID2.Size = size
			Me.txtOBJID.TabIndex = 13
			Me.cmbType.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbType.FormattingEnabled = True
			Dim cmbType As Global.System.Windows.Forms.Control = Me.cmbType
			point = New Global.System.Drawing.Point(312, 103)
			cmbType.Location = point
			Me.cmbType.Name = "cmbType"
			Dim cmbType2 As Global.System.Windows.Forms.Control = Me.cmbType
			size = New Global.System.Drawing.Size(117, 24)
			cmbType2.Size = size
			Me.cmbType.TabIndex = 14
			Dim txtTimeFrom As Global.System.Windows.Forms.Control = Me.txtTimeFrom
			point = New Global.System.Drawing.Point(162, 131)
			txtTimeFrom.Location = point
			Me.txtTimeFrom.Name = "txtTimeFrom"
			Dim txtTimeFrom2 As Global.System.Windows.Forms.Control = Me.txtTimeFrom
			size = New Global.System.Drawing.Size(144, 22)
			txtTimeFrom2.Size = size
			Me.txtTimeFrom.TabIndex = 16
			Me.txtTimeFrom.Text = "0"
			Me.txtTimeFrom.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label1.AutoSize = True
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(24, 134)
			label5.Location = point
			Me.Label1.Name = "Label1"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(44, 16)
			label6.Size = size
			Me.Label1.TabIndex = 15
			Me.Label1.Tag = "CB0027"
			Me.Label1.Text = "tinh tu"
			Dim txttimeTo As Global.System.Windows.Forms.Control = Me.txttimeTo
			point = New Global.System.Drawing.Point(162, 159)
			txttimeTo.Location = point
			Me.txttimeTo.Name = "txttimeTo"
			Dim txttimeTo2 As Global.System.Windows.Forms.Control = Me.txttimeTo
			size = New Global.System.Drawing.Size(144, 22)
			txttimeTo2.Size = size
			Me.txttimeTo.TabIndex = 18
			Me.txttimeTo.Text = "99999"
			Me.txttimeTo.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label4.AutoSize = True
			Dim label7 As Global.System.Windows.Forms.Control = Me.Label4
			point = New Global.System.Drawing.Point(24, 162)
			label7.Location = point
			Me.Label4.Name = "Label4"
			Dim label8 As Global.System.Windows.Forms.Control = Me.Label4
			size = New Global.System.Drawing.Size(54, 16)
			label8.Size = size
			Me.Label4.TabIndex = 17
			Me.Label4.Tag = "CB0028"
			Me.Label4.Text = "tinh den"
			Dim txtLOTMM As Global.System.Windows.Forms.Control = Me.txtLOTMM
			point = New Global.System.Drawing.Point(435, 103)
			txtLOTMM.Location = point
			Me.txtLOTMM.Name = "txtLOTMM"
			Dim txtLOTMM2 As Global.System.Windows.Forms.Control = Me.txtLOTMM
			size = New Global.System.Drawing.Size(95, 22)
			txtLOTMM2.Size = size
			Me.txtLOTMM.TabIndex = 19
			Me.txtLOTMM.Text = "60"
			Me.txtLOTMM.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Dim txtPrice As Global.System.Windows.Forms.Control = Me.txtPrice12
			point = New Global.System.Drawing.Point(162, 187)
			txtPrice.Location = point
			Me.txtPrice12.Name = "txtPrice12"
			Dim txtPrice2 As Global.System.Windows.Forms.Control = Me.txtPrice12
			size = New Global.System.Drawing.Size(144, 22)
			txtPrice2.Size = size
			Me.txtPrice12.TabIndex = 21
			Me.txtPrice12.Text = "0"
			Me.txtPrice12.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label5.AutoSize = True
			Dim label9 As Global.System.Windows.Forms.Control = Me.Label5
			point = New Global.System.Drawing.Point(24, 190)
			label9.Location = point
			Me.Label5.Name = "Label5"
			Dim label10 As Global.System.Windows.Forms.Control = Me.Label5
			size = New Global.System.Drawing.Size(71, 16)
			label10.Size = size
			Me.Label5.TabIndex = 20
			Me.Label5.Tag = "CR0030"
			Me.Label5.Text = "Gia sau 12"
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(655, 490)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.txtPrice12)
			Me.Controls.Add(Me.Label5)
			Me.Controls.Add(Me.txtLOTMM)
			Me.Controls.Add(Me.txttimeTo)
			Me.Controls.Add(Me.Label4)
			Me.Controls.Add(Me.txtTimeFrom)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.cmbType)
			Me.Controls.Add(Me.txtOBJID)
			Me.Controls.Add(Me.txtPRICE)
			Me.Controls.Add(Me.txtOBJNAME)
			Me.Controls.Add(Me.Label3)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.lbMATK)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMGIAKARA5"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Chi tiết khuyến mãi"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x040008B7 RID: 2231
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
