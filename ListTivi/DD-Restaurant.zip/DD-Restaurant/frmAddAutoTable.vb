﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000015 RID: 21
	<DesignerGenerated()>
	Public Partial Class frmAddAutoTable
		Inherits Form

		' Token: 0x06000250 RID: 592 RVA: 0x00002626 File Offset: 0x00000826
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmAddAutoTable_Load
			frmAddAutoTable.__ENCList.Add(New WeakReference(Me))
			Me.mBytSuccess = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x170000ED RID: 237
		' (get) Token: 0x06000253 RID: 595 RVA: 0x000200D4 File Offset: 0x0001E2D4
		' (set) Token: 0x06000254 RID: 596 RVA: 0x000200EC File Offset: 0x0001E2EC
		Friend Overridable Property btnFont As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFont
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFont IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFont.Click, AddressOf Me.btnFont_Click
				End If
				Me._btnFont = value
				flag = Me._btnFont IsNot Nothing
				If flag Then
					AddHandler Me._btnFont.Click, AddressOf Me.btnFont_Click
				End If
			End Set
		End Property

		' Token: 0x170000EE RID: 238
		' (get) Token: 0x06000255 RID: 597 RVA: 0x00020158 File Offset: 0x0001E358
		' (set) Token: 0x06000256 RID: 598 RVA: 0x00020170 File Offset: 0x0001E370
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170000EF RID: 239
		' (get) Token: 0x06000257 RID: 599 RVA: 0x000201DC File Offset: 0x0001E3DC
		' (set) Token: 0x06000258 RID: 600 RVA: 0x000201F4 File Offset: 0x0001E3F4
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x170000F0 RID: 240
		' (get) Token: 0x06000259 RID: 601 RVA: 0x00020260 File Offset: 0x0001E460
		' (set) Token: 0x0600025A RID: 602 RVA: 0x00002663 File Offset: 0x00000863
		Friend Overridable Property lblFont As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFont
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFont = value
			End Set
		End Property

		' Token: 0x170000F1 RID: 241
		' (get) Token: 0x0600025B RID: 603 RVA: 0x00020278 File Offset: 0x0001E478
		' (set) Token: 0x0600025C RID: 604 RVA: 0x0000266D File Offset: 0x0000086D
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x170000F2 RID: 242
		' (get) Token: 0x0600025D RID: 605 RVA: 0x00020290 File Offset: 0x0001E490
		' (set) Token: 0x0600025E RID: 606 RVA: 0x000202A8 File Offset: 0x0001E4A8
		Friend Overridable Property btnColorBack As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnColorBack
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnColorBack IsNot Nothing
				If flag Then
					RemoveHandler Me._btnColorBack.Click, AddressOf Me.btnColorBack_Click
				End If
				Me._btnColorBack = value
				flag = Me._btnColorBack IsNot Nothing
				If flag Then
					AddHandler Me._btnColorBack.Click, AddressOf Me.btnColorBack_Click
				End If
			End Set
		End Property

		' Token: 0x170000F3 RID: 243
		' (get) Token: 0x0600025F RID: 607 RVA: 0x00020314 File Offset: 0x0001E514
		' (set) Token: 0x06000260 RID: 608 RVA: 0x00002677 File Offset: 0x00000877
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x170000F4 RID: 244
		' (get) Token: 0x06000261 RID: 609 RVA: 0x0002032C File Offset: 0x0001E52C
		' (set) Token: 0x06000262 RID: 610 RVA: 0x00002681 File Offset: 0x00000881
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x170000F5 RID: 245
		' (get) Token: 0x06000263 RID: 611 RVA: 0x00020344 File Offset: 0x0001E544
		' (set) Token: 0x06000264 RID: 612 RVA: 0x0000268B File Offset: 0x0000088B
		Friend Overridable Property lblTablename As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTablename
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTablename = value
			End Set
		End Property

		' Token: 0x170000F6 RID: 246
		' (get) Token: 0x06000265 RID: 613 RVA: 0x0002035C File Offset: 0x0001E55C
		' (set) Token: 0x06000266 RID: 614 RVA: 0x00020374 File Offset: 0x0001E574
		Friend Overridable Property btnTablename As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnTablename
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnTablename IsNot Nothing
				If flag Then
					RemoveHandler Me._btnTablename.Click, AddressOf Me.btnTablename_Click
				End If
				Me._btnTablename = value
				flag = Me._btnTablename IsNot Nothing
				If flag Then
					AddHandler Me._btnTablename.Click, AddressOf Me.btnTablename_Click
				End If
			End Set
		End Property

		' Token: 0x170000F7 RID: 247
		' (get) Token: 0x06000267 RID: 615 RVA: 0x000203E0 File Offset: 0x0001E5E0
		' (set) Token: 0x06000268 RID: 616 RVA: 0x000203F8 File Offset: 0x0001E5F8
		Friend Overridable Property btnStart As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnStart
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnStart IsNot Nothing
				If flag Then
					RemoveHandler Me._btnStart.Click, AddressOf Me.btnStart_Click
				End If
				Me._btnStart = value
				flag = Me._btnStart IsNot Nothing
				If flag Then
					AddHandler Me._btnStart.Click, AddressOf Me.btnStart_Click
				End If
			End Set
		End Property

		' Token: 0x170000F8 RID: 248
		' (get) Token: 0x06000269 RID: 617 RVA: 0x00020464 File Offset: 0x0001E664
		' (set) Token: 0x0600026A RID: 618 RVA: 0x00002695 File Offset: 0x00000895
		Friend Overridable Property lblStart As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblStart
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblStart = value
			End Set
		End Property

		' Token: 0x170000F9 RID: 249
		' (get) Token: 0x0600026B RID: 619 RVA: 0x0002047C File Offset: 0x0001E67C
		' (set) Token: 0x0600026C RID: 620 RVA: 0x0000269F File Offset: 0x0000089F
		Friend Overridable Property Label7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		' Token: 0x170000FA RID: 250
		' (get) Token: 0x0600026D RID: 621 RVA: 0x00020494 File Offset: 0x0001E694
		' (set) Token: 0x0600026E RID: 622 RVA: 0x000204AC File Offset: 0x0001E6AC
		Friend Overridable Property btnEnd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnEnd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnEnd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnEnd.Click, AddressOf Me.btnEnd_Click
				End If
				Me._btnEnd = value
				flag = Me._btnEnd IsNot Nothing
				If flag Then
					AddHandler Me._btnEnd.Click, AddressOf Me.btnEnd_Click
				End If
			End Set
		End Property

		' Token: 0x170000FB RID: 251
		' (get) Token: 0x0600026F RID: 623 RVA: 0x00020518 File Offset: 0x0001E718
		' (set) Token: 0x06000270 RID: 624 RVA: 0x000026A9 File Offset: 0x000008A9
		Friend Overridable Property lblEnd As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblEnd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblEnd = value
			End Set
		End Property

		' Token: 0x170000FC RID: 252
		' (get) Token: 0x06000271 RID: 625 RVA: 0x00020530 File Offset: 0x0001E730
		' (set) Token: 0x06000272 RID: 626 RVA: 0x000026B3 File Offset: 0x000008B3
		Friend Overridable Property Label9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label9 = value
			End Set
		End Property

		' Token: 0x170000FD RID: 253
		' (get) Token: 0x06000273 RID: 627 RVA: 0x00020548 File Offset: 0x0001E748
		' (set) Token: 0x06000274 RID: 628 RVA: 0x00020560 File Offset: 0x0001E760
		Friend Overridable Property btnRow As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnRow
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnRow IsNot Nothing
				If flag Then
					RemoveHandler Me._btnRow.Click, AddressOf Me.btnRow_Click
				End If
				Me._btnRow = value
				flag = Me._btnRow IsNot Nothing
				If flag Then
					AddHandler Me._btnRow.Click, AddressOf Me.btnRow_Click
				End If
			End Set
		End Property

		' Token: 0x170000FE RID: 254
		' (get) Token: 0x06000275 RID: 629 RVA: 0x000205CC File Offset: 0x0001E7CC
		' (set) Token: 0x06000276 RID: 630 RVA: 0x000026BD File Offset: 0x000008BD
		Friend Overridable Property lblRow As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblRow
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblRow = value
			End Set
		End Property

		' Token: 0x170000FF RID: 255
		' (get) Token: 0x06000277 RID: 631 RVA: 0x000205E4 File Offset: 0x0001E7E4
		' (set) Token: 0x06000278 RID: 632 RVA: 0x000026C7 File Offset: 0x000008C7
		Friend Overridable Property Label11 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label11
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label11 = value
			End Set
		End Property

		' Token: 0x17000100 RID: 256
		' (get) Token: 0x06000279 RID: 633 RVA: 0x000205FC File Offset: 0x0001E7FC
		' (set) Token: 0x0600027A RID: 634 RVA: 0x00020614 File Offset: 0x0001E814
		Friend Overridable Property btnCol As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCol
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCol IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCol.Click, AddressOf Me.btnCol_Click
				End If
				Me._btnCol = value
				flag = Me._btnCol IsNot Nothing
				If flag Then
					AddHandler Me._btnCol.Click, AddressOf Me.btnCol_Click
				End If
			End Set
		End Property

		' Token: 0x17000101 RID: 257
		' (get) Token: 0x0600027B RID: 635 RVA: 0x00020680 File Offset: 0x0001E880
		' (set) Token: 0x0600027C RID: 636 RVA: 0x000026D1 File Offset: 0x000008D1
		Friend Overridable Property lblCol As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCol
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCol = value
			End Set
		End Property

		' Token: 0x17000102 RID: 258
		' (get) Token: 0x0600027D RID: 637 RVA: 0x00020698 File Offset: 0x0001E898
		' (set) Token: 0x0600027E RID: 638 RVA: 0x000026DB File Offset: 0x000008DB
		Friend Overridable Property Label13 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label13
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label13 = value
			End Set
		End Property

		' Token: 0x17000103 RID: 259
		' (get) Token: 0x0600027F RID: 639 RVA: 0x000206B0 File Offset: 0x0001E8B0
		' (set) Token: 0x06000280 RID: 640 RVA: 0x000026E5 File Offset: 0x000008E5
		Public Property pbytSuccess As Byte
			Get
				Return Me.mBytSuccess
			End Get
			Set(value As Byte)
				Me.mBytSuccess = value
			End Set
		End Property

		' Token: 0x06000281 RID: 641 RVA: 0x000206C8 File Offset: 0x0001E8C8
		Private Sub frmAddAutoTable_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmAddAutoTable_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000282 RID: 642 RVA: 0x00020760 File Offset: 0x0001E960
		Private Sub btnFont_Click(sender As Object, e As EventArgs)
			Try
				mdlFile.gfWriteLogFile("Chọn Font chữ thêm bàn tự động.")
				Dim frmSelectFont As frmSelectFont = New frmSelectFont()
				frmSelectFont.pmStrFontNameDef = Me.lblFont.Font.Name
				frmSelectFont.pmbytFontSizeDef = CByte(Math.Round(CDbl(Me.lblFont.Font.Size)))
				frmSelectFont.pmbytFontColorBlueDef = Me.lblFont.ForeColor.B
				frmSelectFont.pmbytFontColorGreenDef = Me.lblFont.ForeColor.G
				frmSelectFont.pmbytFontColorRedDef = Me.lblFont.ForeColor.R
				frmSelectFont.pmblnCheckDef = True
				frmSelectFont.ShowDialog()
				Dim pmblnOK As Boolean = frmSelectFont.pmblnOK
				If pmblnOK Then
					Me.lblFont.Font = New Font(frmSelectFont.pmStrFontNameDef, CSng(frmSelectFont.pmbytFontSizeDef))
					Me.lblFont.ForeColor = Color.FromArgb(CInt(frmSelectFont.pmbytFontColorRedDef), CInt(frmSelectFont.pmbytFontColorGreenDef), CInt(frmSelectFont.pmbytFontColorBlueDef))
					Me.lblFont.TextAlign = CType(frmSelectFont.pIntTextAlign, ContentAlignment)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnFont_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000283 RID: 643 RVA: 0x000208E8 File Offset: 0x0001EAE8
		Private Sub btnColorBack_Click(sender As Object, e As EventArgs)
			Try
				mdlFile.gfWriteLogFile("Chọn Màu nền cho bàn trong thêm bàn tự động.")
				Dim frmcolorsetting As frmcolorsetting = New frmcolorsetting()
				frmcolorsetting.pbytColorDefred = Conversions.ToString(Me.lblFont.BackColor.R)
				frmcolorsetting.pbytColorDefgreen = Conversions.ToString(Me.lblFont.BackColor.G)
				frmcolorsetting.pbytColorDefblue = Conversions.ToString(Me.lblFont.BackColor.B)
				frmcolorsetting.ShowDialog()
				Dim pblnresult As Boolean = frmcolorsetting.pblnresult
				If pblnresult Then
					Me.lblFont.BackColor = Color.FromArgb(Conversions.ToInteger(frmcolorsetting.pbytColorDefred), Conversions.ToInteger(frmcolorsetting.pbytColorDefgreen), Conversions.ToInteger(frmcolorsetting.pbytColorDefblue))
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnColorBack_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000284 RID: 644 RVA: 0x00020A14 File Offset: 0x0001EC14
		Private Sub btnStart_Click(sender As Object, e As EventArgs)
			Dim frmNumPad As frmNumPad = New frmNumPad()
			MyProject.Forms.frmNumPad.ShowDialog()
			Dim flag As Boolean = MyProject.Forms.frmNumPad.pbytSuccess = 1
			If flag Then
				Me.lblStart.Text = Conversions.ToString(MyProject.Forms.frmNumPad.pSglNumberReturn)
				mdlFile.gfWriteLogFile("Chọn số bàn bắt đầu là: " + Conversions.ToString(MyProject.Forms.frmNumPad.pSglNumberReturn))
			End If
		End Sub

		' Token: 0x06000285 RID: 645 RVA: 0x00020A94 File Offset: 0x0001EC94
		Private Sub btnEnd_Click(sender As Object, e As EventArgs)
			Dim frmNumPad As frmNumPad = New frmNumPad()
			MyProject.Forms.frmNumPad.ShowDialog()
			Dim flag As Boolean = MyProject.Forms.frmNumPad.pbytSuccess = 1
			If flag Then
				Me.lblEnd.Text = Conversions.ToString(MyProject.Forms.frmNumPad.pSglNumberReturn)
				mdlFile.gfWriteLogFile("Chọn số bàn kết thúc là: " + Conversions.ToString(MyProject.Forms.frmNumPad.pSglNumberReturn))
			End If
		End Sub

		' Token: 0x06000286 RID: 646 RVA: 0x00020B14 File Offset: 0x0001ED14
		Private Sub btnCol_Click(sender As Object, e As EventArgs)
			Dim frmNumPad As frmNumPad = New frmNumPad()
			MyProject.Forms.frmNumPad.ShowDialog()
			Dim flag As Boolean = MyProject.Forms.frmNumPad.pbytSuccess = 1
			If flag Then
				Me.lblCol.Text = Conversions.ToString(MyProject.Forms.frmNumPad.pSglNumberReturn)
				mdlFile.gfWriteLogFile("Chọn số bàn trên 1 cột là: " + Conversions.ToString(MyProject.Forms.frmNumPad.pSglNumberReturn))
			End If
		End Sub

		' Token: 0x06000287 RID: 647 RVA: 0x00020B94 File Offset: 0x0001ED94
		Private Sub btnRow_Click(sender As Object, e As EventArgs)
			Dim frmNumPad As frmNumPad = New frmNumPad()
			MyProject.Forms.frmNumPad.ShowDialog()
			Dim flag As Boolean = MyProject.Forms.frmNumPad.pbytSuccess = 1
			If flag Then
				Me.lblRow.Text = Conversions.ToString(MyProject.Forms.frmNumPad.pSglNumberReturn)
				mdlFile.gfWriteLogFile("Chọn số bàn trên 1 dòng là: " + Conversions.ToString(MyProject.Forms.frmNumPad.pSglNumberReturn))
			End If
		End Sub

		' Token: 0x06000288 RID: 648 RVA: 0x00020C14 File Offset: 0x0001EE14
		Private Sub btnTablename_Click(sender As Object, e As EventArgs)
			Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
			frmKeyBoard.pStrEnterText = Me.lblTablename.Text
			frmKeyBoard.ShowDialog()
			Me.lblTablename.Text = frmKeyBoard.pStrEnterText
			mdlFile.gfWriteLogFile("Chọn ký tự đầu cho tên bàn là: " + frmKeyBoard.pStrEnterText)
		End Sub

		' Token: 0x06000289 RID: 649 RVA: 0x00020C6C File Offset: 0x0001EE6C
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			mdlFile.gfWriteLogFile("Nhấn nút Lưu thêm bàn tự động.")
			Dim flag As Boolean = Conversion.Val(Me.lblStart.Text) >= Conversion.Val(Me.lblEnd.Text)
			If flag Then
				Interaction.MsgBox(Me.mArrStrFrmMess(12), MsgBoxStyle.Critical, Nothing)
				mdlFile.gfWriteLogFile("Ngưng lưu: Do số bàn bắt đầu >= số bàn kết thúc")
			Else
				flag = Conversion.Val(Me.lblCol.Text) <= 0.0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(13), MsgBoxStyle.Critical, Nothing)
					mdlFile.gfWriteLogFile("Ngưng lưu: Do số bàn trên 1 cột <= 0")
				Else
					mdlFile.gfWriteLogFile("Lưu thêm bàn tự động thành công.")
					Me.mBytSuccess = 1
					Me.Close()
				End If
			End If
		End Sub

		' Token: 0x0600028A RID: 650 RVA: 0x000026F0 File Offset: 0x000008F0
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			mdlFile.gfWriteLogFile("Nhấn nút thoát thêm bàn tự động.")
			Me.Close()
		End Sub

		' Token: 0x0600028B RID: 651 RVA: 0x00020D2C File Offset: 0x0001EF2C
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(11))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(0), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x040000FE RID: 254
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000100 RID: 256
		<AccessedThroughProperty("btnFont")>
		Private _btnFont As Button

		' Token: 0x04000101 RID: 257
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000102 RID: 258
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000103 RID: 259
		<AccessedThroughProperty("lblFont")>
		Private _lblFont As Label

		' Token: 0x04000104 RID: 260
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000105 RID: 261
		<AccessedThroughProperty("btnColorBack")>
		Private _btnColorBack As Button

		' Token: 0x04000106 RID: 262
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x04000107 RID: 263
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000108 RID: 264
		<AccessedThroughProperty("lblTablename")>
		Private _lblTablename As Label

		' Token: 0x04000109 RID: 265
		<AccessedThroughProperty("btnTablename")>
		Private _btnTablename As Button

		' Token: 0x0400010A RID: 266
		<AccessedThroughProperty("btnStart")>
		Private _btnStart As Button

		' Token: 0x0400010B RID: 267
		<AccessedThroughProperty("lblStart")>
		Private _lblStart As Label

		' Token: 0x0400010C RID: 268
		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		' Token: 0x0400010D RID: 269
		<AccessedThroughProperty("btnEnd")>
		Private _btnEnd As Button

		' Token: 0x0400010E RID: 270
		<AccessedThroughProperty("lblEnd")>
		Private _lblEnd As Label

		' Token: 0x0400010F RID: 271
		<AccessedThroughProperty("Label9")>
		Private _Label9 As Label

		' Token: 0x04000110 RID: 272
		<AccessedThroughProperty("btnRow")>
		Private _btnRow As Button

		' Token: 0x04000111 RID: 273
		<AccessedThroughProperty("lblRow")>
		Private _lblRow As Label

		' Token: 0x04000112 RID: 274
		<AccessedThroughProperty("Label11")>
		Private _Label11 As Label

		' Token: 0x04000113 RID: 275
		<AccessedThroughProperty("btnCol")>
		Private _btnCol As Button

		' Token: 0x04000114 RID: 276
		<AccessedThroughProperty("lblCol")>
		Private _lblCol As Label

		' Token: 0x04000115 RID: 277
		<AccessedThroughProperty("Label13")>
		Private _Label13 As Label

		' Token: 0x04000116 RID: 278
		Private mArrStrFrmMess As String()

		' Token: 0x04000117 RID: 279
		Private mBytSuccess As Byte
	End Class
End Namespace
