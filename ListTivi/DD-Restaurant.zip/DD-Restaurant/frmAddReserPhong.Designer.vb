﻿Namespace prjIS_SalesPOS
	' Token: 0x02000018 RID: 24
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmAddReserPhong
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060002F6 RID: 758 RVA: 0x00024B84 File Offset: 0x00022D84
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060002F7 RID: 759 RVA: 0x00024BBC File Offset: 0x00022DBC
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmAddReserPhong))
			Me.panSua = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.lblstt = New Global.System.Windows.Forms.Label()
			Me.lblNo = New Global.System.Windows.Forms.Label()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.lblDV = New Global.System.Windows.Forms.Label()
			Me.lblTenKH = New Global.System.Windows.Forms.Label()
			Me.Label5 = New Global.System.Windows.Forms.Label()
			Me.lblTongSoPhong = New Global.System.Windows.Forms.Label()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.lblMaKH = New Global.System.Windows.Forms.Label()
			Me.lblEmail = New Global.System.Windows.Forms.Label()
			Me.Label6 = New Global.System.Windows.Forms.Label()
			Me.Label4 = New Global.System.Windows.Forms.Label()
			Me.lblPhone = New Global.System.Windows.Forms.Label()
			Me.Label10 = New Global.System.Windows.Forms.Label()
			Me.lblContact = New Global.System.Windows.Forms.Label()
			Me.Label7 = New Global.System.Windows.Forms.Label()
			Me.dtpNgayDat = New Global.System.Windows.Forms.DateTimePicker()
			Me.Label12 = New Global.System.Windows.Forms.Label()
			Me.TableLayoutPanel7 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.Label13 = New Global.System.Windows.Forms.Label()
			Me.Label14 = New Global.System.Windows.Forms.Label()
			Me.lblHour = New Global.System.Windows.Forms.Label()
			Me.lblMinute = New Global.System.Windows.Forms.Label()
			Me.Label15 = New Global.System.Windows.Forms.Label()
			Me.Label16 = New Global.System.Windows.Forms.Label()
			Me.dtpNgayNhan = New Global.System.Windows.Forms.DateTimePicker()
			Me.dtpNgayTra = New Global.System.Windows.Forms.DateTimePicker()
			Me.Label9 = New Global.System.Windows.Forms.Label()
			Me.lblSelectTable = New Global.System.Windows.Forms.Label()
			Me.Label17 = New Global.System.Windows.Forms.Label()
			Me.lblLoaiPhong = New Global.System.Windows.Forms.Label()
			Me.Label19 = New Global.System.Windows.Forms.Label()
			Me.lblSoDem = New Global.System.Windows.Forms.Label()
			Me.Label21 = New Global.System.Windows.Forms.Label()
			Me.lblTongSoDem = New Global.System.Windows.Forms.Label()
			Me.lblDonGia = New Global.System.Windows.Forms.Label()
			Me.Label24 = New Global.System.Windows.Forms.Label()
			Me.lblNoidung = New Global.System.Windows.Forms.Label()
			Me.lblTienThanhToan = New Global.System.Windows.Forms.Label()
			Me.Label27 = New Global.System.Windows.Forms.Label()
			Me.lblTienDatCoc = New Global.System.Windows.Forms.Label()
			Me.Label29 = New Global.System.Windows.Forms.Label()
			Me.dtpNgayDatCoc = New Global.System.Windows.Forms.DateTimePicker()
			Me.Label30 = New Global.System.Windows.Forms.Label()
			Me.lblTienConLai = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.lblREMARK = New Global.System.Windows.Forms.Label()
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.lblPV = New Global.System.Windows.Forms.Label()
			Me.lblDMMaBan = New Global.System.Windows.Forms.Label()
			Me.lblDMMaKhu = New Global.System.Windows.Forms.Label()
			Me.lblMaPV = New Global.System.Windows.Forms.Label()
			Me.panSua.SuspendLayout()
			Me.TableLayoutPanel7.SuspendLayout()
			Me.SuspendLayout()
			Me.panSua.ColumnCount = 4
			Me.panSua.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.panSua.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.panSua.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.panSua.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.panSua.Controls.Add(Me.btnExit, 3, 14)
			Me.panSua.Controls.Add(Me.lblstt, 0, 0)
			Me.panSua.Controls.Add(Me.lblNo, 1, 0)
			Me.panSua.Controls.Add(Me.lblDV, 0, 2)
			Me.panSua.Controls.Add(Me.lblTenKH, 1, 2)
			Me.panSua.Controls.Add(Me.Label5, 0, 8)
			Me.panSua.Controls.Add(Me.lblTongSoPhong, 1, 8)
			Me.panSua.Controls.Add(Me.Label1, 0, 1)
			Me.panSua.Controls.Add(Me.lblMaKH, 1, 1)
			Me.panSua.Controls.Add(Me.lblEmail, 3, 4)
			Me.panSua.Controls.Add(Me.Label6, 2, 4)
			Me.panSua.Controls.Add(Me.Label4, 0, 4)
			Me.panSua.Controls.Add(Me.lblPhone, 1, 4)
			Me.panSua.Controls.Add(Me.Label10, 0, 3)
			Me.panSua.Controls.Add(Me.lblContact, 1, 3)
			Me.panSua.Controls.Add(Me.Label7, 0, 5)
			Me.panSua.Controls.Add(Me.dtpNgayDat, 1, 5)
			Me.panSua.Controls.Add(Me.Label12, 2, 5)
			Me.panSua.Controls.Add(Me.TableLayoutPanel7, 3, 5)
			Me.panSua.Controls.Add(Me.Label15, 0, 6)
			Me.panSua.Controls.Add(Me.Label16, 2, 6)
			Me.panSua.Controls.Add(Me.dtpNgayNhan, 1, 6)
			Me.panSua.Controls.Add(Me.dtpNgayTra, 3, 6)
			Me.panSua.Controls.Add(Me.Label9, 2, 7)
			Me.panSua.Controls.Add(Me.lblSelectTable, 3, 7)
			Me.panSua.Controls.Add(Me.Label17, 0, 7)
			Me.panSua.Controls.Add(Me.lblLoaiPhong, 1, 7)
			Me.panSua.Controls.Add(Me.Label19, 2, 8)
			Me.panSua.Controls.Add(Me.lblSoDem, 3, 8)
			Me.panSua.Controls.Add(Me.Label21, 0, 9)
			Me.panSua.Controls.Add(Me.lblTongSoDem, 1, 9)
			Me.panSua.Controls.Add(Me.lblDonGia, 3, 9)
			Me.panSua.Controls.Add(Me.Label24, 2, 9)
			Me.panSua.Controls.Add(Me.lblNoidung, 0, 10)
			Me.panSua.Controls.Add(Me.lblTienThanhToan, 1, 10)
			Me.panSua.Controls.Add(Me.Label27, 0, 11)
			Me.panSua.Controls.Add(Me.lblTienDatCoc, 1, 11)
			Me.panSua.Controls.Add(Me.Label29, 2, 11)
			Me.panSua.Controls.Add(Me.dtpNgayDatCoc, 3, 11)
			Me.panSua.Controls.Add(Me.Label30, 0, 12)
			Me.panSua.Controls.Add(Me.lblTienConLai, 1, 12)
			Me.panSua.Controls.Add(Me.Label2, 0, 13)
			Me.panSua.Controls.Add(Me.lblREMARK, 1, 13)
			Me.panSua.Controls.Add(Me.Label3, 0, 14)
			Me.panSua.Controls.Add(Me.lblPV, 1, 14)
			Me.panSua.Controls.Add(Me.lblDMMaBan, 2, 0)
			Me.panSua.Controls.Add(Me.lblDMMaKhu, 3, 0)
			Me.panSua.Controls.Add(Me.lblMaPV, 2, 1)
			Me.panSua.Controls.Add(Me.btnSave, 2, 14)
			Me.panSua.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim panSua As Global.System.Windows.Forms.Control = Me.panSua
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(0, 0)
			panSua.Location = point
			Me.panSua.Name = "panSua"
			Me.panSua.RowCount = 15
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Me.panSua.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 6.666667F))
			Dim panSua2 As Global.System.Windows.Forms.Control = Me.panSua
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(791, 576)
			panSua2.Size = size
			Me.panSua.TabIndex = 3
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.TopCenter
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(594, 535)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(194, 38)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 14
			Me.btnExit.Tag = "C00027"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageAboveText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.lblstt.BackColor = Global.System.Drawing.Color.White
			Me.lblstt.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim lblstt As Global.System.Windows.Forms.Control = Me.lblstt
			point = New Global.System.Drawing.Point(3, 0)
			lblstt.Location = point
			Me.lblstt.Name = "lblstt"
			Dim lblstt2 As Global.System.Windows.Forms.Control = Me.lblstt
			size = New Global.System.Drawing.Size(191, 38)
			lblstt2.Size = size
			Me.lblstt.TabIndex = 7
			Me.lblstt.Tag = "CR0002"
			Me.lblstt.Text = "STT"
			Me.lblstt.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblNo.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.lblNo.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblNo.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblNo.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 10F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblNo.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblNo As Global.System.Windows.Forms.Control = Me.lblNo
			point = New Global.System.Drawing.Point(199, 2)
			lblNo.Location = point
			Dim lblNo2 As Global.System.Windows.Forms.Control = Me.lblNo
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(2)
			lblNo2.Margin = padding
			Me.lblNo.Name = "lblNo"
			Dim lblNo3 As Global.System.Windows.Forms.Control = Me.lblNo
			size = New Global.System.Drawing.Size(193, 34)
			lblNo3.Size = size
			Me.lblNo.TabIndex = 7
			Me.lblNo.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btnSave.BackgroundImage = CType(componentResourceManager.GetObject("btnSave.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnSave.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnSave.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnSave.ImageAlign = Global.System.Drawing.ContentAlignment.TopCenter
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(397, 535)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(191, 38)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 14
			Me.btnSave.Tag = "C00026"
			Me.btnSave.Text = "Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageAboveText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.lblDV.BackColor = Global.System.Drawing.Color.White
			Me.lblDV.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim lblDV As Global.System.Windows.Forms.Control = Me.lblDV
			point = New Global.System.Drawing.Point(3, 76)
			lblDV.Location = point
			Me.lblDV.Name = "lblDV"
			Dim lblDV2 As Global.System.Windows.Forms.Control = Me.lblDV
			size = New Global.System.Drawing.Size(191, 38)
			lblDV2.Size = size
			Me.lblDV.TabIndex = 7
			Me.lblDV.Tag = "CR0005"
			Me.lblDV.Text = "Tên Khách hàng"
			Me.lblDV.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblTenKH.BackColor = Global.System.Drawing.Color.White
			Me.lblTenKH.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblTenKH.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblTenKH.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblTenKH As Global.System.Windows.Forms.Control = Me.lblTenKH
			point = New Global.System.Drawing.Point(199, 78)
			lblTenKH.Location = point
			Dim lblTenKH2 As Global.System.Windows.Forms.Control = Me.lblTenKH
			padding = New Global.System.Windows.Forms.Padding(2)
			lblTenKH2.Margin = padding
			Me.lblTenKH.Name = "lblTenKH"
			Dim lblTenKH3 As Global.System.Windows.Forms.Control = Me.lblTenKH
			size = New Global.System.Drawing.Size(193, 34)
			lblTenKH3.Size = size
			Me.lblTenKH.TabIndex = 7
			Me.lblTenKH.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label5.BackColor = Global.System.Drawing.Color.White
			Me.Label5.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label As Global.System.Windows.Forms.Control = Me.Label5
			point = New Global.System.Drawing.Point(3, 304)
			label.Location = point
			Me.Label5.Name = "Label5"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label5
			size = New Global.System.Drawing.Size(191, 38)
			label2.Size = size
			Me.Label5.TabIndex = 7
			Me.Label5.Tag = "CR0015"
			Me.Label5.Text = "Tổng số phòng"
			Me.Label5.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblTongSoPhong.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.lblTongSoPhong.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblTongSoPhong.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblTongSoPhong.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblTongSoPhong As Global.System.Windows.Forms.Control = Me.lblTongSoPhong
			point = New Global.System.Drawing.Point(199, 306)
			lblTongSoPhong.Location = point
			Dim lblTongSoPhong2 As Global.System.Windows.Forms.Control = Me.lblTongSoPhong
			padding = New Global.System.Windows.Forms.Padding(2)
			lblTongSoPhong2.Margin = padding
			Me.lblTongSoPhong.Name = "lblTongSoPhong"
			Dim lblTongSoPhong3 As Global.System.Windows.Forms.Control = Me.lblTongSoPhong
			size = New Global.System.Drawing.Size(193, 34)
			lblTongSoPhong3.Size = size
			Me.lblTongSoPhong.TabIndex = 7
			Me.lblTongSoPhong.Text = "0"
			Me.lblTongSoPhong.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label1.BackColor = Global.System.Drawing.Color.White
			Me.Label1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(3, 38)
			label3.Location = point
			Me.Label1.Name = "Label1"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(191, 38)
			label4.Size = size
			Me.Label1.TabIndex = 7
			Me.Label1.Tag = "CR0004"
			Me.Label1.Text = "Mã khách hàng"
			Me.Label1.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblMaKH.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.lblMaKH.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblMaKH.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblMaKH.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 10F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblMaKH.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblMaKH As Global.System.Windows.Forms.Control = Me.lblMaKH
			point = New Global.System.Drawing.Point(199, 40)
			lblMaKH.Location = point
			Dim lblMaKH2 As Global.System.Windows.Forms.Control = Me.lblMaKH
			padding = New Global.System.Windows.Forms.Padding(2)
			lblMaKH2.Margin = padding
			Me.lblMaKH.Name = "lblMaKH"
			Dim lblMaKH3 As Global.System.Windows.Forms.Control = Me.lblMaKH
			size = New Global.System.Drawing.Size(193, 34)
			lblMaKH3.Size = size
			Me.lblMaKH.TabIndex = 7
			Me.lblMaKH.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lblEmail.BackColor = Global.System.Drawing.Color.White
			Me.lblEmail.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblEmail.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblEmail.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblEmail As Global.System.Windows.Forms.Control = Me.lblEmail
			point = New Global.System.Drawing.Point(593, 154)
			lblEmail.Location = point
			Dim lblEmail2 As Global.System.Windows.Forms.Control = Me.lblEmail
			padding = New Global.System.Windows.Forms.Padding(2)
			lblEmail2.Margin = padding
			Me.lblEmail.Name = "lblEmail"
			Dim lblEmail3 As Global.System.Windows.Forms.Control = Me.lblEmail
			size = New Global.System.Drawing.Size(196, 34)
			lblEmail3.Size = size
			Me.lblEmail.TabIndex = 7
			Me.lblEmail.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label6.BackColor = Global.System.Drawing.Color.White
			Me.Label6.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label6
			point = New Global.System.Drawing.Point(397, 152)
			label5.Location = point
			Me.Label6.Name = "Label6"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label6
			size = New Global.System.Drawing.Size(191, 38)
			label6.Size = size
			Me.Label6.TabIndex = 7
			Me.Label6.Tag = "CR0008"
			Me.Label6.Text = "Email"
			Me.Label6.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.Label4.BackColor = Global.System.Drawing.Color.White
			Me.Label4.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label7 As Global.System.Windows.Forms.Control = Me.Label4
			point = New Global.System.Drawing.Point(3, 152)
			label7.Location = point
			Me.Label4.Name = "Label4"
			Dim label8 As Global.System.Windows.Forms.Control = Me.Label4
			size = New Global.System.Drawing.Size(191, 38)
			label8.Size = size
			Me.Label4.TabIndex = 7
			Me.Label4.Tag = "CR0007"
			Me.Label4.Text = "Điện thoại"
			Me.Label4.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblPhone.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.lblPhone.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblPhone.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblPhone.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblPhone As Global.System.Windows.Forms.Control = Me.lblPhone
			point = New Global.System.Drawing.Point(199, 154)
			lblPhone.Location = point
			Dim lblPhone2 As Global.System.Windows.Forms.Control = Me.lblPhone
			padding = New Global.System.Windows.Forms.Padding(2)
			lblPhone2.Margin = padding
			Me.lblPhone.Name = "lblPhone"
			Dim lblPhone3 As Global.System.Windows.Forms.Control = Me.lblPhone
			size = New Global.System.Drawing.Size(193, 34)
			lblPhone3.Size = size
			Me.lblPhone.TabIndex = 7
			Me.lblPhone.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label10.BackColor = Global.System.Drawing.Color.White
			Me.Label10.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label9 As Global.System.Windows.Forms.Control = Me.Label10
			point = New Global.System.Drawing.Point(3, 114)
			label9.Location = point
			Me.Label10.Name = "Label10"
			Dim label10 As Global.System.Windows.Forms.Control = Me.Label10
			size = New Global.System.Drawing.Size(191, 38)
			label10.Size = size
			Me.Label10.TabIndex = 7
			Me.Label10.Tag = "CR0006"
			Me.Label10.Text = "Tên người liên hệ"
			Me.Label10.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblContact.BackColor = Global.System.Drawing.Color.White
			Me.lblContact.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblContact.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblContact.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblContact As Global.System.Windows.Forms.Control = Me.lblContact
			point = New Global.System.Drawing.Point(199, 116)
			lblContact.Location = point
			Dim lblContact2 As Global.System.Windows.Forms.Control = Me.lblContact
			padding = New Global.System.Windows.Forms.Padding(2)
			lblContact2.Margin = padding
			Me.lblContact.Name = "lblContact"
			Dim lblContact3 As Global.System.Windows.Forms.Control = Me.lblContact
			size = New Global.System.Drawing.Size(193, 34)
			lblContact3.Size = size
			Me.lblContact.TabIndex = 7
			Me.lblContact.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label7.BackColor = Global.System.Drawing.Color.White
			Me.Label7.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label11 As Global.System.Windows.Forms.Control = Me.Label7
			point = New Global.System.Drawing.Point(3, 190)
			label11.Location = point
			Me.Label7.Name = "Label7"
			Dim label12 As Global.System.Windows.Forms.Control = Me.Label7
			size = New Global.System.Drawing.Size(191, 38)
			label12.Size = size
			Me.Label7.TabIndex = 7
			Me.Label7.Tag = "CR0009"
			Me.Label7.Text = "Ngày đặt"
			Me.Label7.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.dtpNgayDat.AllowDrop = True
			Me.dtpNgayDat.CalendarForeColor = Global.System.Drawing.Color.OrangeRed
			Me.dtpNgayDat.CalendarMonthBackground = Global.System.Drawing.Color.OldLace
			Me.dtpNgayDat.CalendarTitleBackColor = Global.System.Drawing.Color.BlueViolet
			Me.dtpNgayDat.CalendarTitleForeColor = Global.System.Drawing.Color.LightCoral
			Me.dtpNgayDat.CalendarTrailingForeColor = Global.System.Drawing.SystemColors.ControlText
			Me.dtpNgayDat.CustomFormat = "dd/MM/yyyy"
			Me.dtpNgayDat.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.dtpNgayDat.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.dtpNgayDat.Format = Global.System.Windows.Forms.DateTimePickerFormat.Custom
			Dim dtpNgayDat As Global.System.Windows.Forms.Control = Me.dtpNgayDat
			point = New Global.System.Drawing.Point(199, 192)
			dtpNgayDat.Location = point
			Dim dtpNgayDat2 As Global.System.Windows.Forms.Control = Me.dtpNgayDat
			padding = New Global.System.Windows.Forms.Padding(2)
			dtpNgayDat2.Margin = padding
			Me.dtpNgayDat.Name = "dtpNgayDat"
			Dim dtpNgayDat3 As Global.System.Windows.Forms.Control = Me.dtpNgayDat
			size = New Global.System.Drawing.Size(193, 30)
			dtpNgayDat3.Size = size
			Me.dtpNgayDat.TabIndex = 2
			Dim dtpNgayDat4 As Global.System.Windows.Forms.DateTimePicker = Me.dtpNgayDat
			Dim dateTime As Global.System.DateTime = New Global.System.DateTime(2010, 10, 2, 0, 0, 0, 0)
			dtpNgayDat4.Value = dateTime
			Me.Label12.BackColor = Global.System.Drawing.Color.White
			Me.Label12.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label13 As Global.System.Windows.Forms.Control = Me.Label12
			point = New Global.System.Drawing.Point(397, 190)
			label13.Location = point
			Me.Label12.Name = "Label12"
			Dim label14 As Global.System.Windows.Forms.Control = Me.Label12
			size = New Global.System.Drawing.Size(191, 38)
			label14.Size = size
			Me.Label12.TabIndex = 7
			Me.Label12.Tag = "CR0010"
			Me.Label12.Text = "Giờ đặt"
			Me.Label12.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.TableLayoutPanel7.ColumnCount = 4
			Me.TableLayoutPanel7.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 30F))
			Me.TableLayoutPanel7.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel7.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 30F))
			Me.TableLayoutPanel7.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel7.Controls.Add(Me.Label13, 1, 0)
			Me.TableLayoutPanel7.Controls.Add(Me.Label14, 3, 0)
			Me.TableLayoutPanel7.Controls.Add(Me.lblHour, 0, 0)
			Me.TableLayoutPanel7.Controls.Add(Me.lblMinute, 2, 0)
			Me.TableLayoutPanel7.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel7
			point = New Global.System.Drawing.Point(594, 193)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel7.Name = "TableLayoutPanel7"
			Me.TableLayoutPanel7.RowCount = 1
			Me.TableLayoutPanel7.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel7
			size = New Global.System.Drawing.Size(194, 32)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel7.TabIndex = 27
			Me.Label13.BackColor = Global.System.Drawing.Color.White
			Me.Label13.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label15 As Global.System.Windows.Forms.Control = Me.Label13
			point = New Global.System.Drawing.Point(61, 0)
			label15.Location = point
			Me.Label13.Name = "Label13"
			Dim label16 As Global.System.Windows.Forms.Control = Me.Label13
			size = New Global.System.Drawing.Size(32, 32)
			label16.Size = size
			Me.Label13.TabIndex = 7
			Me.Label13.Text = "giờ"
			Me.Label13.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.Label14.BackColor = Global.System.Drawing.Color.White
			Me.Label14.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label17 As Global.System.Windows.Forms.Control = Me.Label14
			point = New Global.System.Drawing.Point(157, 0)
			label17.Location = point
			Me.Label14.Name = "Label14"
			Dim label18 As Global.System.Windows.Forms.Control = Me.Label14
			size = New Global.System.Drawing.Size(34, 32)
			label18.Size = size
			Me.Label14.TabIndex = 7
			Me.Label14.Text = "phút"
			Me.Label14.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblHour.BackColor = Global.System.Drawing.Color.White
			Me.lblHour.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblHour.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblHour.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblHour As Global.System.Windows.Forms.Control = Me.lblHour
			point = New Global.System.Drawing.Point(2, 2)
			lblHour.Location = point
			Dim lblHour2 As Global.System.Windows.Forms.Control = Me.lblHour
			padding = New Global.System.Windows.Forms.Padding(2)
			lblHour2.Margin = padding
			Me.lblHour.Name = "lblHour"
			Dim lblHour3 As Global.System.Windows.Forms.Control = Me.lblHour
			size = New Global.System.Drawing.Size(54, 28)
			lblHour3.Size = size
			Me.lblHour.TabIndex = 7
			Me.lblHour.Text = "00"
			Me.lblHour.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lblMinute.BackColor = Global.System.Drawing.Color.White
			Me.lblMinute.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblMinute.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblMinute.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblMinute As Global.System.Windows.Forms.Control = Me.lblMinute
			point = New Global.System.Drawing.Point(98, 2)
			lblMinute.Location = point
			Dim lblMinute2 As Global.System.Windows.Forms.Control = Me.lblMinute
			padding = New Global.System.Windows.Forms.Padding(2)
			lblMinute2.Margin = padding
			Me.lblMinute.Name = "lblMinute"
			Dim lblMinute3 As Global.System.Windows.Forms.Control = Me.lblMinute
			size = New Global.System.Drawing.Size(54, 28)
			lblMinute3.Size = size
			Me.lblMinute.TabIndex = 7
			Me.lblMinute.Text = "00"
			Me.lblMinute.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label15.BackColor = Global.System.Drawing.Color.White
			Me.Label15.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label19 As Global.System.Windows.Forms.Control = Me.Label15
			point = New Global.System.Drawing.Point(3, 228)
			label19.Location = point
			Me.Label15.Name = "Label15"
			Dim label20 As Global.System.Windows.Forms.Control = Me.Label15
			size = New Global.System.Drawing.Size(191, 38)
			label20.Size = size
			Me.Label15.TabIndex = 7
			Me.Label15.Tag = "CR0011"
			Me.Label15.Text = "Ngày nhận phòng"
			Me.Label15.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.Label16.BackColor = Global.System.Drawing.Color.White
			Me.Label16.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label21 As Global.System.Windows.Forms.Control = Me.Label16
			point = New Global.System.Drawing.Point(397, 228)
			label21.Location = point
			Me.Label16.Name = "Label16"
			Dim label22 As Global.System.Windows.Forms.Control = Me.Label16
			size = New Global.System.Drawing.Size(191, 38)
			label22.Size = size
			Me.Label16.TabIndex = 7
			Me.Label16.Tag = "CR0012"
			Me.Label16.Text = "Ngày trả phòng"
			Me.Label16.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.dtpNgayNhan.AllowDrop = True
			Me.dtpNgayNhan.CalendarForeColor = Global.System.Drawing.Color.OrangeRed
			Me.dtpNgayNhan.CalendarMonthBackground = Global.System.Drawing.Color.OldLace
			Me.dtpNgayNhan.CalendarTitleBackColor = Global.System.Drawing.Color.BlueViolet
			Me.dtpNgayNhan.CalendarTitleForeColor = Global.System.Drawing.Color.LightCoral
			Me.dtpNgayNhan.CalendarTrailingForeColor = Global.System.Drawing.SystemColors.ControlText
			Me.dtpNgayNhan.CustomFormat = "dd/MM/yyyy"
			Me.dtpNgayNhan.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.dtpNgayNhan.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.dtpNgayNhan.Format = Global.System.Windows.Forms.DateTimePickerFormat.Custom
			Dim dtpNgayNhan As Global.System.Windows.Forms.Control = Me.dtpNgayNhan
			point = New Global.System.Drawing.Point(199, 230)
			dtpNgayNhan.Location = point
			Dim dtpNgayNhan2 As Global.System.Windows.Forms.Control = Me.dtpNgayNhan
			padding = New Global.System.Windows.Forms.Padding(2)
			dtpNgayNhan2.Margin = padding
			Me.dtpNgayNhan.Name = "dtpNgayNhan"
			Dim dtpNgayNhan3 As Global.System.Windows.Forms.Control = Me.dtpNgayNhan
			size = New Global.System.Drawing.Size(193, 30)
			dtpNgayNhan3.Size = size
			Me.dtpNgayNhan.TabIndex = 2
			Dim dtpNgayNhan4 As Global.System.Windows.Forms.DateTimePicker = Me.dtpNgayNhan
			dateTime = New Global.System.DateTime(2010, 10, 2, 0, 0, 0, 0)
			dtpNgayNhan4.Value = dateTime
			Me.dtpNgayTra.AllowDrop = True
			Me.dtpNgayTra.CalendarForeColor = Global.System.Drawing.Color.OrangeRed
			Me.dtpNgayTra.CalendarMonthBackground = Global.System.Drawing.Color.OldLace
			Me.dtpNgayTra.CalendarTitleBackColor = Global.System.Drawing.Color.BlueViolet
			Me.dtpNgayTra.CalendarTitleForeColor = Global.System.Drawing.Color.LightCoral
			Me.dtpNgayTra.CalendarTrailingForeColor = Global.System.Drawing.SystemColors.ControlText
			Me.dtpNgayTra.CustomFormat = "dd/MM/yyyy"
			Me.dtpNgayTra.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.dtpNgayTra.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.dtpNgayTra.Format = Global.System.Windows.Forms.DateTimePickerFormat.Custom
			Dim dtpNgayTra As Global.System.Windows.Forms.Control = Me.dtpNgayTra
			point = New Global.System.Drawing.Point(593, 230)
			dtpNgayTra.Location = point
			Dim dtpNgayTra2 As Global.System.Windows.Forms.Control = Me.dtpNgayTra
			padding = New Global.System.Windows.Forms.Padding(2)
			dtpNgayTra2.Margin = padding
			Me.dtpNgayTra.Name = "dtpNgayTra"
			Dim dtpNgayTra3 As Global.System.Windows.Forms.Control = Me.dtpNgayTra
			size = New Global.System.Drawing.Size(196, 30)
			dtpNgayTra3.Size = size
			Me.dtpNgayTra.TabIndex = 2
			Dim dtpNgayTra4 As Global.System.Windows.Forms.DateTimePicker = Me.dtpNgayTra
			dateTime = New Global.System.DateTime(2010, 10, 2, 0, 0, 0, 0)
			dtpNgayTra4.Value = dateTime
			Me.Label9.BackColor = Global.System.Drawing.Color.White
			Me.Label9.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label23 As Global.System.Windows.Forms.Control = Me.Label9
			point = New Global.System.Drawing.Point(397, 266)
			label23.Location = point
			Me.Label9.Name = "Label9"
			Dim label24 As Global.System.Windows.Forms.Control = Me.Label9
			size = New Global.System.Drawing.Size(191, 38)
			label24.Size = size
			Me.Label9.TabIndex = 7
			Me.Label9.Tag = "CR0014"
			Me.Label9.Text = "Tên phòng"
			Me.Label9.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblSelectTable.BackColor = Global.System.Drawing.Color.White
			Me.lblSelectTable.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblSelectTable.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblSelectTable.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblSelectTable As Global.System.Windows.Forms.Control = Me.lblSelectTable
			point = New Global.System.Drawing.Point(593, 268)
			lblSelectTable.Location = point
			Dim lblSelectTable2 As Global.System.Windows.Forms.Control = Me.lblSelectTable
			padding = New Global.System.Windows.Forms.Padding(2)
			lblSelectTable2.Margin = padding
			Me.lblSelectTable.Name = "lblSelectTable"
			Dim lblSelectTable3 As Global.System.Windows.Forms.Control = Me.lblSelectTable
			size = New Global.System.Drawing.Size(196, 34)
			lblSelectTable3.Size = size
			Me.lblSelectTable.TabIndex = 7
			Me.lblSelectTable.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label17.BackColor = Global.System.Drawing.Color.White
			Me.Label17.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label25 As Global.System.Windows.Forms.Control = Me.Label17
			point = New Global.System.Drawing.Point(3, 266)
			label25.Location = point
			Me.Label17.Name = "Label17"
			Dim label26 As Global.System.Windows.Forms.Control = Me.Label17
			size = New Global.System.Drawing.Size(191, 38)
			label26.Size = size
			Me.Label17.TabIndex = 7
			Me.Label17.Tag = "CR0013"
			Me.Label17.Text = "Loại phòng"
			Me.Label17.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblLoaiPhong.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.lblLoaiPhong.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblLoaiPhong.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblLoaiPhong.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblLoaiPhong As Global.System.Windows.Forms.Control = Me.lblLoaiPhong
			point = New Global.System.Drawing.Point(199, 268)
			lblLoaiPhong.Location = point
			Dim lblLoaiPhong2 As Global.System.Windows.Forms.Control = Me.lblLoaiPhong
			padding = New Global.System.Windows.Forms.Padding(2)
			lblLoaiPhong2.Margin = padding
			Me.lblLoaiPhong.Name = "lblLoaiPhong"
			Dim lblLoaiPhong3 As Global.System.Windows.Forms.Control = Me.lblLoaiPhong
			size = New Global.System.Drawing.Size(193, 34)
			lblLoaiPhong3.Size = size
			Me.lblLoaiPhong.TabIndex = 7
			Me.lblLoaiPhong.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label19.BackColor = Global.System.Drawing.Color.White
			Me.Label19.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label27 As Global.System.Windows.Forms.Control = Me.Label19
			point = New Global.System.Drawing.Point(397, 304)
			label27.Location = point
			Me.Label19.Name = "Label19"
			Dim label28 As Global.System.Windows.Forms.Control = Me.Label19
			size = New Global.System.Drawing.Size(191, 38)
			label28.Size = size
			Me.Label19.TabIndex = 7
			Me.Label19.Tag = "CR0016"
			Me.Label19.Text = "Số đêm"
			Me.Label19.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblSoDem.BackColor = Global.System.Drawing.Color.White
			Me.lblSoDem.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblSoDem.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblSoDem.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblSoDem As Global.System.Windows.Forms.Control = Me.lblSoDem
			point = New Global.System.Drawing.Point(593, 306)
			lblSoDem.Location = point
			Dim lblSoDem2 As Global.System.Windows.Forms.Control = Me.lblSoDem
			padding = New Global.System.Windows.Forms.Padding(2)
			lblSoDem2.Margin = padding
			Me.lblSoDem.Name = "lblSoDem"
			Dim lblSoDem3 As Global.System.Windows.Forms.Control = Me.lblSoDem
			size = New Global.System.Drawing.Size(196, 34)
			lblSoDem3.Size = size
			Me.lblSoDem.TabIndex = 7
			Me.lblSoDem.Text = "0"
			Me.lblSoDem.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label21.BackColor = Global.System.Drawing.Color.White
			Me.Label21.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label29 As Global.System.Windows.Forms.Control = Me.Label21
			point = New Global.System.Drawing.Point(3, 342)
			label29.Location = point
			Me.Label21.Name = "Label21"
			Dim label30 As Global.System.Windows.Forms.Control = Me.Label21
			size = New Global.System.Drawing.Size(191, 38)
			label30.Size = size
			Me.Label21.TabIndex = 7
			Me.Label21.Tag = "CR0017"
			Me.Label21.Text = "Tổng số đêm"
			Me.Label21.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblTongSoDem.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.lblTongSoDem.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblTongSoDem.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblTongSoDem.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblTongSoDem As Global.System.Windows.Forms.Control = Me.lblTongSoDem
			point = New Global.System.Drawing.Point(199, 344)
			lblTongSoDem.Location = point
			Dim lblTongSoDem2 As Global.System.Windows.Forms.Control = Me.lblTongSoDem
			padding = New Global.System.Windows.Forms.Padding(2)
			lblTongSoDem2.Margin = padding
			Me.lblTongSoDem.Name = "lblTongSoDem"
			Dim lblTongSoDem3 As Global.System.Windows.Forms.Control = Me.lblTongSoDem
			size = New Global.System.Drawing.Size(193, 34)
			lblTongSoDem3.Size = size
			Me.lblTongSoDem.TabIndex = 7
			Me.lblTongSoDem.Text = "0"
			Me.lblTongSoDem.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lblDonGia.BackColor = Global.System.Drawing.Color.White
			Me.lblDonGia.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblDonGia.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblDonGia.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblDonGia As Global.System.Windows.Forms.Control = Me.lblDonGia
			point = New Global.System.Drawing.Point(593, 344)
			lblDonGia.Location = point
			Dim lblDonGia2 As Global.System.Windows.Forms.Control = Me.lblDonGia
			padding = New Global.System.Windows.Forms.Padding(2)
			lblDonGia2.Margin = padding
			Me.lblDonGia.Name = "lblDonGia"
			Dim lblDonGia3 As Global.System.Windows.Forms.Control = Me.lblDonGia
			size = New Global.System.Drawing.Size(196, 34)
			lblDonGia3.Size = size
			Me.lblDonGia.TabIndex = 7
			Me.lblDonGia.Text = "0"
			Me.lblDonGia.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label24.BackColor = Global.System.Drawing.Color.White
			Me.Label24.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label31 As Global.System.Windows.Forms.Control = Me.Label24
			point = New Global.System.Drawing.Point(397, 342)
			label31.Location = point
			Me.Label24.Name = "Label24"
			Dim label32 As Global.System.Windows.Forms.Control = Me.Label24
			size = New Global.System.Drawing.Size(191, 38)
			label32.Size = size
			Me.Label24.TabIndex = 7
			Me.Label24.Tag = "CR0018"
			Me.Label24.Text = "Đơn giá/đêm"
			Me.Label24.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblNoidung.BackColor = Global.System.Drawing.Color.White
			Me.lblNoidung.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim lblNoidung As Global.System.Windows.Forms.Control = Me.lblNoidung
			point = New Global.System.Drawing.Point(3, 380)
			lblNoidung.Location = point
			Me.lblNoidung.Name = "lblNoidung"
			Dim lblNoidung2 As Global.System.Windows.Forms.Control = Me.lblNoidung
			size = New Global.System.Drawing.Size(191, 38)
			lblNoidung2.Size = size
			Me.lblNoidung.TabIndex = 7
			Me.lblNoidung.Tag = "CR0019"
			Me.lblNoidung.Text = "Tổng tiền thanh toán"
			Me.lblNoidung.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblTienThanhToan.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.lblTienThanhToan.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblTienThanhToan.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblTienThanhToan.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblTienThanhToan As Global.System.Windows.Forms.Control = Me.lblTienThanhToan
			point = New Global.System.Drawing.Point(199, 382)
			lblTienThanhToan.Location = point
			Dim lblTienThanhToan2 As Global.System.Windows.Forms.Control = Me.lblTienThanhToan
			padding = New Global.System.Windows.Forms.Padding(2)
			lblTienThanhToan2.Margin = padding
			Me.lblTienThanhToan.Name = "lblTienThanhToan"
			Dim lblTienThanhToan3 As Global.System.Windows.Forms.Control = Me.lblTienThanhToan
			size = New Global.System.Drawing.Size(193, 34)
			lblTienThanhToan3.Size = size
			Me.lblTienThanhToan.TabIndex = 7
			Me.lblTienThanhToan.Text = "0"
			Me.lblTienThanhToan.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label27.BackColor = Global.System.Drawing.Color.White
			Me.Label27.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label33 As Global.System.Windows.Forms.Control = Me.Label27
			point = New Global.System.Drawing.Point(3, 418)
			label33.Location = point
			Me.Label27.Name = "Label27"
			Dim label34 As Global.System.Windows.Forms.Control = Me.Label27
			size = New Global.System.Drawing.Size(191, 38)
			label34.Size = size
			Me.Label27.TabIndex = 7
			Me.Label27.Tag = "CR0020"
			Me.Label27.Text = "Tiền đặt cọc"
			Me.Label27.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblTienDatCoc.BackColor = Global.System.Drawing.Color.White
			Me.lblTienDatCoc.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblTienDatCoc.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblTienDatCoc.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblTienDatCoc As Global.System.Windows.Forms.Control = Me.lblTienDatCoc
			point = New Global.System.Drawing.Point(199, 420)
			lblTienDatCoc.Location = point
			Dim lblTienDatCoc2 As Global.System.Windows.Forms.Control = Me.lblTienDatCoc
			padding = New Global.System.Windows.Forms.Padding(2)
			lblTienDatCoc2.Margin = padding
			Me.lblTienDatCoc.Name = "lblTienDatCoc"
			Dim lblTienDatCoc3 As Global.System.Windows.Forms.Control = Me.lblTienDatCoc
			size = New Global.System.Drawing.Size(193, 34)
			lblTienDatCoc3.Size = size
			Me.lblTienDatCoc.TabIndex = 7
			Me.lblTienDatCoc.Text = "0"
			Me.lblTienDatCoc.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label29.BackColor = Global.System.Drawing.Color.White
			Me.Label29.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label35 As Global.System.Windows.Forms.Control = Me.Label29
			point = New Global.System.Drawing.Point(397, 418)
			label35.Location = point
			Me.Label29.Name = "Label29"
			Dim label36 As Global.System.Windows.Forms.Control = Me.Label29
			size = New Global.System.Drawing.Size(191, 38)
			label36.Size = size
			Me.Label29.TabIndex = 7
			Me.Label29.Tag = "CR0021"
			Me.Label29.Text = "Ngày đặt cọc"
			Me.Label29.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.dtpNgayDatCoc.AllowDrop = True
			Me.dtpNgayDatCoc.CalendarForeColor = Global.System.Drawing.Color.OrangeRed
			Me.dtpNgayDatCoc.CalendarMonthBackground = Global.System.Drawing.Color.OldLace
			Me.dtpNgayDatCoc.CalendarTitleBackColor = Global.System.Drawing.Color.BlueViolet
			Me.dtpNgayDatCoc.CalendarTitleForeColor = Global.System.Drawing.Color.LightCoral
			Me.dtpNgayDatCoc.CalendarTrailingForeColor = Global.System.Drawing.SystemColors.ControlText
			Me.dtpNgayDatCoc.CustomFormat = "dd/MM/yyyy"
			Me.dtpNgayDatCoc.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.dtpNgayDatCoc.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.dtpNgayDatCoc.Format = Global.System.Windows.Forms.DateTimePickerFormat.Custom
			Dim dtpNgayDatCoc As Global.System.Windows.Forms.Control = Me.dtpNgayDatCoc
			point = New Global.System.Drawing.Point(593, 420)
			dtpNgayDatCoc.Location = point
			Dim dtpNgayDatCoc2 As Global.System.Windows.Forms.Control = Me.dtpNgayDatCoc
			padding = New Global.System.Windows.Forms.Padding(2)
			dtpNgayDatCoc2.Margin = padding
			Me.dtpNgayDatCoc.Name = "dtpNgayDatCoc"
			Dim dtpNgayDatCoc3 As Global.System.Windows.Forms.Control = Me.dtpNgayDatCoc
			size = New Global.System.Drawing.Size(196, 30)
			dtpNgayDatCoc3.Size = size
			Me.dtpNgayDatCoc.TabIndex = 2
			Dim dtpNgayDatCoc4 As Global.System.Windows.Forms.DateTimePicker = Me.dtpNgayDatCoc
			dateTime = New Global.System.DateTime(2010, 10, 2, 0, 0, 0, 0)
			dtpNgayDatCoc4.Value = dateTime
			Me.Label30.BackColor = Global.System.Drawing.Color.White
			Me.Label30.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label37 As Global.System.Windows.Forms.Control = Me.Label30
			point = New Global.System.Drawing.Point(3, 456)
			label37.Location = point
			Me.Label30.Name = "Label30"
			Dim label38 As Global.System.Windows.Forms.Control = Me.Label30
			size = New Global.System.Drawing.Size(191, 38)
			label38.Size = size
			Me.Label30.TabIndex = 7
			Me.Label30.Tag = "CR0022"
			Me.Label30.Text = "Số tiền còn lại"
			Me.Label30.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblTienConLai.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.lblTienConLai.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblTienConLai.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblTienConLai.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblTienConLai As Global.System.Windows.Forms.Control = Me.lblTienConLai
			point = New Global.System.Drawing.Point(199, 458)
			lblTienConLai.Location = point
			Dim lblTienConLai2 As Global.System.Windows.Forms.Control = Me.lblTienConLai
			padding = New Global.System.Windows.Forms.Padding(2)
			lblTienConLai2.Margin = padding
			Me.lblTienConLai.Name = "lblTienConLai"
			Dim lblTienConLai3 As Global.System.Windows.Forms.Control = Me.lblTienConLai
			size = New Global.System.Drawing.Size(193, 34)
			lblTienConLai3.Size = size
			Me.lblTienConLai.TabIndex = 7
			Me.lblTienConLai.Text = "0"
			Me.lblTienConLai.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label2.BackColor = Global.System.Drawing.Color.White
			Me.Label2.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label39 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(3, 494)
			label39.Location = point
			Me.Label2.Name = "Label2"
			Dim label40 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(191, 38)
			label40.Size = size
			Me.Label2.TabIndex = 19
			Me.Label2.Tag = "CR0023"
			Me.Label2.Text = "Ghi chú"
			Me.Label2.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblREMARK.BackColor = Global.System.Drawing.Color.White
			Me.lblREMARK.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblREMARK.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblREMARK.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblREMARK As Global.System.Windows.Forms.Control = Me.lblREMARK
			point = New Global.System.Drawing.Point(199, 496)
			lblREMARK.Location = point
			Dim lblREMARK2 As Global.System.Windows.Forms.Control = Me.lblREMARK
			padding = New Global.System.Windows.Forms.Padding(2)
			lblREMARK2.Margin = padding
			Me.lblREMARK.Name = "lblREMARK"
			Dim lblREMARK3 As Global.System.Windows.Forms.Control = Me.lblREMARK
			size = New Global.System.Drawing.Size(193, 34)
			lblREMARK3.Size = size
			Me.lblREMARK.TabIndex = 18
			Me.lblREMARK.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label3.BackColor = Global.System.Drawing.Color.White
			Me.Label3.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim label41 As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(3, 532)
			label41.Location = point
			Me.Label3.Name = "Label3"
			Dim label42 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(191, 44)
			label42.Size = size
			Me.Label3.TabIndex = 21
			Me.Label3.Tag = "CR0024"
			Me.Label3.Text = "phuc vu"
			Me.Label3.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.lblPV.BackColor = Global.System.Drawing.Color.White
			Me.lblPV.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblPV.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lblPV.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim lblPV As Global.System.Windows.Forms.Control = Me.lblPV
			point = New Global.System.Drawing.Point(199, 534)
			lblPV.Location = point
			Dim lblPV2 As Global.System.Windows.Forms.Control = Me.lblPV
			padding = New Global.System.Windows.Forms.Padding(2)
			lblPV2.Margin = padding
			Me.lblPV.Name = "lblPV"
			Dim lblPV3 As Global.System.Windows.Forms.Control = Me.lblPV
			size = New Global.System.Drawing.Size(193, 40)
			lblPV3.Size = size
			Me.lblPV.TabIndex = 22
			Me.lblPV.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lblDMMaBan.BackColor = Global.System.Drawing.Color.DimGray
			Dim lblDMMaBan As Global.System.Windows.Forms.Control = Me.lblDMMaBan
			point = New Global.System.Drawing.Point(397, 0)
			lblDMMaBan.Location = point
			Me.lblDMMaBan.Name = "lblDMMaBan"
			Dim lblDMMaBan2 As Global.System.Windows.Forms.Control = Me.lblDMMaBan
			size = New Global.System.Drawing.Size(39, 36)
			lblDMMaBan2.Size = size
			Me.lblDMMaBan.TabIndex = 28
			Me.lblDMMaBan.Visible = False
			Me.lblDMMaKhu.BackColor = Global.System.Drawing.Color.DimGray
			Dim lblDMMaKhu As Global.System.Windows.Forms.Control = Me.lblDMMaKhu
			point = New Global.System.Drawing.Point(594, 0)
			lblDMMaKhu.Location = point
			Me.lblDMMaKhu.Name = "lblDMMaKhu"
			Dim lblDMMaKhu2 As Global.System.Windows.Forms.Control = Me.lblDMMaKhu
			size = New Global.System.Drawing.Size(39, 36)
			lblDMMaKhu2.Size = size
			Me.lblDMMaKhu.TabIndex = 28
			Me.lblDMMaKhu.Visible = False
			Me.lblMaPV.BackColor = Global.System.Drawing.Color.DimGray
			Dim lblMaPV As Global.System.Windows.Forms.Control = Me.lblMaPV
			point = New Global.System.Drawing.Point(397, 38)
			lblMaPV.Location = point
			Me.lblMaPV.Name = "lblMaPV"
			Dim lblMaPV2 As Global.System.Windows.Forms.Control = Me.lblMaPV
			size = New Global.System.Drawing.Size(39, 36)
			lblMaPV2.Size = size
			Me.lblMaPV.TabIndex = 28
			Me.lblMaPV.Visible = False
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(8F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			Me.BackColor = Global.System.Drawing.Color.White
			size = New Global.System.Drawing.Size(791, 576)
			Me.ClientSize = size
			Me.Controls.Add(Me.panSua)
			Me.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 10F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			padding = New Global.System.Windows.Forms.Padding(4)
			Me.Margin = padding
			Me.Name = "frmAddReserPhong"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Reservation"
			Me.panSua.ResumeLayout(False)
			Me.TableLayoutPanel7.ResumeLayout(False)
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x04000145 RID: 325
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
