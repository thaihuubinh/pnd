﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My

Namespace prjIS_SalesPOS
	' Token: 0x02000018 RID: 24
	<DesignerGenerated()>
	Public Partial Class frmAddReserPhong
		Inherits Form

		' Token: 0x060002F5 RID: 757 RVA: 0x00024B28 File Offset: 0x00022D28
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmAddReserPhong_Load
			frmAddReserPhong.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mbytRunFirst = 1
			Me.mBlnNew = True
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000127 RID: 295
		' (get) Token: 0x060002F8 RID: 760 RVA: 0x00027E78 File Offset: 0x00026078
		' (set) Token: 0x060002F9 RID: 761 RVA: 0x00002809 File Offset: 0x00000A09
		Friend Overridable Property panSua As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._panSua
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._panSua = value
			End Set
		End Property

		' Token: 0x17000128 RID: 296
		' (get) Token: 0x060002FA RID: 762 RVA: 0x00027E90 File Offset: 0x00026090
		' (set) Token: 0x060002FB RID: 763 RVA: 0x00027EA8 File Offset: 0x000260A8
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000129 RID: 297
		' (get) Token: 0x060002FC RID: 764 RVA: 0x00027F14 File Offset: 0x00026114
		' (set) Token: 0x060002FD RID: 765 RVA: 0x00002813 File Offset: 0x00000A13
		Friend Overridable Property lblstt As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblstt
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblstt = value
			End Set
		End Property

		' Token: 0x1700012A RID: 298
		' (get) Token: 0x060002FE RID: 766 RVA: 0x00027F2C File Offset: 0x0002612C
		' (set) Token: 0x060002FF RID: 767 RVA: 0x0000281D File Offset: 0x00000A1D
		Friend Overridable Property lblNo As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblNo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblNo = value
			End Set
		End Property

		' Token: 0x1700012B RID: 299
		' (get) Token: 0x06000300 RID: 768 RVA: 0x00027F44 File Offset: 0x00026144
		' (set) Token: 0x06000301 RID: 769 RVA: 0x00027F5C File Offset: 0x0002615C
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x1700012C RID: 300
		' (get) Token: 0x06000302 RID: 770 RVA: 0x00027FC8 File Offset: 0x000261C8
		' (set) Token: 0x06000303 RID: 771 RVA: 0x00002827 File Offset: 0x00000A27
		Friend Overridable Property lblDV As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDV = value
			End Set
		End Property

		' Token: 0x1700012D RID: 301
		' (get) Token: 0x06000304 RID: 772 RVA: 0x00027FE0 File Offset: 0x000261E0
		' (set) Token: 0x06000305 RID: 773 RVA: 0x00027FF8 File Offset: 0x000261F8
		Friend Overridable Property lblTenKH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTenKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblTenKH IsNot Nothing
				If flag Then
					RemoveHandler Me._lblTenKH.Click, AddressOf Me.lblTenKH_Click
				End If
				Me._lblTenKH = value
				flag = Me._lblTenKH IsNot Nothing
				If flag Then
					AddHandler Me._lblTenKH.Click, AddressOf Me.lblTenKH_Click
				End If
			End Set
		End Property

		' Token: 0x1700012E RID: 302
		' (get) Token: 0x06000306 RID: 774 RVA: 0x00028064 File Offset: 0x00026264
		' (set) Token: 0x06000307 RID: 775 RVA: 0x00002831 File Offset: 0x00000A31
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x1700012F RID: 303
		' (get) Token: 0x06000308 RID: 776 RVA: 0x0002807C File Offset: 0x0002627C
		' (set) Token: 0x06000309 RID: 777 RVA: 0x0000283B File Offset: 0x00000A3B
		Friend Overridable Property lblTongSoPhong As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTongSoPhong
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTongSoPhong = value
			End Set
		End Property

		' Token: 0x17000130 RID: 304
		' (get) Token: 0x0600030A RID: 778 RVA: 0x00028094 File Offset: 0x00026294
		' (set) Token: 0x0600030B RID: 779 RVA: 0x00002845 File Offset: 0x00000A45
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000131 RID: 305
		' (get) Token: 0x0600030C RID: 780 RVA: 0x000280AC File Offset: 0x000262AC
		' (set) Token: 0x0600030D RID: 781 RVA: 0x000280C4 File Offset: 0x000262C4
		Friend Overridable Property lblMaKH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMaKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblMaKH IsNot Nothing
				If flag Then
					RemoveHandler Me._lblMaKH.Click, AddressOf Me.lblMaKH_Click
				End If
				Me._lblMaKH = value
				flag = Me._lblMaKH IsNot Nothing
				If flag Then
					AddHandler Me._lblMaKH.Click, AddressOf Me.lblMaKH_Click
				End If
			End Set
		End Property

		' Token: 0x17000132 RID: 306
		' (get) Token: 0x0600030E RID: 782 RVA: 0x00028130 File Offset: 0x00026330
		' (set) Token: 0x0600030F RID: 783 RVA: 0x0000284F File Offset: 0x00000A4F
		Friend Overridable Property lblEmail As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblEmail
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblEmail = value
			End Set
		End Property

		' Token: 0x17000133 RID: 307
		' (get) Token: 0x06000310 RID: 784 RVA: 0x00028148 File Offset: 0x00026348
		' (set) Token: 0x06000311 RID: 785 RVA: 0x00002859 File Offset: 0x00000A59
		Friend Overridable Property Label6 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label6 = value
			End Set
		End Property

		' Token: 0x17000134 RID: 308
		' (get) Token: 0x06000312 RID: 786 RVA: 0x00028160 File Offset: 0x00026360
		' (set) Token: 0x06000313 RID: 787 RVA: 0x00002863 File Offset: 0x00000A63
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x17000135 RID: 309
		' (get) Token: 0x06000314 RID: 788 RVA: 0x00028178 File Offset: 0x00026378
		' (set) Token: 0x06000315 RID: 789 RVA: 0x0000286D File Offset: 0x00000A6D
		Friend Overridable Property lblPhone As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPhone
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPhone = value
			End Set
		End Property

		' Token: 0x17000136 RID: 310
		' (get) Token: 0x06000316 RID: 790 RVA: 0x00028190 File Offset: 0x00026390
		' (set) Token: 0x06000317 RID: 791 RVA: 0x00002877 File Offset: 0x00000A77
		Friend Overridable Property Label10 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label10 = value
			End Set
		End Property

		' Token: 0x17000137 RID: 311
		' (get) Token: 0x06000318 RID: 792 RVA: 0x000281A8 File Offset: 0x000263A8
		' (set) Token: 0x06000319 RID: 793 RVA: 0x00002881 File Offset: 0x00000A81
		Friend Overridable Property lblContact As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblContact
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblContact = value
			End Set
		End Property

		' Token: 0x17000138 RID: 312
		' (get) Token: 0x0600031A RID: 794 RVA: 0x000281C0 File Offset: 0x000263C0
		' (set) Token: 0x0600031B RID: 795 RVA: 0x0000288B File Offset: 0x00000A8B
		Friend Overridable Property Label7 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		' Token: 0x17000139 RID: 313
		' (get) Token: 0x0600031C RID: 796 RVA: 0x000281D8 File Offset: 0x000263D8
		' (set) Token: 0x0600031D RID: 797 RVA: 0x00002895 File Offset: 0x00000A95
		Friend Overridable Property dtpNgayDat As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpNgayDat
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Me._dtpNgayDat = value
			End Set
		End Property

		' Token: 0x1700013A RID: 314
		' (get) Token: 0x0600031E RID: 798 RVA: 0x000281F0 File Offset: 0x000263F0
		' (set) Token: 0x0600031F RID: 799 RVA: 0x0000289F File Offset: 0x00000A9F
		Friend Overridable Property Label12 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label12
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label12 = value
			End Set
		End Property

		' Token: 0x1700013B RID: 315
		' (get) Token: 0x06000320 RID: 800 RVA: 0x00028208 File Offset: 0x00026408
		' (set) Token: 0x06000321 RID: 801 RVA: 0x000028A9 File Offset: 0x00000AA9
		Friend Overridable Property TableLayoutPanel7 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel7 = value
			End Set
		End Property

		' Token: 0x1700013C RID: 316
		' (get) Token: 0x06000322 RID: 802 RVA: 0x00028220 File Offset: 0x00026420
		' (set) Token: 0x06000323 RID: 803 RVA: 0x000028B3 File Offset: 0x00000AB3
		Friend Overridable Property Label13 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label13
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label13 = value
			End Set
		End Property

		' Token: 0x1700013D RID: 317
		' (get) Token: 0x06000324 RID: 804 RVA: 0x00028238 File Offset: 0x00026438
		' (set) Token: 0x06000325 RID: 805 RVA: 0x000028BD File Offset: 0x00000ABD
		Friend Overridable Property Label14 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label14
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label14 = value
			End Set
		End Property

		' Token: 0x1700013E RID: 318
		' (get) Token: 0x06000326 RID: 806 RVA: 0x00028250 File Offset: 0x00026450
		' (set) Token: 0x06000327 RID: 807 RVA: 0x00028268 File Offset: 0x00026468
		Friend Overridable Property lblHour As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblHour
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblHour IsNot Nothing
				If flag Then
					RemoveHandler Me._lblHour.Click, AddressOf Me.lblHour_Click
				End If
				Me._lblHour = value
				flag = Me._lblHour IsNot Nothing
				If flag Then
					AddHandler Me._lblHour.Click, AddressOf Me.lblHour_Click
				End If
			End Set
		End Property

		' Token: 0x1700013F RID: 319
		' (get) Token: 0x06000328 RID: 808 RVA: 0x000282D4 File Offset: 0x000264D4
		' (set) Token: 0x06000329 RID: 809 RVA: 0x000282EC File Offset: 0x000264EC
		Friend Overridable Property lblMinute As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMinute
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblMinute IsNot Nothing
				If flag Then
					RemoveHandler Me._lblMinute.Click, AddressOf Me.lblMinute_Click
				End If
				Me._lblMinute = value
				flag = Me._lblMinute IsNot Nothing
				If flag Then
					AddHandler Me._lblMinute.Click, AddressOf Me.lblMinute_Click
				End If
			End Set
		End Property

		' Token: 0x17000140 RID: 320
		' (get) Token: 0x0600032A RID: 810 RVA: 0x00028358 File Offset: 0x00026558
		' (set) Token: 0x0600032B RID: 811 RVA: 0x000028C7 File Offset: 0x00000AC7
		Friend Overridable Property Label15 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label15
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label15 = value
			End Set
		End Property

		' Token: 0x17000141 RID: 321
		' (get) Token: 0x0600032C RID: 812 RVA: 0x00028370 File Offset: 0x00026570
		' (set) Token: 0x0600032D RID: 813 RVA: 0x000028D1 File Offset: 0x00000AD1
		Friend Overridable Property Label16 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label16
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label16 = value
			End Set
		End Property

		' Token: 0x17000142 RID: 322
		' (get) Token: 0x0600032E RID: 814 RVA: 0x00028388 File Offset: 0x00026588
		' (set) Token: 0x0600032F RID: 815 RVA: 0x000283A0 File Offset: 0x000265A0
		Friend Overridable Property dtpNgayNhan As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpNgayNhan
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpNgayNhan IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpNgayNhan.ValueChanged, AddressOf Me.dtpNgayNhan_ValueChanged
				End If
				Me._dtpNgayNhan = value
				flag = Me._dtpNgayNhan IsNot Nothing
				If flag Then
					AddHandler Me._dtpNgayNhan.ValueChanged, AddressOf Me.dtpNgayNhan_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x17000143 RID: 323
		' (get) Token: 0x06000330 RID: 816 RVA: 0x0002840C File Offset: 0x0002660C
		' (set) Token: 0x06000331 RID: 817 RVA: 0x00028424 File Offset: 0x00026624
		Friend Overridable Property dtpNgayTra As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpNgayTra
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpNgayTra IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpNgayTra.ValueChanged, AddressOf Me.dtpNgayTra_ValueChanged
				End If
				Me._dtpNgayTra = value
				flag = Me._dtpNgayTra IsNot Nothing
				If flag Then
					AddHandler Me._dtpNgayTra.ValueChanged, AddressOf Me.dtpNgayTra_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x17000144 RID: 324
		' (get) Token: 0x06000332 RID: 818 RVA: 0x00028490 File Offset: 0x00026690
		' (set) Token: 0x06000333 RID: 819 RVA: 0x000028DB File Offset: 0x00000ADB
		Friend Overridable Property Label9 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label9 = value
			End Set
		End Property

		' Token: 0x17000145 RID: 325
		' (get) Token: 0x06000334 RID: 820 RVA: 0x000284A8 File Offset: 0x000266A8
		' (set) Token: 0x06000335 RID: 821 RVA: 0x000284C0 File Offset: 0x000266C0
		Friend Overridable Property lblSelectTable As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblSelectTable
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblSelectTable IsNot Nothing
				If flag Then
					RemoveHandler Me._lblSelectTable.Click, AddressOf Me.lblSelectTable_Click
				End If
				Me._lblSelectTable = value
				flag = Me._lblSelectTable IsNot Nothing
				If flag Then
					AddHandler Me._lblSelectTable.Click, AddressOf Me.lblSelectTable_Click
				End If
			End Set
		End Property

		' Token: 0x17000146 RID: 326
		' (get) Token: 0x06000336 RID: 822 RVA: 0x0002852C File Offset: 0x0002672C
		' (set) Token: 0x06000337 RID: 823 RVA: 0x000028E5 File Offset: 0x00000AE5
		Friend Overridable Property Label17 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label17
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label17 = value
			End Set
		End Property

		' Token: 0x17000147 RID: 327
		' (get) Token: 0x06000338 RID: 824 RVA: 0x00028544 File Offset: 0x00026744
		' (set) Token: 0x06000339 RID: 825 RVA: 0x000028EF File Offset: 0x00000AEF
		Friend Overridable Property lblLoaiPhong As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLoaiPhong
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblLoaiPhong = value
			End Set
		End Property

		' Token: 0x17000148 RID: 328
		' (get) Token: 0x0600033A RID: 826 RVA: 0x0002855C File Offset: 0x0002675C
		' (set) Token: 0x0600033B RID: 827 RVA: 0x000028F9 File Offset: 0x00000AF9
		Friend Overridable Property Label19 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label19
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label19 = value
			End Set
		End Property

		' Token: 0x17000149 RID: 329
		' (get) Token: 0x0600033C RID: 828 RVA: 0x00028574 File Offset: 0x00026774
		' (set) Token: 0x0600033D RID: 829 RVA: 0x00002903 File Offset: 0x00000B03
		Friend Overridable Property lblSoDem As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblSoDem
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblSoDem = value
			End Set
		End Property

		' Token: 0x1700014A RID: 330
		' (get) Token: 0x0600033E RID: 830 RVA: 0x0002858C File Offset: 0x0002678C
		' (set) Token: 0x0600033F RID: 831 RVA: 0x0000290D File Offset: 0x00000B0D
		Friend Overridable Property Label21 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label21
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label21 = value
			End Set
		End Property

		' Token: 0x1700014B RID: 331
		' (get) Token: 0x06000340 RID: 832 RVA: 0x000285A4 File Offset: 0x000267A4
		' (set) Token: 0x06000341 RID: 833 RVA: 0x00002917 File Offset: 0x00000B17
		Friend Overridable Property lblTongSoDem As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTongSoDem
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTongSoDem = value
			End Set
		End Property

		' Token: 0x1700014C RID: 332
		' (get) Token: 0x06000342 RID: 834 RVA: 0x000285BC File Offset: 0x000267BC
		' (set) Token: 0x06000343 RID: 835 RVA: 0x000285D4 File Offset: 0x000267D4
		Friend Overridable Property lblDonGia As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDonGia
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblDonGia IsNot Nothing
				If flag Then
					RemoveHandler Me._lblDonGia.Click, AddressOf Me.lblDonGia_Click
				End If
				Me._lblDonGia = value
				flag = Me._lblDonGia IsNot Nothing
				If flag Then
					AddHandler Me._lblDonGia.Click, AddressOf Me.lblDonGia_Click
				End If
			End Set
		End Property

		' Token: 0x1700014D RID: 333
		' (get) Token: 0x06000344 RID: 836 RVA: 0x00028640 File Offset: 0x00026840
		' (set) Token: 0x06000345 RID: 837 RVA: 0x00002921 File Offset: 0x00000B21
		Friend Overridable Property Label24 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label24
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label24 = value
			End Set
		End Property

		' Token: 0x1700014E RID: 334
		' (get) Token: 0x06000346 RID: 838 RVA: 0x00028658 File Offset: 0x00026858
		' (set) Token: 0x06000347 RID: 839 RVA: 0x0000292B File Offset: 0x00000B2B
		Friend Overridable Property lblNoidung As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblNoidung
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblNoidung = value
			End Set
		End Property

		' Token: 0x1700014F RID: 335
		' (get) Token: 0x06000348 RID: 840 RVA: 0x00028670 File Offset: 0x00026870
		' (set) Token: 0x06000349 RID: 841 RVA: 0x00002935 File Offset: 0x00000B35
		Friend Overridable Property lblTienThanhToan As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTienThanhToan
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTienThanhToan = value
			End Set
		End Property

		' Token: 0x17000150 RID: 336
		' (get) Token: 0x0600034A RID: 842 RVA: 0x00028688 File Offset: 0x00026888
		' (set) Token: 0x0600034B RID: 843 RVA: 0x0000293F File Offset: 0x00000B3F
		Friend Overridable Property Label27 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label27
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label27 = value
			End Set
		End Property

		' Token: 0x17000151 RID: 337
		' (get) Token: 0x0600034C RID: 844 RVA: 0x000286A0 File Offset: 0x000268A0
		' (set) Token: 0x0600034D RID: 845 RVA: 0x000286B8 File Offset: 0x000268B8
		Friend Overridable Property lblTienDatCoc As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTienDatCoc
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblTienDatCoc IsNot Nothing
				If flag Then
					RemoveHandler Me._lblTienDatCoc.Click, AddressOf Me.lblTienDatCoc_Click
				End If
				Me._lblTienDatCoc = value
				flag = Me._lblTienDatCoc IsNot Nothing
				If flag Then
					AddHandler Me._lblTienDatCoc.Click, AddressOf Me.lblTienDatCoc_Click
				End If
			End Set
		End Property

		' Token: 0x17000152 RID: 338
		' (get) Token: 0x0600034E RID: 846 RVA: 0x00028724 File Offset: 0x00026924
		' (set) Token: 0x0600034F RID: 847 RVA: 0x00002949 File Offset: 0x00000B49
		Friend Overridable Property Label29 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label29
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label29 = value
			End Set
		End Property

		' Token: 0x17000153 RID: 339
		' (get) Token: 0x06000350 RID: 848 RVA: 0x0002873C File Offset: 0x0002693C
		' (set) Token: 0x06000351 RID: 849 RVA: 0x00002953 File Offset: 0x00000B53
		Friend Overridable Property dtpNgayDatCoc As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpNgayDatCoc
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Me._dtpNgayDatCoc = value
			End Set
		End Property

		' Token: 0x17000154 RID: 340
		' (get) Token: 0x06000352 RID: 850 RVA: 0x00028754 File Offset: 0x00026954
		' (set) Token: 0x06000353 RID: 851 RVA: 0x0000295D File Offset: 0x00000B5D
		Friend Overridable Property Label30 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label30
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label30 = value
			End Set
		End Property

		' Token: 0x17000155 RID: 341
		' (get) Token: 0x06000354 RID: 852 RVA: 0x0002876C File Offset: 0x0002696C
		' (set) Token: 0x06000355 RID: 853 RVA: 0x00002967 File Offset: 0x00000B67
		Friend Overridable Property lblTienConLai As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTienConLai
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTienConLai = value
			End Set
		End Property

		' Token: 0x17000156 RID: 342
		' (get) Token: 0x06000356 RID: 854 RVA: 0x00028784 File Offset: 0x00026984
		' (set) Token: 0x06000357 RID: 855 RVA: 0x00002971 File Offset: 0x00000B71
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000157 RID: 343
		' (get) Token: 0x06000358 RID: 856 RVA: 0x0002879C File Offset: 0x0002699C
		' (set) Token: 0x06000359 RID: 857 RVA: 0x000287B4 File Offset: 0x000269B4
		Friend Overridable Property lblREMARK As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblREMARK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblREMARK IsNot Nothing
				If flag Then
					RemoveHandler Me._lblREMARK.Click, AddressOf Me.lblREMARK_Click
				End If
				Me._lblREMARK = value
				flag = Me._lblREMARK IsNot Nothing
				If flag Then
					AddHandler Me._lblREMARK.Click, AddressOf Me.lblREMARK_Click
				End If
			End Set
		End Property

		' Token: 0x17000158 RID: 344
		' (get) Token: 0x0600035A RID: 858 RVA: 0x00028820 File Offset: 0x00026A20
		' (set) Token: 0x0600035B RID: 859 RVA: 0x0000297B File Offset: 0x00000B7B
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x17000159 RID: 345
		' (get) Token: 0x0600035C RID: 860 RVA: 0x00028838 File Offset: 0x00026A38
		' (set) Token: 0x0600035D RID: 861 RVA: 0x00028850 File Offset: 0x00026A50
		Friend Overridable Property lblPV As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblPV IsNot Nothing
				If flag Then
					RemoveHandler Me._lblPV.Click, AddressOf Me.lblPV_Click
				End If
				Me._lblPV = value
				flag = Me._lblPV IsNot Nothing
				If flag Then
					AddHandler Me._lblPV.Click, AddressOf Me.lblPV_Click
				End If
			End Set
		End Property

		' Token: 0x1700015A RID: 346
		' (get) Token: 0x0600035E RID: 862 RVA: 0x000288BC File Offset: 0x00026ABC
		' (set) Token: 0x0600035F RID: 863 RVA: 0x00002985 File Offset: 0x00000B85
		Friend Overridable Property lblDMMaBan As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDMMaBan
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDMMaBan = value
			End Set
		End Property

		' Token: 0x1700015B RID: 347
		' (get) Token: 0x06000360 RID: 864 RVA: 0x000288D4 File Offset: 0x00026AD4
		' (set) Token: 0x06000361 RID: 865 RVA: 0x0000298F File Offset: 0x00000B8F
		Friend Overridable Property lblDMMaKhu As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDMMaKhu
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDMMaKhu = value
			End Set
		End Property

		' Token: 0x1700015C RID: 348
		' (get) Token: 0x06000362 RID: 866 RVA: 0x000288EC File Offset: 0x00026AEC
		' (set) Token: 0x06000363 RID: 867 RVA: 0x00002999 File Offset: 0x00000B99
		Friend Overridable Property lblMaPV As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMaPV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMaPV = value
			End Set
		End Property

		' Token: 0x1700015D RID: 349
		' (get) Token: 0x06000364 RID: 868 RVA: 0x00028904 File Offset: 0x00026B04
		' (set) Token: 0x06000365 RID: 869 RVA: 0x000029A3 File Offset: 0x00000BA3
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Me._mbdsSource = value
			End Set
		End Property

		' Token: 0x1700015E RID: 350
		' (get) Token: 0x06000366 RID: 870 RVA: 0x0002891C File Offset: 0x00026B1C
		' (set) Token: 0x06000367 RID: 871 RVA: 0x000029AD File Offset: 0x00000BAD
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x06000368 RID: 872 RVA: 0x00028934 File Offset: 0x00026B34
		Private Sub lblREMARK_Click(sender As Object, e As EventArgs)
			Try
				Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
				frmKeyBoard.pStrEnterText = Me.lblREMARK.Text
				frmKeyBoard.ShowDialog()
				Me.lblREMARK.Text = frmKeyBoard.pStrEnterText
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - lblREMARK_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000369 RID: 873 RVA: 0x000289DC File Offset: 0x00026BDC
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnExit_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600036A RID: 874 RVA: 0x00028A5C File Offset: 0x00026C5C
		Private Sub lblHour_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad = New frmNumPad()
				frmNumPad.pSglNumberReturn = Conversions.ToSingle(Me.lblHour.Text)
				frmNumPad.ShowDialog()
				Me.lblHour.Text = Conversions.ToString(frmNumPad.pSglNumberReturn)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - lblHour_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600036B RID: 875 RVA: 0x00028B10 File Offset: 0x00026D10
		Private Sub lblMinute_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad = New frmNumPad()
				frmNumPad.pSglNumberReturn = Conversions.ToSingle(Me.lblMinute.Text)
				frmNumPad.ShowDialog()
				Me.lblMinute.Text = Conversions.ToString(frmNumPad.pSglNumberReturn)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - lblMinute_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600036C RID: 876 RVA: 0x00028BC4 File Offset: 0x00026DC4
		Private Sub lblSelectTable_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim frmSelectTable As frmSelectTable = New frmSelectTable()
				frmSelectTable.ShowDialog()
				Dim flag As Boolean = frmSelectTable.pblnIsOK
				If flag Then
					Dim array As String() = frmSelectTable.pstrTableSelect.Split(New Char() { ","c })
					Me.lblDMMaBan.Text = frmSelectTable.pstrTableSelect
					Dim text As String = ""
					Dim num As Integer = 0
					flag = array.Length > 0
					If flag Then
						For Each text2 As String In array
							Dim array3 As SqlParameter() = New SqlParameter(1) {}
							array3(0) = New SqlParameter("@nvcMABAN", text2.Trim())
							Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
							Dim array4 As SqlParameter() = array3
							Dim text3 As String = "SP_FRMDMBAN_GETTENBAN_FROMMABAN"
							Dim num2 As Integer = 0
							Dim clsConnect As clsConnect = New clsConnect(gStrConISDANHMUC, array4, text3, num2)
							flag = clsConnect.Rows.Count > 0
							If flag Then
								text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(text.Trim().Length > 0, ", ", "")), clsConnect.Rows(0)(0).ToString().Trim()))
							End If
							num += 1
						Next
					End If
					Me.lblSelectTable.Text = text
					Me.lblTongSoPhong.Text = Conversions.ToString(Interaction.IIf(num > 0, num - 1, 0))
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - lblSelectTable_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600036D RID: 877 RVA: 0x00028DB8 File Offset: 0x00026FB8
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.lblSelectTable.Text.Trim().Length = 0
				If flag Then
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(25), Me.mArrStrFrmMess(26), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.ThongTin)
				Else
					Dim text As String = Strings.Right("00" + Me.lblHour.Text, 2) + ":" + Strings.Right("00" + Me.lblMinute.Text, 2) + ":00"
					flag = Not Information.IsDate(text)
					If flag Then
						MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(27), Me.mArrStrFrmMess(26), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.ThongTin)
					Else
						Dim array As String() = Me.lblDMMaBan.Text.Split(New Char() { ","c })
						flag = array.Length > 0
						If flag Then
							Dim flag2 As Boolean = Me.mbytFormStatus = 1
							If flag2 Then
								Dim array2 As SqlParameter() = New SqlParameter(19) {}
								array2(0) = New SqlParameter("@pnchOBJNAME", "")
								array2(1) = New SqlParameter("@pnchMAKH", mdlVariable.gStrStockCode)
								array2(2) = New SqlParameter("@pnchMADV", Me.lblMaKH.Text.Trim())
								array2(3) = New SqlParameter("@pnchREDATE", String.Concat(New String() { Me.dtpNgayDat.Value.Day.ToString("00"), "/", Me.dtpNgayDat.Value.Month.ToString("00"), "/", Me.dtpNgayDat.Value.Year.ToString("0000") }))
								array2(4) = New SqlParameter("@pnchRETIME", text)
								array2(5) = New SqlParameter("@pnchINDATE", String.Concat(New String() { Me.dtpNgayNhan.Value.Day.ToString("00"), "/", Me.dtpNgayNhan.Value.Month.ToString("00"), "/", Me.dtpNgayNhan.Value.Year.ToString("0000") }))
								array2(6) = New SqlParameter("@pnchOUTDATE", String.Concat(New String() { Me.dtpNgayTra.Value.Day.ToString("00"), "/", Me.dtpNgayTra.Value.Month.ToString("00"), "/", Me.dtpNgayTra.Value.Year.ToString("0000") }))
								array2(7) = New SqlParameter("@pnchMAUSER", mdlVariable.gStrUser)
								array2(8) = New SqlParameter("@pintTONGSOPHONG", Conversion.Val(Me.lblTongSoPhong.Text.Replace(",", "")))
								array2(9) = New SqlParameter("@pintSODEM", Conversion.Val(Me.lblSoDem.Text.Replace(",", "")))
								array2(10) = New SqlParameter("@pintTONGSODEM", Conversion.Val(Me.lblTongSoDem.Text.Replace(",", "")))
								array2(11) = New SqlParameter("@pmnyDONGIA", Conversion.Val(Me.lblDonGia.Text.Replace(",", "")))
								array2(12) = New SqlParameter("@pmnyTIENTHANHTOAN", Conversion.Val(Me.lblTienThanhToan.Text.Replace(",", "")))
								array2(13) = New SqlParameter("@pmnyTIENCOC", Conversion.Val(Me.lblTienDatCoc.Text.Replace(",", "")))
								array2(14) = New SqlParameter("@pnchNGAYCOC", String.Concat(New String() { Me.dtpNgayDatCoc.Value.Day.ToString("00"), "/", Me.dtpNgayDatCoc.Value.Month.ToString("00"), "/", Me.dtpNgayDatCoc.Value.Year.ToString("0000") }))
								array2(15) = New SqlParameter("@pmnyTIENCONLAI", Conversion.Val(Me.lblTienConLai.Text.Replace(",", "")))
								array2(16) = New SqlParameter("@pnchREMARK", Me.lblREMARK.Text.Trim())
								array2(17) = New SqlParameter("@pnchMAUSERUP", Me.lblMaPV.Text.Trim())
								array2(18) = New SqlParameter()
								array2(18).Direction = ParameterDirection.ReturnValue
								array2(18).ParameterName = "@pintOBJID"
								Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
								Dim array3 As SqlParameter() = array2
								Dim text2 As String = "SP_FRMRESERPHONG_INSERT"
								Dim flag3 As Boolean = Nothing
								Dim flag4 As Boolean = flag3
								Dim clsConnect As clsConnect = New clsConnect(gStrConISDANHMUC, array3, text2, flag4)
								flag2 = Operators.ConditionalCompareObjectGreater(array2(18).Value, 0, False)
								If flag2 Then
									For Each text3 As String In array
										Dim array5 As SqlParameter() = New SqlParameter(2) {}
										array5(0) = New SqlParameter("@pnchMADATPHONG", RuntimeHelpers.GetObjectValue(array2(18).Value))
										array5(1) = New SqlParameter("@pnchMAPHONG", text3.Trim())
										Dim gStrConISDANHMUC2 As String = mdlVariable.gStrConISDANHMUC
										Dim array6 As SqlParameter() = array5
										Dim text4 As String = "SP_FRMRESERPHONG_INSERT_2"
										flag4 = Nothing
										flag3 = flag4
										Dim clsConnect2 As clsConnect = New clsConnect(gStrConISDANHMUC2, array6, text4, flag3)
									Next
								Else
									flag2 = Operators.ConditionalCompareObjectEqual(array2(18).Value, -5, False)
									If flag2 Then
										MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(28), Me.mArrStrFrmMess(29), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
										Return
									End If
									flag2 = Operators.ConditionalCompareObjectEqual(array2(18).Value, -3, False)
									If flag2 Then
										MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(30), Me.mArrStrFrmMess(29), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
										Return
									End If
									flag2 = Operators.ConditionalCompareObjectEqual(array2(18).Value, -4, False)
									If flag2 Then
										MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(1), Me.mArrStrFrmMess(29), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
										Return
									End If
								End If
							Else
								Dim array7 As SqlParameter() = New SqlParameter(20) {}
								array7(0) = New SqlParameter("@pnchOBJNAME", "")
								array7(1) = New SqlParameter("@pnchMAKH", mdlVariable.gStrStockCode)
								array7(2) = New SqlParameter("@pnchMADV", Me.lblMaKH.Text.Trim())
								array7(3) = New SqlParameter("@pnchREDATE", String.Concat(New String() { Me.dtpNgayDat.Value.Day.ToString("00"), "/", Me.dtpNgayDat.Value.Month.ToString("00"), "/", Me.dtpNgayDat.Value.Year.ToString("0000") }))
								array7(4) = New SqlParameter("@pnchRETIME", text)
								array7(5) = New SqlParameter("@pnchINDATE", String.Concat(New String() { Me.dtpNgayNhan.Value.Day.ToString("00"), "/", Me.dtpNgayNhan.Value.Month.ToString("00"), "/", Me.dtpNgayNhan.Value.Year.ToString("0000") }))
								array7(6) = New SqlParameter("@pnchOUTDATE", String.Concat(New String() { Me.dtpNgayTra.Value.Day.ToString("00"), "/", Me.dtpNgayTra.Value.Month.ToString("00"), "/", Me.dtpNgayTra.Value.Year.ToString("0000") }))
								array7(7) = New SqlParameter("@pnchMAUSER", mdlVariable.gStrUser)
								array7(8) = New SqlParameter("@pintTONGSOPHONG", Conversion.Val(Me.lblTongSoPhong.Text.Replace(",", "")))
								array7(9) = New SqlParameter("@pintSODEM", Conversion.Val(Me.lblSoDem.Text.Replace(",", "")))
								array7(10) = New SqlParameter("@pintTONGSODEM", Conversion.Val(Me.lblTongSoDem.Text.Replace(",", "")))
								array7(11) = New SqlParameter("@pmnyDONGIA", Conversion.Val(Me.lblDonGia.Text.Replace(",", "")))
								array7(12) = New SqlParameter("@pmnyTIENTHANHTOAN", Conversion.Val(Me.lblTienThanhToan.Text.Replace(",", "")))
								array7(13) = New SqlParameter("@pmnyTIENCOC", Conversion.Val(Me.lblTienDatCoc.Text.Replace(",", "")))
								array7(14) = New SqlParameter("@pnchNGAYCOC", String.Concat(New String() { Me.dtpNgayDatCoc.Value.Day.ToString("00"), "/", Me.dtpNgayDatCoc.Value.Month.ToString("00"), "/", Me.dtpNgayDatCoc.Value.Year.ToString("0000") }))
								array7(15) = New SqlParameter("@pmnyTIENCONLAI", Conversion.Val(Me.lblTienConLai.Text.Replace(",", "")))
								array7(16) = New SqlParameter("@pnchREMARK", Me.lblREMARK.Text.Trim())
								array7(17) = New SqlParameter("@pnchMAUSERUP", Me.lblMaPV.Text.Trim())
								array7(18) = New SqlParameter()
								array7(18).Direction = ParameterDirection.ReturnValue
								array7(18).ParameterName = "@pintOBJID"
								array7(19) = New SqlParameter("@pintOBJID", Conversion.Val(Me.lblNo.Text))
								Dim gStrConISDANHMUC3 As String = mdlVariable.gStrConISDANHMUC
								Dim array8 As SqlParameter() = array7
								Dim text5 As String = "SP_FRMRESERPHONG_MODIFY"
								Dim flag4 As Boolean = Nothing
								Dim flag3 As Boolean = flag4
								Dim clsConnect3 As clsConnect = New clsConnect(gStrConISDANHMUC3, array8, text5, flag3)
								flag2 = Operators.ConditionalCompareObjectEqual(array7(18).Value, 0, False)
								If flag2 Then
									For Each text6 As String In array
										Dim array10 As SqlParameter() = New SqlParameter(2) {}
										array10(0) = New SqlParameter("@pnchMADATPHONG", Me.lblNo.Text)
										array10(1) = New SqlParameter("@pnchMAPHONG", text6.Trim())
										Dim gStrConISDANHMUC4 As String = mdlVariable.gStrConISDANHMUC
										Dim array11 As SqlParameter() = array10
										Dim text7 As String = "SP_FRMRESERPHONG_INSERT_2"
										flag4 = Nothing
										flag3 = flag4
										Dim clsConnect4 As clsConnect = New clsConnect(gStrConISDANHMUC4, array11, text7, flag3)
									Next
								Else
									flag2 = Operators.ConditionalCompareObjectEqual(array7(18).Value, -5, False)
									If flag2 Then
										MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(28), Me.mArrStrFrmMess(29), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
										Return
									End If
									flag2 = Operators.ConditionalCompareObjectEqual(array7(18).Value, -3, False)
									If flag2 Then
										MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(30), Me.mArrStrFrmMess(29), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
										Return
									End If
									flag2 = Operators.ConditionalCompareObjectEqual(array7(18).Value, -4, False)
									If flag2 Then
										MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(1), Me.mArrStrFrmMess(29), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
										Return
									End If
								End If
							End If
						End If
						Me.Close()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnSave_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600036E RID: 878 RVA: 0x00029C6C File Offset: 0x00027E6C
		Private Sub lblPV_Click(sender As Object, e As EventArgs)
			Try
				Dim frmUSER As frmUSER1 = New frmUSER1()
				frmUSER.pBytOpen_From_Menu = 7
				frmUSER.ShowDialog()
				Me.lblMaPV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmUSER.pStrOBJID, "", False) = 0, Me.lblMaPV.Text, frmUSER.pStrOBJID.Trim()))
				Me.lblPV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmUSER.pStrOBJNAME, "", False) = 0, Me.lblPV.Text, frmUSER.pStrOBJNAME.Trim()))
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - lblPV_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600036F RID: 879 RVA: 0x00029D78 File Offset: 0x00027F78
		Private Sub frmAddReserPhong_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Me.dtpNgayDat.Format = DateTimePickerFormat.Custom
				Me.dtpNgayDat.CustomFormat = "dd/MM/yyyy"
				Dim flag As Boolean = Me.mbytFormStatus = 1
				If flag Then
					Me.dtpNgayDat.Value = Conversions.ToDate(String.Concat(New String() { DateAndTime.Today.Year.ToString("0000"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Day.ToString("00") }))
				End If
				Me.dtpNgayDatCoc.Format = DateTimePickerFormat.Custom
				Me.dtpNgayDatCoc.CustomFormat = "dd/MM/yyyy"
				flag = Me.mbytFormStatus = 1
				If flag Then
					Me.dtpNgayDatCoc.Value = Conversions.ToDate(String.Concat(New String() { DateAndTime.Today.Year.ToString("0000"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Day.ToString("00") }))
				End If
				Me.dtpNgayNhan.Format = DateTimePickerFormat.Custom
				Me.dtpNgayNhan.CustomFormat = "dd/MM/yyyy"
				flag = Me.mbytFormStatus = 1
				If flag Then
					Me.dtpNgayNhan.Value = Conversions.ToDate(String.Concat(New String() { DateAndTime.Today.Year.ToString("0000"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Day.ToString("00") }))
				End If
				Me.dtpNgayTra.Format = DateTimePickerFormat.Custom
				Me.dtpNgayTra.CustomFormat = "dd/MM/yyyy"
				flag = Me.mbytFormStatus = 1
				If flag Then
					Me.dtpNgayTra.Value = Conversions.ToDate(String.Concat(New String() { DateAndTime.Today.Year.ToString("0000"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Day.ToString("00") }))
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmAddReserPhong_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000370 RID: 880 RVA: 0x0002A130 File Offset: 0x00028330
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000371 RID: 881 RVA: 0x0002A23C File Offset: 0x0002843C
		Private Sub lblTenKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDV As frmDMDV1 = New frmDMDV1()
				frmDMDV.pBytOpen_From_Menu = 7
				frmDMDV.ShowDialog()
				Me.lblTenKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJNAME, "", False) <> 0, frmDMDV.pStrOBJNAME, Me.lblTenKH.Text))
				Me.lblMaKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJID, "", False) <> 0, frmDMDV.pStrOBJID, Me.lblMaKH.Text))
				Me.lblPhone.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrPhone, "", False) <> 0, frmDMDV.pStrPhone, Me.lblPhone.Text))
				Me.lblEmail.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrPhone, "", False) <> 0, frmDMDV.pStrEmail, Me.lblEmail.Text))
				Me.lblContact.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrPhone, "", False) <> 0, frmDMDV.pStrContact, Me.lblContact.Text))
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - lblTenKH_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000372 RID: 882 RVA: 0x0002A40C File Offset: 0x0002860C
		Private Sub lblMaKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMDV As frmDMDV1 = New frmDMDV1()
				frmDMDV.pBytOpen_From_Menu = 7
				frmDMDV.ShowDialog()
				Me.lblTenKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJNAME, "", False) <> 0, frmDMDV.pStrOBJNAME, Me.lblTenKH.Text))
				Me.lblMaKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrOBJID, "", False) <> 0, frmDMDV.pStrOBJID, Me.lblMaKH.Text))
				Me.lblPhone.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrPhone, "", False) <> 0, frmDMDV.pStrPhone, Me.lblPhone.Text))
				Me.lblEmail.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrPhone, "", False) <> 0, frmDMDV.pStrEmail, Me.lblEmail.Text))
				Me.lblContact.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMDV.pStrPhone, "", False) <> 0, frmDMDV.pStrContact, Me.lblContact.Text))
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - lblMaKH_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000373 RID: 883 RVA: 0x000029B8 File Offset: 0x00000BB8
		Private Sub dtpNgayNhan_ValueChanged(sender As Object, e As EventArgs)
			Me.sTinhSoDem()
		End Sub

		' Token: 0x06000374 RID: 884 RVA: 0x0002A5DC File Offset: 0x000287DC
		Private Sub sTinhSoDem()
			Dim timeSpan As TimeSpan = Me.dtpNgayTra.Value - Me.dtpNgayNhan.Value
			Dim flag As Boolean = timeSpan.TotalDays > 0.0
			If flag Then
				Me.lblSoDem.Text = Conversions.ToString(timeSpan.TotalDays)
				Me.lblTongSoDem.Text = Conversions.ToString(Conversion.Val(Me.lblTongSoPhong.Text) * timeSpan.TotalDays)
			Else
				Me.lblSoDem.Text = Conversions.ToString(0)
				Me.lblTongSoDem.Text = Conversions.ToString(0)
			End If
			flag = Versioned.IsNumeric(Me.lblDonGia.Text.Replace(",", ""))
			If flag Then
				Me.lblTienThanhToan.Text = Conversions.ToString(Conversion.Val(Me.lblTongSoDem.Text) * Conversion.Val(Me.lblDonGia.Text.Replace(",", "")))
			End If
			flag = Versioned.IsNumeric(Me.lblTienDatCoc.Text.Replace(",", ""))
			If flag Then
				Me.lblTienConLai.Text = Conversions.ToString(Conversion.Val(Me.lblTienThanhToan.Text.Replace(",", "")) - Conversion.Val(Me.lblTienDatCoc.Text.Replace(",", "")))
			End If
		End Sub

		' Token: 0x06000375 RID: 885 RVA: 0x000029B8 File Offset: 0x00000BB8
		Private Sub dtpNgayTra_ValueChanged(sender As Object, e As EventArgs)
			Me.sTinhSoDem()
		End Sub

		' Token: 0x06000376 RID: 886 RVA: 0x0002A760 File Offset: 0x00028960
		Private Sub lblDonGia_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad = New frmNumPad()
				frmNumPad.pSglNumberReturn = Conversions.ToSingle(Me.lblDonGia.Text)
				frmNumPad.ShowDialog()
				Me.lblDonGia.Text = Conversions.ToString(frmNumPad.pSglNumberReturn)
				Me.sTinhSoDem()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - lblDonGia_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000377 RID: 887 RVA: 0x0002A81C File Offset: 0x00028A1C
		Private Sub lblTienDatCoc_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad = New frmNumPad()
				frmNumPad.pSglNumberReturn = Conversions.ToSingle(Me.lblTienDatCoc.Text)
				frmNumPad.ShowDialog()
				Me.lblTienDatCoc.Text = Conversions.ToString(frmNumPad.pSglNumberReturn)
				Me.sTinhSoDem()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - lblTienDatCoc_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x04000144 RID: 324
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000146 RID: 326
		<AccessedThroughProperty("panSua")>
		Private _panSua As TableLayoutPanel

		' Token: 0x04000147 RID: 327
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000148 RID: 328
		<AccessedThroughProperty("lblstt")>
		Private _lblstt As Label

		' Token: 0x04000149 RID: 329
		<AccessedThroughProperty("lblNo")>
		Private _lblNo As Label

		' Token: 0x0400014A RID: 330
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x0400014B RID: 331
		<AccessedThroughProperty("lblDV")>
		Private _lblDV As Label

		' Token: 0x0400014C RID: 332
		<AccessedThroughProperty("lblTenKH")>
		Private _lblTenKH As Label

		' Token: 0x0400014D RID: 333
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x0400014E RID: 334
		<AccessedThroughProperty("lblTongSoPhong")>
		Private _lblTongSoPhong As Label

		' Token: 0x0400014F RID: 335
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x04000150 RID: 336
		<AccessedThroughProperty("lblMaKH")>
		Private _lblMaKH As Label

		' Token: 0x04000151 RID: 337
		<AccessedThroughProperty("lblEmail")>
		Private _lblEmail As Label

		' Token: 0x04000152 RID: 338
		<AccessedThroughProperty("Label6")>
		Private _Label6 As Label

		' Token: 0x04000153 RID: 339
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x04000154 RID: 340
		<AccessedThroughProperty("lblPhone")>
		Private _lblPhone As Label

		' Token: 0x04000155 RID: 341
		<AccessedThroughProperty("Label10")>
		Private _Label10 As Label

		' Token: 0x04000156 RID: 342
		<AccessedThroughProperty("lblContact")>
		Private _lblContact As Label

		' Token: 0x04000157 RID: 343
		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		' Token: 0x04000158 RID: 344
		<AccessedThroughProperty("dtpNgayDat")>
		Private _dtpNgayDat As DateTimePicker

		' Token: 0x04000159 RID: 345
		<AccessedThroughProperty("Label12")>
		Private _Label12 As Label

		' Token: 0x0400015A RID: 346
		<AccessedThroughProperty("TableLayoutPanel7")>
		Private _TableLayoutPanel7 As TableLayoutPanel

		' Token: 0x0400015B RID: 347
		<AccessedThroughProperty("Label13")>
		Private _Label13 As Label

		' Token: 0x0400015C RID: 348
		<AccessedThroughProperty("Label14")>
		Private _Label14 As Label

		' Token: 0x0400015D RID: 349
		<AccessedThroughProperty("lblHour")>
		Private _lblHour As Label

		' Token: 0x0400015E RID: 350
		<AccessedThroughProperty("lblMinute")>
		Private _lblMinute As Label

		' Token: 0x0400015F RID: 351
		<AccessedThroughProperty("Label15")>
		Private _Label15 As Label

		' Token: 0x04000160 RID: 352
		<AccessedThroughProperty("Label16")>
		Private _Label16 As Label

		' Token: 0x04000161 RID: 353
		<AccessedThroughProperty("dtpNgayNhan")>
		Private _dtpNgayNhan As DateTimePicker

		' Token: 0x04000162 RID: 354
		<AccessedThroughProperty("dtpNgayTra")>
		Private _dtpNgayTra As DateTimePicker

		' Token: 0x04000163 RID: 355
		<AccessedThroughProperty("Label9")>
		Private _Label9 As Label

		' Token: 0x04000164 RID: 356
		<AccessedThroughProperty("lblSelectTable")>
		Private _lblSelectTable As Label

		' Token: 0x04000165 RID: 357
		<AccessedThroughProperty("Label17")>
		Private _Label17 As Label

		' Token: 0x04000166 RID: 358
		<AccessedThroughProperty("lblLoaiPhong")>
		Private _lblLoaiPhong As Label

		' Token: 0x04000167 RID: 359
		<AccessedThroughProperty("Label19")>
		Private _Label19 As Label

		' Token: 0x04000168 RID: 360
		<AccessedThroughProperty("lblSoDem")>
		Private _lblSoDem As Label

		' Token: 0x04000169 RID: 361
		<AccessedThroughProperty("Label21")>
		Private _Label21 As Label

		' Token: 0x0400016A RID: 362
		<AccessedThroughProperty("lblTongSoDem")>
		Private _lblTongSoDem As Label

		' Token: 0x0400016B RID: 363
		<AccessedThroughProperty("lblDonGia")>
		Private _lblDonGia As Label

		' Token: 0x0400016C RID: 364
		<AccessedThroughProperty("Label24")>
		Private _Label24 As Label

		' Token: 0x0400016D RID: 365
		<AccessedThroughProperty("lblNoidung")>
		Private _lblNoidung As Label

		' Token: 0x0400016E RID: 366
		<AccessedThroughProperty("lblTienThanhToan")>
		Private _lblTienThanhToan As Label

		' Token: 0x0400016F RID: 367
		<AccessedThroughProperty("Label27")>
		Private _Label27 As Label

		' Token: 0x04000170 RID: 368
		<AccessedThroughProperty("lblTienDatCoc")>
		Private _lblTienDatCoc As Label

		' Token: 0x04000171 RID: 369
		<AccessedThroughProperty("Label29")>
		Private _Label29 As Label

		' Token: 0x04000172 RID: 370
		<AccessedThroughProperty("dtpNgayDatCoc")>
		Private _dtpNgayDatCoc As DateTimePicker

		' Token: 0x04000173 RID: 371
		<AccessedThroughProperty("Label30")>
		Private _Label30 As Label

		' Token: 0x04000174 RID: 372
		<AccessedThroughProperty("lblTienConLai")>
		Private _lblTienConLai As Label

		' Token: 0x04000175 RID: 373
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000176 RID: 374
		<AccessedThroughProperty("lblREMARK")>
		Private _lblREMARK As Label

		' Token: 0x04000177 RID: 375
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x04000178 RID: 376
		<AccessedThroughProperty("lblPV")>
		Private _lblPV As Label

		' Token: 0x04000179 RID: 377
		<AccessedThroughProperty("lblDMMaBan")>
		Private _lblDMMaBan As Label

		' Token: 0x0400017A RID: 378
		<AccessedThroughProperty("lblDMMaKhu")>
		Private _lblDMMaKhu As Label

		' Token: 0x0400017B RID: 379
		<AccessedThroughProperty("lblMaPV")>
		Private _lblMaPV As Label

		' Token: 0x0400017C RID: 380
		Private mArrStrFrmMess As String()

		' Token: 0x0400017D RID: 381
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x0400017E RID: 382
		Private mbytFormStatus As Byte

		' Token: 0x0400017F RID: 383
		Private mbytRunFirst As Byte

		' Token: 0x04000180 RID: 384
		Private mBlnNew As Boolean
	End Class
End Namespace
