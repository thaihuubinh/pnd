﻿Namespace prjIS_SalesPOS
	' Token: 0x02000068 RID: 104
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMMT2
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060020E8 RID: 8424 RVA: 0x00198180 File Offset: 0x00196380
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060020E9 RID: 8425 RVA: 0x001981B8 File Offset: 0x001963B8
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMMT2))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.txtRate = New Global.System.Windows.Forms.TextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.cmbInclude = New Global.System.Windows.Forms.ComboBox()
			Me.lblRate = New Global.System.Windows.Forms.Label()
			Me.lblOBJNAME = New Global.System.Windows.Forms.Label()
			Me.txtOBJNAME = New Global.System.Windows.Forms.TextBox()
			Me.txtOBJID = New Global.System.Windows.Forms.TextBox()
			Me.lblOBJID = New Global.System.Windows.Forms.Label()
			Me.txtColor = New Global.System.Windows.Forms.TextBox()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(536, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 490)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 7
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnKeyboard, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 2)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 4)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 6
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 469)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 393)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 73)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 81)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(107, 72)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 4
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 237)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(107, 72)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 6
			Me.btnFilter.Tag = "CR0005"
			Me.btnFilter.Text = "Lọ&c"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 159)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 72)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 5
			Me.btnDelete.Tag = "CR0004"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 315)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(107, 72)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 7
			Me.btnFind.Tag = "CR0006"
			Me.btnFind.Text = "&Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(332, 80)
			label.Location = point
			Me.Label2.Name = "Label2"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(37, 21)
			label2.Size = size
			Me.Label2.TabIndex = 37
			Me.Label2.Tag = "0R0000"
			Me.Label2.Text = "%"
			Me.txtRate.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtRate As Global.System.Windows.Forms.Control = Me.txtRate
			point = New Global.System.Drawing.Point(169, 76)
			txtRate.Location = point
			Me.txtRate.Name = "txtRate"
			Dim txtRate2 As Global.System.Windows.Forms.Control = Me.txtRate
			size = New Global.System.Drawing.Size(161, 22)
			txtRate2.Size = size
			Me.txtRate.TabIndex = 31
			Me.txtRate.Tag = "0R0000"
			Me.txtRate.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(7, 110)
			label3.Location = point
			Me.Label1.Name = "Label1"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(154, 21)
			label4.Size = size
			Me.Label1.TabIndex = 36
			Me.Label1.Tag = "CR0010"
			Me.Label1.Text = "Giá đã có thuế ?"
			Me.cmbInclude.FormattingEnabled = True
			Dim cmbInclude As Global.System.Windows.Forms.Control = Me.cmbInclude
			point = New Global.System.Drawing.Point(169, 104)
			cmbInclude.Location = point
			Me.cmbInclude.Name = "cmbInclude"
			Dim cmbInclude2 As Global.System.Windows.Forms.Control = Me.cmbInclude
			size = New Global.System.Drawing.Size(364, 24)
			cmbInclude2.Size = size
			Me.cmbInclude.TabIndex = 32
			Me.cmbInclude.Tag = "0R0000"
			Me.lblRate.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblRate As Global.System.Windows.Forms.Control = Me.lblRate
			point = New Global.System.Drawing.Point(7, 80)
			lblRate.Location = point
			Me.lblRate.Name = "lblRate"
			Dim lblRate2 As Global.System.Windows.Forms.Control = Me.lblRate
			size = New Global.System.Drawing.Size(154, 21)
			lblRate2.Size = size
			Me.lblRate.TabIndex = 35
			Me.lblRate.Tag = "CR0009"
			Me.lblRate.Text = "Thuế suất"
			Me.lblOBJNAME.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJNAME As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			point = New Global.System.Drawing.Point(7, 49)
			lblOBJNAME.Location = point
			Me.lblOBJNAME.Name = "lblOBJNAME"
			Dim lblOBJNAME2 As Global.System.Windows.Forms.Control = Me.lblOBJNAME
			size = New Global.System.Drawing.Size(154, 21)
			lblOBJNAME2.Size = size
			Me.lblOBJNAME.TabIndex = 34
			Me.lblOBJNAME.Tag = "CR0008"
			Me.lblOBJNAME.Text = "Tên mức thuế"
			Me.txtOBJNAME.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJNAME As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			point = New Global.System.Drawing.Point(169, 48)
			txtOBJNAME.Location = point
			Me.txtOBJNAME.Name = "txtOBJNAME"
			Dim txtOBJNAME2 As Global.System.Windows.Forms.Control = Me.txtOBJNAME
			size = New Global.System.Drawing.Size(364, 22)
			txtOBJNAME2.Size = size
			Me.txtOBJNAME.TabIndex = 30
			Me.txtOBJNAME.Tag = "0R0000"
			Me.txtOBJID.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtOBJID As Global.System.Windows.Forms.Control = Me.txtOBJID
			point = New Global.System.Drawing.Point(169, 19)
			txtOBJID.Location = point
			Me.txtOBJID.Name = "txtOBJID"
			Dim txtOBJID2 As Global.System.Windows.Forms.Control = Me.txtOBJID
			size = New Global.System.Drawing.Size(161, 22)
			txtOBJID2.Size = size
			Me.txtOBJID.TabIndex = 29
			Me.txtOBJID.Tag = "0R0000"
			Me.lblOBJID.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblOBJID As Global.System.Windows.Forms.Control = Me.lblOBJID
			point = New Global.System.Drawing.Point(7, 20)
			lblOBJID.Location = point
			Me.lblOBJID.Name = "lblOBJID"
			Dim lblOBJID2 As Global.System.Windows.Forms.Control = Me.lblOBJID
			size = New Global.System.Drawing.Size(154, 21)
			lblOBJID2.Size = size
			Me.lblOBJID.TabIndex = 33
			Me.lblOBJID.Tag = "CR0007"
			Me.lblOBJID.Text = "Mã mức thuế"
			Me.txtColor.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Dim txtColor As Global.System.Windows.Forms.Control = Me.txtColor
			point = New Global.System.Drawing.Point(427, 20)
			txtColor.Location = point
			Me.txtColor.Name = "txtColor"
			Dim txtColor2 As Global.System.Windows.Forms.Control = Me.txtColor
			size = New Global.System.Drawing.Size(106, 22)
			txtColor2.Size = size
			Me.txtColor.TabIndex = 51
			Me.txtColor.Tag = "0R0000"
			Me.txtColor.Visible = False
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnKeyboard.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnKeyboard.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(3, 3)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(107, 72)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 172
			Me.btnKeyboard.Text = "Keyboard"
			Me.btnKeyboard.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(655, 490)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.txtColor)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.txtRate)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.cmbInclude)
			Me.Controls.Add(Me.lblRate)
			Me.Controls.Add(Me.lblOBJNAME)
			Me.Controls.Add(Me.txtOBJNAME)
			Me.Controls.Add(Me.txtOBJID)
			Me.Controls.Add(Me.lblOBJID)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMMT2"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Chi tiết DMMT"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x04000D76 RID: 3446
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
