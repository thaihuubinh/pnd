﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200020C RID: 524
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60510k58Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006133 RID: 24883 RVA: 0x0001164B File Offset: 0x0000F84B
		Public Sub New()
			CachedrptRepBC60510k58Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170024A6 RID: 9382
		' (get) Token: 0x06006134 RID: 24884 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006135 RID: 24885 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170024A7 RID: 9383
		' (get) Token: 0x06006136 RID: 24886 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006137 RID: 24887 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170024A8 RID: 9384
		' (get) Token: 0x06006138 RID: 24888 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006139 RID: 24889 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x0600613A RID: 24890 RVA: 0x004DCCE0 File Offset: 0x004DAEE0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60510k58Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x0600613B RID: 24891 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002804 RID: 10244
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
