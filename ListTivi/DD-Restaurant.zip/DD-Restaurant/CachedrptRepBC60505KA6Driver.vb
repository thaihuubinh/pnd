﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020001F0 RID: 496
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60505KA6Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006002 RID: 24578 RVA: 0x000111CF File Offset: 0x0000F3CF
		Public Sub New()
			CachedrptRepBC60505KA6Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002401 RID: 9217
		' (get) Token: 0x06006003 RID: 24579 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006004 RID: 24580 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002402 RID: 9218
		' (get) Token: 0x06006005 RID: 24581 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006006 RID: 24582 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002403 RID: 9219
		' (get) Token: 0x06006007 RID: 24583 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006008 RID: 24584 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006009 RID: 24585 RVA: 0x004DC960 File Offset: 0x004DAB60
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60505KA6Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x0600600A RID: 24586 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040027E8 RID: 10216
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
