﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000025 RID: 37
	<DesignerGenerated()>
	Public Partial Class frmCheckConnect
		Inherits Form

		' Token: 0x060006AB RID: 1707 RVA: 0x0004F498 File Offset: 0x0004D698
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmCheckConnect_Load
			frmCheckConnect.__ENCList.Add(New WeakReference(Me))
			Me.mbytSelect_PXK = 0
			Me.mblnSendData = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000286 RID: 646
		' (get) Token: 0x060006AE RID: 1710 RVA: 0x000502E0 File Offset: 0x0004E4E0
		' (set) Token: 0x060006AF RID: 1711 RVA: 0x000502F8 File Offset: 0x0004E4F8
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnOK_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnOK_Click
				End If
			End Set
		End Property

		' Token: 0x17000287 RID: 647
		' (get) Token: 0x060006B0 RID: 1712 RVA: 0x00050364 File Offset: 0x0004E564
		' (set) Token: 0x060006B1 RID: 1713 RVA: 0x00003249 File Offset: 0x00001449
		Friend Overridable Property dgvCHECK As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvCHECK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvCHECK = value
			End Set
		End Property

		' Token: 0x17000288 RID: 648
		' (get) Token: 0x060006B2 RID: 1714 RVA: 0x0005037C File Offset: 0x0004E57C
		' (set) Token: 0x060006B3 RID: 1715 RVA: 0x00003253 File Offset: 0x00001453
		Friend Overridable Property colMAMAY As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._colMAMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._colMAMAY = value
			End Set
		End Property

		' Token: 0x17000289 RID: 649
		' (get) Token: 0x060006B4 RID: 1716 RVA: 0x00050394 File Offset: 0x0004E594
		' (set) Token: 0x060006B5 RID: 1717 RVA: 0x0000325D File Offset: 0x0000145D
		Friend Overridable Property colTenMay As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._colTenMay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._colTenMay = value
			End Set
		End Property

		' Token: 0x1700028A RID: 650
		' (get) Token: 0x060006B6 RID: 1718 RVA: 0x000503AC File Offset: 0x0004E5AC
		' (set) Token: 0x060006B7 RID: 1719 RVA: 0x00003267 File Offset: 0x00001467
		Friend Overridable Property colIP As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._colIP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._colIP = value
			End Set
		End Property

		' Token: 0x1700028B RID: 651
		' (get) Token: 0x060006B8 RID: 1720 RVA: 0x000503C4 File Offset: 0x0004E5C4
		' (set) Token: 0x060006B9 RID: 1721 RVA: 0x00003271 File Offset: 0x00001471
		Friend Overridable Property colServer As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._colServer
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._colServer = value
			End Set
		End Property

		' Token: 0x1700028C RID: 652
		' (get) Token: 0x060006BA RID: 1722 RVA: 0x000503DC File Offset: 0x0004E5DC
		' (set) Token: 0x060006BB RID: 1723 RVA: 0x000503F4 File Offset: 0x0004E5F4
		Friend Overridable Property Timer1 As Timer
			<DebuggerNonUserCode()>
			Get
				Return Me._Timer1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim flag As Boolean = Me._Timer1 IsNot Nothing
				If flag Then
					RemoveHandler Me._Timer1.Tick, AddressOf Me.Timer1_Tick
				End If
				Me._Timer1 = value
				flag = Me._Timer1 IsNot Nothing
				If flag Then
					AddHandler Me._Timer1.Tick, AddressOf Me.Timer1_Tick
				End If
			End Set
		End Property

		' Token: 0x1700028D RID: 653
		' (get) Token: 0x060006BC RID: 1724 RVA: 0x00050460 File Offset: 0x0004E660
		' (set) Token: 0x060006BD RID: 1725 RVA: 0x0000327B File Offset: 0x0000147B
		Friend Overridable Property lblLeft As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblLeft
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblLeft = value
			End Set
		End Property

		' Token: 0x1700028E RID: 654
		' (get) Token: 0x060006BE RID: 1726 RVA: 0x00050478 File Offset: 0x0004E678
		' (set) Token: 0x060006BF RID: 1727 RVA: 0x00003285 File Offset: 0x00001485
		Friend Overridable Property lblCenter As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblCenter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblCenter = value
			End Set
		End Property

		' Token: 0x1700028F RID: 655
		' (get) Token: 0x060006C0 RID: 1728 RVA: 0x00050490 File Offset: 0x0004E690
		' (set) Token: 0x060006C1 RID: 1729 RVA: 0x0000328F File Offset: 0x0000148F
		Friend Overridable Property lblRight As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblRight
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblRight = value
			End Set
		End Property

		' Token: 0x17000290 RID: 656
		' (get) Token: 0x060006C2 RID: 1730 RVA: 0x000504A8 File Offset: 0x0004E6A8
		' (set) Token: 0x060006C3 RID: 1731 RVA: 0x00003299 File Offset: 0x00001499
		Friend Overridable Property picLoad As PictureBox
			<DebuggerNonUserCode()>
			Get
				Return Me._picLoad
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._picLoad = value
			End Set
		End Property

		' Token: 0x17000291 RID: 657
		' (get) Token: 0x060006C4 RID: 1732 RVA: 0x000504C0 File Offset: 0x0004E6C0
		' (set) Token: 0x060006C5 RID: 1733 RVA: 0x000032A3 File Offset: 0x000014A3
		Friend Overridable Property Timer2 As Timer
			<DebuggerNonUserCode()>
			Get
				Return Me._Timer2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Me._Timer2 = value
			End Set
		End Property

		' Token: 0x17000292 RID: 658
		' (get) Token: 0x060006C6 RID: 1734 RVA: 0x000504D8 File Offset: 0x0004E6D8
		' (set) Token: 0x060006C7 RID: 1735 RVA: 0x000032AD File Offset: 0x000014AD
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x17000293 RID: 659
		' (get) Token: 0x060006C8 RID: 1736 RVA: 0x000504F0 File Offset: 0x0004E6F0
		' (set) Token: 0x060006C9 RID: 1737 RVA: 0x000032B7 File Offset: 0x000014B7
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000294 RID: 660
		' (get) Token: 0x060006CA RID: 1738 RVA: 0x00050508 File Offset: 0x0004E708
		' (set) Token: 0x060006CB RID: 1739 RVA: 0x000032C1 File Offset: 0x000014C1
		Friend Overridable Property dvgDM As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dvgDM
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dvgDM = value
			End Set
		End Property

		' Token: 0x17000295 RID: 661
		' (get) Token: 0x060006CC RID: 1740 RVA: 0x00050520 File Offset: 0x0004E720
		' (set) Token: 0x060006CD RID: 1741 RVA: 0x000032CB File Offset: 0x000014CB
		Friend Overridable Property colMADM As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._colMADM
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._colMADM = value
			End Set
		End Property

		' Token: 0x17000296 RID: 662
		' (get) Token: 0x060006CE RID: 1742 RVA: 0x00050538 File Offset: 0x0004E738
		' (set) Token: 0x060006CF RID: 1743 RVA: 0x000032D5 File Offset: 0x000014D5
		Friend Overridable Property colTENDM As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._colTENDM
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._colTENDM = value
			End Set
		End Property

		' Token: 0x17000297 RID: 663
		' (get) Token: 0x060006D0 RID: 1744 RVA: 0x00050550 File Offset: 0x0004E750
		' (set) Token: 0x060006D1 RID: 1745 RVA: 0x000032DF File Offset: 0x000014DF
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000298 RID: 664
		' (get) Token: 0x060006D2 RID: 1746 RVA: 0x00050568 File Offset: 0x0004E768
		' (set) Token: 0x060006D3 RID: 1747 RVA: 0x000032E9 File Offset: 0x000014E9
		Friend Overridable Property lblRight2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblRight2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblRight2 = value
			End Set
		End Property

		' Token: 0x17000299 RID: 665
		' (get) Token: 0x060006D4 RID: 1748 RVA: 0x00050580 File Offset: 0x0004E780
		' (set) Token: 0x060006D5 RID: 1749 RVA: 0x000032F3 File Offset: 0x000014F3
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x1700029A RID: 666
		' (get) Token: 0x060006D6 RID: 1750 RVA: 0x00050598 File Offset: 0x0004E798
		' (set) Token: 0x060006D7 RID: 1751 RVA: 0x000032FD File Offset: 0x000014FD
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x1700029B RID: 667
		' (get) Token: 0x060006D8 RID: 1752 RVA: 0x000505B0 File Offset: 0x0004E7B0
		' (set) Token: 0x060006D9 RID: 1753 RVA: 0x00003307 File Offset: 0x00001507
		Friend Overridable Property lstKQ As ListView
			<DebuggerNonUserCode()>
			Get
				Return Me._lstKQ
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListView)
				Me._lstKQ = value
			End Set
		End Property

		' Token: 0x1700029C RID: 668
		' (get) Token: 0x060006DA RID: 1754 RVA: 0x000505C8 File Offset: 0x0004E7C8
		' (set) Token: 0x060006DB RID: 1755 RVA: 0x00003311 File Offset: 0x00001511
		Friend Overridable Property col01 As ColumnHeader
			<DebuggerNonUserCode()>
			Get
				Return Me._col01
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ColumnHeader)
				Me._col01 = value
			End Set
		End Property

		' Token: 0x1700029D RID: 669
		' (get) Token: 0x060006DC RID: 1756 RVA: 0x000505E0 File Offset: 0x0004E7E0
		' (set) Token: 0x060006DD RID: 1757 RVA: 0x0000331B File Offset: 0x0000151B
		Friend Overridable Property col02 As ColumnHeader
			<DebuggerNonUserCode()>
			Get
				Return Me._col02
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ColumnHeader)
				Me._col02 = value
			End Set
		End Property

		' Token: 0x1700029E RID: 670
		' (get) Token: 0x060006DE RID: 1758 RVA: 0x000505F8 File Offset: 0x0004E7F8
		' (set) Token: 0x060006DF RID: 1759 RVA: 0x00003325 File Offset: 0x00001525
		Friend Overridable Property col03 As ColumnHeader
			<DebuggerNonUserCode()>
			Get
				Return Me._col03
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ColumnHeader)
				Me._col03 = value
			End Set
		End Property

		' Token: 0x1700029F RID: 671
		' (get) Token: 0x060006E0 RID: 1760 RVA: 0x00050610 File Offset: 0x0004E810
		' (set) Token: 0x060006E1 RID: 1761 RVA: 0x0000332F File Offset: 0x0000152F
		Friend Overridable Property col04 As ColumnHeader
			<DebuggerNonUserCode()>
			Get
				Return Me._col04
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ColumnHeader)
				Me._col04 = value
			End Set
		End Property

		' Token: 0x170002A0 RID: 672
		' (get) Token: 0x060006E2 RID: 1762 RVA: 0x00050628 File Offset: 0x0004E828
		' (set) Token: 0x060006E3 RID: 1763 RVA: 0x00003339 File Offset: 0x00001539
		Friend Overridable Property col05 As ColumnHeader
			<DebuggerNonUserCode()>
			Get
				Return Me._col05
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ColumnHeader)
				Me._col05 = value
			End Set
		End Property

		' Token: 0x170002A1 RID: 673
		' (get) Token: 0x060006E4 RID: 1764 RVA: 0x00050640 File Offset: 0x0004E840
		' (set) Token: 0x060006E5 RID: 1765 RVA: 0x00003343 File Offset: 0x00001543
		Public Property pblnSendData As Boolean
			Get
				Return Me.mblnSendData
			End Get
			Set(value As Boolean)
				Me.mblnSendData = value
			End Set
		End Property

		' Token: 0x060006E6 RID: 1766 RVA: 0x00050658 File Offset: 0x0004E858
		Private Sub frmCheckConnect_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = Me.mblnSendData
				If flag Then
					Me.Width = 513
				Else
					Me.Width = 370
				End If
				Me.Timer1.Enabled = True
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmCheckConnect_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060006E7 RID: 1767 RVA: 0x00050738 File Offset: 0x0004E938
		Private Sub btnOK_Click(sender As Object, e As EventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnOK_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060006E8 RID: 1768 RVA: 0x000507C4 File Offset: 0x0004E9C4
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060006E9 RID: 1769 RVA: 0x00050870 File Offset: 0x0004EA70
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060006EA RID: 1770 RVA: 0x000509A0 File Offset: 0x0004EBA0
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060006EB RID: 1771 RVA: 0x00050A40 File Offset: 0x0004EC40
		Private Sub sCheckConnect(lblName As Label, strIP As String, strServer As String)
			Dim pictureBox As PictureBox = New PictureBox()
			Dim clsCheckConnect As clsCheckConnect = New clsCheckConnect()
			Try
				Dim flag As Boolean = clsCheckConnect.QuickOpen(New SqlConnection() With { .ConnectionString = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("Data Source = " + strIP, Interaction.IIf(strServer.Trim().Length > 0, "\" + strServer, "")), "; Initial Catalog=ISDANHMUC; User ID=sa; Password=sa")) }, 10)
				pictureBox.BackgroundImageLayout = ImageLayout.Zoom
				pictureBox.Width = 32
				pictureBox.Height = 32
				Dim flag2 As Boolean = Not flag
				If flag2 Then
					pictureBox.BackgroundImage = Resources.no
				Else
					pictureBox.BackgroundImage = Resources.yes
				End If
			Catch ex As Exception
				pictureBox.BackgroundImage = Resources.no
			Finally
				pictureBox.Left = Me.lblRight.Left
				pictureBox.Top = lblName.Top - 4
				Me.Controls.Add(pictureBox)
			End Try
		End Sub

		' Token: 0x060006EC RID: 1772 RVA: 0x00050B60 File Offset: 0x0004ED60
		Private Sub sSendData(lblName As Label, strIP As String, strServer As String, strMaMay As String)
			Dim label As Label = New Label()
			Dim pictureBox As PictureBox = New PictureBox()
			Dim clsCheckConnect As clsCheckConnect = New clsCheckConnect()
			Try
				Dim sqlConnection As SqlConnection = New SqlConnection()
				Dim text As String = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject("Data Source = " + strIP, Interaction.IIf(strServer.Trim().Length > 0, "\" + strServer, "")), "; Initial Catalog=ISDANHMUC; User ID=sa; Password=sa"))
				sqlConnection.ConnectionString = text
				Dim flag As Boolean = clsCheckConnect.QuickOpen(sqlConnection, 10)
				pictureBox.BackgroundImageLayout = ImageLayout.Zoom
				pictureBox.Width = 32
				pictureBox.Height = 32
				Dim flag2 As Boolean = Not flag
				If flag2 Then
					pictureBox.BackgroundImage = Resources.no
				Else
					Dim num As Integer = 0
					Dim clsConnect As clsConnect = New clsConnect()
					Dim array As SqlParameter() = New SqlParameter(1) {}
					Dim sqlCommand As SqlCommand = New SqlCommand()
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@nchMAMAY"
					array(0).Value = Strings.Trim(strMaMay)
					Dim num2 As Integer
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMSENDDATA_GET_ALL_DATA_DMHH_SEND", num2)
					Dim num3 As Integer = 0
					Dim num4 As Integer = clsConnect.Rows.Count - 1
					Dim num5 As Integer = num3
					While True
						Dim num6 As Integer = num5
						Dim num7 As Integer = num4
						If num6 > num7 Then
							Exit For
						End If
						flag2 = Conversion.Val(RuntimeHelpers.GetObjectValue(clsConnect.Rows(num5)("TYPE"))) = 0.0
						If flag2 Then
							Dim flag3 As Boolean = Me.gfAddNewDMHH(text, Conversions.ToString(clsConnect.Rows(num5)("MAHH")), Conversions.ToString(clsConnect.Rows(num5)("OBJNAME")), Conversions.ToString(clsConnect.Rows(num5)("SUBOBJNAME")), Conversions.ToString(clsConnect.Rows(num5)("MADVT")), Conversions.ToString(clsConnect.Rows(num5)("MANH")), Conversions.ToString(clsConnect.Rows(num5)("MAMT")), Conversions.ToString(clsConnect.Rows(num5)("MAPL")), Conversions.ToString(clsConnect.Rows(num5)("MANSX")), Conversions.ToString(clsConnect.Rows(num5)("MADC")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE1")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE2")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE3")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE4")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE5")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE6")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE7")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE8")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE9")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE10")), Conversions.ToBoolean(clsConnect.Rows(num5)("LSAVE")), Conversions.ToString(clsConnect.Rows(num5)("REMARK")), Conversions.ToString(clsConnect.Rows(num5)("MADV")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP1")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP2")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP3")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP4")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP5")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP6")), Conversions.ToBoolean(clsConnect.Rows(num5)("LOPEN")), Conversions.ToBoolean(clsConnect.Rows(num5)("LHIDEN")), Conversions.ToBoolean(clsConnect.Rows(num5)("LSTOPUSE")), Conversions.ToBoolean(clsConnect.Rows(num5)("LCOMBO")), Conversions.ToString(clsConnect.Rows(num5)("COMBO")), Conversions.ToDouble(clsConnect.Rows(num5)("PURSEHH")), Conversions.ToBoolean(clsConnect.Rows(num5)("LSETCOMBO")), Conversions.ToBoolean(clsConnect.Rows(num5)("LTON_KHACHHANG")), Conversions.ToString(clsConnect.Rows(num5)("PHIEU")), CType(Interaction.IIf(clsConnect.Rows(num5)("UIMAGE").[GetType]().Equals(Type.[GetType]("System.DBNull")), Nothing, RuntimeHelpers.GetObjectValue(clsConnect.Rows(num5)("UIMAGE"))), Byte()), strMaMay) = 1
							If flag3 Then
								num += 1
							End If
						Else
							Dim flag3 As Boolean = Conversion.Val(RuntimeHelpers.GetObjectValue(clsConnect.Rows(num5)("TYPE"))) = 1.0
							If flag3 Then
								flag2 = Me.gfUpdateDMHH(text, Conversions.ToString(clsConnect.Rows(num5)("MAHH")), Conversions.ToString(clsConnect.Rows(num5)("OBJNAME")), Conversions.ToString(clsConnect.Rows(num5)("SUBOBJNAME")), Conversions.ToString(clsConnect.Rows(num5)("MADVT")), Conversions.ToString(clsConnect.Rows(num5)("MANH")), Conversions.ToString(clsConnect.Rows(num5)("MAMT")), Conversions.ToString(clsConnect.Rows(num5)("MAPL")), Conversions.ToString(clsConnect.Rows(num5)("MANSX")), Conversions.ToString(clsConnect.Rows(num5)("MADC")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE1")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE2")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE3")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE4")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE5")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE6")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE7")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE8")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE9")), Conversions.ToDouble(clsConnect.Rows(num5)("PRICE10")), Conversions.ToBoolean(clsConnect.Rows(num5)("LSAVE")), Conversions.ToString(clsConnect.Rows(num5)("REMARK")), Conversions.ToString(clsConnect.Rows(num5)("MADV")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP1")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP2")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP3")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP4")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP5")), Conversions.ToString(clsConnect.Rows(num5)("MAMAYINBEP6")), Conversions.ToBoolean(clsConnect.Rows(num5)("LOPEN")), Conversions.ToBoolean(clsConnect.Rows(num5)("LHIDEN")), Conversions.ToBoolean(clsConnect.Rows(num5)("LSTOPUSE")), Conversions.ToBoolean(clsConnect.Rows(num5)("LCOMBO")), Conversions.ToString(clsConnect.Rows(num5)("COMBO")), Conversions.ToDouble(clsConnect.Rows(num5)("PURSEHH")), Conversions.ToBoolean(clsConnect.Rows(num5)("LSETCOMBO")), Conversions.ToBoolean(clsConnect.Rows(num5)("LTON_KHACHHANG")), Conversions.ToString(clsConnect.Rows(num5)("PHIEU")), CType(Interaction.IIf(clsConnect.Rows(num5)("UIMAGE").[GetType]().Equals(Type.[GetType]("System.DBNull")), Nothing, RuntimeHelpers.GetObjectValue(clsConnect.Rows(num5)("UIMAGE"))), Byte()), strMaMay) = 1
								If flag2 Then
									num += 1
								End If
							Else
								flag3 = Conversion.Val(RuntimeHelpers.GetObjectValue(clsConnect.Rows(num5)("TYPE"))) = 2.0
								If flag3 Then
									flag2 = Me.fDeleteDMHH(text, Conversions.ToString(clsConnect.Rows(num5)("MAHH")), strMaMay) = 1
									If flag2 Then
										num += 1
									End If
								End If
							End If
						End If
						num5 += 1
					End While
					label.Text = num.ToString() + "/" + Conversions.ToString(clsConnect.Rows.Count)
					label.Font = New Font(New FontFamily("Tahoma"), 14F, FontStyle.Bold, GraphicsUnit.Pixel)
					pictureBox.BackgroundImage = Resources.yes
				End If
			Catch ex As Exception
				pictureBox.BackgroundImage = Resources.no
			Finally
				pictureBox.Left = Me.lblRight.Left
				pictureBox.Top = lblName.Top - 2
				label.Left = Me.lblRight2.Left
				label.Top = lblName.Top
				label.AutoSize = False
				label.Width = 68
				label.Height = 20
				label.TextAlign = ContentAlignment.MiddleLeft
				label.ForeColor = Color.Blue
				Me.Controls.Add(pictureBox)
				Me.Controls.Add(label)
			End Try
		End Sub

		' Token: 0x060006ED RID: 1773 RVA: 0x000517F4 File Offset: 0x0004F9F4
		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			Dim num As Integer = Me.lblLeft.Top
			Me.Timer1.Enabled = False
			Try
				For Each obj As Object In CType(Me.dgvCHECK.Rows, IEnumerable)
					Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
					Dim label As Label = New Label()
					label.Name = Conversions.ToString(Operators.ConcatenateObject("lbl", dataGridViewRow.Cells("colMAMAY").Value))
					label.Font = New Font(New FontFamily("Tahoma"), 14F, FontStyle.Bold, GraphicsUnit.Pixel)
					label.Text = Conversions.ToString(dataGridViewRow.Cells("colTENMAY").Value)
					label.Left = Me.lblLeft.Left
					label.Top = num + 2
					Me.picLoad.Top = num + 5
					Me.picLoad.Visible = True
					Me.picLoad.Left = Me.lblCenter.Left
					Me.Controls.Add(label)
					Dim flag As Boolean = Me.mblnSendData
					If flag Then
						Me.sSendData(label, Conversions.ToString(dataGridViewRow.Cells("colIP").Value), Conversions.ToString(dataGridViewRow.Cells("colSERVER").Value), Conversions.ToString(dataGridViewRow.Cells("colMAMAY").Value))
					Else
						Me.sCheckConnect(label, Conversions.ToString(dataGridViewRow.Cells("colIP").Value), Conversions.ToString(dataGridViewRow.Cells("colSERVER").Value))
					End If
					num = num + label.Height + 14
					Dim label2 As Label = New Label()
					label2.Left = 0
					label2.Top = num - 3
					label2.Width = Me.Width
					label2.Height = 1
					label2.Text = ""
					label2.BackColor = Color.Silver
					Me.Controls.Add(label2)
					Me.picLoad.Visible = False
				Next
			Finally
				Dim enumerator As IEnumerator
				Dim flag As Boolean = TypeOf enumerator Is IDisposable
				If flag Then
					TryCast(enumerator, IDisposable).Dispose()
				End If
			End Try
		End Sub

		' Token: 0x060006EE RID: 1774 RVA: 0x00051A6C File Offset: 0x0004FC6C
		Private Function gfAddNewDMHH(mCNN As String, strMa As String, strTen As String, strTenphu As String, strDVT As String, strMaNH As String, strMaMT As String, strMAPL As String, strMaNSX As String, strMaDC As String, dblPrice1 As Double, dblPrice2 As Double, dblPrice3 As Double, dblPrice4 As Double, dblPrice5 As Double, dblPrice6 As Double, dblPrice7 As Double, dblPrice8 As Double, dblPrice9 As Double, dblPrice10 As Double, blnKho As Boolean, strRemark As String, strMaDV As String, strMaINBEP1 As String, strMaINBEP2 As String, strMaINBEP3 As String, strMaINBEP4 As String, strMaINBEP5 As String, strMaINBEP6 As String, blnLOPEN As Boolean, blnLHIDEN As Boolean, blnLSTOPUSE As Boolean, blnLCOMBO As Boolean, strCOMBO As String, dblPURE As Double, blnLSETCOMBO As Boolean, blnLTON_KHACHHANG As Boolean, strPHIEU As String, bytIMG As Byte(), strMaMay As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(40) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(strMa)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(strTen)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcTENPHU"
				array(2).Value = Strings.Trim(strTenphu)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcDVT"
				array(3).Value = Strings.Trim(strDVT)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnchMANH"
				array(4).Value = Strings.Trim(strMaNH)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnchMAMT"
				array(5).Value = Strings.Trim(strMaMT)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnchMAPL"
				array(6).Value = Strings.Trim(strMAPL)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnchMANSX"
				array(7).Value = Strings.Trim(strMaNSX)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnchMADC"
				array(8).Value = Strings.Trim(strMaDC)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pmnyPRICE"
				array(9).Value = dblPrice1
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pmnyPRICE2"
				array(10).Value = dblPrice2
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pmnyPRICE3"
				array(11).Value = dblPrice3
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pmnyPRICE4"
				array(12).Value = dblPrice4
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pmnyPRICE5"
				array(13).Value = dblPrice5
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pmnyPRICE6"
				array(14).Value = dblPrice6
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pmnyPRICE7"
				array(15).Value = dblPrice7
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pmnyPRICE8"
				array(16).Value = dblPrice8
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pmnyPRICE9"
				array(17).Value = dblPrice9
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@pmnyPRICE10"
				array(18).Value = dblPrice10
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pbitLMATERIAL"
				array(19).Value = 0
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@bitKHO"
				array(20).Value = blnKho
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = Strings.Trim(strRemark)
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMADV"
				array(22).Value = Strings.Trim(strMaDV)
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnchMAINBEP1"
				array(23).Value = Strings.Trim(strMaINBEP1)
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnchMAINBEP2"
				array(24).Value = Strings.Trim(strMaINBEP2)
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnchMAINBEP3"
				array(25).Value = Strings.Trim(strMaINBEP3)
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pbitLOPEN"
				array(26).Value = blnLOPEN
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pbitLHIDEN"
				array(27).Value = blnLHIDEN
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pbitLSTOPUSE"
				array(28).Value = blnLSTOPUSE
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pbitLCOMBO"
				array(29).Value = blnLCOMBO
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnvcCOMBO"
				array(30).Value = strCOMBO.Trim()
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@int_Result"
				array(31).Direction = ParameterDirection.ReturnValue
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pmnyPURSE"
				array(32).Value = dblPURE
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pbitLSETCOMBO"
				array(33).Value = blnLSETCOMBO
				array(34) = sqlCommand.CreateParameter()
				array(34).ParameterName = "@pbitLTON_KHACHHANG"
				array(34).Value = blnLTON_KHACHHANG
				array(35) = sqlCommand.CreateParameter()
				array(35).ParameterName = "@pnvcPHIEU"
				array(35).Value = strPHIEU.Trim()
				array(36) = sqlCommand.CreateParameter()
				array(36).ParameterName = "@pnchMAINBEP4"
				array(36).Value = Strings.Trim(strMaINBEP4)
				array(37) = sqlCommand.CreateParameter()
				array(37).ParameterName = "@pnchMAINBEP5"
				array(37).Value = Strings.Trim(strMaINBEP5)
				array(38) = sqlCommand.CreateParameter()
				array(38).ParameterName = "@pnchMAINBEP6"
				array(38).Value = Strings.Trim(strMaINBEP6)
				Dim flag As Boolean = bytIMG IsNot Nothing
				If flag Then
					array(39) = sqlCommand.CreateParameter()
					array(39).ParameterName = "@pimgUIMAGE"
					array(39).Value = bytIMG
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mCNN, array, "SP_FRMDMHH_INSERT_DMHH", flag2)
				Else
					array(39) = sqlCommand.CreateParameter()
					array(39).ParameterName = "@pnchNO"
					array(39).Value = ""
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mCNN, array, "SP_FRMDMHH_INSERT_DMHH_NOIMAGE", flag2)
				End If
				Dim num As Integer = Conversions.ToInteger(array(31).Value)
				Me.fDeleteDMHH_SEND(strMa, strMaMay)
				flag = num = 0
				If flag Then
					b = 1
				Else
					b = 0
				End If
				flag = num = 0
				If flag Then
					b = 1
				Else
					flag = num = 1
					If flag Then
						Dim text As String = Me.mArrStrFrmMess(8)
					Else
						flag = num = 2
						If flag Then
							Dim text As String = Me.mArrStrFrmMess(9)
						Else
							flag = num = 3
							If flag Then
								Dim text As String = Me.mArrStrFrmMess(10)
							Else
								flag = num = 4
								If flag Then
									Dim text As String = Me.mArrStrFrmMess(11)
								Else
									flag = num = 5
									If flag Then
										Dim text As String = Me.mArrStrFrmMess(12)
									Else
										flag = num = 6
										If flag Then
											Dim text As String = Me.mArrStrFrmMess(13)
										Else
											flag = num = 7
											If flag Then
												Dim text As String = Me.mArrStrFrmMess(14)
											Else
												flag = num = 8
												If flag Then
													Dim text As String = Me.mArrStrFrmMess(15)
												Else
													Dim text As String = Me.mArrStrFrmMess(16)
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gfAddNewDMHH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060006EF RID: 1775 RVA: 0x000523C8 File Offset: 0x000505C8
		Private Function gfUpdateDMHH(mCNN As String, strMa As String, strTen As String, strTenphu As String, strDVT As String, strMaNH As String, strMaMT As String, strMAPL As String, strMaNSX As String, strMaDC As String, dblPrice1 As Double, dblPrice2 As Double, dblPrice3 As Double, dblPrice4 As Double, dblPrice5 As Double, dblPrice6 As Double, dblPrice7 As Double, dblPrice8 As Double, dblPrice9 As Double, dblPrice10 As Double, blnKho As Boolean, strRemark As String, strMaDV As String, strMaINBEP1 As String, strMaINBEP2 As String, strMaINBEP3 As String, strMaINBEP4 As String, strMaINBEP5 As String, strMaINBEP6 As String, blnLOPEN As Boolean, blnLHIDEN As Boolean, blnLSTOPUSE As Boolean, blnLCOMBO As Boolean, strCOMBO As String, dblPURE As Double, blnLSETCOMBO As Boolean, blnLTON_KHACHHANG As Boolean, strPHIEU As String, bytIMG As Byte(), strMaMay As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(40) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(strMa)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(strTen)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnvcTENPHU"
				array(2).Value = Strings.Trim(strTenphu)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvcDVT"
				array(3).Value = Strings.Trim(strDVT)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnchMANH"
				array(4).Value = Strings.Trim(strMaNH)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnchMAMT"
				array(5).Value = Strings.Trim(strMaMT)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pnchMAPL"
				array(6).Value = Strings.Trim(strMAPL)
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pnchMANSX"
				array(7).Value = Strings.Trim(strMaNSX)
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pnchMADC"
				array(8).Value = Strings.Trim(strMaDC)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pmnyPRICE"
				array(9).Value = dblPrice1
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pmnyPRICE2"
				array(10).Value = dblPrice2
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pmnyPRICE3"
				array(11).Value = dblPrice3
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pmnyPRICE4"
				array(12).Value = dblPrice4
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pmnyPRICE5"
				array(13).Value = dblPrice5
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pmnyPRICE6"
				array(14).Value = dblPrice6
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@pmnyPRICE7"
				array(15).Value = dblPrice7
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@pmnyPRICE8"
				array(16).Value = dblPrice8
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pmnyPRICE9"
				array(17).Value = dblPrice9
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@pmnyPRICE10"
				array(18).Value = dblPrice10
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pbitLMATERIAL"
				array(19).Value = 0
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@bitKHO"
				array(20).Value = blnKho
				array(21) = sqlCommand.CreateParameter()
				array(21).ParameterName = "@pnvcREMARK"
				array(21).Value = Strings.Trim(strRemark)
				array(22) = sqlCommand.CreateParameter()
				array(22).ParameterName = "@pnchMADV"
				array(22).Value = Strings.Trim(strMaDV)
				array(23) = sqlCommand.CreateParameter()
				array(23).ParameterName = "@pnchMAINBEP1"
				array(23).Value = Strings.Trim(strMaINBEP1)
				array(24) = sqlCommand.CreateParameter()
				array(24).ParameterName = "@pnchMAINBEP2"
				array(24).Value = Strings.Trim(strMaINBEP2)
				array(25) = sqlCommand.CreateParameter()
				array(25).ParameterName = "@pnchMAINBEP3"
				array(25).Value = Strings.Trim(strMaINBEP3)
				array(26) = sqlCommand.CreateParameter()
				array(26).ParameterName = "@pbitLOPEN"
				array(26).Value = blnLOPEN
				array(27) = sqlCommand.CreateParameter()
				array(27).ParameterName = "@pbitLHIDEN"
				array(27).Value = blnLHIDEN
				array(28) = sqlCommand.CreateParameter()
				array(28).ParameterName = "@pbitLSTOPUSE"
				array(28).Value = blnLSTOPUSE
				array(29) = sqlCommand.CreateParameter()
				array(29).ParameterName = "@pbitLCOMBO"
				array(29).Value = blnLCOMBO
				array(30) = sqlCommand.CreateParameter()
				array(30).ParameterName = "@pnvcCOMBO"
				array(30).Value = strCOMBO.Trim()
				array(31) = sqlCommand.CreateParameter()
				array(31).ParameterName = "@int_Result"
				array(31).Direction = ParameterDirection.ReturnValue
				array(32) = sqlCommand.CreateParameter()
				array(32).ParameterName = "@pmnyPURSE"
				array(32).Value = dblPURE
				array(33) = sqlCommand.CreateParameter()
				array(33).ParameterName = "@pbitLSETCOMBO"
				array(33).Value = blnLSETCOMBO
				array(34) = sqlCommand.CreateParameter()
				array(34).ParameterName = "@pbitLTON_KHACHHANG"
				array(34).Value = blnLTON_KHACHHANG
				array(35) = sqlCommand.CreateParameter()
				array(35).ParameterName = "@pnvcPHIEU"
				array(35).Value = strPHIEU.Trim()
				array(36) = sqlCommand.CreateParameter()
				array(36).ParameterName = "@pnchMAINBEP4"
				array(36).Value = Strings.Trim(strMaINBEP4)
				array(37) = sqlCommand.CreateParameter()
				array(37).ParameterName = "@pnchMAINBEP5"
				array(37).Value = Strings.Trim(strMaINBEP5)
				array(38) = sqlCommand.CreateParameter()
				array(38).ParameterName = "@pnchMAINBEP6"
				array(38).Value = Strings.Trim(strMaINBEP6)
				Dim flag As Boolean = bytIMG IsNot Nothing
				If flag Then
					array(39) = sqlCommand.CreateParameter()
					array(39).ParameterName = "@pimgUIMAGE"
					array(39).Value = bytIMG
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mCNN, array, "SP_FRMDMHH_UPDATE_DMHH", flag2)
				Else
					array(39) = sqlCommand.CreateParameter()
					array(39).ParameterName = "@pnchNO"
					array(39).Value = ""
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mCNN, array, "SP_FRMDMHH_UPDATE_DMHH_NOIMAGE", flag2)
				End If
				Dim num As Integer = Conversions.ToInteger(array(31).Value)
				Me.fDeleteDMHH_SEND(strMa, strMaMay)
				flag = num = 0
				If flag Then
					b = 1
				Else
					b = 0
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gfUpdateDMHH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060006F0 RID: 1776 RVA: 0x00052C38 File Offset: 0x00050E38
		Private Function fDeleteDMHH(mCNN As String, strMAHH As String, strMaMay As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(strMAHH)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mCNN, array, "SP_FRMDMHH_DEL_DMHH", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Me.fDeleteDMHH_SEND(strMAHH, strMaMay)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					b = 0
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060006F1 RID: 1777 RVA: 0x00052DAC File Offset: 0x00050FAC
		Private Function fDeleteDMHH_SEND(strMaHH As String, strMAMAY As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nchMAHH"
				array(0).Value = Strings.Trim(strMaHH)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nchMAMAY"
				array(1).Value = Strings.Trim(strMAMAY)
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMSENDDATA_DELETE_ALL_DATA_DMHH_SEND_DMHHEDIT", flag)
				b = 1
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x040002E5 RID: 741
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040002E7 RID: 743
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040002E8 RID: 744
		<AccessedThroughProperty("dgvCHECK")>
		Private _dgvCHECK As DataGridView

		' Token: 0x040002E9 RID: 745
		<AccessedThroughProperty("colMAMAY")>
		Private _colMAMAY As DataGridViewTextBoxColumn

		' Token: 0x040002EA RID: 746
		<AccessedThroughProperty("colTenMay")>
		Private _colTenMay As DataGridViewTextBoxColumn

		' Token: 0x040002EB RID: 747
		<AccessedThroughProperty("colIP")>
		Private _colIP As DataGridViewTextBoxColumn

		' Token: 0x040002EC RID: 748
		<AccessedThroughProperty("colServer")>
		Private _colServer As DataGridViewTextBoxColumn

		' Token: 0x040002ED RID: 749
		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		' Token: 0x040002EE RID: 750
		<AccessedThroughProperty("lblLeft")>
		Private _lblLeft As Label

		' Token: 0x040002EF RID: 751
		<AccessedThroughProperty("lblCenter")>
		Private _lblCenter As Label

		' Token: 0x040002F0 RID: 752
		<AccessedThroughProperty("lblRight")>
		Private _lblRight As Label

		' Token: 0x040002F1 RID: 753
		<AccessedThroughProperty("picLoad")>
		Private _picLoad As PictureBox

		' Token: 0x040002F2 RID: 754
		<AccessedThroughProperty("Timer2")>
		Private _Timer2 As Timer

		' Token: 0x040002F3 RID: 755
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x040002F4 RID: 756
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x040002F5 RID: 757
		<AccessedThroughProperty("dvgDM")>
		Private _dvgDM As DataGridView

		' Token: 0x040002F6 RID: 758
		<AccessedThroughProperty("colMADM")>
		Private _colMADM As DataGridViewTextBoxColumn

		' Token: 0x040002F7 RID: 759
		<AccessedThroughProperty("colTENDM")>
		Private _colTENDM As DataGridViewTextBoxColumn

		' Token: 0x040002F8 RID: 760
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x040002F9 RID: 761
		<AccessedThroughProperty("lblRight2")>
		Private _lblRight2 As Label

		' Token: 0x040002FA RID: 762
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x040002FB RID: 763
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x040002FC RID: 764
		<AccessedThroughProperty("lstKQ")>
		Private _lstKQ As ListView

		' Token: 0x040002FD RID: 765
		<AccessedThroughProperty("col01")>
		Private _col01 As ColumnHeader

		' Token: 0x040002FE RID: 766
		<AccessedThroughProperty("col02")>
		Private _col02 As ColumnHeader

		' Token: 0x040002FF RID: 767
		<AccessedThroughProperty("col03")>
		Private _col03 As ColumnHeader

		' Token: 0x04000300 RID: 768
		<AccessedThroughProperty("col04")>
		Private _col04 As ColumnHeader

		' Token: 0x04000301 RID: 769
		<AccessedThroughProperty("col05")>
		Private _col05 As ColumnHeader

		' Token: 0x04000302 RID: 770
		Private mArrStrFrmMess As String()

		' Token: 0x04000303 RID: 771
		Private mbytFormStatus As Byte

		' Token: 0x04000304 RID: 772
		Private mbytSuccess As Byte

		' Token: 0x04000305 RID: 773
		Private mclsTbDMNV As clsConnect

		' Token: 0x04000306 RID: 774
		Private mbytSelect_PXK As Byte

		' Token: 0x04000307 RID: 775
		Private mblnSendData As Boolean
	End Class
End Namespace
