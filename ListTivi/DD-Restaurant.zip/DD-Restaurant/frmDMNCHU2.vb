﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200006A RID: 106
	<DesignerGenerated()>
	Public Partial Class frmDMNCHU2
		Inherits Form

		' Token: 0x06002187 RID: 8583 RVA: 0x0019F8FC File Offset: 0x0019DAFC
		<DebuggerNonUserCode()>
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMLN2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMLN2_Load
			frmDMNCHU2.__ENCList.Add(New WeakReference(Me))
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000B79 RID: 2937
		' (get) Token: 0x0600218A RID: 8586 RVA: 0x001A0764 File Offset: 0x0019E964
		' (set) Token: 0x0600218B RID: 8587 RVA: 0x00006B82 File Offset: 0x00004D82
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000B7A RID: 2938
		' (get) Token: 0x0600218C RID: 8588 RVA: 0x001A077C File Offset: 0x0019E97C
		' (set) Token: 0x0600218D RID: 8589 RVA: 0x001A0794 File Offset: 0x0019E994
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000B7B RID: 2939
		' (get) Token: 0x0600218E RID: 8590 RVA: 0x001A0800 File Offset: 0x0019EA00
		' (set) Token: 0x0600218F RID: 8591 RVA: 0x00006B8C File Offset: 0x00004D8C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x17000B7C RID: 2940
		' (get) Token: 0x06002190 RID: 8592 RVA: 0x001A0818 File Offset: 0x0019EA18
		' (set) Token: 0x06002191 RID: 8593 RVA: 0x001A0830 File Offset: 0x0019EA30
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000B7D RID: 2941
		' (get) Token: 0x06002192 RID: 8594 RVA: 0x001A089C File Offset: 0x0019EA9C
		' (set) Token: 0x06002193 RID: 8595 RVA: 0x001A08B4 File Offset: 0x0019EAB4
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000B7E RID: 2942
		' (get) Token: 0x06002194 RID: 8596 RVA: 0x001A0920 File Offset: 0x0019EB20
		' (set) Token: 0x06002195 RID: 8597 RVA: 0x001A0938 File Offset: 0x0019EB38
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000B7F RID: 2943
		' (get) Token: 0x06002196 RID: 8598 RVA: 0x001A09A4 File Offset: 0x0019EBA4
		' (set) Token: 0x06002197 RID: 8599 RVA: 0x00006B96 File Offset: 0x00004D96
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x17000B80 RID: 2944
		' (get) Token: 0x06002198 RID: 8600 RVA: 0x001A09BC File Offset: 0x0019EBBC
		' (set) Token: 0x06002199 RID: 8601 RVA: 0x001A09D4 File Offset: 0x0019EBD4
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000B81 RID: 2945
		' (get) Token: 0x0600219A RID: 8602 RVA: 0x001A0A70 File Offset: 0x0019EC70
		' (set) Token: 0x0600219B RID: 8603 RVA: 0x001A0A88 File Offset: 0x0019EC88
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000B82 RID: 2946
		' (get) Token: 0x0600219C RID: 8604 RVA: 0x001A0B24 File Offset: 0x0019ED24
		' (set) Token: 0x0600219D RID: 8605 RVA: 0x00006BA0 File Offset: 0x00004DA0
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x17000B83 RID: 2947
		' (get) Token: 0x0600219E RID: 8606 RVA: 0x001A0B3C File Offset: 0x0019ED3C
		' (set) Token: 0x0600219F RID: 8607 RVA: 0x00006BAA File Offset: 0x00004DAA
		Friend Overridable Property txtColor As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtColor = value
			End Set
		End Property

		' Token: 0x17000B84 RID: 2948
		' (get) Token: 0x060021A0 RID: 8608 RVA: 0x001A0B54 File Offset: 0x0019ED54
		' (set) Token: 0x060021A1 RID: 8609 RVA: 0x00006BB4 File Offset: 0x00004DB4
		Friend Overridable Property lblREMARK As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblREMARK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblREMARK = value
			End Set
		End Property

		' Token: 0x17000B85 RID: 2949
		' (get) Token: 0x060021A2 RID: 8610 RVA: 0x001A0B6C File Offset: 0x0019ED6C
		' (set) Token: 0x060021A3 RID: 8611 RVA: 0x001A0B84 File Offset: 0x0019ED84
		Friend Overridable Property txtREMARK As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtREMARK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtREMARK IsNot Nothing
				If flag Then
					RemoveHandler Me._txtREMARK.KeyPress, AddressOf Me.txtREMARK_KeyPress
					RemoveHandler Me._txtREMARK.LostFocus, AddressOf Me.txtREMARK_LostFocus
				End If
				Me._txtREMARK = value
				flag = Me._txtREMARK IsNot Nothing
				If flag Then
					AddHandler Me._txtREMARK.KeyPress, AddressOf Me.txtREMARK_KeyPress
					AddHandler Me._txtREMARK.LostFocus, AddressOf Me.txtREMARK_LostFocus
				End If
			End Set
		End Property

		' Token: 0x17000B86 RID: 2950
		' (get) Token: 0x060021A4 RID: 8612 RVA: 0x001A0C20 File Offset: 0x0019EE20
		' (set) Token: 0x060021A5 RID: 8613 RVA: 0x001A0C38 File Offset: 0x0019EE38
		Friend Overridable Property TxtDISCOUNT As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._TxtDISCOUNT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._TxtDISCOUNT IsNot Nothing
				If flag Then
					RemoveHandler Me._TxtDISCOUNT.KeyPress, AddressOf Me.TxtDISCOUNT_KeyPress
				End If
				Me._TxtDISCOUNT = value
				flag = Me._TxtDISCOUNT IsNot Nothing
				If flag Then
					AddHandler Me._TxtDISCOUNT.KeyPress, AddressOf Me.TxtDISCOUNT_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000B87 RID: 2951
		' (get) Token: 0x060021A6 RID: 8614 RVA: 0x001A0CA4 File Offset: 0x0019EEA4
		' (set) Token: 0x060021A7 RID: 8615 RVA: 0x00006BBE File Offset: 0x00004DBE
		Friend Overridable Property LblDISCOUNT As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._LblDISCOUNT
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._LblDISCOUNT = value
			End Set
		End Property

		' Token: 0x17000B88 RID: 2952
		' (get) Token: 0x060021A8 RID: 8616 RVA: 0x001A0CBC File Offset: 0x0019EEBC
		' (set) Token: 0x060021A9 RID: 8617 RVA: 0x00006BC8 File Offset: 0x00004DC8
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000B89 RID: 2953
		' (get) Token: 0x060021AA RID: 8618 RVA: 0x001A0CD4 File Offset: 0x0019EED4
		' (set) Token: 0x060021AB RID: 8619 RVA: 0x001A0CEC File Offset: 0x0019EEEC
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x17000B8A RID: 2954
		' (get) Token: 0x060021AC RID: 8620 RVA: 0x001A0D58 File Offset: 0x0019EF58
		' (set) Token: 0x060021AD RID: 8621 RVA: 0x00006BD2 File Offset: 0x00004DD2
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000B8B RID: 2955
		' (get) Token: 0x060021AE RID: 8622 RVA: 0x001A0D70 File Offset: 0x0019EF70
		' (set) Token: 0x060021AF RID: 8623 RVA: 0x00006BDD File Offset: 0x00004DDD
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000B8C RID: 2956
		' (get) Token: 0x060021B0 RID: 8624 RVA: 0x001A0D88 File Offset: 0x0019EF88
		' (set) Token: 0x060021B1 RID: 8625 RVA: 0x00006BE8 File Offset: 0x00004DE8
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x060021B2 RID: 8626 RVA: 0x001A0DA0 File Offset: 0x0019EFA0
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.TxtDISCOUNT.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060021B3 RID: 8627 RVA: 0x001A0E44 File Offset: 0x0019F044
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060021B4 RID: 8628 RVA: 0x001A0EF0 File Offset: 0x0019F0F0
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.btnExit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060021B5 RID: 8629 RVA: 0x001A0F9C File Offset: 0x0019F19C
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060021B6 RID: 8630 RVA: 0x001A1044 File Offset: 0x0019F244
		Private Sub frmDMLN2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLN2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060021B7 RID: 8631 RVA: 0x001A10F0 File Offset: 0x0019F2F0
		Private Sub frmDMLN2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLN2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060021B8 RID: 8632 RVA: 0x001A119C File Offset: 0x0019F39C
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
						If flag Then
							Me.mbytSuccess = Me.fAddNew()
						Else
							flag = Me.mbytFormStatus = 3
							If flag Then
								Me.mbytSuccess = Me.fModify()
							End If
						End If
						flag = Me.mbytSuccess = 1
						If flag Then
							Me.Close()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060021B9 RID: 8633 RVA: 0x001A1328 File Offset: 0x0019F528
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060021BA RID: 8634 RVA: 0x001A13CC File Offset: 0x0019F5CC
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.TxtDISCOUNT.Text), ",", "", 1, -1, CompareMethod.Binary)
				flag = (Operators.CompareString(text2, "", False) <> 0) And Not Versioned.IsNumeric(text2)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(52), MsgBoxStyle.Critical, Nothing)
					Me.TxtDISCOUNT.Focus()
				Else
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), "GIAMGIA= "), Strings.Replace(text2, ",", "", 1, -1, CompareMethod.Binary)), ""))
					End If
					text2 = Strings.Replace(Strings.Trim(Me.txtREMARK.Text), "'", "''", 1, -1, CompareMethod.Binary)
					flag = Strings.Len(text2) > 0
					If flag Then
						text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '"), text2), "%'"))
					End If
					Me.mStrFilter = text
					flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
					If flag Then
						Me.mbytSuccess = 1
					End If
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060021BB RID: 8635 RVA: 0x001A1634 File Offset: 0x0019F834
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.TxtDISCOUNT.Text), ",", "", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " GIAMGIA ="), Conversion.Val(Strings.Replace(text2, ",", "", 1, -1, CompareMethod.Binary))), ""))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtREMARK.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060021BC RID: 8636 RVA: 0x001A18D0 File Offset: 0x0019FAD0
		Private Sub txtREMARK_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060021BD RID: 8637 RVA: 0x001A1978 File Offset: 0x0019FB78
		Private Sub txtREMARK_LostFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060021BE RID: 8638 RVA: 0x001A1A24 File Offset: 0x0019FC24
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.Focus()
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtREMARK.[ReadOnly] = True
						Me.TxtDISCOUNT.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtColor.BackColor
						Me.txtOBJNAME.BackColor = Me.txtColor.BackColor
						Me.txtREMARK.BackColor = Me.txtColor.BackColor
						Me.TxtDISCOUNT.BackColor = Me.txtColor.BackColor
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060021BF RID: 8639 RVA: 0x001A1BB8 File Offset: 0x0019FDB8
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060021C0 RID: 8640 RVA: 0x001A1D48 File Offset: 0x0019FF48
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 3
				Me.txtOBJNAME.MaxLength = 100
				Me.txtREMARK.MaxLength = 200
				Me.TxtDISCOUNT.MaxLength = 3
				Me.TxtDISCOUNT.TextAlign = HorizontalAlignment.Right
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060021C1 RID: 8641 RVA: 0x001A1E48 File Offset: 0x001A0048
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.lblOBJID.Tag = "CB0007"
				Me.lblOBJNAME.Tag = "CB0008"
				Me.LblDISCOUNT.Tag = "CR0010"
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060021C2 RID: 8642 RVA: 0x001A2040 File Offset: 0x001A0240
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060021C3 RID: 8643 RVA: 0x001A20E0 File Offset: 0x001A02E0
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@MA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@TEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@GHICHU"
				array(2).Value = Strings.Trim(Me.txtREMARK.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pdecDISTCOUNT"
				array(3).Value = Conversion.Val(Strings.Replace(Strings.Trim(Me.TxtDISCOUNT.Text), ",", "", 1, -1, CompareMethod.Binary))
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@int_Result"
				array(4).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNCHU_INSERT_DMNCHU", flag)
				Dim num As Integer = Conversions.ToInteger(array(4).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060021C4 RID: 8644 RVA: 0x001A2364 File Offset: 0x001A0564
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@MA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@TEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@GHICHU"
				array(2).Value = Strings.Trim(Me.txtREMARK.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pdecDISTCOUNT"
				array(3).Value = Conversion.Val(Strings.Replace(Strings.Trim(Me.TxtDISCOUNT.Text), ",", "", 1, -1, CompareMethod.Binary))
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@int_Result"
				array(4).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNCHU_UPDATE_DMNCHU", flag)
				Dim num As Integer = Conversions.ToInteger(array(4).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060021C5 RID: 8645 RVA: 0x001A25D8 File Offset: 0x001A07D8
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNCHU_DEL_DMNCHU", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
						Else
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060021C6 RID: 8646 RVA: 0x001A279C File Offset: 0x001A099C
		Private Sub TxtDISCOUNT_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txtREMARK.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - TxtDISCOUNT_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060021C7 RID: 8647 RVA: 0x001A2938 File Offset: 0x001A0B38
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x060021C8 RID: 8648 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x04000DAF RID: 3503
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000DB1 RID: 3505
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000DB2 RID: 3506
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000DB3 RID: 3507
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000DB4 RID: 3508
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000DB5 RID: 3509
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000DB6 RID: 3510
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000DB7 RID: 3511
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000DB8 RID: 3512
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000DB9 RID: 3513
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000DBA RID: 3514
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000DBB RID: 3515
		<AccessedThroughProperty("txtColor")>
		Private _txtColor As TextBox

		' Token: 0x04000DBC RID: 3516
		<AccessedThroughProperty("lblREMARK")>
		Private _lblREMARK As Label

		' Token: 0x04000DBD RID: 3517
		<AccessedThroughProperty("txtREMARK")>
		Private _txtREMARK As TextBox

		' Token: 0x04000DBE RID: 3518
		<AccessedThroughProperty("TxtDISCOUNT")>
		Private _TxtDISCOUNT As TextBox

		' Token: 0x04000DBF RID: 3519
		<AccessedThroughProperty("LblDISCOUNT")>
		Private _LblDISCOUNT As Label

		' Token: 0x04000DC0 RID: 3520
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000DC1 RID: 3521
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000DC2 RID: 3522
		Private mArrStrFrmMess As String()

		' Token: 0x04000DC3 RID: 3523
		Private mbytFormStatus As Byte

		' Token: 0x04000DC4 RID: 3524
		Private mbytSuccess As Byte

		' Token: 0x04000DC5 RID: 3525
		Private mStrFilter As String
	End Class
End Namespace
