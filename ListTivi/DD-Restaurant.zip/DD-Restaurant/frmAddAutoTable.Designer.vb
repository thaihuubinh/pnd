﻿Namespace prjIS_SalesPOS
	' Token: 0x02000015 RID: 21
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmAddAutoTable
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000251 RID: 593 RVA: 0x0001EA20 File Offset: 0x0001CC20
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000252 RID: 594 RVA: 0x0001EA58 File Offset: 0x0001CC58
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmAddAutoTable))
			Me.btnFont = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.lblFont = New Global.System.Windows.Forms.Label()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.btnColorBack = New Global.System.Windows.Forms.Button()
			Me.Label5 = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.lblTablename = New Global.System.Windows.Forms.Label()
			Me.btnTablename = New Global.System.Windows.Forms.Button()
			Me.btnStart = New Global.System.Windows.Forms.Button()
			Me.lblStart = New Global.System.Windows.Forms.Label()
			Me.Label7 = New Global.System.Windows.Forms.Label()
			Me.btnEnd = New Global.System.Windows.Forms.Button()
			Me.lblEnd = New Global.System.Windows.Forms.Label()
			Me.Label9 = New Global.System.Windows.Forms.Label()
			Me.btnRow = New Global.System.Windows.Forms.Button()
			Me.lblRow = New Global.System.Windows.Forms.Label()
			Me.Label11 = New Global.System.Windows.Forms.Label()
			Me.btnCol = New Global.System.Windows.Forms.Button()
			Me.lblCol = New Global.System.Windows.Forms.Label()
			Me.Label13 = New Global.System.Windows.Forms.Label()
			Me.SuspendLayout()
			Me.btnFont.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.None
			Me.btnFont.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnFont.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnFont.Image = CType(componentResourceManager.GetObject("btnFont.Image"), Global.System.Drawing.Image)
			Dim btnFont As Global.System.Windows.Forms.Control = Me.btnFont
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(454, 9)
			btnFont.Location = point
			Dim btnFont2 As Global.System.Windows.Forms.Control = Me.btnFont
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(2)
			btnFont2.Margin = padding
			Me.btnFont.Name = "btnFont"
			Dim btnFont3 As Global.System.Windows.Forms.Control = Me.btnFont
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(43, 35)
			btnFont3.Size = size
			Me.btnFont.TabIndex = 18
			Me.btnFont.Tag = ""
			Me.btnFont.UseVisualStyleBackColor = True
			Me.btnExit.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(367, 375)
			btnExit.Location = point
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			padding = New Global.System.Windows.Forms.Padding(2)
			btnExit2.Margin = padding
			Me.btnExit.Name = "btnExit"
			Dim btnExit3 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(130, 54)
			btnExit3.Size = size
			Me.btnExit.TabIndex = 17
			Me.btnExit.Tag = "C00002"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = False
			Me.btnSave.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnSave.BackgroundImage = CType(componentResourceManager.GetObject("btnSave.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnSave.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnSave.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnSave.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Me.btnSave.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(11, 375)
			btnSave.Location = point
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			padding = New Global.System.Windows.Forms.Padding(2)
			btnSave2.Margin = padding
			Me.btnSave.Name = "btnSave"
			Dim btnSave3 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(130, 54)
			btnSave3.Size = size
			Me.btnSave.TabIndex = 16
			Me.btnSave.Tag = "C00001"
			Me.btnSave.Text = "chon"
			Me.btnSave.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = False
			Me.lblFont.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblFont.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblFont.ForeColor = Global.System.Drawing.Color.Black
			Dim lblFont As Global.System.Windows.Forms.Control = Me.lblFont
			point = New Global.System.Drawing.Point(203, 9)
			lblFont.Location = point
			Dim lblFont2 As Global.System.Windows.Forms.Control = Me.lblFont
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			lblFont2.Margin = padding
			Me.lblFont.Name = "lblFont"
			Dim lblFont3 As Global.System.Windows.Forms.Control = Me.lblFont
			size = New Global.System.Drawing.Size(236, 113)
			lblFont3.Size = size
			Me.lblFont.TabIndex = 14
			Me.lblFont.Text = "Abc"
			Me.lblFont.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label1.ForeColor = Global.System.Drawing.Color.FromArgb(0, 0, 192)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(16, 10)
			label.Location = point
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			label2.Margin = padding
			Me.Label1.Name = "Label1"
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(174, 31)
			label3.Size = size
			Me.Label1.TabIndex = 15
			Me.Label1.Tag = "C00003"
			Me.Label1.Text = "chọn font"
			Me.btnColorBack.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.None
			Me.btnColorBack.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnColorBack.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnColorBack.Image = CType(componentResourceManager.GetObject("btnColorBack.Image"), Global.System.Drawing.Image)
			Dim btnColorBack As Global.System.Windows.Forms.Control = Me.btnColorBack
			point = New Global.System.Drawing.Point(454, 49)
			btnColorBack.Location = point
			Dim btnColorBack2 As Global.System.Windows.Forms.Control = Me.btnColorBack
			padding = New Global.System.Windows.Forms.Padding(2)
			btnColorBack2.Margin = padding
			Me.btnColorBack.Name = "btnColorBack"
			Dim btnColorBack3 As Global.System.Windows.Forms.Control = Me.btnColorBack
			size = New Global.System.Drawing.Size(43, 35)
			btnColorBack3.Size = size
			Me.btnColorBack.TabIndex = 24
			Me.btnColorBack.Tag = ""
			Me.btnColorBack.UseVisualStyleBackColor = True
			Me.Label5.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label5.ForeColor = Global.System.Drawing.Color.FromArgb(0, 0, 192)
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label5
			point = New Global.System.Drawing.Point(16, 50)
			label4.Location = point
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label5
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			label5.Margin = padding
			Me.Label5.Name = "Label5"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label5
			size = New Global.System.Drawing.Size(174, 31)
			label6.Size = size
			Me.Label5.TabIndex = 23
			Me.Label5.Tag = "C00005"
			Me.Label5.Text = "chọn mau nen"
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label2.ForeColor = Global.System.Drawing.Color.FromArgb(0, 0, 192)
			Dim label7 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(16, 131)
			label7.Location = point
			Dim label8 As Global.System.Windows.Forms.Control = Me.Label2
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			label8.Margin = padding
			Me.Label2.Name = "Label2"
			Dim label9 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(174, 31)
			label9.Size = size
			Me.Label2.TabIndex = 25
			Me.Label2.Tag = "C00006"
			Me.Label2.Text = "ki tu dau ten ban"
			Me.lblTablename.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblTablename.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblTablename.ForeColor = Global.System.Drawing.Color.Black
			Dim lblTablename As Global.System.Windows.Forms.Control = Me.lblTablename
			point = New Global.System.Drawing.Point(203, 132)
			lblTablename.Location = point
			Dim lblTablename2 As Global.System.Windows.Forms.Control = Me.lblTablename
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			lblTablename2.Margin = padding
			Me.lblTablename.Name = "lblTablename"
			Dim lblTablename3 As Global.System.Windows.Forms.Control = Me.lblTablename
			size = New Global.System.Drawing.Size(236, 34)
			lblTablename3.Size = size
			Me.lblTablename.TabIndex = 26
			Me.lblTablename.Text = "B"
			Me.lblTablename.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btnTablename.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.None
			Me.btnTablename.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnTablename.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnTablename.Image = CType(componentResourceManager.GetObject("btnTablename.Image"), Global.System.Drawing.Image)
			Dim btnTablename As Global.System.Windows.Forms.Control = Me.btnTablename
			point = New Global.System.Drawing.Point(454, 132)
			btnTablename.Location = point
			Dim btnTablename2 As Global.System.Windows.Forms.Control = Me.btnTablename
			padding = New Global.System.Windows.Forms.Padding(2)
			btnTablename2.Margin = padding
			Me.btnTablename.Name = "btnTablename"
			Dim btnTablename3 As Global.System.Windows.Forms.Control = Me.btnTablename
			size = New Global.System.Drawing.Size(43, 35)
			btnTablename3.Size = size
			Me.btnTablename.TabIndex = 27
			Me.btnTablename.Tag = ""
			Me.btnTablename.UseVisualStyleBackColor = True
			Me.btnStart.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.None
			Me.btnStart.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnStart.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnStart.Image = CType(componentResourceManager.GetObject("btnStart.Image"), Global.System.Drawing.Image)
			Dim btnStart As Global.System.Windows.Forms.Control = Me.btnStart
			point = New Global.System.Drawing.Point(454, 172)
			btnStart.Location = point
			Dim btnStart2 As Global.System.Windows.Forms.Control = Me.btnStart
			padding = New Global.System.Windows.Forms.Padding(2)
			btnStart2.Margin = padding
			Me.btnStart.Name = "btnStart"
			Dim btnStart3 As Global.System.Windows.Forms.Control = Me.btnStart
			size = New Global.System.Drawing.Size(43, 35)
			btnStart3.Size = size
			Me.btnStart.TabIndex = 30
			Me.btnStart.Tag = ""
			Me.btnStart.UseVisualStyleBackColor = True
			Me.lblStart.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblStart.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblStart.ForeColor = Global.System.Drawing.Color.Black
			Dim lblStart As Global.System.Windows.Forms.Control = Me.lblStart
			point = New Global.System.Drawing.Point(203, 172)
			lblStart.Location = point
			Dim lblStart2 As Global.System.Windows.Forms.Control = Me.lblStart
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			lblStart2.Margin = padding
			Me.lblStart.Name = "lblStart"
			Dim lblStart3 As Global.System.Windows.Forms.Control = Me.lblStart
			size = New Global.System.Drawing.Size(236, 34)
			lblStart3.Size = size
			Me.lblStart.TabIndex = 29
			Me.lblStart.Text = "1"
			Me.lblStart.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label7.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label7.ForeColor = Global.System.Drawing.Color.FromArgb(0, 0, 192)
			Dim label10 As Global.System.Windows.Forms.Control = Me.Label7
			point = New Global.System.Drawing.Point(16, 172)
			label10.Location = point
			Dim label11 As Global.System.Windows.Forms.Control = Me.Label7
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			label11.Margin = padding
			Me.Label7.Name = "Label7"
			Dim label12 As Global.System.Windows.Forms.Control = Me.Label7
			size = New Global.System.Drawing.Size(174, 31)
			label12.Size = size
			Me.Label7.TabIndex = 28
			Me.Label7.Tag = "C00007"
			Me.Label7.Text = "So ban bat dau"
			Me.btnEnd.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.None
			Me.btnEnd.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnEnd.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnEnd.Image = CType(componentResourceManager.GetObject("btnEnd.Image"), Global.System.Drawing.Image)
			Dim btnEnd As Global.System.Windows.Forms.Control = Me.btnEnd
			point = New Global.System.Drawing.Point(454, 212)
			btnEnd.Location = point
			Dim btnEnd2 As Global.System.Windows.Forms.Control = Me.btnEnd
			padding = New Global.System.Windows.Forms.Padding(2)
			btnEnd2.Margin = padding
			Me.btnEnd.Name = "btnEnd"
			Dim btnEnd3 As Global.System.Windows.Forms.Control = Me.btnEnd
			size = New Global.System.Drawing.Size(43, 35)
			btnEnd3.Size = size
			Me.btnEnd.TabIndex = 33
			Me.btnEnd.Tag = ""
			Me.btnEnd.UseVisualStyleBackColor = True
			Me.lblEnd.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblEnd.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblEnd.ForeColor = Global.System.Drawing.Color.Black
			Dim lblEnd As Global.System.Windows.Forms.Control = Me.lblEnd
			point = New Global.System.Drawing.Point(203, 212)
			lblEnd.Location = point
			Dim lblEnd2 As Global.System.Windows.Forms.Control = Me.lblEnd
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			lblEnd2.Margin = padding
			Me.lblEnd.Name = "lblEnd"
			Dim lblEnd3 As Global.System.Windows.Forms.Control = Me.lblEnd
			size = New Global.System.Drawing.Size(236, 34)
			lblEnd3.Size = size
			Me.lblEnd.TabIndex = 32
			Me.lblEnd.Text = "20"
			Me.lblEnd.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label9.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label9.ForeColor = Global.System.Drawing.Color.FromArgb(0, 0, 192)
			Dim label13 As Global.System.Windows.Forms.Control = Me.Label9
			point = New Global.System.Drawing.Point(16, 212)
			label13.Location = point
			Dim label14 As Global.System.Windows.Forms.Control = Me.Label9
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			label14.Margin = padding
			Me.Label9.Name = "Label9"
			Dim label15 As Global.System.Windows.Forms.Control = Me.Label9
			size = New Global.System.Drawing.Size(174, 31)
			label15.Size = size
			Me.Label9.TabIndex = 31
			Me.Label9.Tag = "C00008"
			Me.Label9.Text = "so ban ket thuc"
			Me.btnRow.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.None
			Me.btnRow.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnRow.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnRow.Image = CType(componentResourceManager.GetObject("btnRow.Image"), Global.System.Drawing.Image)
			Dim btnRow As Global.System.Windows.Forms.Control = Me.btnRow
			point = New Global.System.Drawing.Point(454, 293)
			btnRow.Location = point
			Dim btnRow2 As Global.System.Windows.Forms.Control = Me.btnRow
			padding = New Global.System.Windows.Forms.Padding(2)
			btnRow2.Margin = padding
			Me.btnRow.Name = "btnRow"
			Dim btnRow3 As Global.System.Windows.Forms.Control = Me.btnRow
			size = New Global.System.Drawing.Size(43, 35)
			btnRow3.Size = size
			Me.btnRow.TabIndex = 39
			Me.btnRow.Tag = ""
			Me.btnRow.UseVisualStyleBackColor = True
			Me.btnRow.Visible = False
			Me.lblRow.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblRow.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblRow.ForeColor = Global.System.Drawing.Color.Black
			Dim lblRow As Global.System.Windows.Forms.Control = Me.lblRow
			point = New Global.System.Drawing.Point(203, 293)
			lblRow.Location = point
			Dim lblRow2 As Global.System.Windows.Forms.Control = Me.lblRow
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			lblRow2.Margin = padding
			Me.lblRow.Name = "lblRow"
			Dim lblRow3 As Global.System.Windows.Forms.Control = Me.lblRow
			size = New Global.System.Drawing.Size(236, 34)
			lblRow3.Size = size
			Me.lblRow.TabIndex = 38
			Me.lblRow.Text = "4"
			Me.lblRow.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lblRow.Visible = False
			Me.Label11.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label11.ForeColor = Global.System.Drawing.Color.FromArgb(0, 0, 192)
			Dim label16 As Global.System.Windows.Forms.Control = Me.Label11
			point = New Global.System.Drawing.Point(16, 293)
			label16.Location = point
			Dim label17 As Global.System.Windows.Forms.Control = Me.Label11
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			label17.Margin = padding
			Me.Label11.Name = "Label11"
			Dim label18 As Global.System.Windows.Forms.Control = Me.Label11
			size = New Global.System.Drawing.Size(174, 31)
			label18.Size = size
			Me.Label11.TabIndex = 37
			Me.Label11.Tag = "C000010"
			Me.Label11.Text = "so ban tren 1 dong"
			Me.Label11.Visible = False
			Me.btnCol.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.None
			Me.btnCol.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnCol.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnCol.Image = CType(componentResourceManager.GetObject("btnCol.Image"), Global.System.Drawing.Image)
			Dim btnCol As Global.System.Windows.Forms.Control = Me.btnCol
			point = New Global.System.Drawing.Point(454, 253)
			btnCol.Location = point
			Dim btnCol2 As Global.System.Windows.Forms.Control = Me.btnCol
			padding = New Global.System.Windows.Forms.Padding(2)
			btnCol2.Margin = padding
			Me.btnCol.Name = "btnCol"
			Dim btnCol3 As Global.System.Windows.Forms.Control = Me.btnCol
			size = New Global.System.Drawing.Size(43, 35)
			btnCol3.Size = size
			Me.btnCol.TabIndex = 36
			Me.btnCol.Tag = ""
			Me.btnCol.UseVisualStyleBackColor = True
			Me.lblCol.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblCol.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblCol.ForeColor = Global.System.Drawing.Color.Black
			Dim lblCol As Global.System.Windows.Forms.Control = Me.lblCol
			point = New Global.System.Drawing.Point(203, 253)
			lblCol.Location = point
			Dim lblCol2 As Global.System.Windows.Forms.Control = Me.lblCol
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			lblCol2.Margin = padding
			Me.lblCol.Name = "lblCol"
			Dim lblCol3 As Global.System.Windows.Forms.Control = Me.lblCol
			size = New Global.System.Drawing.Size(236, 34)
			lblCol3.Size = size
			Me.lblCol.TabIndex = 35
			Me.lblCol.Text = "5"
			Me.lblCol.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label13.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label13.ForeColor = Global.System.Drawing.Color.FromArgb(0, 0, 192)
			Dim label19 As Global.System.Windows.Forms.Control = Me.Label13
			point = New Global.System.Drawing.Point(16, 253)
			label19.Location = point
			Dim label20 As Global.System.Windows.Forms.Control = Me.Label13
			padding = New Global.System.Windows.Forms.Padding(2, 0, 2, 0)
			label20.Margin = padding
			Me.Label13.Name = "Label13"
			Dim label21 As Global.System.Windows.Forms.Control = Me.Label13
			size = New Global.System.Drawing.Size(174, 31)
			label21.Size = size
			Me.Label13.TabIndex = 34
			Me.Label13.Tag = "C00010"
			Me.Label13.Text = "So ban tren 1 cot"
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(9F, 18F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(508, 440)
			Me.ClientSize = size
			Me.Controls.Add(Me.btnRow)
			Me.Controls.Add(Me.lblRow)
			Me.Controls.Add(Me.Label11)
			Me.Controls.Add(Me.btnCol)
			Me.Controls.Add(Me.lblCol)
			Me.Controls.Add(Me.Label13)
			Me.Controls.Add(Me.btnEnd)
			Me.Controls.Add(Me.lblEnd)
			Me.Controls.Add(Me.Label9)
			Me.Controls.Add(Me.btnStart)
			Me.Controls.Add(Me.lblStart)
			Me.Controls.Add(Me.Label7)
			Me.Controls.Add(Me.btnTablename)
			Me.Controls.Add(Me.lblTablename)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.btnColorBack)
			Me.Controls.Add(Me.Label5)
			Me.Controls.Add(Me.btnFont)
			Me.Controls.Add(Me.btnExit)
			Me.Controls.Add(Me.btnSave)
			Me.Controls.Add(Me.lblFont)
			Me.Controls.Add(Me.Label1)
			Me.Font = New Global.System.Drawing.Font("Arial Black", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			padding = New Global.System.Windows.Forms.Padding(5, 4, 5, 4)
			Me.Margin = padding
			Me.Name = "frmAddAutoTable"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x040000FF RID: 255
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
