﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000057 RID: 87
	<DesignerGenerated()>
	Public Partial Class frmDMLDCHI1
		Inherits Form

		' Token: 0x06001A3F RID: 6719 RVA: 0x001459F8 File Offset: 0x00143BF8
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMLDCHI1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMLDCHI1_Load
			frmDMLDCHI1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000907 RID: 2311
		' (get) Token: 0x06001A42 RID: 6722 RVA: 0x00146C84 File Offset: 0x00144E84
		' (set) Token: 0x06001A43 RID: 6723 RVA: 0x00005CB2 File Offset: 0x00003EB2
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000908 RID: 2312
		' (get) Token: 0x06001A44 RID: 6724 RVA: 0x00146C9C File Offset: 0x00144E9C
		' (set) Token: 0x06001A45 RID: 6725 RVA: 0x00146CB4 File Offset: 0x00144EB4
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000909 RID: 2313
		' (get) Token: 0x06001A46 RID: 6726 RVA: 0x00146D20 File Offset: 0x00144F20
		' (set) Token: 0x06001A47 RID: 6727 RVA: 0x00146D38 File Offset: 0x00144F38
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x1700090A RID: 2314
		' (get) Token: 0x06001A48 RID: 6728 RVA: 0x00146DA4 File Offset: 0x00144FA4
		' (set) Token: 0x06001A49 RID: 6729 RVA: 0x00146DBC File Offset: 0x00144FBC
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x1700090B RID: 2315
		' (get) Token: 0x06001A4A RID: 6730 RVA: 0x00146E28 File Offset: 0x00145028
		' (set) Token: 0x06001A4B RID: 6731 RVA: 0x00146E40 File Offset: 0x00145040
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x1700090C RID: 2316
		' (get) Token: 0x06001A4C RID: 6732 RVA: 0x00146EAC File Offset: 0x001450AC
		' (set) Token: 0x06001A4D RID: 6733 RVA: 0x00146EC4 File Offset: 0x001450C4
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x1700090D RID: 2317
		' (get) Token: 0x06001A4E RID: 6734 RVA: 0x00146F30 File Offset: 0x00145130
		' (set) Token: 0x06001A4F RID: 6735 RVA: 0x00146F48 File Offset: 0x00145148
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x1700090E RID: 2318
		' (get) Token: 0x06001A50 RID: 6736 RVA: 0x00146FB4 File Offset: 0x001451B4
		' (set) Token: 0x06001A51 RID: 6737 RVA: 0x00005CBC File Offset: 0x00003EBC
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x1700090F RID: 2319
		' (get) Token: 0x06001A52 RID: 6738 RVA: 0x00146FCC File Offset: 0x001451CC
		' (set) Token: 0x06001A53 RID: 6739 RVA: 0x00146FE4 File Offset: 0x001451E4
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000910 RID: 2320
		' (get) Token: 0x06001A54 RID: 6740 RVA: 0x00147050 File Offset: 0x00145250
		' (set) Token: 0x06001A55 RID: 6741 RVA: 0x00147068 File Offset: 0x00145268
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x17000911 RID: 2321
		' (get) Token: 0x06001A56 RID: 6742 RVA: 0x001470D4 File Offset: 0x001452D4
		' (set) Token: 0x06001A57 RID: 6743 RVA: 0x001470EC File Offset: 0x001452EC
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000912 RID: 2322
		' (get) Token: 0x06001A58 RID: 6744 RVA: 0x00147158 File Offset: 0x00145358
		' (set) Token: 0x06001A59 RID: 6745 RVA: 0x00005CC6 File Offset: 0x00003EC6
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x17000913 RID: 2323
		' (get) Token: 0x06001A5A RID: 6746 RVA: 0x00147170 File Offset: 0x00145370
		' (set) Token: 0x06001A5B RID: 6747 RVA: 0x00147188 File Offset: 0x00145388
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x17000914 RID: 2324
		' (get) Token: 0x06001A5C RID: 6748 RVA: 0x001471F4 File Offset: 0x001453F4
		' (set) Token: 0x06001A5D RID: 6749 RVA: 0x0014720C File Offset: 0x0014540C
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x17000915 RID: 2325
		' (get) Token: 0x06001A5E RID: 6750 RVA: 0x00147278 File Offset: 0x00145478
		' (set) Token: 0x06001A5F RID: 6751 RVA: 0x00147290 File Offset: 0x00145490
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000916 RID: 2326
		' (get) Token: 0x06001A60 RID: 6752 RVA: 0x001472FC File Offset: 0x001454FC
		' (set) Token: 0x06001A61 RID: 6753 RVA: 0x00147314 File Offset: 0x00145514
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000917 RID: 2327
		' (get) Token: 0x06001A62 RID: 6754 RVA: 0x00147380 File Offset: 0x00145580
		' (set) Token: 0x06001A63 RID: 6755 RVA: 0x00147398 File Offset: 0x00145598
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000918 RID: 2328
		' (get) Token: 0x06001A64 RID: 6756 RVA: 0x00147404 File Offset: 0x00145604
		' (set) Token: 0x06001A65 RID: 6757 RVA: 0x0014741C File Offset: 0x0014561C
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x17000919 RID: 2329
		' (get) Token: 0x06001A66 RID: 6758 RVA: 0x00147488 File Offset: 0x00145688
		' (set) Token: 0x06001A67 RID: 6759 RVA: 0x001474A0 File Offset: 0x001456A0
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x1700091A RID: 2330
		' (get) Token: 0x06001A68 RID: 6760 RVA: 0x0014750C File Offset: 0x0014570C
		' (set) Token: 0x06001A69 RID: 6761 RVA: 0x00005CD0 File Offset: 0x00003ED0
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x1700091B RID: 2331
		' (get) Token: 0x06001A6A RID: 6762 RVA: 0x00147524 File Offset: 0x00145724
		' (set) Token: 0x06001A6B RID: 6763 RVA: 0x0014753C File Offset: 0x0014573C
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x1700091C RID: 2332
		' (get) Token: 0x06001A6C RID: 6764 RVA: 0x001475A8 File Offset: 0x001457A8
		' (set) Token: 0x06001A6D RID: 6765 RVA: 0x00005CDA File Offset: 0x00003EDA
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x1700091D RID: 2333
		' (get) Token: 0x06001A6E RID: 6766 RVA: 0x001475C0 File Offset: 0x001457C0
		' (set) Token: 0x06001A6F RID: 6767 RVA: 0x00005CE5 File Offset: 0x00003EE5
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x1700091E RID: 2334
		' (get) Token: 0x06001A70 RID: 6768 RVA: 0x001475D8 File Offset: 0x001457D8
		' (set) Token: 0x06001A71 RID: 6769 RVA: 0x00005CF0 File Offset: 0x00003EF0
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06001A72 RID: 6770 RVA: 0x001475F0 File Offset: 0x001457F0
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
				Me.mStrOBJNAME = Me.dgvData.CurrentRow.Cells("OBJNAME").Value.ToString().Trim() + "  " + Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value.ToString().Trim()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A73 RID: 6771 RVA: 0x00147714 File Offset: 0x00145914
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A74 RID: 6772 RVA: 0x001477E4 File Offset: 0x001459E4
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A75 RID: 6773 RVA: 0x001478D4 File Offset: 0x00145AD4
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A76 RID: 6774 RVA: 0x001479B8 File Offset: 0x00145BB8
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A77 RID: 6775 RVA: 0x00147A7C File Offset: 0x00145C7C
		Private Sub frmDMLDCHI1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLDCHI1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A78 RID: 6776 RVA: 0x00147B14 File Offset: 0x00145D14
		Private Sub frmDMLDCHI1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLDCHI1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A79 RID: 6777 RVA: 0x00147C1C File Offset: 0x00145E1C
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A7A RID: 6778 RVA: 0x00147D24 File Offset: 0x00145F24
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A7B RID: 6779 RVA: 0x00147DBC File Offset: 0x00145FBC
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMLDCHI As frmDMLDCHI2 = New frmDMLDCHI2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMLDCHI.pbytFromStatus = 1
				Dim flag As Boolean = Me.mblnAutoAdd
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLDCHI_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMLDCHI.txtOBJID.Text = Strings.Right("0" + array(0).Value.ToString(), 2)
						frmDMLDCHI.txtOBJID.[ReadOnly] = True
						frmDMLDCHI.txtOBJID.BackColor = frmDMLDCHI.txtColor.BackColor
					End If
				End If
				frmDMLDCHI.ShowDialog()
				flag = frmDMLDCHI.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMLDCHI.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMLDCHI.Dispose()
			End Try
		End Sub

		' Token: 0x06001A7C RID: 6780 RVA: 0x00147FF4 File Offset: 0x001461F4
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMLDCHI As frmDMLDCHI2 = New frmDMLDCHI2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMLDCHI2 As frmDMLDCHI2 = frmDMLDCHI
				frmDMLDCHI2.pbytFromStatus = 2
				frmDMLDCHI2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMLDCHI2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
				frmDMLDCHI2.txtOBJID.Text = ""
				Dim flag As Boolean = Me.mblnAutoAdd
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLDCHI_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMLDCHI.txtOBJID.Text = Strings.Right("0" + array(0).Value.ToString(), 2)
						frmDMLDCHI.txtOBJID.[ReadOnly] = True
						frmDMLDCHI.txtOBJID.BackColor = frmDMLDCHI.txtColor.BackColor
					End If
				End If
				frmDMLDCHI.ShowDialog()
				flag = frmDMLDCHI.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMLDCHI.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMLDCHI.Dispose()
			End Try
		End Sub

		' Token: 0x06001A7D RID: 6781 RVA: 0x001482BC File Offset: 0x001464BC
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMLDCHI As frmDMLDCHI2 = New frmDMLDCHI2()
			Dim flag As Boolean = False
			Try
				Dim flag2 As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag2 Then
					flag = True
				End If
				Dim frmDMLDCHI2 As frmDMLDCHI2 = frmDMLDCHI
				frmDMLDCHI2.pbytFromStatus = 3
				frmDMLDCHI2.pblnFix = flag
				frmDMLDCHI2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMLDCHI2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMLDCHI2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
				flag2 = flag
				If flag2 Then
					frmDMLDCHI2.txtOBJNAME.[ReadOnly] = True
					frmDMLDCHI2.txtOBJNAME.BackColor = frmDMLDCHI2.txtColor.BackColor
				End If
				frmDMLDCHI.ShowDialog()
				flag2 = frmDMLDCHI.pbytSuccess = 0
				If Not flag2 Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag2 = b = 0
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag2 = b <> 0
					If flag2 Then
						b = Me.fInitGrid()
					End If
					flag2 = b <> 0
					If flag2 Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMLDCHI.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMLDCHI.Dispose()
			End Try
		End Sub

		' Token: 0x06001A7E RID: 6782 RVA: 0x00148538 File Offset: 0x00146738
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMLDCHI As frmDMLDCHI2 = New frmDMLDCHI2()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
					frmDMLDCHI.Dispose()
				Else
					Dim frmDMLDCHI2 As frmDMLDCHI2 = frmDMLDCHI
					frmDMLDCHI2.pbytFromStatus = 4
					frmDMLDCHI2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMLDCHI2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMLDCHI2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
					frmDMLDCHI.ShowDialog()
					flag = frmDMLDCHI.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMLDCHI.Dispose()
			End Try
		End Sub

		' Token: 0x06001A7F RID: 6783 RVA: 0x0014876C File Offset: 0x0014696C
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMLDCHI As frmDMLDCHI2 = New frmDMLDCHI2()
			Try
				frmDMLDCHI.pbytFromStatus = 6
				frmDMLDCHI.ShowDialog()
				Dim flag As Boolean = frmDMLDCHI.pbytSuccess = 0
				If flag Then
					frmDMLDCHI.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMLDCHI.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMLDCHI.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMLDCHI.Dispose()
			End Try
		End Sub

		' Token: 0x06001A80 RID: 6784 RVA: 0x00148960 File Offset: 0x00146B60
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMLDCHI As frmDMLDCHI2 = New frmDMLDCHI2()
			Try
				Me.btnFindNext.Visible = False
				frmDMLDCHI.pbytFromStatus = 5
				frmDMLDCHI.ShowDialog()
				Dim flag As Boolean = frmDMLDCHI.pbytSuccess = 0
				If Not flag Then
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMLDCHI.pStrFilter
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMLDCHI.Dispose()
			End Try
		End Sub

		' Token: 0x06001A81 RID: 6785 RVA: 0x00148A68 File Offset: 0x00146C68
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMDVT As frmDMDVT2 = New frmDMDVT2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDVT.Dispose()
			End Try
		End Sub

		' Token: 0x06001A82 RID: 6786 RVA: 0x00148B30 File Offset: 0x00146D30
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x06001A83 RID: 6787 RVA: 0x00148CAC File Offset: 0x00146EAC
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fPrintDMLDCHI()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A84 RID: 6788 RVA: 0x00148D44 File Offset: 0x00146F44
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A85 RID: 6789 RVA: 0x00148DF4 File Offset: 0x00146FF4
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 160
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SUBOBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("SUBOBJNAME").Width = Me.Width - Me.grpControl.Width - 370
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("SUBOBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("FIXED").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001A86 RID: 6790 RVA: 0x00149060 File Offset: 0x00147260
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001A87 RID: 6791 RVA: 0x001491E0 File Offset: 0x001473E0
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLDCHI_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001A88 RID: 6792 RVA: 0x001492D0 File Offset: 0x001474D0
		Private Function fInitForm() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pintResult"
				array(0).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLN_SETPARA_GET_UPDATELIST", flag2)
				flag = flag2
				If flag Then
					Dim b2 As Byte = Conversions.ToByte(array(0).Value)
					Me.mblnAutoAdd = True
					flag = b2 = 3
					If flag Then
						b2 = 1
					Else
						flag = b2 = 2
						If flag Then
							b2 = 0
						Else
							Me.mblnAutoAdd = False
						End If
					End If
					b2 += Me.mBytOpen_FromMenu
					flag = b2 < 8
					If flag Then
						Me.btnAdd.Visible = False
						Me.btnAddDefault.Visible = False
						Me.btnModify.Visible = False
						Me.btnDelete.Visible = False
					End If
					b = 1
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001A89 RID: 6793 RVA: 0x0014950C File Offset: 0x0014770C
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(mdlVariable.gStrPathApp + "\DISPLAY\" + mdlVariable.gStrLanguage + "\frmDMLDCHI1.TXT")
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2040400000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001A8A RID: 6794 RVA: 0x001495E8 File Offset: 0x001477E8
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001A8B RID: 6795 RVA: 0x00149694 File Offset: 0x00147894
		Private Function fPrintDMLDCHI() As Byte
			Dim rptDMLDCHI As rptDMLDCHI = New rptDMLDCHI()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMLDCHI, "")
				Dim text As String = "2040400000"
				mdlReport.gsSetOfficeReport(rptDMLDCHI, text)
				mdlReport.gsSetFontReport(rptDMLDCHI)
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMLDCHI")
				rptDMLDCHI.SetDataSource(clsConnect)
				rptDMLDCHI.DataDefinition.FormulaFields("fInReasonCode").Text = "{dtReport.OBJID}"
				rptDMLDCHI.DataDefinition.FormulaFields("fInReasonName").Text = "{dtReport.OBJNAME}"
				mdlReport.gsSetTextReport(rptDMLDCHI, "RPTDMLDCHI")
				MyProject.Forms.frmReport.pSource = rptDMLDCHI
				MyProject.Forms.frmReport.MaximizeBox = True
				MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
				Dim textObject As TextObject = CType(rptDMLDCHI.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
				MyProject.Forms.frmReport.Text = textObject.Text
				rptDMLDCHI.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
				rptDMLDCHI.PrintOptions.PaperSize = PaperSize.PaperA4
				MyProject.Forms.frmReport.ShowDialog()
				MyProject.Forms.frmReport.pSource = Nothing
				clsConnect.Dispose()
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMLDCHI " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMLDCHI.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x04000AD3 RID: 2771
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000AD5 RID: 2773
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000AD6 RID: 2774
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000AD7 RID: 2775
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000AD8 RID: 2776
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000AD9 RID: 2777
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000ADA RID: 2778
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000ADB RID: 2779
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000ADC RID: 2780
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000ADD RID: 2781
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000ADE RID: 2782
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000ADF RID: 2783
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000AE0 RID: 2784
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000AE1 RID: 2785
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000AE2 RID: 2786
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000AE3 RID: 2787
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000AE4 RID: 2788
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000AE5 RID: 2789
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000AE6 RID: 2790
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000AE7 RID: 2791
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000AE8 RID: 2792
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000AE9 RID: 2793
		Private mArrStrFrmMess As String()

		' Token: 0x04000AEA RID: 2794
		Private mStrOBJID As String

		' Token: 0x04000AEB RID: 2795
		Private mStrOBJNAME As String

		' Token: 0x04000AEC RID: 2796
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000AED RID: 2797
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000AEE RID: 2798
		Private marrDrFind As DataRow()

		' Token: 0x04000AEF RID: 2799
		Private mintFindLastPos As Integer

		' Token: 0x04000AF0 RID: 2800
		Private mblnAutoAdd As Boolean
	End Class
End Namespace
