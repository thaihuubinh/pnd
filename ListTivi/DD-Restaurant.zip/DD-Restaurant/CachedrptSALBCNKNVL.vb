﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200032C RID: 812
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptSALBCNKNVL
		Inherits Component
		Implements ICachedReport

		' Token: 0x06007219 RID: 29209 RVA: 0x0001446B File Offset: 0x0001266B
		Public Sub New()
			CachedrptSALBCNKNVL.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002FEC RID: 12268
		' (get) Token: 0x0600721A RID: 29210 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x0600721B RID: 29211 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002FED RID: 12269
		' (get) Token: 0x0600721C RID: 29212 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x0600721D RID: 29213 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002FEE RID: 12270
		' (get) Token: 0x0600721E RID: 29214 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x0600721F RID: 29215 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06007220 RID: 29216 RVA: 0x004DF7C4 File Offset: 0x004DD9C4
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptSALBCNKNVL() With { .Site = Me.Site }
		End Function

		' Token: 0x06007221 RID: 29217 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002924 RID: 10532
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
