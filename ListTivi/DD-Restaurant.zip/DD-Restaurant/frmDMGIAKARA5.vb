﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200004D RID: 77
	<DesignerGenerated()>
	Public Partial Class frmDMGIAKARA5
		Inherits Form

		' Token: 0x06001500 RID: 5376 RVA: 0x000FF1F4 File Offset: 0x000FD3F4
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmDMGIAKARA5_Load
			frmDMGIAKARA5.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mStrFilter = ""
			Me.mStrOBJID = ""
			Me.mbytTIMEKIND = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000748 RID: 1864
		' (get) Token: 0x06001503 RID: 5379 RVA: 0x000FFF50 File Offset: 0x000FE150
		' (set) Token: 0x06001504 RID: 5380 RVA: 0x000051EC File Offset: 0x000033EC
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000749 RID: 1865
		' (get) Token: 0x06001505 RID: 5381 RVA: 0x000FFF68 File Offset: 0x000FE168
		' (set) Token: 0x06001506 RID: 5382 RVA: 0x000FFF80 File Offset: 0x000FE180
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700074A RID: 1866
		' (get) Token: 0x06001507 RID: 5383 RVA: 0x000FFFEC File Offset: 0x000FE1EC
		' (set) Token: 0x06001508 RID: 5384 RVA: 0x00100004 File Offset: 0x000FE204
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x1700074B RID: 1867
		' (get) Token: 0x06001509 RID: 5385 RVA: 0x00100070 File Offset: 0x000FE270
		' (set) Token: 0x0600150A RID: 5386 RVA: 0x000051F6 File Offset: 0x000033F6
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x1700074C RID: 1868
		' (get) Token: 0x0600150B RID: 5387 RVA: 0x00100088 File Offset: 0x000FE288
		' (set) Token: 0x0600150C RID: 5388 RVA: 0x00005200 File Offset: 0x00003400
		Friend Overridable Property lbMATK As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lbMATK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lbMATK = value
			End Set
		End Property

		' Token: 0x1700074D RID: 1869
		' (get) Token: 0x0600150D RID: 5389 RVA: 0x001000A0 File Offset: 0x000FE2A0
		' (set) Token: 0x0600150E RID: 5390 RVA: 0x0000520A File Offset: 0x0000340A
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x1700074E RID: 1870
		' (get) Token: 0x0600150F RID: 5391 RVA: 0x001000B8 File Offset: 0x000FE2B8
		' (set) Token: 0x06001510 RID: 5392 RVA: 0x00005214 File Offset: 0x00003414
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x1700074F RID: 1871
		' (get) Token: 0x06001511 RID: 5393 RVA: 0x001000D0 File Offset: 0x000FE2D0
		' (set) Token: 0x06001512 RID: 5394 RVA: 0x0000521E File Offset: 0x0000341E
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAME = value
			End Set
		End Property

		' Token: 0x17000750 RID: 1872
		' (get) Token: 0x06001513 RID: 5395 RVA: 0x001000E8 File Offset: 0x000FE2E8
		' (set) Token: 0x06001514 RID: 5396 RVA: 0x00100100 File Offset: 0x000FE300
		Friend Overridable Property txtPRICE As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPRICE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPRICE IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPRICE.KeyPress, AddressOf Me.txtPRICE_KeyPress1
				End If
				Me._txtPRICE = value
				flag = Me._txtPRICE IsNot Nothing
				If flag Then
					AddHandler Me._txtPRICE.KeyPress, AddressOf Me.txtPRICE_KeyPress1
				End If
			End Set
		End Property

		' Token: 0x17000751 RID: 1873
		' (get) Token: 0x06001515 RID: 5397 RVA: 0x0010016C File Offset: 0x000FE36C
		' (set) Token: 0x06001516 RID: 5398 RVA: 0x00005228 File Offset: 0x00003428
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJID = value
			End Set
		End Property

		' Token: 0x17000752 RID: 1874
		' (get) Token: 0x06001517 RID: 5399 RVA: 0x00100184 File Offset: 0x000FE384
		' (set) Token: 0x06001518 RID: 5400 RVA: 0x0010019C File Offset: 0x000FE39C
		Friend Overridable Property cmbType As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbType
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbType IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbType.TextChanged, AddressOf Me.cmbType_TextChanged
					RemoveHandler Me._cmbType.SelectedIndexChanged, AddressOf Me.cmbType_SelectedIndexChanged
				End If
				Me._cmbType = value
				flag = Me._cmbType IsNot Nothing
				If flag Then
					AddHandler Me._cmbType.TextChanged, AddressOf Me.cmbType_TextChanged
					AddHandler Me._cmbType.SelectedIndexChanged, AddressOf Me.cmbType_SelectedIndexChanged
				End If
			End Set
		End Property

		' Token: 0x17000753 RID: 1875
		' (get) Token: 0x06001519 RID: 5401 RVA: 0x00100238 File Offset: 0x000FE438
		' (set) Token: 0x0600151A RID: 5402 RVA: 0x00100250 File Offset: 0x000FE450
		Friend Overridable Property txtTimeFrom As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTimeFrom
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTimeFrom IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTimeFrom.KeyPress, AddressOf Me.txtTimeFrom_KeyPress1
				End If
				Me._txtTimeFrom = value
				flag = Me._txtTimeFrom IsNot Nothing
				If flag Then
					AddHandler Me._txtTimeFrom.KeyPress, AddressOf Me.txtTimeFrom_KeyPress1
				End If
			End Set
		End Property

		' Token: 0x17000754 RID: 1876
		' (get) Token: 0x0600151B RID: 5403 RVA: 0x001002BC File Offset: 0x000FE4BC
		' (set) Token: 0x0600151C RID: 5404 RVA: 0x00005232 File Offset: 0x00003432
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000755 RID: 1877
		' (get) Token: 0x0600151D RID: 5405 RVA: 0x001002D4 File Offset: 0x000FE4D4
		' (set) Token: 0x0600151E RID: 5406 RVA: 0x001002EC File Offset: 0x000FE4EC
		Friend Overridable Property txttimeTo As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txttimeTo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txttimeTo IsNot Nothing
				If flag Then
					RemoveHandler Me._txttimeTo.KeyPress, AddressOf Me.txttimeTo_KeyPress1
				End If
				Me._txttimeTo = value
				flag = Me._txttimeTo IsNot Nothing
				If flag Then
					AddHandler Me._txttimeTo.KeyPress, AddressOf Me.txttimeTo_KeyPress1
				End If
			End Set
		End Property

		' Token: 0x17000756 RID: 1878
		' (get) Token: 0x0600151F RID: 5407 RVA: 0x00100358 File Offset: 0x000FE558
		' (set) Token: 0x06001520 RID: 5408 RVA: 0x0000523C File Offset: 0x0000343C
		Friend Overridable Property Label4 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		' Token: 0x17000757 RID: 1879
		' (get) Token: 0x06001521 RID: 5409 RVA: 0x00100370 File Offset: 0x000FE570
		' (set) Token: 0x06001522 RID: 5410 RVA: 0x00100388 File Offset: 0x000FE588
		Friend Overridable Property txtLOTMM As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtLOTMM
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtLOTMM IsNot Nothing
				If flag Then
					RemoveHandler Me._txtLOTMM.KeyPress, AddressOf Me.txtLOTMM_KeyPress
				End If
				Me._txtLOTMM = value
				flag = Me._txtLOTMM IsNot Nothing
				If flag Then
					AddHandler Me._txtLOTMM.KeyPress, AddressOf Me.txtLOTMM_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000758 RID: 1880
		' (get) Token: 0x06001523 RID: 5411 RVA: 0x001003F4 File Offset: 0x000FE5F4
		' (set) Token: 0x06001524 RID: 5412 RVA: 0x00005246 File Offset: 0x00003446
		Friend Overridable Property txtPrice12 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPrice12
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtPrice12 = value
			End Set
		End Property

		' Token: 0x17000759 RID: 1881
		' (get) Token: 0x06001525 RID: 5413 RVA: 0x0010040C File Offset: 0x000FE60C
		' (set) Token: 0x06001526 RID: 5414 RVA: 0x00005250 File Offset: 0x00003450
		Friend Overridable Property Label5 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		' Token: 0x1700075A RID: 1882
		' (get) Token: 0x06001527 RID: 5415 RVA: 0x00100424 File Offset: 0x000FE624
		' (set) Token: 0x06001528 RID: 5416 RVA: 0x0000525A File Offset: 0x0000345A
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Me._mbdsSource = value
			End Set
		End Property

		' Token: 0x1700075B RID: 1883
		' (get) Token: 0x06001529 RID: 5417 RVA: 0x0010043C File Offset: 0x000FE63C
		' (set) Token: 0x0600152A RID: 5418 RVA: 0x00005264 File Offset: 0x00003464
		Public Property pbytTimeKind As Byte
			Get
				Return Me.mbytTIMEKIND
			End Get
			Set(value As Byte)
				Me.mbytTIMEKIND = value
			End Set
		End Property

		' Token: 0x1700075C RID: 1884
		' (get) Token: 0x0600152B RID: 5419 RVA: 0x00100454 File Offset: 0x000FE654
		' (set) Token: 0x0600152C RID: 5420 RVA: 0x0000526F File Offset: 0x0000346F
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x1700075D RID: 1885
		' (get) Token: 0x0600152D RID: 5421 RVA: 0x0010046C File Offset: 0x000FE66C
		' (set) Token: 0x0600152E RID: 5422 RVA: 0x0000527A File Offset: 0x0000347A
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x1700075E RID: 1886
		' (get) Token: 0x0600152F RID: 5423 RVA: 0x00100484 File Offset: 0x000FE684
		' (set) Token: 0x06001530 RID: 5424 RVA: 0x00005285 File Offset: 0x00003485
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x1700075F RID: 1887
		' (get) Token: 0x06001531 RID: 5425 RVA: 0x0010049C File Offset: 0x000FE69C
		' (set) Token: 0x06001532 RID: 5426 RVA: 0x00005290 File Offset: 0x00003490
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x06001533 RID: 5427 RVA: 0x001004B4 File Offset: 0x000FE6B4
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(5))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(6))
					Case 4
						Me.btnSave.Tag = "CR0004"
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(7))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				Me.txtOBJID.Focus()
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return b
		End Function

		' Token: 0x06001534 RID: 5428 RVA: 0x00100618 File Offset: 0x000FE818
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001535 RID: 5429 RVA: 0x001006AC File Offset: 0x000FE8AC
		Private Sub frmDMGIAKARA5_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim items As ComboBox.ObjectCollection = Me.cmbType.Items
				items.Add(Me.mArrStrFrmMess(31))
				items.Add(Me.mArrStrFrmMess(21))
				items.Add(Me.mArrStrFrmMess(22))
				items.Add(Me.mArrStrFrmMess(23))
				items.Add(Me.mArrStrFrmMess(32))
				Me.cmbType.SelectedIndex = CInt(Me.mbytTIMEKIND)
				Me.fInitForm()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, "frmSETTING_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001536 RID: 5430 RVA: 0x001007B0 File Offset: 0x000FE9B0
		Private Function fInitForm() As Byte
			Me.txtOBJNAME.MaxLength = 100
			Me.txtPRICE.MaxLength = 9
			Me.txtOBJID.Enabled = False
			Me.txtOBJID.BackColor = Color.FromArgb(255, 255, 192)
			Dim flag As Boolean = Me.mbytFormStatus = 1
			If Not flag Then
				flag = Me.mbytFormStatus = 3
				If flag Then
					Me.txtOBJID.Enabled = False
					Me.txtOBJID.BackColor = Color.FromArgb(255, 255, 192)
				Else
					flag = Me.mbytFormStatus = 4
					If flag Then
						Me.txtOBJNAME.Enabled = False
						Me.txtOBJNAME.BackColor = Color.FromArgb(255, 255, 192)
						Me.txtPRICE.Enabled = False
						Me.txtPRICE.BackColor = Color.FromArgb(255, 255, 192)
						Me.txtTimeFrom.Enabled = False
						Me.txtTimeFrom.BackColor = Color.FromArgb(255, 255, 192)
						Me.txttimeTo.Enabled = False
						Me.txttimeTo.BackColor = Color.FromArgb(255, 255, 192)
						Me.txtLOTMM.Enabled = False
						Me.txtLOTMM.BackColor = Color.FromArgb(255, 255, 192)
						Me.cmbType.Enabled = False
						Me.cmbType.BackColor = Color.FromArgb(255, 255, 192)
					End If
				End If
			End If
			Dim b As Byte
			Return b
		End Function

		' Token: 0x06001537 RID: 5431 RVA: 0x00002DF4 File Offset: 0x00000FF4
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub

		' Token: 0x06001538 RID: 5432 RVA: 0x00100978 File Offset: 0x000FEB78
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Operators.CompareString(Me.txtOBJID.Text, "", False) = 0
			If flag Then
				Interaction.MsgBox(Me.mArrStrFrmMess(8), MsgBoxStyle.Critical, Nothing)
			Else
				flag = Operators.CompareString(Me.txtOBJNAME.Text, "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(9), MsgBoxStyle.Critical, Nothing)
				Else
					flag = Operators.CompareString(Me.txtPRICE.Text, "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(10), MsgBoxStyle.Critical, Nothing)
					Else
						flag = Conversion.Val(Me.txtLOTMM.Text) <= 0.0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
							Me.txtLOTMM.Focus()
						Else
							flag = Me.mbytFormStatus = 1
							If flag Then
								Me.fAddNew()
							Else
								flag = Me.mbytFormStatus = 3
								If flag Then
									Me.fModify()
								Else
									flag = Me.mbytFormStatus = 4
									If flag Then
										Me.fDelete()
									End If
								End If
							End If
							Me.Close()
						End If
					End If
				End If
			End If
		End Sub

		' Token: 0x06001539 RID: 5433 RVA: 0x00100AB4 File Offset: 0x000FECB4
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(10) {}
			Dim b As Byte
			Try
				Dim num As Double = Conversions.ToDouble(Me.txtPRICE.Text)
				Dim text As String = Me.cmbType.Text
				Dim flag As Boolean = Operators.CompareString(text, Me.mArrStrFrmMess(31), False) = 0
				Dim num2 As Integer
				If flag Then
					num2 = 0
					num = Math.Round(Conversion.Val(Me.txtPRICE.Text) / 60.0, 2)
				Else
					flag = Operators.CompareString(text, Me.mArrStrFrmMess(21), False) = 0
					If flag Then
						num2 = 1
					Else
						flag = Operators.CompareString(text, Me.mArrStrFrmMess(22), False) = 0
						If flag Then
							num2 = 2
						Else
							flag = Operators.CompareString(text, Me.mArrStrFrmMess(23), False) = 0
							If flag Then
								num2 = 3
							Else
								flag = Operators.CompareString(text, Me.mArrStrFrmMess(32), False) = 0
								If flag Then
									num2 = 4
								End If
							End If
						End If
					End If
				End If
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcOBJNAME"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@PNCHMAGIAKARA"
				array(2).Value = Strings.Trim(Me.mStrOBJID)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@PDECPRICE"
				array(3).Value = num
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@PTINTIMEKIND"
				array(4).Value = num2
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@decTIMEFROM"
				array(5).Value = Me.txtTimeFrom.Text
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@decTIMETO"
				array(6).Value = Me.txttimeTo.Text
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@int_Result"
				array(7).Direction = ParameterDirection.ReturnValue
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@intLOTMM"
				array(8).Value = Conversion.Val(Me.txtLOTMM.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@PDECPRICE12"
				array(9).Value = Conversion.Val(Me.txtPrice12.Text)
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "INSERT_DATA_DMGIAKARA2", flag2)
				Dim num3 As Integer = Conversions.ToInteger(array(7).Value)
				flag = num3 = 0
				If flag Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag = num3 = 1
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
					Else
						flag = num3 = 2
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						Else
							flag = num3 = 3
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(34), MsgBoxStyle.Critical, Nothing)
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600153A RID: 5434 RVA: 0x00100F1C File Offset: 0x000FF11C
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(10) {}
			Dim b As Byte
			Try
				Dim num As Double = Conversions.ToDouble(Me.txtPRICE.Text)
				Dim text As String = Me.cmbType.Text
				Dim flag As Boolean = Operators.CompareString(text, Me.mArrStrFrmMess(31), False) = 0
				Dim num2 As Integer
				If flag Then
					num2 = 0
					num = Math.Round(Conversion.Val(Me.txtPRICE.Text) / 60.0, 2)
				Else
					flag = Operators.CompareString(text, Me.mArrStrFrmMess(21), False) = 0
					If flag Then
						num2 = 1
					Else
						flag = Operators.CompareString(text, Me.mArrStrFrmMess(22), False) = 0
						If flag Then
							num2 = 2
						Else
							flag = Operators.CompareString(text, Me.mArrStrFrmMess(23), False) = 0
							If flag Then
								num2 = 3
							Else
								flag = Operators.CompareString(text, Me.mArrStrFrmMess(32), False) = 0
								If flag Then
									num2 = 4
								End If
							End If
						End If
					End If
				End If
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcOBJNAME"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@PNCHMAGIAKARA"
				array(2).Value = Strings.Trim(Me.mStrOBJID)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@PDECPRICE"
				array(3).Value = num
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@PTINTIMEKIND"
				array(4).Value = num2
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@decTIMEFROM"
				array(5).Value = Me.txtTimeFrom.Text
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@decTIMETO"
				array(6).Value = Me.txttimeTo.Text
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@int_Result"
				array(7).Direction = ParameterDirection.ReturnValue
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@intLOTMM"
				array(8).Value = Conversion.Val(Me.txtLOTMM.Text)
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@PDECPRICE12"
				array(9).Value = Conversion.Val(Me.txtPrice12.Text)
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "UPDATE_DATA_DMGIAKARA2", flag2)
				Dim num3 As Integer = Conversions.ToInteger(array(7).Value)
				flag = num3 = 0
				If flag Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag = num3 = 1
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						flag = num3 = 2
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						Else
							flag = num3 = 3
							If flag Then
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600153B RID: 5435 RVA: 0x0010136C File Offset: 0x000FF56C
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				Dim text As String = Me.cmbType.Text
				Dim flag As Boolean = Operators.CompareString(text, Me.mArrStrFrmMess(31), False) = 0
				If Not flag Then
					flag = Operators.CompareString(text, Me.mArrStrFrmMess(21), False) = 0
					If Not flag Then
						flag = Operators.CompareString(text, Me.mArrStrFrmMess(22), False) = 0
						If Not flag Then
							flag = Operators.CompareString(text, Me.mArrStrFrmMess(23), False) = 0
							If flag Then
							End If
						End If
					End If
				End If
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@PNCHMAGIAKARA"
				array(0).Value = Strings.Trim(Me.mStrOBJID)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@PNCHOBJID"
				array(1).Value = Strings.Trim(Me.txtOBJID.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "DELETE_DATA_DMGIAKARA2", flag2)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				flag = num = 0
				If flag Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag = num = 1
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						flag = num = 2
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						Else
							flag = num = 3
							If flag Then
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600153C RID: 5436 RVA: 0x001015FC File Offset: 0x000FF7FC
		Private Sub txtPRICE_KeyPress1(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txtTimeFrom.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtPRICE_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600153D RID: 5437 RVA: 0x00101798 File Offset: 0x000FF998
		Private Sub txtLOTMM_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txtTimeFrom.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtLOTMM_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600153E RID: 5438 RVA: 0x00101934 File Offset: 0x000FFB34
		Private Sub txtTimeFrom_KeyPress1(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txttimeTo.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTimeFrom_KeyPress1 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600153F RID: 5439 RVA: 0x00101AD0 File Offset: 0x000FFCD0
		Private Sub txttimeTo_KeyPress1(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.btnSave.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txttimeTo_KeyPress1 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001540 RID: 5440 RVA: 0x00101C6C File Offset: 0x000FFE6C
		Private Sub cmbType_SelectedIndexChanged(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.cmbType.SelectedIndex = 1
			If flag Then
				Me.txtLOTMM.Visible = True
			Else
				Me.txtLOTMM.Visible = False
			End If
			flag = Me.cmbType.SelectedIndex = 2
			If flag Then
				Me.txtPrice12.Visible = True
				Me.Label5.Visible = True
			Else
				Me.txtPrice12.Visible = False
				Me.Label5.Visible = False
			End If
		End Sub

		' Token: 0x06001541 RID: 5441 RVA: 0x00101C6C File Offset: 0x000FFE6C
		Private Sub cmbType_TextChanged(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.cmbType.SelectedIndex = 1
			If flag Then
				Me.txtLOTMM.Visible = True
			Else
				Me.txtLOTMM.Visible = False
			End If
			flag = Me.cmbType.SelectedIndex = 2
			If flag Then
				Me.txtPrice12.Visible = True
				Me.Label5.Visible = True
			Else
				Me.txtPrice12.Visible = False
				Me.Label5.Visible = False
			End If
		End Sub

		' Token: 0x040008B6 RID: 2230
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040008B8 RID: 2232
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x040008B9 RID: 2233
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040008BA RID: 2234
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x040008BB RID: 2235
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040008BC RID: 2236
		<AccessedThroughProperty("lbMATK")>
		Private _lbMATK As Label

		' Token: 0x040008BD RID: 2237
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x040008BE RID: 2238
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x040008BF RID: 2239
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x040008C0 RID: 2240
		<AccessedThroughProperty("txtPRICE")>
		Private _txtPRICE As TextBox

		' Token: 0x040008C1 RID: 2241
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x040008C2 RID: 2242
		<AccessedThroughProperty("cmbType")>
		Private _cmbType As ComboBox

		' Token: 0x040008C3 RID: 2243
		<AccessedThroughProperty("txtTimeFrom")>
		Private _txtTimeFrom As TextBox

		' Token: 0x040008C4 RID: 2244
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x040008C5 RID: 2245
		<AccessedThroughProperty("txttimeTo")>
		Private _txttimeTo As TextBox

		' Token: 0x040008C6 RID: 2246
		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		' Token: 0x040008C7 RID: 2247
		<AccessedThroughProperty("txtLOTMM")>
		Private _txtLOTMM As TextBox

		' Token: 0x040008C8 RID: 2248
		<AccessedThroughProperty("txtPrice12")>
		Private _txtPrice12 As TextBox

		' Token: 0x040008C9 RID: 2249
		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		' Token: 0x040008CA RID: 2250
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040008CB RID: 2251
		Private mArrStrFrmMess As String()

		' Token: 0x040008CC RID: 2252
		Private mbytFormStatus As Byte

		' Token: 0x040008CD RID: 2253
		Private mbytSuccess As Byte

		' Token: 0x040008CE RID: 2254
		Private mStrFilter As String

		' Token: 0x040008CF RID: 2255
		Private mStrOBJID As String

		' Token: 0x040008D0 RID: 2256
		Private mbytTIMEKIND As Byte
	End Class
End Namespace
