﻿Namespace prjIS_SalesPOS
	' Token: 0x02000032 RID: 50
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDanhSachThuChi
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000A93 RID: 2707 RVA: 0x0007CC58 File Offset: 0x0007AE58
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000A94 RID: 2708 RVA: 0x0007CC90 File Offset: 0x0007AE90
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDanhSachThuChi))
			Me.btnPreview = New Global.System.Windows.Forms.Button()
			Me.grpControl = New Global.System.Windows.Forms.GroupBox()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.dgvData = New Global.System.Windows.Forms.DataGridView()
			Me.lblFilterDate = New Global.System.Windows.Forms.Label()
			Me.btnCancel = New Global.System.Windows.Forms.Button()
			Me.mtxDATE = New Global.System.Windows.Forms.MaskedTextBox()
			Me.dtpTuNgay = New Global.System.Windows.Forms.DateTimePicker()
			Me.grpControl.SuspendLayout()
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.btnPreview.Image = Global.prjIS_SalesPOS.My.Resources.Resources._in
			Dim btnPreview As Global.System.Windows.Forms.Control = Me.btnPreview
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(372, 15)
			btnPreview.Location = point
			Me.btnPreview.Name = "btnPreview"
			Dim btnPreview2 As Global.System.Windows.Forms.Control = Me.btnPreview
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(80, 42)
			btnPreview2.Size = size
			Me.btnPreview.TabIndex = 7
			Me.btnPreview.Tag = "CR0012"
			Me.btnPreview.Text = "In"
			Me.btnPreview.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnPreview.UseVisualStyleBackColor = True
			Me.grpControl.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom
			Me.grpControl.Controls.Add(Me.btnDelete)
			Me.grpControl.Controls.Add(Me.btnExit)
			Me.grpControl.Controls.Add(Me.btnPreview)
			Dim grpControl As Global.System.Windows.Forms.Control = Me.grpControl
			point = New Global.System.Drawing.Point(4, 385)
			grpControl.Location = point
			Me.grpControl.Name = "grpControl"
			Dim grpControl2 As Global.System.Windows.Forms.Control = Me.grpControl
			size = New Global.System.Drawing.Size(647, 63)
			grpControl2.Size = size
			Me.grpControl.TabIndex = 2
			Me.grpControl.TabStop = False
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(465, 15)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(80, 42)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 13
			Me.btnDelete.Tag = "CR0007"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(561, 15)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(80, 42)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 12
			Me.btnExit.Tag = "CR0003"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.dgvData.AllowUserToAddRows = False
			Me.dgvData.AllowUserToDeleteRows = False
			Me.dgvData.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvData.BackgroundColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvData.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvData As Global.System.Windows.Forms.Control = Me.dgvData
			point = New Global.System.Drawing.Point(0, 37)
			dgvData.Location = point
			Me.dgvData.Name = "dgvData"
			Me.dgvData.[ReadOnly] = True
			Dim dgvData2 As Global.System.Windows.Forms.Control = Me.dgvData
			size = New Global.System.Drawing.Size(655, 342)
			dgvData2.Size = size
			Me.dgvData.TabIndex = 1
			Me.lblFilterDate.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFilterDate As Global.System.Windows.Forms.Control = Me.lblFilterDate
			point = New Global.System.Drawing.Point(12, 9)
			lblFilterDate.Location = point
			Me.lblFilterDate.Name = "lblFilterDate"
			Dim lblFilterDate2 As Global.System.Windows.Forms.Control = Me.lblFilterDate
			size = New Global.System.Drawing.Size(174, 21)
			lblFilterDate2.Size = size
			Me.lblFilterDate.TabIndex = 43
			Me.lblFilterDate.Tag = "CR0017"
			Me.lblFilterDate.Text = "Đang được lọc theo ngày:"
			Me.btnCancel.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btnCancel As Global.System.Windows.Forms.Control = Me.btnCancel
			point = New Global.System.Drawing.Point(325, 5)
			btnCancel.Location = point
			Me.btnCancel.Name = "btnCancel"
			Dim btnCancel2 As Global.System.Windows.Forms.Control = Me.btnCancel
			size = New Global.System.Drawing.Size(33, 30)
			btnCancel2.Size = size
			Me.btnCancel.TabIndex = 4
			Me.btnCancel.Tag = "N0015B0016"
			Me.btnCancel.Text = "X"
			Me.btnCancel.UseVisualStyleBackColor = True
			Me.mtxDATE.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim mtxDATE As Global.System.Windows.Forms.Control = Me.mtxDATE
			point = New Global.System.Drawing.Point(192, 6)
			mtxDATE.Location = point
			Me.mtxDATE.Mask = "00/00/0000"
			Me.mtxDATE.Name = "mtxDATE"
			Me.mtxDATE.PromptChar = "-"c
			Dim mtxDATE2 As Global.System.Windows.Forms.Control = Me.mtxDATE
			size = New Global.System.Drawing.Size(113, 30)
			mtxDATE2.Size = size
			Me.mtxDATE.TabIndex = 44
			Me.mtxDATE.Tag = "N0015B0000"
			Me.mtxDATE.ValidatingType = GetType(Global.System.DateTime)
			Me.dtpTuNgay.Font = New Global.System.Drawing.Font("Arial", 15.5F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim dtpTuNgay As Global.System.Windows.Forms.Control = Me.dtpTuNgay
			point = New Global.System.Drawing.Point(302, 5)
			dtpTuNgay.Location = point
			Me.dtpTuNgay.Name = "dtpTuNgay"
			Dim dtpTuNgay2 As Global.System.Windows.Forms.Control = Me.dtpTuNgay
			size = New Global.System.Drawing.Size(20, 31)
			dtpTuNgay2.Size = size
			Me.dtpTuNgay.TabIndex = 45
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(655, 460)
			Me.ClientSize = size
			Me.Controls.Add(Me.dtpTuNgay)
			Me.Controls.Add(Me.mtxDATE)
			Me.Controls.Add(Me.lblFilterDate)
			Me.Controls.Add(Me.btnCancel)
			Me.Controls.Add(Me.dgvData)
			Me.Controls.Add(Me.grpControl)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmDanhSachThuChi"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Danh sách thu chi"
			Me.grpControl.ResumeLayout(False)
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x040004A9 RID: 1193
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
