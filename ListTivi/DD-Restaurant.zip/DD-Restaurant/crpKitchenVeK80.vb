﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x02000113 RID: 275
	Public Class crpKitchenVeK80
		Inherits ReportClass

		' Token: 0x060056D7 RID: 22231 RVA: 0x0000EE6A File Offset: 0x0000D06A
		Public Sub New()
			crpKitchenVeK80.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001F25 RID: 7973
		' (get) Token: 0x060056D8 RID: 22232 RVA: 0x004DADC8 File Offset: 0x004D8FC8
		' (set) Token: 0x060056D9 RID: 22233 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crpKitchenVeK80.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001F26 RID: 7974
		' (get) Token: 0x060056DA RID: 22234 RVA: 0x004DA738 File Offset: 0x004D8938
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsLogo As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001F27 RID: 7975
		' (get) Token: 0x060056DB RID: 22235 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property phsTieude1 As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001F28 RID: 7976
		' (get) Token: 0x060056DC RID: 22236 RVA: 0x004DA780 File Offset: 0x004D8980
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dsDVTTEN As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001F29 RID: 7977
		' (get) Token: 0x060056DD RID: 22237 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property sNgay2 As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001F2A RID: 7978
		' (get) Token: 0x060056DE RID: 22238 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x0400270B RID: 9995
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
