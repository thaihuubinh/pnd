﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000063 RID: 99
	<DesignerGenerated()>
	Public Partial Class frmDMMAYINBEPKHU
		Inherits Form

		' Token: 0x06001F0F RID: 7951 RVA: 0x00180EC8 File Offset: 0x0017F0C8
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMBP2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMBP2_Load
			frmDMMAYINBEPKHU.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mbytAllData = 0
			Me.mbtySingle = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000AAE RID: 2734
		' (get) Token: 0x06001F12 RID: 7954 RVA: 0x001816D4 File Offset: 0x0017F8D4
		' (set) Token: 0x06001F13 RID: 7955 RVA: 0x000066D9 File Offset: 0x000048D9
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x17000AAF RID: 2735
		' (get) Token: 0x06001F14 RID: 7956 RVA: 0x001816EC File Offset: 0x0017F8EC
		' (set) Token: 0x06001F15 RID: 7957 RVA: 0x00181704 File Offset: 0x0017F904
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000AB0 RID: 2736
		' (get) Token: 0x06001F16 RID: 7958 RVA: 0x00181770 File Offset: 0x0017F970
		' (set) Token: 0x06001F17 RID: 7959 RVA: 0x00181788 File Offset: 0x0017F988
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x17000AB1 RID: 2737
		' (get) Token: 0x06001F18 RID: 7960 RVA: 0x001817F4 File Offset: 0x0017F9F4
		' (set) Token: 0x06001F19 RID: 7961 RVA: 0x0018180C File Offset: 0x0017FA0C
		Friend Overridable Property btnThemAll As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnThemAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnThemAll IsNot Nothing
				If flag Then
					RemoveHandler Me._btnThemAll.Click, AddressOf Me.btnThemAll_Click
				End If
				Me._btnThemAll = value
				flag = Me._btnThemAll IsNot Nothing
				If flag Then
					AddHandler Me._btnThemAll.Click, AddressOf Me.btnThemAll_Click
				End If
			End Set
		End Property

		' Token: 0x17000AB2 RID: 2738
		' (get) Token: 0x06001F1A RID: 7962 RVA: 0x00181878 File Offset: 0x0017FA78
		' (set) Token: 0x06001F1B RID: 7963 RVA: 0x00181890 File Offset: 0x0017FA90
		Friend Overridable Property btnThem1MH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnThem1MH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnThem1MH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnThem1MH.Click, AddressOf Me.btnThem1MH_Click
				End If
				Me._btnThem1MH = value
				flag = Me._btnThem1MH IsNot Nothing
				If flag Then
					AddHandler Me._btnThem1MH.Click, AddressOf Me.btnThem1MH_Click
				End If
			End Set
		End Property

		' Token: 0x17000AB3 RID: 2739
		' (get) Token: 0x06001F1C RID: 7964 RVA: 0x001818FC File Offset: 0x0017FAFC
		' (set) Token: 0x06001F1D RID: 7965 RVA: 0x00181914 File Offset: 0x0017FB14
		Friend Overridable Property btnGobo As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnGobo
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnGobo IsNot Nothing
				If flag Then
					RemoveHandler Me._btnGobo.Click, AddressOf Me.btnGobo_Click
				End If
				Me._btnGobo = value
				flag = Me._btnGobo IsNot Nothing
				If flag Then
					AddHandler Me._btnGobo.Click, AddressOf Me.btnGobo_Click
				End If
			End Set
		End Property

		' Token: 0x17000AB4 RID: 2740
		' (get) Token: 0x06001F1E RID: 7966 RVA: 0x00181980 File Offset: 0x0017FB80
		' (set) Token: 0x06001F1F RID: 7967 RVA: 0x000066E3 File Offset: 0x000048E3
		Friend Overridable Property lstHanghoaThemAll As ListBox
			<DebuggerNonUserCode()>
			Get
				Return Me._lstHanghoaThemAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Me._lstHanghoaThemAll = value
			End Set
		End Property

		' Token: 0x17000AB5 RID: 2741
		' (get) Token: 0x06001F20 RID: 7968 RVA: 0x00181998 File Offset: 0x0017FB98
		' (set) Token: 0x06001F21 RID: 7969 RVA: 0x000066ED File Offset: 0x000048ED
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000AB6 RID: 2742
		' (get) Token: 0x06001F22 RID: 7970 RVA: 0x001819B0 File Offset: 0x0017FBB0
		' (set) Token: 0x06001F23 RID: 7971 RVA: 0x000066F7 File Offset: 0x000048F7
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Me._mbdsSource = value
			End Set
		End Property

		' Token: 0x17000AB7 RID: 2743
		' (get) Token: 0x06001F24 RID: 7972 RVA: 0x001819C8 File Offset: 0x0017FBC8
		' (set) Token: 0x06001F25 RID: 7973 RVA: 0x00006701 File Offset: 0x00004901
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x17000AB8 RID: 2744
		' (get) Token: 0x06001F26 RID: 7974 RVA: 0x001819E0 File Offset: 0x0017FBE0
		' (set) Token: 0x06001F27 RID: 7975 RVA: 0x0000670C File Offset: 0x0000490C
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x17000AB9 RID: 2745
		' (get) Token: 0x06001F28 RID: 7976 RVA: 0x001819F8 File Offset: 0x0017FBF8
		' (set) Token: 0x06001F29 RID: 7977 RVA: 0x00006717 File Offset: 0x00004917
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x17000ABA RID: 2746
		' (get) Token: 0x06001F2A RID: 7978 RVA: 0x00181A10 File Offset: 0x0017FC10
		' (set) Token: 0x06001F2B RID: 7979 RVA: 0x00006722 File Offset: 0x00004922
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000ABB RID: 2747
		' (get) Token: 0x06001F2C RID: 7980 RVA: 0x00181A28 File Offset: 0x0017FC28
		' (set) Token: 0x06001F2D RID: 7981 RVA: 0x0000672D File Offset: 0x0000492D
		Public Property pStrMAHHSALE As String
			Get
				Return Me.mStrMAHHSALE
			End Get
			Set(value As String)
				Me.mStrMAHHSALE = value
			End Set
		End Property

		' Token: 0x17000ABC RID: 2748
		' (get) Token: 0x06001F2E RID: 7982 RVA: 0x00181A40 File Offset: 0x0017FC40
		' (set) Token: 0x06001F2F RID: 7983 RVA: 0x00006738 File Offset: 0x00004938
		Public Property pStrMAHHSUR As String
			Get
				Return Me.mStrMAHHSUR
			End Get
			Set(value As String)
				Me.mStrMAHHSUR = value
			End Set
		End Property

		' Token: 0x06001F30 RID: 7984 RVA: 0x00181A58 File Offset: 0x0017FC58
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001F31 RID: 7985 RVA: 0x00181AE4 File Offset: 0x0017FCE4
		Private Sub frmDMBP2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F32 RID: 7986 RVA: 0x00181B7C File Offset: 0x0017FD7C
		Private Sub frmDMBP2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				Me.mbytFlag = 4
				Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKHU")
				Me.fGetData_4ListBox()
				flag = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F33 RID: 7987 RVA: 0x00181C60 File Offset: 0x0017FE60
		Private Sub btnGobo_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytFlag = 3
				Me.fGetData_4ListBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnGobo_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001F34 RID: 7988 RVA: 0x00181CF4 File Offset: 0x0017FEF4
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Me.sAdd()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F35 RID: 7989 RVA: 0x00181D94 File Offset: 0x0017FF94
		Private Sub btnThemAll_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytFlag = 1
				Me.fGetData_4ListBox()
				Me.sAdd()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnThemAll_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001F36 RID: 7990 RVA: 0x00181E2C File Offset: 0x0018002C
		Private Sub btnThem1MH_Click(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim frmDMKHU As frmDMKHU1 = New frmDMKHU1()
				frmDMKHU.pBytOpen_From_Menu = 7
				frmDMKHU.ShowDialog()
				Dim flag As Boolean = Operators.CompareString(frmDMKHU.pStrOBJID, "", False) = 0
				If flag Then
					frmDMKHU.Dispose()
				Else
					Me.mstrMAHH = frmDMKHU.pStrOBJID
					Me.mbytSuccess = Me.fAddNew(Strings.Trim(Me.mstrMAHH), Me.mStrOBJID)
					Me.mbytFlag = 4
					Me.fGetData_4ListBox()
					Me.sRefesh_ListBox()
					frmDMKHU.Dispose()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnThem1MH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F37 RID: 7991 RVA: 0x00181F48 File Offset: 0x00180148
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 4
						Me.sDisplay_Moddelete()
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001F38 RID: 7992 RVA: 0x00182010 File Offset: 0x00180210
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnSave.Enabled = True
				Me.btnExit.Enabled = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return b
		End Function

		' Token: 0x06001F39 RID: 7993 RVA: 0x001820B4 File Offset: 0x001802B4
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.lstHanghoaThemAll.SelectionMode = SelectionMode.MultiSimple
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001F3A RID: 7994 RVA: 0x0018216C File Offset: 0x0018036C
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(5))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(6))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(7))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return b
		End Function

		' Token: 0x06001F3B RID: 7995 RVA: 0x001822B4 File Offset: 0x001804B4
		Private Sub sClear_Form()
			Try
				Me.mclsTBHHThemAll.Dispose()
				Me.mclsTemp.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001F3C RID: 7996 RVA: 0x00182360 File Offset: 0x00180560
		Private Function fAddNew(pstrMAKHU As String, pstrMAMAYINBEP As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nchMAKHU"
				array(0).Value = pstrMAKHU
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nchMAMAYINBEP"
				array(1).Value = pstrMAMAYINBEP
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_DMMAYINBEPKHU_INSERT", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(8), MsgBoxStyle.Critical, Nothing)
						Me.btnExit.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(9), MsgBoxStyle.Critical, Nothing)
							Me.btnExit.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001F3D RID: 7997 RVA: 0x00182534 File Offset: 0x00180734
		Private Function fModify(pstrMAMAYINBEP As String, pstrMAKHU As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(3) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nchMAMAYINBEP"
				array(0).Value = pstrMAMAYINBEP
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nchMAKHU"
				array(1).Value = pstrMAKHU
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@int_Result"
				array(2).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_DMMAYINBEPKHU_DELETE", flag)
				Dim num As Integer = Conversions.ToInteger(array(2).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001F3E RID: 7998 RVA: 0x001826BC File Offset: 0x001808BC
		Private Function fDELETE_ALL() As Object
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim obj As Object
			Try
				obj = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@int_Result"
				array(0).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMGIAKARA3_DELETE_ALL", flag)
				Dim num As Integer = Conversions.ToInteger(array(0).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					obj = 1
				End If
			Catch ex As Exception
				obj = False
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return obj
		End Function

		' Token: 0x06001F3F RID: 7999 RVA: 0x001827F0 File Offset: 0x001809F0
		Private Function fGetData_4ListBox() As Byte
			' The following expression was wrapped in a checked-statement
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = Me.mbytFlag = 1
				If flag Then
					Me.mclsTBHHThemAll = Nothing
					Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKHU")
					Me.sRefesh_ListBox()
				Else
					flag = Me.mbytFlag = 4
					If flag Then
						Dim clsConnect As clsConnect = New clsConnect()
						Dim sqlCommand As SqlCommand = New SqlCommand()
						Dim array As SqlParameter() = New SqlParameter(1) {}
						array(0) = sqlCommand.CreateParameter()
						array(0).ParameterName = "@nchMAMAYINBEP"
						array(0).Value = Strings.Trim(Me.mStrOBJID)
						Me.mclsTBHHThemAll = Nothing
						Dim num As Integer
						Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_DMMAYINBEPKHU_GETDATA", num)
						Me.sRefesh_ListBox()
					Else
						flag = Me.mbytFlag = 3
						If flag Then
							Dim flag2 As Boolean = False
							Dim num2 As Integer = 0
							Dim num3 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
							Dim num4 As Integer = num2
							While True
								Dim num5 As Integer = num4
								Dim num6 As Integer = num3
								If num5 > num6 Then
									GoTo IL_0112
								End If
								flag = Me.lstHanghoaThemAll.GetSelected(num4)
								If flag Then
									Exit For
								End If
								num4 += 1
							End While
							flag2 = True
							IL_0112:
							flag = flag2
							If flag Then
								Try
									Dim num7 As Integer = 0
									Dim num8 As Integer = 0
									Dim num9 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
									num4 = num8
									While True
										Dim num10 As Integer = num4
										Dim num6 As Integer = num9
										If num10 > num6 Then
											Exit For
										End If
										flag = Me.lstHanghoaThemAll.GetSelected(num4)
										If flag Then
											num7 += 1
										End If
										num4 += 1
									End While
									Dim array2 As DataRow() = New DataRow(num7 + 1 - 1) {}
									num7 = 0
									Dim num11 As Integer = 0
									Dim num12 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
									num4 = num11
									While True
										Dim num13 As Integer = num4
										Dim num6 As Integer = num12
										If num13 > num6 Then
											Exit For
										End If
										flag = Me.lstHanghoaThemAll.GetSelected(num4)
										If flag Then
											Dim dataRowView As DataRowView = CType(Me.lstHanghoaThemAll.Items(num4), DataRowView)
											Dim row As DataRow = dataRowView.Row
											array2(num7) = row
											num7 += 1
										End If
										num4 += 1
									End While
									Dim num14 As Integer = 0
									Dim num15 As Integer = Me.lstHanghoaThemAll.SelectedItems.Count - 1
									Dim num16 As Integer = num14
									While True
										Dim num17 As Integer = num16
										Dim num6 As Integer = num15
										If num17 > num6 Then
											Exit For
										End If
										Dim text As String = Conversions.ToString(NewLateBinding.LateIndexGet(Me.lstHanghoaThemAll.SelectedItems(num16), New Object() { "OBJID" }, Nothing))
										Me.fModify(Me.mStrOBJID, text)
										num16 += 1
									End While
									Dim num18 As Integer = 0
									Dim num19 As Integer = num7
									num4 = num18
									While True
										Dim num20 As Integer = num4
										Dim num6 As Integer = num19
										If num20 > num6 Then
											Exit For
										End If
										Me.mclsTBHHThemAll.Rows.Remove(array2(num4))
										num4 += 1
									End While
								Catch ex As Exception
								End Try
								Me.mbytFlag = 4
								Me.fGetData_4ListBox()
								Me.sRefesh_ListBox()
							End If
						End If
					End If
				End If
				b = 1
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4ListBox ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001F40 RID: 8000 RVA: 0x00182B64 File Offset: 0x00180D64
		Private Sub sRefesh_ListBox()
			Try
				Dim lstHanghoaThemAll As ListBox = Me.lstHanghoaThemAll
				lstHanghoaThemAll.DataSource = Me.mclsTBHHThemAll
				lstHanghoaThemAll.DisplayMember = "OBJNAME"
				lstHanghoaThemAll.ValueMember = "OBJID"
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sRefesh_ListBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001F41 RID: 8001 RVA: 0x00182C18 File Offset: 0x00180E18
		Private Sub sAdd()
			' The following expression was wrapped in a checked-statement
			Try
				Dim num As Integer = 0
				Dim num2 As Integer = Me.lstHanghoaThemAll.Items.Count - 1
				Dim num3 As Integer = num
				While True
					Dim num4 As Integer = num3
					Dim num5 As Integer = num2
					If num4 > num5 Then
						Exit For
					End If
					Dim text As String = Conversions.ToString(NewLateBinding.LateIndexGet(Me.lstHanghoaThemAll.Items(num3), New Object() { "OBJID" }, Nothing))
					Me.mbytSuccess = Me.fAddNew(Strings.Trim(text), Me.mStrOBJID)
					num3 += 1
				End While
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sAdd ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001F42 RID: 8002 RVA: 0x00182D10 File Offset: 0x00180F10
		Private Function fGetNameHH(strMAHH As String) As String
			Dim array As DataColumn() = New DataColumn(0) {}
			Dim text As String = ""
			Try
				Me.mclsTemp = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
				array(0) = Me.mclsTemp.Columns("OBJID")
				Me.mclsTemp.PrimaryKey = array
				Dim dataRow As DataRow = Me.mclsTemp.Rows.Find(strMAHH)
				Dim text2 As String = dataRow("OBJNAME").ToString()
				text = text2
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetNameHH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
			Return text
		End Function

		' Token: 0x06001F43 RID: 8003 RVA: 0x00182E14 File Offset: 0x00181014
		Private Sub sDisplay_Moddelete()
			Dim dataSet As DataSet = New DataSet()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADNKM"
				array(0).Value = Me.mStrOBJID
				Dim num As Integer
				dataSet = New clsMyDataset(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM4_GET_DATA", num)
				Dim flag As Boolean = Me.lstHanghoaThemAll.Items.Count = 0
				If flag Then
					Me.mclsTBHHThemAll = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
					Me.mclsTBHHThemAll.Rows.Clear()
				End If
				Dim num2 As Integer = dataSet.Tables(0).Rows.Count
				Dim array2 As String() = New String(num2 + 1 - 1) {}
				Dim num3 As Integer = 0
				Dim num4 As Integer = dataSet.Tables(0).Rows.Count - 1
				num2 = num3
				While True
					Dim num5 As Integer = num2
					Dim num6 As Integer = num4
					If num5 > num6 Then
						Exit For
					End If
					array2(num2) = Conversions.ToString(dataSet.Tables(0).Rows(num2)("MAHHSALE"))
					Dim text As String = array2(num2)
					Dim text2 As String = Me.fGetNameHH(Strings.Trim(text))
					Me.mclsTBHHThemAll.Rows.Add(New Object() { Strings.Trim(text), Strings.Trim(text2) })
					num2 += 1
				End While
				Me.sRefesh_ListBox()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sDisplay_Moddelete ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x04000CB6 RID: 3254
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000CB8 RID: 3256
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x04000CB9 RID: 3257
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000CBA RID: 3258
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000CBB RID: 3259
		<AccessedThroughProperty("btnThemAll")>
		Private _btnThemAll As Button

		' Token: 0x04000CBC RID: 3260
		<AccessedThroughProperty("btnThem1MH")>
		Private _btnThem1MH As Button

		' Token: 0x04000CBD RID: 3261
		<AccessedThroughProperty("btnGobo")>
		Private _btnGobo As Button

		' Token: 0x04000CBE RID: 3262
		<AccessedThroughProperty("lstHanghoaThemAll")>
		Private _lstHanghoaThemAll As ListBox

		' Token: 0x04000CBF RID: 3263
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000CC0 RID: 3264
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000CC1 RID: 3265
		Private mArrStrFrmMess As String()

		' Token: 0x04000CC2 RID: 3266
		Private mbytFormStatus As Byte

		' Token: 0x04000CC3 RID: 3267
		Private mbytSuccess As Byte

		' Token: 0x04000CC4 RID: 3268
		Private mStrFilter As String

		' Token: 0x04000CC5 RID: 3269
		Private mStrOBJID As String

		' Token: 0x04000CC6 RID: 3270
		Private mStrMAHHSALE As String

		' Token: 0x04000CC7 RID: 3271
		Private mStrMAHHSUR As String

		' Token: 0x04000CC8 RID: 3272
		Private mclsTBHHThemAll As clsConnect

		' Token: 0x04000CC9 RID: 3273
		Private mclsTemp As clsConnect

		' Token: 0x04000CCA RID: 3274
		Private mbytFlag As Byte

		' Token: 0x04000CCB RID: 3275
		Private mstrMAHH As String

		' Token: 0x04000CCC RID: 3276
		Private mstrTENHH As String

		' Token: 0x04000CCD RID: 3277
		Private mbytAllData As Byte

		' Token: 0x04000CCE RID: 3278
		Private mbtySingle As Byte
	End Class
End Namespace
