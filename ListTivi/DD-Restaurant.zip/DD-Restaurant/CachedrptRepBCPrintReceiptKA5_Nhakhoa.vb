﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002EC RID: 748
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBCPrintReceiptKA5_Nhakhoa
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006F35 RID: 28469 RVA: 0x00013A2B File Offset: 0x00011C2B
		Public Sub New()
			CachedrptRepBCPrintReceiptKA5_Nhakhoa.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002E48 RID: 11848
		' (get) Token: 0x06006F36 RID: 28470 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006F37 RID: 28471 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002E49 RID: 11849
		' (get) Token: 0x06006F38 RID: 28472 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006F39 RID: 28473 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002E4A RID: 11850
		' (get) Token: 0x06006F3A RID: 28474 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006F3B RID: 28475 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006F3C RID: 28476 RVA: 0x004DEFC4 File Offset: 0x004DD1C4
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBCPrintReceiptKA5_Nhakhoa() With { .Site = Me.Site }
		End Function

		' Token: 0x06006F3D RID: 28477 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028E4 RID: 10468
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
