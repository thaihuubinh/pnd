﻿Namespace prjIS_SalesPOS
	' Token: 0x0200002A RID: 42
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCTGIAHH_Ban02
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060007EC RID: 2028 RVA: 0x0005C8A8 File Offset: 0x0005AAA8
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060007ED RID: 2029 RVA: 0x0005C8E0 File Offset: 0x0005AAE0
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCTGIAHH_Ban02))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.lblMAHH = New Global.System.Windows.Forms.Label()
			Me.lblWORKDATE = New Global.System.Windows.Forms.Label()
			Me.txtDONGIAMUA = New Global.System.Windows.Forms.TextBox()
			Me.lblMoneyUnit = New Global.System.Windows.Forms.Label()
			Me.txtTENHH = New Global.System.Windows.Forms.TextBox()
			Me.btnSelDMHH = New Global.System.Windows.Forms.Button()
			Me.txtMAHH = New Global.System.Windows.Forms.TextBox()
			Me.lblDONGIA = New Global.System.Windows.Forms.Label()
			Me.lblMark = New Global.System.Windows.Forms.Label()
			Me.lblDVT2 = New Global.System.Windows.Forms.Label()
			Me.dgvMAHH = New Global.System.Windows.Forms.DataGridView()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			CType(Me.dgvMAHH, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(599, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 499)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 10
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 2)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 1)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 5
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 478)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 193)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(107, 89)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 2
			Me.btnFilter.Tag = "CR0005"
			Me.btnFilter.Text = "Lọ&c"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 383)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 92)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 4
			Me.btnExit.Tag = "CR0002"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 288)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(107, 89)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 3
			Me.btnFind.Tag = "CR0006"
			Me.btnFind.Text = "&Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 3)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(107, 89)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 0
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 98)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 89)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 1
			Me.btnDelete.Tag = "CR0004"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.lblMAHH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAHH As Global.System.Windows.Forms.Control = Me.lblMAHH
			point = New Global.System.Drawing.Point(9, 11)
			lblMAHH.Location = point
			Me.lblMAHH.Name = "lblMAHH"
			Dim lblMAHH2 As Global.System.Windows.Forms.Control = Me.lblMAHH
			size = New Global.System.Drawing.Size(154, 21)
			lblMAHH2.Size = size
			Me.lblMAHH.TabIndex = 33
			Me.lblMAHH.Tag = "CR0007"
			Me.lblMAHH.Text = "Mã hàng hóa"
			Me.lblWORKDATE.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblWORKDATE As Global.System.Windows.Forms.Control = Me.lblWORKDATE
			point = New Global.System.Drawing.Point(-140, -135)
			lblWORKDATE.Location = point
			Me.lblWORKDATE.Name = "lblWORKDATE"
			Dim lblWORKDATE2 As Global.System.Windows.Forms.Control = Me.lblWORKDATE
			size = New Global.System.Drawing.Size(154, 21)
			lblWORKDATE2.Size = size
			Me.lblWORKDATE.TabIndex = 54
			Me.lblWORKDATE.Tag = "CR0032"
			Me.lblWORKDATE.Text = "Ngày tuyển dụng"
			Me.txtDONGIAMUA.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtDONGIAMUA As Global.System.Windows.Forms.Control = Me.txtDONGIAMUA
			point = New Global.System.Drawing.Point(146, 40)
			txtDONGIAMUA.Location = point
			Me.txtDONGIAMUA.Name = "txtDONGIAMUA"
			Dim txtDONGIAMUA2 As Global.System.Windows.Forms.Control = Me.txtDONGIAMUA
			size = New Global.System.Drawing.Size(132, 22)
			txtDONGIAMUA2.Size = size
			Me.txtDONGIAMUA.TabIndex = 4
			Me.txtDONGIAMUA.Tag = "0R0000"
			Me.lblMoneyUnit.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMoneyUnit As Global.System.Windows.Forms.Control = Me.lblMoneyUnit
			point = New Global.System.Drawing.Point(284, 43)
			lblMoneyUnit.Location = point
			Me.lblMoneyUnit.Name = "lblMoneyUnit"
			Dim lblMoneyUnit2 As Global.System.Windows.Forms.Control = Me.lblMoneyUnit
			size = New Global.System.Drawing.Size(42, 21)
			lblMoneyUnit2.Size = size
			Me.lblMoneyUnit.TabIndex = 83
			Me.lblMoneyUnit.Tag = "CR0000"
			Me.lblMoneyUnit.Text = "VNĐ"
			Me.txtTENHH.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENHH As Global.System.Windows.Forms.Control = Me.txtTENHH
			point = New Global.System.Drawing.Point(325, 12)
			txtTENHH.Location = point
			Me.txtTENHH.Name = "txtTENHH"
			Me.txtTENHH.[ReadOnly] = True
			Dim txtTENHH2 As Global.System.Windows.Forms.Control = Me.txtTENHH
			size = New Global.System.Drawing.Size(247, 22)
			txtTENHH2.Size = size
			Me.txtTENHH.TabIndex = 2
			Me.txtTENHH.Tag = "0R0000"
			Me.btnSelDMHH.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnSelDMHH As Global.System.Windows.Forms.Control = Me.btnSelDMHH
			point = New Global.System.Drawing.Point(284, 12)
			btnSelDMHH.Location = point
			Me.btnSelDMHH.Name = "btnSelDMHH"
			Dim btnSelDMHH2 As Global.System.Windows.Forms.Control = Me.btnSelDMHH
			size = New Global.System.Drawing.Size(35, 22)
			btnSelDMHH2.Size = size
			Me.btnSelDMHH.TabIndex = 1
			Me.btnSelDMHH.Tag = "CB0047"
			Me.btnSelDMHH.UseVisualStyleBackColor = True
			Me.txtMAHH.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAHH As Global.System.Windows.Forms.Control = Me.txtMAHH
			point = New Global.System.Drawing.Point(146, 12)
			txtMAHH.Location = point
			Me.txtMAHH.Name = "txtMAHH"
			Dim txtMAHH2 As Global.System.Windows.Forms.Control = Me.txtMAHH
			size = New Global.System.Drawing.Size(132, 22)
			txtMAHH2.Size = size
			Me.txtMAHH.TabIndex = 0
			Me.txtMAHH.Tag = "0R0000"
			Me.lblDONGIA.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblDONGIA As Global.System.Windows.Forms.Control = Me.lblDONGIA
			point = New Global.System.Drawing.Point(9, 43)
			lblDONGIA.Location = point
			Me.lblDONGIA.Name = "lblDONGIA"
			Dim lblDONGIA2 As Global.System.Windows.Forms.Control = Me.lblDONGIA
			size = New Global.System.Drawing.Size(131, 21)
			lblDONGIA2.Size = size
			Me.lblDONGIA.TabIndex = 76
			Me.lblDONGIA.Tag = "CR0043"
			Me.lblDONGIA.Text = "Đơn giá mua"
			Me.lblMark.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMark As Global.System.Windows.Forms.Control = Me.lblMark
			point = New Global.System.Drawing.Point(332, 43)
			lblMark.Location = point
			Me.lblMark.Name = "lblMark"
			Dim lblMark2 As Global.System.Windows.Forms.Control = Me.lblMark
			size = New Global.System.Drawing.Size(12, 21)
			lblMark2.Size = size
			Me.lblMark.TabIndex = 106
			Me.lblMark.Tag = "CR0011"
			Me.lblMark.Text = "/"
			Me.lblDVT2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblDVT As Global.System.Windows.Forms.Control = Me.lblDVT2
			point = New Global.System.Drawing.Point(350, 43)
			lblDVT.Location = point
			Me.lblDVT2.Name = "lblDVT2"
			Dim lblDVT2 As Global.System.Windows.Forms.Control = Me.lblDVT2
			size = New Global.System.Drawing.Size(175, 21)
			lblDVT2.Size = size
			Me.lblDVT2.TabIndex = 107
			Me.lblDVT2.Tag = "0R0000"
			Me.lblDVT2.Text = "ĐVT"
			Me.dgvMAHH.AllowUserToAddRows = False
			Me.dgvMAHH.AllowUserToDeleteRows = False
			Me.dgvMAHH.Anchor = Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvMAHH.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvMAHH.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvMAHH.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvMAHH As Global.System.Windows.Forms.Control = Me.dgvMAHH
			point = New Global.System.Drawing.Point(146, 35)
			dgvMAHH.Location = point
			Dim dgvMAHH2 As Global.System.Windows.Forms.Control = Me.dgvMAHH
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(4, 3, 4, 3)
			dgvMAHH2.Margin = padding
			Me.dgvMAHH.Name = "dgvMAHH"
			Me.dgvMAHH.[ReadOnly] = True
			Dim dgvMAHH3 As Global.System.Windows.Forms.Control = Me.dgvMAHH
			size = New Global.System.Drawing.Size(426, 419)
			dgvMAHH3.Size = size
			Me.dgvMAHH.TabIndex = 115
			Me.dgvMAHH.Visible = False
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(718, 499)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.dgvMAHH)
			Me.Controls.Add(Me.lblDVT2)
			Me.Controls.Add(Me.lblMark)
			Me.Controls.Add(Me.txtTENHH)
			Me.Controls.Add(Me.btnSelDMHH)
			Me.Controls.Add(Me.txtMAHH)
			Me.Controls.Add(Me.lblMoneyUnit)
			Me.Controls.Add(Me.lblDONGIA)
			Me.Controls.Add(Me.lblWORKDATE)
			Me.Controls.Add(Me.txtDONGIAMUA)
			Me.Controls.Add(Me.lblMAHH)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmCTGIAHH02"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "frmDOCUMENT016"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			CType(Me.dgvMAHH, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x04000378 RID: 888
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
