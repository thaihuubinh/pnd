﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000274 RID: 628
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60606K80Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600661A RID: 26138 RVA: 0x000126F3 File Offset: 0x000108F3
		Public Sub New()
			CachedrptRepBC60606K80Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002785 RID: 10117
		' (get) Token: 0x0600661B RID: 26139 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x0600661C RID: 26140 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002786 RID: 10118
		' (get) Token: 0x0600661D RID: 26141 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x0600661E RID: 26142 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002787 RID: 10119
		' (get) Token: 0x0600661F RID: 26143 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006620 RID: 26144 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006621 RID: 26145 RVA: 0x004DD9E0 File Offset: 0x004DBBE0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60606K80Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x06006622 RID: 26146 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x0400286C RID: 10348
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
