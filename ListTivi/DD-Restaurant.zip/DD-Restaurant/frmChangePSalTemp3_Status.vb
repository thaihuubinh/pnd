﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000023 RID: 35
	<DesignerGenerated()>
	Public Partial Class frmChangePSalTemp3_Status
		Inherits Form

		' Token: 0x06000665 RID: 1637 RVA: 0x0004C484 File Offset: 0x0004A684
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmChangeTableStatus_Load
			frmChangePSalTemp3_Status.__ENCList.Add(New WeakReference(Me))
			Me.mintSelectIndexNhom = 0
			Me.mLngAutoID = ""
			Me.mBlnChangeColor = False
			Me.mBlnOK = False
			Me.mBlnPrintRequest = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000270 RID: 624
		' (get) Token: 0x06000668 RID: 1640 RVA: 0x0004D054 File Offset: 0x0004B254
		' (set) Token: 0x06000669 RID: 1641 RVA: 0x0004D06C File Offset: 0x0004B26C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000271 RID: 625
		' (get) Token: 0x0600066A RID: 1642 RVA: 0x0004D0D8 File Offset: 0x0004B2D8
		' (set) Token: 0x0600066B RID: 1643 RVA: 0x00003131 File Offset: 0x00001331
		Friend Overridable Property TableLayoutPanel5 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel5 = value
			End Set
		End Property

		' Token: 0x17000272 RID: 626
		' (get) Token: 0x0600066C RID: 1644 RVA: 0x0004D0F0 File Offset: 0x0004B2F0
		' (set) Token: 0x0600066D RID: 1645 RVA: 0x0004D108 File Offset: 0x0004B308
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000273 RID: 627
		' (get) Token: 0x0600066E RID: 1646 RVA: 0x0004D174 File Offset: 0x0004B374
		' (set) Token: 0x0600066F RID: 1647 RVA: 0x0004D18C File Offset: 0x0004B38C
		Friend Overridable Property dtgStatus As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dtgStatus
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dtgStatus IsNot Nothing
				If flag Then
					RemoveHandler Me._dtgStatus.RowEnter, AddressOf Me.dtgStatus_RowEnter
					RemoveHandler Me._dtgStatus.DoubleClick, AddressOf Me.dtgStatus_DoubleClick
				End If
				Me._dtgStatus = value
				flag = Me._dtgStatus IsNot Nothing
				If flag Then
					AddHandler Me._dtgStatus.RowEnter, AddressOf Me.dtgStatus_RowEnter
					AddHandler Me._dtgStatus.DoubleClick, AddressOf Me.dtgStatus_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x17000274 RID: 628
		' (get) Token: 0x06000670 RID: 1648 RVA: 0x0004D228 File Offset: 0x0004B428
		' (set) Token: 0x06000671 RID: 1649 RVA: 0x0000313B File Offset: 0x0000133B
		Friend Overridable Property Column1 As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._Column1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._Column1 = value
			End Set
		End Property

		' Token: 0x17000275 RID: 629
		' (get) Token: 0x06000672 RID: 1650 RVA: 0x0004D240 File Offset: 0x0004B440
		' (set) Token: 0x06000673 RID: 1651 RVA: 0x00003145 File Offset: 0x00001345
		Friend Overridable Property Column2 As DataGridViewTextBoxColumn
			<DebuggerNonUserCode()>
			Get
				Return Me._Column2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridViewTextBoxColumn)
				Me._Column2 = value
			End Set
		End Property

		' Token: 0x17000276 RID: 630
		' (get) Token: 0x06000674 RID: 1652 RVA: 0x0004D258 File Offset: 0x0004B458
		' (set) Token: 0x06000675 RID: 1653 RVA: 0x0004D270 File Offset: 0x0004B470
		Friend Overridable Property btnColor As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnColor IsNot Nothing
				If flag Then
					RemoveHandler Me._btnColor.Click, AddressOf Me.btnColor_Click
				End If
				Me._btnColor = value
				flag = Me._btnColor IsNot Nothing
				If flag Then
					AddHandler Me._btnColor.Click, AddressOf Me.btnColor_Click
				End If
			End Set
		End Property

		' Token: 0x17000277 RID: 631
		' (get) Token: 0x06000676 RID: 1654 RVA: 0x0004D2DC File Offset: 0x0004B4DC
		' (set) Token: 0x06000677 RID: 1655 RVA: 0x0000314F File Offset: 0x0000134F
		Friend Overridable Property lblColor As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblColor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblColor = value
			End Set
		End Property

		' Token: 0x17000278 RID: 632
		' (get) Token: 0x06000678 RID: 1656 RVA: 0x0004D2F4 File Offset: 0x0004B4F4
		' (set) Token: 0x06000679 RID: 1657 RVA: 0x0004D30C File Offset: 0x0004B50C
		Friend Overridable Property btnIn As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnIn
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnIn IsNot Nothing
				If flag Then
					RemoveHandler Me._btnIn.Click, AddressOf Me.btnIn_Click
				End If
				Me._btnIn = value
				flag = Me._btnIn IsNot Nothing
				If flag Then
					AddHandler Me._btnIn.Click, AddressOf Me.btnIn_Click
				End If
			End Set
		End Property

		' Token: 0x17000279 RID: 633
		' (get) Token: 0x0600067A RID: 1658 RVA: 0x0004D378 File Offset: 0x0004B578
		' (set) Token: 0x0600067B RID: 1659 RVA: 0x00003159 File Offset: 0x00001359
		Public Property pBlnPrintRequest As Boolean
			Get
				Return Me.mBlnPrintRequest
			End Get
			Set(value As Boolean)
				Me.mBlnPrintRequest = value
			End Set
		End Property

		' Token: 0x1700027A RID: 634
		' (get) Token: 0x0600067C RID: 1660 RVA: 0x0004D390 File Offset: 0x0004B590
		' (set) Token: 0x0600067D RID: 1661 RVA: 0x00003164 File Offset: 0x00001364
		Public Property pLngAutoID As String
			Get
				Return Me.mLngAutoID
			End Get
			Set(value As String)
				Me.mLngAutoID = value
			End Set
		End Property

		' Token: 0x1700027B RID: 635
		' (get) Token: 0x0600067E RID: 1662 RVA: 0x0004D3A8 File Offset: 0x0004B5A8
		' (set) Token: 0x0600067F RID: 1663 RVA: 0x0000316F File Offset: 0x0000136F
		Public Property pBlnOK As Boolean
			Get
				Return Me.mBlnOK
			End Get
			Set(value As Boolean)
				Me.mBlnOK = value
			End Set
		End Property

		' Token: 0x1700027C RID: 636
		' (get) Token: 0x06000680 RID: 1664 RVA: 0x0004D3C0 File Offset: 0x0004B5C0
		' (set) Token: 0x06000681 RID: 1665 RVA: 0x0000317A File Offset: 0x0000137A
		Public Property pBlnChangeColor As Boolean
			Get
				Return Me.mBlnChangeColor
			End Get
			Set(value As Boolean)
				Me.mBlnChangeColor = value
			End Set
		End Property

		' Token: 0x06000682 RID: 1666 RVA: 0x00003185 File Offset: 0x00001385
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			mdlFile.gfWriteLogFile("Nhấn nút Thoát khỏi form đổi trạng thái món in bếp.")
			Me.mBlnOK = False
			Me.Close()
		End Sub

		' Token: 0x06000683 RID: 1667 RVA: 0x0004D3D8 File Offset: 0x0004B5D8
		Private Sub frmChangeTableStatus_Load(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Me.fInitCaption()
				Me.dtgStatus.Rows.Add(New Object() { "1", Me.mArrStrFrmMess(5) })
				Me.dtgStatus.Rows.Add(New Object() { "2", Me.mArrStrFrmMess(6) })
				Me.dtgStatus.Rows.Add(New Object() { "3", Me.mArrStrFrmMess(7) })
				Me.dtgStatus.Rows.Add(New Object() { "4", Me.mArrStrFrmMess(8) })
				Me.dtgStatus.Rows.Add(New Object() { "5", Me.mArrStrFrmMess(9) })
				Dim clsConnect As clsConnect = New clsConnect()
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "PSALTEMP3_STATUSMAU")
				Dim flag As Boolean = clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
				If flag Then
					Dim num As Integer = 0
					Dim num2 As Integer = clsConnect.Rows.Count - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						Me.lblColor.BackColor = Color.FromArgb(Conversions.ToInteger(clsConnect.Rows(num3)("BACKCOLORRED")), Conversions.ToInteger(clsConnect.Rows(num3)("BACKCOLORGREEN")), Conversions.ToInteger(clsConnect.Rows(num3)("BACKCOLORBLUE")))
						Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
						dataGridViewCellStyle.BackColor = Me.lblColor.BackColor
						Me.dtgStatus.Rows(num3).DefaultCellStyle = dataGridViewCellStyle
						num3 += 1
					End While
				End If
				clsConnect.Dispose()
				Me.dtgStatus.Columns(0).Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - frmChangeTableStatus_Load " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000684 RID: 1668 RVA: 0x0004D674 File Offset: 0x0004B874
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000685 RID: 1669 RVA: 0x0004D770 File Offset: 0x0004B970
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim flag As Boolean = Me.dtgStatus.SelectedRows.Count <= 0
				If flag Then
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(3), Me.mArrStrFrmMess(4), frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
				Else
					Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
					flag = Me.mBlnChangeColor
					If flag Then
						Dim num As Integer = 0
						Dim num2 As Integer = Me.dtgStatus.Rows.Count - 1
						Dim num3 As Integer = num
						While True
							Dim num4 As Integer = num3
							Dim num5 As Integer = num2
							If num4 > num5 Then
								Exit For
							End If
							dataGridViewCellStyle = Me.dtgStatus.Rows(num3).DefaultCellStyle
							Me.lblColor.BackColor = dataGridViewCellStyle.BackColor
							Me.fUpdateBangMau(num3 + 1, "", Me.lblColor.BackColor.R, Me.lblColor.BackColor.G, Me.lblColor.BackColor.B)
							num3 += 1
						End While
					End If
					Me.gsUpdatePSalTemp3_Status(Conversions.ToByte(Me.dtgStatus.CurrentRow.Cells(0).Value))
					Me.mBlnOK = True
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnSelect_Click " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000686 RID: 1670 RVA: 0x000031A2 File Offset: 0x000013A2
		Private Sub dtgStatus_DoubleClick(sender As Object, e As EventArgs)
			Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
		End Sub

		' Token: 0x06000687 RID: 1671 RVA: 0x000031B4 File Offset: 0x000013B4
		Private Sub dtgStatus_RowEnter(sender As Object, e As DataGridViewCellEventArgs)
			Me.mintSelectIndexNhom = e.RowIndex
		End Sub

		' Token: 0x06000688 RID: 1672 RVA: 0x0004D928 File Offset: 0x0004BB28
		Private Sub btnColor_Click(sender As Object, e As EventArgs)
			Try
				Dim frmcolorsetting As frmcolorsetting = New frmcolorsetting()
				frmcolorsetting.ShowDialog()
				Dim pblnresult As Boolean = frmcolorsetting.pblnresult
				If pblnresult Then
					Me.mBlnChangeColor = True
					Me.lblColor.BackColor = Color.FromArgb(Conversions.ToInteger(frmcolorsetting.pbytColorDefred), Conversions.ToInteger(frmcolorsetting.pbytColorDefgreen), Conversions.ToInteger(frmcolorsetting.pbytColorDefblue))
					Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
					dataGridViewCellStyle.BackColor = Me.lblColor.BackColor
					Me.dtgStatus.Rows(Me.dtgStatus.CurrentRow.Index).DefaultCellStyle = dataGridViewCellStyle
					mdlFile.gfWriteLogFile("Chọn màu: " + Me.lblColor.BackColor.ToString() + " cho " + Me.dtgStatus.Rows(Me.dtgStatus.CurrentRow.Index).Cells(1).Value.ToString())
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnColor_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000689 RID: 1673 RVA: 0x0004DAA0 File Offset: 0x0004BCA0
		Private Function fUpdateBangMau(pintOJID As Integer, pStrName As String, pbytRed As Byte, pbytGreen As Byte, pbytBlue As Byte) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(6) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnvcOBJID"
				array(0).Value = pintOJID
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@nvcOBJNAME"
				array(1).Value = pStrName.Trim()
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@tniBACKCOLORRED"
				array(2).Value = pbytRed
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@tniBACKCOLORGREEN"
				array(3).Value = pbytGreen
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@tniBACKCOLORBLUE"
				array(4).Value = pbytBlue
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@int_Result"
				array(5).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMREPRINTKP_STATUSMAU_UPDATE", flag)
				Dim num As Integer = Conversions.ToInteger(array(5).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(11), "", frmMyMessage.enuNutChon.NutOK, frmMyMessage.enuHinh.Loi)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(11), vbCrLf, Me.Name, " - fUpdate ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x0600068A RID: 1674 RVA: 0x0004DCCC File Offset: 0x0004BECC
		Private Sub gsUpdatePSalTemp3_Status(bytStatus As Byte)
			Try
				Dim array As SqlParameter() = New SqlParameter(2) {}
				array(0) = New SqlParameter("@bigAUTOID", Me.mLngAutoID)
				array(1) = New SqlParameter("@tniSTATUS", bytStatus)
				Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
				Dim array2 As SqlParameter() = array
				Dim text As String = "SP_FRMREPRINTKP_UPDATE_PSALTEMP3_STATUS"
				Dim num As Integer = 0
				Dim clsConnect As clsConnect = New clsConnect(gStrConISDANHMUC, array2, text, num)
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - gsUpdatePSalTemp3_Status " + ex.Message + vbCrLf, MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x0600068B RID: 1675 RVA: 0x0004DD70 File Offset: 0x0004BF70
		Private Sub btnIn_Click(sender As Object, e As EventArgs)
			Try
				Me.mBlnPrintRequest = True
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - btnIn_Click " + ex.Message + vbCrLf, MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x040002C7 RID: 711
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040002C9 RID: 713
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040002CA RID: 714
		<AccessedThroughProperty("TableLayoutPanel5")>
		Private _TableLayoutPanel5 As TableLayoutPanel

		' Token: 0x040002CB RID: 715
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040002CC RID: 716
		<AccessedThroughProperty("dtgStatus")>
		Private _dtgStatus As DataGridView

		' Token: 0x040002CD RID: 717
		<AccessedThroughProperty("Column1")>
		Private _Column1 As DataGridViewTextBoxColumn

		' Token: 0x040002CE RID: 718
		<AccessedThroughProperty("Column2")>
		Private _Column2 As DataGridViewTextBoxColumn

		' Token: 0x040002CF RID: 719
		<AccessedThroughProperty("btnColor")>
		Private _btnColor As Button

		' Token: 0x040002D0 RID: 720
		<AccessedThroughProperty("lblColor")>
		Private _lblColor As Label

		' Token: 0x040002D1 RID: 721
		<AccessedThroughProperty("btnIn")>
		Private _btnIn As Button

		' Token: 0x040002D2 RID: 722
		Private mArrStrFrmMess As String()

		' Token: 0x040002D3 RID: 723
		Private mintSelectIndexNhom As Integer

		' Token: 0x040002D4 RID: 724
		Private mLngAutoID As String

		' Token: 0x040002D5 RID: 725
		Private mBlnChangeColor As Boolean

		' Token: 0x040002D6 RID: 726
		Private mBlnOK As Boolean

		' Token: 0x040002D7 RID: 727
		Private mBlnPrintRequest As Boolean
	End Class
End Namespace
