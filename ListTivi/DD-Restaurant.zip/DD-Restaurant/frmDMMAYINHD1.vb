﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO.Ports
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000064 RID: 100
	<DesignerGenerated()>
	Public Partial Class frmDMMAYINHD1
		Inherits Form

		' Token: 0x06001F45 RID: 8005 RVA: 0x00183010 File Offset: 0x00181210
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMMAYINHD1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMMAYINHD1_Load
			frmDMMAYINHD1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.srlCOMport = New SerialPort()
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000ABD RID: 2749
		' (get) Token: 0x06001F48 RID: 8008 RVA: 0x00184624 File Offset: 0x00182824
		' (set) Token: 0x06001F49 RID: 8009 RVA: 0x00006750 File Offset: 0x00004950
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000ABE RID: 2750
		' (get) Token: 0x06001F4A RID: 8010 RVA: 0x0018463C File Offset: 0x0018283C
		' (set) Token: 0x06001F4B RID: 8011 RVA: 0x00184654 File Offset: 0x00182854
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x17000ABF RID: 2751
		' (get) Token: 0x06001F4C RID: 8012 RVA: 0x001846C0 File Offset: 0x001828C0
		' (set) Token: 0x06001F4D RID: 8013 RVA: 0x001846D8 File Offset: 0x001828D8
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000AC0 RID: 2752
		' (get) Token: 0x06001F4E RID: 8014 RVA: 0x00184744 File Offset: 0x00182944
		' (set) Token: 0x06001F4F RID: 8015 RVA: 0x0018475C File Offset: 0x0018295C
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000AC1 RID: 2753
		' (get) Token: 0x06001F50 RID: 8016 RVA: 0x001847C8 File Offset: 0x001829C8
		' (set) Token: 0x06001F51 RID: 8017 RVA: 0x001847E0 File Offset: 0x001829E0
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000AC2 RID: 2754
		' (get) Token: 0x06001F52 RID: 8018 RVA: 0x0018484C File Offset: 0x00182A4C
		' (set) Token: 0x06001F53 RID: 8019 RVA: 0x00184864 File Offset: 0x00182A64
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000AC3 RID: 2755
		' (get) Token: 0x06001F54 RID: 8020 RVA: 0x001848D0 File Offset: 0x00182AD0
		' (set) Token: 0x06001F55 RID: 8021 RVA: 0x001848E8 File Offset: 0x00182AE8
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000AC4 RID: 2756
		' (get) Token: 0x06001F56 RID: 8022 RVA: 0x00184954 File Offset: 0x00182B54
		' (set) Token: 0x06001F57 RID: 8023 RVA: 0x0018496C File Offset: 0x00182B6C
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000AC5 RID: 2757
		' (get) Token: 0x06001F58 RID: 8024 RVA: 0x001849D8 File Offset: 0x00182BD8
		' (set) Token: 0x06001F59 RID: 8025 RVA: 0x0000675A File Offset: 0x0000495A
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000AC6 RID: 2758
		' (get) Token: 0x06001F5A RID: 8026 RVA: 0x001849F0 File Offset: 0x00182BF0
		' (set) Token: 0x06001F5B RID: 8027 RVA: 0x00184A08 File Offset: 0x00182C08
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000AC7 RID: 2759
		' (get) Token: 0x06001F5C RID: 8028 RVA: 0x00184A74 File Offset: 0x00182C74
		' (set) Token: 0x06001F5D RID: 8029 RVA: 0x00184A8C File Offset: 0x00182C8C
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x17000AC8 RID: 2760
		' (get) Token: 0x06001F5E RID: 8030 RVA: 0x00184AF8 File Offset: 0x00182CF8
		' (set) Token: 0x06001F5F RID: 8031 RVA: 0x00184B10 File Offset: 0x00182D10
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000AC9 RID: 2761
		' (get) Token: 0x06001F60 RID: 8032 RVA: 0x00184B7C File Offset: 0x00182D7C
		' (set) Token: 0x06001F61 RID: 8033 RVA: 0x00006764 File Offset: 0x00004964
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x17000ACA RID: 2762
		' (get) Token: 0x06001F62 RID: 8034 RVA: 0x00184B94 File Offset: 0x00182D94
		' (set) Token: 0x06001F63 RID: 8035 RVA: 0x00184BAC File Offset: 0x00182DAC
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x17000ACB RID: 2763
		' (get) Token: 0x06001F64 RID: 8036 RVA: 0x00184C18 File Offset: 0x00182E18
		' (set) Token: 0x06001F65 RID: 8037 RVA: 0x00184C30 File Offset: 0x00182E30
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x17000ACC RID: 2764
		' (get) Token: 0x06001F66 RID: 8038 RVA: 0x00184C9C File Offset: 0x00182E9C
		' (set) Token: 0x06001F67 RID: 8039 RVA: 0x00184CB4 File Offset: 0x00182EB4
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000ACD RID: 2765
		' (get) Token: 0x06001F68 RID: 8040 RVA: 0x00184D20 File Offset: 0x00182F20
		' (set) Token: 0x06001F69 RID: 8041 RVA: 0x00184D38 File Offset: 0x00182F38
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000ACE RID: 2766
		' (get) Token: 0x06001F6A RID: 8042 RVA: 0x00184DA4 File Offset: 0x00182FA4
		' (set) Token: 0x06001F6B RID: 8043 RVA: 0x00184DBC File Offset: 0x00182FBC
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000ACF RID: 2767
		' (get) Token: 0x06001F6C RID: 8044 RVA: 0x00184E28 File Offset: 0x00183028
		' (set) Token: 0x06001F6D RID: 8045 RVA: 0x0000676E File Offset: 0x0000496E
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x17000AD0 RID: 2768
		' (get) Token: 0x06001F6E RID: 8046 RVA: 0x00184E40 File Offset: 0x00183040
		' (set) Token: 0x06001F6F RID: 8047 RVA: 0x00006778 File Offset: 0x00004978
		Friend Overridable Property lblStore As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblStore
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblStore = value
			End Set
		End Property

		' Token: 0x17000AD1 RID: 2769
		' (get) Token: 0x06001F70 RID: 8048 RVA: 0x00184E58 File Offset: 0x00183058
		' (set) Token: 0x06001F71 RID: 8049 RVA: 0x00006782 File Offset: 0x00004982
		Friend Overridable Property txtOBJNAMEMAY As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAMEMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAMEMAY = value
			End Set
		End Property

		' Token: 0x17000AD2 RID: 2770
		' (get) Token: 0x06001F72 RID: 8050 RVA: 0x00184E70 File Offset: 0x00183070
		' (set) Token: 0x06001F73 RID: 8051 RVA: 0x00184E88 File Offset: 0x00183088
		Friend Overridable Property btnSelectMAY As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelectMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelectMAY IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelectMAY.Click, AddressOf Me.btnSelectMAY_Click
				End If
				Me._btnSelectMAY = value
				flag = Me._btnSelectMAY IsNot Nothing
				If flag Then
					AddHandler Me._btnSelectMAY.Click, AddressOf Me.btnSelectMAY_Click
				End If
			End Set
		End Property

		' Token: 0x17000AD3 RID: 2771
		' (get) Token: 0x06001F74 RID: 8052 RVA: 0x00184EF4 File Offset: 0x001830F4
		' (set) Token: 0x06001F75 RID: 8053 RVA: 0x00184F0C File Offset: 0x0018310C
		Friend Overridable Property txtOBJIDMAY As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJIDMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJIDMAY IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJIDMAY.TextChanged, AddressOf Me.txtOBJIDMAY_TextChanged
				End If
				Me._txtOBJIDMAY = value
				flag = Me._txtOBJIDMAY IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJIDMAY.TextChanged, AddressOf Me.txtOBJIDMAY_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000AD4 RID: 2772
		' (get) Token: 0x06001F76 RID: 8054 RVA: 0x00184F78 File Offset: 0x00183178
		' (set) Token: 0x06001F77 RID: 8055 RVA: 0x00184F90 File Offset: 0x00183190
		Friend Overridable Property btnTestPrint As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnTestPrint
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnTestPrint IsNot Nothing
				If flag Then
					RemoveHandler Me._btnTestPrint.Click, AddressOf Me.btnTestPrint_Click
				End If
				Me._btnTestPrint = value
				flag = Me._btnTestPrint IsNot Nothing
				If flag Then
					AddHandler Me._btnTestPrint.Click, AddressOf Me.btnTestPrint_Click
				End If
			End Set
		End Property

		' Token: 0x17000AD5 RID: 2773
		' (get) Token: 0x06001F78 RID: 8056 RVA: 0x00184FFC File Offset: 0x001831FC
		' (set) Token: 0x06001F79 RID: 8057 RVA: 0x0000678C File Offset: 0x0000498C
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000AD6 RID: 2774
		' (get) Token: 0x06001F7A RID: 8058 RVA: 0x00185014 File Offset: 0x00183214
		' (set) Token: 0x06001F7B RID: 8059 RVA: 0x0018502C File Offset: 0x0018322C
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000AD7 RID: 2775
		' (get) Token: 0x06001F7C RID: 8060 RVA: 0x00185098 File Offset: 0x00183298
		' (set) Token: 0x06001F7D RID: 8061 RVA: 0x00006796 File Offset: 0x00004996
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x17000AD8 RID: 2776
		' (get) Token: 0x06001F7E RID: 8062 RVA: 0x001850B0 File Offset: 0x001832B0
		' (set) Token: 0x06001F7F RID: 8063 RVA: 0x000067A1 File Offset: 0x000049A1
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000AD9 RID: 2777
		' (get) Token: 0x06001F80 RID: 8064 RVA: 0x001850C8 File Offset: 0x001832C8
		' (set) Token: 0x06001F81 RID: 8065 RVA: 0x000067AC File Offset: 0x000049AC
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06001F82 RID: 8066 RVA: 0x001850E0 File Offset: 0x001832E0
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				Me.mStrOBJNAME = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F83 RID: 8067 RVA: 0x001851E0 File Offset: 0x001833E0
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F84 RID: 8068 RVA: 0x001852B0 File Offset: 0x001834B0
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F85 RID: 8069 RVA: 0x001853A0 File Offset: 0x001835A0
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F86 RID: 8070 RVA: 0x00185484 File Offset: 0x00183684
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F87 RID: 8071 RVA: 0x00185548 File Offset: 0x00183748
		Private Sub frmDMMAYINHD1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Dim b As Byte = mdlVariable.gfGetDMMAYINHD()
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAYINHD1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F88 RID: 8072 RVA: 0x001855E8 File Offset: 0x001837E8
		Private Function fGetData_4Filter() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMMAY = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMAY")
				Dim flag As Boolean = Me.mclsTbDMMAY IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Filter ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001F89 RID: 8073 RVA: 0x001856A4 File Offset: 0x001838A4
		Private Sub frmDMMAYINHD1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Filter()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAYINHD1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F8A RID: 8074 RVA: 0x001857F0 File Offset: 0x001839F0
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F8B RID: 8075 RVA: 0x001858F8 File Offset: 0x00183AF8
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F8C RID: 8076 RVA: 0x00185990 File Offset: 0x00183B90
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINHD As frmDMMAYINHD2 = New frmDMMAYINHD2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMMAYINHD.pbytFromStatus = 1
				frmDMMAYINHD.pStrLoaiMayin = Conversions.ToString(0)
				Dim flag As Boolean = Me.mbdsSource.Count > 0
				If flag Then
					frmDMMAYINHD.pStrMAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				End If
				frmDMMAYINHD.ShowDialog()
				flag = frmDMMAYINHD.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMMAYINHD.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMMAYINHD.Dispose()
			End Try
		End Sub

		' Token: 0x06001F8D RID: 8077 RVA: 0x00185B80 File Offset: 0x00183D80
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINHD As frmDMMAYINHD2 = New frmDMMAYINHD2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMMAYINHD2 As frmDMMAYINHD2 = frmDMMAYINHD
				frmDMMAYINHD2.pbytFromStatus = 2
				frmDMMAYINHD2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMMAYINHD2.pStrMAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINHD2.pStrLoaiMayin = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("KIND").Value, ""))
				frmDMMAYINHD2.txtCOMName.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("COMNAME").Value, ""))
				frmDMMAYINHD2.txtBaudrate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BAUDRATE").Value, ""))
				frmDMMAYINHD2.txtDataBit.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DATABITS").Value, ""))
				frmDMMAYINHD2.txtParityBit.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PARITYBITS").Value, ""))
				frmDMMAYINHD2.txtStopBit.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("STOPBITS").Value, ""))
				frmDMMAYINHD2.txtFlowControl.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FLOWCONTROL").Value, ""))
				frmDMMAYINHD2.txtTimeOut.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TIMEOUT").Value, ""))
				frmDMMAYINHD2.txtPrintCount.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PRINTCOUNT").Value, ""))
				frmDMMAYINHD2.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMMAYINHD2.txtMAMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINHD2.txtTENMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAY").Value, ""))
				frmDMMAYINHD2.chkLOPENDRAWERTAMTINH.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LOPENDRAWERTAMTINH").Value, ""), True, False), True, False))
				frmDMMAYINHD2.chkLOPENDRAWER.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LOPENDRAWER").Value, ""), True, False), True, False))
				frmDMMAYINHD2.txtPrintWidth.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("PRINTWIDTH").Value)
				frmDMMAYINHD2.TxtMAMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAYCALL").Value, ""))
				frmDMMAYINHD2.txtTENMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAYCALL").Value, ""))
				frmDMMAYINHD2.txtTOP.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TOPMARGIN").Value)
				frmDMMAYINHD2.txtLEFT.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("LEFTMARGIN").Value)
				frmDMMAYINHD2.txtBottom.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("BOTTOMMARGIN").Value)
				frmDMMAYINHD2.txtRight.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("RIGHTMARGIN").Value)
				frmDMMAYINHD.ShowDialog()
				Dim flag As Boolean = frmDMMAYINHD.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMMAYINHD.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMMAYINHD.Dispose()
			End Try
		End Sub

		' Token: 0x06001F8E RID: 8078 RVA: 0x00186268 File Offset: 0x00184468
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINHD As frmDMMAYINHD2 = New frmDMMAYINHD2()
			Try
				Dim frmDMMAYINHD2 As frmDMMAYINHD2 = frmDMMAYINHD
				frmDMMAYINHD2.pbytFromStatus = 3
				frmDMMAYINHD2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMMAYINHD2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMMAYINHD2.pStrMAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINHD2.pStrLoaiMayin = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("KIND").Value, ""))
				frmDMMAYINHD2.txtCOMName.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("COMNAME").Value, ""))
				frmDMMAYINHD2.txtBaudrate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BAUDRATE").Value, ""))
				frmDMMAYINHD2.txtDataBit.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DATABITS").Value, ""))
				frmDMMAYINHD2.txtParityBit.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PARITYBITS").Value, ""))
				frmDMMAYINHD2.txtStopBit.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("STOPBITS").Value, ""))
				frmDMMAYINHD2.txtFlowControl.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FLOWCONTROL").Value, ""))
				frmDMMAYINHD2.txtTimeOut.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TIMEOUT").Value, ""))
				frmDMMAYINHD2.txtPrintCount.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PRINTCOUNT").Value, ""))
				frmDMMAYINHD2.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMMAYINHD2.txtMAMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINHD2.txtTENMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAY").Value, ""))
				frmDMMAYINHD2.chkLOPENDRAWERTAMTINH.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LOPENDRAWERTAMTINH").Value, ""), True, False), True, False))
				frmDMMAYINHD2.chkLOPENDRAWER.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LOPENDRAWER").Value, ""), True, False), True, False))
				frmDMMAYINHD2.txtPrintWidth.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("PRINTWIDTH").Value)
				frmDMMAYINHD2.TxtMAMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAYCALL").Value, ""))
				frmDMMAYINHD2.txtTENMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAYCALL").Value, ""))
				frmDMMAYINHD2.txtTOP.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TOPMARGIN").Value)
				frmDMMAYINHD2.txtLEFT.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("LEFTMARGIN").Value)
				frmDMMAYINHD2.txtBottom.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("BOTTOMMARGIN").Value)
				frmDMMAYINHD2.txtRight.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("RIGHTMARGIN").Value)
				frmDMMAYINHD.ShowDialog()
				Dim flag As Boolean = frmDMMAYINHD.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMMAYINHD.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAYINHD.Dispose()
			End Try
		End Sub

		' Token: 0x06001F8F RID: 8079 RVA: 0x00186934 File Offset: 0x00184B34
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINHD As frmDMMAYINHD2 = New frmDMMAYINHD2()
			Try
				Dim frmDMMAYINHD2 As frmDMMAYINHD2 = frmDMMAYINHD
				frmDMMAYINHD2.pbytFromStatus = 4
				frmDMMAYINHD2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMMAYINHD2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMMAYINHD2.pStrMAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINHD2.pStrLoaiMayin = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("KIND").Value, ""))
				frmDMMAYINHD2.txtCOMName.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("COMNAME").Value, ""))
				frmDMMAYINHD2.txtBaudrate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BAUDRATE").Value, ""))
				frmDMMAYINHD2.txtDataBit.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DATABITS").Value, ""))
				frmDMMAYINHD2.txtParityBit.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PARITYBITS").Value, ""))
				frmDMMAYINHD2.txtStopBit.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("STOPBITS").Value, ""))
				frmDMMAYINHD2.txtFlowControl.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FLOWCONTROL").Value, ""))
				frmDMMAYINHD2.txtTimeOut.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TIMEOUT").Value, ""))
				frmDMMAYINHD2.txtPrintCount.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PRINTCOUNT").Value, ""))
				frmDMMAYINHD2.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMMAYINHD2.txtMAMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINHD2.txtTENMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAY").Value, ""))
				frmDMMAYINHD2.chkLOPENDRAWERTAMTINH.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LSHARE").Value, ""), True, False), True, False))
				frmDMMAYINHD2.chkLOPENDRAWER.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LOPENDRAWER").Value, ""), True, False), True, False))
				frmDMMAYINHD2.txtPrintWidth.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("PRINTWIDTH").Value)
				frmDMMAYINHD2.TxtMAMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAYCALL").Value, ""))
				frmDMMAYINHD2.txtTENMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAYCALL").Value, ""))
				frmDMMAYINHD2.txtTOP.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TOPMARGIN").Value)
				frmDMMAYINHD2.txtLEFT.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("LEFTMARGIN").Value)
				frmDMMAYINHD2.txtBottom.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("BOTTOMMARGIN").Value)
				frmDMMAYINHD2.txtRight.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("RIGHTMARGIN").Value)
				frmDMMAYINHD.ShowDialog()
				Dim flag As Boolean = frmDMMAYINHD.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAYINHD.Dispose()
			End Try
		End Sub

		' Token: 0x06001F90 RID: 8080 RVA: 0x00186FE0 File Offset: 0x001851E0
		Private Sub btnTestPrint_Click(sender As Object, e As EventArgs)
			Dim text As String = Me.mArrStrFrmMess(40)
			Dim text2 As String = Me.mArrStrFrmMess(41)
			Try
				Dim obj As Object = Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("KIND").Value, "")
				Dim flag As Boolean = Operators.ConditionalCompareObjectEqual(obj, "0", False)
				If flag Then
					Me.sTestPrintCOM80(mdlPrintReceipt.gfRemove_signVie(text2), mdlPrintReceipt.gfRemove_signVie(text))
				Else
					flag = Operators.ConditionalCompareObjectEqual(obj, "1", False)
					If flag Then
						Me.sTestPrintCOM80(mdlPrintReceipt.gfRemove_signVie(text2), mdlPrintReceipt.gfRemove_signVie(text))
					Else
						flag = Operators.ConditionalCompareObjectEqual(obj, "2", False)
						If flag Then
							Me.sTestPrintCOM80(mdlPrintReceipt.gfRemove_signVie(text2), mdlPrintReceipt.gfRemove_signVie(text))
						Else
							flag = Operators.ConditionalCompareObjectEqual(obj, "3", False)
							If flag Then
								Me.gsTestPrintDiver58(text2, text)
							Else
								flag = Operators.ConditionalCompareObjectEqual(obj, "4", False)
								If flag Then
									Me.gsTestPrintDiver58(text2, text)
								Else
									flag = Operators.ConditionalCompareObjectEqual(obj, "5", False)
									If flag Then
										Me.gsTestPrintDiver58(text2, text)
									Else
										flag = Operators.ConditionalCompareObjectEqual(obj, "6", False)
										If flag Then
											Me.gsTestPrintDiver58(text2, text)
										Else
											flag = Operators.ConditionalCompareObjectEqual(obj, "7", False)
											If flag Then
												Me.gsTestPrintDiver58(text2, text)
											Else
												flag = Operators.ConditionalCompareObjectEqual(obj, "8", False)
												If flag Then
													Me.gsTestPrintDiver58(text2, text)
												Else
													flag = Operators.ConditionalCompareObjectEqual(obj, "9", False)
													If flag Then
														Me.gsTestPrintDiver58(text2, text)
													Else
														flag = Operators.ConditionalCompareObjectEqual(obj, "10", False)
														If flag Then
															Me.gsTestPrintDiver58(text2, text)
														Else
															flag = Operators.ConditionalCompareObjectEqual(obj, "11", False)
															If flag Then
																Me.gsTestPrintDiver58(text2, text)
															End If
														End If
													End If
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnTestPrint_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001F91 RID: 8081 RVA: 0x00187250 File Offset: 0x00185450
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim frmDMMAYINHDKHU As frmDMMAYINHDKHU = New frmDMMAYINHDKHU()
			Try
				frmDMMAYINHDKHU.pStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMMAYINHDKHU.ShowDialog()
				Dim flag As Boolean = frmDMMAYINHDKHU.pbytSuccess = 0
				If flag Then
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAYINHDKHU.Dispose()
			End Try
		End Sub

		' Token: 0x06001F92 RID: 8082 RVA: 0x0018735C File Offset: 0x0018555C
		Private Sub txtOBJIDMAY_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMMAY Is Nothing
				If Not flag Then
					Me.btnCancelFilter.Visible = False
					array(0) = Me.mclsTbDMMAY.Columns("OBJID")
					Me.mclsTbDMMAY.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMMAY.Rows.Find(Strings.Trim(Me.txtOBJIDMAY.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtOBJNAMEMAY.Text = dataRow("OBJNAME").ToString()
						Me.mbdsSource.Filter = "MAMAY like '" + Strings.Replace(Strings.Trim(Me.txtOBJIDMAY.Text), "'", "''", 1, -1, CompareMethod.Binary) + "'"
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						Me.txtOBJNAMEMAY.Text = ""
						Me.mbdsSource.RemoveFilter()
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJIDMAY_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F93 RID: 8083 RVA: 0x00187520 File Offset: 0x00185720
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINHD As frmDMMAYINHD2 = New frmDMMAYINHD2()
			Try
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				frmDMMAYINHD.pbytFromStatus = 5
				frmDMMAYINHD.ShowDialog()
				Dim flag As Boolean = frmDMMAYINHD.pbytSuccess = 0
				If Not flag Then
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMMAYINHD.pStrFilter
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAYINHD.Dispose()
			End Try
		End Sub

		' Token: 0x06001F94 RID: 8084 RVA: 0x00187638 File Offset: 0x00185838
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINHD As frmDMMAYINHD2 = New frmDMMAYINHD2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAYINHD.Dispose()
			End Try
		End Sub

		' Token: 0x06001F95 RID: 8085 RVA: 0x00187700 File Offset: 0x00185900
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x06001F96 RID: 8086 RVA: 0x0018787C File Offset: 0x00185A7C
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = Strings.Trim(Me.txtOBJIDMAY.Text)
				Dim b As Byte = Me.fPrintDMMAYINHD(text)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F97 RID: 8087 RVA: 0x00187928 File Offset: 0x00185B28
		Private Sub btnSelectMAY_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAY As frmDMMAY1 = New frmDMMAY1()
				frmDMMAY.pBytOpen_From_Menu = 7
				frmDMMAY.btnSelect.Visible = True
				frmDMMAY.ShowDialog()
				Me.txtOBJIDMAY.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAY.pStrOBJID, "", False) = 0, Me.txtOBJIDMAY.Text, frmDMMAY.pStrOBJID))
				frmDMMAY.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelectMAY_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F98 RID: 8088 RVA: 0x00187A20 File Offset: 0x00185C20
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("COMNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("COMNAME").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("COMNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("BAUDRATE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("BAUDRATE").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("BAUDRATE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DATABITS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(28))
				dgvData.Columns("DATABITS").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("DATABITS").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("PARITYBITS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(29))
				dgvData.Columns("PARITYBITS").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("PARITYBITS").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("STOPBITS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(30))
				dgvData.Columns("STOPBITS").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("STOPBITS").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("FLOWCONTROL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(31))
				dgvData.Columns("FLOWCONTROL").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("FLOWCONTROL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TIMEOUT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(32))
				dgvData.Columns("TIMEOUT").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("TIMEOUT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("PRINTCOUNT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(33))
				dgvData.Columns("PRINTCOUNT").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("PRINTCOUNT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(34))
				dgvData.Columns("REMARK").Width = 300
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENMAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("TENMAY").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENMAY").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MAMAY").Visible = False
				dgvData.Columns("MAMAYCALL").Visible = False
				dgvData.Columns("TENMAYCALL").Visible = False
				dgvData.Columns("KIND").Visible = False
				dgvData.Columns("LSHARE").Visible = False
				dgvData.Columns("LOPENDRAWER").Visible = False
				dgvData.Columns("PRINTWIDTH").Visible = False
				dgvData.Columns("TOPMARGIN").Visible = False
				dgvData.Columns("LEFTMARGIN").Visible = False
				dgvData.Columns("BOTTOMMARGIN").Visible = False
				dgvData.Columns("RIGHTMARGIN").Visible = False
				dgvData.Columns("LOPENDRAWERTAMTINH").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001F99 RID: 8089 RVA: 0x0018812C File Offset: 0x0018632C
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				Me.btnTestPrint.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001F9A RID: 8090 RVA: 0x001882BC File Offset: 0x001864BC
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAYINHD_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001F9B RID: 8091 RVA: 0x001883AC File Offset: 0x001865AC
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001F9C RID: 8092 RVA: 0x001884FC File Offset: 0x001866FC
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2080300000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001F9D RID: 8093 RVA: 0x00188608 File Offset: 0x00186808
		Private Sub sClear_Form()
			Try
				Dim flag As Boolean = Me.mclsTbDMMAY IsNot Nothing
				If flag Then
					Me.mclsTbDMMAY.Dispose()
				End If
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001F9E RID: 8094 RVA: 0x001886D0 File Offset: 0x001868D0
		Private Sub sTestPrintCOM80(pstrStringHead As String, pstrStringBody As String)
			Dim serialPort As SerialPort = New SerialPort()
			serialPort.PortName = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("COMNAME").Value, ""))
			serialPort.BaudRate = Conversions.ToInteger(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BAUDRATE").Value, ""))
			serialPort.DataBits = Conversions.ToInteger(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DATABITS").Value, ""))
			serialPort.Parity = CType(Conversions.ToInteger(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PARITYBITS").Value, "")), Parity)
			serialPort.StopBits = CType(Conversions.ToInteger(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("STOPBITS").Value, "")), StopBits)
			Dim flag As Boolean = Not serialPort.IsOpen
			If flag Then
				serialPort.Open()
			End If
			Try
				serialPort.Write(ChrW(29) & "\" & vbLf & ChrW(1))
				serialPort.Write(ChrW(27) & "a" & ChrW(1))
				serialPort.Write(ChrW(27) & "!" & vbNullChar)
				serialPort.WriteLine(pstrStringHead)
				serialPort.WriteLine(pstrStringBody)
				serialPort.WriteLine("")
				serialPort.WriteLine("")
				serialPort.WriteLine(ChrW(27) & "d" & vbNullChar)
				serialPort.WriteLine(ChrW(29) & "VB" & ChrW(1))
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sTestPrintCOM80 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				serialPort.Close()
			End Try
		End Sub

		' Token: 0x06001F9F RID: 8095 RVA: 0x001888F0 File Offset: 0x00186AF0
		Public Sub gsTestPrintDiver58(pstrStringHead As String, pstrStringBody As String)
			Dim rptRepBCTestPrintK58Driver As rptRepBCTestPrintK58Driver = New rptRepBCTestPrintK58Driver()
			Try
				Dim textObject As TextObject = CType(rptRepBCTestPrintK58Driver.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
				textObject.Text = pstrStringHead
				Dim textObject2 As TextObject = CType(rptRepBCTestPrintK58Driver.ReportDefinition.ReportObjects("Text1"), TextObject)
				textObject2.Text = pstrStringBody
				Dim textObject3 As TextObject = CType(rptRepBCTestPrintK58Driver.ReportDefinition.ReportObjects("Text2"), TextObject)
				textObject3.Text = ""
				Dim textObject4 As TextObject = CType(rptRepBCTestPrintK58Driver.ReportDefinition.ReportObjects("Text3"), TextObject)
				textObject4.Text = ""
				MyProject.Forms.frmReport.pSource = rptRepBCTestPrintK58Driver
				rptRepBCTestPrintK58Driver.PrintToPrinter(1, False, 0, 0)
				MyProject.Forms.frmReport.pSource = Nothing
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gsTestPrintDiver58 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				rptRepBCTestPrintK58Driver.Dispose()
			End Try
		End Sub

		' Token: 0x06001FA0 RID: 8096 RVA: 0x00188A74 File Offset: 0x00186C74
		Private Function fPrintDMMAYINHD(pstrMAMAY As String) As Byte
			Dim rptDMMAYINHD As rptDMMAYINHD = New rptDMMAYINHD()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMMAYINHD, "")
				Dim text As String = "2080300000"
				mdlReport.gsSetOfficeReport(rptDMMAYINHD, text)
				mdlReport.gsSetFontReport(rptDMMAYINHD)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAMAY"
				array(0).Value = pstrMAMAY
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_GET_DMMAYINHD", num)
				Dim flag As Boolean = num = 1
				If flag Then
					rptDMMAYINHD.SetDataSource(clsConnect)
					rptDMMAYINHD.DataDefinition.FormulaFields("fPrintBillCode").Text = "{dtReport.OBJID}"
					rptDMMAYINHD.DataDefinition.FormulaFields("fPrintBillName").Text = "{dtReport.OBJNAME}"
					rptDMMAYINHD.DataDefinition.FormulaFields("fCOMName").Text = "{dtReport.COMNAME}"
					rptDMMAYINHD.DataDefinition.FormulaFields("fBaudRate").Text = "{dtReport.BAUDRATE}"
					rptDMMAYINHD.DataDefinition.FormulaFields("fComputerName").Text = "{dtReport.TENMAY}"
					mdlReport.gsSetTextReport(rptDMMAYINHD, "RPTDMMAYINHD")
					MyProject.Forms.frmReport.pSource = rptDMMAYINHD
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMMAYINHD.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMMAYINHD.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMMAYINHD.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMMAYINHD " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMMAYINHD.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x04000CCF RID: 3279
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000CD1 RID: 3281
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000CD2 RID: 3282
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000CD3 RID: 3283
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000CD4 RID: 3284
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000CD5 RID: 3285
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000CD6 RID: 3286
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000CD7 RID: 3287
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000CD8 RID: 3288
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000CD9 RID: 3289
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000CDA RID: 3290
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000CDB RID: 3291
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000CDC RID: 3292
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000CDD RID: 3293
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000CDE RID: 3294
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000CDF RID: 3295
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000CE0 RID: 3296
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000CE1 RID: 3297
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000CE2 RID: 3298
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000CE3 RID: 3299
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000CE4 RID: 3300
		<AccessedThroughProperty("lblStore")>
		Private _lblStore As Label

		' Token: 0x04000CE5 RID: 3301
		<AccessedThroughProperty("txtOBJNAMEMAY")>
		Private _txtOBJNAMEMAY As TextBox

		' Token: 0x04000CE6 RID: 3302
		<AccessedThroughProperty("btnSelectMAY")>
		Private _btnSelectMAY As Button

		' Token: 0x04000CE7 RID: 3303
		<AccessedThroughProperty("txtOBJIDMAY")>
		Private _txtOBJIDMAY As TextBox

		' Token: 0x04000CE8 RID: 3304
		<AccessedThroughProperty("btnTestPrint")>
		Private _btnTestPrint As Button

		' Token: 0x04000CE9 RID: 3305
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000CEA RID: 3306
		Private mArrStrFrmMess As String()

		' Token: 0x04000CEB RID: 3307
		Private mStrOBJID As String

		' Token: 0x04000CEC RID: 3308
		Private mStrOBJNAME As String

		' Token: 0x04000CED RID: 3309
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000CEE RID: 3310
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000CEF RID: 3311
		Private marrDrFind As DataRow()

		' Token: 0x04000CF0 RID: 3312
		Private mintFindLastPos As Integer

		' Token: 0x04000CF1 RID: 3313
		Private mclsTbDMMAY As clsConnect

		' Token: 0x04000CF2 RID: 3314
		Private srlCOMport As SerialPort
	End Class
End Namespace
