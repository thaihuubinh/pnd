﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x02000115 RID: 277
	Public Class crpPhieuKiemMonK58
		Inherits ReportClass

		' Token: 0x060056EA RID: 22250 RVA: 0x0000EEBC File Offset: 0x0000D0BC
		Public Sub New()
			crpPhieuKiemMonK58.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001F2E RID: 7982
		' (get) Token: 0x060056EB RID: 22251 RVA: 0x004DAE08 File Offset: 0x004D9008
		' (set) Token: 0x060056EC RID: 22252 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crpPhieuKiemMonK58.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001F2F RID: 7983
		' (get) Token: 0x060056ED RID: 22253 RVA: 0x004DA738 File Offset: 0x004D8938
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportHeaderSection5 As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001F30 RID: 7984
		' (get) Token: 0x060056EE RID: 22254 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001F31 RID: 7985
		' (get) Token: 0x060056EF RID: 22255 RVA: 0x004DA780 File Offset: 0x004D8980
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsSOTT As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001F32 RID: 7986
		' (get) Token: 0x060056F0 RID: 22256 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property rhsSoKhach As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001F33 RID: 7987
		' (get) Token: 0x060056F1 RID: 22257 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportHeaderSection11 As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001F34 RID: 7988
		' (get) Token: 0x060056F2 RID: 22258 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportHeaderSection3 As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x17001F35 RID: 7989
		' (get) Token: 0x060056F3 RID: 22259 RVA: 0x004DA810 File Offset: 0x004D8A10
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsTenBan As Section
			Get
				Return Me.ReportDefinition.Sections(6)
			End Get
		End Property

		' Token: 0x17001F36 RID: 7990
		' (get) Token: 0x060056F4 RID: 22260 RVA: 0x004DA834 File Offset: 0x004D8A34
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportHeaderSection4 As Section
			Get
				Return Me.ReportDefinition.Sections(7)
			End Get
		End Property

		' Token: 0x17001F37 RID: 7991
		' (get) Token: 0x060056F5 RID: 22261 RVA: 0x004DA858 File Offset: 0x004D8A58
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportHeaderSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(8)
			End Get
		End Property

		' Token: 0x17001F38 RID: 7992
		' (get) Token: 0x060056F6 RID: 22262 RVA: 0x004DA87C File Offset: 0x004D8A7C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property rhsPHUCVU As Section
			Get
				Return Me.ReportDefinition.Sections(9)
			End Get
		End Property

		' Token: 0x17001F39 RID: 7993
		' (get) Token: 0x060056F7 RID: 22263 RVA: 0x004DA8A0 File Offset: 0x004D8AA0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection6 As Section
			Get
				Return Me.ReportDefinition.Sections(10)
			End Get
		End Property

		' Token: 0x17001F3A RID: 7994
		' (get) Token: 0x060056F8 RID: 22264 RVA: 0x004DA8C4 File Offset: 0x004D8AC4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportHeaderSection7 As Section
			Get
				Return Me.ReportDefinition.Sections(11)
			End Get
		End Property

		' Token: 0x17001F3B RID: 7995
		' (get) Token: 0x060056F9 RID: 22265 RVA: 0x004DA8E8 File Offset: 0x004D8AE8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportHeaderSection8 As Section
			Get
				Return Me.ReportDefinition.Sections(12)
			End Get
		End Property

		' Token: 0x17001F3C RID: 7996
		' (get) Token: 0x060056FA RID: 22266 RVA: 0x004DA90C File Offset: 0x004D8B0C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportHeaderSection9 As Section
			Get
				Return Me.ReportDefinition.Sections(13)
			End Get
		End Property

		' Token: 0x17001F3D RID: 7997
		' (get) Token: 0x060056FB RID: 22267 RVA: 0x004DA930 File Offset: 0x004D8B30
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportHeaderSection10 As Section
			Get
				Return Me.ReportDefinition.Sections(14)
			End Get
		End Property

		' Token: 0x17001F3E RID: 7998
		' (get) Token: 0x060056FC RID: 22268 RVA: 0x004DA954 File Offset: 0x004D8B54
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section2 As Section
			Get
				Return Me.ReportDefinition.Sections(15)
			End Get
		End Property

		' Token: 0x17001F3F RID: 7999
		' (get) Token: 0x060056FD RID: 22269 RVA: 0x004DA978 File Offset: 0x004D8B78
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property GroupHeaderSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(16)
			End Get
		End Property

		' Token: 0x17001F40 RID: 8000
		' (get) Token: 0x060056FE RID: 22270 RVA: 0x004DA99C File Offset: 0x004D8B9C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property GroupHeaderSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(17)
			End Get
		End Property

		' Token: 0x17001F41 RID: 8001
		' (get) Token: 0x060056FF RID: 22271 RVA: 0x004DA9C0 File Offset: 0x004D8BC0
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Sec As Section
			Get
				Return Me.ReportDefinition.Sections(18)
			End Get
		End Property

		' Token: 0x17001F42 RID: 8002
		' (get) Token: 0x06005700 RID: 22272 RVA: 0x004DA9E4 File Offset: 0x004D8BE4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(19)
			End Get
		End Property

		' Token: 0x17001F43 RID: 8003
		' (get) Token: 0x06005701 RID: 22273 RVA: 0x004DAA08 File Offset: 0x004D8C08
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection6 As Section
			Get
				Return Me.ReportDefinition.Sections(20)
			End Get
		End Property

		' Token: 0x17001F44 RID: 8004
		' (get) Token: 0x06005702 RID: 22274 RVA: 0x004DAA2C File Offset: 0x004D8C2C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection5 As Section
			Get
				Return Me.ReportDefinition.Sections(21)
			End Get
		End Property

		' Token: 0x17001F45 RID: 8005
		' (get) Token: 0x06005703 RID: 22275 RVA: 0x004DAA50 File Offset: 0x004D8C50
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property dst1 As Section
			Get
				Return Me.ReportDefinition.Sections(22)
			End Get
		End Property

		' Token: 0x17001F46 RID: 8006
		' (get) Token: 0x06005704 RID: 22276 RVA: 0x004DAA74 File Offset: 0x004D8C74
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(23)
			End Get
		End Property

		' Token: 0x17001F47 RID: 8007
		' (get) Token: 0x06005705 RID: 22277 RVA: 0x004DAA98 File Offset: 0x004D8C98
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection3 As Section
			Get
				Return Me.ReportDefinition.Sections(24)
			End Get
		End Property

		' Token: 0x17001F48 RID: 8008
		' (get) Token: 0x06005706 RID: 22278 RVA: 0x004DAABC File Offset: 0x004D8CBC
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property DetailSection4 As Section
			Get
				Return Me.ReportDefinition.Sections(25)
			End Get
		End Property

		' Token: 0x17001F49 RID: 8009
		' (get) Token: 0x06005707 RID: 22279 RVA: 0x004DAAE0 File Offset: 0x004D8CE0
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(26)
			End Get
		End Property

		' Token: 0x17001F4A RID: 8010
		' (get) Token: 0x06005708 RID: 22280 RVA: 0x004DAB04 File Offset: 0x004D8D04
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(27)
			End Get
		End Property

		' Token: 0x17001F4B RID: 8011
		' (get) Token: 0x06005709 RID: 22281 RVA: 0x004DAB28 File Offset: 0x004D8D28
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property secSumQty As Section
			Get
				Return Me.ReportDefinition.Sections(28)
			End Get
		End Property

		' Token: 0x17001F4C RID: 8012
		' (get) Token: 0x0600570A RID: 22282 RVA: 0x004DAB4C File Offset: 0x004D8D4C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section5F As Section
			Get
				Return Me.ReportDefinition.Sections(29)
			End Get
		End Property

		' Token: 0x0400270D RID: 9997
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
