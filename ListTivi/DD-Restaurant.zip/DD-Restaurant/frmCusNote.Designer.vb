﻿Namespace prjIS_SalesPOS
	' Token: 0x0200002C RID: 44
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCusNote
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000873 RID: 2163 RVA: 0x0006219C File Offset: 0x0006039C
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000874 RID: 2164 RVA: 0x000621D4 File Offset: 0x000603D4
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCusNote))
			Me.lblPosition = New Global.System.Windows.Forms.Label()
			Me.btnAddDefault = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.btnLast = New Global.System.Windows.Forms.Button()
			Me.btnNext = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.btnPreview = New Global.System.Windows.Forms.Button()
			Me.btnCancelFilter = New Global.System.Windows.Forms.Button()
			Me.grpNavigater = New Global.System.Windows.Forms.GroupBox()
			Me.btnFirst = New Global.System.Windows.Forms.Button()
			Me.btnPrevious = New Global.System.Windows.Forms.Button()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.grpControl = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnAdd = New Global.System.Windows.Forms.Button()
			Me.btnModify = New Global.System.Windows.Forms.Button()
			Me.btnFindNext = New Global.System.Windows.Forms.Button()
			Me.dgvData = New Global.System.Windows.Forms.DataGridView()
			Me.lblFilterDate = New Global.System.Windows.Forms.Label()
			Me.btnCancel = New Global.System.Windows.Forms.Button()
			Me.mtxDATE = New Global.System.Windows.Forms.MaskedTextBox()
			Me.dtpTuNgay = New Global.System.Windows.Forms.DateTimePicker()
			Me.lblMA1 = New Global.System.Windows.Forms.Label()
			Me.txtTEN1 = New Global.System.Windows.Forms.TextBox()
			Me.btnDM1 = New Global.System.Windows.Forms.Button()
			Me.txtMA1 = New Global.System.Windows.Forms.TextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.mtxTODATE = New Global.System.Windows.Forms.MaskedTextBox()
			Me.dtpDenNgay = New Global.System.Windows.Forms.DateTimePicker()
			Me.dgvDMDV = New Global.System.Windows.Forms.DataGridView()
			Me.grpNavigater.SuspendLayout()
			Me.grpControl.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.dgvDMDV, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.lblPosition.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.lblPosition.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblPosition.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPosition As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(84, 14)
			lblPosition.Location = point
			Me.lblPosition.Name = "lblPosition"
			Dim lblPosition2 As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(93, 35)
			lblPosition2.Size = size
			Me.lblPosition.TabIndex = 6
			Me.lblPosition.Tag = "0R0000"
			Me.lblPosition.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btnAddDefault.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnAddDefault.Image = Global.prjIS_SalesPOS.My.Resources.Resources.them_copy
			Dim btnAddDefault As Global.System.Windows.Forms.Control = Me.btnAddDefault
			point = New Global.System.Drawing.Point(3, 51)
			btnAddDefault.Location = point
			Me.btnAddDefault.Name = "btnAddDefault"
			Dim btnAddDefault2 As Global.System.Windows.Forms.Control = Me.btnAddDefault
			size = New Global.System.Drawing.Size(107, 42)
			btnAddDefault2.Size = size
			Me.btnAddDefault.TabIndex = 3
			Me.btnAddDefault.Tag = "CR0005"
			Me.btnAddDefault.Text = "Thêm sửa"
			Me.btnAddDefault.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnAddDefault.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 147)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 42)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 2
			Me.btnDelete.Tag = "CR0007"
			Me.btnDelete.Text = "Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.btnLast.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi_1
			Dim btnLast As Global.System.Windows.Forms.Control = Me.btnLast
			point = New Global.System.Drawing.Point(215, 14)
			btnLast.Location = point
			Me.btnLast.Name = "btnLast"
			Dim btnLast2 As Global.System.Windows.Forms.Control = Me.btnLast
			size = New Global.System.Drawing.Size(40, 35)
			btnLast2.Size = size
			Me.btnLast.TabIndex = 5
			Me.btnLast.UseVisualStyleBackColor = True
			Me.btnNext.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi
			Dim btnNext As Global.System.Windows.Forms.Control = Me.btnNext
			point = New Global.System.Drawing.Point(176, 14)
			btnNext.Location = point
			Me.btnNext.Name = "btnNext"
			Dim btnNext2 As Global.System.Windows.Forms.Control = Me.btnNext
			size = New Global.System.Drawing.Size(40, 35)
			btnNext2.Size = size
			Me.btnNext.TabIndex = 4
			Me.btnNext.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 291)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(107, 42)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 4
			Me.btnFind.Tag = "CR0010"
			Me.btnFind.Text = "Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.btnPreview.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnPreview.Image = Global.prjIS_SalesPOS.My.Resources.Resources._in
			Dim btnPreview As Global.System.Windows.Forms.Control = Me.btnPreview
			point = New Global.System.Drawing.Point(3, 387)
			btnPreview.Location = point
			Me.btnPreview.Name = "btnPreview"
			Dim btnPreview2 As Global.System.Windows.Forms.Control = Me.btnPreview
			size = New Global.System.Drawing.Size(107, 42)
			btnPreview2.Size = size
			Me.btnPreview.TabIndex = 7
			Me.btnPreview.Tag = "CR0012"
			Me.btnPreview.Text = "In"
			Me.btnPreview.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnPreview.UseVisualStyleBackColor = True
			Me.btnCancelFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnCancelFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Cancel
			Dim btnCancelFilter As Global.System.Windows.Forms.Control = Me.btnCancelFilter
			point = New Global.System.Drawing.Point(3, 243)
			btnCancelFilter.Location = point
			Me.btnCancelFilter.Name = "btnCancelFilter"
			Dim btnCancelFilter2 As Global.System.Windows.Forms.Control = Me.btnCancelFilter
			size = New Global.System.Drawing.Size(107, 42)
			btnCancelFilter2.Size = size
			Me.btnCancelFilter.TabIndex = 6
			Me.btnCancelFilter.Tag = "CR0009"
			Me.btnCancelFilter.Text = "Bỏ lọc"
			Me.btnCancelFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnCancelFilter.UseVisualStyleBackColor = True
			Me.grpNavigater.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom
			Me.grpNavigater.Controls.Add(Me.lblPosition)
			Me.grpNavigater.Controls.Add(Me.btnFirst)
			Me.grpNavigater.Controls.Add(Me.btnPrevious)
			Me.grpNavigater.Controls.Add(Me.btnLast)
			Me.grpNavigater.Controls.Add(Me.btnNext)
			Dim grpNavigater As Global.System.Windows.Forms.Control = Me.grpNavigater
			point = New Global.System.Drawing.Point(344, 438)
			grpNavigater.Location = point
			Me.grpNavigater.Name = "grpNavigater"
			Dim grpNavigater2 As Global.System.Windows.Forms.Control = Me.grpNavigater
			size = New Global.System.Drawing.Size(266, 64)
			grpNavigater2.Size = size
			Me.grpNavigater.TabIndex = 3
			Me.grpNavigater.TabStop = False
			Me.btnFirst.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui_1
			Dim btnFirst As Global.System.Windows.Forms.Control = Me.btnFirst
			point = New Global.System.Drawing.Point(6, 14)
			btnFirst.Location = point
			Me.btnFirst.Name = "btnFirst"
			Dim btnFirst2 As Global.System.Windows.Forms.Control = Me.btnFirst
			size = New Global.System.Drawing.Size(40, 35)
			btnFirst2.Size = size
			Me.btnFirst.TabIndex = 2
			Me.btnFirst.UseVisualStyleBackColor = True
			Me.btnPrevious.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui
			Dim btnPrevious As Global.System.Windows.Forms.Control = Me.btnPrevious
			point = New Global.System.Drawing.Point(45, 14)
			btnPrevious.Location = point
			Me.btnPrevious.Name = "btnPrevious"
			Dim btnPrevious2 As Global.System.Windows.Forms.Control = Me.btnPrevious
			size = New Global.System.Drawing.Size(40, 35)
			btnPrevious2.Size = size
			Me.btnPrevious.TabIndex = 3
			Me.btnPrevious.UseVisualStyleBackColor = True
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 195)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(107, 42)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 5
			Me.btnFilter.Tag = "CR0008"
			Me.btnFilter.Text = "Lọc"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.grpControl.Controls.Add(Me.TableLayoutPanel1)
			Me.grpControl.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpControl As Global.System.Windows.Forms.Control = Me.grpControl
			point = New Global.System.Drawing.Point(940, 0)
			grpControl.Location = point
			Me.grpControl.Name = "grpControl"
			Dim grpControl2 As Global.System.Windows.Forms.Control = Me.grpControl
			size = New Global.System.Drawing.Size(119, 511)
			grpControl2.Size = size
			Me.grpControl.TabIndex = 2
			Me.grpControl.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 9)
			Me.TableLayoutPanel1.Controls.Add(Me.btnAdd, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnAddDefault, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnModify, 0, 2)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFindNext, 0, 7)
			Me.TableLayoutPanel1.Controls.Add(Me.btnCancelFilter, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnPreview, 0, 8)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 6)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 10
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 9.999999F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 9.999999F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 9.999999F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 9.999999F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 9.999999F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 9.999999F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 9.999999F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 9.999999F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 9.999999F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 9.999999F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Absolute, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Absolute, 20F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 490)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 435)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 52)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 12
			Me.btnExit.Tag = "CR0003"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnAdd.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnAdd.Image = Global.prjIS_SalesPOS.My.Resources.Resources.them
			Dim btnAdd As Global.System.Windows.Forms.Control = Me.btnAdd
			point = New Global.System.Drawing.Point(3, 3)
			btnAdd.Location = point
			Me.btnAdd.Name = "btnAdd"
			Dim btnAdd2 As Global.System.Windows.Forms.Control = Me.btnAdd
			size = New Global.System.Drawing.Size(107, 42)
			btnAdd2.Size = size
			Me.btnAdd.TabIndex = 0
			Me.btnAdd.Tag = "CR0004"
			Me.btnAdd.Text = "Thêm"
			Me.btnAdd.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnAdd.UseVisualStyleBackColor = True
			Me.btnModify.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnModify.Image = Global.prjIS_SalesPOS.My.Resources.Resources.sua
			Dim btnModify As Global.System.Windows.Forms.Control = Me.btnModify
			point = New Global.System.Drawing.Point(3, 99)
			btnModify.Location = point
			Me.btnModify.Name = "btnModify"
			Dim btnModify2 As Global.System.Windows.Forms.Control = Me.btnModify
			size = New Global.System.Drawing.Size(107, 42)
			btnModify2.Size = size
			Me.btnModify.TabIndex = 1
			Me.btnModify.Tag = "CR0006"
			Me.btnModify.Text = "Sửa"
			Me.btnModify.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnModify.UseVisualStyleBackColor = True
			Me.btnFindNext.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFindNext.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnFindNext.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim_tiep
			Dim btnFindNext As Global.System.Windows.Forms.Control = Me.btnFindNext
			point = New Global.System.Drawing.Point(3, 339)
			btnFindNext.Location = point
			Me.btnFindNext.Name = "btnFindNext"
			Dim btnFindNext2 As Global.System.Windows.Forms.Control = Me.btnFindNext
			size = New Global.System.Drawing.Size(107, 42)
			btnFindNext2.Size = size
			Me.btnFindNext.TabIndex = 8
			Me.btnFindNext.Tag = "CR0011"
			Me.btnFindNext.Text = "Tìm tiếp"
			Me.btnFindNext.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFindNext.UseVisualStyleBackColor = True
			Me.dgvData.AllowUserToAddRows = False
			Me.dgvData.AllowUserToDeleteRows = False
			Me.dgvData.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvData.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvData.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvData As Global.System.Windows.Forms.Control = Me.dgvData
			point = New Global.System.Drawing.Point(0, 37)
			dgvData.Location = point
			Me.dgvData.Name = "dgvData"
			Me.dgvData.RowTemplate.DefaultCellStyle.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 12.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.dgvData.RowTemplate.Height = 28
			Dim dgvData2 As Global.System.Windows.Forms.Control = Me.dgvData
			size = New Global.System.Drawing.Size(934, 395)
			dgvData2.Size = size
			Me.dgvData.TabIndex = 1
			Me.lblFilterDate.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFilterDate As Global.System.Windows.Forms.Control = Me.lblFilterDate
			point = New Global.System.Drawing.Point(2, 9)
			lblFilterDate.Location = point
			Me.lblFilterDate.Name = "lblFilterDate"
			Dim lblFilterDate2 As Global.System.Windows.Forms.Control = Me.lblFilterDate
			size = New Global.System.Drawing.Size(77, 21)
			lblFilterDate2.Size = size
			Me.lblFilterDate.TabIndex = 43
			Me.lblFilterDate.Tag = "CR0017"
			Me.lblFilterDate.Text = "Từ ngày"
			Me.btnCancel.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btnCancel As Global.System.Windows.Forms.Control = Me.btnCancel
			point = New Global.System.Drawing.Point(416, 1)
			btnCancel.Location = point
			Me.btnCancel.Name = "btnCancel"
			Dim btnCancel2 As Global.System.Windows.Forms.Control = Me.btnCancel
			size = New Global.System.Drawing.Size(35, 33)
			btnCancel2.Size = size
			Me.btnCancel.TabIndex = 4
			Me.btnCancel.Tag = ""
			Me.btnCancel.Text = "X"
			Me.btnCancel.UseVisualStyleBackColor = True
			Me.mtxDATE.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim mtxDATE As Global.System.Windows.Forms.Control = Me.mtxDATE
			point = New Global.System.Drawing.Point(80, 2)
			mtxDATE.Location = point
			Me.mtxDATE.Mask = "00/00/0000"
			Me.mtxDATE.Name = "mtxDATE"
			Me.mtxDATE.PromptChar = "-"c
			Dim mtxDATE2 As Global.System.Windows.Forms.Control = Me.mtxDATE
			size = New Global.System.Drawing.Size(124, 30)
			mtxDATE2.Size = size
			Me.mtxDATE.TabIndex = 44
			Me.mtxDATE.Tag = ""
			Me.mtxDATE.ValidatingType = GetType(Global.System.DateTime)
			Me.dtpTuNgay.Font = New Global.System.Drawing.Font("Arial", 15.5F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim dtpTuNgay As Global.System.Windows.Forms.Control = Me.dtpTuNgay
			point = New Global.System.Drawing.Point(203, 2)
			dtpTuNgay.Location = point
			Me.dtpTuNgay.Name = "dtpTuNgay"
			Dim dtpTuNgay2 As Global.System.Windows.Forms.Control = Me.dtpTuNgay
			size = New Global.System.Drawing.Size(20, 31)
			dtpTuNgay2.Size = size
			Me.dtpTuNgay.TabIndex = 47
			Me.lblMA1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMA As Global.System.Windows.Forms.Control = Me.lblMA1
			point = New Global.System.Drawing.Point(503, 9)
			lblMA.Location = point
			Me.lblMA1.Name = "lblMA1"
			Dim lblMA2 As Global.System.Windows.Forms.Control = Me.lblMA1
			size = New Global.System.Drawing.Size(112, 21)
			lblMA2.Size = size
			Me.lblMA1.TabIndex = 60
			Me.lblMA1.Tag = "CR0019"
			Me.lblMA1.Text = "Khách hàng"
			Me.txtTEN1.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.txtTEN1.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Me.txtTEN1.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtTEN As Global.System.Windows.Forms.Control = Me.txtTEN1
			point = New Global.System.Drawing.Point(732, 5)
			txtTEN.Location = point
			Me.txtTEN1.Name = "txtTEN1"
			Dim txtTEN2 As Global.System.Windows.Forms.Control = Me.txtTEN1
			size = New Global.System.Drawing.Size(202, 26)
			txtTEN2.Size = size
			Me.txtTEN1.TabIndex = 59
			Me.txtTEN1.Tag = ""
			Me.btnDM1.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnDM1.Image = CType(componentResourceManager.GetObject("btnDM1.Image"), Global.System.Drawing.Image)
			Dim btnDM As Global.System.Windows.Forms.Control = Me.btnDM1
			point = New Global.System.Drawing.Point(701, 4)
			btnDM.Location = point
			Me.btnDM1.Name = "btnDM1"
			Dim btnDM2 As Global.System.Windows.Forms.Control = Me.btnDM1
			size = New Global.System.Drawing.Size(30, 28)
			btnDM2.Size = size
			Me.btnDM1.TabIndex = 58
			Me.btnDM1.Tag = ""
			Me.btnDM1.UseVisualStyleBackColor = True
			Me.txtMA1.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtMA1.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtMA As Global.System.Windows.Forms.Control = Me.txtMA1
			point = New Global.System.Drawing.Point(620, 5)
			txtMA.Location = point
			Me.txtMA1.Name = "txtMA1"
			Dim txtMA2 As Global.System.Windows.Forms.Control = Me.txtMA1
			size = New Global.System.Drawing.Size(79, 26)
			txtMA2.Size = size
			Me.txtMA1.TabIndex = 57
			Me.txtMA1.Tag = ""
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(229, 7)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(40, 21)
			label2.Size = size
			Me.Label1.TabIndex = 43
			Me.Label1.Tag = "CR0018"
			Me.Label1.Text = "đến"
			Me.mtxTODATE.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim mtxTODATE As Global.System.Windows.Forms.Control = Me.mtxTODATE
			point = New Global.System.Drawing.Point(266, 2)
			mtxTODATE.Location = point
			Me.mtxTODATE.Mask = "00/00/0000"
			Me.mtxTODATE.Name = "mtxTODATE"
			Me.mtxTODATE.PromptChar = "-"c
			Dim mtxTODATE2 As Global.System.Windows.Forms.Control = Me.mtxTODATE
			size = New Global.System.Drawing.Size(124, 30)
			mtxTODATE2.Size = size
			Me.mtxTODATE.TabIndex = 44
			Me.mtxTODATE.Tag = ""
			Me.mtxTODATE.ValidatingType = GetType(Global.System.DateTime)
			Me.dtpDenNgay.Font = New Global.System.Drawing.Font("Arial", 15.5F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim dtpDenNgay As Global.System.Windows.Forms.Control = Me.dtpDenNgay
			point = New Global.System.Drawing.Point(389, 2)
			dtpDenNgay.Location = point
			Me.dtpDenNgay.Name = "dtpDenNgay"
			Dim dtpDenNgay2 As Global.System.Windows.Forms.Control = Me.dtpDenNgay
			size = New Global.System.Drawing.Size(20, 31)
			dtpDenNgay2.Size = size
			Me.dtpDenNgay.TabIndex = 47
			Me.dgvDMDV.AllowUserToAddRows = False
			Me.dgvDMDV.AllowUserToDeleteRows = False
			Me.dgvDMDV.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.dgvDMDV.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvDMDV As Global.System.Windows.Forms.Control = Me.dgvDMDV
			point = New Global.System.Drawing.Point(319, 32)
			dgvDMDV.Location = point
			Me.dgvDMDV.Name = "dgvDMDV"
			Me.dgvDMDV.[ReadOnly] = True
			Dim dgvDMDV2 As Global.System.Windows.Forms.Control = Me.dgvDMDV
			size = New Global.System.Drawing.Size(615, 249)
			dgvDMDV2.Size = size
			Me.dgvDMDV.TabIndex = 117
			Me.dgvDMDV.Visible = False
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(1059, 511)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.dgvDMDV)
			Me.Controls.Add(Me.lblMA1)
			Me.Controls.Add(Me.txtTEN1)
			Me.Controls.Add(Me.btnDM1)
			Me.Controls.Add(Me.txtMA1)
			Me.Controls.Add(Me.dtpDenNgay)
			Me.Controls.Add(Me.dtpTuNgay)
			Me.Controls.Add(Me.mtxTODATE)
			Me.Controls.Add(Me.mtxDATE)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.lblFilterDate)
			Me.Controls.Add(Me.btnCancel)
			Me.Controls.Add(Me.dgvData)
			Me.Controls.Add(Me.grpNavigater)
			Me.Controls.Add(Me.grpControl)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmCusNote"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "frmCusNote"
			Me.WindowState = Global.System.Windows.Forms.FormWindowState.Maximized
			Me.grpNavigater.ResumeLayout(False)
			Me.grpControl.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.dgvDMDV, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x040003B6 RID: 950
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
