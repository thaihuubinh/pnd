﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000036 RID: 54
	<DesignerGenerated()>
	Public Partial Class frmDMAUTOPRICE3
		Inherits Form

		' Token: 0x06000BE2 RID: 3042 RVA: 0x0008BD30 File Offset: 0x00089F30
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMDNKM3_Activated
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMDNKM3_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMDNKM3_Load
			frmDMAUTOPRICE3.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSourceMas = New BindingSource()
			Me.mbdsSourceDel = New BindingSource()
			Me.mdgvMaster = New DataGridView()
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000456 RID: 1110
		' (get) Token: 0x06000BE5 RID: 3045 RVA: 0x0008D6A0 File Offset: 0x0008B8A0
		' (set) Token: 0x06000BE6 RID: 3046 RVA: 0x00004077 File Offset: 0x00002277
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000457 RID: 1111
		' (get) Token: 0x06000BE7 RID: 3047 RVA: 0x0008D6B8 File Offset: 0x0008B8B8
		' (set) Token: 0x06000BE8 RID: 3048 RVA: 0x0008D6D0 File Offset: 0x0008B8D0
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000458 RID: 1112
		' (get) Token: 0x06000BE9 RID: 3049 RVA: 0x0008D73C File Offset: 0x0008B93C
		' (set) Token: 0x06000BEA RID: 3050 RVA: 0x0008D754 File Offset: 0x0008B954
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000459 RID: 1113
		' (get) Token: 0x06000BEB RID: 3051 RVA: 0x0008D7C0 File Offset: 0x0008B9C0
		' (set) Token: 0x06000BEC RID: 3052 RVA: 0x0008D7D8 File Offset: 0x0008B9D8
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x1700045A RID: 1114
		' (get) Token: 0x06000BED RID: 3053 RVA: 0x0008D844 File Offset: 0x0008BA44
		' (set) Token: 0x06000BEE RID: 3054 RVA: 0x00004081 File Offset: 0x00002281
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x1700045B RID: 1115
		' (get) Token: 0x06000BEF RID: 3055 RVA: 0x0008D85C File Offset: 0x0008BA5C
		' (set) Token: 0x06000BF0 RID: 3056 RVA: 0x0008D874 File Offset: 0x0008BA74
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x1700045C RID: 1116
		' (get) Token: 0x06000BF1 RID: 3057 RVA: 0x0008D8E0 File Offset: 0x0008BAE0
		' (set) Token: 0x06000BF2 RID: 3058 RVA: 0x0008D8F8 File Offset: 0x0008BAF8
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x1700045D RID: 1117
		' (get) Token: 0x06000BF3 RID: 3059 RVA: 0x0008D964 File Offset: 0x0008BB64
		' (set) Token: 0x06000BF4 RID: 3060 RVA: 0x0000408B File Offset: 0x0000228B
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x1700045E RID: 1118
		' (get) Token: 0x06000BF5 RID: 3061 RVA: 0x0008D97C File Offset: 0x0008BB7C
		' (set) Token: 0x06000BF6 RID: 3062 RVA: 0x0008D994 File Offset: 0x0008BB94
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x1700045F RID: 1119
		' (get) Token: 0x06000BF7 RID: 3063 RVA: 0x0008DA00 File Offset: 0x0008BC00
		' (set) Token: 0x06000BF8 RID: 3064 RVA: 0x0008DA18 File Offset: 0x0008BC18
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x17000460 RID: 1120
		' (get) Token: 0x06000BF9 RID: 3065 RVA: 0x0008DA84 File Offset: 0x0008BC84
		' (set) Token: 0x06000BFA RID: 3066 RVA: 0x0008DA9C File Offset: 0x0008BC9C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000461 RID: 1121
		' (get) Token: 0x06000BFB RID: 3067 RVA: 0x0008DB08 File Offset: 0x0008BD08
		' (set) Token: 0x06000BFC RID: 3068 RVA: 0x00004095 File Offset: 0x00002295
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x17000462 RID: 1122
		' (get) Token: 0x06000BFD RID: 3069 RVA: 0x0008DB20 File Offset: 0x0008BD20
		' (set) Token: 0x06000BFE RID: 3070 RVA: 0x0000409F File Offset: 0x0000229F
		Friend Overridable Property lblFromTime As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFromTime = value
			End Set
		End Property

		' Token: 0x17000463 RID: 1123
		' (get) Token: 0x06000BFF RID: 3071 RVA: 0x0008DB38 File Offset: 0x0008BD38
		' (set) Token: 0x06000C00 RID: 3072 RVA: 0x000040A9 File Offset: 0x000022A9
		Friend Overridable Property lblTungay As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTungay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTungay = value
			End Set
		End Property

		' Token: 0x17000464 RID: 1124
		' (get) Token: 0x06000C01 RID: 3073 RVA: 0x0008DB50 File Offset: 0x0008BD50
		' (set) Token: 0x06000C02 RID: 3074 RVA: 0x000040B3 File Offset: 0x000022B3
		Friend Overridable Property lblTen As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTen
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTen = value
			End Set
		End Property

		' Token: 0x17000465 RID: 1125
		' (get) Token: 0x06000C03 RID: 3075 RVA: 0x0008DB68 File Offset: 0x0008BD68
		' (set) Token: 0x06000C04 RID: 3076 RVA: 0x000040BD File Offset: 0x000022BD
		Friend Overridable Property txtTen As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTen
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTen = value
			End Set
		End Property

		' Token: 0x17000466 RID: 1126
		' (get) Token: 0x06000C05 RID: 3077 RVA: 0x0008DB80 File Offset: 0x0008BD80
		' (set) Token: 0x06000C06 RID: 3078 RVA: 0x0008DB98 File Offset: 0x0008BD98
		Friend Overridable Property btnPrintMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrintMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrintMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrintMas.Click, AddressOf Me.btnPrintMas_Click
				End If
				Me._btnPrintMas = value
				flag = Me._btnPrintMas IsNot Nothing
				If flag Then
					AddHandler Me._btnPrintMas.Click, AddressOf Me.btnPrintMas_Click
				End If
			End Set
		End Property

		' Token: 0x17000467 RID: 1127
		' (get) Token: 0x06000C07 RID: 3079 RVA: 0x0008DC04 File Offset: 0x0008BE04
		' (set) Token: 0x06000C08 RID: 3080 RVA: 0x0008DC1C File Offset: 0x0008BE1C
		Friend Overridable Property btnDelMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelMas.Click, AddressOf Me.btnDelMas_Click
				End If
				Me._btnDelMas = value
				flag = Me._btnDelMas IsNot Nothing
				If flag Then
					AddHandler Me._btnDelMas.Click, AddressOf Me.btnDelMas_Click
				End If
			End Set
		End Property

		' Token: 0x17000468 RID: 1128
		' (get) Token: 0x06000C09 RID: 3081 RVA: 0x0008DC88 File Offset: 0x0008BE88
		' (set) Token: 0x06000C0A RID: 3082 RVA: 0x0008DCA0 File Offset: 0x0008BEA0
		Friend Overridable Property btnEditMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnEditMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnEditMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnEditMas.Click, AddressOf Me.btnEditMas_Click
				End If
				Me._btnEditMas = value
				flag = Me._btnEditMas IsNot Nothing
				If flag Then
					AddHandler Me._btnEditMas.Click, AddressOf Me.btnEditMas_Click
				End If
			End Set
		End Property

		' Token: 0x17000469 RID: 1129
		' (get) Token: 0x06000C0B RID: 3083 RVA: 0x0008DD0C File Offset: 0x0008BF0C
		' (set) Token: 0x06000C0C RID: 3084 RVA: 0x0008DD24 File Offset: 0x0008BF24
		Friend Overridable Property btnFirstMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirstMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirstMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirstMas.Click, AddressOf Me.btnFirstMas_Click
				End If
				Me._btnFirstMas = value
				flag = Me._btnFirstMas IsNot Nothing
				If flag Then
					AddHandler Me._btnFirstMas.Click, AddressOf Me.btnFirstMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700046A RID: 1130
		' (get) Token: 0x06000C0D RID: 3085 RVA: 0x0008DD90 File Offset: 0x0008BF90
		' (set) Token: 0x06000C0E RID: 3086 RVA: 0x0008DDA8 File Offset: 0x0008BFA8
		Friend Overridable Property btnPreMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreMas.Click, AddressOf Me.btnPreMas_Click
				End If
				Me._btnPreMas = value
				flag = Me._btnPreMas IsNot Nothing
				If flag Then
					AddHandler Me._btnPreMas.Click, AddressOf Me.btnPreMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700046B RID: 1131
		' (get) Token: 0x06000C0F RID: 3087 RVA: 0x0008DE14 File Offset: 0x0008C014
		' (set) Token: 0x06000C10 RID: 3088 RVA: 0x0008DE2C File Offset: 0x0008C02C
		Friend Overridable Property btnNextMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNextMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNextMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNextMas.Click, AddressOf Me.btnNextMas_Click
				End If
				Me._btnNextMas = value
				flag = Me._btnNextMas IsNot Nothing
				If flag Then
					AddHandler Me._btnNextMas.Click, AddressOf Me.btnNextMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700046C RID: 1132
		' (get) Token: 0x06000C11 RID: 3089 RVA: 0x0008DE98 File Offset: 0x0008C098
		' (set) Token: 0x06000C12 RID: 3090 RVA: 0x0008DEB0 File Offset: 0x0008C0B0
		Friend Overridable Property btnLastMas As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLastMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLastMas IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLastMas.Click, AddressOf Me.btnLastMas_Click
				End If
				Me._btnLastMas = value
				flag = Me._btnLastMas IsNot Nothing
				If flag Then
					AddHandler Me._btnLastMas.Click, AddressOf Me.btnLastMas_Click
				End If
			End Set
		End Property

		' Token: 0x1700046D RID: 1133
		' (get) Token: 0x06000C13 RID: 3091 RVA: 0x0008DF1C File Offset: 0x0008C11C
		' (set) Token: 0x06000C14 RID: 3092 RVA: 0x000040C7 File Offset: 0x000022C7
		Friend Overridable Property lblDengio As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDengio
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDengio = value
			End Set
		End Property

		' Token: 0x1700046E RID: 1134
		' (get) Token: 0x06000C15 RID: 3093 RVA: 0x0008DF34 File Offset: 0x0008C134
		' (set) Token: 0x06000C16 RID: 3094 RVA: 0x000040D1 File Offset: 0x000022D1
		Friend Overridable Property lblDenngay As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblDenngay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblDenngay = value
			End Set
		End Property

		' Token: 0x1700046F RID: 1135
		' (get) Token: 0x06000C17 RID: 3095 RVA: 0x0008DF4C File Offset: 0x0008C14C
		' (set) Token: 0x06000C18 RID: 3096 RVA: 0x000040DB File Offset: 0x000022DB
		Friend Overridable Property mtxFromDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxFromDate = value
			End Set
		End Property

		' Token: 0x17000470 RID: 1136
		' (get) Token: 0x06000C19 RID: 3097 RVA: 0x0008DF64 File Offset: 0x0008C164
		' (set) Token: 0x06000C1A RID: 3098 RVA: 0x000040E5 File Offset: 0x000022E5
		Friend Overridable Property mtxToDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxToDate = value
			End Set
		End Property

		' Token: 0x17000471 RID: 1137
		' (get) Token: 0x06000C1B RID: 3099 RVA: 0x0008DF7C File Offset: 0x0008C17C
		' (set) Token: 0x06000C1C RID: 3100 RVA: 0x000040EF File Offset: 0x000022EF
		Friend Overridable Property mtxFromTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxFromTime = value
			End Set
		End Property

		' Token: 0x17000472 RID: 1138
		' (get) Token: 0x06000C1D RID: 3101 RVA: 0x0008DF94 File Offset: 0x0008C194
		' (set) Token: 0x06000C1E RID: 3102 RVA: 0x000040F9 File Offset: 0x000022F9
		Friend Overridable Property mtxToTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtxToTime = value
			End Set
		End Property

		' Token: 0x17000473 RID: 1139
		' (get) Token: 0x06000C1F RID: 3103 RVA: 0x0008DFAC File Offset: 0x0008C1AC
		' (set) Token: 0x06000C20 RID: 3104 RVA: 0x00004103 File Offset: 0x00002303
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000474 RID: 1140
		' (get) Token: 0x06000C21 RID: 3105 RVA: 0x0008DFC4 File Offset: 0x0008C1C4
		' (set) Token: 0x06000C22 RID: 3106 RVA: 0x0008DFDC File Offset: 0x0008C1DC
		Friend Overridable Property btnAddAll As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddAll IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddAll.Click, AddressOf Me.btnAddAll_Click
				End If
				Me._btnAddAll = value
				flag = Me._btnAddAll IsNot Nothing
				If flag Then
					AddHandler Me._btnAddAll.Click, AddressOf Me.btnAddAll_Click
				End If
			End Set
		End Property

		' Token: 0x17000475 RID: 1141
		' (get) Token: 0x06000C23 RID: 3107 RVA: 0x0008E048 File Offset: 0x0008C248
		' (set) Token: 0x06000C24 RID: 3108 RVA: 0x0008E060 File Offset: 0x0008C260
		Private Overridable Property mbdsSourceMas As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceMas
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceMas IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceMas.PositionChanged, AddressOf Me.mbdsSourceMas_PositionChanged
				End If
				Me._mbdsSourceMas = value
				flag = Me._mbdsSourceMas IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceMas.PositionChanged, AddressOf Me.mbdsSourceMas_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000476 RID: 1142
		' (get) Token: 0x06000C25 RID: 3109 RVA: 0x0008E0CC File Offset: 0x0008C2CC
		' (set) Token: 0x06000C26 RID: 3110 RVA: 0x0008E0E4 File Offset: 0x0008C2E4
		Private Overridable Property mbdsSourceDel As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSourceDel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSourceDel IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSourceDel.PositionChanged, AddressOf Me.mbdsSourceDel_PositionChanged
				End If
				Me._mbdsSourceDel = value
				flag = Me._mbdsSourceDel IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSourceDel.PositionChanged, AddressOf Me.mbdsSourceDel_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000477 RID: 1143
		' (get) Token: 0x06000C27 RID: 3111 RVA: 0x0008E150 File Offset: 0x0008C350
		' (set) Token: 0x06000C28 RID: 3112 RVA: 0x0000410D File Offset: 0x0000230D
		Public Property pdgvMaster As DataGridView
			Get
				Return Me.mdgvMaster
			End Get
			Set(value As DataGridView)
				Me.mdgvMaster = value
			End Set
		End Property

		' Token: 0x17000478 RID: 1144
		' (get) Token: 0x06000C29 RID: 3113 RVA: 0x0008E168 File Offset: 0x0008C368
		' (set) Token: 0x06000C2A RID: 3114 RVA: 0x00004118 File Offset: 0x00002318
		Public Property pbdsSource As BindingSource
			Get
				Return Me.mbdsSourceMas
			End Get
			Set(value As BindingSource)
				Me.mbdsSourceMas = value
			End Set
		End Property

		' Token: 0x17000479 RID: 1145
		' (get) Token: 0x06000C2B RID: 3115 RVA: 0x0008E180 File Offset: 0x0008C380
		' (set) Token: 0x06000C2C RID: 3116 RVA: 0x00004124 File Offset: 0x00002324
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x1700047A RID: 1146
		' (get) Token: 0x06000C2D RID: 3117 RVA: 0x0008E198 File Offset: 0x0008C398
		' (set) Token: 0x06000C2E RID: 3118 RVA: 0x0000412F File Offset: 0x0000232F
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06000C2F RID: 3119 RVA: 0x0008E1B0 File Offset: 0x0008C3B0
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C30 RID: 3120 RVA: 0x0008E280 File Offset: 0x0008C480
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceDel.Position
				Dim flag As Boolean = position < Me.mbdsSourceDel.Count - 1
				If flag Then
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					mbdsSourceDel.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C31 RID: 3121 RVA: 0x0008E370 File Offset: 0x0008C570
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceDel.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					mbdsSourceDel.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C32 RID: 3122 RVA: 0x0008E454 File Offset: 0x0008C654
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSourceDel.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(2, Me.mbdsSourceDel.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C33 RID: 3123 RVA: 0x0008E518 File Offset: 0x0008C718
		Private Sub btnLastMas_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSourceMas.Position = Me.mbdsSourceMas.Count - 1
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLastMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C34 RID: 3124 RVA: 0x0008E5CC File Offset: 0x0008C7CC
		Private Sub btnNextMas_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceMas.Position
				Dim flag As Boolean = position < Me.mbdsSourceMas.Count - 1
				If flag Then
					Dim mbdsSourceMas As BindingSource = Me.mbdsSourceMas
					mbdsSourceMas.Position += 1
				End If
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNextMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C35 RID: 3125 RVA: 0x0008E6A8 File Offset: 0x0008C8A8
		Private Sub btnPreMas_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSourceMas.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSourceMas As BindingSource = Me.mbdsSourceMas
					mbdsSourceMas.Position -= 1
				End If
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C36 RID: 3126 RVA: 0x0008E778 File Offset: 0x0008C978
		Private Sub btnFirstMas_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSourceMas.Position = 0
				Dim b As Byte = Me.fShow_DatainText()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirstMas_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C37 RID: 3127 RVA: 0x0000413A File Offset: 0x0000233A
		Private Sub frmDMDNKM3_Activated(sender As Object, e As EventArgs)
			Me.fGetData_4Grid()
			Me.fShow_DatainText()
		End Sub

		' Token: 0x06000C38 RID: 3128 RVA: 0x0008E820 File Offset: 0x0008CA20
		Private Sub frmDMDNKM3_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM3_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C39 RID: 3129 RVA: 0x0008E8B8 File Offset: 0x0008CAB8
		Private Sub frmDMDNKM3_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mbdsSourceMas_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					b = Me.fShow_DatainText()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM3_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C3A RID: 3130 RVA: 0x0008E9D4 File Offset: 0x0008CBD4
		Private Sub mbdsSourceDel_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSourceDel.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSourceDel As BindingSource = Me.mbdsSourceDel
					Me.lblPosition.Text = (mbdsSourceDel.Position + 1).ToString() + " / " + mbdsSourceDel.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceDel_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C3B RID: 3131 RVA: 0x0008EADC File Offset: 0x0008CCDC
		Private Sub mbdsSourceMas_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSourceMas.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButtonMas(True)
				Else
					Dim b As Byte = Me.fDisableButtonMas(False)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSourceMas_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C3C RID: 3132 RVA: 0x0008EB98 File Offset: 0x0008CD98
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C3D RID: 3133 RVA: 0x0008EC30 File Offset: 0x0008CE30
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = Me.fAdd_frmDOCUMENT4()
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0
				If flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Find("KHOACHINH", text)
						Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C3E RID: 3134 RVA: 0x0008ED64 File Offset: 0x0008CF64
		Private Sub btnAddAll_Click(sender As Object, e As EventArgs)
			Dim clsConnect As clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMHH")
			Dim clsConnect2 As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(5) {}
			Try
				Dim text As String = Interaction.InputBox(Me.mArrStrFrmMess(40), "", "", -1, -1)
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0 AndAlso Conversion.Val(text) > 0.0 AndAlso clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
				If flag Then
					Dim num As Long = 0L
					Dim num2 As Long = CLng((clsConnect.Rows.Count - 1))
					Dim num3 As Long = num
					While True
						Dim num4 As Long = num3
						Dim num5 As Long = num2
						If num4 > num5 Then
							Exit For
						End If
						array(0) = sqlCommand.CreateParameter()
						array(0).ParameterName = "@pnchMAAUTOPRICE"
						array(0).Value = Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, "")
						array(1) = sqlCommand.CreateParameter()
						array(1).ParameterName = "@pnchMAHH"
						array(1).Value = clsConnect.Rows(CInt(num3))("OBJID").ToString().Trim()
						array(2) = sqlCommand.CreateParameter()
						array(2).ParameterName = "@pnchMADVT"
						array(2).Value = clsConnect.Rows(CInt(num3))("MADVT").ToString().Trim()
						array(3) = sqlCommand.CreateParameter()
						array(3).ParameterName = "@ptniLEVEL"
						array(3).Value = CInt((CByte(Math.Round(Conversion.Val(text))) - 1))
						array(4) = sqlCommand.CreateParameter()
						array(4).ParameterName = "@int_Result"
						array(4).Direction = ParameterDirection.ReturnValue
						Dim flag2 As Boolean
						clsConnect2 = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMAUTOPRICE_INSERT_DETAIL", flag2)
						Dim num6 As Integer = Conversions.ToInteger(array(4).Value)
						num3 += 1L
					End While
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSourceDel.Position = Me.mbdsSourceDel.Find("KHOACHINH", text)
						Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAddAll_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
				sqlCommand.Dispose()
				clsConnect2.Dispose()
			End Try
		End Sub

		' Token: 0x06000C3F RID: 3135 RVA: 0x0008F0C8 File Offset: 0x0008D2C8
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Try
				Me.fModify_frmDOCUMENT4()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000C40 RID: 3136 RVA: 0x0008F154 File Offset: 0x0008D354
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fDelete_frmDOCUMENT4()
				Dim flag As Boolean = b = 0
				If Not flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSourceDel_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000C41 RID: 3137 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnPrintMas_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06000C42 RID: 3138 RVA: 0x0008F238 File Offset: 0x0008D438
		Private Sub btnDelMas_Click(sender As Object, e As EventArgs)
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE2 = New frmDMAUTOPRICE2()
			Try
				Dim frmDMAUTOPRICE2 As frmDMAUTOPRICE2 = frmDMAUTOPRICE
				frmDMAUTOPRICE2.pbytFromStatus = 4
				frmDMAUTOPRICE2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMAUTOPRICE2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMAUTOPRICE2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("MAKH").Value, ""))
				frmDMAUTOPRICE2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMAUTOPRICE2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMAUTOPRICE2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMAUTOPRICE2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMAUTOPRICE2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
				frmDMAUTOPRICE.ShowDialog()
				Dim flag As Boolean = frmDMAUTOPRICE.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = mdlVariable.gfrmDMAUTOPRICE1.gfGetData_4Grid()
					flag = b <> 0
					If flag Then
						Me.fShow_DatainText()
					End If
					Me.Close()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMAUTOPRICE.Dispose()
			End Try
		End Sub

		' Token: 0x06000C43 RID: 3139 RVA: 0x0008F724 File Offset: 0x0008D924
		Private Sub btnEditMas_Click(sender As Object, e As EventArgs)
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE2 = New frmDMAUTOPRICE2()
			Try
				Dim frmDMAUTOPRICE2 As frmDMAUTOPRICE2 = frmDMAUTOPRICE
				frmDMAUTOPRICE2.pbytFromStatus = 3
				frmDMAUTOPRICE2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMAUTOPRICE2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMAUTOPRICE2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("MAKH").Value, ""))
				frmDMAUTOPRICE2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMAUTOPRICE2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMAUTOPRICE2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMAUTOPRICE2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMAUTOPRICE2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.pdgvMaster.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
				frmDMAUTOPRICE.ShowDialog()
				Dim flag As Boolean = frmDMAUTOPRICE.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = mdlVariable.gfrmDMAUTOPRICE1.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						Me.fShow_DatainText()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMAUTOPRICE.Dispose()
			End Try
		End Sub

		' Token: 0x06000C44 RID: 3140 RVA: 0x0008FC28 File Offset: 0x0008DE28
		Private Function fModify_frmDOCUMENT4() As Byte
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE4 = New frmDMAUTOPRICE4()
			Dim b As Byte
			Try
				b = 0
				frmDMAUTOPRICE.pbytFromStatus = 3
				Dim flag As Boolean = Me.dgvData.RowCount > 0
				If flag Then
					frmDMAUTOPRICE.txtMAHH.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAHH").Value, ""))
					frmDMAUTOPRICE.txtMADVT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MADVT").Value, ""))
					frmDMAUTOPRICE.pBytLevelPrice = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("MUCGIA").Value)
				End If
				frmDMAUTOPRICE.pStrMAAUTOPRICE = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMAUTOPRICE.ShowDialog()
				flag = frmDMAUTOPRICE.pbytSuccess = 0
				If Not flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fModify_frmDOCUMENT4 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMAUTOPRICE.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000C45 RID: 3141 RVA: 0x0008FDF0 File Offset: 0x0008DFF0
		Private Function fDelete_frmDOCUMENT4() As Byte
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE4 = New frmDMAUTOPRICE4()
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = Me.dgvData.RowCount <= 0
				If Not flag Then
					frmDMAUTOPRICE.txtMAHH.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAHH").Value, ""))
					frmDMAUTOPRICE.txtMADVT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MADVT").Value, ""))
					frmDMAUTOPRICE.pBytLevelPrice = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("MUCGIA").Value)
					frmDMAUTOPRICE.pbytFromStatus = 4
					frmDMAUTOPRICE.pStrMAAUTOPRICE = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
					frmDMAUTOPRICE.ShowDialog()
					flag = frmDMAUTOPRICE.pbytSuccess = 0
					If Not flag Then
						b = 1
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDelete_frmDOCUMENT4 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMAUTOPRICE.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000C46 RID: 3142 RVA: 0x0008FFC0 File Offset: 0x0008E1C0
		Private Function fAdd_frmDOCUMENT4() As String
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE4 = New frmDMAUTOPRICE4()
			Dim text As String = ""
			Try
				frmDMAUTOPRICE.pbytFromStatus = 1
				frmDMAUTOPRICE.pStrMAAUTOPRICE = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))
				frmDMAUTOPRICE.ShowDialog()
				Dim flag As Boolean = frmDMAUTOPRICE.pbytSuccess = 0
				If Not flag Then
					text = frmDMAUTOPRICE.pStrFilter
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAdd_frmDOCUMENT4 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMAUTOPRICE.Dispose()
			End Try
			Return text
		End Function

		' Token: 0x06000C47 RID: 3143 RVA: 0x000900C4 File Offset: 0x0008E2C4
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("MAHH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("MAHH").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("MAHH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENHH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("TENHH").Width = 250
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENHH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENDVT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(28))
				dgvData.Columns("TENDVT").Width = 70
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENDVT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MUCGIA").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("MUCGIA").Width = Me.Width - 450 - Me.grpControl.Width - 10
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("MUCGIA").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("KHOACHINH").Visible = False
				dgvData.Columns("MAAUTOPRICE").Visible = False
				dgvData.Columns("MADVT").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C48 RID: 3144 RVA: 0x000903C8 File Offset: 0x0008E5C8
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C49 RID: 3145 RVA: 0x000904D0 File Offset: 0x0008E6D0
		Private Function fDisableButtonMas(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirstMas.Enabled = Not pblnDisable
				Me.btnLastMas.Enabled = Not pblnDisable
				Me.btnPreMas.Enabled = Not pblnDisable
				Me.btnNextMas.Enabled = Not pblnDisable
				Me.btnPrintMas.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButtonMas ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C4A RID: 3146 RVA: 0x000905B8 File Offset: 0x0008E7B8
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim b As Byte
			Try
				b = 0
				Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
				Dim text As String = "SP_FRMDMAUTOPRICE2_GET_DATA"
				Dim num As Integer
				Dim flag As Boolean = num <> 0
				Dim clsConnect2 As clsConnect = New clsConnect(gStrConISDANHMUC, text, flag)
				num = If((-If((flag > False), 1, 0)), 1, 0)
				clsConnect = clsConnect2
				Me.mbdsSourceDel.DataSource = clsConnect
				Me.dgvData.DataSource = Me.mbdsSourceDel
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000C4B RID: 3147 RVA: 0x000906A0 File Offset: 0x0008E8A0
		Private Function fShow_DatainText() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.txtTen.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJNAME").Value, ""))
				Me.mtxFromDate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("TUNGAY").Value, ""))
				Me.mtxToDate.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("DENNGAY").Value, ""))
				Me.mtxFromTime.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("TUGIO").Value, ""))
				Me.mtxToTime.Text = Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("DENGIO").Value, ""))
				Me.mbdsSourceDel.Filter = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("MAAUTOPRICE ='", Me.mdgvMaster.CurrentRow.Cells("OBJID").Value), ""), "'"))
				mdlUIForm.gsSetCap_2Form(Me, String.Concat(New String() { Me.mArrStrFrmMess(2), " ", Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))), Me.mArrStrFrmMess(16), " [", mdlVariable.gstrStockName, "]" }))
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fShow_DatainText ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C4C RID: 3148 RVA: 0x00090948 File Offset: 0x0008EB48
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.txtTen.[ReadOnly] = True
				Me.mtxFromDate.[ReadOnly] = True
				Me.mtxToDate.[ReadOnly] = True
				Me.mtxFromTime.[ReadOnly] = True
				Me.mtxToTime.[ReadOnly] = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C4D RID: 3149 RVA: 0x00090A3C File Offset: 0x0008EC3C
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, String.Concat(New String() { Me.mArrStrFrmMess(2), " ", Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, ""))), Me.mArrStrFrmMess(16), " [", mdlVariable.gstrStockName, "]" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000C4E RID: 3150 RVA: 0x00090BD8 File Offset: 0x0008EDD8
		Private Function fDeleteDatail() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMADNKM"
				array(0).Value = Operators.ConcatenateObject(Me.mdgvMaster.CurrentRow.Cells("OBJID").Value, "")
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_DEL_DETAIL", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000C4F RID: 3151 RVA: 0x00090D64 File Offset: 0x0008EF64
		Private Sub sClear_Form()
			Try
				Me.mbdsSourceDel.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0400052C RID: 1324
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400052E RID: 1326
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x0400052F RID: 1327
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000530 RID: 1328
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000531 RID: 1329
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000532 RID: 1330
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000533 RID: 1331
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000534 RID: 1332
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000535 RID: 1333
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000536 RID: 1334
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000537 RID: 1335
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000538 RID: 1336
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000539 RID: 1337
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x0400053A RID: 1338
		<AccessedThroughProperty("lblFromTime")>
		Private _lblFromTime As Label

		' Token: 0x0400053B RID: 1339
		<AccessedThroughProperty("lblTungay")>
		Private _lblTungay As Label

		' Token: 0x0400053C RID: 1340
		<AccessedThroughProperty("lblTen")>
		Private _lblTen As Label

		' Token: 0x0400053D RID: 1341
		<AccessedThroughProperty("txtTen")>
		Private _txtTen As TextBox

		' Token: 0x0400053E RID: 1342
		<AccessedThroughProperty("btnPrintMas")>
		Private _btnPrintMas As Button

		' Token: 0x0400053F RID: 1343
		<AccessedThroughProperty("btnDelMas")>
		Private _btnDelMas As Button

		' Token: 0x04000540 RID: 1344
		<AccessedThroughProperty("btnEditMas")>
		Private _btnEditMas As Button

		' Token: 0x04000541 RID: 1345
		<AccessedThroughProperty("btnFirstMas")>
		Private _btnFirstMas As Button

		' Token: 0x04000542 RID: 1346
		<AccessedThroughProperty("btnPreMas")>
		Private _btnPreMas As Button

		' Token: 0x04000543 RID: 1347
		<AccessedThroughProperty("btnNextMas")>
		Private _btnNextMas As Button

		' Token: 0x04000544 RID: 1348
		<AccessedThroughProperty("btnLastMas")>
		Private _btnLastMas As Button

		' Token: 0x04000545 RID: 1349
		<AccessedThroughProperty("lblDengio")>
		Private _lblDengio As Label

		' Token: 0x04000546 RID: 1350
		<AccessedThroughProperty("lblDenngay")>
		Private _lblDenngay As Label

		' Token: 0x04000547 RID: 1351
		<AccessedThroughProperty("mtxFromDate")>
		Private _mtxFromDate As MaskedTextBox

		' Token: 0x04000548 RID: 1352
		<AccessedThroughProperty("mtxToDate")>
		Private _mtxToDate As MaskedTextBox

		' Token: 0x04000549 RID: 1353
		<AccessedThroughProperty("mtxFromTime")>
		Private _mtxFromTime As MaskedTextBox

		' Token: 0x0400054A RID: 1354
		<AccessedThroughProperty("mtxToTime")>
		Private _mtxToTime As MaskedTextBox

		' Token: 0x0400054B RID: 1355
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x0400054C RID: 1356
		<AccessedThroughProperty("btnAddAll")>
		Private _btnAddAll As Button

		' Token: 0x0400054D RID: 1357
		Private mArrStrFrmMess As String()

		' Token: 0x0400054E RID: 1358
		Private mStrOBJID As String

		' Token: 0x0400054F RID: 1359
		Private mStrMAKM As String

		' Token: 0x04000550 RID: 1360
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000551 RID: 1361
		<AccessedThroughProperty("mbdsSourceMas")>
		Private _mbdsSourceMas As BindingSource

		' Token: 0x04000552 RID: 1362
		<AccessedThroughProperty("mbdsSourceDel")>
		Private _mbdsSourceDel As BindingSource

		' Token: 0x04000553 RID: 1363
		Private mdgvMaster As DataGridView

		' Token: 0x04000554 RID: 1364
		Private marrDrFind As DataRow()

		' Token: 0x04000555 RID: 1365
		Private mintFindLastPos As Integer
	End Class
End Namespace
