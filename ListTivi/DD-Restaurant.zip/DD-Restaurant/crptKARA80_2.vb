﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x0200011F RID: 287
	Public Class crptKARA80_2
		Inherits ReportClass

		' Token: 0x0600578D RID: 22413 RVA: 0x0000F056 File Offset: 0x0000D256
		Public Sub New()
			crptKARA80_2.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001F9F RID: 8095
		' (get) Token: 0x0600578E RID: 22414 RVA: 0x004DAF48 File Offset: 0x004D9148
		' (set) Token: 0x0600578F RID: 22415 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crptKARA80_2.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001FA0 RID: 8096
		' (get) Token: 0x06005790 RID: 22416 RVA: 0x004DA738 File Offset: 0x004D8938
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section1 As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001FA1 RID: 8097
		' (get) Token: 0x06005791 RID: 22417 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section2 As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001FA2 RID: 8098
		' (get) Token: 0x06005792 RID: 22418 RVA: 0x004DA780 File Offset: 0x004D8980
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section3 As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001FA3 RID: 8099
		' (get) Token: 0x06005793 RID: 22419 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section4 As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001FA4 RID: 8100
		' (get) Token: 0x06005794 RID: 22420 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x04002717 RID: 10007
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
