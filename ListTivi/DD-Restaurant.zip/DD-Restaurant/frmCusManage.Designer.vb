﻿Namespace prjIS_SalesPOS
	' Token: 0x0200002B RID: 43
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCusManage
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600084C RID: 2124 RVA: 0x00060818 File Offset: 0x0005EA18
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600084D RID: 2125 RVA: 0x00060850 File Offset: 0x0005EA50
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Global.System.ComponentModel.Container()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCusManage))
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.ContextMenuStrip1 = New Global.System.Windows.Forms.ContextMenuStrip(Me.components)
			Me.tmrRight = New Global.System.Windows.Forms.Timer(Me.components)
			Me.lblTitle = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.lblExit = New Global.System.Windows.Forms.Label()
			Me.GroupBox1 = New Global.System.Windows.Forms.GroupBox()
			Me.mtbToDate = New Global.System.Windows.Forms.MaskedTextBox()
			Me.mtbFromDate = New Global.System.Windows.Forms.MaskedTextBox()
			Me.lblToDate = New Global.System.Windows.Forms.Label()
			Me.lblFromDate = New Global.System.Windows.Forms.Label()
			Me.dtpDenNgay = New Global.System.Windows.Forms.DateTimePicker()
			Me.dtpTuNgay = New Global.System.Windows.Forms.DateTimePicker()
			Me.btnChuyenNhomDV = New Global.System.Windows.Forms.Button()
			Me.GroupBox1.SuspendLayout()
			Me.SuspendLayout()
			Me.btnExit.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(469, 430)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(147, 41)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 4
			Me.btnExit.Tag = "C00006"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = False
			Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
			Dim contextMenuStrip As Global.System.Windows.Forms.Control = Me.ContextMenuStrip1
			size = New Global.System.Drawing.Size(61, 4)
			contextMenuStrip.Size = size
			Me.tmrRight.Interval = 40
			Me.lblTitle.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.lblTitle.BackColor = Global.System.Drawing.Color.Gray
			Me.lblTitle.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblTitle.ForeColor = Global.System.Drawing.Color.White
			Dim lblTitle As Global.System.Windows.Forms.Control = Me.lblTitle
			point = New Global.System.Drawing.Point(0, 1)
			lblTitle.Location = point
			Me.lblTitle.Name = "lblTitle"
			Dim lblTitle2 As Global.System.Windows.Forms.Control = Me.lblTitle
			size = New Global.System.Drawing.Size(621, 30)
			lblTitle2.Size = size
			Me.lblTitle.TabIndex = 5
			Me.lblTitle.Tag = "CB0007"
			Me.lblTitle.Text = "Quản lý khách hàng"
			Me.lblTitle.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label2.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.Label2.BackColor = Global.System.Drawing.Color.Gray
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label2.ForeColor = Global.System.Drawing.Color.White
			Dim label As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(-5, 475)
			label.Location = point
			Me.Label2.Name = "Label2"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(628, 5)
			label2.Size = size
			Me.Label2.TabIndex = 6
			Me.Label2.Tag = ""
			Me.Label2.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lblExit.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lblExit.ForeColor = Global.System.Drawing.Color.Red
			Dim lblExit As Global.System.Windows.Forms.Control = Me.lblExit
			point = New Global.System.Drawing.Point(584, 3)
			lblExit.Location = point
			Me.lblExit.Name = "lblExit"
			Dim lblExit2 As Global.System.Windows.Forms.Control = Me.lblExit
			size = New Global.System.Drawing.Size(35, 26)
			lblExit2.Size = size
			Me.lblExit.TabIndex = 7
			Me.lblExit.Text = "X"
			Me.lblExit.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.GroupBox1.Controls.Add(Me.btnChuyenNhomDV)
			Me.GroupBox1.Controls.Add(Me.mtbToDate)
			Me.GroupBox1.Controls.Add(Me.mtbFromDate)
			Me.GroupBox1.Controls.Add(Me.lblToDate)
			Me.GroupBox1.Controls.Add(Me.lblFromDate)
			Me.GroupBox1.Controls.Add(Me.dtpDenNgay)
			Me.GroupBox1.Controls.Add(Me.dtpTuNgay)
			Me.GroupBox1.Font = New Global.System.Drawing.Font("Arial", 10F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim groupBox As Global.System.Windows.Forms.Control = Me.GroupBox1
			point = New Global.System.Drawing.Point(3, 51)
			groupBox.Location = point
			Me.GroupBox1.Name = "GroupBox1"
			Dim groupBox2 As Global.System.Windows.Forms.Control = Me.GroupBox1
			size = New Global.System.Drawing.Size(613, 103)
			groupBox2.Size = size
			Me.GroupBox1.TabIndex = 8
			Me.GroupBox1.TabStop = False
			Me.GroupBox1.Tag = "CR0002"
			Me.GroupBox1.Text = "Chuyển khách hàng xuống nhóm thấp hơn khi không có giao dịch trong khoảng thời gian"
			Me.mtbToDate.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim mtbToDate As Global.System.Windows.Forms.Control = Me.mtbToDate
			point = New Global.System.Drawing.Point(130, 63)
			mtbToDate.Location = point
			Me.mtbToDate.Mask = "00/00/0000"
			Me.mtbToDate.Name = "mtbToDate"
			Dim mtbToDate2 As Global.System.Windows.Forms.Control = Me.mtbToDate
			size = New Global.System.Drawing.Size(108, 30)
			mtbToDate2.Size = size
			Me.mtbToDate.TabIndex = 16
			Me.mtbToDate.ValidatingType = GetType(Global.System.DateTime)
			Me.mtbFromDate.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.mtbFromDate.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.mtbFromDate.ImeMode = Global.System.Windows.Forms.ImeMode.NoControl
			Dim mtbFromDate As Global.System.Windows.Forms.Control = Me.mtbFromDate
			point = New Global.System.Drawing.Point(130, 27)
			mtbFromDate.Location = point
			Me.mtbFromDate.Mask = "00/00/0000"
			Me.mtbFromDate.Name = "mtbFromDate"
			Dim mtbFromDate2 As Global.System.Windows.Forms.Control = Me.mtbFromDate
			size = New Global.System.Drawing.Size(108, 30)
			mtbFromDate2.Size = size
			Me.mtbFromDate.TabIndex = 15
			Me.mtbFromDate.ValidatingType = GetType(Global.System.DateTime)
			Me.lblToDate.AutoSize = True
			Me.lblToDate.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblToDate As Global.System.Windows.Forms.Control = Me.lblToDate
			point = New Global.System.Drawing.Point(24, 66)
			lblToDate.Location = point
			Me.lblToDate.Name = "lblToDate"
			Dim lblToDate2 As Global.System.Windows.Forms.Control = Me.lblToDate
			size = New Global.System.Drawing.Size(74, 18)
			lblToDate2.Size = size
			Me.lblToDate.TabIndex = 18
			Me.lblToDate.Tag = "CR0004"
			Me.lblToDate.Text = "Đến ngày"
			Me.lblFromDate.AutoSize = True
			Me.lblFromDate.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFromDate As Global.System.Windows.Forms.Control = Me.lblFromDate
			point = New Global.System.Drawing.Point(24, 31)
			lblFromDate.Location = point
			Me.lblFromDate.Name = "lblFromDate"
			Dim lblFromDate2 As Global.System.Windows.Forms.Control = Me.lblFromDate
			size = New Global.System.Drawing.Size(65, 18)
			lblFromDate2.Size = size
			Me.lblFromDate.TabIndex = 17
			Me.lblFromDate.Tag = "CR0003"
			Me.lblFromDate.Text = "Từ ngày"
			Me.dtpDenNgay.Font = New Global.System.Drawing.Font("Arial", 15.5F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim dtpDenNgay As Global.System.Windows.Forms.Control = Me.dtpDenNgay
			point = New Global.System.Drawing.Point(238, 62)
			dtpDenNgay.Location = point
			Me.dtpDenNgay.Name = "dtpDenNgay"
			Dim dtpDenNgay2 As Global.System.Windows.Forms.Control = Me.dtpDenNgay
			size = New Global.System.Drawing.Size(20, 31)
			dtpDenNgay2.Size = size
			Me.dtpDenNgay.TabIndex = 21
			Me.dtpTuNgay.Font = New Global.System.Drawing.Font("Arial", 15.5F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim dtpTuNgay As Global.System.Windows.Forms.Control = Me.dtpTuNgay
			point = New Global.System.Drawing.Point(238, 27)
			dtpTuNgay.Location = point
			Me.dtpTuNgay.Name = "dtpTuNgay"
			Dim dtpTuNgay2 As Global.System.Windows.Forms.Control = Me.dtpTuNgay
			size = New Global.System.Drawing.Size(20, 31)
			dtpTuNgay2.Size = size
			Me.dtpTuNgay.TabIndex = 20
			Me.btnChuyenNhomDV.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Dim btnChuyenNhomDV As Global.System.Windows.Forms.Control = Me.btnChuyenNhomDV
			point = New Global.System.Drawing.Point(466, 56)
			btnChuyenNhomDV.Location = point
			Me.btnChuyenNhomDV.Name = "btnChuyenNhomDV"
			Dim btnChuyenNhomDV2 As Global.System.Windows.Forms.Control = Me.btnChuyenNhomDV
			size = New Global.System.Drawing.Size(140, 41)
			btnChuyenNhomDV2.Size = size
			Me.btnChuyenNhomDV.TabIndex = 9
			Me.btnChuyenNhomDV.Tag = "C00005"
			Me.btnChuyenNhomDV.Text = "Thực hiện"
			Me.btnChuyenNhomDV.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnChuyenNhomDV.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			Me.BackColor = Global.System.Drawing.Color.FromArgb(224, 224, 224)
			size = New Global.System.Drawing.Size(621, 478)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.GroupBox1)
			Me.Controls.Add(Me.lblExit)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.lblTitle)
			Me.Controls.Add(Me.btnExit)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Me.KeyPreview = True
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmCusManage"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "kh"
			Me.GroupBox1.ResumeLayout(False)
			Me.GroupBox1.PerformLayout()
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x040003A5 RID: 933
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
