﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000140 RID: 320
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptChiTietNVL2
		Inherits Component
		Implements ICachedReport

		' Token: 0x060058D6 RID: 22742 RVA: 0x0000F59F File Offset: 0x0000D79F
		Public Sub New()
			CachedrptChiTietNVL2.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002045 RID: 8261
		' (get) Token: 0x060058D7 RID: 22743 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060058D8 RID: 22744 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002046 RID: 8262
		' (get) Token: 0x060058D9 RID: 22745 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060058DA RID: 22746 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002047 RID: 8263
		' (get) Token: 0x060058DB RID: 22747 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060058DC RID: 22748 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x060058DD RID: 22749 RVA: 0x004DB360 File Offset: 0x004D9560
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptChiTietNVL2() With { .Site = Me.Site }
		End Function

		' Token: 0x060058DE RID: 22750 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002738 RID: 10040
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
