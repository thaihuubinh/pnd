﻿Imports System
Imports System.Diagnostics

Namespace prjIS_SalesPOS
	' Token: 0x02000080 RID: 128
	Public Class ChkItem
		' Token: 0x060027FA RID: 10234 RVA: 0x00007789 File Offset: 0x00005989
		<DebuggerNonUserCode()>
		Public Sub New()
		End Sub

		' Token: 0x0400103C RID: 4156
		Public Text As String

		' Token: 0x0400103D RID: 4157
		Public ID As String
	End Class
End Namespace
