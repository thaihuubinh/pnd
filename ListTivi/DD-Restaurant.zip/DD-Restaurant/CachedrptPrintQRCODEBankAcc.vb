﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020001B2 RID: 434
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptPrintQRCODEBankAcc
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005D44 RID: 23876 RVA: 0x000107E1 File Offset: 0x0000E9E1
		Public Sub New()
			CachedrptPrintQRCODEBankAcc.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002279 RID: 8825
		' (get) Token: 0x06005D45 RID: 23877 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005D46 RID: 23878 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700227A RID: 8826
		' (get) Token: 0x06005D47 RID: 23879 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005D48 RID: 23880 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700227B RID: 8827
		' (get) Token: 0x06005D49 RID: 23881 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005D4A RID: 23882 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005D4B RID: 23883 RVA: 0x004DC1A0 File Offset: 0x004DA3A0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptPrintQRCODEBankAcc() With { .Site = Me.Site }
		End Function

		' Token: 0x06005D4C RID: 23884 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040027AA RID: 10154
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
