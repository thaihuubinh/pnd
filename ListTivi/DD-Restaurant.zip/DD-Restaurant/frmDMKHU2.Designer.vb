﻿Namespace prjIS_SalesPOS
	' Token: 0x02000056 RID: 86
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMKHU2
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060019D6 RID: 6614 RVA: 0x00140E2C File Offset: 0x0013F02C
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060019D7 RID: 6615 RVA: 0x00140E64 File Offset: 0x0013F064
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMKHU2))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.lblMAHH = New Global.System.Windows.Forms.Label()
			Me.txtMAKHO = New Global.System.Windows.Forms.TextBox()
			Me.lblMAKH = New Global.System.Windows.Forms.Label()
			Me.txtGHICHU = New Global.System.Windows.Forms.TextBox()
			Me.lblMIN = New Global.System.Windows.Forms.Label()
			Me.lblMAX = New Global.System.Windows.Forms.Label()
			Me.txtTENKHU = New Global.System.Windows.Forms.TextBox()
			Me.btnDMKH = New Global.System.Windows.Forms.Button()
			Me.txtTENkho = New Global.System.Windows.Forms.TextBox()
			Me.txtMAKHU = New Global.System.Windows.Forms.TextBox()
			Me.cmbLevelPrice = New Global.System.Windows.Forms.ComboBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.cmbStatusClose = New Global.System.Windows.Forms.ComboBox()
			Me.Label4 = New Global.System.Windows.Forms.Label()
			Me.txtPERSERVICE = New Global.System.Windows.Forms.TextBox()
			Me.btnKey = New Global.System.Windows.Forms.Button()
			Me.txtPERVAT = New Global.System.Windows.Forms.TextBox()
			Me.Label5 = New Global.System.Windows.Forms.Label()
			Me.Label6 = New Global.System.Windows.Forms.Label()
			Me.chkLOnlyCash = New Global.System.Windows.Forms.CheckBox()
			Me.chkLNotVAT = New Global.System.Windows.Forms.CheckBox()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(575, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 526)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 5
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnKeyboard, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 2)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 6
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 505)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnKeyboard.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnKeyboard.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(3, 3)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(107, 78)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 122
			Me.btnKeyboard.Text = "Keyboard"
			Me.btnKeyboard.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 255)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(107, 78)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 6
			Me.btnFilter.Tag = "CR0005"
			Me.btnFilter.Text = "Lọ&c"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 423)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 79)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "CR0009"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 339)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(107, 78)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 7
			Me.btnFind.Tag = "CR0006"
			Me.btnFind.Text = "&Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 87)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(107, 78)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 4
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 171)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 78)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 5
			Me.btnDelete.Tag = "CR0004"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.lblMAHH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAHH As Global.System.Windows.Forms.Control = Me.lblMAHH
			point = New Global.System.Drawing.Point(4, 42)
			lblMAHH.Location = point
			Me.lblMAHH.Name = "lblMAHH"
			Dim lblMAHH2 As Global.System.Windows.Forms.Control = Me.lblMAHH
			size = New Global.System.Drawing.Size(160, 21)
			lblMAHH2.Size = size
			Me.lblMAHH.TabIndex = 34
			Me.lblMAHH.Tag = "CB0008"
			Me.lblMAHH.Text = "Tên "
			Me.txtMAKHO.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAKHO As Global.System.Windows.Forms.Control = Me.txtMAKHO
			point = New Global.System.Drawing.Point(182, 67)
			txtMAKHO.Location = point
			Me.txtMAKHO.Name = "txtMAKHO"
			Dim txtMAKHO2 As Global.System.Windows.Forms.Control = Me.txtMAKHO
			size = New Global.System.Drawing.Size(115, 22)
			txtMAKHO2.Size = size
			Me.txtMAKHO.TabIndex = 2
			Me.txtMAKHO.Tag = "0R0000"
			Me.lblMAKH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAKH As Global.System.Windows.Forms.Control = Me.lblMAKH
			point = New Global.System.Drawing.Point(4, 15)
			lblMAKH.Location = point
			Me.lblMAKH.Name = "lblMAKH"
			Dim lblMAKH2 As Global.System.Windows.Forms.Control = Me.lblMAKH
			size = New Global.System.Drawing.Size(160, 21)
			lblMAKH2.Size = size
			Me.lblMAKH.TabIndex = 33
			Me.lblMAKH.Tag = "CB0007"
			Me.lblMAKH.Text = "Mã"
			Me.txtGHICHU.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtGHICHU As Global.System.Windows.Forms.Control = Me.txtGHICHU
			point = New Global.System.Drawing.Point(182, 214)
			txtGHICHU.Location = point
			Me.txtGHICHU.Name = "txtGHICHU"
			Dim txtGHICHU2 As Global.System.Windows.Forms.Control = Me.txtGHICHU
			size = New Global.System.Drawing.Size(387, 22)
			txtGHICHU2.Size = size
			Me.txtGHICHU.TabIndex = 4
			Me.txtGHICHU.Tag = "0R0000"
			Me.lblMIN.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMIN As Global.System.Windows.Forms.Control = Me.lblMIN
			point = New Global.System.Drawing.Point(4, 70)
			lblMIN.Location = point
			Me.lblMIN.Name = "lblMIN"
			Dim lblMIN2 As Global.System.Windows.Forms.Control = Me.lblMIN
			size = New Global.System.Drawing.Size(160, 21)
			lblMIN2.Size = size
			Me.lblMIN.TabIndex = 39
			Me.lblMIN.Tag = "CB0010"
			Me.lblMIN.Text = "Mã kho"
			Me.lblMAX.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAX As Global.System.Windows.Forms.Control = Me.lblMAX
			point = New Global.System.Drawing.Point(4, 217)
			lblMAX.Location = point
			Me.lblMAX.Name = "lblMAX"
			Dim lblMAX2 As Global.System.Windows.Forms.Control = Me.lblMAX
			size = New Global.System.Drawing.Size(160, 21)
			lblMAX2.Size = size
			Me.lblMAX.TabIndex = 40
			Me.lblMAX.Tag = "CR0032"
			Me.lblMAX.Text = "Tên "
			Me.txtTENKHU.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtTENKHU As Global.System.Windows.Forms.Control = Me.txtTENKHU
			point = New Global.System.Drawing.Point(182, 39)
			txtTENKHU.Location = point
			Me.txtTENKHU.Name = "txtTENKHU"
			Dim txtTENKHU2 As Global.System.Windows.Forms.Control = Me.txtTENKHU
			size = New Global.System.Drawing.Size(344, 22)
			txtTENKHU2.Size = size
			Me.txtTENKHU.TabIndex = 1
			Me.txtTENKHU.Tag = "0R0000"
			Me.btnDMKH.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMKH As Global.System.Windows.Forms.Control = Me.btnDMKH
			point = New Global.System.Drawing.Point(295, 67)
			btnDMKH.Location = point
			Me.btnDMKH.Name = "btnDMKH"
			Dim btnDMKH2 As Global.System.Windows.Forms.Control = Me.btnDMKH
			size = New Global.System.Drawing.Size(45, 22)
			btnDMKH2.Size = size
			Me.btnDMKH.TabIndex = 3
			Me.btnDMKH.Tag = "CB0011"
			Me.btnDMKH.UseVisualStyleBackColor = True
			Me.txtTENkho.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTENkho As Global.System.Windows.Forms.Control = Me.txtTENkho
			point = New Global.System.Drawing.Point(346, 67)
			txtTENkho.Location = point
			Me.txtTENkho.Name = "txtTENkho"
			Dim txtTENkho2 As Global.System.Windows.Forms.Control = Me.txtTENkho
			size = New Global.System.Drawing.Size(223, 22)
			txtTENkho2.Size = size
			Me.txtTENkho.TabIndex = 6
			Me.txtTENkho.Tag = "0R0000"
			Me.txtMAKHU.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAKHU As Global.System.Windows.Forms.Control = Me.txtMAKHU
			point = New Global.System.Drawing.Point(182, 12)
			txtMAKHU.Location = point
			Me.txtMAKHU.Name = "txtMAKHU"
			Dim txtMAKHU2 As Global.System.Windows.Forms.Control = Me.txtMAKHU
			size = New Global.System.Drawing.Size(115, 22)
			txtMAKHU2.Size = size
			Me.txtMAKHU.TabIndex = 0
			Me.txtMAKHU.Tag = "0R0000"
			Me.cmbLevelPrice.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbLevelPrice.FormattingEnabled = True
			Me.cmbLevelPrice.Items.AddRange(New Object() { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" })
			Dim cmbLevelPrice As Global.System.Windows.Forms.Control = Me.cmbLevelPrice
			point = New Global.System.Drawing.Point(182, 92)
			cmbLevelPrice.Location = point
			Me.cmbLevelPrice.Name = "cmbLevelPrice"
			Dim cmbLevelPrice2 As Global.System.Windows.Forms.Control = Me.cmbLevelPrice
			size = New Global.System.Drawing.Size(115, 24)
			cmbLevelPrice2.Size = size
			Me.cmbLevelPrice.TabIndex = 3
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(4, 95)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(160, 21)
			label2.Size = size
			Me.Label1.TabIndex = 42
			Me.Label1.Tag = "CB0044"
			Me.Label1.Text = "MUC GIA CUA KHU"
			Me.Label2.AutoSize = True
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(302, 95)
			label3.Location = point
			Me.Label2.Name = "Label2"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(260, 16)
			label4.Size = size
			Me.Label2.TabIndex = 43
			Me.Label2.Tag = "CB0045"
			Me.Label2.Text = "(Đổi giá khi chọn khu,0: không áp dụng)"
			Me.Label3.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(4, 125)
			label5.Location = point
			Me.Label3.Name = "Label3"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(160, 43)
			label6.Size = size
			Me.Label3.TabIndex = 45
			Me.Label3.Tag = "CB0046"
			Me.Label3.Text = "TRANG THAI BAN KHI dong"
			Me.cmbStatusClose.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cmbStatusClose.FormattingEnabled = True
			Me.cmbStatusClose.Items.AddRange(New Object() { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" })
			Dim cmbStatusClose As Global.System.Windows.Forms.Control = Me.cmbStatusClose
			point = New Global.System.Drawing.Point(182, 122)
			cmbStatusClose.Location = point
			Me.cmbStatusClose.Name = "cmbStatusClose"
			Dim cmbStatusClose2 As Global.System.Windows.Forms.Control = Me.cmbStatusClose
			size = New Global.System.Drawing.Size(387, 24)
			cmbStatusClose2.Size = size
			Me.cmbStatusClose.TabIndex = 44
			Me.Label4.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label7 As Global.System.Windows.Forms.Control = Me.Label4
			point = New Global.System.Drawing.Point(4, 161)
			label7.Location = point
			Me.Label4.Name = "Label4"
			Dim label8 As Global.System.Windows.Forms.Control = Me.Label4
			size = New Global.System.Drawing.Size(160, 21)
			label8.Size = size
			Me.Label4.TabIndex = 47
			Me.Label4.Tag = "CR0052"
			Me.Label4.Text = "Phí phục vụ"
			Me.txtPERSERVICE.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPERSERVICE As Global.System.Windows.Forms.Control = Me.txtPERSERVICE
			point = New Global.System.Drawing.Point(182, 158)
			txtPERSERVICE.Location = point
			Me.txtPERSERVICE.Name = "txtPERSERVICE"
			Dim txtPERSERVICE2 As Global.System.Windows.Forms.Control = Me.txtPERSERVICE
			size = New Global.System.Drawing.Size(115, 22)
			txtPERSERVICE2.Size = size
			Me.txtPERSERVICE.TabIndex = 46
			Me.txtPERSERVICE.Tag = "0R0000"
			Me.txtPERSERVICE.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.btnKey.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnKey As Global.System.Windows.Forms.Control = Me.btnKey
			point = New Global.System.Drawing.Point(527, 37)
			btnKey.Location = point
			Me.btnKey.Name = "btnKey"
			Dim btnKey2 As Global.System.Windows.Forms.Control = Me.btnKey
			size = New Global.System.Drawing.Size(42, 26)
			btnKey2.Size = size
			Me.btnKey.TabIndex = 48
			Me.btnKey.Tag = "CB0011"
			Me.btnKey.UseVisualStyleBackColor = True
			Me.txtPERVAT.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtPERVAT As Global.System.Windows.Forms.Control = Me.txtPERVAT
			point = New Global.System.Drawing.Point(182, 186)
			txtPERVAT.Location = point
			Me.txtPERVAT.Name = "txtPERVAT"
			Dim txtPERVAT2 As Global.System.Windows.Forms.Control = Me.txtPERVAT
			size = New Global.System.Drawing.Size(115, 22)
			txtPERVAT2.Size = size
			Me.txtPERVAT.TabIndex = 46
			Me.txtPERVAT.Tag = "0R0000"
			Me.txtPERVAT.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Right
			Me.Label5.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label9 As Global.System.Windows.Forms.Control = Me.Label5
			point = New Global.System.Drawing.Point(4, 189)
			label9.Location = point
			Me.Label5.Name = "Label5"
			Dim label10 As Global.System.Windows.Forms.Control = Me.Label5
			size = New Global.System.Drawing.Size(160, 21)
			label10.Size = size
			Me.Label5.TabIndex = 47
			Me.Label5.Tag = "CR0053"
			Me.Label5.Text = "VAT"
			Me.Label6.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label11 As Global.System.Windows.Forms.Control = Me.Label6
			point = New Global.System.Drawing.Point(4, 245)
			label11.Location = point
			Me.Label6.Name = "Label6"
			Dim label12 As Global.System.Windows.Forms.Control = Me.Label6
			size = New Global.System.Drawing.Size(160, 21)
			label12.Size = size
			Me.Label6.TabIndex = 40
			Me.Label6.Tag = "CR0054"
			Me.Label6.Text = "Chỉ được thanh toán HĐ"
			Me.chkLOnlyCash.AutoSize = True
			Dim chkLOnlyCash As Global.System.Windows.Forms.Control = Me.chkLOnlyCash
			point = New Global.System.Drawing.Point(182, 246)
			chkLOnlyCash.Location = point
			Me.chkLOnlyCash.Name = "chkLOnlyCash"
			Dim chkLOnlyCash2 As Global.System.Windows.Forms.Control = Me.chkLOnlyCash
			size = New Global.System.Drawing.Size(15, 14)
			chkLOnlyCash2.Size = size
			Me.chkLOnlyCash.TabIndex = 49
			Me.chkLOnlyCash.UseVisualStyleBackColor = True
			Me.chkLNotVAT.AutoSize = True
			Dim chkLNotVAT As Global.System.Windows.Forms.Control = Me.chkLNotVAT
			point = New Global.System.Drawing.Point(313, 188)
			chkLNotVAT.Location = point
			Me.chkLNotVAT.Name = "chkLNotVAT"
			Dim chkLNotVAT2 As Global.System.Windows.Forms.Control = Me.chkLNotVAT
			size = New Global.System.Drawing.Size(141, 20)
			chkLNotVAT2.Size = size
			Me.chkLNotVAT.TabIndex = 50
			Me.chkLNotVAT.Tag = "CR0055"
			Me.chkLNotVAT.Text = "Không áp dụng VAT"
			Me.chkLNotVAT.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(694, 526)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.chkLNotVAT)
			Me.Controls.Add(Me.chkLOnlyCash)
			Me.Controls.Add(Me.btnKey)
			Me.Controls.Add(Me.Label5)
			Me.Controls.Add(Me.Label4)
			Me.Controls.Add(Me.txtPERVAT)
			Me.Controls.Add(Me.txtPERSERVICE)
			Me.Controls.Add(Me.Label3)
			Me.Controls.Add(Me.cmbStatusClose)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.cmbLevelPrice)
			Me.Controls.Add(Me.Label6)
			Me.Controls.Add(Me.lblMAX)
			Me.Controls.Add(Me.lblMIN)
			Me.Controls.Add(Me.txtTENkho)
			Me.Controls.Add(Me.txtMAKHU)
			Me.Controls.Add(Me.btnDMKH)
			Me.Controls.Add(Me.txtTENKHU)
			Me.Controls.Add(Me.txtGHICHU)
			Me.Controls.Add(Me.lblMAHH)
			Me.Controls.Add(Me.txtMAKHO)
			Me.Controls.Add(Me.lblMAKH)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMKHU2"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "DMMAY2"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x04000AAC RID: 2732
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
