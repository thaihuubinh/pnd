﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200024A RID: 586
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC6060001k80Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006432 RID: 25650 RVA: 0x00012039 File Offset: 0x00010239
		Public Sub New()
			CachedrptRepBC6060001k80Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x1700266F RID: 9839
		' (get) Token: 0x06006433 RID: 25651 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006434 RID: 25652 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002670 RID: 9840
		' (get) Token: 0x06006435 RID: 25653 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006436 RID: 25654 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002671 RID: 9841
		' (get) Token: 0x06006437 RID: 25655 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006438 RID: 25656 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006439 RID: 25657 RVA: 0x004DD4A0 File Offset: 0x004DB6A0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC6060001k80Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x0600643A RID: 25658 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002842 RID: 10306
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
