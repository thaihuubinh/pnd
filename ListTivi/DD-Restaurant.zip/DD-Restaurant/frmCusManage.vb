﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200002B RID: 43
	<DesignerGenerated()>
	Public Partial Class frmCusManage
		Inherits Form

		' Token: 0x0600084B RID: 2123 RVA: 0x0000368A File Offset: 0x0000188A
		<DebuggerNonUserCode()>
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmCusManage_Load
			frmCusManage.__ENCList.Add(New WeakReference(Me))
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000323 RID: 803
		' (get) Token: 0x0600084E RID: 2126 RVA: 0x0006136C File Offset: 0x0005F56C
		' (set) Token: 0x0600084F RID: 2127 RVA: 0x00061384 File Offset: 0x0005F584
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000324 RID: 804
		' (get) Token: 0x06000850 RID: 2128 RVA: 0x000613F0 File Offset: 0x0005F5F0
		' (set) Token: 0x06000851 RID: 2129 RVA: 0x000036C0 File Offset: 0x000018C0
		Friend Overridable Property tmrRight As Timer
			<DebuggerNonUserCode()>
			Get
				Return Me._tmrRight
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Me._tmrRight = value
			End Set
		End Property

		' Token: 0x17000325 RID: 805
		' (get) Token: 0x06000852 RID: 2130 RVA: 0x00061408 File Offset: 0x0005F608
		' (set) Token: 0x06000853 RID: 2131 RVA: 0x000036CA File Offset: 0x000018CA
		Friend Overridable Property ContextMenuStrip1 As ContextMenuStrip
			<DebuggerNonUserCode()>
			Get
				Return Me._ContextMenuStrip1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ContextMenuStrip)
				Me._ContextMenuStrip1 = value
			End Set
		End Property

		' Token: 0x17000326 RID: 806
		' (get) Token: 0x06000854 RID: 2132 RVA: 0x00061420 File Offset: 0x0005F620
		' (set) Token: 0x06000855 RID: 2133 RVA: 0x000036D4 File Offset: 0x000018D4
		Friend Overridable Property lblTitle As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblTitle
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblTitle = value
			End Set
		End Property

		' Token: 0x17000327 RID: 807
		' (get) Token: 0x06000856 RID: 2134 RVA: 0x00061438 File Offset: 0x0005F638
		' (set) Token: 0x06000857 RID: 2135 RVA: 0x000036DE File Offset: 0x000018DE
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x17000328 RID: 808
		' (get) Token: 0x06000858 RID: 2136 RVA: 0x00061450 File Offset: 0x0005F650
		' (set) Token: 0x06000859 RID: 2137 RVA: 0x00061468 File Offset: 0x0005F668
		Friend Overridable Property lblExit As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Dim flag As Boolean = Me._lblExit IsNot Nothing
				If flag Then
					RemoveHandler Me._lblExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._lblExit = value
				flag = Me._lblExit IsNot Nothing
				If flag Then
					AddHandler Me._lblExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000329 RID: 809
		' (get) Token: 0x0600085A RID: 2138 RVA: 0x000614D4 File Offset: 0x0005F6D4
		' (set) Token: 0x0600085B RID: 2139 RVA: 0x000036E8 File Offset: 0x000018E8
		Friend Overridable Property GroupBox1 As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._GroupBox1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox1 = value
			End Set
		End Property

		' Token: 0x1700032A RID: 810
		' (get) Token: 0x0600085C RID: 2140 RVA: 0x000614EC File Offset: 0x0005F6EC
		' (set) Token: 0x0600085D RID: 2141 RVA: 0x000036F2 File Offset: 0x000018F2
		Friend Overridable Property mtbToDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtbToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtbToDate = value
			End Set
		End Property

		' Token: 0x1700032B RID: 811
		' (get) Token: 0x0600085E RID: 2142 RVA: 0x00061504 File Offset: 0x0005F704
		' (set) Token: 0x0600085F RID: 2143 RVA: 0x000036FC File Offset: 0x000018FC
		Friend Overridable Property mtbFromDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtbFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Me._mtbFromDate = value
			End Set
		End Property

		' Token: 0x1700032C RID: 812
		' (get) Token: 0x06000860 RID: 2144 RVA: 0x0006151C File Offset: 0x0005F71C
		' (set) Token: 0x06000861 RID: 2145 RVA: 0x00003706 File Offset: 0x00001906
		Friend Overridable Property lblToDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblToDate = value
			End Set
		End Property

		' Token: 0x1700032D RID: 813
		' (get) Token: 0x06000862 RID: 2146 RVA: 0x00061534 File Offset: 0x0005F734
		' (set) Token: 0x06000863 RID: 2147 RVA: 0x00003710 File Offset: 0x00001910
		Friend Overridable Property lblFromDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFromDate = value
			End Set
		End Property

		' Token: 0x1700032E RID: 814
		' (get) Token: 0x06000864 RID: 2148 RVA: 0x0006154C File Offset: 0x0005F74C
		' (set) Token: 0x06000865 RID: 2149 RVA: 0x00061564 File Offset: 0x0005F764
		Friend Overridable Property dtpDenNgay As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpDenNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpDenNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpDenNgay.ValueChanged, AddressOf Me.dtpDenNgay_ValueChanged
				End If
				Me._dtpDenNgay = value
				flag = Me._dtpDenNgay IsNot Nothing
				If flag Then
					AddHandler Me._dtpDenNgay.ValueChanged, AddressOf Me.dtpDenNgay_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x1700032F RID: 815
		' (get) Token: 0x06000866 RID: 2150 RVA: 0x000615D0 File Offset: 0x0005F7D0
		' (set) Token: 0x06000867 RID: 2151 RVA: 0x000615E8 File Offset: 0x0005F7E8
		Friend Overridable Property dtpTuNgay As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpTuNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpTuNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.DateTimePicker1_ValueChanged
				End If
				Me._dtpTuNgay = value
				flag = Me._dtpTuNgay IsNot Nothing
				If flag Then
					AddHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.DateTimePicker1_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x17000330 RID: 816
		' (get) Token: 0x06000868 RID: 2152 RVA: 0x00061654 File Offset: 0x0005F854
		' (set) Token: 0x06000869 RID: 2153 RVA: 0x0006166C File Offset: 0x0005F86C
		Friend Overridable Property btnChuyenNhomDV As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnChuyenNhomDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnChuyenNhomDV IsNot Nothing
				If flag Then
					RemoveHandler Me._btnChuyenNhomDV.Click, AddressOf Me.btnChuyenNhomDV_Click
				End If
				Me._btnChuyenNhomDV = value
				flag = Me._btnChuyenNhomDV IsNot Nothing
				If flag Then
					AddHandler Me._btnChuyenNhomDV.Click, AddressOf Me.btnChuyenNhomDV_Click
				End If
			End Set
		End Property

		' Token: 0x0600086A RID: 2154 RVA: 0x000616D8 File Offset: 0x0005F8D8
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600086B RID: 2155 RVA: 0x0000371A File Offset: 0x0000191A
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			mdlFile.gfWriteLogFile("Nhấn nút thoát form quản lý khách hàng.")
			Me.Close()
		End Sub

		' Token: 0x0600086C RID: 2156 RVA: 0x000617D4 File Offset: 0x0005F9D4
		Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs)
			Me.mtbFromDate.Text = String.Concat(New String() { Me.dtpTuNgay.Value.Day.ToString("00"), "/", Me.dtpTuNgay.Value.Month.ToString("00"), "/", Me.dtpTuNgay.Value.Year.ToString("0000") })
		End Sub

		' Token: 0x0600086D RID: 2157 RVA: 0x00061884 File Offset: 0x0005FA84
		Private Sub dtpDenNgay_ValueChanged(sender As Object, e As EventArgs)
			Me.mtbToDate.Text = String.Concat(New String() { Me.dtpDenNgay.Value.Day.ToString("00"), "/", Me.dtpDenNgay.Value.Month.ToString("00"), "/", Me.dtpDenNgay.Value.Year.ToString("0000") })
		End Sub

		' Token: 0x0600086E RID: 2158 RVA: 0x00061934 File Offset: 0x0005FB34
		Private Sub btnChuyenNhomDV_Click(sender As Object, e As EventArgs)
			Dim text As String = String.Concat(New String() { Strings.Right("00" + Strings.Trim(Strings.Mid(Me.mtbFromDate.Text, 1, 2)), 2), "/", Strings.Right("00" + Strings.Trim(Strings.Mid(Me.mtbFromDate.Text, 4, 2)), 2), "/", Strings.Right("0000" + Strings.Trim(Strings.Mid(Me.mtbFromDate.Text, 7, 4)), 4) })
			Dim text2 As String = String.Concat(New String() { Strings.Right("00" + Strings.Trim(Strings.Mid(Me.mtbToDate.Text, 1, 2)), 2), "/", Strings.Right("00" + Strings.Trim(Strings.Mid(Me.mtbToDate.Text, 4, 2)), 2), "/", Strings.Right("0000" + Strings.Trim(Strings.Mid(Me.mtbToDate.Text, 7, 4)), 4) })
			Dim flag As Boolean = Strings.Trim(text).Length <= 4
			If flag Then
				Interaction.MsgBox(Me.mArrStrFrmMess(10), MsgBoxStyle.Critical, Nothing)
				Me.mtbFromDate.Focus()
			Else
				Dim text3 As String = String.Concat(New String() { Strings.Mid(Strings.Trim(text), 7, 4), "/", Strings.Mid(Strings.Trim(text), 4, 2), "/", Strings.Mid(Strings.Trim(text), 1, 2) })
				flag = Not Information.IsDate(text3)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(10), MsgBoxStyle.Critical, Nothing)
					Me.mtbFromDate.Focus()
				Else
					flag = Strings.Trim(text2).Length <= 4
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(10), MsgBoxStyle.Critical, Nothing)
						Me.mtbToDate.Focus()
					Else
						Dim text4 As String = String.Concat(New String() { Strings.Mid(Strings.Trim(text2), 7, 4), "/", Strings.Mid(Strings.Trim(text2), 4, 2), "/", Strings.Mid(Strings.Trim(text2), 1, 2) })
						flag = Not Information.IsDate(text4)
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(10), MsgBoxStyle.Critical, Nothing)
							Me.mtbToDate.Focus()
						Else
							flag = DateTime.Compare(Conversions.ToDate(text3), Conversions.ToDate(text4)) > 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(11), MsgBoxStyle.Critical, Nothing)
								Me.mtbFromDate.Focus()
							Else
								flag = MyProject.Forms.frmMyMessage.Show(Me.mArrStrFrmMess(8), Me.mArrStrFrmMess(9), frmMyMessage.enuNutChon.NutCoKhong, frmMyMessage.enuHinh.Hoi) = DialogResult.No
								If Not flag Then
									text3 = text3.Replace("/", "")
									text4 = text4.Replace("/", "")
									Me.fPrintDMDV_None(text3, text4)
								End If
							End If
						End If
					End If
				End If
			End If
		End Sub

		' Token: 0x0600086F RID: 2159 RVA: 0x00061CD8 File Offset: 0x0005FED8
		Private Sub frmCusManage_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - frmCusManage_Load() " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000870 RID: 2160 RVA: 0x00061D58 File Offset: 0x0005FF58
		Private Function fPrintDMDV_None(pstrFrom As String, pstrTo As String) As Byte
			Dim rptDMDV_None As rptDMDV_None = New rptDMDV_None()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMDV_None, "")
				Dim text As String = "2071000000"
				mdlReport.gsSetOfficeReport(rptDMDV_None, text)
				mdlReport.gsSetFontReport(rptDMDV_None)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnvcFROM"
				array(0).Value = pstrFrom
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTO"
				array(1).Value = pstrTo
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMCUSMANAGE_DOWN_NHOMDV", num)
				Dim flag As Boolean = num = 1
				If flag Then
					rptDMDV_None.SetDataSource(clsConnect)
					rptDMDV_None.DataDefinition.FormulaFields("fUnitCode").Text = "{dtReport.MADV}"
					rptDMDV_None.DataDefinition.FormulaFields("fUnitName").Text = "{dtReport.TENDV}"
					rptDMDV_None.DataDefinition.FormulaFields("fAddress").Text = "{dtReport.ADDRESS}"
					rptDMDV_None.DataDefinition.FormulaFields("fTel").Text = "{dtReport.TEL}"
					rptDMDV_None.DataDefinition.FormulaFields("fNhomTruoc").Text = "{dtReport.NHOMTRUOC}"
					rptDMDV_None.DataDefinition.FormulaFields("fNhomSau").Text = "{dtReport.NHOMSAU}"
					rptDMDV_None.DataDefinition.FormulaFields("fDiemTruoc").Text = "{dtReport.SCORE}"
					rptDMDV_None.DataDefinition.FormulaFields("fDiemSau").Text = "{dtReport.SCORE_SAU}"
					mdlReport.gsSetTextReport(rptDMDV_None, "FRMCUSMANAGE")
					MyProject.Forms.frmReport.pSource = rptDMDV_None
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMDV_None.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					Dim textObject2 As TextObject = CType(rptDMDV_None.ReportDefinition.ReportObjects("txtThoiKhoang"), TextObject)
					textObject2.Text = String.Concat(New String() { Me.mArrStrFrmMess(22), " ", Me.mtbFromDate.Text, " - ", Me.mArrStrFrmMess(23), " ", Me.mtbToDate.Text })
					rptDMDV_None.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMDV_None.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMDV_None " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMDV_None.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x040003A4 RID: 932
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040003A6 RID: 934
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040003A7 RID: 935
		<AccessedThroughProperty("tmrRight")>
		Private _tmrRight As Timer

		' Token: 0x040003A8 RID: 936
		<AccessedThroughProperty("ContextMenuStrip1")>
		Private _ContextMenuStrip1 As ContextMenuStrip

		' Token: 0x040003A9 RID: 937
		<AccessedThroughProperty("lblTitle")>
		Private _lblTitle As Label

		' Token: 0x040003AA RID: 938
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x040003AB RID: 939
		<AccessedThroughProperty("lblExit")>
		Private _lblExit As Label

		' Token: 0x040003AC RID: 940
		<AccessedThroughProperty("GroupBox1")>
		Private _GroupBox1 As GroupBox

		' Token: 0x040003AD RID: 941
		<AccessedThroughProperty("mtbToDate")>
		Private _mtbToDate As MaskedTextBox

		' Token: 0x040003AE RID: 942
		<AccessedThroughProperty("mtbFromDate")>
		Private _mtbFromDate As MaskedTextBox

		' Token: 0x040003AF RID: 943
		<AccessedThroughProperty("lblToDate")>
		Private _lblToDate As Label

		' Token: 0x040003B0 RID: 944
		<AccessedThroughProperty("lblFromDate")>
		Private _lblFromDate As Label

		' Token: 0x040003B1 RID: 945
		<AccessedThroughProperty("dtpDenNgay")>
		Private _dtpDenNgay As DateTimePicker

		' Token: 0x040003B2 RID: 946
		<AccessedThroughProperty("dtpTuNgay")>
		Private _dtpTuNgay As DateTimePicker

		' Token: 0x040003B3 RID: 947
		<AccessedThroughProperty("btnChuyenNhomDV")>
		Private _btnChuyenNhomDV As Button

		' Token: 0x040003B4 RID: 948
		Private mArrStrFrmMess As String()
	End Class
End Namespace
