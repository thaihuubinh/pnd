﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200003A RID: 58
	<DesignerGenerated()>
	Public Partial Class frmDMBP1
		Inherits Form

		' Token: 0x06000D3A RID: 3386 RVA: 0x0009B7B4 File Offset: 0x000999B4
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMBP1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMBP1_Load
			frmDMBP1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd_DMBP = False
			Me.mbytFather = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x170004C2 RID: 1218
		' (get) Token: 0x06000D3D RID: 3389 RVA: 0x0009CC7C File Offset: 0x0009AE7C
		' (set) Token: 0x06000D3E RID: 3390 RVA: 0x000042CB File Offset: 0x000024CB
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x170004C3 RID: 1219
		' (get) Token: 0x06000D3F RID: 3391 RVA: 0x0009CC94 File Offset: 0x0009AE94
		' (set) Token: 0x06000D40 RID: 3392 RVA: 0x0009CCAC File Offset: 0x0009AEAC
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x170004C4 RID: 1220
		' (get) Token: 0x06000D41 RID: 3393 RVA: 0x0009CD18 File Offset: 0x0009AF18
		' (set) Token: 0x06000D42 RID: 3394 RVA: 0x0009CD30 File Offset: 0x0009AF30
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170004C5 RID: 1221
		' (get) Token: 0x06000D43 RID: 3395 RVA: 0x0009CD9C File Offset: 0x0009AF9C
		' (set) Token: 0x06000D44 RID: 3396 RVA: 0x0009CDB4 File Offset: 0x0009AFB4
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x170004C6 RID: 1222
		' (get) Token: 0x06000D45 RID: 3397 RVA: 0x0009CE20 File Offset: 0x0009B020
		' (set) Token: 0x06000D46 RID: 3398 RVA: 0x0009CE38 File Offset: 0x0009B038
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x170004C7 RID: 1223
		' (get) Token: 0x06000D47 RID: 3399 RVA: 0x0009CEA4 File Offset: 0x0009B0A4
		' (set) Token: 0x06000D48 RID: 3400 RVA: 0x0009CEBC File Offset: 0x0009B0BC
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170004C8 RID: 1224
		' (get) Token: 0x06000D49 RID: 3401 RVA: 0x0009CF28 File Offset: 0x0009B128
		' (set) Token: 0x06000D4A RID: 3402 RVA: 0x0009CF40 File Offset: 0x0009B140
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x170004C9 RID: 1225
		' (get) Token: 0x06000D4B RID: 3403 RVA: 0x0009CFAC File Offset: 0x0009B1AC
		' (set) Token: 0x06000D4C RID: 3404 RVA: 0x0009CFC4 File Offset: 0x0009B1C4
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170004CA RID: 1226
		' (get) Token: 0x06000D4D RID: 3405 RVA: 0x0009D030 File Offset: 0x0009B230
		' (set) Token: 0x06000D4E RID: 3406 RVA: 0x000042D5 File Offset: 0x000024D5
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x170004CB RID: 1227
		' (get) Token: 0x06000D4F RID: 3407 RVA: 0x0009D048 File Offset: 0x0009B248
		' (set) Token: 0x06000D50 RID: 3408 RVA: 0x0009D060 File Offset: 0x0009B260
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x170004CC RID: 1228
		' (get) Token: 0x06000D51 RID: 3409 RVA: 0x0009D0CC File Offset: 0x0009B2CC
		' (set) Token: 0x06000D52 RID: 3410 RVA: 0x0009D0E4 File Offset: 0x0009B2E4
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x170004CD RID: 1229
		' (get) Token: 0x06000D53 RID: 3411 RVA: 0x0009D150 File Offset: 0x0009B350
		' (set) Token: 0x06000D54 RID: 3412 RVA: 0x0009D168 File Offset: 0x0009B368
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170004CE RID: 1230
		' (get) Token: 0x06000D55 RID: 3413 RVA: 0x0009D1D4 File Offset: 0x0009B3D4
		' (set) Token: 0x06000D56 RID: 3414 RVA: 0x000042DF File Offset: 0x000024DF
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170004CF RID: 1231
		' (get) Token: 0x06000D57 RID: 3415 RVA: 0x0009D1EC File Offset: 0x0009B3EC
		' (set) Token: 0x06000D58 RID: 3416 RVA: 0x0009D204 File Offset: 0x0009B404
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x170004D0 RID: 1232
		' (get) Token: 0x06000D59 RID: 3417 RVA: 0x0009D270 File Offset: 0x0009B470
		' (set) Token: 0x06000D5A RID: 3418 RVA: 0x0009D288 File Offset: 0x0009B488
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x170004D1 RID: 1233
		' (get) Token: 0x06000D5B RID: 3419 RVA: 0x0009D2F4 File Offset: 0x0009B4F4
		' (set) Token: 0x06000D5C RID: 3420 RVA: 0x0009D30C File Offset: 0x0009B50C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170004D2 RID: 1234
		' (get) Token: 0x06000D5D RID: 3421 RVA: 0x0009D378 File Offset: 0x0009B578
		' (set) Token: 0x06000D5E RID: 3422 RVA: 0x0009D390 File Offset: 0x0009B590
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x170004D3 RID: 1235
		' (get) Token: 0x06000D5F RID: 3423 RVA: 0x0009D3FC File Offset: 0x0009B5FC
		' (set) Token: 0x06000D60 RID: 3424 RVA: 0x0009D414 File Offset: 0x0009B614
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170004D4 RID: 1236
		' (get) Token: 0x06000D61 RID: 3425 RVA: 0x0009D480 File Offset: 0x0009B680
		' (set) Token: 0x06000D62 RID: 3426 RVA: 0x0009D498 File Offset: 0x0009B698
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x170004D5 RID: 1237
		' (get) Token: 0x06000D63 RID: 3427 RVA: 0x0009D504 File Offset: 0x0009B704
		' (set) Token: 0x06000D64 RID: 3428 RVA: 0x000042E9 File Offset: 0x000024E9
		Friend Overridable Property lblKHO As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblKHO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblKHO = value
			End Set
		End Property

		' Token: 0x170004D6 RID: 1238
		' (get) Token: 0x06000D65 RID: 3429 RVA: 0x0009D51C File Offset: 0x0009B71C
		' (set) Token: 0x06000D66 RID: 3430 RVA: 0x0009D534 File Offset: 0x0009B734
		Friend Overridable Property cmbKHO As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbKHO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbKHO IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbKHO.SelectedIndexChanged, AddressOf Me.cmbKHO_SelectedIndexChanged
				End If
				Me._cmbKHO = value
				flag = Me._cmbKHO IsNot Nothing
				If flag Then
					AddHandler Me._cmbKHO.SelectedIndexChanged, AddressOf Me.cmbKHO_SelectedIndexChanged
				End If
			End Set
		End Property

		' Token: 0x170004D7 RID: 1239
		' (get) Token: 0x06000D67 RID: 3431 RVA: 0x0009D5A0 File Offset: 0x0009B7A0
		' (set) Token: 0x06000D68 RID: 3432 RVA: 0x000042F3 File Offset: 0x000024F3
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170004D8 RID: 1240
		' (get) Token: 0x06000D69 RID: 3433 RVA: 0x0009D5B8 File Offset: 0x0009B7B8
		' (set) Token: 0x06000D6A RID: 3434 RVA: 0x0009D5D0 File Offset: 0x0009B7D0
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170004D9 RID: 1241
		' (get) Token: 0x06000D6B RID: 3435 RVA: 0x0009D63C File Offset: 0x0009B83C
		' (set) Token: 0x06000D6C RID: 3436 RVA: 0x000042FD File Offset: 0x000024FD
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x170004DA RID: 1242
		' (get) Token: 0x06000D6D RID: 3437 RVA: 0x0009D654 File Offset: 0x0009B854
		' (set) Token: 0x06000D6E RID: 3438 RVA: 0x00004308 File Offset: 0x00002508
		Public Property pbytIsFather As Byte
			Get
				Return Me.mbytFather
			End Get
			Set(value As Byte)
				Me.mbytFather = value
			End Set
		End Property

		' Token: 0x170004DB RID: 1243
		' (get) Token: 0x06000D6F RID: 3439 RVA: 0x0009D66C File Offset: 0x0009B86C
		' (set) Token: 0x06000D70 RID: 3440 RVA: 0x00004313 File Offset: 0x00002513
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x170004DC RID: 1244
		' (get) Token: 0x06000D71 RID: 3441 RVA: 0x0009D684 File Offset: 0x0009B884
		' (set) Token: 0x06000D72 RID: 3442 RVA: 0x0000431E File Offset: 0x0000251E
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06000D73 RID: 3443 RVA: 0x0009D69C File Offset: 0x0009B89C
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
				Me.mStrOBJNAME = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJNAME").Value)
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D74 RID: 3444 RVA: 0x0009D788 File Offset: 0x0009B988
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D75 RID: 3445 RVA: 0x0009D858 File Offset: 0x0009BA58
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D76 RID: 3446 RVA: 0x0009D948 File Offset: 0x0009BB48
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D77 RID: 3447 RVA: 0x0009DA2C File Offset: 0x0009BC2C
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D78 RID: 3448 RVA: 0x0009DAF0 File Offset: 0x0009BCF0
		Private Sub frmDMBP1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D79 RID: 3449 RVA: 0x0009DB88 File Offset: 0x0009BD88
		Private Sub frmDMBP1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Combo()
				End If
				Me.sGetPara_From_SetparaXML()
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D7A RID: 3450 RVA: 0x0009DCA8 File Offset: 0x0009BEA8
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D7B RID: 3451 RVA: 0x0009DDB0 File Offset: 0x0009BFB0
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D7C RID: 3452 RVA: 0x0009DE48 File Offset: 0x0009C048
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Try
				frmDMBP.pbytFromStatus = 1
				Dim flag As Boolean = Me.dgvData.RowCount > 0
				If flag Then
					frmDMBP.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				Else
					frmDMBP.pStrKHO = ""
				End If
				flag = Me.mblnAutoAdd_DMBP
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pnchFather"
					array(0).Value = ""
					array(1) = sqlCommand.CreateParameter()
					array(1).ParameterName = "@pintResult"
					array(1).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMBP_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMBP.txtOBJID.Text = Strings.Right("0000000000" + array(1).Value.ToString(), 2)
						frmDMBP.txtOBJID.[ReadOnly] = True
						frmDMBP.txtOBJID.BackColor = frmDMBP.txtTENBP.BackColor
					End If
				End If
				frmDMBP.ShowDialog()
				flag = frmDMBP.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMBP.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x06000D7D RID: 3453 RVA: 0x0009E104 File Offset: 0x0009C304
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Try
				Dim frmDMBP2 As frmDMBP2 = frmDMBP
				frmDMBP2.pbytFromStatus = 2
				Dim flag As Boolean = Me.dgvData.RowCount > 0
				If flag Then
					frmDMBP2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMBP2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
					frmDMBP2.txtMABP.Text = Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FATHER").Value, "")))
					frmDMBP2.txtTENBP.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENCHA").Value, ""))
					frmDMBP2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				End If
				flag = Me.mblnAutoAdd_DMBP
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pnchFather"
					array(0).Value = Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FATHER").Value, "")))
					array(1) = sqlCommand.CreateParameter()
					array(1).ParameterName = "@pintResult"
					array(1).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMBP_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMBP.txtOBJID.Text = Strings.Right("000000" + array(1).Value.ToString(), Conversions.ToInteger(Interaction.IIf(Operators.CompareString(Strings.Trim(Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FATHER").Value, ""))), "", False) = 0, 2, 6)))
						frmDMBP.txtOBJID.[ReadOnly] = True
						frmDMBP.txtOBJID.BackColor = frmDMBP.txtTENBP.BackColor
					End If
				End If
				frmDMBP.ShowDialog()
				flag = frmDMBP.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMBP.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x06000D7E RID: 3454 RVA: 0x0009E530 File Offset: 0x0009C730
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					frmDMBP.Dispose()
				Else
					Dim frmDMBP2 As frmDMBP2 = frmDMBP
					frmDMBP2.pbytFromStatus = 3
					frmDMBP2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMBP2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMBP2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
					frmDMBP2.txtMABP.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FATHER").Value, ""))
					frmDMBP2.txtTENBP.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENCHA").Value, ""))
					frmDMBP2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
					frmDMBP.ShowDialog()
					flag = frmDMBP.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMBP.pStrFilter)
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x06000D7F RID: 3455 RVA: 0x0009E830 File Offset: 0x0009CA30
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
					frmDMBP.Dispose()
				Else
					Dim frmDMBP2 As frmDMBP2 = frmDMBP
					frmDMBP2.pbytFromStatus = 4
					frmDMBP2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMBP2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMBP2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
					frmDMBP2.txtMABP.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FATHER").Value, ""))
					frmDMBP2.txtTENBP.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENCHA").Value, ""))
					frmDMBP2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
					frmDMBP.ShowDialog()
					flag = frmDMBP.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x06000D80 RID: 3456 RVA: 0x0009EB10 File Offset: 0x0009CD10
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Try
				frmDMBP.pbytFromStatus = 6
				frmDMBP.ShowDialog()
				Dim flag As Boolean = frmDMBP.pbytSuccess = 0
				If flag Then
					frmDMBP.Dispose()
				Else
					Dim text As String = Conversions.ToString(Interaction.IIf(Operators.ConditionalCompareObjectNotEqual(Me.cmbKHO.SelectedValue, "", False), Operators.ConcatenateObject(Operators.ConcatenateObject(" AND MAKH ='", Me.cmbKHO.SelectedValue), "'"), ""))
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMBP.pStrFilter + text, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMBP.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x06000D81 RID: 3457 RVA: 0x0009ED54 File Offset: 0x0009CF54
		Private Sub cmbKHO_SelectedIndexChanged(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Try
				Me.mbdsSource.RemoveFilter()
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If Not flag Then
					flag = Operators.ConditionalCompareObjectNotEqual(Me.cmbKHO.SelectedValue, "", False)
					If flag Then
						Me.mbdsSource.Filter = " MAKH LIKE '%" + Strings.Trim(Conversions.ToString(Me.cmbKHO.SelectedValue)) + "%'"
					End If
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Visible = False
					Me.btnFindNext.Visible = False
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbKHO_SelectedIndexChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x06000D82 RID: 3458 RVA: 0x0009EE8C File Offset: 0x0009D08C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Try
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				frmDMBP.pbytFromStatus = 5
				frmDMBP.ShowDialog()
				Dim flag As Boolean = frmDMBP.pbytSuccess = 0
				If Not flag Then
					Dim text As String = Conversions.ToString(Interaction.IIf(Operators.ConditionalCompareObjectNotEqual(Me.cmbKHO.SelectedValue, "", False), Operators.ConcatenateObject(Operators.ConcatenateObject(" AND MAKH ='", Me.cmbKHO.SelectedValue), "'"), ""))
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMBP.pStrFilter + text
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x06000D83 RID: 3459 RVA: 0x0009F008 File Offset: 0x0009D208
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Try
				Dim text As String = Conversions.ToString(Interaction.IIf(Operators.ConditionalCompareObjectNotEqual(Me.cmbKHO.SelectedValue, "", False), Operators.ConcatenateObject(Operators.ConcatenateObject(" MAKH ='", Me.cmbKHO.SelectedValue), "'"), ""))
				Me.mbdsSource.RemoveFilter()
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0
				If flag Then
					Me.mbdsSource.Filter = text
				End If
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x06000D84 RID: 3460 RVA: 0x0009F138 File Offset: 0x0009D338
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x06000D85 RID: 3461 RVA: 0x0009F2B4 File Offset: 0x0009D4B4
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Dim flag As Boolean = Me.cmbKHO.SelectedIndex = Me.cmbKHO.Items.Count - 1
				Dim text As String
				If flag Then
					text = ""
				Else
					text = Conversions.ToString(Me.cmbKHO.SelectedValue)
				End If
				Dim b As Byte = Me.fPrintDMBP(text)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D86 RID: 3462 RVA: 0x0009F390 File Offset: 0x0009D590
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D87 RID: 3463 RVA: 0x0009F440 File Offset: 0x0009D640
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMBP")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mblnAutoAdd_DMBP = xmlNode.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D88 RID: 3464 RVA: 0x0009F53C File Offset: 0x0009D73C
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("REMARK").Width = Me.Width - 460 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENKH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("TENKH").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENKH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("FATHER").Visible = False
				dgvData.Columns("TENCHA").Visible = False
				dgvData.Columns("MAKH").Visible = False
				dgvData.Columns("FIXED").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000D89 RID: 3465 RVA: 0x0009F858 File Offset: 0x0009DA58
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000D8A RID: 3466 RVA: 0x0009F9D8 File Offset: 0x0009DBD8
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@ptniFATHER"
				array(0).Value = Me.mbytFather
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMBP_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000D8B RID: 3467 RVA: 0x0009FAFC File Offset: 0x0009DCFC
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Me.cmbKHO.DropDownStyle = ComboBoxStyle.DropDownList
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000D8C RID: 3468 RVA: 0x0009FC58 File Offset: 0x0009DE58
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2070200000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000D8D RID: 3469 RVA: 0x0009FD64 File Offset: 0x0009DF64
		Private Function fGetData_4Combo() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbKHO = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Me.mclsTbKHO.Rows.Add(New Object() { "", Me.mArrStrFrmMess(16) })
				Dim flag As Boolean = Me.mclsTbKHO IsNot Nothing
				If flag Then
					Dim cmbKHO As ComboBox = Me.cmbKHO
					cmbKHO.DataSource = Me.mclsTbKHO
					cmbKHO.DisplayMember = "OBJNAME"
					cmbKHO.ValueMember = "OBJID"
					cmbKHO.SelectedIndex = cmbKHO.Items.Count - 1
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000D8E RID: 3470 RVA: 0x0009FEB4 File Offset: 0x0009E0B4
		Private Sub sClear_Form()
			Try
				Me.mclsTbKHO.Dispose()
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000D8F RID: 3471 RVA: 0x0009FF6C File Offset: 0x0009E16C
		Private Function fPrintDMBP(pstrMAKH As String) As Byte
			Dim rptDMBP As rptDMBP = New rptDMBP()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMBP, "")
				Dim text As String = "2070200000"
				mdlReport.gsSetOfficeReport(rptDMBP, text)
				mdlReport.gsSetFontReport(rptDMBP)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAKH"
				array(0).Value = pstrMAKH
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_GET_DMBP", num)
				Dim flag As Boolean = num = 1
				If flag Then
					rptDMBP.SetDataSource(clsConnect)
					rptDMBP.DataDefinition.FormulaFields("fDepartCode").Text = "{dtReport.OBJID}"
					rptDMBP.DataDefinition.FormulaFields("fDepartName").Text = "{dtReport.OBJNAME}"
					rptDMBP.DataDefinition.FormulaFields("fFaDepartName").Text = "{dtReport.TENCHA}"
					rptDMBP.DataDefinition.FormulaFields("fNote").Text = "{dtReport.REMARK}"
					rptDMBP.DataDefinition.FormulaFields("fStockName").Text = "{dtReport.TENKH}"
					mdlReport.gsSetTextReport(rptDMBP, "RPTDMBP")
					MyProject.Forms.frmReport.pSource = rptDMBP
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMBP.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMBP.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMBP.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMBP " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMBP.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x040005AF RID: 1455
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040005B1 RID: 1457
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x040005B2 RID: 1458
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x040005B3 RID: 1459
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x040005B4 RID: 1460
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x040005B5 RID: 1461
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x040005B6 RID: 1462
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x040005B7 RID: 1463
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x040005B8 RID: 1464
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x040005B9 RID: 1465
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x040005BA RID: 1466
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x040005BB RID: 1467
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x040005BC RID: 1468
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x040005BD RID: 1469
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x040005BE RID: 1470
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x040005BF RID: 1471
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x040005C0 RID: 1472
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040005C1 RID: 1473
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x040005C2 RID: 1474
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040005C3 RID: 1475
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040005C4 RID: 1476
		<AccessedThroughProperty("lblKHO")>
		Private _lblKHO As Label

		' Token: 0x040005C5 RID: 1477
		<AccessedThroughProperty("cmbKHO")>
		Private _cmbKHO As ComboBox

		' Token: 0x040005C6 RID: 1478
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040005C7 RID: 1479
		Private mArrStrFrmMess As String()

		' Token: 0x040005C8 RID: 1480
		Private mStrOBJID As String

		' Token: 0x040005C9 RID: 1481
		Private mStrOBJNAME As String

		' Token: 0x040005CA RID: 1482
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040005CB RID: 1483
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040005CC RID: 1484
		Private marrDrFind As DataRow()

		' Token: 0x040005CD RID: 1485
		Private mintFindLastPos As Integer

		' Token: 0x040005CE RID: 1486
		Private mblnAutoAdd_DMBP As Boolean

		' Token: 0x040005CF RID: 1487
		Private mclsTbKHO As clsConnect

		' Token: 0x040005D0 RID: 1488
		Private mbytFather As Byte
	End Class
End Namespace
