﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200001A RID: 26
	<DesignerGenerated()>
	Public Partial Class frmBanChuaTT
		Inherits Form

		' Token: 0x060003B6 RID: 950 RVA: 0x0002CE1C File Offset: 0x0002B01C
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDOCUMENT021_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDOCUMENT021_Load
			frmBanChuaTT.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000175 RID: 373
		' (get) Token: 0x060003B9 RID: 953 RVA: 0x0002DFDC File Offset: 0x0002C1DC
		' (set) Token: 0x060003BA RID: 954 RVA: 0x00002AAD File Offset: 0x00000CAD
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000176 RID: 374
		' (get) Token: 0x060003BB RID: 955 RVA: 0x0002DFF4 File Offset: 0x0002C1F4
		' (set) Token: 0x060003BC RID: 956 RVA: 0x0002E00C File Offset: 0x0002C20C
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000177 RID: 375
		' (get) Token: 0x060003BD RID: 957 RVA: 0x0002E078 File Offset: 0x0002C278
		' (set) Token: 0x060003BE RID: 958 RVA: 0x0002E090 File Offset: 0x0002C290
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000178 RID: 376
		' (get) Token: 0x060003BF RID: 959 RVA: 0x0002E0FC File Offset: 0x0002C2FC
		' (set) Token: 0x060003C0 RID: 960 RVA: 0x00002AB7 File Offset: 0x00000CB7
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000179 RID: 377
		' (get) Token: 0x060003C1 RID: 961 RVA: 0x0002E114 File Offset: 0x0002C314
		' (set) Token: 0x060003C2 RID: 962 RVA: 0x0002E12C File Offset: 0x0002C32C
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x1700017A RID: 378
		' (get) Token: 0x060003C3 RID: 963 RVA: 0x0002E198 File Offset: 0x0002C398
		' (set) Token: 0x060003C4 RID: 964 RVA: 0x0002E1B0 File Offset: 0x0002C3B0
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x1700017B RID: 379
		' (get) Token: 0x060003C5 RID: 965 RVA: 0x0002E21C File Offset: 0x0002C41C
		' (set) Token: 0x060003C6 RID: 966 RVA: 0x00002AC1 File Offset: 0x00000CC1
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x1700017C RID: 380
		' (get) Token: 0x060003C7 RID: 967 RVA: 0x0002E234 File Offset: 0x0002C434
		' (set) Token: 0x060003C8 RID: 968 RVA: 0x0002E24C File Offset: 0x0002C44C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700017D RID: 381
		' (get) Token: 0x060003C9 RID: 969 RVA: 0x0002E2B8 File Offset: 0x0002C4B8
		' (set) Token: 0x060003CA RID: 970 RVA: 0x00002ACB File Offset: 0x00000CCB
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x1700017E RID: 382
		' (get) Token: 0x060003CB RID: 971 RVA: 0x0002E2D0 File Offset: 0x0002C4D0
		' (set) Token: 0x060003CC RID: 972 RVA: 0x00002AD5 File Offset: 0x00000CD5
		Friend Overridable Property lblFilterDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFilterDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFilterDate = value
			End Set
		End Property

		' Token: 0x1700017F RID: 383
		' (get) Token: 0x060003CD RID: 973 RVA: 0x0002E2E8 File Offset: 0x0002C4E8
		' (set) Token: 0x060003CE RID: 974 RVA: 0x0002E300 File Offset: 0x0002C500
		Friend Overridable Property btnCancel As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancel IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancel.Click, AddressOf Me.btnCancel_Click
				End If
				Me._btnCancel = value
				flag = Me._btnCancel IsNot Nothing
				If flag Then
					AddHandler Me._btnCancel.Click, AddressOf Me.btnCancel_Click
				End If
			End Set
		End Property

		' Token: 0x17000180 RID: 384
		' (get) Token: 0x060003CF RID: 975 RVA: 0x0002E36C File Offset: 0x0002C56C
		' (set) Token: 0x060003D0 RID: 976 RVA: 0x0002E384 File Offset: 0x0002C584
		Friend Overridable Property mtxDATE As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxDATE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxDATE IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxDATE.TextChanged, AddressOf Me.mtxDATE_TextChanged
				End If
				Me._mtxDATE = value
				flag = Me._mtxDATE IsNot Nothing
				If flag Then
					AddHandler Me._mtxDATE.TextChanged, AddressOf Me.mtxDATE_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000181 RID: 385
		' (get) Token: 0x060003D1 RID: 977 RVA: 0x0002E3F0 File Offset: 0x0002C5F0
		' (set) Token: 0x060003D2 RID: 978 RVA: 0x0002E408 File Offset: 0x0002C608
		Friend Overridable Property btnDetail As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDetail
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDetail IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDetail.Click, AddressOf Me.btnDetail_Click
				End If
				Me._btnDetail = value
				flag = Me._btnDetail IsNot Nothing
				If flag Then
					AddHandler Me._btnDetail.Click, AddressOf Me.btnDetail_Click
				End If
			End Set
		End Property

		' Token: 0x17000182 RID: 386
		' (get) Token: 0x060003D3 RID: 979 RVA: 0x0002E474 File Offset: 0x0002C674
		' (set) Token: 0x060003D4 RID: 980 RVA: 0x0002E48C File Offset: 0x0002C68C
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000183 RID: 387
		' (get) Token: 0x060003D5 RID: 981 RVA: 0x0002E4F8 File Offset: 0x0002C6F8
		' (set) Token: 0x060003D6 RID: 982 RVA: 0x00002ADF File Offset: 0x00000CDF
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000184 RID: 388
		' (get) Token: 0x060003D7 RID: 983 RVA: 0x0002E510 File Offset: 0x0002C710
		' (set) Token: 0x060003D8 RID: 984 RVA: 0x0002E528 File Offset: 0x0002C728
		Friend Overridable Property dtpTuNgay As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpTuNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpTuNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.dtpTuNgay_ValueChanged
				End If
				Me._dtpTuNgay = value
				flag = Me._dtpTuNgay IsNot Nothing
				If flag Then
					AddHandler Me._dtpTuNgay.ValueChanged, AddressOf Me.dtpTuNgay_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x17000185 RID: 389
		' (get) Token: 0x060003D9 RID: 985 RVA: 0x0002E594 File Offset: 0x0002C794
		' (set) Token: 0x060003DA RID: 986 RVA: 0x00002AE9 File Offset: 0x00000CE9
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000186 RID: 390
		' (get) Token: 0x060003DB RID: 987 RVA: 0x0002E5AC File Offset: 0x0002C7AC
		' (set) Token: 0x060003DC RID: 988 RVA: 0x0002E5C4 File Offset: 0x0002C7C4
		Friend Overridable Property mtxTODATE As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxTODATE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxTODATE IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxTODATE.TextChanged, AddressOf Me.mtxTODATE_TextChanged
				End If
				Me._mtxTODATE = value
				flag = Me._mtxTODATE IsNot Nothing
				If flag Then
					AddHandler Me._mtxTODATE.TextChanged, AddressOf Me.mtxTODATE_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000187 RID: 391
		' (get) Token: 0x060003DD RID: 989 RVA: 0x0002E630 File Offset: 0x0002C830
		' (set) Token: 0x060003DE RID: 990 RVA: 0x0002E648 File Offset: 0x0002C848
		Friend Overridable Property dtpDenNgay As DateTimePicker
			<DebuggerNonUserCode()>
			Get
				Return Me._dtpDenNgay
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DateTimePicker)
				Dim flag As Boolean = Me._dtpDenNgay IsNot Nothing
				If flag Then
					RemoveHandler Me._dtpDenNgay.ValueChanged, AddressOf Me.dtpDenNgay_ValueChanged
				End If
				Me._dtpDenNgay = value
				flag = Me._dtpDenNgay IsNot Nothing
				If flag Then
					AddHandler Me._dtpDenNgay.ValueChanged, AddressOf Me.dtpDenNgay_ValueChanged
				End If
			End Set
		End Property

		' Token: 0x17000188 RID: 392
		' (get) Token: 0x060003DF RID: 991 RVA: 0x0002E6B4 File Offset: 0x0002C8B4
		' (set) Token: 0x060003E0 RID: 992 RVA: 0x00002AF3 File Offset: 0x00000CF3
		Friend Overridable Property lblToTal As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblToTal
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblToTal = value
			End Set
		End Property

		' Token: 0x17000189 RID: 393
		' (get) Token: 0x060003E1 RID: 993 RVA: 0x0002E6CC File Offset: 0x0002C8CC
		' (set) Token: 0x060003E2 RID: 994 RVA: 0x0002E6E4 File Offset: 0x0002C8E4
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x1700018A RID: 394
		' (get) Token: 0x060003E3 RID: 995 RVA: 0x0002E750 File Offset: 0x0002C950
		' (set) Token: 0x060003E4 RID: 996 RVA: 0x00002AFD File Offset: 0x00000CFD
		Public Property pStrNGAYCT As String
			Get
				Return Me.mStrNGAYCT
			End Get
			Set(value As String)
				Me.mStrNGAYCT = value
			End Set
		End Property

		' Token: 0x1700018B RID: 395
		' (get) Token: 0x060003E5 RID: 997 RVA: 0x0002E768 File Offset: 0x0002C968
		' (set) Token: 0x060003E6 RID: 998 RVA: 0x00002B08 File Offset: 0x00000D08
		Public Property pStrNGAYGS As String
			Get
				Return Me.mStrNGAYGS
			End Get
			Set(value As String)
				Me.mStrNGAYGS = value
			End Set
		End Property

		' Token: 0x1700018C RID: 396
		' (get) Token: 0x060003E7 RID: 999 RVA: 0x0002E780 File Offset: 0x0002C980
		' (set) Token: 0x060003E8 RID: 1000 RVA: 0x00002B13 File Offset: 0x00000D13
		Public Property pStrSOCT As String
			Get
				Return Me.mStrSOCT
			End Get
			Set(value As String)
				Me.mStrSOCT = value
			End Set
		End Property

		' Token: 0x1700018D RID: 397
		' (get) Token: 0x060003E9 RID: 1001 RVA: 0x0002E798 File Offset: 0x0002C998
		' (set) Token: 0x060003EA RID: 1002 RVA: 0x00002B1E File Offset: 0x00000D1E
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060003EB RID: 1003 RVA: 0x0002E7B0 File Offset: 0x0002C9B0
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData("SOCT", Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003EC RID: 1004 RVA: 0x0002E884 File Offset: 0x0002CA84
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData("SOCT", Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003ED RID: 1005 RVA: 0x0002E978 File Offset: 0x0002CB78
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData("SOCT", Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003EE RID: 1006 RVA: 0x0002EA60 File Offset: 0x0002CC60
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData("SOCT", Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003EF RID: 1007 RVA: 0x0002EB28 File Offset: 0x0002CD28
		Private Sub frmDOCUMENT021_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDOCUMENT021_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003F0 RID: 1008 RVA: 0x0002EBC0 File Offset: 0x0002CDC0
		Private Sub frmDOCUMENT021_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					Me.mtxDATE.Text = ""
					Me.mtxTODATE.Text = ""
					b = Me.gf_GetData_4Grid("", "")
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
				flag = mdlVariable.garrDrDMMAYINHD IsNot Nothing AndAlso mdlVariable.garrDrDMMAYINHD.Length > 0
				If flag Then
					Dim flag2 As Boolean = Conversions.ToBoolean(Operators.OrObject(Operators.OrObject(Operators.CompareObjectEqual(mdlVariable.garrDrDMMAYINHD(0)("KIND"), 0, False), Operators.CompareObjectEqual(mdlVariable.garrDrDMMAYINHD(0)("KIND"), 1, False)), Operators.CompareObjectEqual(mdlVariable.garrDrDMMAYINHD(0)("KIND"), 2, False)))
					If flag2 Then
						Dim flag3 As Boolean = mdlVariable.gsrlCOMBillport Is Nothing
						If flag3 Then
							b = mdlPrintReceipt.gfOpenSerialPort()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDOCUMENT021_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003F1 RID: 1009 RVA: 0x0002EDB0 File Offset: 0x0002CFB0
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003F2 RID: 1010 RVA: 0x0002EEB8 File Offset: 0x0002D0B8
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				mdlPrintReceipt.gsCloseSerialPort()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003F3 RID: 1011 RVA: 0x0002EF58 File Offset: 0x0002D158
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrSOCT = Conversions.ToString(Me.dgvData.CurrentRow.Cells("SOCT").Value)
				Me.mStrNGAYGS = Conversions.ToString(Me.dgvData.CurrentRow.Cells("NGAYGS").Value)
				Me.mStrNGAYCT = Conversions.ToString(Me.dgvData.CurrentRow.Cells("NGAYCT").Value)
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003F4 RID: 1012 RVA: 0x0002F070 File Offset: 0x0002D270
		Private Sub btnCancel_Click(sender As Object, e As EventArgs)
			Try
				Me.mtxDATE.Text = ""
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnCancel_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003F5 RID: 1013 RVA: 0x0002F120 File Offset: 0x0002D320
		Private Sub dtpTuNgay_ValueChanged(sender As Object, e As EventArgs)
			Me.mtxDATE.Text = String.Concat(New String() { Me.dtpTuNgay.Value.Day.ToString("00"), "/", Me.dtpTuNgay.Value.Month.ToString("00"), "/", Me.dtpTuNgay.Value.Year.ToString("0000") })
		End Sub

		' Token: 0x060003F6 RID: 1014 RVA: 0x0002F1D0 File Offset: 0x0002D3D0
		Private Sub dtpDenNgay_ValueChanged(sender As Object, e As EventArgs)
			Me.mtxTODATE.Text = String.Concat(New String() { Me.dtpDenNgay.Value.Day.ToString("00"), "/", Me.dtpDenNgay.Value.Month.ToString("00"), "/", Me.dtpDenNgay.Value.Year.ToString("0000") })
		End Sub

		' Token: 0x060003F7 RID: 1015 RVA: 0x0002F280 File Offset: 0x0002D480
		Private Sub mtxDATE_TextChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource Is Nothing
				If Not flag Then
					Me.mtxTODATE.Text = Me.mtxDATE.Text
					Dim text As String = Strings.Mid(Me.mtxDATE.Text, 3, 1)
					Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtxDATE.Text, text, "", 1, -1, CompareMethod.Binary))
					Dim text3 As String = Strings.Trim(Strings.Replace(Me.mtxTODATE.Text, text, "", 1, -1, CompareMethod.Binary))
					flag = Strings.Len(text2) = 0 AndAlso Strings.Len(text3) = 0
					Dim flag2 As Boolean
					If flag Then
						flag2 = Me.gf_GetData_4Grid(text2, text3) = 0
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					flag2 = Strings.Len(text2) < 8
					If Not flag2 Then
						flag2 = Strings.Len(text3) < 8
						If Not flag2 Then
							text2 = text2.Substring(4) + text2.Substring(2, 2) + text2.Substring(0, 2)
							text3 = text3.Substring(4) + text3.Substring(2, 2) + text3.Substring(0, 2)
							flag2 = Me.gf_GetData_4Grid(text2, text3) = 0
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
							End If
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxDATE_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003F8 RID: 1016 RVA: 0x0002F4A8 File Offset: 0x0002D6A8
		Private Sub btnDetail_Click(sender As Object, e As EventArgs)
			Try
				Dim frmBanChuaTT_Detail As frmBanChuaTT_Detail = New frmBanChuaTT_Detail()
				Dim frmBanChuaTT_Detail2 As frmBanChuaTT_Detail = frmBanChuaTT_Detail
				frmBanChuaTT_Detail2.pbdsSource = Me.mbdsSource
				frmBanChuaTT_Detail2.pdgvMaster = Me.dgvData
				frmBanChuaTT_Detail.ShowDialog()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDetail_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003F9 RID: 1017 RVA: 0x0002F564 File Offset: 0x0002D764
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				Dim flag As Boolean = mdlVariable.gblnLBILLSOHD_NGAN
				Dim text As String
				If flag Then
					text = Conversions.ToString(Interaction.IIf(mdlVariable.gblnLSHOWSOHDTT, "SOTTNGAN", "SOCTNGAN"))
				Else
					text = Conversions.ToString(Interaction.IIf(mdlVariable.gblnLSHOWSOHDTT, "SOTT", "SOCT"))
				End If
				dgvData.Columns(text).HeaderText = Conversions.ToString(Interaction.IIf(mdlVariable.gblnLSHOWSOHDTT, Me.mArrStrFrmMess(35).Trim(), Me.mArrStrFrmMess(18).Trim()))
				dgvData.Columns(text).Width = 140
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns(text).DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NGAYCT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("NGAYCT").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("NGAYCT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("GIOVAO").HeaderText = Strings.Trim(Me.mArrStrFrmMess(32))
				dgvData.Columns("GIOVAO").Width = 70
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("GIOVAO").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("NGAYRADK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(51))
				dgvData.Columns("NGAYRADK").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("NGAYRADK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("GIORADK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(52))
				dgvData.Columns("GIORADK").Width = 70
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("GIORADK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENDV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("TENDV").Width = Me.Width - 910 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENDV").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TABLENAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(33))
				dgvData.Columns("TABLENAME").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TABLENAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("THANHTOANBILL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(21))
				dgvData.Columns("THANHTOANBILL").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("THANHTOANBILL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENUSER").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("TENUSER").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENUSER").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENUSERPV").HeaderText = Strings.Trim(Me.mArrStrFrmMess(34))
				dgvData.Columns("TENUSERPV").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENUSERPV").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LCORRECT").Visible = False
				dgvData.Columns("DOCID").Visible = False
				dgvData.Columns("NGAYKT").Visible = False
				dgvData.Columns("GIOKT").Visible = False
				dgvData.Columns("MADV").Visible = False
				dgvData.Columns("MAKH").Visible = False
				dgvData.Columns("MALH").Visible = False
				dgvData.Columns("MAUSER").Visible = False
				dgvData.Columns("MATT").Visible = False
				dgvData.Columns("MAMT").Visible = False
				dgvData.Columns("MAMAY").Visible = False
				dgvData.Columns("MAKHU").Visible = False
				dgvData.Columns("TENKH").Visible = False
				dgvData.Columns("TENLH").Visible = False
				dgvData.Columns("TENTT").Visible = False
				dgvData.Columns("TENMT").Visible = False
				dgvData.Columns("TENMAY").Visible = False
				dgvData.Columns("TENKHU").Visible = False
				dgvData.Columns("GIORA").Visible = False
				dgvData.Columns("EXCHANGE").Visible = False
				dgvData.Columns("PERDISC_BILL").Visible = False
				dgvData.Columns("LPURSE").Visible = False
				dgvData.Columns("LVAT").Visible = False
				dgvData.Columns("TENDERAMT").Visible = False
				dgvData.Columns("TIP").Visible = False
				dgvData.Columns("SERVICE").Visible = False
				dgvData.Columns("TIMEAMT").Visible = False
				dgvData.Columns("REMARK").Visible = False
				dgvData.Columns("PERDISC_BILLMIX").Visible = False
				dgvData.Columns("PERTIME").Visible = False
				dgvData.Columns("TONGCONG").Visible = False
				dgvData.Columns("MAHTTT").Visible = False
				dgvData.Columns("MAUSERPV").Visible = False
				flag = mdlVariable.gblnLBILLSOHD_NGAN
				If flag Then
					dgvData.Columns("SOCT").Visible = False
					dgvData.Columns("SOTT").Visible = False
					flag = mdlVariable.gblnLSHOWSOHDTT
					If flag Then
						dgvData.Columns("SOCTNGAN").Visible = False
					Else
						dgvData.Columns("SOTTNGAN").Visible = False
					End If
				Else
					dgvData.Columns("SOCTNGAN").Visible = False
					dgvData.Columns("SOTTNGAN").Visible = False
					flag = mdlVariable.gblnLSHOWSOHDTT
					If flag Then
						dgvData.Columns("SOCT").Visible = False
					Else
						dgvData.Columns("SOTT").Visible = False
					End If
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060003FA RID: 1018 RVA: 0x0002FEEC File Offset: 0x0002E0EC
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnSelect.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060003FB RID: 1019 RVA: 0x0002FFE4 File Offset: 0x0002E1E4
		Public Function gf_GetData_4Grid(strTu As String, strDen As String) As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(6) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchKH"
				array(0).Value = mdlVariable.gStrStockCode
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@intDecAmt"
				array(1).Value = mdlVariable.gbytDECNUMAMT
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@intDecQty"
				array(2).Value = mdlVariable.gbytDECNUMQTY
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@intDecAmt_for"
				array(3).Value = mdlVariable.gbytDECNUMFOR
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@nvcNGAY"
				array(4).Value = strTu
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@nvcDENNGAY"
				array(5).Value = strDen
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMBANCHUATT_GET_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Dim flag2 As Boolean = mdlVariable.gblnONLYUSERREPORT
					If flag2 Then
						Me.mbdsSource.Filter = "MaUSER='" + mdlVariable.gStrUser + "'"
					End If
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					flag2 = clsConnect.Rows.Count > 0
					If flag2 Then
						Me.lblToTal.Text = clsConnect.Rows(0)("TONGCONG").ToString()
					Else
						Me.lblToTal.Text = "0"
					End If
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gf_GetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060003FC RID: 1020 RVA: 0x00030264 File Offset: 0x0002E464
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 7
				If flag Then
					Me.btnSelect.Visible = True
				Else
					Me.btnSelect.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060003FD RID: 1021 RVA: 0x00030344 File Offset: 0x0002E544
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, String.Concat(New String() { Me.mArrStrFrmMess(2), " [", Strings.Mid(mdlVariable.gStrSelectMonth, 5, 2), "/", Strings.Mid(mdlVariable.gStrSelectMonth, 1, 4), " ] ", Me.mArrStrFrmMess(22), " [", mdlVariable.gstrStockName, "]" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "6070100000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060003FE RID: 1022 RVA: 0x000304E0 File Offset: 0x0002E6E0
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060003FF RID: 1023 RVA: 0x0003058C File Offset: 0x0002E78C
		Private Sub mtxTODATE_TextChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource Is Nothing
				If Not flag Then
					Dim text As String = Strings.Mid(Me.mtxDATE.Text, 3, 1)
					Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtxDATE.Text, text, "", 1, -1, CompareMethod.Binary))
					Dim text3 As String = Strings.Trim(Strings.Replace(Me.mtxTODATE.Text, text, "", 1, -1, CompareMethod.Binary))
					flag = Strings.Len(text2) < 8
					If Not flag Then
						flag = Strings.Len(text3) < 8
						If Not flag Then
							text2 = text2.Substring(4) + text2.Substring(2, 2) + text2.Substring(0, 2)
							text3 = text3.Substring(4) + text3.Substring(2, 2) + text3.Substring(0, 2)
							flag = Me.gf_GetData_4Grid(text2, text3) = 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
							End If
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxToDATE_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0400019E RID: 414
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040001A0 RID: 416
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x040001A1 RID: 417
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x040001A2 RID: 418
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x040001A3 RID: 419
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x040001A4 RID: 420
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x040001A5 RID: 421
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x040001A6 RID: 422
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x040001A7 RID: 423
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040001A8 RID: 424
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040001A9 RID: 425
		<AccessedThroughProperty("lblFilterDate")>
		Private _lblFilterDate As Label

		' Token: 0x040001AA RID: 426
		<AccessedThroughProperty("btnCancel")>
		Private _btnCancel As Button

		' Token: 0x040001AB RID: 427
		<AccessedThroughProperty("mtxDATE")>
		Private _mtxDATE As MaskedTextBox

		' Token: 0x040001AC RID: 428
		<AccessedThroughProperty("btnDetail")>
		Private _btnDetail As Button

		' Token: 0x040001AD RID: 429
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040001AE RID: 430
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040001AF RID: 431
		<AccessedThroughProperty("dtpTuNgay")>
		Private _dtpTuNgay As DateTimePicker

		' Token: 0x040001B0 RID: 432
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x040001B1 RID: 433
		<AccessedThroughProperty("mtxTODATE")>
		Private _mtxTODATE As MaskedTextBox

		' Token: 0x040001B2 RID: 434
		<AccessedThroughProperty("dtpDenNgay")>
		Private _dtpDenNgay As DateTimePicker

		' Token: 0x040001B3 RID: 435
		<AccessedThroughProperty("lblToTal")>
		Private _lblToTal As Label

		' Token: 0x040001B4 RID: 436
		Private mArrStrFrmMess As String()

		' Token: 0x040001B5 RID: 437
		Private mStrSOCT As String

		' Token: 0x040001B6 RID: 438
		Private mStrNGAYGS As String

		' Token: 0x040001B7 RID: 439
		Private mStrNGAYCT As String

		' Token: 0x040001B8 RID: 440
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040001B9 RID: 441
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040001BA RID: 442
		Private marrDrFind As DataRow()

		' Token: 0x040001BB RID: 443
		Private mintFindLastPos As Integer

		' Token: 0x040001BC RID: 444
		Private mblnAutoAdd As Boolean

		' Token: 0x040001BD RID: 445
		Private mbytLen_OBJID As Byte

		' Token: 0x040001BE RID: 446
		Private mclsTbDMKH As clsConnect
	End Class
End Namespace
