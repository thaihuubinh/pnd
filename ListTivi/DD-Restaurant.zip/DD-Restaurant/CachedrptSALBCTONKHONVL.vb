﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200032E RID: 814
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptSALBCTONKHONVL
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600722E RID: 29230 RVA: 0x000144BD File Offset: 0x000126BD
		Public Sub New()
			CachedrptSALBCTONKHONVL.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002FF7 RID: 12279
		' (get) Token: 0x0600722F RID: 29231 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06007230 RID: 29232 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002FF8 RID: 12280
		' (get) Token: 0x06007231 RID: 29233 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06007232 RID: 29234 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002FF9 RID: 12281
		' (get) Token: 0x06007233 RID: 29235 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06007234 RID: 29236 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06007235 RID: 29237 RVA: 0x004DF804 File Offset: 0x004DDA04
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptSALBCTONKHONVL() With { .Site = Me.Site }
		End Function

		' Token: 0x06007236 RID: 29238 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002926 RID: 10534
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
