﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200001D RID: 29
	<DesignerGenerated()>
	Public Partial Class frmCAL_PURSE
		Inherits Form

		' Token: 0x0600047B RID: 1147 RVA: 0x000364BC File Offset: 0x000346BC
		<DebuggerNonUserCode()>
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmCAL_PURSE_load
			AddHandler MyBase.FormClosing, AddressOf Me.frmCAL_PURSE_FormClosing
			frmCAL_PURSE.__ENCList.Add(New WeakReference(Me))
			Me.InitializeComponent()
		End Sub

		' Token: 0x170001B4 RID: 436
		' (get) Token: 0x0600047E RID: 1150 RVA: 0x00037218 File Offset: 0x00035418
		' (set) Token: 0x0600047F RID: 1151 RVA: 0x00002C4B File Offset: 0x00000E4B
		Friend Overridable Property lblSTARTDATE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblSTARTDATE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblSTARTDATE = value
			End Set
		End Property

		' Token: 0x170001B5 RID: 437
		' (get) Token: 0x06000480 RID: 1152 RVA: 0x00037230 File Offset: 0x00035430
		' (set) Token: 0x06000481 RID: 1153 RVA: 0x00002C55 File Offset: 0x00000E55
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x170001B6 RID: 438
		' (get) Token: 0x06000482 RID: 1154 RVA: 0x00037248 File Offset: 0x00035448
		' (set) Token: 0x06000483 RID: 1155 RVA: 0x00037260 File Offset: 0x00035460
		Friend Overridable Property btnOK As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnOK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnOK IsNot Nothing
				If flag Then
					RemoveHandler Me._btnOK.Click, AddressOf Me.btnOK_Click
				End If
				Me._btnOK = value
				flag = Me._btnOK IsNot Nothing
				If flag Then
					AddHandler Me._btnOK.Click, AddressOf Me.btnOK_Click
				End If
			End Set
		End Property

		' Token: 0x170001B7 RID: 439
		' (get) Token: 0x06000484 RID: 1156 RVA: 0x000372CC File Offset: 0x000354CC
		' (set) Token: 0x06000485 RID: 1157 RVA: 0x000372E4 File Offset: 0x000354E4
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170001B8 RID: 440
		' (get) Token: 0x06000486 RID: 1158 RVA: 0x00037350 File Offset: 0x00035550
		' (set) Token: 0x06000487 RID: 1159 RVA: 0x00037368 File Offset: 0x00035568
		Friend Overridable Property txtFromMonth As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtFromMonth
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtFromMonth IsNot Nothing
				If flag Then
					RemoveHandler Me._txtFromMonth.GotFocus, AddressOf Me.txtFromMonth_GotFocus
				End If
				Me._txtFromMonth = value
				flag = Me._txtFromMonth IsNot Nothing
				If flag Then
					AddHandler Me._txtFromMonth.GotFocus, AddressOf Me.txtFromMonth_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170001B9 RID: 441
		' (get) Token: 0x06000488 RID: 1160 RVA: 0x000373D4 File Offset: 0x000355D4
		' (set) Token: 0x06000489 RID: 1161 RVA: 0x000373EC File Offset: 0x000355EC
		Friend Overridable Property txtToMonth As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtToMonth
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtToMonth IsNot Nothing
				If flag Then
					RemoveHandler Me._txtToMonth.GotFocus, AddressOf Me.txtToMonth_GotFocus
				End If
				Me._txtToMonth = value
				flag = Me._txtToMonth IsNot Nothing
				If flag Then
					AddHandler Me._txtToMonth.GotFocus, AddressOf Me.txtToMonth_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170001BA RID: 442
		' (get) Token: 0x0600048A RID: 1162 RVA: 0x00037458 File Offset: 0x00035658
		' (set) Token: 0x0600048B RID: 1163 RVA: 0x00002C5F File Offset: 0x00000E5F
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x170001BB RID: 443
		' (get) Token: 0x0600048C RID: 1164 RVA: 0x00037470 File Offset: 0x00035670
		' (set) Token: 0x0600048D RID: 1165 RVA: 0x00037488 File Offset: 0x00035688
		Friend Overridable Property txtToYear As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtToYear
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtToYear IsNot Nothing
				If flag Then
					RemoveHandler Me._txtToYear.GotFocus, AddressOf Me.txtToYear_GotFocus
				End If
				Me._txtToYear = value
				flag = Me._txtToYear IsNot Nothing
				If flag Then
					AddHandler Me._txtToYear.GotFocus, AddressOf Me.txtToYear_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170001BC RID: 444
		' (get) Token: 0x0600048E RID: 1166 RVA: 0x000374F4 File Offset: 0x000356F4
		' (set) Token: 0x0600048F RID: 1167 RVA: 0x00002C69 File Offset: 0x00000E69
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x170001BD RID: 445
		' (get) Token: 0x06000490 RID: 1168 RVA: 0x0003750C File Offset: 0x0003570C
		' (set) Token: 0x06000491 RID: 1169 RVA: 0x00037524 File Offset: 0x00035724
		Friend Overridable Property txtFromYear As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtFromYear
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtFromYear IsNot Nothing
				If flag Then
					RemoveHandler Me._txtFromYear.GotFocus, AddressOf Me.txtFromYear_GotFocus
				End If
				Me._txtFromYear = value
				flag = Me._txtFromYear IsNot Nothing
				If flag Then
					AddHandler Me._txtFromYear.GotFocus, AddressOf Me.txtFromYear_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170001BE RID: 446
		' (get) Token: 0x06000492 RID: 1170 RVA: 0x00037590 File Offset: 0x00035790
		' (set) Token: 0x06000493 RID: 1171 RVA: 0x00002C73 File Offset: 0x00000E73
		Friend Overridable Property Label3 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		' Token: 0x170001BF RID: 447
		' (get) Token: 0x06000494 RID: 1172 RVA: 0x000375A8 File Offset: 0x000357A8
		' (set) Token: 0x06000495 RID: 1173 RVA: 0x00002C7D File Offset: 0x00000E7D
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x170001C0 RID: 448
		' (get) Token: 0x06000496 RID: 1174 RVA: 0x000375C0 File Offset: 0x000357C0
		' (set) Token: 0x06000497 RID: 1175 RVA: 0x000375D8 File Offset: 0x000357D8
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x170001C1 RID: 449
		' (get) Token: 0x06000498 RID: 1176 RVA: 0x00037644 File Offset: 0x00035844
		' (set) Token: 0x06000499 RID: 1177 RVA: 0x0003765C File Offset: 0x0003585C
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x170001C2 RID: 450
		' (get) Token: 0x0600049A RID: 1178 RVA: 0x000376C8 File Offset: 0x000358C8
		' (set) Token: 0x0600049B RID: 1179 RVA: 0x000376E0 File Offset: 0x000358E0
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x170001C3 RID: 451
		' (get) Token: 0x0600049C RID: 1180 RVA: 0x0003774C File Offset: 0x0003594C
		' (set) Token: 0x0600049D RID: 1181 RVA: 0x00037764 File Offset: 0x00035964
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x170001C4 RID: 452
		' (get) Token: 0x0600049E RID: 1182 RVA: 0x000377D0 File Offset: 0x000359D0
		' (set) Token: 0x0600049F RID: 1183 RVA: 0x00002C87 File Offset: 0x00000E87
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x060004A0 RID: 1184 RVA: 0x000377E8 File Offset: 0x000359E8
		Private Sub txtFromMonth_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtFromMonth.[ReadOnly]
				If [readOnly] Then
					Me.btnNext.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - txtFromMonth_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004A1 RID: 1185 RVA: 0x00037894 File Offset: 0x00035A94
		Private Sub txtFromYear_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtFromYear.[ReadOnly]
				If [readOnly] Then
					Me.btnNext.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - txtFromYear_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004A2 RID: 1186 RVA: 0x00037940 File Offset: 0x00035B40
		Private Sub txtToMonth_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtToMonth.[ReadOnly]
				If [readOnly] Then
					Me.btnNext.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - txtToMonth_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004A3 RID: 1187 RVA: 0x000379EC File Offset: 0x00035BEC
		Private Sub txtToYear_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtToYear.[ReadOnly]
				If [readOnly] Then
					Me.btnNext.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - txtToYear_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004A4 RID: 1188 RVA: 0x00037A98 File Offset: 0x00035C98
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.txtToMonth.Text = Me.txtFromMonth.Text
				Me.txtToYear.Text = Me.txtFromYear.Text
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - txtToYear_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004A5 RID: 1189 RVA: 0x00037B58 File Offset: 0x00035D58
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				Me.txtToMonth.Text = DateTime.Today.Month.ToString("00")
				Me.txtToYear.Text = DateTime.Today.Year.ToString("0000")
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004A6 RID: 1190 RVA: 0x00037C38 File Offset: 0x00035E38
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = (Operators.CompareString(Me.txtToMonth.Text, Me.txtFromMonth.Text, False) = 0) And (Operators.CompareString(Me.txtToYear.Text, Me.txtFromYear.Text, False) = 0)
				If Not flag Then
					flag = Operators.CompareString(Me.txtToMonth.Text, "01", False) = 0
					If flag Then
						Me.txtToMonth.Text = "12"
						Me.txtToYear.Text = Conversions.ToString(Conversion.Val(Me.txtToYear.Text) - 1.0)
					Else
						Me.txtToMonth.Text = (Conversion.Val(Me.txtToMonth.Text) - 1.0).ToString("00")
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004A7 RID: 1191 RVA: 0x00037DBC File Offset: 0x00035FBC
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = (Operators.CompareString(Me.txtToMonth.Text, DateTime.Today.Month.ToString("00"), False) = 0) And (Operators.CompareString(Me.txtToYear.Text, DateTime.Today.Year.ToString("0000"), False) = 0)
				If Not flag Then
					flag = Operators.CompareString(Me.txtToMonth.Text, "12", False) = 0
					If flag Then
						Me.txtToMonth.Text = "01"
						Me.txtToYear.Text = Conversions.ToString(Conversion.Val(Me.txtToYear.Text) + 1.0)
					Else
						Me.txtToMonth.Text = (Conversion.Val(Me.txtToMonth.Text) + 1.0).ToString("00")
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004A8 RID: 1192 RVA: 0x00037F6C File Offset: 0x0003616C
		Private Sub frmCAL_PURSE_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - frmCAL_PURSE_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004A9 RID: 1193 RVA: 0x00038004 File Offset: 0x00036204
		Private Sub frmCAL_PURSE_load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - frmCAL_PURSE_load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004AA RID: 1194 RVA: 0x000380B0 File Offset: 0x000362B0
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.sClear_Form()
				mdlFile.gfWriteLogFile("Nhấn thoát form tính giá vốn.")
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060004AB RID: 1195 RVA: 0x00038154 File Offset: 0x00036354
		Private Sub btnOK_Click(sender As Object, e As EventArgs)
			Try
				mdlFile.gfWriteLogFile(String.Concat(New String() { "Nhấn đồng ý tính giá vốn từ ", Me.txtFromMonth.Text, "/", Me.txtFromYear.Text, " đến ", Me.txtToMonth.Text, "/", Me.txtToYear.Text }))
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				Dim text As String = mdlBalance.gf_Cal_Purse(Me.txtFromYear.Text, Me.txtFromMonth.Text, Me.txtToYear.Text, Me.txtToMonth.Text)
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0
				If flag Then
					Interaction.MsgBox(text, MsgBoxStyle.Critical, Nothing)
					mdlFile.gfWriteLogFile("Hiện thông báo âm kho hàng hóa khi tính giá vốn.")
				Else
					Dim text2 As String = mdlBalance.gf_Cal_Purse_NVL(Me.txtFromYear.Text, Me.txtFromMonth.Text, Me.txtToYear.Text, Me.txtToMonth.Text)
					flag = Operators.CompareString(text2, "", False) <> 0
					If flag Then
						Interaction.MsgBox(text2, MsgBoxStyle.Critical, Nothing)
						mdlFile.gfWriteLogFile("Hiện thông báo âm kho NVL khi tính giá vốn.")
					End If
					flag = (Operators.CompareString(text, "", False) = 0) And (Operators.CompareString(text2, "", False) = 0)
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(8), MsgBoxStyle.Information, Nothing)
						mdlFile.gfWriteLogFile("Hiện thông báo tính giá vốn thành công.")
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - btnOK_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				Me.Close()
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
			End Try
		End Sub

		' Token: 0x060004AC RID: 1196 RVA: 0x000383A0 File Offset: 0x000365A0
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtFromMonth.[ReadOnly] = True
				Me.txtFromYear.[ReadOnly] = True
				Me.txtToMonth.[ReadOnly] = True
				Me.txtToYear.[ReadOnly] = True
				Dim text As String = mdlGeneral.gfCheck_Start("S")
				Dim text2 As String = mdlGeneral.gfCheck_Start("L")
				Dim flag As Boolean = (Operators.CompareString(text2, "", False) <> 0) And (Operators.CompareString(text2, text, False) > 0)
				Dim text3 As String
				If flag Then
					Dim dateTime As DateTime = Conversions.ToDate(String.Concat(New String() { Strings.Mid(text2, 1, 4), "/", Strings.Mid(text2, 5, 2), "/", Strings.Mid(text2, 7, 2) }))
					dateTime = DateAndTime.DateAdd(DateInterval.Day, 1.0, dateTime)
					text3 = dateTime.Year.ToString("0000") + dateTime.Month.ToString("00")
				Else
					text3 = text
				End If
				Me.txtFromMonth.Text = Strings.Mid(text3, 5, 2)
				Me.txtFromYear.Text = Strings.Mid(text3, 1, 4)
				Me.txtToMonth.Text = DateTime.Today.Month.ToString("00")
				Me.txtToYear.Text = DateTime.Today.Year.ToString("0000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060004AD RID: 1197 RVA: 0x00038604 File Offset: 0x00036804
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(1))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060004AE RID: 1198 RVA: 0x00038710 File Offset: 0x00036910
		Private Sub sClear_Form()
			Try
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(7), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x040001EF RID: 495
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040001F1 RID: 497
		<AccessedThroughProperty("lblSTARTDATE")>
		Private _lblSTARTDATE As Label

		' Token: 0x040001F2 RID: 498
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x040001F3 RID: 499
		<AccessedThroughProperty("btnOK")>
		Private _btnOK As Button

		' Token: 0x040001F4 RID: 500
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040001F5 RID: 501
		<AccessedThroughProperty("txtFromMonth")>
		Private _txtFromMonth As TextBox

		' Token: 0x040001F6 RID: 502
		<AccessedThroughProperty("txtToMonth")>
		Private _txtToMonth As TextBox

		' Token: 0x040001F7 RID: 503
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x040001F8 RID: 504
		<AccessedThroughProperty("txtToYear")>
		Private _txtToYear As TextBox

		' Token: 0x040001F9 RID: 505
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x040001FA RID: 506
		<AccessedThroughProperty("txtFromYear")>
		Private _txtFromYear As TextBox

		' Token: 0x040001FB RID: 507
		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		' Token: 0x040001FC RID: 508
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x040001FD RID: 509
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x040001FE RID: 510
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x040001FF RID: 511
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000200 RID: 512
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000201 RID: 513
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000202 RID: 514
		Private mArrStrFrmMess As String()
	End Class
End Namespace
