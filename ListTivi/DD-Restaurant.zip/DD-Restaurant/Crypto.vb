﻿Imports System
Imports System.Diagnostics
Imports System.Security.Cryptography
Imports System.Text
Imports System.Windows.Forms

Namespace prjIS_SalesPOS
	' Token: 0x020000EB RID: 235
	Public Class Crypto
		' Token: 0x06005471 RID: 21617 RVA: 0x00007789 File Offset: 0x00005989
		<DebuggerNonUserCode()>
		Public Sub New()
		End Sub

		' Token: 0x06005472 RID: 21618 RVA: 0x00483AE4 File Offset: 0x00481CE4
		Public Shared Function MD5Hash(value As String) As Byte()
			Return Crypto.MD5.ComputeHash(Encoding.ASCII.GetBytes(value))
		End Function

		' Token: 0x06005473 RID: 21619 RVA: 0x00483B0C File Offset: 0x00481D0C
		Public Shared Function Encrypt(stringToEncrypt As String, Optional key As String = "cocke") As String
			Crypto.DES.Key = Crypto.MD5Hash(key)
			Crypto.DES.Mode = CipherMode.ECB
			Dim bytes As Byte() = Encoding.ASCII.GetBytes(stringToEncrypt)
			Return Convert.ToBase64String(Crypto.DES.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length))
		End Function

		' Token: 0x06005474 RID: 21620 RVA: 0x00483B60 File Offset: 0x00481D60
		Public Shared Function Decrypt(encryptedString As String, Optional key As String = "cocke") As String
			Dim text As String
			Try
				Crypto.DES.Key = Crypto.MD5Hash(key)
				Crypto.DES.Mode = CipherMode.ECB
				Dim array As Byte() = Convert.FromBase64String(encryptedString)
				text = Encoding.ASCII.GetString(Crypto.DES.CreateDecryptor().TransformFinalBlock(array, 0, array.Length))
			Catch ex As Exception
				MessageBox.Show("Invalid", "Decryption Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
				text = ""
			End Try
			Return text
		End Function

		' Token: 0x040024DD RID: 9437
		Private Shared DES As TripleDESCryptoServiceProvider = New TripleDESCryptoServiceProvider()

		' Token: 0x040024DE RID: 9438
		Private Shared MD5 As MD5CryptoServiceProvider = New MD5CryptoServiceProvider()
	End Class
End Namespace
