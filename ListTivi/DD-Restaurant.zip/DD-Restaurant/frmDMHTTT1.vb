﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000051 RID: 81
	<DesignerGenerated()>
	Public Partial Class frmDMHTTT1
		Inherits Form

		' Token: 0x0600181D RID: 6173 RVA: 0x0012B490 File Offset: 0x00129690
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmdmhttt1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmdmhttt1_Load
			frmDMHTTT1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mclsTbStore = New clsConnect()
			Me.mblnAutoAdd_DMHTTT = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700085B RID: 2139
		' (get) Token: 0x06001820 RID: 6176 RVA: 0x0012C730 File Offset: 0x0012A930
		' (set) Token: 0x06001821 RID: 6177 RVA: 0x00005901 File Offset: 0x00003B01
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x1700085C RID: 2140
		' (get) Token: 0x06001822 RID: 6178 RVA: 0x0012C748 File Offset: 0x0012A948
		' (set) Token: 0x06001823 RID: 6179 RVA: 0x0012C760 File Offset: 0x0012A960
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x1700085D RID: 2141
		' (get) Token: 0x06001824 RID: 6180 RVA: 0x0012C7CC File Offset: 0x0012A9CC
		' (set) Token: 0x06001825 RID: 6181 RVA: 0x0012C7E4 File Offset: 0x0012A9E4
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x1700085E RID: 2142
		' (get) Token: 0x06001826 RID: 6182 RVA: 0x0012C850 File Offset: 0x0012AA50
		' (set) Token: 0x06001827 RID: 6183 RVA: 0x0012C868 File Offset: 0x0012AA68
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x1700085F RID: 2143
		' (get) Token: 0x06001828 RID: 6184 RVA: 0x0012C8D4 File Offset: 0x0012AAD4
		' (set) Token: 0x06001829 RID: 6185 RVA: 0x0012C8EC File Offset: 0x0012AAEC
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000860 RID: 2144
		' (get) Token: 0x0600182A RID: 6186 RVA: 0x0012C958 File Offset: 0x0012AB58
		' (set) Token: 0x0600182B RID: 6187 RVA: 0x0012C970 File Offset: 0x0012AB70
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000861 RID: 2145
		' (get) Token: 0x0600182C RID: 6188 RVA: 0x0012C9DC File Offset: 0x0012ABDC
		' (set) Token: 0x0600182D RID: 6189 RVA: 0x0012C9F4 File Offset: 0x0012ABF4
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000862 RID: 2146
		' (get) Token: 0x0600182E RID: 6190 RVA: 0x0012CA60 File Offset: 0x0012AC60
		' (set) Token: 0x0600182F RID: 6191 RVA: 0x0012CA78 File Offset: 0x0012AC78
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000863 RID: 2147
		' (get) Token: 0x06001830 RID: 6192 RVA: 0x0012CAE4 File Offset: 0x0012ACE4
		' (set) Token: 0x06001831 RID: 6193 RVA: 0x0000590B File Offset: 0x00003B0B
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000864 RID: 2148
		' (get) Token: 0x06001832 RID: 6194 RVA: 0x0012CAFC File Offset: 0x0012ACFC
		' (set) Token: 0x06001833 RID: 6195 RVA: 0x0012CB14 File Offset: 0x0012AD14
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000865 RID: 2149
		' (get) Token: 0x06001834 RID: 6196 RVA: 0x0012CB80 File Offset: 0x0012AD80
		' (set) Token: 0x06001835 RID: 6197 RVA: 0x0012CB98 File Offset: 0x0012AD98
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x17000866 RID: 2150
		' (get) Token: 0x06001836 RID: 6198 RVA: 0x0012CC04 File Offset: 0x0012AE04
		' (set) Token: 0x06001837 RID: 6199 RVA: 0x0012CC1C File Offset: 0x0012AE1C
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000867 RID: 2151
		' (get) Token: 0x06001838 RID: 6200 RVA: 0x0012CC88 File Offset: 0x0012AE88
		' (set) Token: 0x06001839 RID: 6201 RVA: 0x00005915 File Offset: 0x00003B15
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x17000868 RID: 2152
		' (get) Token: 0x0600183A RID: 6202 RVA: 0x0012CCA0 File Offset: 0x0012AEA0
		' (set) Token: 0x0600183B RID: 6203 RVA: 0x0012CCB8 File Offset: 0x0012AEB8
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x17000869 RID: 2153
		' (get) Token: 0x0600183C RID: 6204 RVA: 0x0012CD24 File Offset: 0x0012AF24
		' (set) Token: 0x0600183D RID: 6205 RVA: 0x0012CD3C File Offset: 0x0012AF3C
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x1700086A RID: 2154
		' (get) Token: 0x0600183E RID: 6206 RVA: 0x0012CDA8 File Offset: 0x0012AFA8
		' (set) Token: 0x0600183F RID: 6207 RVA: 0x0012CDC0 File Offset: 0x0012AFC0
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700086B RID: 2155
		' (get) Token: 0x06001840 RID: 6208 RVA: 0x0012CE2C File Offset: 0x0012B02C
		' (set) Token: 0x06001841 RID: 6209 RVA: 0x0012CE44 File Offset: 0x0012B044
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x1700086C RID: 2156
		' (get) Token: 0x06001842 RID: 6210 RVA: 0x0012CEB0 File Offset: 0x0012B0B0
		' (set) Token: 0x06001843 RID: 6211 RVA: 0x0012CEC8 File Offset: 0x0012B0C8
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x1700086D RID: 2157
		' (get) Token: 0x06001844 RID: 6212 RVA: 0x0012CF34 File Offset: 0x0012B134
		' (set) Token: 0x06001845 RID: 6213 RVA: 0x0012CF4C File Offset: 0x0012B14C
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x1700086E RID: 2158
		' (get) Token: 0x06001846 RID: 6214 RVA: 0x0012CFB8 File Offset: 0x0012B1B8
		' (set) Token: 0x06001847 RID: 6215 RVA: 0x0000591F File Offset: 0x00003B1F
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x1700086F RID: 2159
		' (get) Token: 0x06001848 RID: 6216 RVA: 0x0012CFD0 File Offset: 0x0012B1D0
		' (set) Token: 0x06001849 RID: 6217 RVA: 0x0012CFE8 File Offset: 0x0012B1E8
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000870 RID: 2160
		' (get) Token: 0x0600184A RID: 6218 RVA: 0x0012D054 File Offset: 0x0012B254
		' (set) Token: 0x0600184B RID: 6219 RVA: 0x00005929 File Offset: 0x00003B29
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x17000871 RID: 2161
		' (get) Token: 0x0600184C RID: 6220 RVA: 0x0012D06C File Offset: 0x0012B26C
		' (set) Token: 0x0600184D RID: 6221 RVA: 0x00005934 File Offset: 0x00003B34
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000872 RID: 2162
		' (get) Token: 0x0600184E RID: 6222 RVA: 0x0012D084 File Offset: 0x0012B284
		' (set) Token: 0x0600184F RID: 6223 RVA: 0x0000593F File Offset: 0x00003B3F
		Public Property pbytDEBT As Byte
			Get
				Return Me.mbytDebt
			End Get
			Set(value As Byte)
				Me.mbytDebt = value
			End Set
		End Property

		' Token: 0x17000873 RID: 2163
		' (get) Token: 0x06001850 RID: 6224 RVA: 0x0012D09C File Offset: 0x0012B29C
		' (set) Token: 0x06001851 RID: 6225 RVA: 0x0000594A File Offset: 0x00003B4A
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06001852 RID: 6226 RVA: 0x0012D0B4 File Offset: 0x0012B2B4
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				Me.mStrOBJNAME = Me.dgvData.CurrentRow.Cells("OBJNAME").Value.ToString().Trim() + "  " + Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value.ToString().Trim()
				Me.mbytDebt = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("LDEBT").Value)
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001853 RID: 6227 RVA: 0x0012D224 File Offset: 0x0012B424
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001854 RID: 6228 RVA: 0x0012D2F4 File Offset: 0x0012B4F4
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001855 RID: 6229 RVA: 0x0012D3E4 File Offset: 0x0012B5E4
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001856 RID: 6230 RVA: 0x0012D4C8 File Offset: 0x0012B6C8
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001857 RID: 6231 RVA: 0x0012D58C File Offset: 0x0012B78C
		Private Sub frmdmhttt1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmdmhttt1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001858 RID: 6232 RVA: 0x0012D624 File Offset: 0x0012B824
		Private Sub frmdmhttt1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Combo()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
				Me.sGetPara_From_SetparaXML()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmdmhttt1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001859 RID: 6233 RVA: 0x0012D744 File Offset: 0x0012B944
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600185A RID: 6234 RVA: 0x0012D84C File Offset: 0x0012BA4C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600185B RID: 6235 RVA: 0x0012D8E4 File Offset: 0x0012BAE4
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMHTTT As frmDMHTTT2 = New frmDMHTTT2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMHTTT.pbytFromStatus = 1
				Dim flag As Boolean = Me.mblnAutoAdd_DMHTTT
				Dim flag3 As Boolean
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMhttt_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						flag3 = Conversions.ToDouble(array(0).Value.ToString()) < 10.0
						If flag3 Then
							frmDMHTTT.txtOBJID.Text = "0" + array(0).Value.ToString()
						Else
							frmDMHTTT.txtOBJID.Text = array(0).Value.ToString()
						End If
						frmDMHTTT.txtOBJID.[ReadOnly] = True
						frmDMHTTT.txtOBJID.BackColor = frmDMHTTT.txtColor.BackColor
					End If
				End If
				frmDMHTTT.ShowDialog()
				flag3 = frmDMHTTT.pbytSuccess = 0
				If Not flag3 Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag3 = b = 0
					If flag3 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag3 = b <> 0
					If flag3 Then
						b = Me.fInitGrid()
					End If
					flag3 = b <> 0
					If flag3 Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMHTTT.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMHTTT.Dispose()
			End Try
		End Sub

		' Token: 0x0600185C RID: 6236 RVA: 0x0012DB5C File Offset: 0x0012BD5C
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMHTTT As frmDMHTTT2 = New frmDMHTTT2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMHTTT2 As frmDMHTTT2 = frmDMHTTT
				frmDMHTTT2.pbytFromStatus = 2
				frmDMHTTT2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMHTTT2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
				frmDMHTTT2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMHTTT2.chkISSUP.Checked = False
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LDEBT").Value)
				If flag Then
					frmDMHTTT2.chkISSUP.Checked = True
				End If
				flag = Me.mblnAutoAdd_DMHTTT
				Dim flag3 As Boolean
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHTTT_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						flag3 = Conversions.ToDouble(array(0).Value.ToString()) < 10.0
						If flag3 Then
							frmDMHTTT.txtOBJID.Text = "0" + array(0).Value.ToString()
						Else
							frmDMHTTT.txtOBJID.Text = array(0).Value.ToString()
						End If
						frmDMHTTT.txtOBJID.[ReadOnly] = True
						frmDMHTTT.txtOBJID.BackColor = frmDMHTTT.txtColor.BackColor
					End If
				End If
				frmDMHTTT.ShowDialog()
				flag3 = frmDMHTTT.pbytSuccess = 0
				If Not flag3 Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag3 = b = 0
					If flag3 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag3 = b <> 0
					If flag3 Then
						b = Me.fInitGrid()
					End If
					flag3 = b <> 0
					If flag3 Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMHTTT.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMHTTT.Dispose()
			End Try
		End Sub

		' Token: 0x0600185D RID: 6237 RVA: 0x0012DED0 File Offset: 0x0012C0D0
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMHTTT As frmDMHTTT2 = New frmDMHTTT2()
			Dim flag As Boolean = False
			Try
				Dim flag2 As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag2 Then
					flag = True
				End If
				Dim frmDMHTTT2 As frmDMHTTT2 = frmDMHTTT
				frmDMHTTT2.pbytFromStatus = 3
				frmDMHTTT2.pblnFix = flag
				frmDMHTTT2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMHTTT2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMHTTT2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
				frmDMHTTT2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("remark").Value, ""))
				frmDMHTTT2.chkISSUP.Checked = False
				flag2 = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LDEBT").Value)
				If flag2 Then
					frmDMHTTT2.chkISSUP.Checked = True
				End If
				flag2 = flag
				If flag2 Then
					frmDMHTTT2.chkISSUP.Enabled = False
				End If
				frmDMHTTT.ShowDialog()
				flag2 = frmDMHTTT.pbytSuccess = 0
				If Not flag2 Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag2 = b = 0
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag2 = b <> 0
					If flag2 Then
						b = Me.fInitGrid()
					End If
					flag2 = b <> 0
					If flag2 Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMHTTT.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMHTTT.Dispose()
			End Try
		End Sub

		' Token: 0x0600185E RID: 6238 RVA: 0x0012E1B4 File Offset: 0x0012C3B4
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMHTTT As frmDMHTTT2 = New frmDMHTTT2()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
					frmDMHTTT.Dispose()
				Else
					Dim frmDMHTTT2 As frmDMHTTT2 = frmDMHTTT
					frmDMHTTT2.pbytFromStatus = 4
					frmDMHTTT2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMHTTT2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMHTTT2.txtSUBOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
					frmDMHTTT2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
					frmDMHTTT2.chkISSUP.Checked = False
					flag = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LDEBT").Value)
					If flag Then
						frmDMHTTT2.chkISSUP.Checked = True
					End If
					frmDMHTTT.ShowDialog()
					flag = frmDMHTTT.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMHTTT.Dispose()
			End Try
		End Sub

		' Token: 0x0600185F RID: 6239 RVA: 0x0012E468 File Offset: 0x0012C668
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMHTTT As frmDMHTTT2 = New frmDMHTTT2()
			Try
				frmDMHTTT.pbytFromStatus = 6
				frmDMHTTT.ShowDialog()
				Dim flag As Boolean = frmDMHTTT.pbytSuccess = 0
				If flag Then
					frmDMHTTT.Dispose()
				Else
					Dim text As String = ""
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMHTTT.pStrFilter + text, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMHTTT.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMHTTT.Dispose()
			End Try
		End Sub

		' Token: 0x06001860 RID: 6240 RVA: 0x0012E66C File Offset: 0x0012C86C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMHTTT As frmDMHTTT2 = New frmDMHTTT2()
			Try
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				frmDMHTTT.pbytFromStatus = 5
				frmDMHTTT.ShowDialog()
				Dim flag As Boolean = frmDMHTTT.pbytSuccess = 0
				If Not flag Then
					Dim text As String = ""
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMHTTT.pStrFilter + text
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMHTTT.Dispose()
			End Try
		End Sub

		' Token: 0x06001861 RID: 6241 RVA: 0x0012E790 File Offset: 0x0012C990
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMHTTT As frmDMHTTT2 = New frmDMHTTT2()
			Try
				Dim text As String = ""
				Me.mbdsSource.RemoveFilter()
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0
				If flag Then
					Me.mbdsSource.Filter = text
				End If
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMHTTT.Dispose()
			End Try
		End Sub

		' Token: 0x06001862 RID: 6242 RVA: 0x0012E884 File Offset: 0x0012CA84
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x06001863 RID: 6243 RVA: 0x0012EA00 File Offset: 0x0012CC00
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fPrintFRMDMHTTT()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001864 RID: 6244 RVA: 0x0012EA98 File Offset: 0x0012CC98
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001865 RID: 6245 RVA: 0x0012EB48 File Offset: 0x0012CD48
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMHTTT")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mblnAutoAdd_DMHTTT = xmlNode.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001866 RID: 6246 RVA: 0x0012EC44 File Offset: 0x0012CE44
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("objid").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("objid").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("objid").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("objname").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("objname").Width = 250
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("objname").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SUBobjname").HeaderText = Strings.Trim(Me.mArrStrFrmMess(16))
				dgvData.Columns("SUBobjname").Width = 250
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("SUBobjname").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LDEBT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("LDEBT").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("LDEBT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(28))
				dgvData.Columns("REMARK").Width = Me.Width - 760 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("FIXED").Visible = False
				dgvData.Columns("CHUATHUE").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001867 RID: 6247 RVA: 0x0012EF9C File Offset: 0x0012D19C
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001868 RID: 6248 RVA: 0x0012F11C File Offset: 0x0012D31C
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMHTTT_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001869 RID: 6249 RVA: 0x0012F20C File Offset: 0x0012D40C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600186A RID: 6250 RVA: 0x0012F35C File Offset: 0x0012D55C
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2080700000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600186B RID: 6251 RVA: 0x0012F468 File Offset: 0x0012D668
		Private Function fGetData_4Combo() As Byte
			Return 1
		End Function

		' Token: 0x0600186C RID: 6252 RVA: 0x0012F47C File Offset: 0x0012D67C
		Private Sub sClear_Form()
			Try
				Me.mclsTbStore.Dispose()
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600186D RID: 6253 RVA: 0x0012F534 File Offset: 0x0012D734
		Private Function fPrintFRMDMHTTT() As Byte
			Dim rptDMHTTT As rptDMHTTT = New rptDMHTTT()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMHTTT, "")
				Dim text As String = "2080700000"
				mdlReport.gsSetOfficeReport(rptDMHTTT, text)
				mdlReport.gsSetFontReport(rptDMHTTT)
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "SP_FRMDMHTTT_GET_ALL_DATA", flag)
				Dim flag2 As Boolean = flag
				If flag2 Then
					Dim num As Integer = 0
					Dim num2 As Integer = clsConnect.Rows.Count - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						Dim flag3 As Boolean = Operators.ConditionalCompareObjectEqual(clsConnect.Rows(num3)("LDEBT"), True, False)
						If flag3 Then
							clsConnect.Rows(num3)("CHUATHUE") = Me.mArrStrFrmMess(29)
						Else
							clsConnect.Rows(num3)("CHUATHUE") = Me.mArrStrFrmMess(30)
						End If
						num3 += 1
					End While
					rptDMHTTT.SetDataSource(clsConnect)
					rptDMHTTT.DataDefinition.FormulaFields("fInReasonCode").Text = "{dtReport.OBJID}"
					rptDMHTTT.DataDefinition.FormulaFields("fInReasonName").Text = "{dtReport.OBJNAME}"
					rptDMHTTT.DataDefinition.FormulaFields("fIncongno").Text = "{dtReport.CHUATHUE}"
					rptDMHTTT.DataDefinition.FormulaFields("fNOTE").Text = "{dtReport.REMARK}"
					mdlReport.gsSetTextReport(rptDMHTTT, "RPTDMHTTT")
					MyProject.Forms.frmReport.pSource = rptDMHTTT
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMHTTT.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMHTTT.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMHTTT.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMHTTT " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMHTTT.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x04000A01 RID: 2561
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000A03 RID: 2563
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000A04 RID: 2564
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000A05 RID: 2565
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000A06 RID: 2566
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000A07 RID: 2567
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000A08 RID: 2568
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000A09 RID: 2569
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000A0A RID: 2570
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000A0B RID: 2571
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000A0C RID: 2572
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000A0D RID: 2573
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000A0E RID: 2574
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000A0F RID: 2575
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000A10 RID: 2576
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000A11 RID: 2577
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000A12 RID: 2578
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000A13 RID: 2579
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000A14 RID: 2580
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000A15 RID: 2581
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000A16 RID: 2582
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000A17 RID: 2583
		Private mArrStrFrmMess As String()

		' Token: 0x04000A18 RID: 2584
		Private mStrOBJID As String

		' Token: 0x04000A19 RID: 2585
		Private mStrOBJNAME As String

		' Token: 0x04000A1A RID: 2586
		Private mStrMABK As String

		' Token: 0x04000A1B RID: 2587
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000A1C RID: 2588
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000A1D RID: 2589
		Private marrDrFind As DataRow()

		' Token: 0x04000A1E RID: 2590
		Private mintFindLastPos As Integer

		' Token: 0x04000A1F RID: 2591
		Private mclsTbStore As clsConnect

		' Token: 0x04000A20 RID: 2592
		Private mbytDebt As Byte

		' Token: 0x04000A21 RID: 2593
		Private mblnAutoAdd_DMHTTT As Boolean
	End Class
End Namespace
