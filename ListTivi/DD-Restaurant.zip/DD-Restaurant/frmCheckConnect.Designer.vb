﻿Namespace prjIS_SalesPOS
	' Token: 0x02000025 RID: 37
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCheckConnect
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060006AC RID: 1708 RVA: 0x0004F4E8 File Offset: 0x0004D6E8
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060006AD RID: 1709 RVA: 0x0004F520 File Offset: 0x0004D720
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Global.System.ComponentModel.Container()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCheckConnect))
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.dgvCHECK = New Global.System.Windows.Forms.DataGridView()
			Me.colMAMAY = New Global.System.Windows.Forms.DataGridViewTextBoxColumn()
			Me.colTenMay = New Global.System.Windows.Forms.DataGridViewTextBoxColumn()
			Me.colIP = New Global.System.Windows.Forms.DataGridViewTextBoxColumn()
			Me.colServer = New Global.System.Windows.Forms.DataGridViewTextBoxColumn()
			Me.Timer1 = New Global.System.Windows.Forms.Timer(Me.components)
			Me.lblLeft = New Global.System.Windows.Forms.Label()
			Me.lblCenter = New Global.System.Windows.Forms.Label()
			Me.lblRight = New Global.System.Windows.Forms.Label()
			Me.picLoad = New Global.System.Windows.Forms.PictureBox()
			Me.Timer2 = New Global.System.Windows.Forms.Timer(Me.components)
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.dvgDM = New Global.System.Windows.Forms.DataGridView()
			Me.colMADM = New Global.System.Windows.Forms.DataGridViewTextBoxColumn()
			Me.colTENDM = New Global.System.Windows.Forms.DataGridViewTextBoxColumn()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.lblRight2 = New Global.System.Windows.Forms.Label()
			Me.Label4 = New Global.System.Windows.Forms.Label()
			Me.Label5 = New Global.System.Windows.Forms.Label()
			Me.lstKQ = New Global.System.Windows.Forms.ListView()
			Me.col01 = New Global.System.Windows.Forms.ColumnHeader()
			Me.col02 = New Global.System.Windows.Forms.ColumnHeader()
			Me.col03 = New Global.System.Windows.Forms.ColumnHeader()
			Me.col04 = New Global.System.Windows.Forms.ColumnHeader()
			Me.col05 = New Global.System.Windows.Forms.ColumnHeader()
			CType(Me.dgvCHECK, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.picLoad, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.dvgDM, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.btnExit.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.btnExit.Image = CType(componentResourceManager.GetObject("btnExit.Image"), Global.System.Drawing.Image)
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(389, 447)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(111, 43)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "CR0003"
			Me.btnExit.Text = "OK"
			Me.btnExit.UseVisualStyleBackColor = True
			Me.dgvCHECK.AllowUserToAddRows = False
			Me.dgvCHECK.AllowUserToDeleteRows = False
			Me.dgvCHECK.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dgvCHECK.Columns.AddRange(New Global.System.Windows.Forms.DataGridViewColumn() { Me.colMAMAY, Me.colTenMay, Me.colIP, Me.colServer })
			Dim dgvCHECK As Global.System.Windows.Forms.Control = Me.dgvCHECK
			point = New Global.System.Drawing.Point(595, 74)
			dgvCHECK.Location = point
			Me.dgvCHECK.Name = "dgvCHECK"
			Dim dgvCHECK2 As Global.System.Windows.Forms.Control = Me.dgvCHECK
			size = New Global.System.Drawing.Size(213, 68)
			dgvCHECK2.Size = size
			Me.dgvCHECK.TabIndex = 8
			Me.dgvCHECK.Visible = False
			Me.colMAMAY.HeaderText = "Mã máy"
			Me.colMAMAY.Name = "colMAMAY"
			Me.colTenMay.HeaderText = "Tên máy"
			Me.colTenMay.Name = "colTenMay"
			Me.colIP.HeaderText = "IP"
			Me.colIP.Name = "colIP"
			Me.colServer.HeaderText = "Server"
			Me.colServer.Name = "colServer"
			Me.Timer1.Interval = 1500
			Me.lblLeft.BackColor = Global.System.Drawing.Color.LightGray
			Dim lblLeft As Global.System.Windows.Forms.Control = Me.lblLeft
			point = New Global.System.Drawing.Point(56, 49)
			lblLeft.Location = point
			Me.lblLeft.Name = "lblLeft"
			Dim lblLeft2 As Global.System.Windows.Forms.Control = Me.lblLeft
			size = New Global.System.Drawing.Size(9, 268)
			lblLeft2.Size = size
			Me.lblLeft.TabIndex = 9
			Me.lblLeft.Visible = False
			Me.lblCenter.BackColor = Global.System.Drawing.Color.LightGray
			Dim lblCenter As Global.System.Windows.Forms.Control = Me.lblCenter
			point = New Global.System.Drawing.Point(181, 49)
			lblCenter.Location = point
			Me.lblCenter.Name = "lblCenter"
			Dim lblCenter2 As Global.System.Windows.Forms.Control = Me.lblCenter
			size = New Global.System.Drawing.Size(9, 268)
			lblCenter2.Size = size
			Me.lblCenter.TabIndex = 10
			Me.lblCenter.Visible = False
			Me.lblRight.BackColor = Global.System.Drawing.Color.LightGray
			Dim lblRight As Global.System.Windows.Forms.Control = Me.lblRight
			point = New Global.System.Drawing.Point(282, 49)
			lblRight.Location = point
			Me.lblRight.Name = "lblRight"
			Dim lblRight2 As Global.System.Windows.Forms.Control = Me.lblRight
			size = New Global.System.Drawing.Size(9, 268)
			lblRight2.Size = size
			Me.lblRight.TabIndex = 11
			Me.lblRight.Visible = False
			Me.picLoad.Image = Global.prjIS_SalesPOS.My.Resources.Resources.loading_bar
			Dim picLoad As Global.System.Windows.Forms.Control = Me.picLoad
			point = New Global.System.Drawing.Point(180, 55)
			picLoad.Location = point
			Me.picLoad.Name = "picLoad"
			Dim picLoad2 As Global.System.Windows.Forms.Control = Me.picLoad
			size = New Global.System.Drawing.Size(100, 10)
			picLoad2.Size = size
			Me.picLoad.TabIndex = 12
			Me.picLoad.TabStop = False
			Me.picLoad.Visible = False
			Me.Timer2.Interval = 2000
			Me.Label3.BackColor = Global.System.Drawing.Color.LightGray
			Me.Label3.Font = New Global.System.Drawing.Font("Tahoma", 11F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(0, 1)
			label.Location = point
			Me.Label3.Name = "Label3"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(223, 39)
			label2.Size = size
			Me.Label3.TabIndex = 14
			Me.Label3.Tag = "CB0004"
			Me.Label3.Text = "TÊN MÁY"
			Me.Label3.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.Label1.BackColor = Global.System.Drawing.Color.LightGray
			Me.Label1.Font = New Global.System.Drawing.Font("Tahoma", 11F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(224, 1)
			label3.Location = point
			Me.Label1.Name = "Label1"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(140, 39)
			label4.Size = size
			Me.Label1.TabIndex = 14
			Me.Label1.Tag = "CB0005"
			Me.Label1.Text = "TRẠNG THÁI" & vbCrLf & "KẾT NỐI"
			Me.Label1.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.dvgDM.AllowUserToAddRows = False
			Me.dvgDM.AllowUserToDeleteRows = False
			Me.dvgDM.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dvgDM.Columns.AddRange(New Global.System.Windows.Forms.DataGridViewColumn() { Me.colMADM, Me.colTENDM })
			Dim dvgDM As Global.System.Windows.Forms.Control = Me.dvgDM
			point = New Global.System.Drawing.Point(595, 148)
			dvgDM.Location = point
			Me.dvgDM.Name = "dvgDM"
			Dim dvgDM2 As Global.System.Windows.Forms.Control = Me.dvgDM
			size = New Global.System.Drawing.Size(213, 68)
			dvgDM2.Size = size
			Me.dvgDM.TabIndex = 8
			Me.dvgDM.Visible = False
			Me.colMADM.HeaderText = "MaDM"
			Me.colMADM.Name = "colMADM"
			Me.colTENDM.HeaderText = "TenDM"
			Me.colTENDM.Name = "colTENDM"
			Me.Label2.BackColor = Global.System.Drawing.Color.LightGray
			Me.Label2.Font = New Global.System.Drawing.Font("Tahoma", 11F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(365, 1)
			label5.Location = point
			Me.Label2.Name = "Label2"
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(142, 39)
			label6.Size = size
			Me.Label2.TabIndex = 14
			Me.Label2.Tag = "CB0006"
			Me.Label2.Text = "GỬI DỮ LIỆU"
			Me.Label2.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lblRight2.BackColor = Global.System.Drawing.Color.LightGray
			Dim lblRight3 As Global.System.Windows.Forms.Control = Me.lblRight2
			point = New Global.System.Drawing.Point(427, 49)
			lblRight3.Location = point
			Me.lblRight2.Name = "lblRight2"
			Dim lblRight4 As Global.System.Windows.Forms.Control = Me.lblRight2
			size = New Global.System.Drawing.Size(9, 268)
			lblRight4.Size = size
			Me.lblRight2.TabIndex = 11
			Me.lblRight2.Visible = False
			Me.Label4.BackColor = Global.System.Drawing.Color.Silver
			Dim label7 As Global.System.Windows.Forms.Control = Me.Label4
			point = New Global.System.Drawing.Point(-5, 41)
			label7.Location = point
			Me.Label4.Name = "Label4"
			Dim label8 As Global.System.Windows.Forms.Control = Me.Label4
			size = New Global.System.Drawing.Size(520, 1)
			label8.Size = size
			Me.Label4.TabIndex = 15
			Me.Label5.BackColor = Global.System.Drawing.Color.Silver
			Dim label9 As Global.System.Windows.Forms.Control = Me.Label5
			point = New Global.System.Drawing.Point(-5, 444)
			label9.Location = point
			Me.Label5.Name = "Label5"
			Dim label10 As Global.System.Windows.Forms.Control = Me.Label5
			size = New Global.System.Drawing.Size(520, 1)
			label10.Size = size
			Me.Label5.TabIndex = 16
			Me.lstKQ.Columns.AddRange(New Global.System.Windows.Forms.ColumnHeader() { Me.col01, Me.col02, Me.col03, Me.col04, Me.col05 })
			Me.lstKQ.Font = New Global.System.Drawing.Font("Arial", 10F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lstKQ.FullRowSelect = True
			Me.lstKQ.GridLines = True
			Dim lstKQ As Global.System.Windows.Forms.Control = Me.lstKQ
			point = New Global.System.Drawing.Point(3, 320)
			lstKQ.Location = point
			Me.lstKQ.Name = "lstKQ"
			Dim lstKQ2 As Global.System.Windows.Forms.Control = Me.lstKQ
			size = New Global.System.Drawing.Size(497, 120)
			lstKQ2.Size = size
			Me.lstKQ.TabIndex = 17
			Me.lstKQ.UseCompatibleStateImageBehavior = False
			Me.lstKQ.View = Global.System.Windows.Forms.View.Details
			Me.lstKQ.Visible = False
			Me.col01.Text = "Tên máy"
			Me.col01.Width = 100
			Me.col02.Text = "Mã HH"
			Me.col02.Width = 70
			Me.col03.Text = "Tên HH"
			Me.col03.Width = 200
			Me.col04.Text = "Trạng thái"
			Me.col04.Width = 100
			Me.col05.Text = "Ghi chú"
			Me.col05.Width = 1000
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			Me.BackColor = Global.System.Drawing.Color.White
			size = New Global.System.Drawing.Size(507, 491)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.lstKQ)
			Me.Controls.Add(Me.Label5)
			Me.Controls.Add(Me.Label4)
			Me.Controls.Add(Me.btnExit)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.Label3)
			Me.Controls.Add(Me.picLoad)
			Me.Controls.Add(Me.lblRight2)
			Me.Controls.Add(Me.lblRight)
			Me.Controls.Add(Me.lblCenter)
			Me.Controls.Add(Me.lblLeft)
			Me.Controls.Add(Me.dvgDM)
			Me.Controls.Add(Me.dgvCHECK)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmCheckConnect"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Tag = "CR0002"
			Me.Text = "Kiểm tra kết nối"
			CType(Me.dgvCHECK, Global.System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.picLoad, Global.System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.dvgDM, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x040002E6 RID: 742
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
