﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000034 RID: 52
	<DesignerGenerated()>
	Public Partial Class frmDMAUTOPRICE1
		Inherits Form

		' Token: 0x06000B02 RID: 2818 RVA: 0x000808E0 File Offset: 0x0007EAE0
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmDMDNKM1_Load
			AddHandler MyBase.Activated, AddressOf Me.frmDMDNKM1_Activated
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMDNKM1_FormClosing
			frmDMAUTOPRICE1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.InitializeComponent()
		End Sub

		' Token: 0x1700040D RID: 1037
		' (get) Token: 0x06000B05 RID: 2821 RVA: 0x00081EEC File Offset: 0x000800EC
		' (set) Token: 0x06000B06 RID: 2822 RVA: 0x00003F06 File Offset: 0x00002106
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x1700040E RID: 1038
		' (get) Token: 0x06000B07 RID: 2823 RVA: 0x00081F04 File Offset: 0x00080104
		' (set) Token: 0x06000B08 RID: 2824 RVA: 0x00081F1C File Offset: 0x0008011C
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x1700040F RID: 1039
		' (get) Token: 0x06000B09 RID: 2825 RVA: 0x00081F88 File Offset: 0x00080188
		' (set) Token: 0x06000B0A RID: 2826 RVA: 0x00081FA0 File Offset: 0x000801A0
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000410 RID: 1040
		' (get) Token: 0x06000B0B RID: 2827 RVA: 0x0008200C File Offset: 0x0008020C
		' (set) Token: 0x06000B0C RID: 2828 RVA: 0x00082024 File Offset: 0x00080224
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000411 RID: 1041
		' (get) Token: 0x06000B0D RID: 2829 RVA: 0x00082090 File Offset: 0x00080290
		' (set) Token: 0x06000B0E RID: 2830 RVA: 0x000820A8 File Offset: 0x000802A8
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000412 RID: 1042
		' (get) Token: 0x06000B0F RID: 2831 RVA: 0x00082114 File Offset: 0x00080314
		' (set) Token: 0x06000B10 RID: 2832 RVA: 0x0008212C File Offset: 0x0008032C
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000413 RID: 1043
		' (get) Token: 0x06000B11 RID: 2833 RVA: 0x00082198 File Offset: 0x00080398
		' (set) Token: 0x06000B12 RID: 2834 RVA: 0x000821B0 File Offset: 0x000803B0
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000414 RID: 1044
		' (get) Token: 0x06000B13 RID: 2835 RVA: 0x0008221C File Offset: 0x0008041C
		' (set) Token: 0x06000B14 RID: 2836 RVA: 0x00082234 File Offset: 0x00080434
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000415 RID: 1045
		' (get) Token: 0x06000B15 RID: 2837 RVA: 0x000822A0 File Offset: 0x000804A0
		' (set) Token: 0x06000B16 RID: 2838 RVA: 0x00003F10 File Offset: 0x00002110
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000416 RID: 1046
		' (get) Token: 0x06000B17 RID: 2839 RVA: 0x000822B8 File Offset: 0x000804B8
		' (set) Token: 0x06000B18 RID: 2840 RVA: 0x000822D0 File Offset: 0x000804D0
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000417 RID: 1047
		' (get) Token: 0x06000B19 RID: 2841 RVA: 0x0008233C File Offset: 0x0008053C
		' (set) Token: 0x06000B1A RID: 2842 RVA: 0x00082354 File Offset: 0x00080554
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x17000418 RID: 1048
		' (get) Token: 0x06000B1B RID: 2843 RVA: 0x000823C0 File Offset: 0x000805C0
		' (set) Token: 0x06000B1C RID: 2844 RVA: 0x000823D8 File Offset: 0x000805D8
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000419 RID: 1049
		' (get) Token: 0x06000B1D RID: 2845 RVA: 0x00082444 File Offset: 0x00080644
		' (set) Token: 0x06000B1E RID: 2846 RVA: 0x00003F1A File Offset: 0x0000211A
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x1700041A RID: 1050
		' (get) Token: 0x06000B1F RID: 2847 RVA: 0x0008245C File Offset: 0x0008065C
		' (set) Token: 0x06000B20 RID: 2848 RVA: 0x00082474 File Offset: 0x00080674
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x1700041B RID: 1051
		' (get) Token: 0x06000B21 RID: 2849 RVA: 0x000824E0 File Offset: 0x000806E0
		' (set) Token: 0x06000B22 RID: 2850 RVA: 0x000824F8 File Offset: 0x000806F8
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x1700041C RID: 1052
		' (get) Token: 0x06000B23 RID: 2851 RVA: 0x00082564 File Offset: 0x00080764
		' (set) Token: 0x06000B24 RID: 2852 RVA: 0x0008257C File Offset: 0x0008077C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x1700041D RID: 1053
		' (get) Token: 0x06000B25 RID: 2853 RVA: 0x000825E8 File Offset: 0x000807E8
		' (set) Token: 0x06000B26 RID: 2854 RVA: 0x00082600 File Offset: 0x00080800
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x1700041E RID: 1054
		' (get) Token: 0x06000B27 RID: 2855 RVA: 0x0008266C File Offset: 0x0008086C
		' (set) Token: 0x06000B28 RID: 2856 RVA: 0x00003F24 File Offset: 0x00002124
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x1700041F RID: 1055
		' (get) Token: 0x06000B29 RID: 2857 RVA: 0x00082684 File Offset: 0x00080884
		' (set) Token: 0x06000B2A RID: 2858 RVA: 0x00003F2E File Offset: 0x0000212E
		Friend Overridable Property lblMANH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMANH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMANH = value
			End Set
		End Property

		' Token: 0x17000420 RID: 1056
		' (get) Token: 0x06000B2B RID: 2859 RVA: 0x0008269C File Offset: 0x0008089C
		' (set) Token: 0x06000B2C RID: 2860 RVA: 0x00003F38 File Offset: 0x00002138
		Friend Overridable Property txtOBJNAMEKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAMEKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAMEKH = value
			End Set
		End Property

		' Token: 0x17000421 RID: 1057
		' (get) Token: 0x06000B2D RID: 2861 RVA: 0x000826B4 File Offset: 0x000808B4
		' (set) Token: 0x06000B2E RID: 2862 RVA: 0x000826CC File Offset: 0x000808CC
		Friend Overridable Property btnSelectKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelectKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelectKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelectKH.Click, AddressOf Me.btnSelectKH_Click
				End If
				Me._btnSelectKH = value
				flag = Me._btnSelectKH IsNot Nothing
				If flag Then
					AddHandler Me._btnSelectKH.Click, AddressOf Me.btnSelectKH_Click
				End If
			End Set
		End Property

		' Token: 0x17000422 RID: 1058
		' (get) Token: 0x06000B2F RID: 2863 RVA: 0x00082738 File Offset: 0x00080938
		' (set) Token: 0x06000B30 RID: 2864 RVA: 0x00082750 File Offset: 0x00080950
		Friend Overridable Property txtMAKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
				Me._txtMAKH = value
				flag = Me._txtMAKH IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000423 RID: 1059
		' (get) Token: 0x06000B31 RID: 2865 RVA: 0x000827BC File Offset: 0x000809BC
		' (set) Token: 0x06000B32 RID: 2866 RVA: 0x000827D4 File Offset: 0x000809D4
		Friend Overridable Property btnDetail As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDetail
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDetail IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDetail.Click, AddressOf Me.btnDetail_Click
				End If
				Me._btnDetail = value
				flag = Me._btnDetail IsNot Nothing
				If flag Then
					AddHandler Me._btnDetail.Click, AddressOf Me.btnDetail_Click
				End If
			End Set
		End Property

		' Token: 0x17000424 RID: 1060
		' (get) Token: 0x06000B33 RID: 2867 RVA: 0x00082840 File Offset: 0x00080A40
		' (set) Token: 0x06000B34 RID: 2868 RVA: 0x00003F42 File Offset: 0x00002142
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000425 RID: 1061
		' (get) Token: 0x06000B35 RID: 2869 RVA: 0x00082858 File Offset: 0x00080A58
		' (set) Token: 0x06000B36 RID: 2870 RVA: 0x00082870 File Offset: 0x00080A70
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000426 RID: 1062
		' (get) Token: 0x06000B37 RID: 2871 RVA: 0x000828DC File Offset: 0x00080ADC
		' (set) Token: 0x06000B38 RID: 2872 RVA: 0x00003F4C File Offset: 0x0000214C
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x17000427 RID: 1063
		' (get) Token: 0x06000B39 RID: 2873 RVA: 0x000828F4 File Offset: 0x00080AF4
		' (set) Token: 0x06000B3A RID: 2874 RVA: 0x00003F57 File Offset: 0x00002157
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000428 RID: 1064
		' (get) Token: 0x06000B3B RID: 2875 RVA: 0x0008290C File Offset: 0x00080B0C
		' (set) Token: 0x06000B3C RID: 2876 RVA: 0x00003F62 File Offset: 0x00002162
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06000B3D RID: 2877 RVA: 0x00082924 File Offset: 0x00080B24
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B3E RID: 2878 RVA: 0x000829F4 File Offset: 0x00080BF4
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B3F RID: 2879 RVA: 0x00082AE4 File Offset: 0x00080CE4
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B40 RID: 2880 RVA: 0x00082BC8 File Offset: 0x00080DC8
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B41 RID: 2881 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub frmDMDNKM1_Activated(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06000B42 RID: 2882 RVA: 0x00082C8C File Offset: 0x00080E8C
		Private Sub frmDMDNKM1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B43 RID: 2883 RVA: 0x00082D24 File Offset: 0x00080F24
		Private Sub frmDMDNKM1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				Me.sGetDMKH()
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B44 RID: 2884 RVA: 0x00082E34 File Offset: 0x00081034
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B45 RID: 2885 RVA: 0x00082F3C File Offset: 0x0008113C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B46 RID: 2886 RVA: 0x00082FD4 File Offset: 0x000811D4
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE2 = New frmDMAUTOPRICE2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMAUTOPRICE.pbytFromStatus = 1
				frmDMAUTOPRICE.pStrFromDate = String.Concat(New String() { DateAndTime.Today.Day.ToString("00"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Year.ToString("0000") })
				frmDMAUTOPRICE.pStrToDate = String.Concat(New String() { DateAndTime.Today.Day.ToString("00"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Year.ToString("0000") })
				frmDMAUTOPRICE.pStrFromTime = "00:00"
				frmDMAUTOPRICE.pStrToTime = "23:59"
				frmDMAUTOPRICE.gsCheckDate()
				frmDMAUTOPRICE.txtMAKH.Text = mdlVariable.gStrStockCode
				frmDMAUTOPRICE.ShowDialog()
				Dim flag As Boolean = frmDMAUTOPRICE.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMAUTOPRICE.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnDetail_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
				frmDMAUTOPRICE.Dispose()
			End Try
		End Sub

		' Token: 0x06000B47 RID: 2887 RVA: 0x000832B0 File Offset: 0x000814B0
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE2 = New frmDMAUTOPRICE2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMAUTOPRICE2 As frmDMAUTOPRICE2 = frmDMAUTOPRICE
				frmDMAUTOPRICE2.pbytFromStatus = 2
				Dim flag As Boolean = Me.dgvData.RowCount > 0
				If flag Then
					frmDMAUTOPRICE2.pbytFromStatus = 2
					frmDMAUTOPRICE2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMAUTOPRICE2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMAUTOPRICE2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
					frmDMAUTOPRICE2.txtMAKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKHU").Value, ""))
					frmDMAUTOPRICE2.txtTENKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENKHU").Value, ""))
					frmDMAUTOPRICE2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENNGAY").Value, ""))
					frmDMAUTOPRICE2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUNGAY").Value, ""))
					frmDMAUTOPRICE2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUGIO").Value, ""))
					frmDMAUTOPRICE2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENGIO").Value, ""))
					frmDMAUTOPRICE2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
					frmDMAUTOPRICE2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
					frmDMAUTOPRICE2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
					frmDMAUTOPRICE2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
					frmDMAUTOPRICE2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
					frmDMAUTOPRICE2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
					frmDMAUTOPRICE2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
				End If
				frmDMAUTOPRICE.ShowDialog()
				flag = frmDMAUTOPRICE.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMAUTOPRICE.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnDetail_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMAUTOPRICE.Dispose()
			End Try
		End Sub

		' Token: 0x06000B48 RID: 2888 RVA: 0x000838D0 File Offset: 0x00081AD0
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE2 = New frmDMAUTOPRICE2()
			Try
				Dim frmDMAUTOPRICE2 As frmDMAUTOPRICE2 = frmDMAUTOPRICE
				frmDMAUTOPRICE2.pbytFromStatus = 3
				frmDMAUTOPRICE2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMAUTOPRICE2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMAUTOPRICE2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMAUTOPRICE2.txtMAKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKHU").Value, ""))
				frmDMAUTOPRICE2.txtTENKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENKHU").Value, ""))
				frmDMAUTOPRICE2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMAUTOPRICE2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMAUTOPRICE2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMAUTOPRICE2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMAUTOPRICE2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
				frmDMAUTOPRICE2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
				frmDMAUTOPRICE.ShowDialog()
				Dim flag As Boolean = frmDMAUTOPRICE.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMAUTOPRICE.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMAUTOPRICE.Dispose()
			End Try
		End Sub

		' Token: 0x06000B49 RID: 2889 RVA: 0x00083E80 File Offset: 0x00082080
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE2 = New frmDMAUTOPRICE2()
			Try
				Dim frmDMAUTOPRICE2 As frmDMAUTOPRICE2 = frmDMAUTOPRICE
				frmDMAUTOPRICE2.pbytFromStatus = 4
				frmDMAUTOPRICE2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMAUTOPRICE2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMAUTOPRICE2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMAUTOPRICE2.txtMAKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKHU").Value, ""))
				frmDMAUTOPRICE2.txtTENKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENKHU").Value, ""))
				frmDMAUTOPRICE2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMAUTOPRICE2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMAUTOPRICE2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMAUTOPRICE2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMAUTOPRICE2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY2").Value, True, False), True, False))
				frmDMAUTOPRICE2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY3").Value, True, False), True, False))
				frmDMAUTOPRICE2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY4").Value, True, False), True, False))
				frmDMAUTOPRICE2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY5").Value, True, False), True, False))
				frmDMAUTOPRICE2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY6").Value, True, False), True, False))
				frmDMAUTOPRICE2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY7").Value, True, False), True, False))
				frmDMAUTOPRICE2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY8").Value, True, False), True, False))
				frmDMAUTOPRICE.ShowDialog()
				Dim flag As Boolean = frmDMAUTOPRICE.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMAUTOPRICE.Dispose()
			End Try
		End Sub

		' Token: 0x06000B4A RID: 2890 RVA: 0x000843C8 File Offset: 0x000825C8
		Private Sub txtMAKH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Dim flag As Boolean = Me.mclsTbDMKHO Is Nothing
			If Not flag Then
				array(0) = Me.mclsTbDMKHO.Columns("OBJID")
				Me.mclsTbDMKHO.PrimaryKey = array
				Dim dataRow As DataRow = Me.mclsTbDMKHO.Rows.Find(Strings.Trim(Me.txtMAKH.Text))
				flag = dataRow IsNot Nothing
				If flag Then
					Me.txtOBJNAMEKH.Text = dataRow("OBJNAME").ToString()
				Else
					Me.txtOBJNAMEKH.Text = ""
				End If
				flag = Me.mbdsSource Is Nothing
				If Not flag Then
					flag = Strings.Len(Strings.Trim(Me.txtMAKH.Text)) = 0
					If flag Then
						Me.mbdsSource.RemoveFilter()
					Else
						Me.mbdsSource.Filter = "MAKH like '" + Strings.Trim(Me.txtMAKH.Text) + "'"
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			End If
		End Sub

		' Token: 0x06000B4B RID: 2891 RVA: 0x000844F0 File Offset: 0x000826F0
		Private Sub sGetDMKH()
			Try
				Me.mclsTbDMKHO = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetDMKH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B4C RID: 2892 RVA: 0x00084598 File Offset: 0x00082798
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE2 = New frmDMAUTOPRICE2()
			Try
				frmDMAUTOPRICE.pbytFromStatus = 6
				frmDMAUTOPRICE.ShowDialog()
				Dim flag As Boolean = frmDMAUTOPRICE.pbytSuccess = 0
				If flag Then
					frmDMAUTOPRICE.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMAUTOPRICE.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						frmDMAUTOPRICE.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("KHOACHINH", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("KHOACHINH")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMAUTOPRICE.Dispose()
			End Try
		End Sub

		' Token: 0x06000B4D RID: 2893 RVA: 0x0008478C File Offset: 0x0008298C
		Private Sub btnSelectKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKH As frmDMKH1 = New frmDMKH1()
				frmDMKH.pBytOpen_From_Menu = 7
				frmDMKH.ShowDialog()
				Me.txtMAKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJID, "", False) = 0, Me.txtMAKH.Text, frmDMKH.pStrOBJID))
				Me.txtOBJNAMEKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJNAME, "", False) = 0, Me.txtOBJNAMEKH.Text, frmDMKH.pStrOBJNAME))
				frmDMKH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B4E RID: 2894 RVA: 0x000848B0 File Offset: 0x00082AB0
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMAUTOPRICE As frmDMAUTOPRICE2 = New frmDMAUTOPRICE2()
			Try
				Me.btnFindNext.Visible = False
				frmDMAUTOPRICE.pbytFromStatus = 5
				frmDMAUTOPRICE.ShowDialog()
				Dim flag As Boolean = frmDMAUTOPRICE.pbytSuccess = 0
				If Not flag Then
					Me.mbdsSource.Filter = frmDMAUTOPRICE.pStrFilter
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMAUTOPRICE.Dispose()
			End Try
		End Sub

		' Token: 0x06000B4F RID: 2895 RVA: 0x000849B8 File Offset: 0x00082BB8
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x06000B50 RID: 2896 RVA: 0x00084A80 File Offset: 0x00082C80
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("KHOACHINH", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("KHOACHINH")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x06000B51 RID: 2897 RVA: 0x00084BFC File Offset: 0x00082DFC
		Private Sub btnDetail_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMAUTOPRICE As frmDMAUTOPRICE3 = New frmDMAUTOPRICE3()
				Dim frmDMAUTOPRICE2 As frmDMAUTOPRICE3 = frmDMAUTOPRICE
				frmDMAUTOPRICE2.pbdsSource = Me.mbdsSource
				frmDMAUTOPRICE2.pdgvMaster = Me.dgvData
				frmDMAUTOPRICE.ShowDialog()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDetail_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000B52 RID: 2898 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x06000B53 RID: 2899 RVA: 0x00084CB8 File Offset: 0x00082EB8
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = Me.Width - 610 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TUNGAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("TUNGAY").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TUNGAY").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DENNGAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(21))
				dgvData.Columns("DENNGAY").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("DENNGAY").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TUGIO").HeaderText = Strings.Trim(Me.mArrStrFrmMess(22))
				dgvData.Columns("TUGIO").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TUGIO").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DENGIO").HeaderText = Strings.Trim(Me.mArrStrFrmMess(23))
				dgvData.Columns("DENGIO").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("DENGIO").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENKHU").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("TENKHU").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENKHU").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENKH").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("TENKH").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENKH").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MAKH").Visible = False
				dgvData.Columns("LDAY2").Visible = False
				dgvData.Columns("LDAY3").Visible = False
				dgvData.Columns("LDAY4").Visible = False
				dgvData.Columns("LDAY5").Visible = False
				dgvData.Columns("LDAY6").Visible = False
				dgvData.Columns("LDAY7").Visible = False
				dgvData.Columns("LDAY8").Visible = False
				dgvData.Columns("TENKH").Visible = False
				dgvData.Columns("MAKHU").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000B54 RID: 2900 RVA: 0x00085200 File Offset: 0x00083400
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				Me.btnDetail.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000B55 RID: 2901 RVA: 0x00085390 File Offset: 0x00083590
		Public Function gfGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "SP_FRMDMAUTOPRICE1_GET_DATA", flag)
				Dim flag2 As Boolean = flag
				If flag2 Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gfGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000B56 RID: 2902 RVA: 0x0008547C File Offset: 0x0008367C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000B57 RID: 2903 RVA: 0x000855A4 File Offset: 0x000837A4
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000B58 RID: 2904 RVA: 0x000856B0 File Offset: 0x000838B0
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x040004D5 RID: 1237
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040004D7 RID: 1239
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x040004D8 RID: 1240
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x040004D9 RID: 1241
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x040004DA RID: 1242
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x040004DB RID: 1243
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x040004DC RID: 1244
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x040004DD RID: 1245
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x040004DE RID: 1246
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x040004DF RID: 1247
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x040004E0 RID: 1248
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x040004E1 RID: 1249
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x040004E2 RID: 1250
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x040004E3 RID: 1251
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x040004E4 RID: 1252
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x040004E5 RID: 1253
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x040004E6 RID: 1254
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040004E7 RID: 1255
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x040004E8 RID: 1256
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040004E9 RID: 1257
		<AccessedThroughProperty("lblMANH")>
		Private _lblMANH As Label

		' Token: 0x040004EA RID: 1258
		<AccessedThroughProperty("txtOBJNAMEKH")>
		Private _txtOBJNAMEKH As TextBox

		' Token: 0x040004EB RID: 1259
		<AccessedThroughProperty("btnSelectKH")>
		Private _btnSelectKH As Button

		' Token: 0x040004EC RID: 1260
		<AccessedThroughProperty("txtMAKH")>
		Private _txtMAKH As TextBox

		' Token: 0x040004ED RID: 1261
		<AccessedThroughProperty("btnDetail")>
		Private _btnDetail As Button

		' Token: 0x040004EE RID: 1262
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040004EF RID: 1263
		Private mArrStrFrmMess As String()

		' Token: 0x040004F0 RID: 1264
		Private mStrOBJID As String

		' Token: 0x040004F1 RID: 1265
		Private mStrOBJNAME As String

		' Token: 0x040004F2 RID: 1266
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040004F3 RID: 1267
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040004F4 RID: 1268
		Private marrDrFind As DataRow()

		' Token: 0x040004F5 RID: 1269
		Private mintFindLastPos As Integer

		' Token: 0x040004F6 RID: 1270
		Private mclsTbDMKHO As clsConnect
	End Class
End Namespace
