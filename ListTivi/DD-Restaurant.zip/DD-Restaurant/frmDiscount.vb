﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000033 RID: 51
	<DesignerGenerated()>
	Public Partial Class frmDiscount
		Inherits Form

		' Token: 0x06000AC0 RID: 2752 RVA: 0x0007EDB8 File Offset: 0x0007CFB8
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmDiscount_Load
			frmDiscount.__ENCList.Add(New WeakReference(Me))
			Me.mbytSuccess = 1
			Me.mdblPercent = 0.0
			Me.mstrCaption = ""
			Me.mdblInput = 0.0
			Me.mblnTypePer = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x170003F7 RID: 1015
		' (get) Token: 0x06000AC3 RID: 2755 RVA: 0x0007FD04 File Offset: 0x0007DF04
		' (set) Token: 0x06000AC4 RID: 2756 RVA: 0x0007FD1C File Offset: 0x0007DF1C
		Friend Overridable Property btn10 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn10 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn10.Click, AddressOf Me.btn10_Click
				End If
				Me._btn10 = value
				flag = Me._btn10 IsNot Nothing
				If flag Then
					AddHandler Me._btn10.Click, AddressOf Me.btn10_Click
				End If
			End Set
		End Property

		' Token: 0x170003F8 RID: 1016
		' (get) Token: 0x06000AC5 RID: 2757 RVA: 0x0007FD88 File Offset: 0x0007DF88
		' (set) Token: 0x06000AC6 RID: 2758 RVA: 0x0007FDA0 File Offset: 0x0007DFA0
		Friend Overridable Property btn20 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn20
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn20 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn20.Click, AddressOf Me.btn20_Click
				End If
				Me._btn20 = value
				flag = Me._btn20 IsNot Nothing
				If flag Then
					AddHandler Me._btn20.Click, AddressOf Me.btn20_Click
				End If
			End Set
		End Property

		' Token: 0x170003F9 RID: 1017
		' (get) Token: 0x06000AC7 RID: 2759 RVA: 0x0007FE0C File Offset: 0x0007E00C
		' (set) Token: 0x06000AC8 RID: 2760 RVA: 0x0007FE24 File Offset: 0x0007E024
		Friend Overridable Property btn30 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn30
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn30 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn30.Click, AddressOf Me.btn30_Click
				End If
				Me._btn30 = value
				flag = Me._btn30 IsNot Nothing
				If flag Then
					AddHandler Me._btn30.Click, AddressOf Me.btn30_Click
				End If
			End Set
		End Property

		' Token: 0x170003FA RID: 1018
		' (get) Token: 0x06000AC9 RID: 2761 RVA: 0x0007FE90 File Offset: 0x0007E090
		' (set) Token: 0x06000ACA RID: 2762 RVA: 0x0007FEA8 File Offset: 0x0007E0A8
		Friend Overridable Property btn40 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn40
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn40 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn40.Click, AddressOf Me.btn40_Click
				End If
				Me._btn40 = value
				flag = Me._btn40 IsNot Nothing
				If flag Then
					AddHandler Me._btn40.Click, AddressOf Me.btn40_Click
				End If
			End Set
		End Property

		' Token: 0x170003FB RID: 1019
		' (get) Token: 0x06000ACB RID: 2763 RVA: 0x0007FF14 File Offset: 0x0007E114
		' (set) Token: 0x06000ACC RID: 2764 RVA: 0x0007FF2C File Offset: 0x0007E12C
		Friend Overridable Property btn50 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn50
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn50 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn50.Click, AddressOf Me.btn50_Click
				End If
				Me._btn50 = value
				flag = Me._btn50 IsNot Nothing
				If flag Then
					AddHandler Me._btn50.Click, AddressOf Me.btn50_Click
				End If
			End Set
		End Property

		' Token: 0x170003FC RID: 1020
		' (get) Token: 0x06000ACD RID: 2765 RVA: 0x0007FF98 File Offset: 0x0007E198
		' (set) Token: 0x06000ACE RID: 2766 RVA: 0x0007FFB0 File Offset: 0x0007E1B0
		Friend Overridable Property btn60 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn60
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn60 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn60.Click, AddressOf Me.btn60_Click
				End If
				Me._btn60 = value
				flag = Me._btn60 IsNot Nothing
				If flag Then
					AddHandler Me._btn60.Click, AddressOf Me.btn60_Click
				End If
			End Set
		End Property

		' Token: 0x170003FD RID: 1021
		' (get) Token: 0x06000ACF RID: 2767 RVA: 0x0008001C File Offset: 0x0007E21C
		' (set) Token: 0x06000AD0 RID: 2768 RVA: 0x00080034 File Offset: 0x0007E234
		Friend Overridable Property btn70 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn70
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn70 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn70.Click, AddressOf Me.btn70_Click
				End If
				Me._btn70 = value
				flag = Me._btn70 IsNot Nothing
				If flag Then
					AddHandler Me._btn70.Click, AddressOf Me.btn70_Click
				End If
			End Set
		End Property

		' Token: 0x170003FE RID: 1022
		' (get) Token: 0x06000AD1 RID: 2769 RVA: 0x000800A0 File Offset: 0x0007E2A0
		' (set) Token: 0x06000AD2 RID: 2770 RVA: 0x000800B8 File Offset: 0x0007E2B8
		Friend Overridable Property btn80 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn80
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn80 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn80.Click, AddressOf Me.btn80_Click
				End If
				Me._btn80 = value
				flag = Me._btn80 IsNot Nothing
				If flag Then
					AddHandler Me._btn80.Click, AddressOf Me.btn80_Click
				End If
			End Set
		End Property

		' Token: 0x170003FF RID: 1023
		' (get) Token: 0x06000AD3 RID: 2771 RVA: 0x00080124 File Offset: 0x0007E324
		' (set) Token: 0x06000AD4 RID: 2772 RVA: 0x0008013C File Offset: 0x0007E33C
		Friend Overridable Property btn90 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn90
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn90 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn90.Click, AddressOf Me.btn90_Click
				End If
				Me._btn90 = value
				flag = Me._btn90 IsNot Nothing
				If flag Then
					AddHandler Me._btn90.Click, AddressOf Me.btn90_Click
				End If
			End Set
		End Property

		' Token: 0x17000400 RID: 1024
		' (get) Token: 0x06000AD5 RID: 2773 RVA: 0x000801A8 File Offset: 0x0007E3A8
		' (set) Token: 0x06000AD6 RID: 2774 RVA: 0x000801C0 File Offset: 0x0007E3C0
		Friend Overridable Property btn100 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn100
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn100 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn100.Click, AddressOf Me.btn100_Click
				End If
				Me._btn100 = value
				flag = Me._btn100 IsNot Nothing
				If flag Then
					AddHandler Me._btn100.Click, AddressOf Me.btn100_Click
				End If
			End Set
		End Property

		' Token: 0x17000401 RID: 1025
		' (get) Token: 0x06000AD7 RID: 2775 RVA: 0x0008022C File Offset: 0x0007E42C
		' (set) Token: 0x06000AD8 RID: 2776 RVA: 0x00080244 File Offset: 0x0007E444
		Friend Overridable Property txtPer As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtPer
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtPer IsNot Nothing
				If flag Then
					RemoveHandler Me._txtPer.Click, AddressOf Me.txtPer_Click
				End If
				Me._txtPer = value
				flag = Me._txtPer IsNot Nothing
				If flag Then
					AddHandler Me._txtPer.Click, AddressOf Me.txtPer_Click
				End If
			End Set
		End Property

		' Token: 0x17000402 RID: 1026
		' (get) Token: 0x06000AD9 RID: 2777 RVA: 0x000802B0 File Offset: 0x0007E4B0
		' (set) Token: 0x06000ADA RID: 2778 RVA: 0x000802C8 File Offset: 0x0007E4C8
		Friend Overridable Property btnOK As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnOK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnOK IsNot Nothing
				If flag Then
					RemoveHandler Me._btnOK.Click, AddressOf Me.btnOK_Click
				End If
				Me._btnOK = value
				flag = Me._btnOK IsNot Nothing
				If flag Then
					AddHandler Me._btnOK.Click, AddressOf Me.btnOK_Click
				End If
			End Set
		End Property

		' Token: 0x17000403 RID: 1027
		' (get) Token: 0x06000ADB RID: 2779 RVA: 0x00080334 File Offset: 0x0007E534
		' (set) Token: 0x06000ADC RID: 2780 RVA: 0x00003CAF File Offset: 0x00001EAF
		Friend Overridable Property GroupBox1 As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._GroupBox1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox1 = value
			End Set
		End Property

		' Token: 0x17000404 RID: 1028
		' (get) Token: 0x06000ADD RID: 2781 RVA: 0x0008034C File Offset: 0x0007E54C
		' (set) Token: 0x06000ADE RID: 2782 RVA: 0x00080364 File Offset: 0x0007E564
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000405 RID: 1029
		' (get) Token: 0x06000ADF RID: 2783 RVA: 0x000803D0 File Offset: 0x0007E5D0
		' (set) Token: 0x06000AE0 RID: 2784 RVA: 0x000803E8 File Offset: 0x0007E5E8
		Friend Overridable Property btn_30 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn_30
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn_30 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn_30.Click, AddressOf Me.btn_30_Click
				End If
				Me._btn_30 = value
				flag = Me._btn_30 IsNot Nothing
				If flag Then
					AddHandler Me._btn_30.Click, AddressOf Me.btn_30_Click
				End If
			End Set
		End Property

		' Token: 0x17000406 RID: 1030
		' (get) Token: 0x06000AE1 RID: 2785 RVA: 0x00080454 File Offset: 0x0007E654
		' (set) Token: 0x06000AE2 RID: 2786 RVA: 0x0008046C File Offset: 0x0007E66C
		Friend Overridable Property btn_60 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btn_60
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btn_60 IsNot Nothing
				If flag Then
					RemoveHandler Me._btn_60.Click, AddressOf Me.btn_60_Click
				End If
				Me._btn_60 = value
				flag = Me._btn_60 IsNot Nothing
				If flag Then
					AddHandler Me._btn_60.Click, AddressOf Me.btn_60_Click
				End If
			End Set
		End Property

		' Token: 0x17000407 RID: 1031
		' (get) Token: 0x06000AE3 RID: 2787 RVA: 0x000804D8 File Offset: 0x0007E6D8
		' (set) Token: 0x06000AE4 RID: 2788 RVA: 0x000804F0 File Offset: 0x0007E6F0
		Friend Overridable Property btnUser As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnUser
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnUser IsNot Nothing
				If flag Then
					RemoveHandler Me._btnUser.Click, AddressOf Me.btnUser_Click
				End If
				Me._btnUser = value
				flag = Me._btnUser IsNot Nothing
				If flag Then
					AddHandler Me._btnUser.Click, AddressOf Me.btnUser_Click
				End If
			End Set
		End Property

		' Token: 0x17000408 RID: 1032
		' (get) Token: 0x06000AE5 RID: 2789 RVA: 0x0008055C File Offset: 0x0007E75C
		' (set) Token: 0x06000AE6 RID: 2790 RVA: 0x00003CB9 File Offset: 0x00001EB9
		Public Property pblnTypePer As Boolean
			Get
				Return Me.mblnTypePer
			End Get
			Set(value As Boolean)
				Me.mblnTypePer = value
			End Set
		End Property

		' Token: 0x17000409 RID: 1033
		' (get) Token: 0x06000AE7 RID: 2791 RVA: 0x00080574 File Offset: 0x0007E774
		' (set) Token: 0x06000AE8 RID: 2792 RVA: 0x00003CC4 File Offset: 0x00001EC4
		Public Property pstrCaption As String
			Get
				Return Me.mstrCaption
			End Get
			Set(value As String)
				Me.mstrCaption = value
			End Set
		End Property

		' Token: 0x1700040A RID: 1034
		' (get) Token: 0x06000AE9 RID: 2793 RVA: 0x0008058C File Offset: 0x0007E78C
		' (set) Token: 0x06000AEA RID: 2794 RVA: 0x00003CCF File Offset: 0x00001ECF
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x1700040B RID: 1035
		' (get) Token: 0x06000AEB RID: 2795 RVA: 0x000805A4 File Offset: 0x0007E7A4
		' (set) Token: 0x06000AEC RID: 2796 RVA: 0x00003CDA File Offset: 0x00001EDA
		Public Property pdblPercent As Double
			Get
				Return Me.mdblPercent
			End Get
			Set(value As Double)
				Me.mdblPercent = value
			End Set
		End Property

		' Token: 0x1700040C RID: 1036
		' (get) Token: 0x06000AED RID: 2797 RVA: 0x000805BC File Offset: 0x0007E7BC
		' (set) Token: 0x06000AEE RID: 2798 RVA: 0x00003CE5 File Offset: 0x00001EE5
		Public Property pdblInput As Double
			Get
				Return Me.mdblInput
			End Get
			Set(value As Double)
				Me.mdblInput = value
			End Set
		End Property

		' Token: 0x06000AEF RID: 2799 RVA: 0x000805D4 File Offset: 0x0007E7D4
		Private Sub txtPer_Click(sender As Object, e As EventArgs)
			Try
				Dim frmNumPad As frmNumPad = New frmNumPad()
				frmNumPad.pSglNumberReturn = Conversions.ToSingle(Me.txtPer.Text)
				Dim flag As Boolean = Me.mblnTypePer
				If flag Then
					frmNumPad.pblnTypePer = True
				End If
				frmNumPad.ShowDialog()
				Me.txtPer.Text = Conversions.ToString(frmNumPad.pSglNumberReturn)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - btnSoGhe_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000AF0 RID: 2800 RVA: 0x00003CF0 File Offset: 0x00001EF0
		Private Sub btn10_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.05
			Me.mdblInput = 5.0
			Me.Close()
		End Sub

		' Token: 0x06000AF1 RID: 2801 RVA: 0x00003D19 File Offset: 0x00001F19
		Private Sub btn20_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.1
			Me.mdblInput = 10.0
			Me.Close()
		End Sub

		' Token: 0x06000AF2 RID: 2802 RVA: 0x00003D42 File Offset: 0x00001F42
		Private Sub btn50_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.25
			Me.mdblInput = 25.0
			Me.Close()
		End Sub

		' Token: 0x06000AF3 RID: 2803 RVA: 0x00003D6B File Offset: 0x00001F6B
		Private Sub btn60_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.5
			Me.mdblInput = 50.0
			Me.Close()
		End Sub

		' Token: 0x06000AF4 RID: 2804 RVA: 0x00003D94 File Offset: 0x00001F94
		Private Sub btn30_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.15
			Me.mdblInput = 15.0
			Me.Close()
		End Sub

		' Token: 0x06000AF5 RID: 2805 RVA: 0x00003DBD File Offset: 0x00001FBD
		Private Sub btn70_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.7
			Me.mdblInput = 70.0
			Me.Close()
		End Sub

		' Token: 0x06000AF6 RID: 2806 RVA: 0x00003DE6 File Offset: 0x00001FE6
		Private Sub btn40_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.2
			Me.mdblInput = 20.0
			Me.Close()
		End Sub

		' Token: 0x06000AF7 RID: 2807 RVA: 0x00003E0F File Offset: 0x0000200F
		Private Sub btn90_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.9
			Me.mdblInput = 90.0
			Me.Close()
		End Sub

		' Token: 0x06000AF8 RID: 2808 RVA: 0x00003E38 File Offset: 0x00002038
		Private Sub btn80_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.8
			Me.mdblInput = 80.0
			Me.Close()
		End Sub

		' Token: 0x06000AF9 RID: 2809 RVA: 0x00003E61 File Offset: 0x00002061
		Private Sub btn100_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 1.0
			Me.mdblInput = 100.0
			Me.Close()
		End Sub

		' Token: 0x06000AFA RID: 2810 RVA: 0x0008069C File Offset: 0x0007E89C
		Private Sub btnOK_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = Conversion.Val(Me.txtPer.Text.Trim()) / 100.0
			Me.mdblInput = Conversion.Val(Me.txtPer.Text.Trim())
			mdlFile.gfWriteLogFile("Nhập số % là: " + Me.txtPer.Text.Trim())
			Me.Close()
		End Sub

		' Token: 0x06000AFB RID: 2811 RVA: 0x00003E8A File Offset: 0x0000208A
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Me.mbytSuccess = 0
			mdlFile.gfWriteLogFile("Nhấn thoát form chọn số %")
			Me.Close()
		End Sub

		' Token: 0x06000AFC RID: 2812 RVA: 0x00080714 File Offset: 0x0007E914
		Private Sub frmDiscount_Load(sender As Object, e As EventArgs)
			Dim b As Byte = Me.fInitCaption()
		End Sub

		' Token: 0x06000AFD RID: 2813 RVA: 0x0008072C File Offset: 0x0007E92C
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Conversions.ToString(Interaction.IIf(Operators.CompareString(Me.mstrCaption, "", False) = 0, Me.mArrStrFrmMess(1), Me.mstrCaption)))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(2), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000AFE RID: 2814 RVA: 0x00003EA7 File Offset: 0x000020A7
		Private Sub btn_30_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.3
			Me.mdblInput = 30.0
			Me.Close()
		End Sub

		' Token: 0x06000AFF RID: 2815 RVA: 0x00003ED0 File Offset: 0x000020D0
		Private Sub btn_60_Click(sender As Object, e As EventArgs)
			Me.mdblPercent = 0.6
			Me.mdblInput = 60.0
			Me.Close()
		End Sub

		' Token: 0x06000B00 RID: 2816 RVA: 0x00080874 File Offset: 0x0007EA74
		Private Sub btnUser_Click(sender As Object, e As EventArgs)
			Dim text As String = Me.btnUser.Text.Trim().Replace("%", "")
			Dim num As Double = 0.0
			Dim flag As Boolean = Versioned.IsNumeric(text)
			If flag Then
				num = Conversion.Val(text)
			End If
			Me.mdblPercent = num / 100.0
			Me.mdblInput = num
			Me.Close()
		End Sub

		' Token: 0x040004BC RID: 1212
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040004BE RID: 1214
		<AccessedThroughProperty("btn10")>
		Private _btn10 As Button

		' Token: 0x040004BF RID: 1215
		<AccessedThroughProperty("btn20")>
		Private _btn20 As Button

		' Token: 0x040004C0 RID: 1216
		<AccessedThroughProperty("btn30")>
		Private _btn30 As Button

		' Token: 0x040004C1 RID: 1217
		<AccessedThroughProperty("btn40")>
		Private _btn40 As Button

		' Token: 0x040004C2 RID: 1218
		<AccessedThroughProperty("btn50")>
		Private _btn50 As Button

		' Token: 0x040004C3 RID: 1219
		<AccessedThroughProperty("btn60")>
		Private _btn60 As Button

		' Token: 0x040004C4 RID: 1220
		<AccessedThroughProperty("btn70")>
		Private _btn70 As Button

		' Token: 0x040004C5 RID: 1221
		<AccessedThroughProperty("btn80")>
		Private _btn80 As Button

		' Token: 0x040004C6 RID: 1222
		<AccessedThroughProperty("btn90")>
		Private _btn90 As Button

		' Token: 0x040004C7 RID: 1223
		<AccessedThroughProperty("btn100")>
		Private _btn100 As Button

		' Token: 0x040004C8 RID: 1224
		<AccessedThroughProperty("txtPer")>
		Private _txtPer As TextBox

		' Token: 0x040004C9 RID: 1225
		<AccessedThroughProperty("btnOK")>
		Private _btnOK As Button

		' Token: 0x040004CA RID: 1226
		<AccessedThroughProperty("GroupBox1")>
		Private _GroupBox1 As GroupBox

		' Token: 0x040004CB RID: 1227
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040004CC RID: 1228
		<AccessedThroughProperty("btn_30")>
		Private _btn_30 As Button

		' Token: 0x040004CD RID: 1229
		<AccessedThroughProperty("btn_60")>
		Private _btn_60 As Button

		' Token: 0x040004CE RID: 1230
		<AccessedThroughProperty("btnUser")>
		Private _btnUser As Button

		' Token: 0x040004CF RID: 1231
		Private mArrStrFrmMess As String()

		' Token: 0x040004D0 RID: 1232
		Private mbytSuccess As Byte

		' Token: 0x040004D1 RID: 1233
		Private mdblPercent As Double

		' Token: 0x040004D2 RID: 1234
		Private mstrCaption As String

		' Token: 0x040004D3 RID: 1235
		Private mdblInput As Double

		' Token: 0x040004D4 RID: 1236
		Private mblnTypePer As Boolean
	End Class
End Namespace
