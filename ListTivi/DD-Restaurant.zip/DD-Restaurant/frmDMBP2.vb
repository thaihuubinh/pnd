﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200003B RID: 59
	<DesignerGenerated()>
	Public Partial Class frmDMBP2
		Inherits Form

		' Token: 0x06000D91 RID: 3473 RVA: 0x000A0208 File Offset: 0x0009E408
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMBP2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMBP2_Load
			frmDMBP2.__ENCList.Add(New WeakReference(Me))
			Me.mstrKHO = ""
			Me.mstrFather = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x170004DD RID: 1245
		' (get) Token: 0x06000D94 RID: 3476 RVA: 0x000A1260 File Offset: 0x0009F460
		' (set) Token: 0x06000D95 RID: 3477 RVA: 0x00004336 File Offset: 0x00002536
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x170004DE RID: 1246
		' (get) Token: 0x06000D96 RID: 3478 RVA: 0x000A1278 File Offset: 0x0009F478
		' (set) Token: 0x06000D97 RID: 3479 RVA: 0x000A1290 File Offset: 0x0009F490
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170004DF RID: 1247
		' (get) Token: 0x06000D98 RID: 3480 RVA: 0x000A12FC File Offset: 0x0009F4FC
		' (set) Token: 0x06000D99 RID: 3481 RVA: 0x00004340 File Offset: 0x00002540
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x170004E0 RID: 1248
		' (get) Token: 0x06000D9A RID: 3482 RVA: 0x000A1314 File Offset: 0x0009F514
		' (set) Token: 0x06000D9B RID: 3483 RVA: 0x000A132C File Offset: 0x0009F52C
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x170004E1 RID: 1249
		' (get) Token: 0x06000D9C RID: 3484 RVA: 0x000A1398 File Offset: 0x0009F598
		' (set) Token: 0x06000D9D RID: 3485 RVA: 0x000A13B0 File Offset: 0x0009F5B0
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170004E2 RID: 1250
		' (get) Token: 0x06000D9E RID: 3486 RVA: 0x000A141C File Offset: 0x0009F61C
		' (set) Token: 0x06000D9F RID: 3487 RVA: 0x000A1434 File Offset: 0x0009F634
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170004E3 RID: 1251
		' (get) Token: 0x06000DA0 RID: 3488 RVA: 0x000A14A0 File Offset: 0x0009F6A0
		' (set) Token: 0x06000DA1 RID: 3489 RVA: 0x0000434A File Offset: 0x0000254A
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x170004E4 RID: 1252
		' (get) Token: 0x06000DA2 RID: 3490 RVA: 0x000A14B8 File Offset: 0x0009F6B8
		' (set) Token: 0x06000DA3 RID: 3491 RVA: 0x000A14D0 File Offset: 0x0009F6D0
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.GotFocus, AddressOf Me.txtOBJNAME_GotFocus
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x170004E5 RID: 1253
		' (get) Token: 0x06000DA4 RID: 3492 RVA: 0x000A156C File Offset: 0x0009F76C
		' (set) Token: 0x06000DA5 RID: 3493 RVA: 0x000A1584 File Offset: 0x0009F784
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170004E6 RID: 1254
		' (get) Token: 0x06000DA6 RID: 3494 RVA: 0x000A1620 File Offset: 0x0009F820
		' (set) Token: 0x06000DA7 RID: 3495 RVA: 0x00004354 File Offset: 0x00002554
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x170004E7 RID: 1255
		' (get) Token: 0x06000DA8 RID: 3496 RVA: 0x000A1638 File Offset: 0x0009F838
		' (set) Token: 0x06000DA9 RID: 3497 RVA: 0x0000435E File Offset: 0x0000255E
		Friend Overridable Property lblWEBSITE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblWEBSITE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblWEBSITE = value
			End Set
		End Property

		' Token: 0x170004E8 RID: 1256
		' (get) Token: 0x06000DAA RID: 3498 RVA: 0x000A1650 File Offset: 0x0009F850
		' (set) Token: 0x06000DAB RID: 3499 RVA: 0x000A1668 File Offset: 0x0009F868
		Friend Overridable Property cmbKHO As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbKHO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbKHO IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbKHO.KeyPress, AddressOf Me.cmbKHO_KeyPress
					RemoveHandler Me._cmbKHO.GotFocus, AddressOf Me.cmbKHO_GotFocus
				End If
				Me._cmbKHO = value
				flag = Me._cmbKHO IsNot Nothing
				If flag Then
					AddHandler Me._cmbKHO.KeyPress, AddressOf Me.cmbKHO_KeyPress
					AddHandler Me._cmbKHO.GotFocus, AddressOf Me.cmbKHO_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170004E9 RID: 1257
		' (get) Token: 0x06000DAC RID: 3500 RVA: 0x000A1704 File Offset: 0x0009F904
		' (set) Token: 0x06000DAD RID: 3501 RVA: 0x00004368 File Offset: 0x00002568
		Friend Overridable Property lblKHO As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblKHO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblKHO = value
			End Set
		End Property

		' Token: 0x170004EA RID: 1258
		' (get) Token: 0x06000DAE RID: 3502 RVA: 0x000A171C File Offset: 0x0009F91C
		' (set) Token: 0x06000DAF RID: 3503 RVA: 0x000A1734 File Offset: 0x0009F934
		Friend Overridable Property txtREMARK As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtREMARK
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtREMARK IsNot Nothing
				If flag Then
					RemoveHandler Me._txtREMARK.KeyPress, AddressOf Me.txtREMARK_KeyPress
					RemoveHandler Me._txtREMARK.GotFocus, AddressOf Me.txtREMARK_GotFocus
				End If
				Me._txtREMARK = value
				flag = Me._txtREMARK IsNot Nothing
				If flag Then
					AddHandler Me._txtREMARK.KeyPress, AddressOf Me.txtREMARK_KeyPress
					AddHandler Me._txtREMARK.GotFocus, AddressOf Me.txtREMARK_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170004EB RID: 1259
		' (get) Token: 0x06000DB0 RID: 3504 RVA: 0x000A17D0 File Offset: 0x0009F9D0
		' (set) Token: 0x06000DB1 RID: 3505 RVA: 0x000A17E8 File Offset: 0x0009F9E8
		Friend Overridable Property txtTENBP As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENBP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENBP IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENBP.GotFocus, AddressOf Me.txtTENBP_GotFocus
				End If
				Me._txtTENBP = value
				flag = Me._txtTENBP IsNot Nothing
				If flag Then
					AddHandler Me._txtTENBP.GotFocus, AddressOf Me.txtTENBP_GotFocus
				End If
			End Set
		End Property

		' Token: 0x170004EC RID: 1260
		' (get) Token: 0x06000DB2 RID: 3506 RVA: 0x000A1854 File Offset: 0x0009FA54
		' (set) Token: 0x06000DB3 RID: 3507 RVA: 0x000A186C File Offset: 0x0009FA6C
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170004ED RID: 1261
		' (get) Token: 0x06000DB4 RID: 3508 RVA: 0x000A18D8 File Offset: 0x0009FAD8
		' (set) Token: 0x06000DB5 RID: 3509 RVA: 0x000A18F0 File Offset: 0x0009FAF0
		Friend Overridable Property txtMABP As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMABP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMABP IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMABP.KeyPress, AddressOf Me.txtMABP_KeyPress
					RemoveHandler Me._txtMABP.GotFocus, AddressOf Me.txtMABP_GotFocus
					RemoveHandler Me._txtMABP.TextChanged, AddressOf Me.txtMABP_TextChanged
				End If
				Me._txtMABP = value
				flag = Me._txtMABP IsNot Nothing
				If flag Then
					AddHandler Me._txtMABP.KeyPress, AddressOf Me.txtMABP_KeyPress
					AddHandler Me._txtMABP.GotFocus, AddressOf Me.txtMABP_GotFocus
					AddHandler Me._txtMABP.TextChanged, AddressOf Me.txtMABP_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170004EE RID: 1262
		' (get) Token: 0x06000DB6 RID: 3510 RVA: 0x000A19C0 File Offset: 0x0009FBC0
		' (set) Token: 0x06000DB7 RID: 3511 RVA: 0x00004372 File Offset: 0x00002572
		Friend Overridable Property lblVATCODE As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblVATCODE
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblVATCODE = value
			End Set
		End Property

		' Token: 0x170004EF RID: 1263
		' (get) Token: 0x06000DB8 RID: 3512 RVA: 0x000A19D8 File Offset: 0x0009FBD8
		' (set) Token: 0x06000DB9 RID: 3513 RVA: 0x0000437C File Offset: 0x0000257C
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170004F0 RID: 1264
		' (get) Token: 0x06000DBA RID: 3514 RVA: 0x000A19F0 File Offset: 0x0009FBF0
		' (set) Token: 0x06000DBB RID: 3515 RVA: 0x000A1A08 File Offset: 0x0009FC08
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x170004F1 RID: 1265
		' (get) Token: 0x06000DBC RID: 3516 RVA: 0x000A1A74 File Offset: 0x0009FC74
		' (set) Token: 0x06000DBD RID: 3517 RVA: 0x00004386 File Offset: 0x00002586
		Public Property pStrFather As String
			Get
				Return Me.mstrFather
			End Get
			Set(value As String)
				Me.mstrFather = value
			End Set
		End Property

		' Token: 0x170004F2 RID: 1266
		' (get) Token: 0x06000DBE RID: 3518 RVA: 0x000A1A8C File Offset: 0x0009FC8C
		' (set) Token: 0x06000DBF RID: 3519 RVA: 0x00004391 File Offset: 0x00002591
		Public Property pStrKHO As String
			Get
				Return Me.mstrKHO
			End Get
			Set(value As String)
				Me.mstrKHO = value
			End Set
		End Property

		' Token: 0x170004F3 RID: 1267
		' (get) Token: 0x06000DC0 RID: 3520 RVA: 0x000A1AA4 File Offset: 0x0009FCA4
		' (set) Token: 0x06000DC1 RID: 3521 RVA: 0x0000439C File Offset: 0x0000259C
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x170004F4 RID: 1268
		' (get) Token: 0x06000DC2 RID: 3522 RVA: 0x000A1ABC File Offset: 0x0009FCBC
		' (set) Token: 0x06000DC3 RID: 3523 RVA: 0x000043A7 File Offset: 0x000025A7
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x170004F5 RID: 1269
		' (get) Token: 0x06000DC4 RID: 3524 RVA: 0x000A1AD4 File Offset: 0x0009FCD4
		' (set) Token: 0x06000DC5 RID: 3525 RVA: 0x000043B2 File Offset: 0x000025B2
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06000DC6 RID: 3526 RVA: 0x000A1AEC File Offset: 0x0009FCEC
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DC7 RID: 3527 RVA: 0x000A1B98 File Offset: 0x0009FD98
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim num As Integer = Strings.Asc(e.KeyChar)
				Dim flag As Boolean = num = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000DC8 RID: 3528 RVA: 0x000A1C40 File Offset: 0x0009FE40
		Private Sub txtOBJNAME_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJNAME.[ReadOnly]
				If [readOnly] Then
					Me.txtMABP.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DC9 RID: 3529 RVA: 0x000A1CEC File Offset: 0x0009FEEC
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMABP.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000DCA RID: 3530 RVA: 0x000A1D90 File Offset: 0x0009FF90
		Private Sub txtMABP_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtMABP.[ReadOnly]
				If [readOnly] Then
					Me.cmbKHO.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMABP_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DCB RID: 3531 RVA: 0x000A1E3C File Offset: 0x000A003C
		Private Sub txtMABP_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbKHO.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMABP_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000DCC RID: 3532 RVA: 0x000A1EE0 File Offset: 0x000A00E0
		Private Sub txtMABP_TextChanged(sender As Object, e As EventArgs)
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim array2 As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMBP Is Nothing
				If Not flag Then
					array2(0) = Me.mclsTbDMBP.Columns("OBJID")
					Me.mclsTbDMBP.PrimaryKey = array2
					Dim dataRow As DataRow = Me.mclsTbDMBP.Rows.Find(Strings.Trim(Me.txtMABP.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENBP.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENBP.Text = ""
					End If
					flag = (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 1)
					If flag Then
						Application.DoEvents()
						array(0) = sqlCommand.CreateParameter()
						array(0).ParameterName = "@pnchFather"
						array(0).Value = Strings.Trim(Me.txtMABP.Text)
						array(1) = sqlCommand.CreateParameter()
						array(1).ParameterName = "@pintResult"
						array(1).Direction = ParameterDirection.ReturnValue
						Dim flag2 As Boolean
						clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMBP_GET_MAX_OBJID", flag2)
						flag = flag2
						If flag Then
							Dim flag3 As Boolean = (dataRow IsNot Nothing) And (Strings.Len(Strings.Trim(Me.txtMABP.Text)) > 0)
							If flag3 Then
								Me.txtOBJID.Text = Strings.Trim(Me.txtMABP.Text) + Strings.Right("000" + array(1).Value.ToString(), 3)
							Else
								flag3 = Strings.Len(Strings.Trim(Me.txtMABP.Text)) = 0
								If flag3 Then
									Me.txtOBJID.Text = Strings.Right("000" + array(1).Value.ToString(), 3)
								Else
									Me.txtOBJID.Text = ""
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMABP_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
		End Sub

		' Token: 0x06000DCD RID: 3533 RVA: 0x000A21C0 File Offset: 0x000A03C0
		Private Sub cmbKHO_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbytFormStatus = 4
				If flag Then
					Me.txtREMARK.Focus()
				Else
					Me.cmbKHO.DroppedDown = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbKHO_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DCE RID: 3534 RVA: 0x000A227C File Offset: 0x000A047C
		Private Sub cmbKHO_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtREMARK.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbKHO_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000DCF RID: 3535 RVA: 0x000A2320 File Offset: 0x000A0520
		Private Sub txtREMARK_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtREMARK.[ReadOnly]
				If [readOnly] Then
					Me.btnExit.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtREMARK_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000DD0 RID: 3536 RVA: 0x000A23C0 File Offset: 0x000A05C0
		Private Sub txtREMARK_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim flag2 As Boolean = Me.mbytFormStatus = 5
					If flag2 Then
						Me.btnFilter.Focus()
					Else
						flag2 = Me.mbytFormStatus = 6
						If flag2 Then
							Me.btnFind.Focus()
						Else
							Me.btnSave.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtREMARK_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000DD1 RID: 3537 RVA: 0x000A249C File Offset: 0x000A069C
		Private Sub txtTENBP_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENBP.[ReadOnly]
				If [readOnly] Then
					Me.cmbKHO.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENBP_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000DD2 RID: 3538 RVA: 0x000A253C File Offset: 0x000A073C
		Private Sub frmDMBP2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DD3 RID: 3539 RVA: 0x000A25E8 File Offset: 0x000A07E8
		Private Sub frmDMBP2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Combo()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMBPFather()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMBP2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DD4 RID: 3540 RVA: 0x000A26BC File Offset: 0x000A08BC
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(22), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
						If flag Then
							Me.mbytSuccess = Me.fAddNew()
						Else
							flag = Me.mbytFormStatus = 3
							If flag Then
								Me.mbytSuccess = Me.fModify()
							End If
						End If
						flag = Me.mbytSuccess = 1
						If flag Then
							Me.Close()
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DD5 RID: 3541 RVA: 0x000A2848 File Offset: 0x000A0A48
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DD6 RID: 3542 RVA: 0x000A28EC File Offset: 0x000A0AEC
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				text2 = Conversions.ToString(Me.cmbKHO.SelectedValue)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtREMARK.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMABP.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FATHER like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DD7 RID: 3543 RVA: 0x000A2BCC File Offset: 0x000A0DCC
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '%" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '%"), text2), "%'"))
				End If
				text2 = Conversions.ToString(Me.cmbKHO.SelectedValue)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtREMARK.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " REMARK like '%"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMABP.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FATHER like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DD8 RID: 3544 RVA: 0x000A2EAC File Offset: 0x000A10AC
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMBP As frmDMBP1 = New frmDMBP1()
				frmDMBP.pBytOpen_From_Menu = 7
				frmDMBP.pbytIsFather = 1
				frmDMBP.ShowDialog()
				Me.txtMABP.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMBP.pStrOBJID, "", False) = 0, Me.txtMABP.Text, frmDMBP.pStrOBJID))
				Me.txtTENBP.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMBP.pStrOBJNAME, "", False) = 0, Me.txtTENBP.Text, frmDMBP.pStrOBJNAME))
				frmDMBP.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DD9 RID: 3545 RVA: 0x000A2FD8 File Offset: 0x000A11D8
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJNAME.Focus()
						Me.txtOBJID.[ReadOnly] = True
						Me.txtMABP.[ReadOnly] = True
						Me.txtMABP.BackColor = Me.txtTENBP.BackColor
						Me.txtOBJID.BackColor = Me.txtTENBP.BackColor
						Me.btnSelect.Enabled = False
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtMABP.[ReadOnly] = True
						Me.txtREMARK.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtTENBP.BackColor
						Me.txtMABP.BackColor = Me.txtTENBP.BackColor
						Me.txtOBJNAME.BackColor = Me.txtTENBP.BackColor
						Me.txtREMARK.BackColor = Me.txtTENBP.BackColor
						Me.cmbKHO.BackColor = Me.txtTENBP.BackColor
						Me.btnSelect.Enabled = False
					Case 5, 6
						Me.cmbKHO.SelectedIndex = Me.cmbKHO.Items.Count - 1
						Me.txtOBJID.[ReadOnly] = False
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000DDA RID: 3546 RVA: 0x000A31F8 File Offset: 0x000A13F8
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000DDB RID: 3547 RVA: 0x000A3388 File Offset: 0x000A1588
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 6
				Me.txtOBJNAME.MaxLength = 20
				Me.txtMABP.MaxLength = 3
				Me.txtREMARK.MaxLength = 200
				Me.txtTENBP.[ReadOnly] = True
				Me.cmbKHO.DropDownStyle = ComboBoxStyle.DropDownList
				Dim flag As Boolean = Me.mbytFormStatus = 4
				If flag Then
					Me.cmbKHO.DropDownStyle = ComboBoxStyle.DropDown
				End If
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000DDC RID: 3548 RVA: 0x000A34B0 File Offset: 0x000A16B0
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0007"
					Me.lblOBJNAME.Tag = "CB0008"
					Me.lblKHO.Tag = "CB0031"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(13))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(14))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(15))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(17))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(16))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000DDD RID: 3549 RVA: 0x000A36A8 File Offset: 0x000A18A8
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMBP.Dispose()
				Me.mclsTbKHO.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000DDE RID: 3550 RVA: 0x000A3760 File Offset: 0x000A1960
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(6) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = RuntimeHelpers.GetObjectValue(Me.cmbKHO.SelectedValue)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchFather"
				array(3).Value = Strings.Trim(Me.txtMABP.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvcREMARK"
				array(4).Value = Strings.Trim(Me.txtREMARK.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@int_Result"
				array(5).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMBP_INSERT_DMBP", flag)
				Dim num As Integer = Conversions.ToInteger(array(5).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJID.Focus()
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000DDF RID: 3551 RVA: 0x000A39FC File Offset: 0x000A1BFC
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(6) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvcTEN"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = RuntimeHelpers.GetObjectValue(Me.cmbKHO.SelectedValue)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchFather"
				array(3).Value = Strings.Trim(Me.txtMABP.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvcREMARK"
				array(4).Value = Strings.Trim(Me.txtREMARK.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@int_Result"
				array(5).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMBP_UPDATE_DMBP", flag)
				Dim num As Integer = Conversions.ToInteger(array(5).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
					Else
						Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000DE0 RID: 3552 RVA: 0x000A3C88 File Offset: 0x000A1E88
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMA"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMBP_DEL_DMBP", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(34), MsgBoxStyle.Critical, Nothing)
							Else
								Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000DE1 RID: 3553 RVA: 0x000A3E6C File Offset: 0x000A206C
		Private Function fGetData_4Combo() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbKHO = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = (Me.mbytFormStatus = 5) Or (Me.mbytFormStatus = 6)
				If flag Then
					Me.mclsTbKHO.Rows.Add(New Object() { "", Me.mArrStrFrmMess(9) })
				End If
				flag = Me.mclsTbKHO IsNot Nothing
				If flag Then
					Dim cmbKHO As ComboBox = Me.cmbKHO
					cmbKHO.DataSource = Me.mclsTbKHO
					cmbKHO.DisplayMember = "OBJNAME"
					cmbKHO.ValueMember = "OBJID"
					cmbKHO.SelectedIndex = 0
					b = 1
				End If
				flag = Operators.CompareString(Me.mstrKHO, "", False) <> 0
				If flag Then
					Me.cmbKHO.SelectedValue = Me.mstrKHO
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000DE2 RID: 3554 RVA: 0x000A3FF8 File Offset: 0x000A21F8
		Private Function fGetData_DMBPFather() As Byte
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@ptniFATHER"
				array(0).Value = 1
				Dim num As Integer
				Me.mclsTbDMBP = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMBP_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMBPFather ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000DE3 RID: 3555 RVA: 0x000A40F8 File Offset: 0x000A22F8
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x06000DE4 RID: 3556 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x040005D1 RID: 1489
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040005D3 RID: 1491
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x040005D4 RID: 1492
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x040005D5 RID: 1493
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040005D6 RID: 1494
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x040005D7 RID: 1495
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x040005D8 RID: 1496
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x040005D9 RID: 1497
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x040005DA RID: 1498
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x040005DB RID: 1499
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x040005DC RID: 1500
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x040005DD RID: 1501
		<AccessedThroughProperty("lblWEBSITE")>
		Private _lblWEBSITE As Label

		' Token: 0x040005DE RID: 1502
		<AccessedThroughProperty("cmbKHO")>
		Private _cmbKHO As ComboBox

		' Token: 0x040005DF RID: 1503
		<AccessedThroughProperty("lblKHO")>
		Private _lblKHO As Label

		' Token: 0x040005E0 RID: 1504
		<AccessedThroughProperty("txtREMARK")>
		Private _txtREMARK As TextBox

		' Token: 0x040005E1 RID: 1505
		<AccessedThroughProperty("txtTENBP")>
		Private _txtTENBP As TextBox

		' Token: 0x040005E2 RID: 1506
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040005E3 RID: 1507
		<AccessedThroughProperty("txtMABP")>
		Private _txtMABP As TextBox

		' Token: 0x040005E4 RID: 1508
		<AccessedThroughProperty("lblVATCODE")>
		Private _lblVATCODE As Label

		' Token: 0x040005E5 RID: 1509
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x040005E6 RID: 1510
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x040005E7 RID: 1511
		Private mArrStrFrmMess As String()

		' Token: 0x040005E8 RID: 1512
		Private mbytFormStatus As Byte

		' Token: 0x040005E9 RID: 1513
		Private mbytSuccess As Byte

		' Token: 0x040005EA RID: 1514
		Private mStrFilter As String

		' Token: 0x040005EB RID: 1515
		Private mclsTbKHO As clsConnect

		' Token: 0x040005EC RID: 1516
		Private mclsTbDMBP As clsConnect

		' Token: 0x040005ED RID: 1517
		Private mstrKHO As String

		' Token: 0x040005EE RID: 1518
		Private mstrFather As String
	End Class
End Namespace
