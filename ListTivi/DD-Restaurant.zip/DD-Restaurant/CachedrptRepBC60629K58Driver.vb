﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002B8 RID: 696
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60629K58Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006954 RID: 26964 RVA: 0x000131D7 File Offset: 0x000113D7
		Public Sub New()
			CachedrptRepBC60629K58Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x1700296B RID: 10603
		' (get) Token: 0x06006955 RID: 26965 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006956 RID: 26966 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700296C RID: 10604
		' (get) Token: 0x06006957 RID: 26967 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006958 RID: 26968 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x1700296D RID: 10605
		' (get) Token: 0x06006959 RID: 26969 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x0600695A RID: 26970 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x0600695B RID: 26971 RVA: 0x004DE260 File Offset: 0x004DC460
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60629K58Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x0600695C RID: 26972 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028B0 RID: 10416
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
