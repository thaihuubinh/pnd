﻿Imports System
Imports System.Collections
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Runtime.CompilerServices
Imports Microsoft.VisualBasic

Namespace prjIS_SalesPOS
	' Token: 0x02000009 RID: 9
	Public Class clsConnect
		Inherits DataTable

		' Token: 0x170000D1 RID: 209
		' (get) Token: 0x060001B1 RID: 433 RVA: 0x0001C4AC File Offset: 0x0001A6AC
		' (set) Token: 0x060001B2 RID: 434 RVA: 0x000020C4 File Offset: 0x000002C4
		Private Overridable Property mDa As SqlDataAdapter
			<DebuggerNonUserCode()>
			Get
				Return Me._mDa
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As SqlDataAdapter)
				Me._mDa = value
			End Set
		End Property

		' Token: 0x170000D2 RID: 210
		' (get) Token: 0x060001B3 RID: 435 RVA: 0x0001C4C4 File Offset: 0x0001A6C4
		' (set) Token: 0x060001B4 RID: 436 RVA: 0x000020CE File Offset: 0x000002CE
		Public Property pStrSQL As String
			Get
				Return Me.mStrSQL
			End Get
			Set(value As String)
				Me.mStrSQL = value
			End Set
		End Property

		' Token: 0x170000D3 RID: 211
		' (get) Token: 0x060001B5 RID: 437 RVA: 0x0001C4DC File Offset: 0x0001A6DC
		' (set) Token: 0x060001B6 RID: 438 RVA: 0x000020D9 File Offset: 0x000002D9
		Public Property pStrTable As String
			Get
				Return Me.mStrTable
			End Get
			Set(value As String)
				Me.mStrTable = value
			End Set
		End Property

		' Token: 0x170000D4 RID: 212
		' (get) Token: 0x060001B7 RID: 439 RVA: 0x0001C4F4 File Offset: 0x0001A6F4
		' (set) Token: 0x060001B8 RID: 440 RVA: 0x000020E4 File Offset: 0x000002E4
		Public Property pCnConnectSQL As SqlConnection
			Get
				Return Me.mCnSQL
			End Get
			Set(value As SqlConnection)
				Me.mCnSQL = value
			End Set
		End Property

		' Token: 0x170000D5 RID: 213
		' (get) Token: 0x060001B9 RID: 441 RVA: 0x0001C50C File Offset: 0x0001A70C
		' (set) Token: 0x060001BA RID: 442 RVA: 0x000020EF File Offset: 0x000002EF
		Public Property pStrProcName As String
			Get
				Return Me.mStrProcName
			End Get
			Set(value As String)
				Me.mStrProcName = value
			End Set
		End Property

		' Token: 0x170000D6 RID: 214
		' (get) Token: 0x060001BB RID: 443 RVA: 0x0001C524 File Offset: 0x0001A724
		' (set) Token: 0x060001BC RID: 444 RVA: 0x000020FA File Offset: 0x000002FA
		Public Property pCmdSQL As SqlCommand
			Get
				Return Me.mCmdSQL
			End Get
			Set(value As SqlCommand)
				Me.mCmdSQL = value
			End Set
		End Property

		' Token: 0x170000D7 RID: 215
		' (get) Token: 0x060001BD RID: 445 RVA: 0x0001C53C File Offset: 0x0001A73C
		' (set) Token: 0x060001BE RID: 446 RVA: 0x00002105 File Offset: 0x00000305
		Public Property pSqlPar As SqlParameter()
			Get
				Return Me.mParSQL
			End Get
			Set(value As SqlParameter())
				Me.mParSQL = value
			End Set
		End Property

		' Token: 0x060001BF RID: 447 RVA: 0x00002110 File Offset: 0x00000310
		Public Sub New()
			clsConnect.__ENCList.Add(New WeakReference(Me))
			Me.mCmdSQL = New SqlCommand()
			Me.mDa = New SqlDataAdapter()
		End Sub

		' Token: 0x060001C0 RID: 448 RVA: 0x0001C554 File Offset: 0x0001A754
		Public Sub New(pStrConnect As String, pstrTableName As String)
			clsConnect.__ENCList.Add(New WeakReference(Me))
			Me.mCmdSQL = New SqlCommand()
			Me.mDa = New SqlDataAdapter()
			Try
				Me.mStrTable = pstrTableName
				Me.mStrConnect = pStrConnect
				Dim flag As Boolean = Me.fRead_Table(False)
			Catch ex As Exception
				Interaction.MsgBox(mdlVariable.gArrStrMess(2) + vbCrLf & "clsConnect - New" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060001C1 RID: 449 RVA: 0x0001C5FC File Offset: 0x0001A7FC
		Public Sub New(pStrConnect As String, pstrTableName As String, pstrTableName2 As String, pstrTableName3 As String)
			clsConnect.__ENCList.Add(New WeakReference(Me))
			Me.mCmdSQL = New SqlCommand()
			Me.mDa = New SqlDataAdapter()
			Try
				Me.mStrTable = pstrTableName
				Me.mStrConnect = pStrConnect
				Dim flag As Boolean = Me.fRead_Table(True)
			Catch ex As Exception
			Finally
			End Try
		End Sub

		' Token: 0x060001C2 RID: 450 RVA: 0x0001C684 File Offset: 0x0001A884
		Public Sub New(pStrConnect As String, psqlParProc As SqlParameter(), pStrProcRead As String, ByRef pintRetProcTable As Integer)
			clsConnect.__ENCList.Add(New WeakReference(Me))
			Me.mCmdSQL = New SqlCommand()
			Me.mDa = New SqlDataAdapter()
			Try
				pintRetProcTable = 0
				Me.mStrConnect = pStrConnect
				Me.mStrProcName = pStrProcRead
				Me.mParSQL = psqlParProc
				Dim flag As Boolean = Me.fRead_Proc()
				If flag Then
					pintRetProcTable = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(mdlVariable.gArrStrMess(2) + vbCrLf & "clsConnect - New" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060001C3 RID: 451 RVA: 0x0001C73C File Offset: 0x0001A93C
		Public Sub New(pStrConnect As String, psqlParProc As SqlParameter(), pStrProcRead As String, ByRef pblnRetExecProc As Boolean)
			clsConnect.__ENCList.Add(New WeakReference(Me))
			Me.mCmdSQL = New SqlCommand()
			Me.mDa = New SqlDataAdapter()
			Try
				Me.mStrConnect = pStrConnect
				Me.mStrProcName = pStrProcRead
				Me.mParSQL = psqlParProc
				pblnRetExecProc = Me.fExec_Proc()
			Catch ex As Exception
				Interaction.MsgBox(mdlVariable.gArrStrMess(2) + vbCrLf & "clsConnect - New" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060001C4 RID: 452 RVA: 0x0001C7EC File Offset: 0x0001A9EC
		Public Sub New(pStrConnect As String, pStrProcRead As String, ByRef pblnRetExecProc As Boolean)
			clsConnect.__ENCList.Add(New WeakReference(Me))
			Me.mCmdSQL = New SqlCommand()
			Me.mDa = New SqlDataAdapter()
			Try
				Me.mStrConnect = pStrConnect
				Me.mStrProcName = pStrProcRead
				pblnRetExecProc = Me.fRead_Proc_No_Where()
			Catch ex As Exception
				Interaction.MsgBox(mdlVariable.gArrStrMess(2) + vbCrLf & "clsConnect - New" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060001C5 RID: 453 RVA: 0x0001C894 File Offset: 0x0001AA94
		Private Function fRead_Table(Optional blnNoError As Boolean = False) As Boolean
			Dim flag As Boolean
			Try
				flag = False
				Dim flag2 As Boolean = True
				Me.mStrSQL = "select * from " + Me.mStrTable
				Dim flag3 As Boolean = Me.mCnSQL Is Nothing
				If flag3 Then
					Me.mCnSQL = New SqlConnection()
					Me.mCnSQL.ConnectionString = Me.mStrConnect + "; Connect Timeout=30000"
					Me.mCnSQL.Open()
					flag3 = Me.mCnSQL.State <> ConnectionState.Open
					If flag3 Then
						Interaction.MsgBox(mdlVariable.gArrStrMess(3) + vbCrLf & "clsConnect - fRead_Table", MsgBoxStyle.Critical, Nothing)
						flag2 = False
					End If
				End If
				flag3 = flag2
				If flag3 Then
					Me.mCmdSQL.Connection = Me.mCnSQL
					Me.mCmdSQL.CommandType = CommandType.Text
					Me.mCmdSQL.CommandText = Me.mStrSQL
					Me.mCmdSQL.CommandTimeout = 30000
					Me.mCmdSQL.ExecuteNonQuery()
					Me.mDa = New SqlDataAdapter(Me.mCmdSQL)
					Me.mDa.Fill(Me)
					Me.mCnSQL.Close()
					flag = True
				End If
				Me.sSetNothing()
			Catch ex As Exception
				Dim flag3 As Boolean = Not blnNoError
				If flag3 Then
					Interaction.MsgBox(String.Concat(New String() { mdlVariable.gArrStrMess(2), vbCrLf & "clsConnect - fRead_Table: ", Me.mStrSQL, vbCrLf, ex.Message }), MsgBoxStyle.Critical, Nothing)
				End If
			Finally
				Me.sSetNothing()
			End Try
			Return flag
		End Function

		' Token: 0x060001C6 RID: 454 RVA: 0x0001CA60 File Offset: 0x0001AC60
		Private Function fRead_Proc() As Boolean
			' The following expression was wrapped in a checked-statement
			Dim flag As Boolean
			Try
				flag = False
				Dim flag2 As Boolean = True
				Dim flag3 As Boolean = Me.mCnSQL Is Nothing
				If flag3 Then
					Me.mCnSQL = New SqlConnection()
					Me.mCnSQL.ConnectionString = Me.mStrConnect + "; Connect Timeout=30000"
					Me.mCnSQL.Open()
					flag3 = Me.mCnSQL.State <> ConnectionState.Open
					If flag3 Then
						Interaction.MsgBox(mdlVariable.gArrStrMess(3) + vbCrLf & "clsConnect - fRead_Proc", MsgBoxStyle.Critical, Nothing)
						flag2 = False
					End If
				End If
				flag3 = flag2
				If flag3 Then
					Me.mCmdSQL.Connection = Me.mCnSQL
					Me.mCmdSQL.CommandType = CommandType.StoredProcedure
					Me.mCmdSQL.CommandText = Me.mStrProcName
					Me.mCmdSQL.CommandTimeout = 30000
					Dim num As Integer = 0
					Dim num2 As Integer = Information.UBound(Me.mParSQL, 1) - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						Me.mCmdSQL.Parameters.Add(Me.mParSQL(num3))
						num3 += 1
					End While
					Me.mDa = New SqlDataAdapter(Me.mCmdSQL)
					Me.mDa.Fill(Me)
					Me.mCnSQL.Close()
					flag = True
				End If
				Me.sSetNothing()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { mdlVariable.gArrStrMess(2), vbCrLf & "clsConnect - fRead_Proc: ", Me.mStrProcName, vbCrLf, ex.Message }), MsgBoxStyle.Critical, Nothing)
			Finally
				Me.sSetNothing()
			End Try
			Return flag
		End Function

		' Token: 0x060001C7 RID: 455 RVA: 0x0001CC44 File Offset: 0x0001AE44
		Private Function fExec_Proc() As Boolean
			' The following expression was wrapped in a checked-statement
			Dim flag As Boolean
			Try
				flag = False
				Dim flag2 As Boolean = True
				Dim flag3 As Boolean = Me.mCnSQL Is Nothing
				If flag3 Then
					Me.mCnSQL = New SqlConnection()
					Me.mCnSQL.ConnectionString = Me.mStrConnect + "; Connect Timeout=30000"
					Me.mCnSQL.Open()
					flag3 = Me.mCnSQL.State <> ConnectionState.Open
					If flag3 Then
						Interaction.MsgBox(mdlVariable.gArrStrMess(3) + vbCrLf & "clsConnect - fExec_Proc", MsgBoxStyle.Critical, Nothing)
						flag2 = False
					End If
				End If
				flag3 = flag2
				If flag3 Then
					Me.mCmdSQL.Connection = Me.mCnSQL
					Me.mCmdSQL.CommandType = CommandType.StoredProcedure
					Me.mCmdSQL.CommandText = Me.mStrProcName
					Me.mCmdSQL.CommandTimeout = 30000
					Dim num As Integer = 0
					Dim num2 As Integer = Information.UBound(Me.mParSQL, 1) - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						Me.mCmdSQL.Parameters.Add(Me.mParSQL(num3))
						num3 += 1
					End While
					Me.mCmdSQL.ExecuteNonQuery()
					Me.mCnSQL.Close()
					flag = True
				End If
				Me.sSetNothing()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { mdlVariable.gArrStrMess(2), vbCrLf & "clsConnect - fExec_Proc: ", Me.mStrProcName, vbCrLf, ex.Message }), MsgBoxStyle.Critical, Nothing)
			Finally
				Me.sSetNothing()
			End Try
			Return flag
		End Function

		' Token: 0x060001C8 RID: 456 RVA: 0x0001CE18 File Offset: 0x0001B018
		Private Function fRead_Proc_No_Where() As Boolean
			Dim flag As Boolean
			Try
				flag = False
				Dim flag2 As Boolean = True
				Dim flag3 As Boolean = Me.mCnSQL Is Nothing
				If flag3 Then
					Me.mCnSQL = New SqlConnection()
					Me.mCnSQL.ConnectionString = Me.mStrConnect + "; Connect Timeout=30000"
					Me.mCnSQL.Open()
					flag3 = Me.mCnSQL.State <> ConnectionState.Open
					If flag3 Then
						Interaction.MsgBox(mdlVariable.gArrStrMess(3) + vbCrLf & "clsConnect - fRead_Proc_No_Where", MsgBoxStyle.Critical, Nothing)
						flag2 = False
					End If
				End If
				flag3 = flag2
				If flag3 Then
					Me.mCmdSQL.Connection = Me.mCnSQL
					Me.mCmdSQL.CommandType = CommandType.StoredProcedure
					Me.mCmdSQL.CommandText = Me.mStrProcName
					Me.mCmdSQL.CommandTimeout = 30000
					Me.mCmdSQL.ExecuteNonQuery()
					Me.mDa = New SqlDataAdapter(Me.mCmdSQL)
					Me.mDa.Fill(Me)
					Me.mCnSQL.Close()
					flag = True
				End If
				Me.sSetNothing()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { mdlVariable.gArrStrMess(2), vbCrLf & "clsConnect - fRead_Proc_No_Where: ", Me.mStrProcName, vbCrLf, ex.Message }), MsgBoxStyle.Critical, Nothing)
			Finally
				Me.sSetNothing()
			End Try
			Return flag
		End Function

		' Token: 0x060001C9 RID: 457 RVA: 0x0001CFC4 File Offset: 0x0001B1C4
		Private Sub sSetNothing()
			Try
				Me.mDa = Nothing
				Me.mCmdSQL = Nothing
				Me.mCnSQL = Nothing
			Catch ex As Exception
				Interaction.MsgBox(mdlVariable.gArrStrMess(1) + vbCrLf & "mdlFile - sSetNothing" & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x040000D4 RID: 212
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040000D5 RID: 213
		Private mStrSQL As String

		' Token: 0x040000D6 RID: 214
		Private mStrTable As String

		' Token: 0x040000D7 RID: 215
		Private mStrProcName As String

		' Token: 0x040000D8 RID: 216
		Private mStrConnect As String

		' Token: 0x040000D9 RID: 217
		Private mCmdSQL As SqlCommand

		' Token: 0x040000DA RID: 218
		Private mParSQL As SqlParameter()

		' Token: 0x040000DB RID: 219
		<AccessedThroughProperty("mDa")>
		Private _mDa As SqlDataAdapter

		' Token: 0x040000DC RID: 220
		Private mCnSQL As SqlConnection
	End Class
End Namespace
