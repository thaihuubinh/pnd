﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200033E RID: 830
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptSDBDBAL
		Inherits Component
		Implements ICachedReport

		' Token: 0x060072CC RID: 29388 RVA: 0x0001474D File Offset: 0x0001294D
		Public Sub New()
			CachedrptSDBDBAL.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17003045 RID: 12357
		' (get) Token: 0x060072CD RID: 29389 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060072CE RID: 29390 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17003046 RID: 12358
		' (get) Token: 0x060072CF RID: 29391 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060072D0 RID: 29392 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17003047 RID: 12359
		' (get) Token: 0x060072D1 RID: 29393 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060072D2 RID: 29394 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x060072D3 RID: 29395 RVA: 0x004DFA04 File Offset: 0x004DDC04
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptSDBDBAL() With { .Site = Me.Site }
		End Function

		' Token: 0x060072D4 RID: 29396 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002936 RID: 10550
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
