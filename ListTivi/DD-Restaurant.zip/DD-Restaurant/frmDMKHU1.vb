﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000055 RID: 85
	<DesignerGenerated()>
	Public Partial Class frmDMKHU1
		Inherits Form

		' Token: 0x06001974 RID: 6516 RVA: 0x0013BBD4 File Offset: 0x00139DD4
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMKHU1_Activated
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMKHU1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMKHU1_Load
			frmDMKHU1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd = False
			Me.mBlnOK = False
			Me.mBlnMultiSel = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x170008C4 RID: 2244
		' (get) Token: 0x06001977 RID: 6519 RVA: 0x0013D200 File Offset: 0x0013B400
		' (set) Token: 0x06001978 RID: 6520 RVA: 0x00005B30 File Offset: 0x00003D30
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x170008C5 RID: 2245
		' (get) Token: 0x06001979 RID: 6521 RVA: 0x0013D218 File Offset: 0x0013B418
		' (set) Token: 0x0600197A RID: 6522 RVA: 0x0013D230 File Offset: 0x0013B430
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x170008C6 RID: 2246
		' (get) Token: 0x0600197B RID: 6523 RVA: 0x0013D29C File Offset: 0x0013B49C
		' (set) Token: 0x0600197C RID: 6524 RVA: 0x0013D2B4 File Offset: 0x0013B4B4
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170008C7 RID: 2247
		' (get) Token: 0x0600197D RID: 6525 RVA: 0x0013D320 File Offset: 0x0013B520
		' (set) Token: 0x0600197E RID: 6526 RVA: 0x0013D338 File Offset: 0x0013B538
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x170008C8 RID: 2248
		' (get) Token: 0x0600197F RID: 6527 RVA: 0x0013D3A4 File Offset: 0x0013B5A4
		' (set) Token: 0x06001980 RID: 6528 RVA: 0x0013D3BC File Offset: 0x0013B5BC
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x170008C9 RID: 2249
		' (get) Token: 0x06001981 RID: 6529 RVA: 0x0013D428 File Offset: 0x0013B628
		' (set) Token: 0x06001982 RID: 6530 RVA: 0x0013D440 File Offset: 0x0013B640
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170008CA RID: 2250
		' (get) Token: 0x06001983 RID: 6531 RVA: 0x0013D4AC File Offset: 0x0013B6AC
		' (set) Token: 0x06001984 RID: 6532 RVA: 0x0013D4C4 File Offset: 0x0013B6C4
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x170008CB RID: 2251
		' (get) Token: 0x06001985 RID: 6533 RVA: 0x0013D530 File Offset: 0x0013B730
		' (set) Token: 0x06001986 RID: 6534 RVA: 0x0013D548 File Offset: 0x0013B748
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170008CC RID: 2252
		' (get) Token: 0x06001987 RID: 6535 RVA: 0x0013D5B4 File Offset: 0x0013B7B4
		' (set) Token: 0x06001988 RID: 6536 RVA: 0x00005B3A File Offset: 0x00003D3A
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x170008CD RID: 2253
		' (get) Token: 0x06001989 RID: 6537 RVA: 0x0013D5CC File Offset: 0x0013B7CC
		' (set) Token: 0x0600198A RID: 6538 RVA: 0x0013D5E4 File Offset: 0x0013B7E4
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x170008CE RID: 2254
		' (get) Token: 0x0600198B RID: 6539 RVA: 0x0013D650 File Offset: 0x0013B850
		' (set) Token: 0x0600198C RID: 6540 RVA: 0x0013D668 File Offset: 0x0013B868
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x170008CF RID: 2255
		' (get) Token: 0x0600198D RID: 6541 RVA: 0x0013D6D4 File Offset: 0x0013B8D4
		' (set) Token: 0x0600198E RID: 6542 RVA: 0x0013D6EC File Offset: 0x0013B8EC
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170008D0 RID: 2256
		' (get) Token: 0x0600198F RID: 6543 RVA: 0x0013D758 File Offset: 0x0013B958
		' (set) Token: 0x06001990 RID: 6544 RVA: 0x00005B44 File Offset: 0x00003D44
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170008D1 RID: 2257
		' (get) Token: 0x06001991 RID: 6545 RVA: 0x0013D770 File Offset: 0x0013B970
		' (set) Token: 0x06001992 RID: 6546 RVA: 0x0013D788 File Offset: 0x0013B988
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x170008D2 RID: 2258
		' (get) Token: 0x06001993 RID: 6547 RVA: 0x0013D7F4 File Offset: 0x0013B9F4
		' (set) Token: 0x06001994 RID: 6548 RVA: 0x0013D80C File Offset: 0x0013BA0C
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x170008D3 RID: 2259
		' (get) Token: 0x06001995 RID: 6549 RVA: 0x0013D878 File Offset: 0x0013BA78
		' (set) Token: 0x06001996 RID: 6550 RVA: 0x0013D890 File Offset: 0x0013BA90
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170008D4 RID: 2260
		' (get) Token: 0x06001997 RID: 6551 RVA: 0x0013D8FC File Offset: 0x0013BAFC
		' (set) Token: 0x06001998 RID: 6552 RVA: 0x0013D914 File Offset: 0x0013BB14
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x170008D5 RID: 2261
		' (get) Token: 0x06001999 RID: 6553 RVA: 0x0013D980 File Offset: 0x0013BB80
		' (set) Token: 0x0600199A RID: 6554 RVA: 0x0013D998 File Offset: 0x0013BB98
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x170008D6 RID: 2262
		' (get) Token: 0x0600199B RID: 6555 RVA: 0x0013DA04 File Offset: 0x0013BC04
		' (set) Token: 0x0600199C RID: 6556 RVA: 0x00005B4E File Offset: 0x00003D4E
		Friend Overridable Property lblMANH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMANH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMANH = value
			End Set
		End Property

		' Token: 0x170008D7 RID: 2263
		' (get) Token: 0x0600199D RID: 6557 RVA: 0x0013DA1C File Offset: 0x0013BC1C
		' (set) Token: 0x0600199E RID: 6558 RVA: 0x00005B58 File Offset: 0x00003D58
		Friend Overridable Property txtOBJNAMEKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAMEKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAMEKH = value
			End Set
		End Property

		' Token: 0x170008D8 RID: 2264
		' (get) Token: 0x0600199F RID: 6559 RVA: 0x0013DA34 File Offset: 0x0013BC34
		' (set) Token: 0x060019A0 RID: 6560 RVA: 0x0013DA4C File Offset: 0x0013BC4C
		Friend Overridable Property btnSelectKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelectKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelectKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelectKH.Click, AddressOf Me.btnSelectKH_Click
				End If
				Me._btnSelectKH = value
				flag = Me._btnSelectKH IsNot Nothing
				If flag Then
					AddHandler Me._btnSelectKH.Click, AddressOf Me.btnSelectKH_Click
				End If
			End Set
		End Property

		' Token: 0x170008D9 RID: 2265
		' (get) Token: 0x060019A1 RID: 6561 RVA: 0x0013DAB8 File Offset: 0x0013BCB8
		' (set) Token: 0x060019A2 RID: 6562 RVA: 0x0013DAD0 File Offset: 0x0013BCD0
		Friend Overridable Property txtOBJIDKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJIDKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJIDKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJIDKH.TextChanged, AddressOf Me.txtOBJIDKH_TextChanged
				End If
				Me._txtOBJIDKH = value
				flag = Me._txtOBJIDKH IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJIDKH.TextChanged, AddressOf Me.txtOBJIDKH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170008DA RID: 2266
		' (get) Token: 0x060019A3 RID: 6563 RVA: 0x0013DB3C File Offset: 0x0013BD3C
		' (set) Token: 0x060019A4 RID: 6564 RVA: 0x0013DB54 File Offset: 0x0013BD54
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170008DB RID: 2267
		' (get) Token: 0x060019A5 RID: 6565 RVA: 0x0013DBC0 File Offset: 0x0013BDC0
		' (set) Token: 0x060019A6 RID: 6566 RVA: 0x00005B62 File Offset: 0x00003D62
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170008DC RID: 2268
		' (get) Token: 0x060019A7 RID: 6567 RVA: 0x0013DBD8 File Offset: 0x0013BDD8
		' (set) Token: 0x060019A8 RID: 6568 RVA: 0x0013DBF0 File Offset: 0x0013BDF0
		Friend Overridable Property chkCheckAll As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkCheckAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkCheckAll IsNot Nothing
				If flag Then
					RemoveHandler Me._chkCheckAll.CheckedChanged, AddressOf Me.CheckBox1_CheckedChanged
				End If
				Me._chkCheckAll = value
				flag = Me._chkCheckAll IsNot Nothing
				If flag Then
					AddHandler Me._chkCheckAll.CheckedChanged, AddressOf Me.CheckBox1_CheckedChanged
				End If
			End Set
		End Property

		' Token: 0x170008DD RID: 2269
		' (get) Token: 0x060019A9 RID: 6569 RVA: 0x0013DC5C File Offset: 0x0013BE5C
		' (set) Token: 0x060019AA RID: 6570 RVA: 0x0013DC74 File Offset: 0x0013BE74
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170008DE RID: 2270
		' (get) Token: 0x060019AB RID: 6571 RVA: 0x0013DCE0 File Offset: 0x0013BEE0
		' (set) Token: 0x060019AC RID: 6572 RVA: 0x00005B6C File Offset: 0x00003D6C
		Public Property pBlnMultiSel As Boolean
			Get
				Return Me.mBlnMultiSel
			End Get
			Set(value As Boolean)
				Me.mBlnMultiSel = value
			End Set
		End Property

		' Token: 0x170008DF RID: 2271
		' (get) Token: 0x060019AD RID: 6573 RVA: 0x0013DCF8 File Offset: 0x0013BEF8
		' (set) Token: 0x060019AE RID: 6574 RVA: 0x00005B77 File Offset: 0x00003D77
		Public Property pBlnOK As Boolean
			Get
				Return Me.mBlnOK
			End Get
			Set(value As Boolean)
				Me.mBlnOK = value
			End Set
		End Property

		' Token: 0x170008E0 RID: 2272
		' (get) Token: 0x060019AF RID: 6575 RVA: 0x0013DD10 File Offset: 0x0013BF10
		' (set) Token: 0x060019B0 RID: 6576 RVA: 0x00005B82 File Offset: 0x00003D82
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x170008E1 RID: 2273
		' (get) Token: 0x060019B1 RID: 6577 RVA: 0x0013DD28 File Offset: 0x0013BF28
		' (set) Token: 0x060019B2 RID: 6578 RVA: 0x00005B8D File Offset: 0x00003D8D
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x170008E2 RID: 2274
		' (get) Token: 0x060019B3 RID: 6579 RVA: 0x0013DD40 File Offset: 0x0013BF40
		' (set) Token: 0x060019B4 RID: 6580 RVA: 0x00005B98 File Offset: 0x00003D98
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060019B5 RID: 6581 RVA: 0x0013DD58 File Offset: 0x0013BF58
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData("OBJID", Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019B6 RID: 6582 RVA: 0x0013DE2C File Offset: 0x0013C02C
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData("OBJID", Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019B7 RID: 6583 RVA: 0x0013DF20 File Offset: 0x0013C120
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData("OBJID", Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019B8 RID: 6584 RVA: 0x0013E008 File Offset: 0x0013C208
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData("OBJID", Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019B9 RID: 6585 RVA: 0x0013E0D0 File Offset: 0x0013C2D0
		Private Sub btnSelectKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKH As frmDMKH1 = New frmDMKH1()
				frmDMKH.pBytOpen_From_Menu = 7
				frmDMKH.ShowDialog()
				Me.txtOBJIDKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJID, "", False) = 0, Me.txtOBJIDKH.Text, frmDMKH.pStrOBJID))
				Me.txtOBJNAMEKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJNAME, "", False) = 0, Me.txtOBJNAMEKH.Text, frmDMKH.pStrOBJNAME))
				frmDMKH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelectKH_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019BA RID: 6586 RVA: 0x0013E1F4 File Offset: 0x0013C3F4
		Private Sub txtOBJIDKH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKH Is Nothing
				If Not flag Then
					Me.btnCancelFilter.Visible = False
					array(0) = Me.mclsTbDMKH.Columns("OBJID")
					Me.mclsTbDMKH.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKH.Rows.Find(Strings.Trim(Me.txtOBJIDKH.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.btnFind.Enabled = False
						Me.txtOBJNAMEKH.Text = dataRow("objname").ToString()
						Me.mbdsSource.Filter = "MAKH like '" + Strings.Replace(Strings.Trim(Me.txtOBJIDKH.Text), "'", "''", 1, -1, CompareMethod.Binary) + "'"
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						Me.txtOBJNAMEKH.Text = ""
						Me.mbdsSource.RemoveFilter()
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJIDKH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019BB RID: 6587 RVA: 0x0013E3C8 File Offset: 0x0013C5C8
		Private Sub frmDMKHU1_Activated(sender As Object, e As EventArgs)
			Try
				Me.txtOBJIDKH_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMKHU1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019BC RID: 6588 RVA: 0x0013E468 File Offset: 0x0013C668
		Private Sub frmDMKHU1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMKHU1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019BD RID: 6589 RVA: 0x0013E500 File Offset: 0x0013C700
		Private Sub frmDMKHU1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Filter()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHHLIM1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019BE RID: 6590 RVA: 0x0013E64C File Offset: 0x0013C84C
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019BF RID: 6591 RVA: 0x0013E754 File Offset: 0x0013C954
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = mdlVariable.gfrmSaleMode IsNot Nothing AndAlso mdlVariable.gfrmSaleMode.pdsTbDataKhu IsNot Nothing
				If flag Then
					Dim array As SqlParameter() = New SqlParameter(1) {}
					array(0) = New SqlParameter("@nchMAKH", "")
					Dim gfrmSaleMode As frmSaleMode = mdlVariable.gfrmSaleMode
					Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
					Dim array2 As SqlParameter() = array
					Dim text As String = "SP_FRMTABLEPLAN_GET_DMKHU"
					Dim num As Integer = 0
					gfrmSaleMode.pdsTbDataKhu = New clsConnect(gStrConISDANHMUC, array2, text, num)
				End If
				Me.mBlnOK = False
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019C0 RID: 6592 RVA: 0x0013E85C File Offset: 0x0013CA5C
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMKHU As frmDMKHU2 = New frmDMKHU2()
			Try
				frmDMKHU.pbytFromStatus = 1
				frmDMKHU.cmbLevelPrice.SelectedIndex = 0
				frmDMKHU.ShowDialog()
				Dim flag As Boolean = frmDMKHU.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMKHU.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKHU.Dispose()
			End Try
		End Sub

		' Token: 0x060019C1 RID: 6593 RVA: 0x0013E9CC File Offset: 0x0013CBCC
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMKHU As frmDMKHU2 = New frmDMKHU2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMKHU2 As frmDMKHU2 = frmDMKHU
				frmDMKHU2.pbytFromStatus = 2
				frmDMKHU2.txtMAKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("objid").Value, ""))
				frmDMKHU2.txtTENKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("objname").Value, ""))
				frmDMKHU2.pStrMAKH = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("makh").Value, ""))
				frmDMKHU2.txtGHICHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("remark").Value, ""))
				frmDMKHU2.cmbLevelPrice.SelectedIndex = Conversions.ToInteger(Me.dgvData.CurrentRow.Cells("LevelPrice").Value)
				frmDMKHU2.pbytStatusClose = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("STATUSCLOSE").Value)
				frmDMKHU2.txtPERSERVICE.Text = Conversions.ToString(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("PERSERVICE").Value)))
				frmDMKHU2.txtPERVAT.Text = Conversions.ToString(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("PERVAT").Value)))
				frmDMKHU2.chkLOnlyCash.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LONLYCASH").Value)
				frmDMKHU2.chkLNotVAT.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LNOTVAT").Value)
				frmDMKHU.ShowDialog()
				Dim flag As Boolean = frmDMKHU.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("objid", frmDMKHU.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAddDefault_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMKHU.Dispose()
			End Try
		End Sub

		' Token: 0x060019C2 RID: 6594 RVA: 0x0013ED88 File Offset: 0x0013CF88
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMKHU As frmDMKHU2 = New frmDMKHU2()
			Try
				Dim frmDMKHU2 As frmDMKHU2 = frmDMKHU
				frmDMKHU2.pbytFromStatus = 3
				frmDMKHU2.txtMAKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMKHU2.txtTENKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMKHU2.pStrMAKH = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMKHU2.txtGHICHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMKHU2.txtMAKHU.[ReadOnly] = True
				frmDMKHU2.cmbLevelPrice.SelectedIndex = Conversions.ToInteger(Me.dgvData.CurrentRow.Cells("LevelPrice").Value)
				frmDMKHU2.pbytStatusClose = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("STATUSCLOSE").Value)
				frmDMKHU2.txtPERSERVICE.Text = Conversions.ToString(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("PERSERVICE").Value)))
				frmDMKHU2.txtPERVAT.Text = Conversions.ToString(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("PERVAT").Value)))
				frmDMKHU2.chkLOnlyCash.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LONLYCASH").Value)
				frmDMKHU2.chkLNotVAT.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LNOTVAT").Value)
				frmDMKHU.ShowDialog()
				Dim flag As Boolean = frmDMKHU.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("objid", frmDMKHU.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKHU.Dispose()
			End Try
		End Sub

		' Token: 0x060019C3 RID: 6595 RVA: 0x0013F108 File Offset: 0x0013D308
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMKHU As frmDMKHU2 = New frmDMKHU2()
			Try
				Dim frmDMKHU2 As frmDMKHU2 = frmDMKHU
				frmDMKHU2.pbytFromStatus = 4
				frmDMKHU2.txtMAKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("objid").Value, ""))
				frmDMKHU2.txtTENKHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("objname").Value, ""))
				frmDMKHU2.pStrMAKH = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("makh").Value, ""))
				frmDMKHU2.txtGHICHU.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("remark").Value, ""))
				frmDMKHU2.txtMAKHU.[ReadOnly] = True
				frmDMKHU2.cmbLevelPrice.SelectedIndex = Conversions.ToInteger(Me.dgvData.CurrentRow.Cells("LevelPrice").Value)
				frmDMKHU2.pbytStatusClose = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("STATUSCLOSE").Value)
				frmDMKHU2.txtPERSERVICE.Text = Conversions.ToString(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("PERSERVICE").Value)))
				frmDMKHU2.txtPERVAT.Text = Conversions.ToString(Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("PERVAT").Value)))
				frmDMKHU2.chkLOnlyCash.Checked = Conversion.Val(RuntimeHelpers.GetObjectValue(Me.dgvData.CurrentRow.Cells("LONLYCASH").Value)) <> 0.0
				frmDMKHU2.chkLNotVAT.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LNOTVAT").Value)
				frmDMKHU.ShowDialog()
				Dim flag As Boolean = frmDMKHU.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKHU.Dispose()
			End Try
		End Sub

		' Token: 0x060019C4 RID: 6596 RVA: 0x0013F478 File Offset: 0x0013D678
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMKHU As frmDMKHU2 = New frmDMKHU2()
			Try
				frmDMKHU.pbytFromStatus = 6
				frmDMKHU.ShowDialog()
				Dim flag As Boolean = frmDMKHU.pbytSuccess = 0
				If flag Then
					frmDMKHU.Dispose()
				Else
					Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Trim(Me.txtOBJIDKH.Text), "", False) <> 0, " AND MAKH ='" + Strings.Replace(Strings.Trim(Me.txtOBJIDKH.Text), "'", "''", 1, -1, CompareMethod.Binary) + "'", ""))
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMKHU.pStrFilter + text, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMKHU.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("objid", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("objid")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKHU.Dispose()
			End Try
		End Sub

		' Token: 0x060019C5 RID: 6597 RVA: 0x0013F6D8 File Offset: 0x0013D8D8
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMKHU As frmDMKHU2 = New frmDMKHU2()
			Try
				Me.btnFindNext.Visible = False
				frmDMKHU.pbytFromStatus = 5
				frmDMKHU.ShowDialog()
				Dim flag As Boolean = frmDMKHU.pbytSuccess = 0
				If Not flag Then
					Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Trim(Me.txtOBJIDKH.Text), "", False) <> 0, " AND MAKH ='" + Strings.Replace(Strings.Trim(Me.txtOBJIDKH.Text), "'", "''", 1, -1, CompareMethod.Binary) + "'", ""))
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMKHU.pStrFilter + text
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKHU.Dispose()
			End Try
		End Sub

		' Token: 0x060019C6 RID: 6598 RVA: 0x0013F864 File Offset: 0x0013DA64
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMKHU As frmDMKHU2 = New frmDMKHU2()
			Try
				Dim text As String = Conversions.ToString(Interaction.IIf(Operators.CompareString(Strings.Trim(Me.txtOBJIDKH.Text), "", False) <> 0, "MAKH ='" + Strings.Replace(Strings.Trim(Me.txtOBJIDKH.Text), "'", "''", 1, -1, CompareMethod.Binary) + "'", ""))
				Me.mbdsSource.RemoveFilter()
				Dim flag As Boolean = Operators.CompareString(text, "", False) <> 0
				If flag Then
					Me.mbdsSource.Filter = text
				End If
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMKHU.Dispose()
			End Try
		End Sub

		' Token: 0x060019C7 RID: 6599 RVA: 0x0013F9CC File Offset: 0x0013DBCC
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("objid", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("objid")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x060019C8 RID: 6600 RVA: 0x0013FB48 File Offset: 0x0013DD48
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fPrintDMKHU(Strings.Trim(Me.txtOBJIDKH.Text))
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019C9 RID: 6601 RVA: 0x0013FBF0 File Offset: 0x0013DDF0
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Me.mStrOBJID = ""
				Me.mStrOBJNAME = ""
				Dim flag As Boolean = Me.mBlnMultiSel
				Dim flag2 As Boolean
				If flag Then
					Try
						For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
							Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
							flag2 = Conversions.ToBoolean(dataGridViewRow.Cells("chkSelect").Value)
							If flag2 Then
								Me.mStrOBJID = Me.mStrOBJID + dataGridViewRow.Cells("OBJID").Value.ToString().Trim() + ","
								Me.mStrOBJNAME = Me.mStrOBJNAME + dataGridViewRow.Cells("OBJNAME").Value.ToString().Trim() + ","
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						flag2 = TypeOf enumerator Is IDisposable
						If flag2 Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
				Else
					Me.mStrOBJID = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
					Me.mStrOBJNAME = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJNAME").Value)
				End If
				flag2 = Me.mStrOBJID.Trim().EndsWith(",")
				If flag2 Then
					Me.mStrOBJID = Me.mStrOBJID.Trim().Substring(0, Me.mStrOBJID.Trim().Length - 1)
					Me.mStrOBJNAME = Me.mStrOBJNAME.Trim().Substring(0, Me.mStrOBJNAME.Trim().Length - 1)
				End If
				Me.mBlnOK = True
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019CA RID: 6602 RVA: 0x0013FE8C File Offset: 0x0013E08C
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019CB RID: 6603 RVA: 0x0013FF3C File Offset: 0x0013E13C
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("chkSelect").Visible = Me.mBlnMultiSel
				Me.chkCheckAll.Visible = Me.mBlnMultiSel
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 130
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJID").[ReadOnly] = True
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 400
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").[ReadOnly] = True
				dgvData.Columns("LEVELPRICE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(28))
				dgvData.Columns("LEVELPRICE").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("LEVELPRICE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("LEVELPRICE").[ReadOnly] = True
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("REMARK").Width = Me.Width - 665 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").[ReadOnly] = True
				dgvData.Columns("MAKH").Visible = False
				dgvData.Columns("STATUSCLOSE").Visible = False
				dgvData.Columns("PERSERVICE").Visible = False
				dgvData.Columns("PERVAT").Visible = False
				dgvData.Columns("LONLYCASH").Visible = False
				dgvData.Columns("LNOTVAT").Visible = False
				dgvData.Focus()
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060019CC RID: 6604 RVA: 0x00140320 File Offset: 0x0013E520
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060019CD RID: 6605 RVA: 0x001404A0 File Offset: 0x0013E6A0
		Private Function fGetData_4Filter() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKH = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = Me.mclsTbDMKH IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Filter ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060019CE RID: 6606 RVA: 0x0014055C File Offset: 0x0013E75C
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKHU_GET_ALL_DATA_DMKHU", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.dgvData.Columns.Clear()
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					Dim dataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn = New DataGridViewCheckBoxColumn()
					dataGridViewCheckBoxColumn.[ReadOnly] = False
					dataGridViewCheckBoxColumn.Name = "chkSelect"
					dataGridViewCheckBoxColumn.HeaderText = Me.mArrStrFrmMess(29)
					Me.dgvData.Columns.Insert(0, dataGridViewCheckBoxColumn)
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060019CF RID: 6607 RVA: 0x001406B8 File Offset: 0x0013E8B8
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Me.txtOBJIDKH.Text = mdlVariable.gStrStockCode
				Dim flag As Boolean = Operators.CompareString(mdlVariable.gStrStockCode, "", False) <> 0
				If flag Then
					Me.txtOBJIDKH.[ReadOnly] = True
					Me.txtOBJIDKH.BackColor = Me.txtOBJNAMEKH.BackColor
					Me.btnSelectKH.Enabled = False
				End If
				flag = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060019D0 RID: 6608 RVA: 0x00140814 File Offset: 0x0013EA14
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2080200000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060019D1 RID: 6609 RVA: 0x00140920 File Offset: 0x0013EB20
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mclsTbDMKH.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060019D2 RID: 6610 RVA: 0x001409D8 File Offset: 0x0013EBD8
		Private Function fPrintDMKHU(pstrMAKH As String) As Byte
			Dim rptDMKHU As rptDMKHU = New rptDMKHU()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMKHU, "")
				Dim text As String = "2080200000"
				mdlReport.gsSetOfficeReport(rptDMKHU, text)
				mdlReport.gsSetFontReport(rptDMKHU)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAKH"
				array(0).Value = pstrMAKH
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMKHU_GET_DATA_DMKHU", num)
				Dim num2 As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag As Boolean = num = 1
				If flag Then
					rptDMKHU.SetDataSource(clsConnect)
					rptDMKHU.DataDefinition.FormulaFields("fPluCode").Text = "{dtReport.OBJID}"
					rptDMKHU.DataDefinition.FormulaFields("fPluName").Text = "{dtReport.OBJNAME}"
					rptDMKHU.DataDefinition.FormulaFields("fGroupCode").Text = "{dtReport.MAKH}"
					rptDMKHU.DataDefinition.FormulaFields("fMaxQty").Text = "{dtReport.REMARK}"
					rptDMKHU.DataDefinition.FormulaFields("fStockName").Text = "{dtReport.TENKH}"
					mdlReport.gsSetTextReport(rptDMKHU, "RPTDMKHU")
					MyProject.Forms.frmReport.pSource = rptDMKHU
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMKHU.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMKHU.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMKHU.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMKHU " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMKHU.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060019D3 RID: 6611 RVA: 0x00140CAC File Offset: 0x0013EEAC
		Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.chkCheckAll.Checked
			If flag Then
				Try
					For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
						Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
						dataGridViewRow.Cells("chkSelect").Value = True
					Next
				Finally
					Dim enumerator As IEnumerator
					flag = TypeOf enumerator Is IDisposable
					If flag Then
						TryCast(enumerator, IDisposable).Dispose()
					End If
				End Try
			Else
				Try
					For Each obj2 As Object In CType(Me.dgvData.Rows, IEnumerable)
						Dim dataGridViewRow2 As DataGridViewRow = CType(obj2, DataGridViewRow)
						dataGridViewRow2.Cells("chkSelect").Value = False
					Next
				Finally
					Dim enumerator2 As IEnumerator
					flag = TypeOf enumerator2 Is IDisposable
					If flag Then
						TryCast(enumerator2, IDisposable).Dispose()
					End If
				End Try
			End If
		End Sub

		' Token: 0x04000A84 RID: 2692
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000A86 RID: 2694
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000A87 RID: 2695
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000A88 RID: 2696
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000A89 RID: 2697
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000A8A RID: 2698
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000A8B RID: 2699
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000A8C RID: 2700
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000A8D RID: 2701
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000A8E RID: 2702
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000A8F RID: 2703
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000A90 RID: 2704
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000A91 RID: 2705
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000A92 RID: 2706
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000A93 RID: 2707
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000A94 RID: 2708
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000A95 RID: 2709
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000A96 RID: 2710
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000A97 RID: 2711
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000A98 RID: 2712
		<AccessedThroughProperty("lblMANH")>
		Private _lblMANH As Label

		' Token: 0x04000A99 RID: 2713
		<AccessedThroughProperty("txtOBJNAMEKH")>
		Private _txtOBJNAMEKH As TextBox

		' Token: 0x04000A9A RID: 2714
		<AccessedThroughProperty("btnSelectKH")>
		Private _btnSelectKH As Button

		' Token: 0x04000A9B RID: 2715
		<AccessedThroughProperty("txtOBJIDKH")>
		Private _txtOBJIDKH As TextBox

		' Token: 0x04000A9C RID: 2716
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000A9D RID: 2717
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000A9E RID: 2718
		<AccessedThroughProperty("chkCheckAll")>
		Private _chkCheckAll As CheckBox

		' Token: 0x04000A9F RID: 2719
		Private mArrStrFrmMess As String()

		' Token: 0x04000AA0 RID: 2720
		Private mStrOBJID As String

		' Token: 0x04000AA1 RID: 2721
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000AA2 RID: 2722
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000AA3 RID: 2723
		Private marrDrFind As DataRow()

		' Token: 0x04000AA4 RID: 2724
		Private mintFindLastPos As Integer

		' Token: 0x04000AA5 RID: 2725
		Private mblnAutoAdd As Boolean

		' Token: 0x04000AA6 RID: 2726
		Private mbytLen_OBJID As Byte

		' Token: 0x04000AA7 RID: 2727
		Private mclsTbDMKH As clsConnect

		' Token: 0x04000AA8 RID: 2728
		Private mStrOBJNAME As String

		' Token: 0x04000AA9 RID: 2729
		Private mBlnOK As Boolean

		' Token: 0x04000AAA RID: 2730
		Private mBlnMultiSel As Boolean
	End Class
End Namespace
