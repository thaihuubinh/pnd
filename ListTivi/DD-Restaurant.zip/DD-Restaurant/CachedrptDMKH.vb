﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200015E RID: 350
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptDMKH
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005A04 RID: 23044 RVA: 0x0000FA6D File Offset: 0x0000DC6D
		Public Sub New()
			CachedrptDMKH.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170020DD RID: 8413
		' (get) Token: 0x06005A05 RID: 23045 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005A06 RID: 23046 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170020DE RID: 8414
		' (get) Token: 0x06005A07 RID: 23047 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005A08 RID: 23048 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170020DF RID: 8415
		' (get) Token: 0x06005A09 RID: 23049 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005A0A RID: 23050 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005A0B RID: 23051 RVA: 0x004DB720 File Offset: 0x004D9920
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptDMKH() With { .Site = Me.Site }
		End Function

		' Token: 0x06005A0C RID: 23052 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002756 RID: 10070
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
