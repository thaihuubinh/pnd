﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020002D2 RID: 722
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBCPrintReceiptK58Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06006AB9 RID: 27321 RVA: 0x00013601 File Offset: 0x00011801
		Public Sub New()
			CachedrptRepBCPrintReceiptK58Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002A4E RID: 10830
		' (get) Token: 0x06006ABA RID: 27322 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06006ABB RID: 27323 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002A4F RID: 10831
		' (get) Token: 0x06006ABC RID: 27324 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06006ABD RID: 27325 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002A50 RID: 10832
		' (get) Token: 0x06006ABE RID: 27326 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06006ABF RID: 27327 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06006AC0 RID: 27328 RVA: 0x004DEB64 File Offset: 0x004DCD64
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBCPrintReceiptK58Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x06006AC1 RID: 27329 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040028CA RID: 10442
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
