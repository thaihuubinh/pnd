﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000035 RID: 53
	<DesignerGenerated()>
	Public Partial Class frmDMAUTOPRICE2
		Inherits Form

		' Token: 0x06000B5A RID: 2906 RVA: 0x00085750 File Offset: 0x00083950
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMAUTOPRICE2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMAUTOPRICE2_Load
			frmDMAUTOPRICE2.__ENCList.Add(New WeakReference(Me))
			Me.mstrKHO = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000429 RID: 1065
		' (get) Token: 0x06000B5D RID: 2909 RVA: 0x00087184 File Offset: 0x00085384
		' (set) Token: 0x06000B5E RID: 2910 RVA: 0x00003F7A File Offset: 0x0000217A
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x1700042A RID: 1066
		' (get) Token: 0x06000B5F RID: 2911 RVA: 0x0008719C File Offset: 0x0008539C
		' (set) Token: 0x06000B60 RID: 2912 RVA: 0x000871B4 File Offset: 0x000853B4
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x1700042B RID: 1067
		' (get) Token: 0x06000B61 RID: 2913 RVA: 0x00087220 File Offset: 0x00085420
		' (set) Token: 0x06000B62 RID: 2914 RVA: 0x00003F84 File Offset: 0x00002184
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x1700042C RID: 1068
		' (get) Token: 0x06000B63 RID: 2915 RVA: 0x00087238 File Offset: 0x00085438
		' (set) Token: 0x06000B64 RID: 2916 RVA: 0x00087250 File Offset: 0x00085450
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x1700042D RID: 1069
		' (get) Token: 0x06000B65 RID: 2917 RVA: 0x000872BC File Offset: 0x000854BC
		' (set) Token: 0x06000B66 RID: 2918 RVA: 0x000872D4 File Offset: 0x000854D4
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x1700042E RID: 1070
		' (get) Token: 0x06000B67 RID: 2919 RVA: 0x00087340 File Offset: 0x00085540
		' (set) Token: 0x06000B68 RID: 2920 RVA: 0x00087358 File Offset: 0x00085558
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x1700042F RID: 1071
		' (get) Token: 0x06000B69 RID: 2921 RVA: 0x000873C4 File Offset: 0x000855C4
		' (set) Token: 0x06000B6A RID: 2922 RVA: 0x00003F8E File Offset: 0x0000218E
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x17000430 RID: 1072
		' (get) Token: 0x06000B6B RID: 2923 RVA: 0x000873DC File Offset: 0x000855DC
		' (set) Token: 0x06000B6C RID: 2924 RVA: 0x000873F4 File Offset: 0x000855F4
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000431 RID: 1073
		' (get) Token: 0x06000B6D RID: 2925 RVA: 0x00087460 File Offset: 0x00085660
		' (set) Token: 0x06000B6E RID: 2926 RVA: 0x00087478 File Offset: 0x00085678
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000432 RID: 1074
		' (get) Token: 0x06000B6F RID: 2927 RVA: 0x00087514 File Offset: 0x00085714
		' (set) Token: 0x06000B70 RID: 2928 RVA: 0x00003F98 File Offset: 0x00002198
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x17000433 RID: 1075
		' (get) Token: 0x06000B71 RID: 2929 RVA: 0x0008752C File Offset: 0x0008572C
		' (set) Token: 0x06000B72 RID: 2930 RVA: 0x00003FA2 File Offset: 0x000021A2
		Friend Overridable Property lblFromDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFromDate = value
			End Set
		End Property

		' Token: 0x17000434 RID: 1076
		' (get) Token: 0x06000B73 RID: 2931 RVA: 0x00087544 File Offset: 0x00085744
		' (set) Token: 0x06000B74 RID: 2932 RVA: 0x0008755C File Offset: 0x0008575C
		Friend Overridable Property txtTENKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENKH.KeyPress, AddressOf Me.txtTENKH_KeyPress
					RemoveHandler Me._txtTENKH.GotFocus, AddressOf Me.txtTENKH_GotFocus
				End If
				Me._txtTENKH = value
				flag = Me._txtTENKH IsNot Nothing
				If flag Then
					AddHandler Me._txtTENKH.KeyPress, AddressOf Me.txtTENKH_KeyPress
					AddHandler Me._txtTENKH.GotFocus, AddressOf Me.txtTENKH_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000435 RID: 1077
		' (get) Token: 0x06000B75 RID: 2933 RVA: 0x000875F8 File Offset: 0x000857F8
		' (set) Token: 0x06000B76 RID: 2934 RVA: 0x00087610 File Offset: 0x00085810
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000436 RID: 1078
		' (get) Token: 0x06000B77 RID: 2935 RVA: 0x0008767C File Offset: 0x0008587C
		' (set) Token: 0x06000B78 RID: 2936 RVA: 0x00087694 File Offset: 0x00085894
		Friend Overridable Property txtMAKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKH.KeyPress, AddressOf Me.txtMAKH_KeyPress
					RemoveHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
				Me._txtMAKH = value
				flag = Me._txtMAKH IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKH.KeyPress, AddressOf Me.txtMAKH_KeyPress
					AddHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000437 RID: 1079
		' (get) Token: 0x06000B79 RID: 2937 RVA: 0x00087730 File Offset: 0x00085930
		' (set) Token: 0x06000B7A RID: 2938 RVA: 0x00003FAC File Offset: 0x000021AC
		Friend Overridable Property lblkHO As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblkHO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblkHO = value
			End Set
		End Property

		' Token: 0x17000438 RID: 1080
		' (get) Token: 0x06000B7B RID: 2939 RVA: 0x00087748 File Offset: 0x00085948
		' (set) Token: 0x06000B7C RID: 2940 RVA: 0x00003FB6 File Offset: 0x000021B6
		Friend Overridable Property lblToDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblToDate = value
			End Set
		End Property

		' Token: 0x17000439 RID: 1081
		' (get) Token: 0x06000B7D RID: 2941 RVA: 0x00087760 File Offset: 0x00085960
		' (set) Token: 0x06000B7E RID: 2942 RVA: 0x00003FC0 File Offset: 0x000021C0
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x1700043A RID: 1082
		' (get) Token: 0x06000B7F RID: 2943 RVA: 0x00087778 File Offset: 0x00085978
		' (set) Token: 0x06000B80 RID: 2944 RVA: 0x00003FCA File Offset: 0x000021CA
		Friend Overridable Property lblToTime As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblToTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblToTime = value
			End Set
		End Property

		' Token: 0x1700043B RID: 1083
		' (get) Token: 0x06000B81 RID: 2945 RVA: 0x00087790 File Offset: 0x00085990
		' (set) Token: 0x06000B82 RID: 2946 RVA: 0x00003FD4 File Offset: 0x000021D4
		Friend Overridable Property lblFromTime As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFromTime = value
			End Set
		End Property

		' Token: 0x1700043C RID: 1084
		' (get) Token: 0x06000B83 RID: 2947 RVA: 0x000877A8 File Offset: 0x000859A8
		' (set) Token: 0x06000B84 RID: 2948 RVA: 0x000877C0 File Offset: 0x000859C0
		Friend Overridable Property chkT2 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT2 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT2.KeyPress, AddressOf Me.chkT2_KeyPress
				End If
				Me._chkT2 = value
				flag = Me._chkT2 IsNot Nothing
				If flag Then
					AddHandler Me._chkT2.KeyPress, AddressOf Me.chkT2_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700043D RID: 1085
		' (get) Token: 0x06000B85 RID: 2949 RVA: 0x0008782C File Offset: 0x00085A2C
		' (set) Token: 0x06000B86 RID: 2950 RVA: 0x00087844 File Offset: 0x00085A44
		Friend Overridable Property chkT3 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT3 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT3.KeyPress, AddressOf Me.chkT3_KeyPress
				End If
				Me._chkT3 = value
				flag = Me._chkT3 IsNot Nothing
				If flag Then
					AddHandler Me._chkT3.KeyPress, AddressOf Me.chkT3_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700043E RID: 1086
		' (get) Token: 0x06000B87 RID: 2951 RVA: 0x000878B0 File Offset: 0x00085AB0
		' (set) Token: 0x06000B88 RID: 2952 RVA: 0x000878C8 File Offset: 0x00085AC8
		Friend Overridable Property chkT4 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT4 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT4.KeyPress, AddressOf Me.chkT4_KeyPress
				End If
				Me._chkT4 = value
				flag = Me._chkT4 IsNot Nothing
				If flag Then
					AddHandler Me._chkT4.KeyPress, AddressOf Me.chkT4_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700043F RID: 1087
		' (get) Token: 0x06000B89 RID: 2953 RVA: 0x00087934 File Offset: 0x00085B34
		' (set) Token: 0x06000B8A RID: 2954 RVA: 0x0008794C File Offset: 0x00085B4C
		Friend Overridable Property chkT5 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT5 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT5.KeyPress, AddressOf Me.chkT5_KeyPress
				End If
				Me._chkT5 = value
				flag = Me._chkT5 IsNot Nothing
				If flag Then
					AddHandler Me._chkT5.KeyPress, AddressOf Me.chkT5_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000440 RID: 1088
		' (get) Token: 0x06000B8B RID: 2955 RVA: 0x000879B8 File Offset: 0x00085BB8
		' (set) Token: 0x06000B8C RID: 2956 RVA: 0x000879D0 File Offset: 0x00085BD0
		Friend Overridable Property chkT6 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT6 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT6.KeyPress, AddressOf Me.chkT6_KeyPress
				End If
				Me._chkT6 = value
				flag = Me._chkT6 IsNot Nothing
				If flag Then
					AddHandler Me._chkT6.KeyPress, AddressOf Me.chkT6_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000441 RID: 1089
		' (get) Token: 0x06000B8D RID: 2957 RVA: 0x00087A3C File Offset: 0x00085C3C
		' (set) Token: 0x06000B8E RID: 2958 RVA: 0x00087A54 File Offset: 0x00085C54
		Friend Overridable Property chkT7 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT7 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT7.KeyPress, AddressOf Me.chkT7_KeyPress
				End If
				Me._chkT7 = value
				flag = Me._chkT7 IsNot Nothing
				If flag Then
					AddHandler Me._chkT7.KeyPress, AddressOf Me.chkT7_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000442 RID: 1090
		' (get) Token: 0x06000B8F RID: 2959 RVA: 0x00087AC0 File Offset: 0x00085CC0
		' (set) Token: 0x06000B90 RID: 2960 RVA: 0x00087AD8 File Offset: 0x00085CD8
		Friend Overridable Property chkCN As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkCN
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkCN IsNot Nothing
				If flag Then
					RemoveHandler Me._chkCN.KeyPress, AddressOf Me.chkCN_KeyPress
				End If
				Me._chkCN = value
				flag = Me._chkCN IsNot Nothing
				If flag Then
					AddHandler Me._chkCN.KeyPress, AddressOf Me.chkCN_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000443 RID: 1091
		' (get) Token: 0x06000B91 RID: 2961 RVA: 0x00087B44 File Offset: 0x00085D44
		' (set) Token: 0x06000B92 RID: 2962 RVA: 0x00087B5C File Offset: 0x00085D5C
		Friend Overridable Property mtxFromDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxFromDate IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxFromDate.KeyPress, AddressOf Me.mtxFromDate_KeyPress
				End If
				Me._mtxFromDate = value
				flag = Me._mtxFromDate IsNot Nothing
				If flag Then
					AddHandler Me._mtxFromDate.KeyPress, AddressOf Me.mtxFromDate_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000444 RID: 1092
		' (get) Token: 0x06000B93 RID: 2963 RVA: 0x00087BC8 File Offset: 0x00085DC8
		' (set) Token: 0x06000B94 RID: 2964 RVA: 0x00087BE0 File Offset: 0x00085DE0
		Friend Overridable Property mtxToDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxToDate IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxToDate.KeyPress, AddressOf Me.mtxToDate_KeyPress
				End If
				Me._mtxToDate = value
				flag = Me._mtxToDate IsNot Nothing
				If flag Then
					AddHandler Me._mtxToDate.KeyPress, AddressOf Me.mtxToDate_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000445 RID: 1093
		' (get) Token: 0x06000B95 RID: 2965 RVA: 0x00087C4C File Offset: 0x00085E4C
		' (set) Token: 0x06000B96 RID: 2966 RVA: 0x00087C64 File Offset: 0x00085E64
		Friend Overridable Property mtxFromTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxFromTime IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxFromTime.KeyPress, AddressOf Me.mtxFromTime_KeyPress
				End If
				Me._mtxFromTime = value
				flag = Me._mtxFromTime IsNot Nothing
				If flag Then
					AddHandler Me._mtxFromTime.KeyPress, AddressOf Me.mtxFromTime_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000446 RID: 1094
		' (get) Token: 0x06000B97 RID: 2967 RVA: 0x00087CD0 File Offset: 0x00085ED0
		' (set) Token: 0x06000B98 RID: 2968 RVA: 0x00087CE8 File Offset: 0x00085EE8
		Friend Overridable Property mtxToTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxToTime IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxToTime.KeyPress, AddressOf Me.mtxToTime_KeyPress
				End If
				Me._mtxToTime = value
				flag = Me._mtxToTime IsNot Nothing
				If flag Then
					AddHandler Me._mtxToTime.KeyPress, AddressOf Me.mtxToTime_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000447 RID: 1095
		' (get) Token: 0x06000B99 RID: 2969 RVA: 0x00087D54 File Offset: 0x00085F54
		' (set) Token: 0x06000B9A RID: 2970 RVA: 0x00003FDE File Offset: 0x000021DE
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000448 RID: 1096
		' (get) Token: 0x06000B9B RID: 2971 RVA: 0x00087D6C File Offset: 0x00085F6C
		' (set) Token: 0x06000B9C RID: 2972 RVA: 0x00003FE8 File Offset: 0x000021E8
		Friend Overridable Property txtTENKHU As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENKHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTENKHU = value
			End Set
		End Property

		' Token: 0x17000449 RID: 1097
		' (get) Token: 0x06000B9D RID: 2973 RVA: 0x00087D84 File Offset: 0x00085F84
		' (set) Token: 0x06000B9E RID: 2974 RVA: 0x00087D9C File Offset: 0x00085F9C
		Friend Overridable Property btnDMKHU As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDMKHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDMKHU IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDMKHU.Click, AddressOf Me.btnDMKHU_Click
				End If
				Me._btnDMKHU = value
				flag = Me._btnDMKHU IsNot Nothing
				If flag Then
					AddHandler Me._btnDMKHU.Click, AddressOf Me.btnDMKHU_Click
				End If
			End Set
		End Property

		' Token: 0x1700044A RID: 1098
		' (get) Token: 0x06000B9F RID: 2975 RVA: 0x00087E08 File Offset: 0x00086008
		' (set) Token: 0x06000BA0 RID: 2976 RVA: 0x00087E20 File Offset: 0x00086020
		Friend Overridable Property txtMAKHU As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKHU IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKHU.TextChanged, AddressOf Me.txtMAKHU_TextChanged
				End If
				Me._txtMAKHU = value
				flag = Me._txtMAKHU IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKHU.TextChanged, AddressOf Me.txtMAKHU_TextChanged
				End If
			End Set
		End Property

		' Token: 0x1700044B RID: 1099
		' (get) Token: 0x06000BA1 RID: 2977 RVA: 0x00087E8C File Offset: 0x0008608C
		' (set) Token: 0x06000BA2 RID: 2978 RVA: 0x00003FF2 File Offset: 0x000021F2
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x1700044C RID: 1100
		' (get) Token: 0x06000BA3 RID: 2979 RVA: 0x00087EA4 File Offset: 0x000860A4
		' (set) Token: 0x06000BA4 RID: 2980 RVA: 0x00003FFC File Offset: 0x000021FC
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x1700044D RID: 1101
		' (get) Token: 0x06000BA5 RID: 2981 RVA: 0x00087EBC File Offset: 0x000860BC
		' (set) Token: 0x06000BA6 RID: 2982 RVA: 0x00004007 File Offset: 0x00002207
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x1700044E RID: 1102
		' (get) Token: 0x06000BA7 RID: 2983 RVA: 0x00087ED4 File Offset: 0x000860D4
		' (set) Token: 0x06000BA8 RID: 2984 RVA: 0x00004012 File Offset: 0x00002212
		Public Property pStrKHO As String
			Get
				Return Me.mstrKHO
			End Get
			Set(value As String)
				Me.mstrKHO = value
			End Set
		End Property

		' Token: 0x1700044F RID: 1103
		' (get) Token: 0x06000BA9 RID: 2985 RVA: 0x00087EEC File Offset: 0x000860EC
		' (set) Token: 0x06000BAA RID: 2986 RVA: 0x0000401D File Offset: 0x0000221D
		Public Property pStrOBJID As String
			Get
				Return Me.mstrOBJID
			End Get
			Set(value As String)
				Me.mstrOBJID = value
			End Set
		End Property

		' Token: 0x17000450 RID: 1104
		' (get) Token: 0x06000BAB RID: 2987 RVA: 0x00087F04 File Offset: 0x00086104
		' (set) Token: 0x06000BAC RID: 2988 RVA: 0x00004028 File Offset: 0x00002228
		Public Property pStrHTKM As String
			Get
				Return Me.mstrHTKM
			End Get
			Set(value As String)
				Me.mstrHTKM = value
			End Set
		End Property

		' Token: 0x17000451 RID: 1105
		' (get) Token: 0x06000BAD RID: 2989 RVA: 0x00087F1C File Offset: 0x0008611C
		' (set) Token: 0x06000BAE RID: 2990 RVA: 0x00004033 File Offset: 0x00002233
		Public Property pStrFromDate As String
			Get
				Return Me.mStrFromDate
			End Get
			Set(value As String)
				Me.mStrFromDate = value
			End Set
		End Property

		' Token: 0x17000452 RID: 1106
		' (get) Token: 0x06000BAF RID: 2991 RVA: 0x00087F34 File Offset: 0x00086134
		' (set) Token: 0x06000BB0 RID: 2992 RVA: 0x0000403E File Offset: 0x0000223E
		Public Property pStrToDate As String
			Get
				Return Me.mStrToDate
			End Get
			Set(value As String)
				Me.mStrToDate = value
			End Set
		End Property

		' Token: 0x17000453 RID: 1107
		' (get) Token: 0x06000BB1 RID: 2993 RVA: 0x00087F4C File Offset: 0x0008614C
		' (set) Token: 0x06000BB2 RID: 2994 RVA: 0x00004049 File Offset: 0x00002249
		Public Property pStrFromTime As String
			Get
				Return Me.mStrFromTime
			End Get
			Set(value As String)
				Me.mStrFromTime = value
			End Set
		End Property

		' Token: 0x17000454 RID: 1108
		' (get) Token: 0x06000BB3 RID: 2995 RVA: 0x00087F64 File Offset: 0x00086164
		' (set) Token: 0x06000BB4 RID: 2996 RVA: 0x00004054 File Offset: 0x00002254
		Public Property pStrToTime As String
			Get
				Return Me.mStrToTime
			End Get
			Set(value As String)
				Me.mStrToTime = value
			End Set
		End Property

		' Token: 0x17000455 RID: 1109
		' (get) Token: 0x06000BB5 RID: 2997 RVA: 0x00087F7C File Offset: 0x0008617C
		' (set) Token: 0x06000BB6 RID: 2998 RVA: 0x0000405F File Offset: 0x0000225F
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06000BB7 RID: 2999 RVA: 0x00087F94 File Offset: 0x00086194
		Private Sub frmDMAUTOPRICE2_Activated(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fEnableButton()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
				Me.txtMAKH_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.txtMAKHU_TextChanged(RuntimeHelpers.GetObjectValue(sender), e)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMAUTOPRICE2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BB8 RID: 3000 RVA: 0x0008805C File Offset: 0x0008625C
		Private Sub frmDMAUTOPRICE2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMKH()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMKHU()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMAUTOPRICE2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BB9 RID: 3001 RVA: 0x00088130 File Offset: 0x00086330
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						Dim text As String = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
						Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text, "", 1, -1, CompareMethod.Binary))
						flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
							Me.mtxFromDate.Focus()
						Else
							text = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
							text2 = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text, "", 1, -1, CompareMethod.Binary))
							flag = Strings.Len(text2) > 0
							If flag Then
								text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 1, 2) })
								flag = Not Information.IsDate(text2)
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(35), MsgBoxStyle.Critical, Nothing)
									Me.mtxFromDate.Focus()
									Return
								End If
							End If
							text = Strings.Mid(Me.mtxToDate.Text, 3, 1)
							text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text, "", 1, -1, CompareMethod.Binary))
							flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
								Me.mtxToDate.Focus()
							Else
								text = Strings.Mid(Me.mtxToDate.Text, 3, 1)
								text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text, "", 1, -1, CompareMethod.Binary))
								flag = Strings.Len(text2) > 0
								If flag Then
									text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 1, 2) })
									flag = Not Information.IsDate(text2)
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(36), MsgBoxStyle.Critical, Nothing)
										Me.mtxToDate.Focus()
										Return
									End If
								End If
								Dim text3 As String = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text, "", 1, -1, CompareMethod.Binary))
								text3 = Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 4, 2) + Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 1, 2)
								Dim text4 As String = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text, "", 1, -1, CompareMethod.Binary))
								text4 = Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 4, 2) + Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 1, 2)
								flag = Operators.CompareString(text3, text4, False) > 0
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(43), MsgBoxStyle.Critical, Nothing)
									Me.mtxToDate.Focus()
								Else
									text = Strings.Mid(Me.mtxFromTime.Text, 3, 1)
									text2 = Strings.Trim(Strings.Replace(Me.mtxFromTime.Text, text, "", 1, -1, CompareMethod.Binary))
									flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
										Me.mtxFromTime.Focus()
									Else
										text = Strings.Mid(Me.mtxFromTime.Text, 3, 1)
										text2 = Strings.Trim(Strings.Replace(Me.mtxFromTime.Text, text, "", 1, -1, CompareMethod.Binary))
										flag = Strings.Len(text2) > 0
										If flag Then
											Dim text5 As String = Strings.Mid(Me.mtxFromTime.Text, 1, 2)
											Dim text6 As String = Strings.Mid(Me.mtxFromTime.Text, 4, 2)
											flag = (Conversion.Val(text5) < 0.0) Or (Conversion.Val(text5) > 23.0) Or (Conversion.Val(text6) < 0.0) Or (Conversion.Val(text6) > 59.0)
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(37), MsgBoxStyle.Critical, Nothing)
												Me.mtxFromTime.Focus()
												Return
											End If
										End If
										text = Strings.Mid(Me.mtxToTime.Text, 3, 1)
										text2 = Strings.Trim(Strings.Replace(Me.mtxToTime.Text, text, "", 1, -1, CompareMethod.Binary))
										flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
										If flag Then
											Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
											Me.mtxToTime.Focus()
										Else
											text = Strings.Mid(Me.mtxToTime.Text, 3, 1)
											text2 = Strings.Trim(Strings.Replace(Me.mtxToTime.Text, text, "", 1, -1, CompareMethod.Binary))
											flag = Strings.Len(text2) > 0
											If flag Then
												Dim text5 As String = Strings.Mid(Me.mtxToTime.Text, 1, 2)
												Dim text6 As String = Strings.Mid(Me.mtxToTime.Text, 4, 2)
												flag = (Conversion.Val(text5) < 0.0) Or (Conversion.Val(text5) > 23.0) Or (Conversion.Val(text6) < 0.0) Or (Conversion.Val(text6) > 59.0)
												If flag Then
													Interaction.MsgBox(Me.mArrStrFrmMess(38), MsgBoxStyle.Critical, Nothing)
													Me.mtxToTime.Focus()
													Return
												End If
											End If
											Dim text7 As String = Strings.Trim(Strings.Replace(Me.mtxFromTime.Text, text, "", 1, -1, CompareMethod.Binary))
											text7 = Strings.Mid(Strings.Trim(Me.mtxFromTime.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxFromTime.Text), 4, 2) + Strings.Mid(Strings.Trim(Me.mtxFromTime.Text), 1, 2)
											Dim text8 As String = Strings.Trim(Strings.Replace(Me.mtxToTime.Text, text, "", 1, -1, CompareMethod.Binary))
											text8 = Strings.Mid(Strings.Trim(Me.mtxToTime.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxToTime.Text), 4, 2) + Strings.Mid(Strings.Trim(Me.mtxToTime.Text), 1, 2)
											flag = Operators.CompareString(text7, text8, False) > 0
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(44), MsgBoxStyle.Critical, Nothing)
												Me.mtxToDate.Focus()
											Else
												flag = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
												If flag Then
													Me.mbytSuccess = Me.fAddNew()
												Else
													flag = Me.mbytFormStatus = 3
													If flag Then
														Me.mbytSuccess = Me.fModify()
													End If
												End If
												flag = Me.mbytSuccess = 1
												If flag Then
													Me.Close()
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BBA RID: 3002 RVA: 0x00088A68 File Offset: 0x00086C68
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BBB RID: 3003 RVA: 0x00088B0C File Offset: 0x00086D0C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAKH.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAKHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKHU like '"), text2), "%'"))
				End If
				Dim text3 As String = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FROMDATE like '%"), text2), "%'"))
				End If
				text3 = Strings.Mid(Me.mtxToDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TODATE like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BBC RID: 3004 RVA: 0x00088EA0 File Offset: 0x000870A0
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAKH.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAKHU.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKHU like '"), text2), "%'"))
				End If
				Dim text3 As String = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FROMDATE like '%"), text2), "%'"))
				End If
				text3 = Strings.Mid(Me.mtxToDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TODATE like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BBD RID: 3005 RVA: 0x00089234 File Offset: 0x00087434
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKH As frmDMKH1 = New frmDMKH1()
				frmDMKH.pBytOpen_From_Menu = 7
				frmDMKH.ShowDialog()
				Me.txtMAKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJID, "", False) = 0, Me.txtMAKH.Text, frmDMKH.pStrOBJID))
				Me.txtTENKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJNAME, "", False) = 0, Me.txtTENKH.Text, frmDMKH.pStrOBJNAME))
				frmDMKH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BBE RID: 3006 RVA: 0x00089358 File Offset: 0x00087558
		Private Sub btnDMKHU_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKHU As frmDMKHU1 = New frmDMKHU1()
				frmDMKHU.pBytOpen_From_Menu = 7
				frmDMKHU.StartPosition = FormStartPosition.CenterScreen
				frmDMKHU.ShowDialog()
				Me.txtMAKHU.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKHU.pStrOBJID, "", False) = 0, Me.txtMAKHU.Text, frmDMKHU.pStrOBJID))
				Me.txtTENKHU.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKHU.pStrOBJNAME, "", False) = 0, Me.txtTENKHU.Text, frmDMKHU.pStrOBJNAME))
				frmDMKHU.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDMKHU_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BBF RID: 3007 RVA: 0x00089484 File Offset: 0x00087684
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJNAME.Focus()
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtTENKH.BackColor
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtTENKH.BackColor
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtOBJNAME.BackColor = Me.txtTENKH.BackColor
						Me.txtMAKH.[ReadOnly] = True
						Me.txtMAKH.BackColor = Me.txtTENKH.BackColor
						Me.btnSelect.Enabled = False
						Me.mtxFromDate.[ReadOnly] = True
						Me.mtxFromDate.BackColor = Me.txtTENKH.BackColor
						Me.mtxToDate.[ReadOnly] = True
						Me.mtxToDate.BackColor = Me.txtTENKH.BackColor
						Me.mtxFromTime.[ReadOnly] = True
						Me.mtxFromTime.BackColor = Me.txtTENKH.BackColor
						Me.mtxToTime.[ReadOnly] = True
						Me.mtxToTime.BackColor = Me.txtTENKH.BackColor
						Me.chkT2.Enabled = False
						Me.chkT3.Enabled = False
						Me.chkT4.Enabled = False
						Me.chkT5.Enabled = False
						Me.chkT6.Enabled = False
						Me.chkT7.Enabled = False
						Me.chkCN.Enabled = False
						Me.btnDelete.Focus()
					Case 5, 6
						Me.txtOBJID.[ReadOnly] = False
				End Select
				Dim flag As Boolean = Operators.CompareString(Me.mStrFromDate, "", False) <> 0
				If flag Then
					Me.mtxFromDate.Text = Me.mStrFromDate
				End If
				flag = Operators.CompareString(Me.mStrToDate, "", False) <> 0
				If flag Then
					Me.mtxToDate.Text = Me.mStrToDate
				End If
				flag = Operators.CompareString(Me.mStrFromTime, "", False) <> 0
				If flag Then
					Me.mtxFromTime.Text = Me.mStrFromTime
				End If
				flag = Operators.CompareString(Me.mStrToTime, "", False) <> 0
				If flag Then
					Me.mtxToTime.Text = Me.mStrToTime
				End If
				flag = Operators.CompareString(Me.mstrOBJID, "", False) <> 0
				If flag Then
					Me.txtOBJID.Text = Me.mstrOBJID
				End If
				flag = Operators.CompareString(Me.mstrKHO, "", False) <> 0
				If flag Then
					Me.txtMAKH.Text = Me.mstrKHO
				End If
				flag = Operators.CompareString(mdlVariable.gStrStockCode, "", False) <> 0
				If flag Then
					Me.txtMAKH.[ReadOnly] = True
					Me.txtMAKH.BackColor = Me.txtTENKH.BackColor
					Me.btnSelect.Enabled = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000BC0 RID: 3008 RVA: 0x0008988C File Offset: 0x00087A8C
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000BC1 RID: 3009 RVA: 0x00089A1C File Offset: 0x00087C1C
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 10
				Me.txtOBJNAME.MaxLength = 100
				Me.txtMAKH.MaxLength = 3
				Me.txtMAKHU.MaxLength = 3
				Me.txtTENKH.[ReadOnly] = True
				Me.txtTENKHU.[ReadOnly] = True
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				Me.txtMAKH.CharacterCasing = CharacterCasing.Upper
				Me.txtMAKHU.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000BC2 RID: 3010 RVA: 0x00089B40 File Offset: 0x00087D40
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0014"
					Me.lblOBJNAME.Tag = "CB0015"
					Me.lblFromDate.Tag = "CB0018"
					Me.lblToDate.Tag = "CB0019"
					Me.lblFromTime.Tag = "CB0021"
					Me.lblToTime.Tag = "CB0022"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(8))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(9))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(10))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(12))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(11))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000BC3 RID: 3011 RVA: 0x00089D68 File Offset: 0x00087F68
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMKHO.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BC4 RID: 3012 RVA: 0x00089E14 File Offset: 0x00088014
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(16) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvchOBJNAME"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKH.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvchTOTIME"
				array(3).Value = Strings.Trim(Me.mtxToTime.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvchFROMDATE"
				array(4).Value = Strings.Trim(Me.mtxFromDate.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvchTODATE"
				array(5).Value = Strings.Trim(Me.mtxToDate.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pbitLDAY2"
				array(6).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT2.Checked, 1, 0))
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pbitLDAY3"
				array(7).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT3.Checked, 1, 0))
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pbitLDAY4"
				array(8).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT4.Checked, 1, 0))
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pbitLDAY5"
				array(9).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT5.Checked, 1, 0))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pbitLDAY6"
				array(10).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT6.Checked, 1, 0))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pbitLDAY7"
				array(11).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT7.Checked, 1, 0))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pbitLDAY8"
				array(12).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCN.Checked, 1, 0))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pnvchFROMTIME"
				array(13).Value = Strings.Trim(Me.mtxFromTime.Text)
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pnchMAKHU"
				array(14).Value = Strings.Trim(Me.txtMAKHU.Text)
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@int_Result"
				array(15).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMAUTOPRICE_INSERT", flag)
				Dim num As Integer = Conversions.ToInteger(array(15).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(31), MsgBoxStyle.Critical, Nothing)
						Me.txtMAKH.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKHU.Focus()
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(34), MsgBoxStyle.Critical, Nothing)
								Me.btnExit.Focus()
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000BC5 RID: 3013 RVA: 0x0008A390 File Offset: 0x00088590
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(16) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvchOBJNAME"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKH.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnvchTOTIME"
				array(3).Value = Strings.Trim(Me.mtxToTime.Text)
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvchFROMDATE"
				array(4).Value = Strings.Trim(Me.mtxFromDate.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvchTODATE"
				array(5).Value = Strings.Trim(Me.mtxToDate.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pbitLDAY2"
				array(6).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT2.Checked, 1, 0))
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pbitLDAY3"
				array(7).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT3.Checked, 1, 0))
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pbitLDAY4"
				array(8).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT4.Checked, 1, 0))
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pbitLDAY5"
				array(9).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT5.Checked, 1, 0))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pbitLDAY6"
				array(10).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT6.Checked, 1, 0))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pbitLDAY7"
				array(11).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT7.Checked, 1, 0))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pbitLDAY8"
				array(12).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCN.Checked, 1, 0))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pnvchFROMTIME"
				array(13).Value = Strings.Trim(Me.mtxFromTime.Text)
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pnchMAKHU"
				array(14).Value = Strings.Trim(Me.txtMAKHU.Text)
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@int_Result"
				array(15).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMAUTOPRICE_UPDATE", flag)
				Dim num As Integer = Conversions.ToInteger(array(15).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(31), MsgBoxStyle.Critical, Nothing)
						Me.txtMAKH.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
							Me.txtMAKHU.Focus()
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(33), MsgBoxStyle.Critical, Nothing)
								Me.btnExit.Focus()
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000BC6 RID: 3014 RVA: 0x0008A908 File Offset: 0x00088B08
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMAUTOPRICE_DEL", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(33), MsgBoxStyle.Critical, Nothing)
						Me.btnExit.Focus()
						b = 1
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(48), MsgBoxStyle.Critical, Nothing)
							Me.btnExit.Focus()
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000BC7 RID: 3015 RVA: 0x0008AAD4 File Offset: 0x00088CD4
		Private Sub sClearCheckBox()
			Try
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.chkT2.Checked = False
						Me.chkT3.Checked = False
						Me.chkT4.Checked = False
						Me.chkT5.Checked = False
						Me.chkT6.Checked = False
						Me.chkT7.Checked = False
						Me.chkCN.Checked = False
				End Select
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClearCheckBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BC8 RID: 3016 RVA: 0x0008ABEC File Offset: 0x00088DEC
		Private Sub sDisplayLabel()
			Try
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sDisplayLabel ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BC9 RID: 3017 RVA: 0x0008AC84 File Offset: 0x00088E84
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BCA RID: 3018 RVA: 0x0008AD30 File Offset: 0x00088F30
		Private Sub txtTENKH_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENKH.[ReadOnly]
				If [readOnly] Then
					Me.mtxFromDate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENKH_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BCB RID: 3019 RVA: 0x0008ADDC File Offset: 0x00088FDC
		Private Sub txtTenNDV_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENKH.[ReadOnly]
				If [readOnly] Then
					Me.mtxFromDate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTenNDV_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BCC RID: 3020 RVA: 0x0008AE88 File Offset: 0x00089088
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BCD RID: 3021 RVA: 0x0008AF2C File Offset: 0x0008912C
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMAKH.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BCE RID: 3022 RVA: 0x0008AFD0 File Offset: 0x000891D0
		Private Sub txtMAKH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtTENKH.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BCF RID: 3023 RVA: 0x0008B074 File Offset: 0x00089274
		Private Sub txtTENKH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxFromDate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENKH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BD0 RID: 3024 RVA: 0x0008B118 File Offset: 0x00089318
		Private Sub mtxFromDate_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxToDate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxFromDate_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BD1 RID: 3025 RVA: 0x0008B1BC File Offset: 0x000893BC
		Private Sub mtxToDate_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT2.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxToDate_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BD2 RID: 3026 RVA: 0x0008B260 File Offset: 0x00089460
		Private Sub chkT2_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT3.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT2_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BD3 RID: 3027 RVA: 0x0008B304 File Offset: 0x00089504
		Private Sub chkT3_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT4.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT3_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BD4 RID: 3028 RVA: 0x0008B3A8 File Offset: 0x000895A8
		Private Sub chkT4_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT5.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT4_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BD5 RID: 3029 RVA: 0x0008B44C File Offset: 0x0008964C
		Private Sub chkT5_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT6.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT5_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BD6 RID: 3030 RVA: 0x0008B4F0 File Offset: 0x000896F0
		Private Sub chkT6_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT7.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT6_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BD7 RID: 3031 RVA: 0x0008B594 File Offset: 0x00089794
		Private Sub chkT7_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkCN.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT7_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BD8 RID: 3032 RVA: 0x0008B638 File Offset: 0x00089838
		Private Sub chkCN_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxFromTime.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkCN_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BD9 RID: 3033 RVA: 0x0008B6DC File Offset: 0x000898DC
		Private Sub mtxFromTime_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxToTime.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxFromTime_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BDA RID: 3034 RVA: 0x0008B780 File Offset: 0x00089980
		Private Sub mtxToTime_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.btnSave.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxToTime_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000BDB RID: 3035 RVA: 0x0008B824 File Offset: 0x00089A24
		Private Sub txtMAKH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKHO Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMKHO.Columns("OBJID")
					Me.mclsTbDMKHO.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKHO.Rows.Find(Strings.Trim(Me.txtMAKH.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENKH.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENKH.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BDC RID: 3036 RVA: 0x0008B978 File Offset: 0x00089B78
		Private Sub txtMAKHU_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKHU Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMKHU.Columns("OBJID")
					Me.mclsTbDMKHU.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKHU.Rows.Find(Strings.Trim(Me.txtMAKHU.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENKHU.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENKHU.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHU_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BDD RID: 3037 RVA: 0x0008BACC File Offset: 0x00089CCC
		Private Function fGetData_DMKH() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKHO = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = Me.mclsTbDMKHO IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMKH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000BDE RID: 3038 RVA: 0x0008BB88 File Offset: 0x00089D88
		Private Function fGetData_DMKHU() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKHU = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKHU")
				Dim flag As Boolean = Me.mclsTbDMKHU IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMKHU ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000BDF RID: 3039 RVA: 0x0008BC44 File Offset: 0x00089E44
		Public Sub gsCheckDate()
			Try
				Me.chkT2.Checked = True
				Me.chkT3.Checked = True
				Me.chkT4.Checked = True
				Me.chkT5.Checked = True
				Me.chkT6.Checked = True
				Me.chkT7.Checked = True
				Me.chkCN.Checked = True
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gsCheckDate ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000BE0 RID: 3040 RVA: 0x0000393D File Offset: 0x00001B3D
		Protected Overrides Sub Finalize()
			MyBase.Finalize()
		End Sub

		' Token: 0x040004F7 RID: 1271
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040004F9 RID: 1273
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x040004FA RID: 1274
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x040004FB RID: 1275
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040004FC RID: 1276
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x040004FD RID: 1277
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x040004FE RID: 1278
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x040004FF RID: 1279
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000500 RID: 1280
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000501 RID: 1281
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000502 RID: 1282
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000503 RID: 1283
		<AccessedThroughProperty("lblFromDate")>
		Private _lblFromDate As Label

		' Token: 0x04000504 RID: 1284
		<AccessedThroughProperty("txtTENKH")>
		Private _txtTENKH As TextBox

		' Token: 0x04000505 RID: 1285
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000506 RID: 1286
		<AccessedThroughProperty("txtMAKH")>
		Private _txtMAKH As TextBox

		' Token: 0x04000507 RID: 1287
		<AccessedThroughProperty("lblkHO")>
		Private _lblkHO As Label

		' Token: 0x04000508 RID: 1288
		<AccessedThroughProperty("lblToDate")>
		Private _lblToDate As Label

		' Token: 0x04000509 RID: 1289
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x0400050A RID: 1290
		<AccessedThroughProperty("lblToTime")>
		Private _lblToTime As Label

		' Token: 0x0400050B RID: 1291
		<AccessedThroughProperty("lblFromTime")>
		Private _lblFromTime As Label

		' Token: 0x0400050C RID: 1292
		<AccessedThroughProperty("chkT2")>
		Private _chkT2 As CheckBox

		' Token: 0x0400050D RID: 1293
		<AccessedThroughProperty("chkT3")>
		Private _chkT3 As CheckBox

		' Token: 0x0400050E RID: 1294
		<AccessedThroughProperty("chkT4")>
		Private _chkT4 As CheckBox

		' Token: 0x0400050F RID: 1295
		<AccessedThroughProperty("chkT5")>
		Private _chkT5 As CheckBox

		' Token: 0x04000510 RID: 1296
		<AccessedThroughProperty("chkT6")>
		Private _chkT6 As CheckBox

		' Token: 0x04000511 RID: 1297
		<AccessedThroughProperty("chkT7")>
		Private _chkT7 As CheckBox

		' Token: 0x04000512 RID: 1298
		<AccessedThroughProperty("chkCN")>
		Private _chkCN As CheckBox

		' Token: 0x04000513 RID: 1299
		<AccessedThroughProperty("mtxFromDate")>
		Private _mtxFromDate As MaskedTextBox

		' Token: 0x04000514 RID: 1300
		<AccessedThroughProperty("mtxToDate")>
		Private _mtxToDate As MaskedTextBox

		' Token: 0x04000515 RID: 1301
		<AccessedThroughProperty("mtxFromTime")>
		Private _mtxFromTime As MaskedTextBox

		' Token: 0x04000516 RID: 1302
		<AccessedThroughProperty("mtxToTime")>
		Private _mtxToTime As MaskedTextBox

		' Token: 0x04000517 RID: 1303
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000518 RID: 1304
		<AccessedThroughProperty("txtTENKHU")>
		Private _txtTENKHU As TextBox

		' Token: 0x04000519 RID: 1305
		<AccessedThroughProperty("btnDMKHU")>
		Private _btnDMKHU As Button

		' Token: 0x0400051A RID: 1306
		<AccessedThroughProperty("txtMAKHU")>
		Private _txtMAKHU As TextBox

		' Token: 0x0400051B RID: 1307
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x0400051C RID: 1308
		Private mArrStrFrmMess As String()

		' Token: 0x0400051D RID: 1309
		Private mbytFormStatus As Byte

		' Token: 0x0400051E RID: 1310
		Private mbytSuccess As Byte

		' Token: 0x0400051F RID: 1311
		Private mstrKHO As String

		' Token: 0x04000520 RID: 1312
		Private mstrOBJID As String

		' Token: 0x04000521 RID: 1313
		Private mstrHTKM As String

		' Token: 0x04000522 RID: 1314
		Private mstrMaNHOMDV As Object

		' Token: 0x04000523 RID: 1315
		Private mStrFilter As String

		' Token: 0x04000524 RID: 1316
		Private mStrFromDate As String

		' Token: 0x04000525 RID: 1317
		Private mStrToDate As String

		' Token: 0x04000526 RID: 1318
		Private mStrFromTime As String

		' Token: 0x04000527 RID: 1319
		Private mStrToTime As String

		' Token: 0x04000528 RID: 1320
		Private mclsTbDMKHO As clsConnect

		' Token: 0x04000529 RID: 1321
		Private mclsTbDMNHOMDV As clsConnect

		' Token: 0x0400052A RID: 1322
		Private mclsTbDMKM As clsConnect

		' Token: 0x0400052B RID: 1323
		Private mclsTbDMKHU As clsConnect
	End Class
End Namespace
