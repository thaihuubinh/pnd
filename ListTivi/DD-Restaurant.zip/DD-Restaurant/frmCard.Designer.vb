﻿Namespace prjIS_SalesPOS
	' Token: 0x0200001E RID: 30
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Friend Partial Class frmCard
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060004B1 RID: 1201 RVA: 0x000387B0 File Offset: 0x000369B0
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(Disposing As Boolean)
			If Disposing Then
				Dim flag As Boolean = Me.components IsNot Nothing
				If flag Then
					Me.components.Dispose()
				End If
			End If
			MyBase.Dispose(Disposing)
		End Sub

		' Token: 0x060004F6 RID: 1270 RVA: 0x00038E7C File Offset: 0x0003707C
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Global.System.ComponentModel.Container()
			Me.ToolTip1 = New Global.System.Windows.Forms.ToolTip(Me.components)
			Me.btnForceCancel = New Global.System.Windows.Forms.Button()
			Me.ProgressBar1 = New Global.System.Windows.Forms.ProgressBar()
			Me.Frame2 = New Global.System.Windows.Forms.GroupBox()
			Me.cboCardType = New Global.System.Windows.Forms.ComboBox()
			Me.txtSubRoom = New Global.System.Windows.Forms.TextBox()
			Me.txtCardAuthCode = New Global.System.Windows.Forms.TextBox()
			Me.txtCardSnr = New Global.System.Windows.Forms.TextBox()
			Me.txtHotelCode = New Global.System.Windows.Forms.TextBox()
			Me.txtCleaning = New Global.System.Windows.Forms.TextBox()
			Me.txtRoom = New Global.System.Windows.Forms.TextBox()
			Me.txtFloor = New Global.System.Windows.Forms.TextBox()
			Me.txtBuilding = New Global.System.Windows.Forms.TextBox()
			Me.txtExpireDate = New Global.System.Windows.Forms.TextBox()
			Me.txtCardKey = New Global.System.Windows.Forms.TextBox()
			Me.txtStartDate = New Global.System.Windows.Forms.TextBox()
			Me.Label15 = New Global.System.Windows.Forms.Label()
			Me.Label10 = New Global.System.Windows.Forms.Label()
			Me.Label9 = New Global.System.Windows.Forms.Label()
			Me.Label8 = New Global.System.Windows.Forms.Label()
			Me.Label7 = New Global.System.Windows.Forms.Label()
			Me.Label6 = New Global.System.Windows.Forms.Label()
			Me.Label5 = New Global.System.Windows.Forms.Label()
			Me.Label4 = New Global.System.Windows.Forms.Label()
			Me.Label3 = New Global.System.Windows.Forms.Label()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.btnReadAuth = New Global.System.Windows.Forms.Button()
			Me.btnCheckLink = New Global.System.Windows.Forms.Button()
			Me.btnCheckCard = New Global.System.Windows.Forms.Button()
			Me.btnGetNewAuth = New Global.System.Windows.Forms.Button()
			Me.btnCancelCard = New Global.System.Windows.Forms.Button()
			Me.btnIssueCard = New Global.System.Windows.Forms.Button()
			Me.btnReadCard = New Global.System.Windows.Forms.Button()
			Me.Label16 = New Global.System.Windows.Forms.Label()
			Me.cboLockType = New Global.System.Windows.Forms.ComboBox()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.Frame2.SuspendLayout()
			Me.SuspendLayout()
			Me.btnForceCancel.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnForceCancel.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.btnForceCancel.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnForceCancel.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim btnForceCancel As Global.System.Windows.Forms.Control = Me.btnForceCancel
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(610, 415)
			btnForceCancel.Location = point
			Me.btnForceCancel.Name = "btnForceCancel"
			Me.btnForceCancel.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim btnForceCancel2 As Global.System.Windows.Forms.Control = Me.btnForceCancel
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(81, 41)
			btnForceCancel2.Size = size
			Me.btnForceCancel.TabIndex = 47
			Me.btnForceCancel.Text = "Force Cancel"
			Me.btnForceCancel.UseVisualStyleBackColor = False
			Dim progressBar As Global.System.Windows.Forms.Control = Me.ProgressBar1
			point = New Global.System.Drawing.Point(9, 380)
			progressBar.Location = point
			Me.ProgressBar1.Name = "ProgressBar1"
			Dim progressBar2 As Global.System.Windows.Forms.Control = Me.ProgressBar1
			size = New Global.System.Drawing.Size(681, 25)
			progressBar2.Size = size
			Me.ProgressBar1.TabIndex = 37
			Me.Frame2.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Frame2.Controls.Add(Me.cboCardType)
			Me.Frame2.Controls.Add(Me.txtSubRoom)
			Me.Frame2.Controls.Add(Me.txtCardAuthCode)
			Me.Frame2.Controls.Add(Me.txtCardSnr)
			Me.Frame2.Controls.Add(Me.txtHotelCode)
			Me.Frame2.Controls.Add(Me.txtCleaning)
			Me.Frame2.Controls.Add(Me.txtRoom)
			Me.Frame2.Controls.Add(Me.txtFloor)
			Me.Frame2.Controls.Add(Me.txtBuilding)
			Me.Frame2.Controls.Add(Me.txtExpireDate)
			Me.Frame2.Controls.Add(Me.txtCardKey)
			Me.Frame2.Controls.Add(Me.txtStartDate)
			Me.Frame2.Controls.Add(Me.Label15)
			Me.Frame2.Controls.Add(Me.Label10)
			Me.Frame2.Controls.Add(Me.Label9)
			Me.Frame2.Controls.Add(Me.Label8)
			Me.Frame2.Controls.Add(Me.Label7)
			Me.Frame2.Controls.Add(Me.Label6)
			Me.Frame2.Controls.Add(Me.Label5)
			Me.Frame2.Controls.Add(Me.Label4)
			Me.Frame2.Controls.Add(Me.Label3)
			Me.Frame2.Controls.Add(Me.Label2)
			Me.Frame2.Controls.Add(Me.Label1)
			Me.Frame2.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Frame2.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim frame As Global.System.Windows.Forms.Control = Me.Frame2
			point = New Global.System.Drawing.Point(8, 8)
			frame.Location = point
			Me.Frame2.Name = "Frame2"
			Me.Frame2.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim frame2 As Global.System.Windows.Forms.Control = Me.Frame2
			size = New Global.System.Drawing.Size(281, 369)
			frame2.Size = size
			Me.Frame2.TabIndex = 8
			Me.Frame2.TabStop = False
			Me.Frame2.Text = "Card Data"
			Me.cboCardType.BackColor = Global.System.Drawing.SystemColors.Window
			Me.cboCardType.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.cboCardType.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cboCardType.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.cboCardType.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Me.cboCardType.Items.AddRange(New Object() { "AuthCard", "ClockCard", "DataCard", "SetCard", "DisableCard", "CheckoutCard", "EmergencyCard", "ControlCard", "BuildingCard", "FloorCard", "GuestCard", "CleaningCard", "MaintainCard", "MeetingCard", "UnknowCard" })
			Dim cboCardType As Global.System.Windows.Forms.Control = Me.cboCardType
			point = New Global.System.Drawing.Point(96, 16)
			cboCardType.Location = point
			Me.cboCardType.Name = "cboCardType"
			Me.cboCardType.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim cboCardType2 As Global.System.Windows.Forms.Control = Me.cboCardType
			size = New Global.System.Drawing.Size(169, 22)
			cboCardType2.Size = size
			Me.cboCardType.TabIndex = 46
			Me.txtSubRoom.AcceptsReturn = True
			Me.txtSubRoom.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtSubRoom.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtSubRoom.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtSubRoom.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtSubRoom As Global.System.Windows.Forms.Control = Me.txtSubRoom
			point = New Global.System.Drawing.Point(184, 208)
			txtSubRoom.Location = point
			Me.txtSubRoom.MaxLength = 0
			Me.txtSubRoom.Name = "txtSubRoom"
			Me.txtSubRoom.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtSubRoom2 As Global.System.Windows.Forms.Control = Me.txtSubRoom
			size = New Global.System.Drawing.Size(81, 20)
			txtSubRoom2.Size = size
			Me.txtSubRoom.TabIndex = 45
			Me.txtCardAuthCode.AcceptsReturn = True
			Me.txtCardAuthCode.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtCardAuthCode.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtCardAuthCode.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtCardAuthCode.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtCardAuthCode As Global.System.Windows.Forms.Control = Me.txtCardAuthCode
			point = New Global.System.Drawing.Point(120, 336)
			txtCardAuthCode.Location = point
			Me.txtCardAuthCode.MaxLength = 0
			Me.txtCardAuthCode.Name = "txtCardAuthCode"
			Me.txtCardAuthCode.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtCardAuthCode2 As Global.System.Windows.Forms.Control = Me.txtCardAuthCode
			size = New Global.System.Drawing.Size(145, 20)
			txtCardAuthCode2.Size = size
			Me.txtCardAuthCode.TabIndex = 40
			Me.txtCardSnr.AcceptsReturn = True
			Me.txtCardSnr.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtCardSnr.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtCardSnr.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtCardSnr.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtCardSnr As Global.System.Windows.Forms.Control = Me.txtCardSnr
			point = New Global.System.Drawing.Point(96, 304)
			txtCardSnr.Location = point
			Me.txtCardSnr.MaxLength = 0
			Me.txtCardSnr.Name = "txtCardSnr"
			Me.txtCardSnr.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtCardSnr2 As Global.System.Windows.Forms.Control = Me.txtCardSnr
			size = New Global.System.Drawing.Size(169, 20)
			txtCardSnr2.Size = size
			Me.txtCardSnr.TabIndex = 27
			Me.txtHotelCode.AcceptsReturn = True
			Me.txtHotelCode.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtHotelCode.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtHotelCode.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtHotelCode.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtHotelCode As Global.System.Windows.Forms.Control = Me.txtHotelCode
			point = New Global.System.Drawing.Point(96, 272)
			txtHotelCode.Location = point
			Me.txtHotelCode.MaxLength = 0
			Me.txtHotelCode.Name = "txtHotelCode"
			Me.txtHotelCode.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtHotelCode2 As Global.System.Windows.Forms.Control = Me.txtHotelCode
			size = New Global.System.Drawing.Size(169, 20)
			txtHotelCode2.Size = size
			Me.txtHotelCode.TabIndex = 25
			Me.txtCleaning.AcceptsReturn = True
			Me.txtCleaning.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtCleaning.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtCleaning.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtCleaning.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtCleaning As Global.System.Windows.Forms.Control = Me.txtCleaning
			point = New Global.System.Drawing.Point(96, 240)
			txtCleaning.Location = point
			Me.txtCleaning.MaxLength = 0
			Me.txtCleaning.Name = "txtCleaning"
			Me.txtCleaning.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtCleaning2 As Global.System.Windows.Forms.Control = Me.txtCleaning
			size = New Global.System.Drawing.Size(169, 20)
			txtCleaning2.Size = size
			Me.txtCleaning.TabIndex = 23
			Me.txtRoom.AcceptsReturn = True
			Me.txtRoom.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtRoom.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtRoom.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtRoom.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtRoom As Global.System.Windows.Forms.Control = Me.txtRoom
			point = New Global.System.Drawing.Point(96, 208)
			txtRoom.Location = point
			Me.txtRoom.MaxLength = 0
			Me.txtRoom.Name = "txtRoom"
			Me.txtRoom.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtRoom2 As Global.System.Windows.Forms.Control = Me.txtRoom
			size = New Global.System.Drawing.Size(81, 20)
			txtRoom2.Size = size
			Me.txtRoom.TabIndex = 15
			Me.txtFloor.AcceptsReturn = True
			Me.txtFloor.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtFloor.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtFloor.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtFloor.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtFloor As Global.System.Windows.Forms.Control = Me.txtFloor
			point = New Global.System.Drawing.Point(96, 176)
			txtFloor.Location = point
			Me.txtFloor.MaxLength = 0
			Me.txtFloor.Name = "txtFloor"
			Me.txtFloor.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtFloor2 As Global.System.Windows.Forms.Control = Me.txtFloor
			size = New Global.System.Drawing.Size(169, 20)
			txtFloor2.Size = size
			Me.txtFloor.TabIndex = 14
			Me.txtBuilding.AcceptsReturn = True
			Me.txtBuilding.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtBuilding.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtBuilding.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtBuilding.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtBuilding As Global.System.Windows.Forms.Control = Me.txtBuilding
			point = New Global.System.Drawing.Point(96, 144)
			txtBuilding.Location = point
			Me.txtBuilding.MaxLength = 0
			Me.txtBuilding.Name = "txtBuilding"
			Me.txtBuilding.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtBuilding2 As Global.System.Windows.Forms.Control = Me.txtBuilding
			size = New Global.System.Drawing.Size(169, 20)
			txtBuilding2.Size = size
			Me.txtBuilding.TabIndex = 13
			Me.txtExpireDate.AcceptsReturn = True
			Me.txtExpireDate.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtExpireDate.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtExpireDate.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtExpireDate.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtExpireDate As Global.System.Windows.Forms.Control = Me.txtExpireDate
			point = New Global.System.Drawing.Point(96, 112)
			txtExpireDate.Location = point
			Me.txtExpireDate.MaxLength = 0
			Me.txtExpireDate.Name = "txtExpireDate"
			Me.txtExpireDate.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtExpireDate2 As Global.System.Windows.Forms.Control = Me.txtExpireDate
			size = New Global.System.Drawing.Size(169, 20)
			txtExpireDate2.Size = size
			Me.txtExpireDate.TabIndex = 12
			Me.txtCardKey.AcceptsReturn = True
			Me.txtCardKey.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtCardKey.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtCardKey.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtCardKey.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtCardKey As Global.System.Windows.Forms.Control = Me.txtCardKey
			point = New Global.System.Drawing.Point(96, 48)
			txtCardKey.Location = point
			Me.txtCardKey.MaxLength = 0
			Me.txtCardKey.Name = "txtCardKey"
			Me.txtCardKey.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtCardKey2 As Global.System.Windows.Forms.Control = Me.txtCardKey
			size = New Global.System.Drawing.Size(169, 20)
			txtCardKey2.Size = size
			Me.txtCardKey.TabIndex = 10
			Me.txtCardKey.Text = "2004-12-1 00:00:01"
			Me.txtStartDate.AcceptsReturn = True
			Me.txtStartDate.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtStartDate.Cursor = Global.System.Windows.Forms.Cursors.IBeam
			Me.txtStartDate.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.txtStartDate.ForeColor = Global.System.Drawing.SystemColors.WindowText
			Dim txtStartDate As Global.System.Windows.Forms.Control = Me.txtStartDate
			point = New Global.System.Drawing.Point(96, 80)
			txtStartDate.Location = point
			Me.txtStartDate.MaxLength = 0
			Me.txtStartDate.Name = "txtStartDate"
			Me.txtStartDate.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim txtStartDate2 As Global.System.Windows.Forms.Control = Me.txtStartDate
			size = New Global.System.Drawing.Size(169, 20)
			txtStartDate2.Size = size
			Me.txtStartDate.TabIndex = 9
			Me.Label15.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label15.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label15.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label15.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label As Global.System.Windows.Forms.Control = Me.Label15
			point = New Global.System.Drawing.Point(8, 344)
			label.Location = point
			Me.Label15.Name = "Label15"
			Me.Label15.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label15
			size = New Global.System.Drawing.Size(113, 17)
			label2.Size = size
			Me.Label15.TabIndex = 39
			Me.Label15.Text = "Authorization Code"
			Me.Label10.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label10.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label10.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label10.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label10
			point = New Global.System.Drawing.Point(8, 312)
			label3.Location = point
			Me.Label10.Name = "Label10"
			Me.Label10.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label10
			size = New Global.System.Drawing.Size(57, 17)
			label4.Size = size
			Me.Label10.TabIndex = 26
			Me.Label10.Text = "Card Snr"
			Me.Label9.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label9.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label9.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label9.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label5 As Global.System.Windows.Forms.Control = Me.Label9
			point = New Global.System.Drawing.Point(8, 280)
			label5.Location = point
			Me.Label9.Name = "Label9"
			Me.Label9.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label6 As Global.System.Windows.Forms.Control = Me.Label9
			size = New Global.System.Drawing.Size(81, 17)
			label6.Size = size
			Me.Label9.TabIndex = 24
			Me.Label9.Text = "Hotel Code"
			Me.Label8.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label8.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label8.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label8.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label7 As Global.System.Windows.Forms.Control = Me.Label8
			point = New Global.System.Drawing.Point(8, 248)
			label7.Location = point
			Me.Label8.Name = "Label8"
			Me.Label8.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label8 As Global.System.Windows.Forms.Control = Me.Label8
			size = New Global.System.Drawing.Size(49, 17)
			label8.Size = size
			Me.Label8.TabIndex = 22
			Me.Label8.Text = "Cleaning"
			Me.Label7.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label7.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label7.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label7.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label9 As Global.System.Windows.Forms.Control = Me.Label7
			point = New Global.System.Drawing.Point(8, 208)
			label9.Location = point
			Me.Label7.Name = "Label7"
			Me.Label7.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label10 As Global.System.Windows.Forms.Control = Me.Label7
			size = New Global.System.Drawing.Size(57, 25)
			label10.Size = size
			Me.Label7.TabIndex = 21
			Me.Label7.Text = "Room"
			Me.Label6.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label6.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label6.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label6.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label11 As Global.System.Windows.Forms.Control = Me.Label6
			point = New Global.System.Drawing.Point(8, 176)
			label11.Location = point
			Me.Label6.Name = "Label6"
			Me.Label6.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label12 As Global.System.Windows.Forms.Control = Me.Label6
			size = New Global.System.Drawing.Size(57, 25)
			label12.Size = size
			Me.Label6.TabIndex = 20
			Me.Label6.Text = "Floor"
			Me.Label5.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label5.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label5.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label5.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label13 As Global.System.Windows.Forms.Control = Me.Label5
			point = New Global.System.Drawing.Point(8, 144)
			label13.Location = point
			Me.Label5.Name = "Label5"
			Me.Label5.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label14 As Global.System.Windows.Forms.Control = Me.Label5
			size = New Global.System.Drawing.Size(57, 25)
			label14.Size = size
			Me.Label5.TabIndex = 19
			Me.Label5.Text = "Building"
			Me.Label4.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label4.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label4.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label4.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label15 As Global.System.Windows.Forms.Control = Me.Label4
			point = New Global.System.Drawing.Point(8, 112)
			label15.Location = point
			Me.Label4.Name = "Label4"
			Me.Label4.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label16 As Global.System.Windows.Forms.Control = Me.Label4
			size = New Global.System.Drawing.Size(81, 17)
			label16.Size = size
			Me.Label4.TabIndex = 18
			Me.Label4.Text = "Expire Date"
			Me.Label3.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label3.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label3.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label3.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label17 As Global.System.Windows.Forms.Control = Me.Label3
			point = New Global.System.Drawing.Point(8, 80)
			label17.Location = point
			Me.Label3.Name = "Label3"
			Me.Label3.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label18 As Global.System.Windows.Forms.Control = Me.Label3
			size = New Global.System.Drawing.Size(81, 17)
			label18.Size = size
			Me.Label3.TabIndex = 17
			Me.Label3.Text = "Start Date"
			Me.Label2.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label2.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label2.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label19 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(8, 48)
			label19.Location = point
			Me.Label2.Name = "Label2"
			Me.Label2.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label20 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(57, 25)
			label20.Size = size
			Me.Label2.TabIndex = 16
			Me.Label2.Text = "Card Key"
			Me.Label1.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label1.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label1.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label21 As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(8, 24)
			label21.Location = point
			Me.Label1.Name = "Label1"
			Me.Label1.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label22 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(73, 17)
			label22.Size = size
			Me.Label1.TabIndex = 11
			Me.Label1.Text = "Card Type"
			Me.btnReadAuth.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnReadAuth.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.btnReadAuth.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnReadAuth.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim btnReadAuth As Global.System.Windows.Forms.Control = Me.btnReadAuth
			point = New Global.System.Drawing.Point(351, 415)
			btnReadAuth.Location = point
			Me.btnReadAuth.Name = "btnReadAuth"
			Me.btnReadAuth.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim btnReadAuth2 As Global.System.Windows.Forms.Control = Me.btnReadAuth
			size = New Global.System.Drawing.Size(81, 41)
			btnReadAuth2.Size = size
			Me.btnReadAuth.TabIndex = 6
			Me.btnReadAuth.Text = "ReadAuth"
			Me.btnReadAuth.UseVisualStyleBackColor = False
			Me.btnCheckLink.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnCheckLink.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.btnCheckLink.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnCheckLink.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim btnCheckLink As Global.System.Windows.Forms.Control = Me.btnCheckLink
			point = New Global.System.Drawing.Point(437, 415)
			btnCheckLink.Location = point
			Me.btnCheckLink.Name = "btnCheckLink"
			Me.btnCheckLink.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim btnCheckLink2 As Global.System.Windows.Forms.Control = Me.btnCheckLink
			size = New Global.System.Drawing.Size(81, 41)
			btnCheckLink2.Size = size
			Me.btnCheckLink.TabIndex = 5
			Me.btnCheckLink.Text = "CheckLink"
			Me.btnCheckLink.UseVisualStyleBackColor = False
			Me.btnCheckCard.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnCheckCard.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.btnCheckCard.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnCheckCard.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim btnCheckCard As Global.System.Windows.Forms.Control = Me.btnCheckCard
			point = New Global.System.Drawing.Point(263, 415)
			btnCheckCard.Location = point
			Me.btnCheckCard.Name = "btnCheckCard"
			Me.btnCheckCard.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim btnCheckCard2 As Global.System.Windows.Forms.Control = Me.btnCheckCard
			size = New Global.System.Drawing.Size(81, 41)
			btnCheckCard2.Size = size
			Me.btnCheckCard.TabIndex = 4
			Me.btnCheckCard.Text = "CheckCard"
			Me.btnCheckCard.UseVisualStyleBackColor = False
			Me.btnGetNewAuth.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnGetNewAuth.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.btnGetNewAuth.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnGetNewAuth.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim btnGetNewAuth As Global.System.Windows.Forms.Control = Me.btnGetNewAuth
			point = New Global.System.Drawing.Point(523, 415)
			btnGetNewAuth.Location = point
			Me.btnGetNewAuth.Name = "btnGetNewAuth"
			Me.btnGetNewAuth.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim btnGetNewAuth2 As Global.System.Windows.Forms.Control = Me.btnGetNewAuth
			size = New Global.System.Drawing.Size(81, 41)
			btnGetNewAuth2.Size = size
			Me.btnGetNewAuth.TabIndex = 3
			Me.btnGetNewAuth.Text = "GetNewAuth"
			Me.btnGetNewAuth.UseVisualStyleBackColor = False
			Me.btnCancelCard.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnCancelCard.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.btnCancelCard.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnCancelCard.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim btnCancelCard As Global.System.Windows.Forms.Control = Me.btnCancelCard
			point = New Global.System.Drawing.Point(176, 415)
			btnCancelCard.Location = point
			Me.btnCancelCard.Name = "btnCancelCard"
			Me.btnCancelCard.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim btnCancelCard2 As Global.System.Windows.Forms.Control = Me.btnCancelCard
			size = New Global.System.Drawing.Size(81, 41)
			btnCancelCard2.Size = size
			Me.btnCancelCard.TabIndex = 2
			Me.btnCancelCard.Text = "CancelCard"
			Me.btnCancelCard.UseVisualStyleBackColor = False
			Me.btnIssueCard.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnIssueCard.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.btnIssueCard.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnIssueCard.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim btnIssueCard As Global.System.Windows.Forms.Control = Me.btnIssueCard
			point = New Global.System.Drawing.Point(91, 415)
			btnIssueCard.Location = point
			Me.btnIssueCard.Name = "btnIssueCard"
			Me.btnIssueCard.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim btnIssueCard2 As Global.System.Windows.Forms.Control = Me.btnIssueCard
			size = New Global.System.Drawing.Size(81, 41)
			btnIssueCard2.Size = size
			Me.btnIssueCard.TabIndex = 1
			Me.btnIssueCard.Text = "IssueCard"
			Me.btnIssueCard.UseVisualStyleBackColor = False
			Me.btnReadCard.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnReadCard.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.btnReadCard.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnReadCard.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim btnReadCard As Global.System.Windows.Forms.Control = Me.btnReadCard
			point = New Global.System.Drawing.Point(7, 415)
			btnReadCard.Location = point
			Me.btnReadCard.Name = "btnReadCard"
			Me.btnReadCard.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim btnReadCard2 As Global.System.Windows.Forms.Control = Me.btnReadCard
			size = New Global.System.Drawing.Size(81, 41)
			btnReadCard2.Size = size
			Me.btnReadCard.TabIndex = 0
			Me.btnReadCard.Text = "ReadCard"
			Me.btnReadCard.UseVisualStyleBackColor = False
			Me.Label16.BackColor = Global.System.Drawing.SystemColors.Control
			Me.Label16.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Label16.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label16.ForeColor = Global.System.Drawing.SystemColors.ControlText
			Dim label23 As Global.System.Windows.Forms.Control = Me.Label16
			point = New Global.System.Drawing.Point(320, 16)
			label23.Location = point
			Me.Label16.Name = "Label16"
			Me.Label16.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Dim label24 As Global.System.Windows.Forms.Control = Me.Label16
			size = New Global.System.Drawing.Size(81, 17)
			label24.Size = size
			Me.Label16.TabIndex = 42
			Me.Label16.Text = "Lock Type"
			Me.cboLockType.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cboLockType.FormattingEnabled = True
			Me.cboLockType.Items.AddRange(New Object() { "Not support", "Old IC Lock", "C IC Lock", "Temic Lock", "Mifare Lock", "iButton Lock", "Magnetic Lock" })
			Dim cboLockType As Global.System.Windows.Forms.Control = Me.cboLockType
			point = New Global.System.Drawing.Point(386, 14)
			cboLockType.Location = point
			Me.cboLockType.Name = "cboLockType"
			Dim cboLockType2 As Global.System.Windows.Forms.Control = Me.cboLockType
			size = New Global.System.Drawing.Size(281, 22)
			cboLockType2.Size = size
			Me.cboLockType.TabIndex = 48
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(615, 320)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(75, 44)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 49
			Me.btnExit.Text = "Exit"
			Me.btnExit.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(6F, 14F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			Me.BackColor = Global.System.Drawing.SystemColors.Control
			size = New Global.System.Drawing.Size(712, 467)
			Me.ClientSize = size
			Me.Controls.Add(Me.btnExit)
			Me.Controls.Add(Me.cboLockType)
			Me.Controls.Add(Me.btnForceCancel)
			Me.Controls.Add(Me.ProgressBar1)
			Me.Controls.Add(Me.Frame2)
			Me.Controls.Add(Me.btnReadAuth)
			Me.Controls.Add(Me.btnCheckLink)
			Me.Controls.Add(Me.btnCheckCard)
			Me.Controls.Add(Me.btnGetNewAuth)
			Me.Controls.Add(Me.btnCancelCard)
			Me.Controls.Add(Me.btnIssueCard)
			Me.Controls.Add(Me.btnReadCard)
			Me.Controls.Add(Me.Label16)
			Me.Cursor = Global.System.Windows.Forms.Cursors.[Default]
			Me.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			point = New Global.System.Drawing.Point(4, 23)
			Me.Location = point
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmCard"
			Me.RightToLeft = Global.System.Windows.Forms.RightToLeft.No
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Hotel Reader Manager"
			Me.Frame2.ResumeLayout(False)
			Me.Frame2.PerformLayout()
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x04000204 RID: 516
		Private components As Global.System.ComponentModel.IContainer

		' Token: 0x04000205 RID: 517
		Public ToolTip1 As Global.System.Windows.Forms.ToolTip
	End Class
End Namespace
