﻿Namespace prjIS_SalesPOS
	' Token: 0x02000027 RID: 39
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCOMBO
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600076A RID: 1898 RVA: 0x00057320 File Offset: 0x00055520
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600076B RID: 1899 RVA: 0x00057358 File Offset: 0x00055558
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCOMBO))
			Me.lblPosition = New Global.System.Windows.Forms.Label()
			Me.btnLast = New Global.System.Windows.Forms.Button()
			Me.btnNext = New Global.System.Windows.Forms.Button()
			Me.grpNavigater = New Global.System.Windows.Forms.GroupBox()
			Me.btnFirst = New Global.System.Windows.Forms.Button()
			Me.btnPrevious = New Global.System.Windows.Forms.Button()
			Me.grpControl = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSelect = New Global.System.Windows.Forms.Button()
			Me.dgvData = New Global.System.Windows.Forms.DataGridView()
			Me.grpNavigater.SuspendLayout()
			Me.grpControl.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.lblPosition.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.lblPosition.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblPosition.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPosition As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(84, 14)
			lblPosition.Location = point
			Me.lblPosition.Name = "lblPosition"
			Dim lblPosition2 As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(93, 35)
			lblPosition2.Size = size
			Me.lblPosition.TabIndex = 6
			Me.lblPosition.Tag = "0R0000"
			Me.lblPosition.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btnLast.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.toi
			Me.btnLast.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Center
			Dim btnLast As Global.System.Windows.Forms.Control = Me.btnLast
			point = New Global.System.Drawing.Point(215, 14)
			btnLast.Location = point
			Me.btnLast.Name = "btnLast"
			Dim btnLast2 As Global.System.Windows.Forms.Control = Me.btnLast
			size = New Global.System.Drawing.Size(40, 35)
			btnLast2.Size = size
			Me.btnLast.TabIndex = 5
			Me.btnLast.UseVisualStyleBackColor = True
			Me.btnNext.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.toi
			Me.btnNext.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Center
			Dim btnNext As Global.System.Windows.Forms.Control = Me.btnNext
			point = New Global.System.Drawing.Point(176, 14)
			btnNext.Location = point
			Me.btnNext.Name = "btnNext"
			Dim btnNext2 As Global.System.Windows.Forms.Control = Me.btnNext
			size = New Global.System.Drawing.Size(40, 35)
			btnNext2.Size = size
			Me.btnNext.TabIndex = 4
			Me.btnNext.UseVisualStyleBackColor = True
			Me.grpNavigater.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom
			Me.grpNavigater.Controls.Add(Me.lblPosition)
			Me.grpNavigater.Controls.Add(Me.btnFirst)
			Me.grpNavigater.Controls.Add(Me.btnPrevious)
			Me.grpNavigater.Controls.Add(Me.btnLast)
			Me.grpNavigater.Controls.Add(Me.btnNext)
			Dim grpNavigater As Global.System.Windows.Forms.Control = Me.grpNavigater
			point = New Global.System.Drawing.Point(218, 453)
			grpNavigater.Location = point
			Me.grpNavigater.Name = "grpNavigater"
			Dim grpNavigater2 As Global.System.Windows.Forms.Control = Me.grpNavigater
			size = New Global.System.Drawing.Size(263, 60)
			grpNavigater2.Size = size
			Me.grpNavigater.TabIndex = 3
			Me.grpNavigater.TabStop = False
			Me.btnFirst.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.lui
			Me.btnFirst.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Center
			Dim btnFirst As Global.System.Windows.Forms.Control = Me.btnFirst
			point = New Global.System.Drawing.Point(6, 14)
			btnFirst.Location = point
			Me.btnFirst.Name = "btnFirst"
			Dim btnFirst2 As Global.System.Windows.Forms.Control = Me.btnFirst
			size = New Global.System.Drawing.Size(40, 35)
			btnFirst2.Size = size
			Me.btnFirst.TabIndex = 2
			Me.btnFirst.UseVisualStyleBackColor = True
			Me.btnPrevious.BackgroundImage = Global.prjIS_SalesPOS.My.Resources.Resources.lui
			Me.btnPrevious.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Center
			Dim btnPrevious As Global.System.Windows.Forms.Control = Me.btnPrevious
			point = New Global.System.Drawing.Point(45, 14)
			btnPrevious.Location = point
			Me.btnPrevious.Name = "btnPrevious"
			Dim btnPrevious2 As Global.System.Windows.Forms.Control = Me.btnPrevious
			size = New Global.System.Drawing.Size(40, 35)
			btnPrevious2.Size = size
			Me.btnPrevious.TabIndex = 3
			Me.btnPrevious.UseVisualStyleBackColor = True
			Me.grpControl.Controls.Add(Me.TableLayoutPanel1)
			Me.grpControl.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpControl As Global.System.Windows.Forms.Control = Me.grpControl
			point = New Global.System.Drawing.Point(687, 0)
			grpControl.Location = point
			Me.grpControl.Name = "grpControl"
			Dim grpControl2 As Global.System.Windows.Forms.Control = Me.grpControl
			size = New Global.System.Drawing.Size(119, 526)
			grpControl2.Size = size
			Me.grpControl.TabIndex = 2
			Me.grpControl.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 9)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSelect, 0, 0)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 10
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 10F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 10F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 10F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 10F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 10F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 10F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 10F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 10F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 10F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 10F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 505)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 453)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 49)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 12
			Me.btnExit.Tag = "CR0003"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnSelect.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Center
			Me.btnSelect.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSelect.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnSelect As Global.System.Windows.Forms.Control = Me.btnSelect
			point = New Global.System.Drawing.Point(3, 3)
			btnSelect.Location = point
			Me.btnSelect.Name = "btnSelect"
			Dim btnSelect2 As Global.System.Windows.Forms.Control = Me.btnSelect
			size = New Global.System.Drawing.Size(107, 44)
			btnSelect2.Size = size
			Me.btnSelect.TabIndex = 13
			Me.btnSelect.Tag = "CR0013"
			Me.btnSelect.Text = "chon"
			Me.btnSelect.UseVisualStyleBackColor = True
			Me.dgvData.AllowUserToAddRows = False
			Me.dgvData.AllowUserToDeleteRows = False
			Me.dgvData.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvData.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvData As Global.System.Windows.Forms.Control = Me.dgvData
			point = New Global.System.Drawing.Point(0, 0)
			dgvData.Location = point
			Me.dgvData.Name = "dgvData"
			Me.dgvData.[ReadOnly] = True
			Dim dgvData2 As Global.System.Windows.Forms.Control = Me.dgvData
			size = New Global.System.Drawing.Size(684, 447)
			dgvData2.Size = size
			Me.dgvData.TabIndex = 1
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(806, 526)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.dgvData)
			Me.Controls.Add(Me.grpNavigater)
			Me.Controls.Add(Me.grpControl)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmCOMBO"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "frmDOCUMENT017"
			Me.grpNavigater.ResumeLayout(False)
			Me.grpControl.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x04000342 RID: 834
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
