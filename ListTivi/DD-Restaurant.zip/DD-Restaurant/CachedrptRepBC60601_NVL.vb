﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200025A RID: 602
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60601_NVL
		Inherits Component
		Implements ICachedReport

		' Token: 0x060064F7 RID: 25847 RVA: 0x000122C9 File Offset: 0x000104C9
		Public Sub New()
			CachedrptRepBC60601_NVL.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x170026E4 RID: 9956
		' (get) Token: 0x060064F8 RID: 25848 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x060064F9 RID: 25849 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170026E5 RID: 9957
		' (get) Token: 0x060064FA RID: 25850 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x060064FB RID: 25851 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x170026E6 RID: 9958
		' (get) Token: 0x060064FC RID: 25852 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x060064FD RID: 25853 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x060064FE RID: 25854 RVA: 0x004DD6A0 File Offset: 0x004DB8A0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60601_NVL() With { .Site = Me.Site }
		End Function

		' Token: 0x060064FF RID: 25855 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002852 RID: 10322
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
