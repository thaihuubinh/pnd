﻿Namespace prjIS_SalesPOS
	' Token: 0x0200001F RID: 31
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCashSongSong
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x0600050D RID: 1293 RVA: 0x0003BC30 File Offset: 0x00039E30
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x0600050E RID: 1294 RVA: 0x0003BC68 File Offset: 0x00039E68
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCashSongSong))
			Me.btnSelect = New Global.System.Windows.Forms.Button()
			Me.TableLayoutPanel5 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.TableLayoutPanel3 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.lbl8 = New Global.System.Windows.Forms.Label()
			Me.lbl9 = New Global.System.Windows.Forms.Label()
			Me.lbl13 = New Global.System.Windows.Forms.Label()
			Me.lbl11 = New Global.System.Windows.Forms.Label()
			Me.lbl10 = New Global.System.Windows.Forms.Label()
			Me.lbl12 = New Global.System.Windows.Forms.Label()
			Me.lbl14 = New Global.System.Windows.Forms.Label()
			Me.btn8 = New Global.System.Windows.Forms.Button()
			Me.btn9 = New Global.System.Windows.Forms.Button()
			Me.btn10 = New Global.System.Windows.Forms.Button()
			Me.btn11 = New Global.System.Windows.Forms.Button()
			Me.btn12 = New Global.System.Windows.Forms.Button()
			Me.btn13 = New Global.System.Windows.Forms.Button()
			Me.btn14 = New Global.System.Windows.Forms.Button()
			Me.TableLayoutPanel2 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.lbl1 = New Global.System.Windows.Forms.Label()
			Me.lbl2 = New Global.System.Windows.Forms.Label()
			Me.lbl4 = New Global.System.Windows.Forms.Label()
			Me.lbl6 = New Global.System.Windows.Forms.Label()
			Me.lbl3 = New Global.System.Windows.Forms.Label()
			Me.lbl5 = New Global.System.Windows.Forms.Label()
			Me.lbl7 = New Global.System.Windows.Forms.Label()
			Me.btn1 = New Global.System.Windows.Forms.Button()
			Me.btn2 = New Global.System.Windows.Forms.Button()
			Me.btn3 = New Global.System.Windows.Forms.Button()
			Me.btn4 = New Global.System.Windows.Forms.Button()
			Me.btn5 = New Global.System.Windows.Forms.Button()
			Me.btn6 = New Global.System.Windows.Forms.Button()
			Me.btn7 = New Global.System.Windows.Forms.Button()
			Me.TableLayoutPanel5.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.TableLayoutPanel3.SuspendLayout()
			Me.TableLayoutPanel2.SuspendLayout()
			Me.SuspendLayout()
			Me.btnSelect.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnSelect.BackgroundImage = CType(componentResourceManager.GetObject("btnSelect.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnSelect.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnSelect.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSelect.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnSelect.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnSelect.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnSelect.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Me.btnSelect.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnSelect As Global.System.Windows.Forms.Control = Me.btnSelect
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(309, 3)
			btnSelect.Location = point
			Me.btnSelect.Name = "btnSelect"
			Dim btnSelect2 As Global.System.Windows.Forms.Control = Me.btnSelect
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(147, 38)
			btnSelect2.Size = size
			Me.btnSelect.TabIndex = 3
			Me.btnSelect.Tag = "C14B0007"
			Me.btnSelect.Text = "Chọn"
			Me.btnSelect.UseVisualStyleBackColor = False
			Me.TableLayoutPanel5.ColumnCount = 4
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 25F))
			Me.TableLayoutPanel5.Controls.Add(Me.btnExit, 3, 0)
			Me.TableLayoutPanel5.Controls.Add(Me.btnSelect, 2, 0)
			Me.TableLayoutPanel5.Dock = Global.System.Windows.Forms.DockStyle.Bottom
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel5
			point = New Global.System.Drawing.Point(0, 389)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
			Me.TableLayoutPanel5.RowCount = 1
			Me.TableLayoutPanel5.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel5
			size = New Global.System.Drawing.Size(614, 44)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel5.TabIndex = 7
			Me.btnExit.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(462, 3)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(149, 38)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 3
			Me.btnExit.Tag = "C14B0008"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.UseVisualStyleBackColor = False
			Me.TableLayoutPanel1.ColumnCount = 3
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 50F))
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Absolute, 20F))
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 50F))
			Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel3, 2, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel2, 0, 0)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel3 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(0, 0)
			tableLayoutPanel3.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 1
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Dim tableLayoutPanel4 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(614, 389)
			tableLayoutPanel4.Size = size
			Me.TableLayoutPanel1.TabIndex = 8
			Me.TableLayoutPanel3.ColumnCount = 2
			Me.TableLayoutPanel3.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 50F))
			Me.TableLayoutPanel3.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 50F))
			Me.TableLayoutPanel3.Controls.Add(Me.lbl8, 0, 0)
			Me.TableLayoutPanel3.Controls.Add(Me.lbl9, 0, 1)
			Me.TableLayoutPanel3.Controls.Add(Me.lbl13, 0, 5)
			Me.TableLayoutPanel3.Controls.Add(Me.lbl11, 0, 3)
			Me.TableLayoutPanel3.Controls.Add(Me.lbl10, 0, 2)
			Me.TableLayoutPanel3.Controls.Add(Me.lbl12, 0, 4)
			Me.TableLayoutPanel3.Controls.Add(Me.lbl14, 0, 6)
			Me.TableLayoutPanel3.Controls.Add(Me.btn8, 1, 0)
			Me.TableLayoutPanel3.Controls.Add(Me.btn9, 1, 1)
			Me.TableLayoutPanel3.Controls.Add(Me.btn10, 1, 2)
			Me.TableLayoutPanel3.Controls.Add(Me.btn11, 1, 3)
			Me.TableLayoutPanel3.Controls.Add(Me.btn12, 1, 4)
			Me.TableLayoutPanel3.Controls.Add(Me.btn13, 1, 5)
			Me.TableLayoutPanel3.Controls.Add(Me.btn14, 1, 6)
			Me.TableLayoutPanel3.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel5 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel3
			point = New Global.System.Drawing.Point(320, 3)
			tableLayoutPanel5.Location = point
			Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
			Me.TableLayoutPanel3.RowCount = 7
			Me.TableLayoutPanel3.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel3.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel3.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel3.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel3.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel3.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel3.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Dim tableLayoutPanel6 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel3
			size = New Global.System.Drawing.Size(291, 383)
			tableLayoutPanel6.Size = size
			Me.TableLayoutPanel3.TabIndex = 1
			Me.lbl8.BackColor = Global.System.Drawing.Color.Silver
			Me.lbl8.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl8.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl8.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl As Global.System.Windows.Forms.Control = Me.lbl8
			point = New Global.System.Drawing.Point(3, 3)
			lbl.Location = point
			Dim lbl2 As Global.System.Windows.Forms.Control = Me.lbl8
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3)
			lbl2.Margin = padding
			Me.lbl8.Name = "lbl8"
			Dim lbl3 As Global.System.Windows.Forms.Control = Me.lbl8
			size = New Global.System.Drawing.Size(139, 48)
			lbl3.Size = size
			Me.lbl8.TabIndex = 0
			Me.lbl8.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl9.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.lbl9.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl9.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl9.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl4 As Global.System.Windows.Forms.Control = Me.lbl9
			point = New Global.System.Drawing.Point(3, 57)
			lbl4.Location = point
			Dim lbl5 As Global.System.Windows.Forms.Control = Me.lbl9
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl5.Margin = padding
			Me.lbl9.Name = "lbl9"
			Dim lbl6 As Global.System.Windows.Forms.Control = Me.lbl9
			size = New Global.System.Drawing.Size(139, 48)
			lbl6.Size = size
			Me.lbl9.TabIndex = 0
			Me.lbl9.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl13.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.lbl13.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl13.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl13.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl7 As Global.System.Windows.Forms.Control = Me.lbl13
			point = New Global.System.Drawing.Point(3, 273)
			lbl7.Location = point
			Dim lbl8 As Global.System.Windows.Forms.Control = Me.lbl13
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl8.Margin = padding
			Me.lbl13.Name = "lbl13"
			Dim lbl9 As Global.System.Windows.Forms.Control = Me.lbl13
			size = New Global.System.Drawing.Size(139, 48)
			lbl9.Size = size
			Me.lbl13.TabIndex = 0
			Me.lbl13.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl11.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.lbl11.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl11.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl11.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl10 As Global.System.Windows.Forms.Control = Me.lbl11
			point = New Global.System.Drawing.Point(3, 165)
			lbl10.Location = point
			Dim lbl11 As Global.System.Windows.Forms.Control = Me.lbl11
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl11.Margin = padding
			Me.lbl11.Name = "lbl11"
			Dim lbl12 As Global.System.Windows.Forms.Control = Me.lbl11
			size = New Global.System.Drawing.Size(139, 48)
			lbl12.Size = size
			Me.lbl11.TabIndex = 0
			Me.lbl11.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl10.BackColor = Global.System.Drawing.Color.Silver
			Me.lbl10.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl10.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl10.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl13 As Global.System.Windows.Forms.Control = Me.lbl10
			point = New Global.System.Drawing.Point(3, 111)
			lbl13.Location = point
			Dim lbl14 As Global.System.Windows.Forms.Control = Me.lbl10
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl14.Margin = padding
			Me.lbl10.Name = "lbl10"
			Dim lbl15 As Global.System.Windows.Forms.Control = Me.lbl10
			size = New Global.System.Drawing.Size(139, 48)
			lbl15.Size = size
			Me.lbl10.TabIndex = 0
			Me.lbl10.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl12.BackColor = Global.System.Drawing.Color.Silver
			Me.lbl12.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl12.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl12.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl16 As Global.System.Windows.Forms.Control = Me.lbl12
			point = New Global.System.Drawing.Point(3, 219)
			lbl16.Location = point
			Dim lbl17 As Global.System.Windows.Forms.Control = Me.lbl12
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl17.Margin = padding
			Me.lbl12.Name = "lbl12"
			Dim lbl18 As Global.System.Windows.Forms.Control = Me.lbl12
			size = New Global.System.Drawing.Size(139, 48)
			lbl18.Size = size
			Me.lbl12.TabIndex = 0
			Me.lbl12.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl14.BackColor = Global.System.Drawing.Color.Silver
			Me.lbl14.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl14.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl14.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl19 As Global.System.Windows.Forms.Control = Me.lbl14
			point = New Global.System.Drawing.Point(3, 327)
			lbl19.Location = point
			Dim lbl20 As Global.System.Windows.Forms.Control = Me.lbl14
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl20.Margin = padding
			Me.lbl14.Name = "lbl14"
			Dim lbl21 As Global.System.Windows.Forms.Control = Me.lbl14
			size = New Global.System.Drawing.Size(139, 53)
			lbl21.Size = size
			Me.lbl14.TabIndex = 0
			Me.lbl14.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btn8.BackColor = Global.System.Drawing.Color.White
			Me.btn8.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn8.Enabled = False
			Me.btn8.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn8.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn8.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn As Global.System.Windows.Forms.Control = Me.btn8
			point = New Global.System.Drawing.Point(148, 3)
			btn.Location = point
			Me.btn8.Name = "btn8"
			Dim btn2 As Global.System.Windows.Forms.Control = Me.btn8
			size = New Global.System.Drawing.Size(140, 48)
			btn2.Size = size
			Me.btn8.TabIndex = 1
			Me.btn8.Text = "0"
			Me.btn8.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn8.UseVisualStyleBackColor = False
			Me.btn9.BackColor = Global.System.Drawing.Color.White
			Me.btn9.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn9.Enabled = False
			Me.btn9.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn9.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn9.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn3 As Global.System.Windows.Forms.Control = Me.btn9
			point = New Global.System.Drawing.Point(148, 57)
			btn3.Location = point
			Me.btn9.Name = "btn9"
			Dim btn4 As Global.System.Windows.Forms.Control = Me.btn9
			size = New Global.System.Drawing.Size(140, 48)
			btn4.Size = size
			Me.btn9.TabIndex = 1
			Me.btn9.Text = "0"
			Me.btn9.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn9.UseVisualStyleBackColor = False
			Me.btn10.BackColor = Global.System.Drawing.Color.White
			Me.btn10.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn10.Enabled = False
			Me.btn10.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn10.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn10.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn5 As Global.System.Windows.Forms.Control = Me.btn10
			point = New Global.System.Drawing.Point(148, 111)
			btn5.Location = point
			Me.btn10.Name = "btn10"
			Dim btn6 As Global.System.Windows.Forms.Control = Me.btn10
			size = New Global.System.Drawing.Size(140, 48)
			btn6.Size = size
			Me.btn10.TabIndex = 1
			Me.btn10.Text = "0"
			Me.btn10.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn10.UseVisualStyleBackColor = False
			Me.btn11.BackColor = Global.System.Drawing.Color.White
			Me.btn11.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn11.Enabled = False
			Me.btn11.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn11.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn11.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn7 As Global.System.Windows.Forms.Control = Me.btn11
			point = New Global.System.Drawing.Point(148, 165)
			btn7.Location = point
			Me.btn11.Name = "btn11"
			Dim btn8 As Global.System.Windows.Forms.Control = Me.btn11
			size = New Global.System.Drawing.Size(140, 48)
			btn8.Size = size
			Me.btn11.TabIndex = 1
			Me.btn11.Text = "0"
			Me.btn11.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn11.UseVisualStyleBackColor = False
			Me.btn12.BackColor = Global.System.Drawing.Color.White
			Me.btn12.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn12.Enabled = False
			Me.btn12.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn12.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn12.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn9 As Global.System.Windows.Forms.Control = Me.btn12
			point = New Global.System.Drawing.Point(148, 219)
			btn9.Location = point
			Me.btn12.Name = "btn12"
			Dim btn10 As Global.System.Windows.Forms.Control = Me.btn12
			size = New Global.System.Drawing.Size(140, 48)
			btn10.Size = size
			Me.btn12.TabIndex = 1
			Me.btn12.Text = "0"
			Me.btn12.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn12.UseVisualStyleBackColor = False
			Me.btn13.BackColor = Global.System.Drawing.Color.White
			Me.btn13.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn13.Enabled = False
			Me.btn13.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn13.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn13.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn11 As Global.System.Windows.Forms.Control = Me.btn13
			point = New Global.System.Drawing.Point(148, 273)
			btn11.Location = point
			Me.btn13.Name = "btn13"
			Dim btn12 As Global.System.Windows.Forms.Control = Me.btn13
			size = New Global.System.Drawing.Size(140, 48)
			btn12.Size = size
			Me.btn13.TabIndex = 1
			Me.btn13.Text = "0"
			Me.btn13.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn13.UseVisualStyleBackColor = False
			Me.btn14.BackColor = Global.System.Drawing.Color.White
			Me.btn14.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn14.Enabled = False
			Me.btn14.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn14.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn14.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn13 As Global.System.Windows.Forms.Control = Me.btn14
			point = New Global.System.Drawing.Point(148, 327)
			btn13.Location = point
			Me.btn14.Name = "btn14"
			Dim btn14 As Global.System.Windows.Forms.Control = Me.btn14
			size = New Global.System.Drawing.Size(140, 53)
			btn14.Size = size
			Me.btn14.TabIndex = 1
			Me.btn14.Text = "0"
			Me.btn14.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn14.UseVisualStyleBackColor = False
			Me.TableLayoutPanel2.ColumnCount = 2
			Me.TableLayoutPanel2.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 50F))
			Me.TableLayoutPanel2.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 50F))
			Me.TableLayoutPanel2.Controls.Add(Me.lbl1, 0, 0)
			Me.TableLayoutPanel2.Controls.Add(Me.lbl2, 0, 1)
			Me.TableLayoutPanel2.Controls.Add(Me.lbl4, 0, 3)
			Me.TableLayoutPanel2.Controls.Add(Me.lbl6, 0, 5)
			Me.TableLayoutPanel2.Controls.Add(Me.lbl3, 0, 2)
			Me.TableLayoutPanel2.Controls.Add(Me.lbl5, 0, 4)
			Me.TableLayoutPanel2.Controls.Add(Me.lbl7, 0, 6)
			Me.TableLayoutPanel2.Controls.Add(Me.btn1, 1, 0)
			Me.TableLayoutPanel2.Controls.Add(Me.btn2, 1, 1)
			Me.TableLayoutPanel2.Controls.Add(Me.btn3, 1, 2)
			Me.TableLayoutPanel2.Controls.Add(Me.btn4, 1, 3)
			Me.TableLayoutPanel2.Controls.Add(Me.btn5, 1, 4)
			Me.TableLayoutPanel2.Controls.Add(Me.btn6, 1, 5)
			Me.TableLayoutPanel2.Controls.Add(Me.btn7, 1, 6)
			Me.TableLayoutPanel2.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel7 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel2
			point = New Global.System.Drawing.Point(3, 3)
			tableLayoutPanel7.Location = point
			Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
			Me.TableLayoutPanel2.RowCount = 7
			Me.TableLayoutPanel2.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel2.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel2.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel2.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel2.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel2.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Me.TableLayoutPanel2.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 14.28571F))
			Dim tableLayoutPanel8 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel2
			size = New Global.System.Drawing.Size(291, 383)
			tableLayoutPanel8.Size = size
			Me.TableLayoutPanel2.TabIndex = 0
			Me.lbl1.BackColor = Global.System.Drawing.Color.Silver
			Me.lbl1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl1.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl1.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl22 As Global.System.Windows.Forms.Control = Me.lbl1
			point = New Global.System.Drawing.Point(3, 3)
			lbl22.Location = point
			Dim lbl23 As Global.System.Windows.Forms.Control = Me.lbl1
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl23.Margin = padding
			Me.lbl1.Name = "lbl1"
			Dim lbl24 As Global.System.Windows.Forms.Control = Me.lbl1
			size = New Global.System.Drawing.Size(139, 48)
			lbl24.Size = size
			Me.lbl1.TabIndex = 0
			Me.lbl1.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl2.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.lbl2.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl2.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl2.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl25 As Global.System.Windows.Forms.Control = Me.lbl2
			point = New Global.System.Drawing.Point(3, 57)
			lbl25.Location = point
			Dim lbl26 As Global.System.Windows.Forms.Control = Me.lbl2
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl26.Margin = padding
			Me.lbl2.Name = "lbl2"
			Dim lbl27 As Global.System.Windows.Forms.Control = Me.lbl2
			size = New Global.System.Drawing.Size(139, 48)
			lbl27.Size = size
			Me.lbl2.TabIndex = 0
			Me.lbl2.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl4.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.lbl4.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl4.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl4.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl28 As Global.System.Windows.Forms.Control = Me.lbl4
			point = New Global.System.Drawing.Point(3, 165)
			lbl28.Location = point
			Dim lbl29 As Global.System.Windows.Forms.Control = Me.lbl4
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl29.Margin = padding
			Me.lbl4.Name = "lbl4"
			Dim lbl30 As Global.System.Windows.Forms.Control = Me.lbl4
			size = New Global.System.Drawing.Size(139, 48)
			lbl30.Size = size
			Me.lbl4.TabIndex = 0
			Me.lbl4.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl6.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.lbl6.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl6.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl6.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl31 As Global.System.Windows.Forms.Control = Me.lbl6
			point = New Global.System.Drawing.Point(3, 273)
			lbl31.Location = point
			Dim lbl32 As Global.System.Windows.Forms.Control = Me.lbl6
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl32.Margin = padding
			Me.lbl6.Name = "lbl6"
			Dim lbl33 As Global.System.Windows.Forms.Control = Me.lbl6
			size = New Global.System.Drawing.Size(139, 48)
			lbl33.Size = size
			Me.lbl6.TabIndex = 0
			Me.lbl6.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl3.BackColor = Global.System.Drawing.Color.Silver
			Me.lbl3.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl3.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl3.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl34 As Global.System.Windows.Forms.Control = Me.lbl3
			point = New Global.System.Drawing.Point(3, 111)
			lbl34.Location = point
			Dim lbl35 As Global.System.Windows.Forms.Control = Me.lbl3
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl35.Margin = padding
			Me.lbl3.Name = "lbl3"
			Dim lbl36 As Global.System.Windows.Forms.Control = Me.lbl3
			size = New Global.System.Drawing.Size(139, 48)
			lbl36.Size = size
			Me.lbl3.TabIndex = 0
			Me.lbl3.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl5.BackColor = Global.System.Drawing.Color.Silver
			Me.lbl5.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl5.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl5.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl37 As Global.System.Windows.Forms.Control = Me.lbl5
			point = New Global.System.Drawing.Point(3, 219)
			lbl37.Location = point
			Dim lbl38 As Global.System.Windows.Forms.Control = Me.lbl5
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl38.Margin = padding
			Me.lbl5.Name = "lbl5"
			Dim lbl39 As Global.System.Windows.Forms.Control = Me.lbl5
			size = New Global.System.Drawing.Size(139, 48)
			lbl39.Size = size
			Me.lbl5.TabIndex = 0
			Me.lbl5.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.lbl7.BackColor = Global.System.Drawing.Color.Silver
			Me.lbl7.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.lbl7.Font = New Global.System.Drawing.Font("Tahoma", 16F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.lbl7.ForeColor = Global.System.Drawing.Color.Black
			Dim lbl40 As Global.System.Windows.Forms.Control = Me.lbl7
			point = New Global.System.Drawing.Point(3, 327)
			lbl40.Location = point
			Dim lbl41 As Global.System.Windows.Forms.Control = Me.lbl7
			padding = New Global.System.Windows.Forms.Padding(3)
			lbl41.Margin = padding
			Me.lbl7.Name = "lbl7"
			Dim lbl42 As Global.System.Windows.Forms.Control = Me.lbl7
			size = New Global.System.Drawing.Size(139, 53)
			lbl42.Size = size
			Me.lbl7.TabIndex = 0
			Me.lbl7.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btn1.BackColor = Global.System.Drawing.Color.FromArgb(192, 192, 255)
			Me.btn1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn1.Enabled = False
			Me.btn1.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn1.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn1.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn15 As Global.System.Windows.Forms.Control = Me.btn1
			point = New Global.System.Drawing.Point(148, 3)
			btn15.Location = point
			Me.btn1.Name = "btn1"
			Dim btn16 As Global.System.Windows.Forms.Control = Me.btn1
			size = New Global.System.Drawing.Size(140, 48)
			btn16.Size = size
			Me.btn1.TabIndex = 1
			Me.btn1.Text = "0"
			Me.btn1.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn1.UseVisualStyleBackColor = False
			Me.btn2.BackColor = Global.System.Drawing.Color.White
			Me.btn2.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn2.Enabled = False
			Me.btn2.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn2.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn2.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn17 As Global.System.Windows.Forms.Control = Me.btn2
			point = New Global.System.Drawing.Point(148, 57)
			btn17.Location = point
			Me.btn2.Name = "btn2"
			Dim btn18 As Global.System.Windows.Forms.Control = Me.btn2
			size = New Global.System.Drawing.Size(140, 48)
			btn18.Size = size
			Me.btn2.TabIndex = 1
			Me.btn2.Text = "0"
			Me.btn2.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn2.UseVisualStyleBackColor = False
			Me.btn3.BackColor = Global.System.Drawing.Color.White
			Me.btn3.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn3.Enabled = False
			Me.btn3.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn3.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn3.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn19 As Global.System.Windows.Forms.Control = Me.btn3
			point = New Global.System.Drawing.Point(148, 111)
			btn19.Location = point
			Me.btn3.Name = "btn3"
			Dim btn20 As Global.System.Windows.Forms.Control = Me.btn3
			size = New Global.System.Drawing.Size(140, 48)
			btn20.Size = size
			Me.btn3.TabIndex = 1
			Me.btn3.Text = "0"
			Me.btn3.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn3.UseVisualStyleBackColor = False
			Me.btn4.BackColor = Global.System.Drawing.Color.White
			Me.btn4.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn4.Enabled = False
			Me.btn4.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn4.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn4.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn21 As Global.System.Windows.Forms.Control = Me.btn4
			point = New Global.System.Drawing.Point(148, 165)
			btn21.Location = point
			Me.btn4.Name = "btn4"
			Dim btn22 As Global.System.Windows.Forms.Control = Me.btn4
			size = New Global.System.Drawing.Size(140, 48)
			btn22.Size = size
			Me.btn4.TabIndex = 1
			Me.btn4.Text = "0"
			Me.btn4.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn4.UseVisualStyleBackColor = False
			Me.btn5.BackColor = Global.System.Drawing.Color.White
			Me.btn5.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn5.Enabled = False
			Me.btn5.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn5.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn5.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn23 As Global.System.Windows.Forms.Control = Me.btn5
			point = New Global.System.Drawing.Point(148, 219)
			btn23.Location = point
			Me.btn5.Name = "btn5"
			Dim btn24 As Global.System.Windows.Forms.Control = Me.btn5
			size = New Global.System.Drawing.Size(140, 48)
			btn24.Size = size
			Me.btn5.TabIndex = 1
			Me.btn5.Text = "0"
			Me.btn5.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn5.UseVisualStyleBackColor = False
			Me.btn6.BackColor = Global.System.Drawing.Color.White
			Me.btn6.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn6.Enabled = False
			Me.btn6.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn6.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn6.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn25 As Global.System.Windows.Forms.Control = Me.btn6
			point = New Global.System.Drawing.Point(148, 273)
			btn25.Location = point
			Me.btn6.Name = "btn6"
			Dim btn26 As Global.System.Windows.Forms.Control = Me.btn6
			size = New Global.System.Drawing.Size(140, 48)
			btn26.Size = size
			Me.btn6.TabIndex = 1
			Me.btn6.Text = "0"
			Me.btn6.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn6.UseVisualStyleBackColor = False
			Me.btn7.BackColor = Global.System.Drawing.Color.White
			Me.btn7.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btn7.Enabled = False
			Me.btn7.FlatAppearance.BorderColor = Global.System.Drawing.Color.Gray
			Me.btn7.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.btn7.Font = New Global.System.Drawing.Font("Tahoma", 13F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btn27 As Global.System.Windows.Forms.Control = Me.btn7
			point = New Global.System.Drawing.Point(148, 327)
			btn27.Location = point
			Me.btn7.Name = "btn7"
			Dim btn28 As Global.System.Windows.Forms.Control = Me.btn7
			size = New Global.System.Drawing.Size(140, 53)
			btn28.Size = size
			Me.btn7.TabIndex = 1
			Me.btn7.Text = "0"
			Me.btn7.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btn7.UseVisualStyleBackColor = False
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(614, 433)
			Me.ClientSize = size
			Me.Controls.Add(Me.TableLayoutPanel1)
			Me.Controls.Add(Me.TableLayoutPanel5)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Me.Name = "frmCashSongSong"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Thanh toán song song"
			Me.TableLayoutPanel5.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.TableLayoutPanel3.ResumeLayout(False)
			Me.TableLayoutPanel2.ResumeLayout(False)
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x0400022C RID: 556
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
