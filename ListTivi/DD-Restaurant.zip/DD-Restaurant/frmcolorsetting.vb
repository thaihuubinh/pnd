﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000026 RID: 38
	<DesignerGenerated()>
	Public Partial Class frmcolorsetting
		Inherits Form

		' Token: 0x060006F3 RID: 1779 RVA: 0x00052EE4 File Offset: 0x000510E4
		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.frmcolorsetting_Load
			frmcolorsetting.__ENCList.Add(New WeakReference(Me))
			Me.mblnSetDefault = False
			Me.mblnResult = False
			Me.mbytAplly = 0
			Me.InitializeComponent()
		End Sub

		' Token: 0x170002A2 RID: 674
		' (get) Token: 0x060006F6 RID: 1782 RVA: 0x000558B8 File Offset: 0x00053AB8
		' (set) Token: 0x060006F7 RID: 1783 RVA: 0x000558D0 File Offset: 0x00053AD0
		Friend Overridable Property btnok As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnok
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnok IsNot Nothing
				If flag Then
					RemoveHandler Me._btnok.Click, AddressOf Me.btnOk_Click
				End If
				Me._btnok = value
				flag = Me._btnok IsNot Nothing
				If flag Then
					AddHandler Me._btnok.Click, AddressOf Me.btnOk_Click
				End If
			End Set
		End Property

		' Token: 0x170002A3 RID: 675
		' (get) Token: 0x060006F8 RID: 1784 RVA: 0x0005593C File Offset: 0x00053B3C
		' (set) Token: 0x060006F9 RID: 1785 RVA: 0x0000335B File Offset: 0x0000155B
		Friend Overridable Property Tblpanelcolor As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._Tblpanelcolor
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._Tblpanelcolor = value
			End Set
		End Property

		' Token: 0x170002A4 RID: 676
		' (get) Token: 0x060006FA RID: 1786 RVA: 0x00055954 File Offset: 0x00053B54
		' (set) Token: 0x060006FB RID: 1787 RVA: 0x0005596C File Offset: 0x00053B6C
		Friend Overridable Property btncolor38 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor38
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor38 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor38.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor38 = value
				flag = Me._btncolor38 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor38.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002A5 RID: 677
		' (get) Token: 0x060006FC RID: 1788 RVA: 0x000559D8 File Offset: 0x00053BD8
		' (set) Token: 0x060006FD RID: 1789 RVA: 0x000559F0 File Offset: 0x00053BF0
		Friend Overridable Property btncolor39 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor39
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor39 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor39.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor39 = value
				flag = Me._btncolor39 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor39.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002A6 RID: 678
		' (get) Token: 0x060006FE RID: 1790 RVA: 0x00055A5C File Offset: 0x00053C5C
		' (set) Token: 0x060006FF RID: 1791 RVA: 0x00055A74 File Offset: 0x00053C74
		Friend Overridable Property btncolor1 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor1 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor1.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor1 = value
				flag = Me._btncolor1 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor1.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002A7 RID: 679
		' (get) Token: 0x06000700 RID: 1792 RVA: 0x00055AE0 File Offset: 0x00053CE0
		' (set) Token: 0x06000701 RID: 1793 RVA: 0x00055AF8 File Offset: 0x00053CF8
		Friend Overridable Property btncolor40 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor40
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor40 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor40.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor40 = value
				flag = Me._btncolor40 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor40.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002A8 RID: 680
		' (get) Token: 0x06000702 RID: 1794 RVA: 0x00055B64 File Offset: 0x00053D64
		' (set) Token: 0x06000703 RID: 1795 RVA: 0x00055B7C File Offset: 0x00053D7C
		Friend Overridable Property btncolor2 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor2 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor2.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor2 = value
				flag = Me._btncolor2 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor2.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002A9 RID: 681
		' (get) Token: 0x06000704 RID: 1796 RVA: 0x00055BE8 File Offset: 0x00053DE8
		' (set) Token: 0x06000705 RID: 1797 RVA: 0x00055C00 File Offset: 0x00053E00
		Friend Overridable Property btncolor37 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor37
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor37 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor37.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor37 = value
				flag = Me._btncolor37 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor37.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002AA RID: 682
		' (get) Token: 0x06000706 RID: 1798 RVA: 0x00055C6C File Offset: 0x00053E6C
		' (set) Token: 0x06000707 RID: 1799 RVA: 0x00055C84 File Offset: 0x00053E84
		Friend Overridable Property btncolor3 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor3 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor3.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor3 = value
				flag = Me._btncolor3 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor3.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002AB RID: 683
		' (get) Token: 0x06000708 RID: 1800 RVA: 0x00055CF0 File Offset: 0x00053EF0
		' (set) Token: 0x06000709 RID: 1801 RVA: 0x00055D08 File Offset: 0x00053F08
		Friend Overridable Property btncolor36 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor36
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor36 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor36.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor36 = value
				flag = Me._btncolor36 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor36.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002AC RID: 684
		' (get) Token: 0x0600070A RID: 1802 RVA: 0x00055D74 File Offset: 0x00053F74
		' (set) Token: 0x0600070B RID: 1803 RVA: 0x00055D8C File Offset: 0x00053F8C
		Friend Overridable Property btncolor4 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor4 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor4.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor4 = value
				flag = Me._btncolor4 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor4.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002AD RID: 685
		' (get) Token: 0x0600070C RID: 1804 RVA: 0x00055DF8 File Offset: 0x00053FF8
		' (set) Token: 0x0600070D RID: 1805 RVA: 0x00055E10 File Offset: 0x00054010
		Friend Overridable Property btncolor33 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor33
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor33 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor33.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor33 = value
				flag = Me._btncolor33 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor33.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002AE RID: 686
		' (get) Token: 0x0600070E RID: 1806 RVA: 0x00055E7C File Offset: 0x0005407C
		' (set) Token: 0x0600070F RID: 1807 RVA: 0x00055E94 File Offset: 0x00054094
		Friend Overridable Property btncolor5 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor5 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor5.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor5 = value
				flag = Me._btncolor5 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor5.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002AF RID: 687
		' (get) Token: 0x06000710 RID: 1808 RVA: 0x00055F00 File Offset: 0x00054100
		' (set) Token: 0x06000711 RID: 1809 RVA: 0x00055F18 File Offset: 0x00054118
		Friend Overridable Property btncolor35 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor35
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor35 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor35.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor35 = value
				flag = Me._btncolor35 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor35.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002B0 RID: 688
		' (get) Token: 0x06000712 RID: 1810 RVA: 0x00055F84 File Offset: 0x00054184
		' (set) Token: 0x06000713 RID: 1811 RVA: 0x00055F9C File Offset: 0x0005419C
		Friend Overridable Property btncolor6 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor6 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor6.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor6 = value
				flag = Me._btncolor6 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor6.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002B1 RID: 689
		' (get) Token: 0x06000714 RID: 1812 RVA: 0x00056008 File Offset: 0x00054208
		' (set) Token: 0x06000715 RID: 1813 RVA: 0x00056020 File Offset: 0x00054220
		Friend Overridable Property btncolor34 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor34
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor34 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor34.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor34 = value
				flag = Me._btncolor34 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor34.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002B2 RID: 690
		' (get) Token: 0x06000716 RID: 1814 RVA: 0x0005608C File Offset: 0x0005428C
		' (set) Token: 0x06000717 RID: 1815 RVA: 0x000560A4 File Offset: 0x000542A4
		Friend Overridable Property btncolor7 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor7 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor7.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor7 = value
				flag = Me._btncolor7 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor7.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002B3 RID: 691
		' (get) Token: 0x06000718 RID: 1816 RVA: 0x00056110 File Offset: 0x00054310
		' (set) Token: 0x06000719 RID: 1817 RVA: 0x00056128 File Offset: 0x00054328
		Friend Overridable Property btncolor30 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor30
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor30 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor30.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor30 = value
				flag = Me._btncolor30 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor30.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002B4 RID: 692
		' (get) Token: 0x0600071A RID: 1818 RVA: 0x00056194 File Offset: 0x00054394
		' (set) Token: 0x0600071B RID: 1819 RVA: 0x000561AC File Offset: 0x000543AC
		Friend Overridable Property btncolor31 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor31
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor31 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor31.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor31 = value
				flag = Me._btncolor31 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor31.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002B5 RID: 693
		' (get) Token: 0x0600071C RID: 1820 RVA: 0x00056218 File Offset: 0x00054418
		' (set) Token: 0x0600071D RID: 1821 RVA: 0x00056230 File Offset: 0x00054430
		Friend Overridable Property btncolor9 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor9
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor9 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor9.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor9 = value
				flag = Me._btncolor9 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor9.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002B6 RID: 694
		' (get) Token: 0x0600071E RID: 1822 RVA: 0x0005629C File Offset: 0x0005449C
		' (set) Token: 0x0600071F RID: 1823 RVA: 0x000562B4 File Offset: 0x000544B4
		Friend Overridable Property btncolor32 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor32
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor32 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor32.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor32 = value
				flag = Me._btncolor32 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor32.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002B7 RID: 695
		' (get) Token: 0x06000720 RID: 1824 RVA: 0x00056320 File Offset: 0x00054520
		' (set) Token: 0x06000721 RID: 1825 RVA: 0x00056338 File Offset: 0x00054538
		Friend Overridable Property btncolor10 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor10
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor10 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor10.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor10 = value
				flag = Me._btncolor10 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor10.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002B8 RID: 696
		' (get) Token: 0x06000722 RID: 1826 RVA: 0x000563A4 File Offset: 0x000545A4
		' (set) Token: 0x06000723 RID: 1827 RVA: 0x000563BC File Offset: 0x000545BC
		Friend Overridable Property btncolor29 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor29
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor29 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor29.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor29 = value
				flag = Me._btncolor29 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor29.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002B9 RID: 697
		' (get) Token: 0x06000724 RID: 1828 RVA: 0x00056428 File Offset: 0x00054628
		' (set) Token: 0x06000725 RID: 1829 RVA: 0x00056440 File Offset: 0x00054640
		Friend Overridable Property btncolor14 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor14
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor14 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor14.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor14 = value
				flag = Me._btncolor14 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor14.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002BA RID: 698
		' (get) Token: 0x06000726 RID: 1830 RVA: 0x000564AC File Offset: 0x000546AC
		' (set) Token: 0x06000727 RID: 1831 RVA: 0x000564C4 File Offset: 0x000546C4
		Friend Overridable Property btncolor28 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor28
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor28 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor28.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor28 = value
				flag = Me._btncolor28 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor28.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002BB RID: 699
		' (get) Token: 0x06000728 RID: 1832 RVA: 0x00056530 File Offset: 0x00054730
		' (set) Token: 0x06000729 RID: 1833 RVA: 0x00056548 File Offset: 0x00054748
		Friend Overridable Property btncolor11 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor11
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor11 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor11.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor11 = value
				flag = Me._btncolor11 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor11.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002BC RID: 700
		' (get) Token: 0x0600072A RID: 1834 RVA: 0x000565B4 File Offset: 0x000547B4
		' (set) Token: 0x0600072B RID: 1835 RVA: 0x000565CC File Offset: 0x000547CC
		Friend Overridable Property btncolor27 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor27
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor27 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor27.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor27 = value
				flag = Me._btncolor27 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor27.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002BD RID: 701
		' (get) Token: 0x0600072C RID: 1836 RVA: 0x00056638 File Offset: 0x00054838
		' (set) Token: 0x0600072D RID: 1837 RVA: 0x00056650 File Offset: 0x00054850
		Friend Overridable Property btncolor12 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor12
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor12 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor12.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor12 = value
				flag = Me._btncolor12 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor12.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002BE RID: 702
		' (get) Token: 0x0600072E RID: 1838 RVA: 0x000566BC File Offset: 0x000548BC
		' (set) Token: 0x0600072F RID: 1839 RVA: 0x000566D4 File Offset: 0x000548D4
		Friend Overridable Property btncolor26 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor26
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor26 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor26.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor26 = value
				flag = Me._btncolor26 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor26.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002BF RID: 703
		' (get) Token: 0x06000730 RID: 1840 RVA: 0x00056740 File Offset: 0x00054940
		' (set) Token: 0x06000731 RID: 1841 RVA: 0x00056758 File Offset: 0x00054958
		Friend Overridable Property btncolor13 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor13
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor13 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor13.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor13 = value
				flag = Me._btncolor13 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor13.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002C0 RID: 704
		' (get) Token: 0x06000732 RID: 1842 RVA: 0x000567C4 File Offset: 0x000549C4
		' (set) Token: 0x06000733 RID: 1843 RVA: 0x000567DC File Offset: 0x000549DC
		Friend Overridable Property btncolor25 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor25
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor25 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor25.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor25 = value
				flag = Me._btncolor25 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor25.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002C1 RID: 705
		' (get) Token: 0x06000734 RID: 1844 RVA: 0x00056848 File Offset: 0x00054A48
		' (set) Token: 0x06000735 RID: 1845 RVA: 0x00056860 File Offset: 0x00054A60
		Friend Overridable Property btncolor16 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor16
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor16 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor16.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor16 = value
				flag = Me._btncolor16 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor16.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002C2 RID: 706
		' (get) Token: 0x06000736 RID: 1846 RVA: 0x000568CC File Offset: 0x00054ACC
		' (set) Token: 0x06000737 RID: 1847 RVA: 0x000568E4 File Offset: 0x00054AE4
		Friend Overridable Property btncolor15 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor15
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor15 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor15.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor15 = value
				flag = Me._btncolor15 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor15.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002C3 RID: 707
		' (get) Token: 0x06000738 RID: 1848 RVA: 0x00056950 File Offset: 0x00054B50
		' (set) Token: 0x06000739 RID: 1849 RVA: 0x00056968 File Offset: 0x00054B68
		Friend Overridable Property btncolor20 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor20
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor20 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor20.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor20 = value
				flag = Me._btncolor20 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor20.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002C4 RID: 708
		' (get) Token: 0x0600073A RID: 1850 RVA: 0x000569D4 File Offset: 0x00054BD4
		' (set) Token: 0x0600073B RID: 1851 RVA: 0x000569EC File Offset: 0x00054BEC
		Friend Overridable Property btncolor23 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor23
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor23 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor23.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor23 = value
				flag = Me._btncolor23 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor23.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002C5 RID: 709
		' (get) Token: 0x0600073C RID: 1852 RVA: 0x00056A58 File Offset: 0x00054C58
		' (set) Token: 0x0600073D RID: 1853 RVA: 0x00056A70 File Offset: 0x00054C70
		Friend Overridable Property btncolor17 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor17
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor17 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor17.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor17 = value
				flag = Me._btncolor17 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor17.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002C6 RID: 710
		' (get) Token: 0x0600073E RID: 1854 RVA: 0x00056ADC File Offset: 0x00054CDC
		' (set) Token: 0x0600073F RID: 1855 RVA: 0x00056AF4 File Offset: 0x00054CF4
		Friend Overridable Property btncolor24 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor24
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor24 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor24.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor24 = value
				flag = Me._btncolor24 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor24.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002C7 RID: 711
		' (get) Token: 0x06000740 RID: 1856 RVA: 0x00056B60 File Offset: 0x00054D60
		' (set) Token: 0x06000741 RID: 1857 RVA: 0x00056B78 File Offset: 0x00054D78
		Friend Overridable Property btncolor18 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor18
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor18 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor18.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor18 = value
				flag = Me._btncolor18 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor18.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002C8 RID: 712
		' (get) Token: 0x06000742 RID: 1858 RVA: 0x00056BE4 File Offset: 0x00054DE4
		' (set) Token: 0x06000743 RID: 1859 RVA: 0x00056BFC File Offset: 0x00054DFC
		Friend Overridable Property btncolor21 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor21
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor21 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor21.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor21 = value
				flag = Me._btncolor21 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor21.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002C9 RID: 713
		' (get) Token: 0x06000744 RID: 1860 RVA: 0x00056C68 File Offset: 0x00054E68
		' (set) Token: 0x06000745 RID: 1861 RVA: 0x00056C80 File Offset: 0x00054E80
		Friend Overridable Property btncolor19 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor19
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor19 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor19.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor19 = value
				flag = Me._btncolor19 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor19.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002CA RID: 714
		' (get) Token: 0x06000746 RID: 1862 RVA: 0x00056CEC File Offset: 0x00054EEC
		' (set) Token: 0x06000747 RID: 1863 RVA: 0x00056D04 File Offset: 0x00054F04
		Friend Overridable Property btncancel As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncancel
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncancel IsNot Nothing
				If flag Then
					RemoveHandler Me._btncancel.Click, AddressOf Me.btncancel_Click
				End If
				Me._btncancel = value
				flag = Me._btncancel IsNot Nothing
				If flag Then
					AddHandler Me._btncancel.Click, AddressOf Me.btncancel_Click
				End If
			End Set
		End Property

		' Token: 0x170002CB RID: 715
		' (get) Token: 0x06000748 RID: 1864 RVA: 0x00056D70 File Offset: 0x00054F70
		' (set) Token: 0x06000749 RID: 1865 RVA: 0x00056D88 File Offset: 0x00054F88
		Friend Overridable Property btncolor22 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor22
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor22 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor22.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor22 = value
				flag = Me._btncolor22 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor22.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002CC RID: 716
		' (get) Token: 0x0600074A RID: 1866 RVA: 0x00056DF4 File Offset: 0x00054FF4
		' (set) Token: 0x0600074B RID: 1867 RVA: 0x00056E0C File Offset: 0x0005500C
		Friend Overridable Property btncolor8 As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btncolor8
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btncolor8 IsNot Nothing
				If flag Then
					RemoveHandler Me._btncolor8.Click, AddressOf Me.btncolor1_Click
				End If
				Me._btncolor8 = value
				flag = Me._btncolor8 IsNot Nothing
				If flag Then
					AddHandler Me._btncolor8.Click, AddressOf Me.btncolor1_Click
				End If
			End Set
		End Property

		' Token: 0x170002CD RID: 717
		' (get) Token: 0x0600074C RID: 1868 RVA: 0x00056E78 File Offset: 0x00055078
		' (set) Token: 0x0600074D RID: 1869 RVA: 0x00056E90 File Offset: 0x00055090
		Friend Overridable Property ChkDefault As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._ChkDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._ChkDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._ChkDefault.Click, AddressOf Me.ChkDefault_Click
				End If
				Me._ChkDefault = value
				flag = Me._ChkDefault IsNot Nothing
				If flag Then
					AddHandler Me._ChkDefault.Click, AddressOf Me.ChkDefault_Click
				End If
			End Set
		End Property

		' Token: 0x170002CE RID: 718
		' (get) Token: 0x0600074E RID: 1870 RVA: 0x00056EFC File Offset: 0x000550FC
		' (set) Token: 0x0600074F RID: 1871 RVA: 0x00003365 File Offset: 0x00001565
		Friend Overridable Property grpApdung As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpApdung
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpApdung = value
			End Set
		End Property

		' Token: 0x170002CF RID: 719
		' (get) Token: 0x06000750 RID: 1872 RVA: 0x00056F14 File Offset: 0x00055114
		' (set) Token: 0x06000751 RID: 1873 RVA: 0x0000336F File Offset: 0x0000156F
		Friend Overridable Property rdoAll As RadioButton
			<DebuggerNonUserCode()>
			Get
				Return Me._rdoAll
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._rdoAll = value
			End Set
		End Property

		' Token: 0x170002D0 RID: 720
		' (get) Token: 0x06000752 RID: 1874 RVA: 0x00056F2C File Offset: 0x0005512C
		' (set) Token: 0x06000753 RID: 1875 RVA: 0x00003379 File Offset: 0x00001579
		Friend Overridable Property rdoNhom As RadioButton
			<DebuggerNonUserCode()>
			Get
				Return Me._rdoNhom
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._rdoNhom = value
			End Set
		End Property

		' Token: 0x170002D1 RID: 721
		' (get) Token: 0x06000754 RID: 1876 RVA: 0x00056F44 File Offset: 0x00055144
		' (set) Token: 0x06000755 RID: 1877 RVA: 0x00003383 File Offset: 0x00001583
		Friend Overridable Property rdoMon As RadioButton
			<DebuggerNonUserCode()>
			Get
				Return Me._rdoMon
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._rdoMon = value
			End Set
		End Property

		' Token: 0x170002D2 RID: 722
		' (get) Token: 0x06000756 RID: 1878 RVA: 0x00056F5C File Offset: 0x0005515C
		' (set) Token: 0x06000757 RID: 1879 RVA: 0x0000338D File Offset: 0x0000158D
		Public Property pbytAplly As Byte
			Get
				Return Me.mbytAplly
			End Get
			Set(value As Byte)
				Me.mbytAplly = value
			End Set
		End Property

		' Token: 0x170002D3 RID: 723
		' (get) Token: 0x06000758 RID: 1880 RVA: 0x00056F74 File Offset: 0x00055174
		' (set) Token: 0x06000759 RID: 1881 RVA: 0x00003398 File Offset: 0x00001598
		Public Property pbytColorDefgreen As String
			Get
				Return Conversions.ToString(Me.mbytColorDefGreen)
			End Get
			Set(value As String)
				Me.mbytColorDefGreen = Conversions.ToByte(value)
			End Set
		End Property

		' Token: 0x170002D4 RID: 724
		' (get) Token: 0x0600075A RID: 1882 RVA: 0x00056F94 File Offset: 0x00055194
		' (set) Token: 0x0600075B RID: 1883 RVA: 0x000033A8 File Offset: 0x000015A8
		Public Property pbytColorDefred As String
			Get
				Return Conversions.ToString(Me.mbytColorDefRed)
			End Get
			Set(value As String)
				Me.mbytColorDefRed = Conversions.ToByte(value)
			End Set
		End Property

		' Token: 0x170002D5 RID: 725
		' (get) Token: 0x0600075C RID: 1884 RVA: 0x00056FB4 File Offset: 0x000551B4
		' (set) Token: 0x0600075D RID: 1885 RVA: 0x000033B8 File Offset: 0x000015B8
		Public Property pbytColorDefblue As String
			Get
				Return Conversions.ToString(Me.mbytColorDefBlue)
			End Get
			Set(value As String)
				Me.mbytColorDefBlue = Conversions.ToByte(value)
			End Set
		End Property

		' Token: 0x170002D6 RID: 726
		' (get) Token: 0x0600075E RID: 1886 RVA: 0x00056FD4 File Offset: 0x000551D4
		' (set) Token: 0x0600075F RID: 1887 RVA: 0x000033C8 File Offset: 0x000015C8
		Public Property pblnsetdefault As String
			Get
				Return Conversions.ToString(Me.mblnSetDefault)
			End Get
			Set(value As String)
				Me.mblnSetDefault = Conversions.ToBoolean(value)
			End Set
		End Property

		' Token: 0x170002D7 RID: 727
		' (get) Token: 0x06000760 RID: 1888 RVA: 0x00056FF4 File Offset: 0x000551F4
		' (set) Token: 0x06000761 RID: 1889 RVA: 0x000033D8 File Offset: 0x000015D8
		Public Property pblnresult As Boolean
			Get
				Return Me.mblnResult
			End Get
			Set(value As Boolean)
				Me.mblnResult = value
			End Set
		End Property

		' Token: 0x06000762 RID: 1890 RVA: 0x0005700C File Offset: 0x0005520C
		Private Sub frmcolorsetting_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " frmcolorsetting_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000763 RID: 1891 RVA: 0x000570A4 File Offset: 0x000552A4
		Private Sub btncolor1_Click(sender As Object, e As EventArgs)
			Dim button As Button = CType(sender, Button)
			Dim backColor As Color = button.BackColor
			Me.mbytColorDefRed = backColor.R
			Me.mbytColorDefBlue = backColor.B
			Me.mbytColorDefGreen = backColor.G
			Me.mblnSetDefault = Me.ChkDefault.Checked
			mdlFile.gfWriteLogFile("Nhấn chọn màu: " + button.BackColor.ToString())
		End Sub

		' Token: 0x06000764 RID: 1892 RVA: 0x00057120 File Offset: 0x00055320
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.ChkDefault.Tag = "CB0002"
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(1))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000765 RID: 1893 RVA: 0x000033E3 File Offset: 0x000015E3
		Private Sub btncancel_Click(sender As Object, e As EventArgs)
			Me.mblnResult = False
			mdlFile.gfWriteLogFile("Nhấn nút Hủy chọn màu.")
			Me.Close()
		End Sub

		' Token: 0x06000766 RID: 1894 RVA: 0x0005723C File Offset: 0x0005543C
		Private Sub btnOk_Click(sender As Object, e As EventArgs)
			Me.mblnResult = True
			mdlFile.gfWriteLogFile("Nhấn nút OK chọn màu.")
			Dim flag As Boolean = Me.rdoMon.Checked
			If flag Then
				Me.mbytAplly = 0
			Else
				flag = Me.rdoNhom.Checked
				If flag Then
					Me.mbytAplly = 1
				Else
					flag = Me.rdoAll.Checked
					If flag Then
						Me.mbytAplly = 2
					End If
				End If
			End If
			Me.Close()
		End Sub

		' Token: 0x06000767 RID: 1895 RVA: 0x00003400 File Offset: 0x00001600
		Private Sub ChkDefault_Click(sender As Object, e As EventArgs)
			Me.mblnSetDefault = Me.ChkDefault.Checked
		End Sub

		' Token: 0x04000308 RID: 776
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400030A RID: 778
		<AccessedThroughProperty("btnok")>
		Private _btnok As Button

		' Token: 0x0400030B RID: 779
		<AccessedThroughProperty("Tblpanelcolor")>
		Private _Tblpanelcolor As TableLayoutPanel

		' Token: 0x0400030C RID: 780
		<AccessedThroughProperty("btncolor38")>
		Private _btncolor38 As Button

		' Token: 0x0400030D RID: 781
		<AccessedThroughProperty("btncolor39")>
		Private _btncolor39 As Button

		' Token: 0x0400030E RID: 782
		<AccessedThroughProperty("btncolor1")>
		Private _btncolor1 As Button

		' Token: 0x0400030F RID: 783
		<AccessedThroughProperty("btncolor40")>
		Private _btncolor40 As Button

		' Token: 0x04000310 RID: 784
		<AccessedThroughProperty("btncolor2")>
		Private _btncolor2 As Button

		' Token: 0x04000311 RID: 785
		<AccessedThroughProperty("btncolor37")>
		Private _btncolor37 As Button

		' Token: 0x04000312 RID: 786
		<AccessedThroughProperty("btncolor3")>
		Private _btncolor3 As Button

		' Token: 0x04000313 RID: 787
		<AccessedThroughProperty("btncolor36")>
		Private _btncolor36 As Button

		' Token: 0x04000314 RID: 788
		<AccessedThroughProperty("btncolor4")>
		Private _btncolor4 As Button

		' Token: 0x04000315 RID: 789
		<AccessedThroughProperty("btncolor33")>
		Private _btncolor33 As Button

		' Token: 0x04000316 RID: 790
		<AccessedThroughProperty("btncolor5")>
		Private _btncolor5 As Button

		' Token: 0x04000317 RID: 791
		<AccessedThroughProperty("btncolor35")>
		Private _btncolor35 As Button

		' Token: 0x04000318 RID: 792
		<AccessedThroughProperty("btncolor6")>
		Private _btncolor6 As Button

		' Token: 0x04000319 RID: 793
		<AccessedThroughProperty("btncolor34")>
		Private _btncolor34 As Button

		' Token: 0x0400031A RID: 794
		<AccessedThroughProperty("btncolor7")>
		Private _btncolor7 As Button

		' Token: 0x0400031B RID: 795
		<AccessedThroughProperty("btncolor30")>
		Private _btncolor30 As Button

		' Token: 0x0400031C RID: 796
		<AccessedThroughProperty("btncolor31")>
		Private _btncolor31 As Button

		' Token: 0x0400031D RID: 797
		<AccessedThroughProperty("btncolor9")>
		Private _btncolor9 As Button

		' Token: 0x0400031E RID: 798
		<AccessedThroughProperty("btncolor32")>
		Private _btncolor32 As Button

		' Token: 0x0400031F RID: 799
		<AccessedThroughProperty("btncolor10")>
		Private _btncolor10 As Button

		' Token: 0x04000320 RID: 800
		<AccessedThroughProperty("btncolor29")>
		Private _btncolor29 As Button

		' Token: 0x04000321 RID: 801
		<AccessedThroughProperty("btncolor14")>
		Private _btncolor14 As Button

		' Token: 0x04000322 RID: 802
		<AccessedThroughProperty("btncolor28")>
		Private _btncolor28 As Button

		' Token: 0x04000323 RID: 803
		<AccessedThroughProperty("btncolor11")>
		Private _btncolor11 As Button

		' Token: 0x04000324 RID: 804
		<AccessedThroughProperty("btncolor27")>
		Private _btncolor27 As Button

		' Token: 0x04000325 RID: 805
		<AccessedThroughProperty("btncolor12")>
		Private _btncolor12 As Button

		' Token: 0x04000326 RID: 806
		<AccessedThroughProperty("btncolor26")>
		Private _btncolor26 As Button

		' Token: 0x04000327 RID: 807
		<AccessedThroughProperty("btncolor13")>
		Private _btncolor13 As Button

		' Token: 0x04000328 RID: 808
		<AccessedThroughProperty("btncolor25")>
		Private _btncolor25 As Button

		' Token: 0x04000329 RID: 809
		<AccessedThroughProperty("btncolor16")>
		Private _btncolor16 As Button

		' Token: 0x0400032A RID: 810
		<AccessedThroughProperty("btncolor15")>
		Private _btncolor15 As Button

		' Token: 0x0400032B RID: 811
		<AccessedThroughProperty("btncolor20")>
		Private _btncolor20 As Button

		' Token: 0x0400032C RID: 812
		<AccessedThroughProperty("btncolor23")>
		Private _btncolor23 As Button

		' Token: 0x0400032D RID: 813
		<AccessedThroughProperty("btncolor17")>
		Private _btncolor17 As Button

		' Token: 0x0400032E RID: 814
		<AccessedThroughProperty("btncolor24")>
		Private _btncolor24 As Button

		' Token: 0x0400032F RID: 815
		<AccessedThroughProperty("btncolor18")>
		Private _btncolor18 As Button

		' Token: 0x04000330 RID: 816
		<AccessedThroughProperty("btncolor21")>
		Private _btncolor21 As Button

		' Token: 0x04000331 RID: 817
		<AccessedThroughProperty("btncolor19")>
		Private _btncolor19 As Button

		' Token: 0x04000332 RID: 818
		<AccessedThroughProperty("btncancel")>
		Private _btncancel As Button

		' Token: 0x04000333 RID: 819
		<AccessedThroughProperty("btncolor22")>
		Private _btncolor22 As Button

		' Token: 0x04000334 RID: 820
		<AccessedThroughProperty("btncolor8")>
		Private _btncolor8 As Button

		' Token: 0x04000335 RID: 821
		<AccessedThroughProperty("ChkDefault")>
		Private _ChkDefault As CheckBox

		' Token: 0x04000336 RID: 822
		<AccessedThroughProperty("grpApdung")>
		Private _grpApdung As GroupBox

		' Token: 0x04000337 RID: 823
		<AccessedThroughProperty("rdoAll")>
		Private _rdoAll As RadioButton

		' Token: 0x04000338 RID: 824
		<AccessedThroughProperty("rdoNhom")>
		Private _rdoNhom As RadioButton

		' Token: 0x04000339 RID: 825
		<AccessedThroughProperty("rdoMon")>
		Private _rdoMon As RadioButton

		' Token: 0x0400033A RID: 826
		Private mArrStrFrmMess As String()

		' Token: 0x0400033B RID: 827
		Private mbytColorDefGreen As Byte

		' Token: 0x0400033C RID: 828
		Private mbytColorDefBlue As Byte

		' Token: 0x0400033D RID: 829
		Private mbytColorDefRed As Byte

		' Token: 0x0400033E RID: 830
		Private mblnSetDefault As Boolean

		' Token: 0x0400033F RID: 831
		Private mblnResult As Boolean

		' Token: 0x04000340 RID: 832
		Private mbytAplly As Byte
	End Class
End Namespace
