﻿Namespace prjIS_SalesPOS
	' Token: 0x02000036 RID: 54
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMAUTOPRICE3
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000BE3 RID: 3043 RVA: 0x0008BDBC File Offset: 0x00089FBC
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000BE4 RID: 3044 RVA: 0x0008BDF4 File Offset: 0x00089FF4
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMAUTOPRICE3))
			Me.lblPosition = New Global.System.Windows.Forms.Label()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.btnLast = New Global.System.Windows.Forms.Button()
			Me.btnNext = New Global.System.Windows.Forms.Button()
			Me.grpNavigater = New Global.System.Windows.Forms.GroupBox()
			Me.btnFirst = New Global.System.Windows.Forms.Button()
			Me.btnPrevious = New Global.System.Windows.Forms.Button()
			Me.grpControl = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnAdd = New Global.System.Windows.Forms.Button()
			Me.btnModify = New Global.System.Windows.Forms.Button()
			Me.dgvData = New Global.System.Windows.Forms.DataGridView()
			Me.lblFromTime = New Global.System.Windows.Forms.Label()
			Me.lblTungay = New Global.System.Windows.Forms.Label()
			Me.lblTen = New Global.System.Windows.Forms.Label()
			Me.txtTen = New Global.System.Windows.Forms.TextBox()
			Me.btnPrintMas = New Global.System.Windows.Forms.Button()
			Me.btnDelMas = New Global.System.Windows.Forms.Button()
			Me.btnEditMas = New Global.System.Windows.Forms.Button()
			Me.btnFirstMas = New Global.System.Windows.Forms.Button()
			Me.btnPreMas = New Global.System.Windows.Forms.Button()
			Me.btnNextMas = New Global.System.Windows.Forms.Button()
			Me.btnLastMas = New Global.System.Windows.Forms.Button()
			Me.lblDengio = New Global.System.Windows.Forms.Label()
			Me.lblDenngay = New Global.System.Windows.Forms.Label()
			Me.mtxFromDate = New Global.System.Windows.Forms.MaskedTextBox()
			Me.mtxToDate = New Global.System.Windows.Forms.MaskedTextBox()
			Me.mtxFromTime = New Global.System.Windows.Forms.MaskedTextBox()
			Me.mtxToTime = New Global.System.Windows.Forms.MaskedTextBox()
			Me.btnAddAll = New Global.System.Windows.Forms.Button()
			Me.grpNavigater.SuspendLayout()
			Me.grpControl.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.lblPosition.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.lblPosition.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblPosition.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPosition As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(83, 14)
			lblPosition.Location = point
			Me.lblPosition.Name = "lblPosition"
			Dim lblPosition2 As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(93, 35)
			lblPosition2.Size = size
			Me.lblPosition.TabIndex = 6
			Me.lblPosition.Tag = "0R0000"
			Me.lblPosition.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 189)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 87)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 2
			Me.btnDelete.Tag = "CR0007"
			Me.btnDelete.Text = "Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.btnLast.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi_1
			Dim btnLast As Global.System.Windows.Forms.Control = Me.btnLast
			point = New Global.System.Drawing.Point(213, 14)
			btnLast.Location = point
			Me.btnLast.Name = "btnLast"
			Dim btnLast2 As Global.System.Windows.Forms.Control = Me.btnLast
			size = New Global.System.Drawing.Size(40, 35)
			btnLast2.Size = size
			Me.btnLast.TabIndex = 5
			Me.btnLast.UseVisualStyleBackColor = True
			Me.btnNext.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi
			Dim btnNext As Global.System.Windows.Forms.Control = Me.btnNext
			point = New Global.System.Drawing.Point(175, 14)
			btnNext.Location = point
			Me.btnNext.Name = "btnNext"
			Dim btnNext2 As Global.System.Windows.Forms.Control = Me.btnNext
			size = New Global.System.Drawing.Size(40, 35)
			btnNext2.Size = size
			Me.btnNext.TabIndex = 4
			Me.btnNext.UseVisualStyleBackColor = True
			Me.grpNavigater.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom
			Me.grpNavigater.Controls.Add(Me.lblPosition)
			Me.grpNavigater.Controls.Add(Me.btnFirst)
			Me.grpNavigater.Controls.Add(Me.btnPrevious)
			Me.grpNavigater.Controls.Add(Me.btnLast)
			Me.grpNavigater.Controls.Add(Me.btnNext)
			Dim grpNavigater As Global.System.Windows.Forms.Control = Me.grpNavigater
			point = New Global.System.Drawing.Point(142, 417)
			grpNavigater.Location = point
			Me.grpNavigater.Name = "grpNavigater"
			Dim grpNavigater2 As Global.System.Windows.Forms.Control = Me.grpNavigater
			size = New Global.System.Drawing.Size(261, 61)
			grpNavigater2.Size = size
			Me.grpNavigater.TabIndex = 8
			Me.grpNavigater.TabStop = False
			Me.btnFirst.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui_1
			Dim btnFirst As Global.System.Windows.Forms.Control = Me.btnFirst
			point = New Global.System.Drawing.Point(6, 14)
			btnFirst.Location = point
			Me.btnFirst.Name = "btnFirst"
			Dim btnFirst2 As Global.System.Windows.Forms.Control = Me.btnFirst
			size = New Global.System.Drawing.Size(40, 35)
			btnFirst2.Size = size
			Me.btnFirst.TabIndex = 2
			Me.btnFirst.UseVisualStyleBackColor = True
			Me.btnPrevious.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui
			Dim btnPrevious As Global.System.Windows.Forms.Control = Me.btnPrevious
			point = New Global.System.Drawing.Point(44, 14)
			btnPrevious.Location = point
			Me.btnPrevious.Name = "btnPrevious"
			Dim btnPrevious2 As Global.System.Windows.Forms.Control = Me.btnPrevious
			size = New Global.System.Drawing.Size(40, 35)
			btnPrevious2.Size = size
			Me.btnPrevious.TabIndex = 3
			Me.btnPrevious.UseVisualStyleBackColor = True
			Me.grpControl.Controls.Add(Me.TableLayoutPanel1)
			Me.grpControl.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpControl As Global.System.Windows.Forms.Control = Me.grpControl
			point = New Global.System.Drawing.Point(536, 0)
			grpControl.Location = point
			Me.grpControl.Name = "grpControl"
			Dim grpControl2 As Global.System.Windows.Forms.Control = Me.grpControl
			size = New Global.System.Drawing.Size(119, 490)
			grpControl2.Size = size
			Me.grpControl.TabIndex = 0
			Me.grpControl.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnAddAll, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 2)
			Me.TableLayoutPanel1.Controls.Add(Me.btnAdd, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnModify, 0, 1)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 5
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 20F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Absolute, 20F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 469)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 375)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 91)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 12
			Me.btnExit.Tag = "CR0003"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnAdd.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnAdd.Image = Global.prjIS_SalesPOS.My.Resources.Resources.them
			Dim btnAdd As Global.System.Windows.Forms.Control = Me.btnAdd
			point = New Global.System.Drawing.Point(3, 3)
			btnAdd.Location = point
			Me.btnAdd.Name = "btnAdd"
			Dim btnAdd2 As Global.System.Windows.Forms.Control = Me.btnAdd
			size = New Global.System.Drawing.Size(107, 87)
			btnAdd2.Size = size
			Me.btnAdd.TabIndex = 0
			Me.btnAdd.Tag = "CR0004"
			Me.btnAdd.Text = "Thêm"
			Me.btnAdd.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnAdd.UseVisualStyleBackColor = True
			Me.btnModify.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnModify.Image = Global.prjIS_SalesPOS.My.Resources.Resources.sua
			Dim btnModify As Global.System.Windows.Forms.Control = Me.btnModify
			point = New Global.System.Drawing.Point(3, 96)
			btnModify.Location = point
			Me.btnModify.Name = "btnModify"
			Dim btnModify2 As Global.System.Windows.Forms.Control = Me.btnModify
			size = New Global.System.Drawing.Size(107, 87)
			btnModify2.Size = size
			Me.btnModify.TabIndex = 1
			Me.btnModify.Tag = "CR0006"
			Me.btnModify.Text = "Sửa"
			Me.btnModify.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnModify.UseVisualStyleBackColor = True
			Me.dgvData.AllowUserToAddRows = False
			Me.dgvData.AllowUserToDeleteRows = False
			Me.dgvData.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvData.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvData.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvData As Global.System.Windows.Forms.Control = Me.dgvData
			point = New Global.System.Drawing.Point(0, 132)
			dgvData.Location = point
			Me.dgvData.Name = "dgvData"
			Me.dgvData.[ReadOnly] = True
			Me.dgvData.RowTemplate.DefaultCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim dgvData2 As Global.System.Windows.Forms.Control = Me.dgvData
			size = New Global.System.Drawing.Size(530, 279)
			dgvData2.Size = size
			Me.dgvData.TabIndex = 9
			Me.lblFromTime.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFromTime As Global.System.Windows.Forms.Control = Me.lblFromTime
			point = New Global.System.Drawing.Point(12, 62)
			lblFromTime.Location = point
			Me.lblFromTime.Name = "lblFromTime"
			Dim lblFromTime2 As Global.System.Windows.Forms.Control = Me.lblFromTime
			size = New Global.System.Drawing.Size(77, 21)
			lblFromTime2.Size = size
			Me.lblFromTime.TabIndex = 64
			Me.lblFromTime.Tag = "CR0020"
			Me.lblFromTime.Text = "Từ giờ"
			Me.lblTungay.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblTungay As Global.System.Windows.Forms.Control = Me.lblTungay
			point = New Global.System.Drawing.Point(12, 34)
			lblTungay.Location = point
			Me.lblTungay.Name = "lblTungay"
			Dim lblTungay2 As Global.System.Windows.Forms.Control = Me.lblTungay
			size = New Global.System.Drawing.Size(77, 21)
			lblTungay2.Size = size
			Me.lblTungay.TabIndex = 63
			Me.lblTungay.Tag = "CR0019"
			Me.lblTungay.Text = "Từ ngày"
			Me.lblTen.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblTen As Global.System.Windows.Forms.Control = Me.lblTen
			point = New Global.System.Drawing.Point(12, 6)
			lblTen.Location = point
			Me.lblTen.Name = "lblTen"
			Dim lblTen2 As Global.System.Windows.Forms.Control = Me.lblTen
			size = New Global.System.Drawing.Size(77, 21)
			lblTen2.Size = size
			Me.lblTen.TabIndex = 62
			Me.lblTen.Tag = "CR0018"
			Me.lblTen.Text = "Tên"
			Me.txtTen.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtTen As Global.System.Windows.Forms.Control = Me.txtTen
			point = New Global.System.Drawing.Point(95, 3)
			txtTen.Location = point
			Me.txtTen.Name = "txtTen"
			Dim txtTen2 As Global.System.Windows.Forms.Control = Me.txtTen
			size = New Global.System.Drawing.Size(293, 22)
			txtTen2.Size = size
			Me.txtTen.TabIndex = 59
			Me.txtTen.Tag = "0R0000"
			Me.btnPrintMas.Image = Global.prjIS_SalesPOS.My.Resources.Resources._in
			Dim btnPrintMas As Global.System.Windows.Forms.Control = Me.btnPrintMas
			point = New Global.System.Drawing.Point(450, 86)
			btnPrintMas.Location = point
			Me.btnPrintMas.Name = "btnPrintMas"
			Dim btnPrintMas2 As Global.System.Windows.Forms.Control = Me.btnPrintMas
			size = New Global.System.Drawing.Size(80, 42)
			btnPrintMas2.Size = size
			Me.btnPrintMas.TabIndex = 7
			Me.btnPrintMas.Tag = "CR0032"
			Me.btnPrintMas.Text = "In"
			Me.btnPrintMas.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnPrintMas.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnPrintMas.UseVisualStyleBackColor = True
			Me.btnDelMas.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelMas As Global.System.Windows.Forms.Control = Me.btnDelMas
			point = New Global.System.Drawing.Point(450, 3)
			btnDelMas.Location = point
			Me.btnDelMas.Name = "btnDelMas"
			Dim btnDelMas2 As Global.System.Windows.Forms.Control = Me.btnDelMas
			size = New Global.System.Drawing.Size(80, 42)
			btnDelMas2.Size = size
			Me.btnDelMas.TabIndex = 5
			Me.btnDelMas.Tag = "CR0030"
			Me.btnDelMas.Text = "Xóa"
			Me.btnDelMas.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnDelMas.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelMas.UseVisualStyleBackColor = True
			Me.btnEditMas.Image = Global.prjIS_SalesPOS.My.Resources.Resources.sua
			Dim btnEditMas As Global.System.Windows.Forms.Control = Me.btnEditMas
			point = New Global.System.Drawing.Point(450, 44)
			btnEditMas.Location = point
			Me.btnEditMas.Name = "btnEditMas"
			Dim btnEditMas2 As Global.System.Windows.Forms.Control = Me.btnEditMas
			size = New Global.System.Drawing.Size(80, 42)
			btnEditMas2.Size = size
			Me.btnEditMas.TabIndex = 6
			Me.btnEditMas.Tag = "CR0031"
			Me.btnEditMas.Text = "Sửa"
			Me.btnEditMas.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnEditMas.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnEditMas.UseVisualStyleBackColor = True
			Me.btnFirstMas.Image = Global.prjIS_SalesPOS.My.Resources.Resources.First
			Dim btnFirstMas As Global.System.Windows.Forms.Control = Me.btnFirstMas
			point = New Global.System.Drawing.Point(413, 3)
			btnFirstMas.Location = point
			Me.btnFirstMas.Name = "btnFirstMas"
			Dim btnFirstMas2 As Global.System.Windows.Forms.Control = Me.btnFirstMas
			size = New Global.System.Drawing.Size(31, 28)
			btnFirstMas2.Size = size
			Me.btnFirstMas.TabIndex = 1
			Me.btnFirstMas.UseVisualStyleBackColor = True
			Me.btnPreMas.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Previous
			Dim btnPreMas As Global.System.Windows.Forms.Control = Me.btnPreMas
			point = New Global.System.Drawing.Point(413, 31)
			btnPreMas.Location = point
			Me.btnPreMas.Name = "btnPreMas"
			Dim btnPreMas2 As Global.System.Windows.Forms.Control = Me.btnPreMas
			size = New Global.System.Drawing.Size(31, 28)
			btnPreMas2.Size = size
			Me.btnPreMas.TabIndex = 2
			Me.btnPreMas.UseVisualStyleBackColor = True
			Me.btnNextMas.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Next
			Dim btnNextMas As Global.System.Windows.Forms.Control = Me.btnNextMas
			point = New Global.System.Drawing.Point(414, 59)
			btnNextMas.Location = point
			Me.btnNextMas.Name = "btnNextMas"
			Dim btnNextMas2 As Global.System.Windows.Forms.Control = Me.btnNextMas
			size = New Global.System.Drawing.Size(31, 28)
			btnNextMas2.Size = size
			Me.btnNextMas.TabIndex = 3
			Me.btnNextMas.UseVisualStyleBackColor = True
			Me.btnLastMas.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Last
			Dim btnLastMas As Global.System.Windows.Forms.Control = Me.btnLastMas
			point = New Global.System.Drawing.Point(414, 87)
			btnLastMas.Location = point
			Me.btnLastMas.Name = "btnLastMas"
			Dim btnLastMas2 As Global.System.Windows.Forms.Control = Me.btnLastMas
			size = New Global.System.Drawing.Size(31, 28)
			btnLastMas2.Size = size
			Me.btnLastMas.TabIndex = 4
			Me.btnLastMas.UseVisualStyleBackColor = True
			Me.lblDengio.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblDengio As Global.System.Windows.Forms.Control = Me.lblDengio
			point = New Global.System.Drawing.Point(193, 59)
			lblDengio.Location = point
			Me.lblDengio.Name = "lblDengio"
			Dim lblDengio2 As Global.System.Windows.Forms.Control = Me.lblDengio
			size = New Global.System.Drawing.Size(91, 21)
			lblDengio2.Size = size
			Me.lblDengio.TabIndex = 70
			Me.lblDengio.Tag = "CR0023"
			Me.lblDengio.Text = "Đến giờ"
			Me.lblDenngay.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblDenngay As Global.System.Windows.Forms.Control = Me.lblDenngay
			point = New Global.System.Drawing.Point(193, 31)
			lblDenngay.Location = point
			Me.lblDenngay.Name = "lblDenngay"
			Dim lblDenngay2 As Global.System.Windows.Forms.Control = Me.lblDenngay
			size = New Global.System.Drawing.Size(91, 21)
			lblDenngay2.Size = size
			Me.lblDenngay.TabIndex = 69
			Me.lblDenngay.Tag = "CR0022"
			Me.lblDenngay.Text = "Đến ngày"
			Me.mtxFromDate.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim mtxFromDate As Global.System.Windows.Forms.Control = Me.mtxFromDate
			point = New Global.System.Drawing.Point(95, 31)
			mtxFromDate.Location = point
			Me.mtxFromDate.Mask = "00/00/0000"
			Me.mtxFromDate.Name = "mtxFromDate"
			Me.mtxFromDate.PromptChar = " "c
			Dim mtxFromDate2 As Global.System.Windows.Forms.Control = Me.mtxFromDate
			size = New Global.System.Drawing.Size(92, 22)
			mtxFromDate2.Size = size
			Me.mtxFromDate.TabIndex = 83
			Me.mtxFromDate.Tag = ""
			Me.mtxFromDate.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.mtxFromDate.ValidatingType = GetType(Global.System.DateTime)
			Me.mtxToDate.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim mtxToDate As Global.System.Windows.Forms.Control = Me.mtxToDate
			point = New Global.System.Drawing.Point(290, 30)
			mtxToDate.Location = point
			Me.mtxToDate.Mask = "00/00/0000"
			Me.mtxToDate.Name = "mtxToDate"
			Me.mtxToDate.PromptChar = " "c
			Dim mtxToDate2 As Global.System.Windows.Forms.Control = Me.mtxToDate
			size = New Global.System.Drawing.Size(98, 22)
			mtxToDate2.Size = size
			Me.mtxToDate.TabIndex = 84
			Me.mtxToDate.Tag = ""
			Me.mtxToDate.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.mtxToDate.ValidatingType = GetType(Global.System.DateTime)
			Me.mtxFromTime.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim mtxFromTime As Global.System.Windows.Forms.Control = Me.mtxFromTime
			point = New Global.System.Drawing.Point(95, 58)
			mtxFromTime.Location = point
			Me.mtxFromTime.Mask = "00:00"
			Me.mtxFromTime.Name = "mtxFromTime"
			Me.mtxFromTime.PromptChar = " "c
			Dim mtxFromTime2 As Global.System.Windows.Forms.Control = Me.mtxFromTime
			size = New Global.System.Drawing.Size(92, 22)
			mtxFromTime2.Size = size
			Me.mtxFromTime.TabIndex = 85
			Me.mtxFromTime.Tag = ""
			Me.mtxFromTime.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.mtxFromTime.ValidatingType = GetType(Global.System.DateTime)
			Me.mtxToTime.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim mtxToTime As Global.System.Windows.Forms.Control = Me.mtxToTime
			point = New Global.System.Drawing.Point(290, 57)
			mtxToTime.Location = point
			Me.mtxToTime.Mask = "00:00"
			Me.mtxToTime.Name = "mtxToTime"
			Me.mtxToTime.PromptChar = " "c
			Dim mtxToTime2 As Global.System.Windows.Forms.Control = Me.mtxToTime
			size = New Global.System.Drawing.Size(98, 22)
			mtxToTime2.Size = size
			Me.mtxToTime.TabIndex = 86
			Me.mtxToTime.Tag = ""
			Me.mtxToTime.TextAlign = Global.System.Windows.Forms.HorizontalAlignment.Center
			Me.mtxToTime.ValidatingType = GetType(Global.System.DateTime)
			Me.btnAddAll.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnAddAll.Image = Global.prjIS_SalesPOS.My.Resources.Resources.them
			Dim btnAddAll As Global.System.Windows.Forms.Control = Me.btnAddAll
			point = New Global.System.Drawing.Point(3, 282)
			btnAddAll.Location = point
			Me.btnAddAll.Name = "btnAddAll"
			Dim btnAddAll2 As Global.System.Windows.Forms.Control = Me.btnAddAll
			size = New Global.System.Drawing.Size(107, 87)
			btnAddAll2.Size = size
			Me.btnAddAll.TabIndex = 87
			Me.btnAddAll.Tag = "CR0039"
			Me.btnAddAll.Text = "Thêm"
			Me.btnAddAll.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnAddAll.UseVisualStyleBackColor = True
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(655, 490)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.mtxToTime)
			Me.Controls.Add(Me.mtxFromTime)
			Me.Controls.Add(Me.mtxToDate)
			Me.Controls.Add(Me.mtxFromDate)
			Me.Controls.Add(Me.lblDengio)
			Me.Controls.Add(Me.lblDenngay)
			Me.Controls.Add(Me.btnLastMas)
			Me.Controls.Add(Me.btnNextMas)
			Me.Controls.Add(Me.btnPreMas)
			Me.Controls.Add(Me.btnFirstMas)
			Me.Controls.Add(Me.btnPrintMas)
			Me.Controls.Add(Me.btnDelMas)
			Me.Controls.Add(Me.btnEditMas)
			Me.Controls.Add(Me.lblFromTime)
			Me.Controls.Add(Me.lblTungay)
			Me.Controls.Add(Me.lblTen)
			Me.Controls.Add(Me.txtTen)
			Me.Controls.Add(Me.dgvData)
			Me.Controls.Add(Me.grpNavigater)
			Me.Controls.Add(Me.grpControl)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmDMAUTOPRICE3"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "frmDNKM3"
			Me.grpNavigater.ResumeLayout(False)
			Me.grpControl.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x0400052D RID: 1325
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
