﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000046 RID: 70
	<DesignerGenerated()>
	Public Partial Class frmDMDVRES
		Inherits Form

		' Token: 0x060012C1 RID: 4801 RVA: 0x000E4578 File Offset: 0x000E2778
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMHH1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMHH1_Load
			frmDMDVRES.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mBlnCallFromFunction = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000693 RID: 1683
		' (get) Token: 0x060012C4 RID: 4804 RVA: 0x000E4BE0 File Offset: 0x000E2DE0
		' (set) Token: 0x060012C5 RID: 4805 RVA: 0x000E4BF8 File Offset: 0x000E2DF8
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000694 RID: 1684
		' (get) Token: 0x060012C6 RID: 4806 RVA: 0x000E4C64 File Offset: 0x000E2E64
		' (set) Token: 0x060012C7 RID: 4807 RVA: 0x000E4C7C File Offset: 0x000E2E7C
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000695 RID: 1685
		' (get) Token: 0x060012C8 RID: 4808 RVA: 0x000E4CE8 File Offset: 0x000E2EE8
		' (set) Token: 0x060012C9 RID: 4809 RVA: 0x000E4D00 File Offset: 0x000E2F00
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.KeyDown, AddressOf Me.dgvData_KeyDown
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.KeyDown, AddressOf Me.dgvData_KeyDown
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x17000696 RID: 1686
		' (get) Token: 0x060012CA RID: 4810 RVA: 0x000E4D9C File Offset: 0x000E2F9C
		' (set) Token: 0x060012CB RID: 4811 RVA: 0x00004DD4 File Offset: 0x00002FD4
		Friend Overridable Property lblMANH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMANH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMANH = value
			End Set
		End Property

		' Token: 0x17000697 RID: 1687
		' (get) Token: 0x060012CC RID: 4812 RVA: 0x000E4DB4 File Offset: 0x000E2FB4
		' (set) Token: 0x060012CD RID: 4813 RVA: 0x000E4DCC File Offset: 0x000E2FCC
		Friend Overridable Property txtOBJIDNH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJIDNH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJIDNH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJIDNH.KeyDown, AddressOf Me.txtOBJIDNH_KeyDown
					RemoveHandler Me._txtOBJIDNH.TextChanged, AddressOf Me.txtOBJIDNH_TextChanged
				End If
				Me._txtOBJIDNH = value
				flag = Me._txtOBJIDNH IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJIDNH.KeyDown, AddressOf Me.txtOBJIDNH_KeyDown
					AddHandler Me._txtOBJIDNH.TextChanged, AddressOf Me.txtOBJIDNH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000698 RID: 1688
		' (get) Token: 0x060012CE RID: 4814 RVA: 0x000E4E68 File Offset: 0x000E3068
		' (set) Token: 0x060012CF RID: 4815 RVA: 0x000E4E80 File Offset: 0x000E3080
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x17000699 RID: 1689
		' (get) Token: 0x060012D0 RID: 4816 RVA: 0x000E4EEC File Offset: 0x000E30EC
		' (set) Token: 0x060012D1 RID: 4817 RVA: 0x00004DDE File Offset: 0x00002FDE
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Me._mbdsSource = value
			End Set
		End Property

		' Token: 0x1700069A RID: 1690
		' (get) Token: 0x060012D2 RID: 4818 RVA: 0x000E4F04 File Offset: 0x000E3104
		' (set) Token: 0x060012D3 RID: 4819 RVA: 0x00004DE8 File Offset: 0x00002FE8
		Public Property pBlnCallFromFunction As Boolean
			Get
				Return Me.mBlnCallFromFunction
			End Get
			Set(value As Boolean)
				Me.mBlnCallFromFunction = value
			End Set
		End Property

		' Token: 0x1700069B RID: 1691
		' (get) Token: 0x060012D4 RID: 4820 RVA: 0x000E4F1C File Offset: 0x000E311C
		' (set) Token: 0x060012D5 RID: 4821 RVA: 0x00004DF3 File Offset: 0x00002FF3
		Public Property pStrMaDV As String
			Get
				Return Me.mStrMaDV
			End Get
			Set(value As String)
				Me.mStrMaDV = value
			End Set
		End Property

		' Token: 0x1700069C RID: 1692
		' (get) Token: 0x060012D6 RID: 4822 RVA: 0x000E4F34 File Offset: 0x000E3134
		' (set) Token: 0x060012D7 RID: 4823 RVA: 0x00004DFE File Offset: 0x00002FFE
		Public Property pStrTenDV As String
			Get
				Return Me.mStrTenDV
			End Get
			Set(value As String)
				Me.mStrTenDV = value
			End Set
		End Property

		' Token: 0x1700069D RID: 1693
		' (get) Token: 0x060012D8 RID: 4824 RVA: 0x000E4F4C File Offset: 0x000E314C
		' (set) Token: 0x060012D9 RID: 4825 RVA: 0x00004E09 File Offset: 0x00003009
		Public Property pstrDienthoai As String
			Get
				Return Me.mStrDienThoai
			End Get
			Set(value As String)
				Me.mStrDienThoai = value
			End Set
		End Property

		' Token: 0x1700069E RID: 1694
		' (get) Token: 0x060012DA RID: 4826 RVA: 0x000E4F64 File Offset: 0x000E3164
		' (set) Token: 0x060012DB RID: 4827 RVA: 0x00004E14 File Offset: 0x00003014
		Public Property pdtNgaySinh As DateTime
			Get
				Return Me.mdtNgaySinh
			End Get
			Set(value As DateTime)
				Me.mdtNgaySinh = value
			End Set
		End Property

		' Token: 0x1700069F RID: 1695
		' (get) Token: 0x060012DC RID: 4828 RVA: 0x000E4F7C File Offset: 0x000E317C
		' (set) Token: 0x060012DD RID: 4829 RVA: 0x00004E1F File Offset: 0x0000301F
		Public Property pstrDiachi As String
			Get
				Return Me.mStrDiaChi
			End Get
			Set(value As String)
				Me.mStrDiaChi = value
			End Set
		End Property

		' Token: 0x170006A0 RID: 1696
		' (get) Token: 0x060012DE RID: 4830 RVA: 0x000E4F94 File Offset: 0x000E3194
		' (set) Token: 0x060012DF RID: 4831 RVA: 0x00004E2A File Offset: 0x0000302A
		Public Property pstrMaNHOMdv As String
			Get
				Return Me.mStrMaNhomDV
			End Get
			Set(value As String)
				Me.mStrMaNhomDV = value
			End Set
		End Property

		' Token: 0x170006A1 RID: 1697
		' (get) Token: 0x060012E0 RID: 4832 RVA: 0x000E4FAC File Offset: 0x000E31AC
		' (set) Token: 0x060012E1 RID: 4833 RVA: 0x00004E35 File Offset: 0x00003035
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060012E2 RID: 4834 RVA: 0x000E4FC4 File Offset: 0x000E31C4
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrMaDV = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
				Me.mStrTenDV = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJNAME").Value)
				Me.mStrMaNhomDV = Conversions.ToString(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value)
				Me.mStrDiaChi = Conversions.ToString(Me.dgvData.CurrentRow.Cells("ADDRESS").Value)
				Me.mStrDienThoai = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TEL").Value)
				Me.mdtNgaySinh = Conversions.ToDate(Me.dgvData.CurrentRow.Cells("NGAYSINH").Value)
				Try
					Process.GetProcessesByName("MyKey")(0).Kill()
				Catch ex As Exception
				End Try
				Me.Close()
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012E3 RID: 4835 RVA: 0x000E51B0 File Offset: 0x000E33B0
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012E4 RID: 4836 RVA: 0x000E5280 File Offset: 0x000E3480
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012E5 RID: 4837 RVA: 0x000E5370 File Offset: 0x000E3570
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012E6 RID: 4838 RVA: 0x000E5454 File Offset: 0x000E3654
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012E7 RID: 4839 RVA: 0x000E5518 File Offset: 0x000E3718
		Private Sub txtOBJIDNH_KeyDown(sender As Object, e As KeyEventArgs)
			Try
				Dim keyCode As Keys = e.KeyCode
				Dim flag As Boolean = keyCode = Keys.Down
				If flag Then
					Dim flag2 As Boolean = Me.mbdsSource.Count > 0
					If flag2 Then
						Me.dgvData.Focus()
					Else
						Me.txtOBJIDNH.Focus()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJIDNH_KeyDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012E8 RID: 4840 RVA: 0x000E55EC File Offset: 0x000E37EC
		Private Sub dgvData_KeyDown(sender As Object, e As KeyEventArgs)
			Try
				Dim keyCode As Keys = e.KeyCode
				Dim flag As Boolean = keyCode = Keys.[Return]
				If flag Then
					Dim flag2 As Boolean = Me.mbdsSource.Count > 0
					If flag2 Then
						Me.mStrMaDV = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
						Me.mStrTenDV = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJNAME").Value)
						Me.mStrMaNhomDV = Conversions.ToString(Me.dgvData.CurrentRow.Cells("MANHOMDV").Value)
						Me.mStrDiaChi = Conversions.ToString(Me.dgvData.CurrentRow.Cells("ADDRESS").Value)
						Me.mStrDienThoai = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TEL").Value)
						Me.mdtNgaySinh = Conversions.ToDate(Me.dgvData.CurrentRow.Cells("NGAYSINH").Value)
						Me.Close()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_KeyDown ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012E9 RID: 4841 RVA: 0x000E57C8 File Offset: 0x000E39C8
		Private Sub frmDMHH1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMHH1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012EA RID: 4842 RVA: 0x000E5860 File Offset: 0x000E3A60
		Private Sub frmDMHH1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Me.CancelButton = Me.btnExit
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = Me.mBlnCallFromFunction
				If flag Then
					Me.Top = 0
					Me.btnKeyboard_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDV_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012EB RID: 4843 RVA: 0x000E597C File Offset: 0x000E3B7C
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012EC RID: 4844 RVA: 0x000E5A14 File Offset: 0x000E3C14
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012ED RID: 4845 RVA: 0x000E5AC4 File Offset: 0x000E3CC4
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("ADDRESS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("ADDRESS").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("ADDRESS").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TEL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(29))
				dgvData.Columns("TEL").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("TEL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MOBILE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(30))
				dgvData.Columns("MOBILE").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("MOBILE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(36))
				dgvData.Columns("REMARK").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("BIRTHDAY").Visible = False
				dgvData.Columns("MANHOMDV").Visible = False
				dgvData.Columns("VATCODE").Visible = False
				dgvData.Columns("FAX").Visible = False
				dgvData.Columns("CONTACT").Visible = False
				dgvData.Columns("ISSUP").Visible = False
				dgvData.Columns("ISCUS").Visible = False
				dgvData.Columns("EMAIL").Visible = False
				dgvData.Columns("WEBSITE").Visible = False
				dgvData.Columns("ISFOR").Visible = False
				dgvData.Columns("ISORG").Visible = False
				dgvData.Columns("MAKH").Visible = False
				dgvData.Columns("TENKH").Visible = False
				dgvData.Columns("FIXED").Visible = False
				dgvData.Columns("TUOI").Visible = False
				dgvData.Columns("GIOITINH").Visible = False
				dgvData.Columns("JOB").Visible = False
				dgvData.Columns("MAUSERUP").Visible = False
				dgvData.Columns("UIMAGE").Visible = False
				dgvData.Columns("CAP").Visible = False
				dgvData.Columns("CHUCVU").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060012EE RID: 4846 RVA: 0x000E6034 File Offset: 0x000E4234
		Private Function fGetData_4Grid() As Byte
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				Me.mclsTbDMDV = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDV_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = Me.mclsTbDMDV
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060012EF RID: 4847 RVA: 0x000E6128 File Offset: 0x000E4328
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060012F0 RID: 4848 RVA: 0x000E61D4 File Offset: 0x000E43D4
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060012F1 RID: 4849 RVA: 0x000E62E0 File Offset: 0x000E44E0
		Private Sub sClear_Form()
			Try
				Dim flag As Boolean = Me.mbdsSource IsNot Nothing
				If flag Then
					Me.mbdsSource.Dispose()
				End If
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060012F2 RID: 4850 RVA: 0x000E639C File Offset: 0x000E459C
		Private Sub txtOBJIDNH_TextChanged(sender As Object, e As EventArgs)
			Dim text As String = Strings.UCase(Me.txtOBJIDNH.Text.Trim())
			Dim text2 As String = ""
			Dim flag As Boolean = Operators.CompareString(text, "", False) = 0
			If flag Then
				Me.mbdsSource.RemoveFilter()
			Else
				flag = (Me.mclsTbDMDV.Rows.Count > 0) And (Operators.CompareString(text, "", False) <> 0)
				Dim flag3 As Boolean
				If flag Then
					Dim num As Integer = 0
					Dim num2 As Integer = Me.mclsTbDMDV.Rows.Count - 1
					Dim num3 As Integer = num
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							Exit For
						End If
						Dim obj As Object = Nothing
						Dim typeFromHandle As Type = GetType(Strings)
						Dim text3 As String = "UCase"
						Dim array As Object() = New Object(0) {}
						Dim array2 As Object() = array
						Dim num6 As Integer = 0
						Dim dataRow As DataRow = Me.mclsTbDMDV.Rows(num3)
						Dim dataRow2 As DataRow = dataRow
						Dim text4 As String = "OBJID"
						array2(num6) = RuntimeHelpers.GetObjectValue(dataRow2(text4))
						Dim array3 As Object() = array
						Dim array4 As Object() = array3
						Dim array5 As String() = Nothing
						Dim array6 As Type() = Nothing
						Dim array7 As Boolean() = New Boolean() { True }
						Dim obj2 As Object = NewLateBinding.LateGet(obj, typeFromHandle, text3, array4, array5, array6, array7)
						If array7(0) Then
							dataRow(text4) = RuntimeHelpers.GetObjectValue(array3(0))
						End If
						If Strings.InStr(Conversions.ToString(obj2), text, CompareMethod.Binary) > 0 Then
							GoTo IL_01A8
						End If
						Dim obj3 As Object = Nothing
						Dim typeFromHandle2 As Type = GetType(Strings)
						Dim text5 As String = "UCase"
						Dim array8 As Object() = New Object(0) {}
						Dim array9 As Object() = array8
						Dim num7 As Integer = 0
						Dim dataRow3 As DataRow = Me.mclsTbDMDV.Rows(num3)
						Dim dataRow4 As DataRow = dataRow3
						Dim text6 As String = "OBJNAME"
						array9(num7) = RuntimeHelpers.GetObjectValue(dataRow4(text6))
						Dim array10 As Object() = array8
						Dim array11 As Object() = array10
						Dim array12 As String() = Nothing
						Dim array13 As Type() = Nothing
						Dim array14 As Boolean() = New Boolean() { True }
						Dim obj4 As Object = NewLateBinding.LateGet(obj3, typeFromHandle2, text5, array11, array12, array13, array14)
						If array14(0) Then
							dataRow3(text6) = RuntimeHelpers.GetObjectValue(array10(0))
						End If
						If Strings.InStr(mdlPrintReceipt.gfRemove_signVie(Conversions.ToString(obj4)), text, CompareMethod.Binary) > 0 Then
							GoTo IL_01A8
						End If
						Dim obj5 As Object = Nothing
						Dim typeFromHandle3 As Type = GetType(Strings)
						Dim text7 As String = "UCase"
						Dim array15 As Object() = New Object(0) {}
						Dim array16 As Object() = array15
						Dim num8 As Integer = 0
						Dim dataRow5 As DataRow = Me.mclsTbDMDV.Rows(num3)
						Dim dataRow6 As DataRow = dataRow5
						Dim text8 As String = "OBJNAME"
						array16(num8) = RuntimeHelpers.GetObjectValue(dataRow6(text8))
						Dim array17 As Object() = array15
						Dim array18 As Object() = array17
						Dim array19 As String() = Nothing
						Dim array20 As Type() = Nothing
						Dim array21 As Boolean() = New Boolean() { True }
						Dim obj6 As Object = NewLateBinding.LateGet(obj5, typeFromHandle3, text7, array18, array19, array20, array21)
						If array21(0) Then
							dataRow5(text8) = RuntimeHelpers.GetObjectValue(array17(0))
						End If
						If Strings.InStr(Conversions.ToString(obj6), text, CompareMethod.Binary) > 0 Then
							GoTo IL_0236
						End If
						Dim obj7 As Object = Nothing
						Dim typeFromHandle4 As Type = GetType(Strings)
						Dim text9 As String = "UCase"
						Dim array22 As Object() = New Object(0) {}
						Dim array23 As Object() = array22
						Dim num9 As Integer = 0
						Dim dataRow7 As DataRow = Me.mclsTbDMDV.Rows(num3)
						Dim dataRow8 As DataRow = dataRow7
						Dim text10 As String = "TEL"
						array23(num9) = RuntimeHelpers.GetObjectValue(dataRow8(text10))
						Dim array24 As Object() = array22
						Dim array25 As Object() = array24
						Dim array26 As String() = Nothing
						Dim array27 As Type() = Nothing
						Dim array28 As Boolean() = New Boolean() { True }
						Dim obj8 As Object = NewLateBinding.LateGet(obj7, typeFromHandle4, text9, array25, array26, array27, array28)
						If array28(0) Then
							dataRow7(text10) = RuntimeHelpers.GetObjectValue(array24(0))
						End If
						If Strings.InStr(Conversions.ToString(obj8), text, CompareMethod.Binary) > 0 Then
							GoTo IL_02C4
						End If
						Dim obj9 As Object = Nothing
						Dim typeFromHandle5 As Type = GetType(Strings)
						Dim text11 As String = "UCase"
						Dim array29 As Object() = New Object(0) {}
						Dim array30 As Object() = array29
						Dim num10 As Integer = 0
						Dim dataRow9 As DataRow = Me.mclsTbDMDV.Rows(num3)
						Dim dataRow10 As DataRow = dataRow9
						Dim text12 As String = "MOBILE"
						array30(num10) = RuntimeHelpers.GetObjectValue(dataRow10(text12))
						Dim array31 As Object() = array29
						Dim array32 As Object() = array31
						Dim array33 As String() = Nothing
						Dim array34 As Type() = Nothing
						Dim array35 As Boolean() = New Boolean() { True }
						Dim obj10 As Object = NewLateBinding.LateGet(obj9, typeFromHandle5, text11, array32, array33, array34, array35)
						If array35(0) Then
							dataRow9(text12) = RuntimeHelpers.GetObjectValue(array31(0))
						End If
						If Strings.InStr(Conversions.ToString(obj10), text, CompareMethod.Binary) > 0 Then
							GoTo IL_0355
						End If
						Dim flag2 As Boolean = False
						IL_0356:
						flag3 = flag2
						If flag3 Then
							text2 = text2 + "'" + Me.mclsTbDMDV.Rows(num3)("OBJID").ToString().Trim() + "',"
						End If
						num3 += 1
						Continue For
						IL_0355:
						flag2 = True
						GoTo IL_0356
						IL_02C4:
						GoTo IL_0355
						IL_0236:
						GoTo IL_02C4
						IL_01A8:
						GoTo IL_0236
					End While
				End If
				flag3 = Operators.CompareString(text2, "", False) = 0
				If flag3 Then
					text2 = "12345678901234567890"
				End If
				text2 = Strings.Left(text2, text2.Length - 1)
				Me.mbdsSource.Filter = "OBJID IN (" + text2 + ")"
			End If
		End Sub

		' Token: 0x060012F3 RID: 4851 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x060012F4 RID: 4852 RVA: 0x000E6794 File Offset: 0x000E4994
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				Me.txtOBJIDNH.Focus()
				Me.txtOBJIDNH.SelectAll()
				Me.Focus()
			End If
		End Sub

		' Token: 0x040007D6 RID: 2006
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040007D8 RID: 2008
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040007D9 RID: 2009
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x040007DA RID: 2010
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x040007DB RID: 2011
		<AccessedThroughProperty("lblMANH")>
		Private _lblMANH As Label

		' Token: 0x040007DC RID: 2012
		<AccessedThroughProperty("txtOBJIDNH")>
		Private _txtOBJIDNH As TextBox

		' Token: 0x040007DD RID: 2013
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x040007DE RID: 2014
		Private mArrStrFrmMess As String()

		' Token: 0x040007DF RID: 2015
		Private mStrMaDV As String

		' Token: 0x040007E0 RID: 2016
		Private mStrTenDV As String

		' Token: 0x040007E1 RID: 2017
		Private mStrMaNhomDV As String

		' Token: 0x040007E2 RID: 2018
		Private mStrDiaChi As String

		' Token: 0x040007E3 RID: 2019
		Private mStrDienThoai As String

		' Token: 0x040007E4 RID: 2020
		Private mdtNgaySinh As DateTime

		' Token: 0x040007E5 RID: 2021
		Private mBytOpen_FromMenu As Byte

		' Token: 0x040007E6 RID: 2022
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x040007E7 RID: 2023
		Private marrDrFind As DataRow()

		' Token: 0x040007E8 RID: 2024
		Private mintFindLastPos As Integer

		' Token: 0x040007E9 RID: 2025
		Private mclsTbDMDV As clsConnect

		' Token: 0x040007EA RID: 2026
		Private mBlnCallFromFunction As Boolean
	End Class
End Namespace
