﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x02000121 RID: 289
	Public Class crptKARAKA5
		Inherits ReportClass

		' Token: 0x060057A0 RID: 22432 RVA: 0x0000F0A8 File Offset: 0x0000D2A8
		Public Sub New()
			crptKARAKA5.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001FA8 RID: 8104
		' (get) Token: 0x060057A1 RID: 22433 RVA: 0x004DAF88 File Offset: 0x004D9188
		' (set) Token: 0x060057A2 RID: 22434 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crptKARAKA5.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001FA9 RID: 8105
		' (get) Token: 0x060057A3 RID: 22435 RVA: 0x004DA738 File Offset: 0x004D8938
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section1 As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001FAA RID: 8106
		' (get) Token: 0x060057A4 RID: 22436 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section2 As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001FAB RID: 8107
		' (get) Token: 0x060057A5 RID: 22437 RVA: 0x004DA780 File Offset: 0x004D8980
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section3 As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001FAC RID: 8108
		' (get) Token: 0x060057A6 RID: 22438 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property DetailSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001FAD RID: 8109
		' (get) Token: 0x060057A7 RID: 22439 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section4 As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001FAE RID: 8110
		' (get) Token: 0x060057A8 RID: 22440 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x04002719 RID: 10009
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
