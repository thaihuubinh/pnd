﻿Namespace prjIS_SalesPOS
	' Token: 0x02000060 RID: 96
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMMAY2
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06001CD8 RID: 7384 RVA: 0x00164DB8 File Offset: 0x00162FB8
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06001CD9 RID: 7385 RVA: 0x00164DF0 File Offset: 0x00162FF0
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMMAY2))
			Me.grpButton = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnKeyboard = New Global.System.Windows.Forms.Button()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.lblMAHH = New Global.System.Windows.Forms.Label()
			Me.txtMAKHO = New Global.System.Windows.Forms.TextBox()
			Me.lblMAKH = New Global.System.Windows.Forms.Label()
			Me.txtGHICHU = New Global.System.Windows.Forms.TextBox()
			Me.lblMIN = New Global.System.Windows.Forms.Label()
			Me.lblMAX = New Global.System.Windows.Forms.Label()
			Me.txtTENMAY = New Global.System.Windows.Forms.TextBox()
			Me.btnDMKH = New Global.System.Windows.Forms.Button()
			Me.txtTENkho = New Global.System.Windows.Forms.TextBox()
			Me.txtMAMAY = New Global.System.Windows.Forms.TextBox()
			Me.txtIP = New Global.System.Windows.Forms.TextBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.txtServer = New Global.System.Windows.Forms.TextBox()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.grpButton.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			Me.SuspendLayout()
			Me.grpButton.Controls.Add(Me.TableLayoutPanel1)
			Me.grpButton.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpButton As Global.System.Windows.Forms.Control = Me.grpButton
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(536, 0)
			grpButton.Location = point
			Me.grpButton.Name = "grpButton"
			Dim grpButton2 As Global.System.Windows.Forms.Control = Me.grpButton
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(119, 490)
			grpButton2.Size = size
			Me.grpButton.TabIndex = 5
			Me.grpButton.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnKeyboard, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 2)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 6
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 16.66667F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 469)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnKeyboard.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Zoom
			Me.btnKeyboard.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnKeyboard.Image = Global.prjIS_SalesPOS.My.Resources.Resources.keyboard_ico
			Me.btnKeyboard.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnKeyboard As Global.System.Windows.Forms.Control = Me.btnKeyboard
			point = New Global.System.Drawing.Point(3, 3)
			btnKeyboard.Location = point
			Me.btnKeyboard.Name = "btnKeyboard"
			Dim btnKeyboard2 As Global.System.Windows.Forms.Control = Me.btnKeyboard
			size = New Global.System.Drawing.Size(107, 72)
			btnKeyboard2.Size = size
			Me.btnKeyboard.TabIndex = 126
			Me.btnKeyboard.Text = "Keyboard"
			Me.btnKeyboard.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnKeyboard.UseVisualStyleBackColor = True
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 237)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(107, 72)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 6
			Me.btnFilter.Tag = "CR0005"
			Me.btnFilter.Text = "Lọ&c"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = True
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 393)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 73)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 8
			Me.btnExit.Tag = "CR0009"
			Me.btnExit.Text = "T&hoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 315)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(107, 72)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 7
			Me.btnFind.Tag = "CR0006"
			Me.btnFind.Text = "&Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = True
			Me.btnSave.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources.luu
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(3, 81)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(107, 72)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 4
			Me.btnSave.Tag = "CR0003"
			Me.btnSave.Text = "&Lưu"
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = True
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 159)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 72)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 5
			Me.btnDelete.Tag = "CR0004"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.lblMAHH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAHH As Global.System.Windows.Forms.Control = Me.lblMAHH
			point = New Global.System.Drawing.Point(7, 42)
			lblMAHH.Location = point
			Me.lblMAHH.Name = "lblMAHH"
			Dim lblMAHH2 As Global.System.Windows.Forms.Control = Me.lblMAHH
			size = New Global.System.Drawing.Size(154, 21)
			lblMAHH2.Size = size
			Me.lblMAHH.TabIndex = 34
			Me.lblMAHH.Tag = "CB0008"
			Me.lblMAHH.Text = "Tên "
			Me.txtMAKHO.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtMAKHO.Font = New Global.System.Drawing.Font("Arial", 11F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtMAKHO As Global.System.Windows.Forms.Control = Me.txtMAKHO
			point = New Global.System.Drawing.Point(162, 67)
			txtMAKHO.Location = point
			Me.txtMAKHO.Name = "txtMAKHO"
			Dim txtMAKHO2 As Global.System.Windows.Forms.Control = Me.txtMAKHO
			size = New Global.System.Drawing.Size(122, 24)
			txtMAKHO2.Size = size
			Me.txtMAKHO.TabIndex = 2
			Me.txtMAKHO.Tag = "0R0000"
			Me.lblMAKH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAKH As Global.System.Windows.Forms.Control = Me.lblMAKH
			point = New Global.System.Drawing.Point(7, 15)
			lblMAKH.Location = point
			Me.lblMAKH.Name = "lblMAKH"
			Dim lblMAKH2 As Global.System.Windows.Forms.Control = Me.lblMAKH
			size = New Global.System.Drawing.Size(154, 21)
			lblMAKH2.Size = size
			Me.lblMAKH.TabIndex = 33
			Me.lblMAKH.Tag = "CB0007"
			Me.lblMAKH.Text = "Mã"
			Me.txtGHICHU.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtGHICHU.Font = New Global.System.Drawing.Font("Arial", 11F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtGHICHU As Global.System.Windows.Forms.Control = Me.txtGHICHU
			point = New Global.System.Drawing.Point(162, 152)
			txtGHICHU.Location = point
			Me.txtGHICHU.Name = "txtGHICHU"
			Dim txtGHICHU2 As Global.System.Windows.Forms.Control = Me.txtGHICHU
			size = New Global.System.Drawing.Size(371, 24)
			txtGHICHU2.Size = size
			Me.txtGHICHU.TabIndex = 4
			Me.txtGHICHU.Tag = "0R0000"
			Me.lblMIN.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMIN As Global.System.Windows.Forms.Control = Me.lblMIN
			point = New Global.System.Drawing.Point(7, 70)
			lblMIN.Location = point
			Me.lblMIN.Name = "lblMIN"
			Dim lblMIN2 As Global.System.Windows.Forms.Control = Me.lblMIN
			size = New Global.System.Drawing.Size(154, 21)
			lblMIN2.Size = size
			Me.lblMIN.TabIndex = 39
			Me.lblMIN.Tag = "CB0010"
			Me.lblMIN.Text = "Mã kho"
			Me.lblMAX.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMAX As Global.System.Windows.Forms.Control = Me.lblMAX
			point = New Global.System.Drawing.Point(7, 155)
			lblMAX.Location = point
			Me.lblMAX.Name = "lblMAX"
			Dim lblMAX2 As Global.System.Windows.Forms.Control = Me.lblMAX
			size = New Global.System.Drawing.Size(154, 21)
			lblMAX2.Size = size
			Me.lblMAX.TabIndex = 40
			Me.lblMAX.Tag = "CR0032"
			Me.lblMAX.Text = "Tên "
			Me.txtTENMAY.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtTENMAY.Font = New Global.System.Drawing.Font("Arial", 11F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtTENMAY As Global.System.Windows.Forms.Control = Me.txtTENMAY
			point = New Global.System.Drawing.Point(162, 39)
			txtTENMAY.Location = point
			Me.txtTENMAY.Name = "txtTENMAY"
			Dim txtTENMAY2 As Global.System.Windows.Forms.Control = Me.txtTENMAY
			size = New Global.System.Drawing.Size(371, 24)
			txtTENMAY2.Size = size
			Me.txtTENMAY.TabIndex = 1
			Me.txtTENMAY.Tag = "0R0000"
			Me.btnDMKH.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnDMKH As Global.System.Windows.Forms.Control = Me.btnDMKH
			point = New Global.System.Drawing.Point(290, 65)
			btnDMKH.Location = point
			Me.btnDMKH.Name = "btnDMKH"
			Dim btnDMKH2 As Global.System.Windows.Forms.Control = Me.btnDMKH
			size = New Global.System.Drawing.Size(45, 25)
			btnDMKH2.Size = size
			Me.btnDMKH.TabIndex = 3
			Me.btnDMKH.Tag = "CB0011"
			Me.btnDMKH.UseVisualStyleBackColor = True
			Me.txtTENkho.BackColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			Dim txtTENkho As Global.System.Windows.Forms.Control = Me.txtTENkho
			point = New Global.System.Drawing.Point(341, 67)
			txtTENkho.Location = point
			Me.txtTENkho.Name = "txtTENkho"
			Dim txtTENkho2 As Global.System.Windows.Forms.Control = Me.txtTENkho
			size = New Global.System.Drawing.Size(192, 22)
			txtTENkho2.Size = size
			Me.txtTENkho.TabIndex = 6
			Me.txtTENkho.Tag = "0R0000"
			Me.txtMAMAY.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtMAMAY.Font = New Global.System.Drawing.Font("Arial", 11F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtMAMAY As Global.System.Windows.Forms.Control = Me.txtMAMAY
			point = New Global.System.Drawing.Point(162, 12)
			txtMAMAY.Location = point
			Me.txtMAMAY.Name = "txtMAMAY"
			Dim txtMAMAY2 As Global.System.Windows.Forms.Control = Me.txtMAMAY
			size = New Global.System.Drawing.Size(122, 24)
			txtMAMAY2.Size = size
			Me.txtMAMAY.TabIndex = 0
			Me.txtMAMAY.Tag = "0R0000"
			Me.txtIP.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtIP.Font = New Global.System.Drawing.Font("Arial", 11F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtIP As Global.System.Windows.Forms.Control = Me.txtIP
			point = New Global.System.Drawing.Point(162, 96)
			txtIP.Location = point
			Me.txtIP.Name = "txtIP"
			Dim txtIP2 As Global.System.Windows.Forms.Control = Me.txtIP
			size = New Global.System.Drawing.Size(371, 24)
			txtIP2.Size = size
			Me.txtIP.TabIndex = 4
			Me.txtIP.Tag = "0R0000"
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(7, 99)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(154, 21)
			label2.Size = size
			Me.Label1.TabIndex = 40
			Me.Label1.Tag = "CR0044"
			Me.Label1.Text = "ip"
			Me.txtServer.BackColor = Global.System.Drawing.SystemColors.Window
			Me.txtServer.Font = New Global.System.Drawing.Font("Arial", 11F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtServer As Global.System.Windows.Forms.Control = Me.txtServer
			point = New Global.System.Drawing.Point(162, 124)
			txtServer.Location = point
			Me.txtServer.Name = "txtServer"
			Dim txtServer2 As Global.System.Windows.Forms.Control = Me.txtServer
			size = New Global.System.Drawing.Size(371, 24)
			txtServer2.Size = size
			Me.txtServer.TabIndex = 4
			Me.txtServer.Tag = "0R0000"
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(7, 127)
			label3.Location = point
			Me.Label2.Name = "Label2"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(154, 21)
			label4.Size = size
			Me.Label2.TabIndex = 40
			Me.Label2.Tag = "CR0045"
			Me.Label2.Text = "server"
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(655, 490)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.lblMAX)
			Me.Controls.Add(Me.lblMIN)
			Me.Controls.Add(Me.txtTENkho)
			Me.Controls.Add(Me.txtMAMAY)
			Me.Controls.Add(Me.btnDMKH)
			Me.Controls.Add(Me.txtTENMAY)
			Me.Controls.Add(Me.txtServer)
			Me.Controls.Add(Me.txtIP)
			Me.Controls.Add(Me.txtGHICHU)
			Me.Controls.Add(Me.lblMAHH)
			Me.Controls.Add(Me.txtMAKHO)
			Me.Controls.Add(Me.lblMAKH)
			Me.Controls.Add(Me.grpButton)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "frmDMMAY2"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "DMMAY2"
			Me.grpButton.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x04000BCD RID: 3021
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
