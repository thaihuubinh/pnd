﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000314 RID: 788
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptSALBC02016
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600712D RID: 28973 RVA: 0x00014093 File Offset: 0x00012293
		Public Sub New()
			CachedrptSALBC02016.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002F78 RID: 12152
		' (get) Token: 0x0600712E RID: 28974 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x0600712F RID: 28975 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002F79 RID: 12153
		' (get) Token: 0x06007130 RID: 28976 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06007131 RID: 28977 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002F7A RID: 12154
		' (get) Token: 0x06007132 RID: 28978 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06007133 RID: 28979 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06007134 RID: 28980 RVA: 0x004DF4C4 File Offset: 0x004DD6C4
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptSALBC02016() With { .Site = Me.Site }
		End Function

		' Token: 0x06007135 RID: 28981 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x0400290C RID: 10508
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
