﻿Namespace prjIS_SalesPOS
	' Token: 0x02000031 RID: 49
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDanhSachPThe
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000A52 RID: 2642 RVA: 0x0007936C File Offset: 0x0007756C
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06000A53 RID: 2643 RVA: 0x000793A4 File Offset: 0x000775A4
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDanhSachPThe))
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Me.btnPreview = New Global.System.Windows.Forms.Button()
			Me.grpControl = New Global.System.Windows.Forms.GroupBox()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnPrintMayInHD = New Global.System.Windows.Forms.Button()
			Me.dgvData = New Global.System.Windows.Forms.DataGridView()
			Me.lblFilterDate = New Global.System.Windows.Forms.Label()
			Me.btnCancel = New Global.System.Windows.Forms.Button()
			Me.mtxFromDate = New Global.System.Windows.Forms.MaskedTextBox()
			Me.dtpTuNgay = New Global.System.Windows.Forms.DateTimePicker()
			Me.cboNgay = New Global.System.Windows.Forms.ComboBox()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.mtxToDate = New Global.System.Windows.Forms.MaskedTextBox()
			Me.dtpDenNgay = New Global.System.Windows.Forms.DateTimePicker()
			Me.Label2 = New Global.System.Windows.Forms.Label()
			Me.grpControl.SuspendLayout()
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.btnPreview.Image = Global.prjIS_SalesPOS.My.Resources.Resources._in
			Dim btnPreview As Global.System.Windows.Forms.Control = Me.btnPreview
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(272, 15)
			btnPreview.Location = point
			Me.btnPreview.Name = "btnPreview"
			Dim btnPreview2 As Global.System.Windows.Forms.Control = Me.btnPreview
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(90, 42)
			btnPreview2.Size = size
			Me.btnPreview.TabIndex = 7
			Me.btnPreview.Tag = "CR0012"
			Me.btnPreview.Text = "In"
			Me.btnPreview.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnPreview.UseVisualStyleBackColor = True
			Me.grpControl.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom
			Me.grpControl.Controls.Add(Me.btnDelete)
			Me.grpControl.Controls.Add(Me.btnExit)
			Me.grpControl.Controls.Add(Me.btnPrintMayInHD)
			Me.grpControl.Controls.Add(Me.btnPreview)
			Dim grpControl As Global.System.Windows.Forms.Control = Me.grpControl
			point = New Global.System.Drawing.Point(113, 438)
			grpControl.Location = point
			Me.grpControl.Name = "grpControl"
			Dim grpControl2 As Global.System.Windows.Forms.Control = Me.grpControl
			size = New Global.System.Drawing.Size(647, 63)
			grpControl2.Size = size
			Me.grpControl.TabIndex = 2
			Me.grpControl.TabStop = False
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(368, 15)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(90, 42)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 13
			Me.btnDelete.Tag = "CR0013"
			Me.btnDelete.Text = "&Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = True
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(551, 15)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(90, 42)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 12
			Me.btnExit.Tag = "CR0014"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.btnPrintMayInHD.Image = CType(componentResourceManager.GetObject("btnPrintMayInHD.Image"), Global.System.Drawing.Image)
			Dim btnPrintMayInHD As Global.System.Windows.Forms.Control = Me.btnPrintMayInHD
			point = New Global.System.Drawing.Point(147, 15)
			btnPrintMayInHD.Location = point
			Me.btnPrintMayInHD.Name = "btnPrintMayInHD"
			Dim btnPrintMayInHD2 As Global.System.Windows.Forms.Control = Me.btnPrintMayInHD
			size = New Global.System.Drawing.Size(119, 42)
			btnPrintMayInHD2.Size = size
			Me.btnPrintMayInHD.TabIndex = 7
			Me.btnPrintMayInHD.Tag = "CR0019"
			Me.btnPrintMayInHD.Text = "In máy in HĐ"
			Me.btnPrintMayInHD.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnPrintMayInHD.UseVisualStyleBackColor = True
			Me.dgvData.AllowUserToAddRows = False
			Me.dgvData.AllowUserToDeleteRows = False
			Me.dgvData.AllowUserToResizeRows = False
			Me.dgvData.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvData.BackgroundColor = Global.System.Drawing.Color.FromArgb(215, 255, 255)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvData.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvData As Global.System.Windows.Forms.Control = Me.dgvData
			point = New Global.System.Drawing.Point(0, 37)
			dgvData.Location = point
			Me.dgvData.Name = "dgvData"
			Me.dgvData.[ReadOnly] = True
			Dim dgvData2 As Global.System.Windows.Forms.Control = Me.dgvData
			size = New Global.System.Drawing.Size(873, 395)
			dgvData2.Size = size
			Me.dgvData.TabIndex = 1
			Me.lblFilterDate.AutoSize = True
			Me.lblFilterDate.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFilterDate As Global.System.Windows.Forms.Control = Me.lblFilterDate
			point = New Global.System.Drawing.Point(7, 9)
			lblFilterDate.Location = point
			Me.lblFilterDate.Name = "lblFilterDate"
			Dim lblFilterDate2 As Global.System.Windows.Forms.Control = Me.lblFilterDate
			size = New Global.System.Drawing.Size(172, 16)
			lblFilterDate2.Size = size
			Me.lblFilterDate.TabIndex = 43
			Me.lblFilterDate.Tag = "CR0003"
			Me.lblFilterDate.Text = "Đang được lọc theo ngày:"
			Me.btnCancel.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim btnCancel As Global.System.Windows.Forms.Control = Me.btnCancel
			point = New Global.System.Drawing.Point(805, 2)
			btnCancel.Location = point
			Me.btnCancel.Name = "btnCancel"
			Dim btnCancel2 As Global.System.Windows.Forms.Control = Me.btnCancel
			size = New Global.System.Drawing.Size(36, 32)
			btnCancel2.Size = size
			Me.btnCancel.TabIndex = 4
			Me.btnCancel.Tag = "N0015B0016"
			Me.btnCancel.Text = "X"
			Me.btnCancel.UseVisualStyleBackColor = True
			Me.btnCancel.Visible = False
			Me.mtxFromDate.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim mtxFromDate As Global.System.Windows.Forms.Control = Me.mtxFromDate
			point = New Global.System.Drawing.Point(425, 3)
			mtxFromDate.Location = point
			Me.mtxFromDate.Mask = "00/00/0000"
			Me.mtxFromDate.Name = "mtxFromDate"
			Me.mtxFromDate.PromptChar = "-"c
			Dim mtxFromDate2 As Global.System.Windows.Forms.Control = Me.mtxFromDate
			size = New Global.System.Drawing.Size(126, 30)
			mtxFromDate2.Size = size
			Me.mtxFromDate.TabIndex = 44
			Me.mtxFromDate.Tag = "N0015B0000"
			Me.mtxFromDate.ValidatingType = GetType(Global.System.DateTime)
			Me.dtpTuNgay.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim dtpTuNgay As Global.System.Windows.Forms.Control = Me.dtpTuNgay
			point = New Global.System.Drawing.Point(551, 3)
			dtpTuNgay.Location = point
			Me.dtpTuNgay.Name = "dtpTuNgay"
			Dim dtpTuNgay2 As Global.System.Windows.Forms.Control = Me.dtpTuNgay
			size = New Global.System.Drawing.Size(20, 30)
			dtpTuNgay2.Size = size
			Me.dtpTuNgay.TabIndex = 45
			Me.cboNgay.DropDownStyle = Global.System.Windows.Forms.ComboBoxStyle.DropDownList
			Me.cboNgay.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.cboNgay.FormattingEnabled = True
			Dim cboNgay As Global.System.Windows.Forms.Control = Me.cboNgay
			point = New Global.System.Drawing.Point(198, 3)
			cboNgay.Location = point
			Me.cboNgay.Name = "cboNgay"
			Dim cboNgay2 As Global.System.Windows.Forms.Control = Me.cboNgay
			size = New Global.System.Drawing.Size(189, 31)
			cboNgay2.Size = size
			Me.cboNgay.TabIndex = 46
			Me.Label1.AutoSize = True
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 14F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(393, 8)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(21, 22)
			label2.Size = size
			Me.Label1.TabIndex = 47
			Me.Label1.Text = "="
			Me.mtxToDate.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim mtxToDate As Global.System.Windows.Forms.Control = Me.mtxToDate
			point = New Global.System.Drawing.Point(655, 3)
			mtxToDate.Location = point
			Me.mtxToDate.Mask = "00/00/0000"
			Me.mtxToDate.Name = "mtxToDate"
			Me.mtxToDate.PromptChar = "-"c
			Dim mtxToDate2 As Global.System.Windows.Forms.Control = Me.mtxToDate
			size = New Global.System.Drawing.Size(126, 30)
			mtxToDate2.Size = size
			Me.mtxToDate.TabIndex = 44
			Me.mtxToDate.Tag = "N0015B0000"
			Me.mtxToDate.ValidatingType = GetType(Global.System.DateTime)
			Me.dtpDenNgay.Font = New Global.System.Drawing.Font("Arial", 15F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim dtpDenNgay As Global.System.Windows.Forms.Control = Me.dtpDenNgay
			point = New Global.System.Drawing.Point(781, 3)
			dtpDenNgay.Location = point
			Me.dtpDenNgay.Name = "dtpDenNgay"
			Dim dtpDenNgay2 As Global.System.Windows.Forms.Control = Me.dtpDenNgay
			size = New Global.System.Drawing.Size(20, 30)
			dtpDenNgay2.Size = size
			Me.dtpDenNgay.TabIndex = 45
			Me.Label2.AutoSize = True
			Me.Label2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim label3 As Global.System.Windows.Forms.Control = Me.Label2
			point = New Global.System.Drawing.Point(577, 9)
			label3.Location = point
			Me.Label2.Name = "Label2"
			Dim label4 As Global.System.Windows.Forms.Control = Me.Label2
			size = New Global.System.Drawing.Size(67, 16)
			label4.Size = size
			Me.Label2.TabIndex = 48
			Me.Label2.Tag = "CR0023"
			Me.Label2.Text = "đến ngày"
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(873, 513)
			Me.ClientSize = size
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.cboNgay)
			Me.Controls.Add(Me.dtpDenNgay)
			Me.Controls.Add(Me.dtpTuNgay)
			Me.Controls.Add(Me.mtxToDate)
			Me.Controls.Add(Me.mtxFromDate)
			Me.Controls.Add(Me.lblFilterDate)
			Me.Controls.Add(Me.btnCancel)
			Me.Controls.Add(Me.dgvData)
			Me.Controls.Add(Me.grpControl)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmDanhSachPThe"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Danh sách bán thẻ khách hàng"
			Me.grpControl.ResumeLayout(False)
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x0400048D RID: 1165
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
