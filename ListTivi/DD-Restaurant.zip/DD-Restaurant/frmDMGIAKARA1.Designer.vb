﻿Namespace prjIS_SalesPOS
	' Token: 0x02000049 RID: 73
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmDMGIAKARA1
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06001382 RID: 4994 RVA: 0x000ECF38 File Offset: 0x000EB138
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x06001383 RID: 4995 RVA: 0x000ECF70 File Offset: 0x000EB170
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmDMGIAKARA1))
			Me.lblPosition = New Global.System.Windows.Forms.Label()
			Me.btnAddDefault = New Global.System.Windows.Forms.Button()
			Me.btnDelete = New Global.System.Windows.Forms.Button()
			Me.btnLast = New Global.System.Windows.Forms.Button()
			Me.btnNext = New Global.System.Windows.Forms.Button()
			Me.btnFind = New Global.System.Windows.Forms.Button()
			Me.btnPreview = New Global.System.Windows.Forms.Button()
			Me.btnCancelFilter = New Global.System.Windows.Forms.Button()
			Me.grpNavigater = New Global.System.Windows.Forms.GroupBox()
			Me.btnFirst = New Global.System.Windows.Forms.Button()
			Me.btnPrevious = New Global.System.Windows.Forms.Button()
			Me.btnFilter = New Global.System.Windows.Forms.Button()
			Me.grpControl = New Global.System.Windows.Forms.GroupBox()
			Me.TableLayoutPanel1 = New Global.System.Windows.Forms.TableLayoutPanel()
			Me.btnAdd = New Global.System.Windows.Forms.Button()
			Me.btnModify = New Global.System.Windows.Forms.Button()
			Me.btnFindNext = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnDetail = New Global.System.Windows.Forms.Button()
			Me.BtnCP = New Global.System.Windows.Forms.Button()
			Me.dgvData = New Global.System.Windows.Forms.DataGridView()
			Me.lblMANH = New Global.System.Windows.Forms.Label()
			Me.txtOBJNAMEKH = New Global.System.Windows.Forms.TextBox()
			Me.btnSelectKH = New Global.System.Windows.Forms.Button()
			Me.txtMAKH = New Global.System.Windows.Forms.TextBox()
			Me.grpNavigater.SuspendLayout()
			Me.grpControl.SuspendLayout()
			Me.TableLayoutPanel1.SuspendLayout()
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.lblPosition.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.lblPosition.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblPosition.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPosition As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(83, 14)
			lblPosition.Location = point
			Me.lblPosition.Name = "lblPosition"
			Dim lblPosition2 As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(93, 35)
			lblPosition2.Size = size
			Me.lblPosition.TabIndex = 6
			Me.lblPosition.Tag = "0R0000"
			Me.lblPosition.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btnAddDefault.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnAddDefault.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnAddDefault.Image = Global.prjIS_SalesPOS.My.Resources.Resources.them_copy
			Dim btnAddDefault As Global.System.Windows.Forms.Control = Me.btnAddDefault
			point = New Global.System.Drawing.Point(3, 42)
			btnAddDefault.Location = point
			Me.btnAddDefault.Name = "btnAddDefault"
			Dim btnAddDefault2 As Global.System.Windows.Forms.Control = Me.btnAddDefault
			size = New Global.System.Drawing.Size(107, 33)
			btnAddDefault2.Size = size
			Me.btnAddDefault.TabIndex = 3
			Me.btnAddDefault.Tag = "CR0005"
			Me.btnAddDefault.Text = "Thêm sửa"
			Me.btnAddDefault.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnAddDefault.UseVisualStyleBackColor = False
			Me.btnDelete.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnDelete.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDelete.Image = Global.prjIS_SalesPOS.My.Resources.Resources.xoa
			Dim btnDelete As Global.System.Windows.Forms.Control = Me.btnDelete
			point = New Global.System.Drawing.Point(3, 120)
			btnDelete.Location = point
			Me.btnDelete.Name = "btnDelete"
			Dim btnDelete2 As Global.System.Windows.Forms.Control = Me.btnDelete
			size = New Global.System.Drawing.Size(107, 33)
			btnDelete2.Size = size
			Me.btnDelete.TabIndex = 2
			Me.btnDelete.Tag = "CR0007"
			Me.btnDelete.Text = "Xóa"
			Me.btnDelete.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDelete.UseVisualStyleBackColor = False
			Me.btnLast.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi_1
			Dim btnLast As Global.System.Windows.Forms.Control = Me.btnLast
			point = New Global.System.Drawing.Point(213, 14)
			btnLast.Location = point
			Me.btnLast.Name = "btnLast"
			Dim btnLast2 As Global.System.Windows.Forms.Control = Me.btnLast
			size = New Global.System.Drawing.Size(40, 35)
			btnLast2.Size = size
			Me.btnLast.TabIndex = 5
			Me.btnLast.UseVisualStyleBackColor = True
			Me.btnNext.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi
			Dim btnNext As Global.System.Windows.Forms.Control = Me.btnNext
			point = New Global.System.Drawing.Point(175, 14)
			btnNext.Location = point
			Me.btnNext.Name = "btnNext"
			Dim btnNext2 As Global.System.Windows.Forms.Control = Me.btnNext
			size = New Global.System.Drawing.Size(40, 35)
			btnNext2.Size = size
			Me.btnNext.TabIndex = 4
			Me.btnNext.UseVisualStyleBackColor = True
			Me.btnFind.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnFind.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFind.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnFind.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim
			Dim btnFind As Global.System.Windows.Forms.Control = Me.btnFind
			point = New Global.System.Drawing.Point(3, 237)
			btnFind.Location = point
			Me.btnFind.Name = "btnFind"
			Dim btnFind2 As Global.System.Windows.Forms.Control = Me.btnFind
			size = New Global.System.Drawing.Size(107, 33)
			btnFind2.Size = size
			Me.btnFind.TabIndex = 4
			Me.btnFind.Tag = "CR0010"
			Me.btnFind.Text = "Tìm"
			Me.btnFind.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFind.UseVisualStyleBackColor = False
			Me.btnPreview.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnPreview.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnPreview.Image = Global.prjIS_SalesPOS.My.Resources.Resources._in
			Dim btnPreview As Global.System.Windows.Forms.Control = Me.btnPreview
			point = New Global.System.Drawing.Point(3, 315)
			btnPreview.Location = point
			Me.btnPreview.Name = "btnPreview"
			Dim btnPreview2 As Global.System.Windows.Forms.Control = Me.btnPreview
			size = New Global.System.Drawing.Size(107, 33)
			btnPreview2.Size = size
			Me.btnPreview.TabIndex = 7
			Me.btnPreview.Tag = "CR0012"
			Me.btnPreview.Text = "In"
			Me.btnPreview.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnPreview.UseVisualStyleBackColor = False
			Me.btnPreview.Visible = False
			Me.btnCancelFilter.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnCancelFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnCancelFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Cancel
			Dim btnCancelFilter As Global.System.Windows.Forms.Control = Me.btnCancelFilter
			point = New Global.System.Drawing.Point(3, 198)
			btnCancelFilter.Location = point
			Me.btnCancelFilter.Name = "btnCancelFilter"
			Dim btnCancelFilter2 As Global.System.Windows.Forms.Control = Me.btnCancelFilter
			size = New Global.System.Drawing.Size(107, 33)
			btnCancelFilter2.Size = size
			Me.btnCancelFilter.TabIndex = 6
			Me.btnCancelFilter.Tag = "CR0009"
			Me.btnCancelFilter.Text = "Bỏ lọc"
			Me.btnCancelFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnCancelFilter.UseVisualStyleBackColor = False
			Me.grpNavigater.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom
			Me.grpNavigater.BackColor = Global.System.Drawing.SystemColors.Control
			Me.grpNavigater.Controls.Add(Me.lblPosition)
			Me.grpNavigater.Controls.Add(Me.btnFirst)
			Me.grpNavigater.Controls.Add(Me.btnPrevious)
			Me.grpNavigater.Controls.Add(Me.btnLast)
			Me.grpNavigater.Controls.Add(Me.btnNext)
			Dim grpNavigater As Global.System.Windows.Forms.Control = Me.grpNavigater
			point = New Global.System.Drawing.Point(142, 417)
			grpNavigater.Location = point
			Me.grpNavigater.Name = "grpNavigater"
			Dim grpNavigater2 As Global.System.Windows.Forms.Control = Me.grpNavigater
			size = New Global.System.Drawing.Size(260, 61)
			grpNavigater2.Size = size
			Me.grpNavigater.TabIndex = 12
			Me.grpNavigater.TabStop = False
			Me.btnFirst.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui_1
			Dim btnFirst As Global.System.Windows.Forms.Control = Me.btnFirst
			point = New Global.System.Drawing.Point(6, 14)
			btnFirst.Location = point
			Me.btnFirst.Name = "btnFirst"
			Dim btnFirst2 As Global.System.Windows.Forms.Control = Me.btnFirst
			size = New Global.System.Drawing.Size(40, 35)
			btnFirst2.Size = size
			Me.btnFirst.TabIndex = 2
			Me.btnFirst.UseVisualStyleBackColor = True
			Me.btnPrevious.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui
			Dim btnPrevious As Global.System.Windows.Forms.Control = Me.btnPrevious
			point = New Global.System.Drawing.Point(44, 14)
			btnPrevious.Location = point
			Me.btnPrevious.Name = "btnPrevious"
			Dim btnPrevious2 As Global.System.Windows.Forms.Control = Me.btnPrevious
			size = New Global.System.Drawing.Size(40, 35)
			btnPrevious2.Size = size
			Me.btnPrevious.TabIndex = 3
			Me.btnPrevious.UseVisualStyleBackColor = True
			Me.btnFilter.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnFilter.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFilter.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Filter
			Dim btnFilter As Global.System.Windows.Forms.Control = Me.btnFilter
			point = New Global.System.Drawing.Point(3, 159)
			btnFilter.Location = point
			Me.btnFilter.Name = "btnFilter"
			Dim btnFilter2 As Global.System.Windows.Forms.Control = Me.btnFilter
			size = New Global.System.Drawing.Size(107, 33)
			btnFilter2.Size = size
			Me.btnFilter.TabIndex = 5
			Me.btnFilter.Tag = "CR0008"
			Me.btnFilter.Text = "Lọc"
			Me.btnFilter.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFilter.UseVisualStyleBackColor = False
			Me.grpControl.BackColor = Global.System.Drawing.SystemColors.Control
			Me.grpControl.Controls.Add(Me.TableLayoutPanel1)
			Me.grpControl.Dock = Global.System.Windows.Forms.DockStyle.Right
			Dim grpControl As Global.System.Windows.Forms.Control = Me.grpControl
			point = New Global.System.Drawing.Point(536, 0)
			grpControl.Location = point
			Me.grpControl.Name = "grpControl"
			Dim grpControl2 As Global.System.Windows.Forms.Control = Me.grpControl
			size = New Global.System.Drawing.Size(119, 490)
			grpControl2.Size = size
			Me.grpControl.TabIndex = 10
			Me.grpControl.TabStop = False
			Me.TableLayoutPanel1.ColumnCount = 1
			Me.TableLayoutPanel1.ColumnStyles.Add(New Global.System.Windows.Forms.ColumnStyle(Global.System.Windows.Forms.SizeType.Percent, 100F))
			Me.TableLayoutPanel1.Controls.Add(Me.btnCancelFilter, 0, 5)
			Me.TableLayoutPanel1.Controls.Add(Me.btnAdd, 0, 0)
			Me.TableLayoutPanel1.Controls.Add(Me.btnModify, 0, 2)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFilter, 0, 4)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFindNext, 0, 7)
			Me.TableLayoutPanel1.Controls.Add(Me.btnPreview, 0, 8)
			Me.TableLayoutPanel1.Controls.Add(Me.btnAddDefault, 0, 1)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDelete, 0, 3)
			Me.TableLayoutPanel1.Controls.Add(Me.btnFind, 0, 6)
			Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 0, 11)
			Me.TableLayoutPanel1.Controls.Add(Me.btnDetail, 0, 10)
			Me.TableLayoutPanel1.Controls.Add(Me.BtnCP, 0, 9)
			Me.TableLayoutPanel1.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim tableLayoutPanel As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			point = New Global.System.Drawing.Point(3, 18)
			tableLayoutPanel.Location = point
			Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
			Me.TableLayoutPanel1.RowCount = 12
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Me.TableLayoutPanel1.RowStyles.Add(New Global.System.Windows.Forms.RowStyle(Global.System.Windows.Forms.SizeType.Percent, 8.333333F))
			Dim tableLayoutPanel2 As Global.System.Windows.Forms.Control = Me.TableLayoutPanel1
			size = New Global.System.Drawing.Size(113, 469)
			tableLayoutPanel2.Size = size
			Me.TableLayoutPanel1.TabIndex = 0
			Me.btnAdd.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnAdd.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnAdd.Image = Global.prjIS_SalesPOS.My.Resources.Resources.them
			Dim btnAdd As Global.System.Windows.Forms.Control = Me.btnAdd
			point = New Global.System.Drawing.Point(3, 3)
			btnAdd.Location = point
			Me.btnAdd.Name = "btnAdd"
			Dim btnAdd2 As Global.System.Windows.Forms.Control = Me.btnAdd
			size = New Global.System.Drawing.Size(107, 33)
			btnAdd2.Size = size
			Me.btnAdd.TabIndex = 0
			Me.btnAdd.Tag = "CR0004"
			Me.btnAdd.Text = "Thêm"
			Me.btnAdd.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnAdd.UseVisualStyleBackColor = False
			Me.btnModify.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnModify.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnModify.Image = Global.prjIS_SalesPOS.My.Resources.Resources.sua
			Dim btnModify As Global.System.Windows.Forms.Control = Me.btnModify
			point = New Global.System.Drawing.Point(3, 81)
			btnModify.Location = point
			Me.btnModify.Name = "btnModify"
			Dim btnModify2 As Global.System.Windows.Forms.Control = Me.btnModify
			size = New Global.System.Drawing.Size(107, 33)
			btnModify2.Size = size
			Me.btnModify.TabIndex = 1
			Me.btnModify.Tag = "CR0006"
			Me.btnModify.Text = "Sửa"
			Me.btnModify.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnModify.UseVisualStyleBackColor = False
			Me.btnFindNext.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnFindNext.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnFindNext.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnFindNext.Image = Global.prjIS_SalesPOS.My.Resources.Resources.tim_tiep
			Dim btnFindNext As Global.System.Windows.Forms.Control = Me.btnFindNext
			point = New Global.System.Drawing.Point(3, 276)
			btnFindNext.Location = point
			Me.btnFindNext.Name = "btnFindNext"
			Dim btnFindNext2 As Global.System.Windows.Forms.Control = Me.btnFindNext
			size = New Global.System.Drawing.Size(107, 33)
			btnFindNext2.Size = size
			Me.btnFindNext.TabIndex = 8
			Me.btnFindNext.Tag = "CR0011"
			Me.btnFindNext.Text = "Tìm tiếp"
			Me.btnFindNext.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnFindNext.UseVisualStyleBackColor = False
			Me.btnExit.BackColor = Global.System.Drawing.SystemColors.Control
			Me.btnExit.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources.thoat
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(3, 432)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(107, 34)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 12
			Me.btnExit.Tag = "CR0003"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = False
			Me.btnDetail.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.btnDetail.Image = Global.prjIS_SalesPOS.My.Resources.Resources.Text_Document
			Dim btnDetail As Global.System.Windows.Forms.Control = Me.btnDetail
			point = New Global.System.Drawing.Point(3, 393)
			btnDetail.Location = point
			Me.btnDetail.Name = "btnDetail"
			Dim btnDetail2 As Global.System.Windows.Forms.Control = Me.btnDetail
			size = New Global.System.Drawing.Size(107, 33)
			btnDetail2.Size = size
			Me.btnDetail.TabIndex = 14
			Me.btnDetail.Tag = "CR0024"
			Me.btnDetail.Text = "Chi tiết &..."
			Me.btnDetail.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnDetail.UseVisualStyleBackColor = True
			Me.BtnCP.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Dim btnCP As Global.System.Windows.Forms.Control = Me.BtnCP
			point = New Global.System.Drawing.Point(3, 354)
			btnCP.Location = point
			Me.BtnCP.Name = "BtnCP"
			Dim btnCP2 As Global.System.Windows.Forms.Control = Me.BtnCP
			size = New Global.System.Drawing.Size(107, 33)
			btnCP2.Size = size
			Me.BtnCP.TabIndex = 15
			Me.BtnCP.Tag = "CR0026"
			Me.BtnCP.Text = "Chon phong"
			Me.BtnCP.UseVisualStyleBackColor = True
			Me.dgvData.AllowUserToAddRows = False
			Me.dgvData.AllowUserToDeleteRows = False
			Me.dgvData.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvData.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvData.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvData As Global.System.Windows.Forms.Control = Me.dgvData
			point = New Global.System.Drawing.Point(0, 36)
			dgvData.Location = point
			Me.dgvData.Name = "dgvData"
			Me.dgvData.[ReadOnly] = True
			Dim dgvData2 As Global.System.Windows.Forms.Control = Me.dgvData
			size = New Global.System.Drawing.Size(530, 375)
			dgvData2.Size = size
			Me.dgvData.TabIndex = 13
			Me.lblMANH.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblMANH As Global.System.Windows.Forms.Control = Me.lblMANH
			point = New Global.System.Drawing.Point(3, 7)
			lblMANH.Location = point
			Me.lblMANH.Name = "lblMANH"
			Dim lblMANH2 As Global.System.Windows.Forms.Control = Me.lblMANH
			size = New Global.System.Drawing.Size(138, 21)
			lblMANH2.Size = size
			Me.lblMANH.TabIndex = 47
			Me.lblMANH.Tag = "CR0017"
			Me.lblMANH.Text = "Kho"
			Me.txtOBJNAMEKH.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Dim txtOBJNAMEKH As Global.System.Windows.Forms.Control = Me.txtOBJNAMEKH
			point = New Global.System.Drawing.Point(321, 8)
			txtOBJNAMEKH.Location = point
			Me.txtOBJNAMEKH.Name = "txtOBJNAMEKH"
			Dim txtOBJNAMEKH2 As Global.System.Windows.Forms.Control = Me.txtOBJNAMEKH
			size = New Global.System.Drawing.Size(209, 22)
			txtOBJNAMEKH2.Size = size
			Me.txtOBJNAMEKH.TabIndex = 46
			Me.txtOBJNAMEKH.Tag = "0R0000"
			Me.btnSelectKH.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnSelectKH As Global.System.Windows.Forms.Control = Me.btnSelectKH
			point = New Global.System.Drawing.Point(270, 8)
			btnSelectKH.Location = point
			Me.btnSelectKH.Name = "btnSelectKH"
			Dim btnSelectKH2 As Global.System.Windows.Forms.Control = Me.btnSelectKH
			size = New Global.System.Drawing.Size(45, 22)
			btnSelectKH2.Size = size
			Me.btnSelectKH.TabIndex = 45
			Me.btnSelectKH.Tag = ""
			Me.btnSelectKH.UseVisualStyleBackColor = True
			Me.txtMAKH.BackColor = Global.System.Drawing.SystemColors.Window
			Dim txtMAKH As Global.System.Windows.Forms.Control = Me.txtMAKH
			point = New Global.System.Drawing.Point(148, 8)
			txtMAKH.Location = point
			Me.txtMAKH.Name = "txtMAKH"
			Dim txtMAKH2 As Global.System.Windows.Forms.Control = Me.txtMAKH
			size = New Global.System.Drawing.Size(116, 22)
			txtMAKH2.Size = size
			Me.txtMAKH.TabIndex = 44
			Me.txtMAKH.Tag = "0R0000"
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			Me.BackColor = Global.System.Drawing.SystemColors.Control
			size = New Global.System.Drawing.Size(655, 490)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.lblMANH)
			Me.Controls.Add(Me.txtOBJNAMEKH)
			Me.Controls.Add(Me.btnSelectKH)
			Me.Controls.Add(Me.txtMAKH)
			Me.Controls.Add(Me.dgvData)
			Me.Controls.Add(Me.grpNavigater)
			Me.Controls.Add(Me.grpControl)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.None
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmDMGIAKARA1"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Danh mục DNKM"
			Me.WindowState = Global.System.Windows.Forms.FormWindowState.Maximized
			Me.grpNavigater.ResumeLayout(False)
			Me.grpControl.ResumeLayout(False)
			Me.TableLayoutPanel1.ResumeLayout(False)
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x0400081F RID: 2079
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
