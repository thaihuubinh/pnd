﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200003E RID: 62
	<DesignerGenerated()>
	Public Partial Class frmDMDNKM2
		Inherits Form

		' Token: 0x06000E5B RID: 3675 RVA: 0x000AA690 File Offset: 0x000A8890
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMDNKM2_Activated
			AddHandler MyBase.Load, AddressOf Me.frmDMDNKM2_Load
			frmDMDNKM2.__ENCList.Add(New WeakReference(Me))
			Me.mstrKHO = ""
			Me.mstrKHU = ""
			Me.mStrFromDate = ""
			Me.mStrToDate = ""
			Me.mStrFromTime = ""
			Me.mStrToTime = ""
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000519 RID: 1305
		' (get) Token: 0x06000E5E RID: 3678 RVA: 0x000ACAC4 File Offset: 0x000AACC4
		' (set) Token: 0x06000E5F RID: 3679 RVA: 0x000044C5 File Offset: 0x000026C5
		Friend Overridable Property grpButton As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpButton
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpButton = value
			End Set
		End Property

		' Token: 0x1700051A RID: 1306
		' (get) Token: 0x06000E60 RID: 3680 RVA: 0x000ACADC File Offset: 0x000AACDC
		' (set) Token: 0x06000E61 RID: 3681 RVA: 0x000ACAF4 File Offset: 0x000AACF4
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x1700051B RID: 1307
		' (get) Token: 0x06000E62 RID: 3682 RVA: 0x000ACB60 File Offset: 0x000AAD60
		' (set) Token: 0x06000E63 RID: 3683 RVA: 0x000044CF File Offset: 0x000026CF
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._btnExit = value
			End Set
		End Property

		' Token: 0x1700051C RID: 1308
		' (get) Token: 0x06000E64 RID: 3684 RVA: 0x000ACB78 File Offset: 0x000AAD78
		' (set) Token: 0x06000E65 RID: 3685 RVA: 0x000ACB90 File Offset: 0x000AAD90
		Friend Overridable Property btnSave As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSave
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSave IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
				Me._btnSave = value
				flag = Me._btnSave IsNot Nothing
				If flag Then
					AddHandler Me._btnSave.Click, AddressOf Me.btnSave_Click
				End If
			End Set
		End Property

		' Token: 0x1700051D RID: 1309
		' (get) Token: 0x06000E66 RID: 3686 RVA: 0x000ACBFC File Offset: 0x000AADFC
		' (set) Token: 0x06000E67 RID: 3687 RVA: 0x000ACC14 File Offset: 0x000AAE14
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x1700051E RID: 1310
		' (get) Token: 0x06000E68 RID: 3688 RVA: 0x000ACC80 File Offset: 0x000AAE80
		' (set) Token: 0x06000E69 RID: 3689 RVA: 0x000ACC98 File Offset: 0x000AAE98
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x1700051F RID: 1311
		' (get) Token: 0x06000E6A RID: 3690 RVA: 0x000ACD04 File Offset: 0x000AAF04
		' (set) Token: 0x06000E6B RID: 3691 RVA: 0x000044D9 File Offset: 0x000026D9
		Friend Overridable Property lblOBJNAME As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJNAME = value
			End Set
		End Property

		' Token: 0x17000520 RID: 1312
		' (get) Token: 0x06000E6C RID: 3692 RVA: 0x000ACD1C File Offset: 0x000AAF1C
		' (set) Token: 0x06000E6D RID: 3693 RVA: 0x000ACD34 File Offset: 0x000AAF34
		Friend Overridable Property txtOBJNAME As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAME
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJNAME IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
				Me._txtOBJNAME = value
				flag = Me._txtOBJNAME IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJNAME.KeyPress, AddressOf Me.txtOBJNAME_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000521 RID: 1313
		' (get) Token: 0x06000E6E RID: 3694 RVA: 0x000ACDA0 File Offset: 0x000AAFA0
		' (set) Token: 0x06000E6F RID: 3695 RVA: 0x000ACDB8 File Offset: 0x000AAFB8
		Friend Overridable Property txtOBJID As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJID IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					RemoveHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
				Me._txtOBJID = value
				flag = Me._txtOBJID IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJID.KeyPress, AddressOf Me.txtOBJID_KeyPress
					AddHandler Me._txtOBJID.GotFocus, AddressOf Me.txtOBJID_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000522 RID: 1314
		' (get) Token: 0x06000E70 RID: 3696 RVA: 0x000ACE54 File Offset: 0x000AB054
		' (set) Token: 0x06000E71 RID: 3697 RVA: 0x000044E3 File Offset: 0x000026E3
		Friend Overridable Property lblOBJID As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblOBJID
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblOBJID = value
			End Set
		End Property

		' Token: 0x17000523 RID: 1315
		' (get) Token: 0x06000E72 RID: 3698 RVA: 0x000ACE6C File Offset: 0x000AB06C
		' (set) Token: 0x06000E73 RID: 3699 RVA: 0x000044ED File Offset: 0x000026ED
		Friend Overridable Property lblFromDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFromDate = value
			End Set
		End Property

		' Token: 0x17000524 RID: 1316
		' (get) Token: 0x06000E74 RID: 3700 RVA: 0x000ACE84 File Offset: 0x000AB084
		' (set) Token: 0x06000E75 RID: 3701 RVA: 0x000ACE9C File Offset: 0x000AB09C
		Friend Overridable Property cmbHTKM As ComboBox
			<DebuggerNonUserCode()>
			Get
				Return Me._cmbHTKM
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ComboBox)
				Dim flag As Boolean = Me._cmbHTKM IsNot Nothing
				If flag Then
					RemoveHandler Me._cmbHTKM.TextChanged, AddressOf Me.cmbHTKM_TextChanged
					RemoveHandler Me._cmbHTKM.KeyPress, AddressOf Me.cmbHTKM_KeyPress
				End If
				Me._cmbHTKM = value
				flag = Me._cmbHTKM IsNot Nothing
				If flag Then
					AddHandler Me._cmbHTKM.TextChanged, AddressOf Me.cmbHTKM_TextChanged
					AddHandler Me._cmbHTKM.KeyPress, AddressOf Me.cmbHTKM_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000525 RID: 1317
		' (get) Token: 0x06000E76 RID: 3702 RVA: 0x000ACF38 File Offset: 0x000AB138
		' (set) Token: 0x06000E77 RID: 3703 RVA: 0x000044F7 File Offset: 0x000026F7
		Friend Overridable Property lblHTKM As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblHTKM
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblHTKM = value
			End Set
		End Property

		' Token: 0x17000526 RID: 1318
		' (get) Token: 0x06000E78 RID: 3704 RVA: 0x000ACF50 File Offset: 0x000AB150
		' (set) Token: 0x06000E79 RID: 3705 RVA: 0x000ACF68 File Offset: 0x000AB168
		Friend Overridable Property txtTENKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTENKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTENKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTENKH.KeyPress, AddressOf Me.txtTENKH_KeyPress
					RemoveHandler Me._txtTENKH.GotFocus, AddressOf Me.txtTENKH_GotFocus
				End If
				Me._txtTENKH = value
				flag = Me._txtTENKH IsNot Nothing
				If flag Then
					AddHandler Me._txtTENKH.KeyPress, AddressOf Me.txtTENKH_KeyPress
					AddHandler Me._txtTENKH.GotFocus, AddressOf Me.txtTENKH_GotFocus
				End If
			End Set
		End Property

		' Token: 0x17000527 RID: 1319
		' (get) Token: 0x06000E7A RID: 3706 RVA: 0x000AD004 File Offset: 0x000AB204
		' (set) Token: 0x06000E7B RID: 3707 RVA: 0x000AD01C File Offset: 0x000AB21C
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000528 RID: 1320
		' (get) Token: 0x06000E7C RID: 3708 RVA: 0x000AD088 File Offset: 0x000AB288
		' (set) Token: 0x06000E7D RID: 3709 RVA: 0x000AD0A0 File Offset: 0x000AB2A0
		Friend Overridable Property txtMAKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKH.KeyPress, AddressOf Me.txtMAKH_KeyPress
					RemoveHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
				Me._txtMAKH = value
				flag = Me._txtMAKH IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKH.KeyPress, AddressOf Me.txtMAKH_KeyPress
					AddHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000529 RID: 1321
		' (get) Token: 0x06000E7E RID: 3710 RVA: 0x000AD13C File Offset: 0x000AB33C
		' (set) Token: 0x06000E7F RID: 3711 RVA: 0x00004501 File Offset: 0x00002701
		Friend Overridable Property lblkHO As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblkHO
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblkHO = value
			End Set
		End Property

		' Token: 0x1700052A RID: 1322
		' (get) Token: 0x06000E80 RID: 3712 RVA: 0x000AD154 File Offset: 0x000AB354
		' (set) Token: 0x06000E81 RID: 3713 RVA: 0x0000450B File Offset: 0x0000270B
		Friend Overridable Property lblToDate As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblToDate = value
			End Set
		End Property

		' Token: 0x1700052B RID: 1323
		' (get) Token: 0x06000E82 RID: 3714 RVA: 0x000AD16C File Offset: 0x000AB36C
		' (set) Token: 0x06000E83 RID: 3715 RVA: 0x00004515 File Offset: 0x00002715
		Friend Overridable Property Label2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		' Token: 0x1700052C RID: 1324
		' (get) Token: 0x06000E84 RID: 3716 RVA: 0x000AD184 File Offset: 0x000AB384
		' (set) Token: 0x06000E85 RID: 3717 RVA: 0x0000451F File Offset: 0x0000271F
		Friend Overridable Property lblToTime As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblToTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblToTime = value
			End Set
		End Property

		' Token: 0x1700052D RID: 1325
		' (get) Token: 0x06000E86 RID: 3718 RVA: 0x000AD19C File Offset: 0x000AB39C
		' (set) Token: 0x06000E87 RID: 3719 RVA: 0x00004529 File Offset: 0x00002729
		Friend Overridable Property lblFromTime As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblFromTime = value
			End Set
		End Property

		' Token: 0x1700052E RID: 1326
		' (get) Token: 0x06000E88 RID: 3720 RVA: 0x000AD1B4 File Offset: 0x000AB3B4
		' (set) Token: 0x06000E89 RID: 3721 RVA: 0x000AD1CC File Offset: 0x000AB3CC
		Friend Overridable Property chkT2 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT2 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT2.KeyPress, AddressOf Me.chkT2_KeyPress
				End If
				Me._chkT2 = value
				flag = Me._chkT2 IsNot Nothing
				If flag Then
					AddHandler Me._chkT2.KeyPress, AddressOf Me.chkT2_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700052F RID: 1327
		' (get) Token: 0x06000E8A RID: 3722 RVA: 0x000AD238 File Offset: 0x000AB438
		' (set) Token: 0x06000E8B RID: 3723 RVA: 0x000AD250 File Offset: 0x000AB450
		Friend Overridable Property chkT3 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT3
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT3 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT3.KeyPress, AddressOf Me.chkT3_KeyPress
				End If
				Me._chkT3 = value
				flag = Me._chkT3 IsNot Nothing
				If flag Then
					AddHandler Me._chkT3.KeyPress, AddressOf Me.chkT3_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000530 RID: 1328
		' (get) Token: 0x06000E8C RID: 3724 RVA: 0x000AD2BC File Offset: 0x000AB4BC
		' (set) Token: 0x06000E8D RID: 3725 RVA: 0x000AD2D4 File Offset: 0x000AB4D4
		Friend Overridable Property chkT4 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT4
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT4 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT4.KeyPress, AddressOf Me.chkT4_KeyPress
				End If
				Me._chkT4 = value
				flag = Me._chkT4 IsNot Nothing
				If flag Then
					AddHandler Me._chkT4.KeyPress, AddressOf Me.chkT4_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000531 RID: 1329
		' (get) Token: 0x06000E8E RID: 3726 RVA: 0x000AD340 File Offset: 0x000AB540
		' (set) Token: 0x06000E8F RID: 3727 RVA: 0x000AD358 File Offset: 0x000AB558
		Friend Overridable Property chkT5 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT5 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT5.KeyPress, AddressOf Me.chkT5_KeyPress
				End If
				Me._chkT5 = value
				flag = Me._chkT5 IsNot Nothing
				If flag Then
					AddHandler Me._chkT5.KeyPress, AddressOf Me.chkT5_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000532 RID: 1330
		' (get) Token: 0x06000E90 RID: 3728 RVA: 0x000AD3C4 File Offset: 0x000AB5C4
		' (set) Token: 0x06000E91 RID: 3729 RVA: 0x000AD3DC File Offset: 0x000AB5DC
		Friend Overridable Property chkT6 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT6
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT6 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT6.KeyPress, AddressOf Me.chkT6_KeyPress
				End If
				Me._chkT6 = value
				flag = Me._chkT6 IsNot Nothing
				If flag Then
					AddHandler Me._chkT6.KeyPress, AddressOf Me.chkT6_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000533 RID: 1331
		' (get) Token: 0x06000E92 RID: 3730 RVA: 0x000AD448 File Offset: 0x000AB648
		' (set) Token: 0x06000E93 RID: 3731 RVA: 0x000AD460 File Offset: 0x000AB660
		Friend Overridable Property chkT7 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkT7
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkT7 IsNot Nothing
				If flag Then
					RemoveHandler Me._chkT7.KeyPress, AddressOf Me.chkT7_KeyPress
				End If
				Me._chkT7 = value
				flag = Me._chkT7 IsNot Nothing
				If flag Then
					AddHandler Me._chkT7.KeyPress, AddressOf Me.chkT7_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000534 RID: 1332
		' (get) Token: 0x06000E94 RID: 3732 RVA: 0x000AD4CC File Offset: 0x000AB6CC
		' (set) Token: 0x06000E95 RID: 3733 RVA: 0x000AD4E4 File Offset: 0x000AB6E4
		Friend Overridable Property chkCN As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkCN
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkCN IsNot Nothing
				If flag Then
					RemoveHandler Me._chkCN.KeyPress, AddressOf Me.chkCN_KeyPress
				End If
				Me._chkCN = value
				flag = Me._chkCN IsNot Nothing
				If flag Then
					AddHandler Me._chkCN.KeyPress, AddressOf Me.chkCN_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000535 RID: 1333
		' (get) Token: 0x06000E96 RID: 3734 RVA: 0x000AD550 File Offset: 0x000AB750
		' (set) Token: 0x06000E97 RID: 3735 RVA: 0x000AD568 File Offset: 0x000AB768
		Friend Overridable Property txtQty1 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtQty1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtQty1 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtQty1.KeyPress, AddressOf Me.txtQty1_KeyPress
				End If
				Me._txtQty1 = value
				flag = Me._txtQty1 IsNot Nothing
				If flag Then
					AddHandler Me._txtQty1.KeyPress, AddressOf Me.txtQty1_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000536 RID: 1334
		' (get) Token: 0x06000E98 RID: 3736 RVA: 0x000AD5D4 File Offset: 0x000AB7D4
		' (set) Token: 0x06000E99 RID: 3737 RVA: 0x00004533 File Offset: 0x00002733
		Friend Overridable Property lblQty1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblQty1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblQty1 = value
			End Set
		End Property

		' Token: 0x17000537 RID: 1335
		' (get) Token: 0x06000E9A RID: 3738 RVA: 0x000AD5EC File Offset: 0x000AB7EC
		' (set) Token: 0x06000E9B RID: 3739 RVA: 0x000AD604 File Offset: 0x000AB804
		Friend Overridable Property txtQty2 As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtQty2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtQty2 IsNot Nothing
				If flag Then
					RemoveHandler Me._txtQty2.KeyPress, AddressOf Me.txtQty2_KeyPress
				End If
				Me._txtQty2 = value
				flag = Me._txtQty2 IsNot Nothing
				If flag Then
					AddHandler Me._txtQty2.KeyPress, AddressOf Me.txtQty2_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000538 RID: 1336
		' (get) Token: 0x06000E9C RID: 3740 RVA: 0x000AD670 File Offset: 0x000AB870
		' (set) Token: 0x06000E9D RID: 3741 RVA: 0x0000453D File Offset: 0x0000273D
		Friend Overridable Property lblQty2 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblQty2
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblQty2 = value
			End Set
		End Property

		' Token: 0x17000539 RID: 1337
		' (get) Token: 0x06000E9E RID: 3742 RVA: 0x000AD688 File Offset: 0x000AB888
		' (set) Token: 0x06000E9F RID: 3743 RVA: 0x000AD6A0 File Offset: 0x000AB8A0
		Friend Overridable Property mtxFromDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxFromDate IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxFromDate.KeyPress, AddressOf Me.mtxFromDate_KeyPress
				End If
				Me._mtxFromDate = value
				flag = Me._mtxFromDate IsNot Nothing
				If flag Then
					AddHandler Me._mtxFromDate.KeyPress, AddressOf Me.mtxFromDate_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700053A RID: 1338
		' (get) Token: 0x06000EA0 RID: 3744 RVA: 0x000AD70C File Offset: 0x000AB90C
		' (set) Token: 0x06000EA1 RID: 3745 RVA: 0x000AD724 File Offset: 0x000AB924
		Friend Overridable Property mtxToDate As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToDate
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxToDate IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxToDate.KeyPress, AddressOf Me.mtxToDate_KeyPress
				End If
				Me._mtxToDate = value
				flag = Me._mtxToDate IsNot Nothing
				If flag Then
					AddHandler Me._mtxToDate.KeyPress, AddressOf Me.mtxToDate_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700053B RID: 1339
		' (get) Token: 0x06000EA2 RID: 3746 RVA: 0x000AD790 File Offset: 0x000AB990
		' (set) Token: 0x06000EA3 RID: 3747 RVA: 0x000AD7A8 File Offset: 0x000AB9A8
		Friend Overridable Property mtxFromTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxFromTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxFromTime IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxFromTime.KeyPress, AddressOf Me.mtxFromTime_KeyPress
				End If
				Me._mtxFromTime = value
				flag = Me._mtxFromTime IsNot Nothing
				If flag Then
					AddHandler Me._mtxFromTime.KeyPress, AddressOf Me.mtxFromTime_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700053C RID: 1340
		' (get) Token: 0x06000EA4 RID: 3748 RVA: 0x000AD814 File Offset: 0x000ABA14
		' (set) Token: 0x06000EA5 RID: 3749 RVA: 0x000AD82C File Offset: 0x000ABA2C
		Friend Overridable Property mtxToTime As MaskedTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._mtxToTime
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MaskedTextBox)
				Dim flag As Boolean = Me._mtxToTime IsNot Nothing
				If flag Then
					RemoveHandler Me._mtxToTime.KeyPress, AddressOf Me.mtxToTime_KeyPress
				End If
				Me._mtxToTime = value
				flag = Me._mtxToTime IsNot Nothing
				If flag Then
					AddHandler Me._mtxToTime.KeyPress, AddressOf Me.mtxToTime_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700053D RID: 1341
		' (get) Token: 0x06000EA6 RID: 3750 RVA: 0x000AD898 File Offset: 0x000ABA98
		' (set) Token: 0x06000EA7 RID: 3751 RVA: 0x000AD8B0 File Offset: 0x000ABAB0
		Friend Overridable Property txtTenNDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTenNDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtTenNDV IsNot Nothing
				If flag Then
					RemoveHandler Me._txtTenNDV.KeyPress, AddressOf Me.txtTenNDV_KeyPress
					RemoveHandler Me._txtTenNDV.GotFocus, AddressOf Me.txtTenNDV_GotFocus
				End If
				Me._txtTenNDV = value
				flag = Me._txtTenNDV IsNot Nothing
				If flag Then
					AddHandler Me._txtTenNDV.KeyPress, AddressOf Me.txtTenNDV_KeyPress
					AddHandler Me._txtTenNDV.GotFocus, AddressOf Me.txtTenNDV_GotFocus
				End If
			End Set
		End Property

		' Token: 0x1700053E RID: 1342
		' (get) Token: 0x06000EA8 RID: 3752 RVA: 0x000AD94C File Offset: 0x000ABB4C
		' (set) Token: 0x06000EA9 RID: 3753 RVA: 0x000AD964 File Offset: 0x000ABB64
		Friend Overridable Property btnNDV As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNDV IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNDV.Click, AddressOf Me.btnNDV_Click
				End If
				Me._btnNDV = value
				flag = Me._btnNDV IsNot Nothing
				If flag Then
					AddHandler Me._btnNDV.Click, AddressOf Me.btnNDV_Click
				End If
			End Set
		End Property

		' Token: 0x1700053F RID: 1343
		' (get) Token: 0x06000EAA RID: 3754 RVA: 0x000AD9D0 File Offset: 0x000ABBD0
		' (set) Token: 0x06000EAB RID: 3755 RVA: 0x000AD9E8 File Offset: 0x000ABBE8
		Friend Overridable Property txtMANDV As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMANDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMANDV IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMANDV.TextChanged, AddressOf Me.txtMANDV_TextChanged
					RemoveHandler Me._txtMANDV.KeyPress, AddressOf Me.txtMANDV_KeyPress
				End If
				Me._txtMANDV = value
				flag = Me._txtMANDV IsNot Nothing
				If flag Then
					AddHandler Me._txtMANDV.TextChanged, AddressOf Me.txtMANDV_TextChanged
					AddHandler Me._txtMANDV.KeyPress, AddressOf Me.txtMANDV_KeyPress
				End If
			End Set
		End Property

		' Token: 0x17000540 RID: 1344
		' (get) Token: 0x06000EAC RID: 3756 RVA: 0x000ADA84 File Offset: 0x000ABC84
		' (set) Token: 0x06000EAD RID: 3757 RVA: 0x00004547 File Offset: 0x00002747
		Friend Overridable Property lblMaNDV As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMaNDV
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMaNDV = value
			End Set
		End Property

		' Token: 0x17000541 RID: 1345
		' (get) Token: 0x06000EAE RID: 3758 RVA: 0x000ADA9C File Offset: 0x000ABC9C
		' (set) Token: 0x06000EAF RID: 3759 RVA: 0x00004551 File Offset: 0x00002751
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000542 RID: 1346
		' (get) Token: 0x06000EB0 RID: 3760 RVA: 0x000ADAB4 File Offset: 0x000ABCB4
		' (set) Token: 0x06000EB1 RID: 3761 RVA: 0x0000455B File Offset: 0x0000275B
		Friend Overridable Property panNHOMCHU As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panNHOMCHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panNHOMCHU = value
			End Set
		End Property

		' Token: 0x17000543 RID: 1347
		' (get) Token: 0x06000EB2 RID: 3762 RVA: 0x000ADACC File Offset: 0x000ABCCC
		' (set) Token: 0x06000EB3 RID: 3763 RVA: 0x000ADAE4 File Offset: 0x000ABCE4
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x17000544 RID: 1348
		' (get) Token: 0x06000EB4 RID: 3764 RVA: 0x000ADB50 File Offset: 0x000ABD50
		' (set) Token: 0x06000EB5 RID: 3765 RVA: 0x00004565 File Offset: 0x00002765
		Friend Overridable Property panKHU As Panel
			<DebuggerNonUserCode()>
			Get
				Return Me._panKHU
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._panKHU = value
			End Set
		End Property

		' Token: 0x17000545 RID: 1349
		' (get) Token: 0x06000EB6 RID: 3766 RVA: 0x000ADB68 File Offset: 0x000ABD68
		' (set) Token: 0x06000EB7 RID: 3767 RVA: 0x0000456F File Offset: 0x0000276F
		Friend Overridable Property Label1 As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._Label1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		' Token: 0x17000546 RID: 1350
		' (get) Token: 0x06000EB8 RID: 3768 RVA: 0x000ADB80 File Offset: 0x000ABD80
		' (set) Token: 0x06000EB9 RID: 3769 RVA: 0x000ADB98 File Offset: 0x000ABD98
		Friend Overridable Property txtMaKhu As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMaKhu
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMaKhu IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMaKhu.KeyPress, AddressOf Me.txtMaKhu_KeyPress
					RemoveHandler Me._txtMaKhu.TextChanged, AddressOf Me.txtMaKhu_TextChanged
				End If
				Me._txtMaKhu = value
				flag = Me._txtMaKhu IsNot Nothing
				If flag Then
					AddHandler Me._txtMaKhu.KeyPress, AddressOf Me.txtMaKhu_KeyPress
					AddHandler Me._txtMaKhu.TextChanged, AddressOf Me.txtMaKhu_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000547 RID: 1351
		' (get) Token: 0x06000EBA RID: 3770 RVA: 0x000ADC34 File Offset: 0x000ABE34
		' (set) Token: 0x06000EBB RID: 3771 RVA: 0x000ADC4C File Offset: 0x000ABE4C
		Friend Overridable Property btnMaKhu As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnMaKhu
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnMaKhu IsNot Nothing
				If flag Then
					RemoveHandler Me._btnMaKhu.Click, AddressOf Me.btnMaKhu_Click
				End If
				Me._btnMaKhu = value
				flag = Me._btnMaKhu IsNot Nothing
				If flag Then
					AddHandler Me._btnMaKhu.Click, AddressOf Me.btnMaKhu_Click
				End If
			End Set
		End Property

		' Token: 0x17000548 RID: 1352
		' (get) Token: 0x06000EBC RID: 3772 RVA: 0x000ADCB8 File Offset: 0x000ABEB8
		' (set) Token: 0x06000EBD RID: 3773 RVA: 0x00004579 File Offset: 0x00002779
		Friend Overridable Property txtTenKhu As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtTenKhu
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtTenKhu = value
			End Set
		End Property

		' Token: 0x17000549 RID: 1353
		' (get) Token: 0x06000EBE RID: 3774 RVA: 0x000ADCD0 File Offset: 0x000ABED0
		' (set) Token: 0x06000EBF RID: 3775 RVA: 0x000ADCE8 File Offset: 0x000ABEE8
		Friend Overridable Property chkL02Per As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._chkL02Per
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._chkL02Per IsNot Nothing
				If flag Then
					RemoveHandler Me._chkL02Per.KeyPress, AddressOf Me.chkCN_KeyPress
				End If
				Me._chkL02Per = value
				flag = Me._chkL02Per IsNot Nothing
				If flag Then
					AddHandler Me._chkL02Per.KeyPress, AddressOf Me.chkCN_KeyPress
				End If
			End Set
		End Property

		' Token: 0x1700054A RID: 1354
		' (get) Token: 0x06000EC0 RID: 3776 RVA: 0x000ADD54 File Offset: 0x000ABF54
		' (set) Token: 0x06000EC1 RID: 3777 RVA: 0x00004583 File Offset: 0x00002783
		Public Property pbytFromStatus As Byte
			Get
				Return Me.mbytFormStatus
			End Get
			Set(value As Byte)
				Me.mbytFormStatus = value
			End Set
		End Property

		' Token: 0x1700054B RID: 1355
		' (get) Token: 0x06000EC2 RID: 3778 RVA: 0x000ADD6C File Offset: 0x000ABF6C
		' (set) Token: 0x06000EC3 RID: 3779 RVA: 0x0000458E File Offset: 0x0000278E
		Public Property pbytSuccess As Byte
			Get
				Return Me.mbytSuccess
			End Get
			Set(value As Byte)
				Me.mbytSuccess = value
			End Set
		End Property

		' Token: 0x1700054C RID: 1356
		' (get) Token: 0x06000EC4 RID: 3780 RVA: 0x000ADD84 File Offset: 0x000ABF84
		' (set) Token: 0x06000EC5 RID: 3781 RVA: 0x00004599 File Offset: 0x00002799
		Public Property pStrKHO As String
			Get
				Return Me.mstrKHO
			End Get
			Set(value As String)
				Me.mstrKHO = value
			End Set
		End Property

		' Token: 0x1700054D RID: 1357
		' (get) Token: 0x06000EC6 RID: 3782 RVA: 0x000ADD9C File Offset: 0x000ABF9C
		' (set) Token: 0x06000EC7 RID: 3783 RVA: 0x000045A4 File Offset: 0x000027A4
		Public Property pStrKHU As String
			Get
				Return Me.mstrKHU
			End Get
			Set(value As String)
				Me.mstrKHU = value
			End Set
		End Property

		' Token: 0x1700054E RID: 1358
		' (get) Token: 0x06000EC8 RID: 3784 RVA: 0x000ADDB4 File Offset: 0x000ABFB4
		' (set) Token: 0x06000EC9 RID: 3785 RVA: 0x000045AF File Offset: 0x000027AF
		Public Property pStrMANHOMDV As String
			Get
				Return Conversions.ToString(Me.mstrMaNHOMDV)
			End Get
			Set(value As String)
				Me.mstrMaNHOMDV = value
			End Set
		End Property

		' Token: 0x1700054F RID: 1359
		' (get) Token: 0x06000ECA RID: 3786 RVA: 0x000ADDD4 File Offset: 0x000ABFD4
		' (set) Token: 0x06000ECB RID: 3787 RVA: 0x000045BA File Offset: 0x000027BA
		Public Property pStrOBJID As String
			Get
				Return Me.mstrOBJID
			End Get
			Set(value As String)
				Me.mstrOBJID = value
			End Set
		End Property

		' Token: 0x17000550 RID: 1360
		' (get) Token: 0x06000ECC RID: 3788 RVA: 0x000ADDEC File Offset: 0x000ABFEC
		' (set) Token: 0x06000ECD RID: 3789 RVA: 0x000045C5 File Offset: 0x000027C5
		Public Property pStrHTKM As String
			Get
				Return Me.mstrHTKM
			End Get
			Set(value As String)
				Me.mstrHTKM = value
			End Set
		End Property

		' Token: 0x17000551 RID: 1361
		' (get) Token: 0x06000ECE RID: 3790 RVA: 0x000ADE04 File Offset: 0x000AC004
		' (set) Token: 0x06000ECF RID: 3791 RVA: 0x000045D0 File Offset: 0x000027D0
		Public Property pStrFromDate As String
			Get
				Return Me.mStrFromDate
			End Get
			Set(value As String)
				Me.mStrFromDate = value
			End Set
		End Property

		' Token: 0x17000552 RID: 1362
		' (get) Token: 0x06000ED0 RID: 3792 RVA: 0x000ADE1C File Offset: 0x000AC01C
		' (set) Token: 0x06000ED1 RID: 3793 RVA: 0x000045DB File Offset: 0x000027DB
		Public Property pStrToDate As String
			Get
				Return Me.mStrToDate
			End Get
			Set(value As String)
				Me.mStrToDate = value
			End Set
		End Property

		' Token: 0x17000553 RID: 1363
		' (get) Token: 0x06000ED2 RID: 3794 RVA: 0x000ADE34 File Offset: 0x000AC034
		' (set) Token: 0x06000ED3 RID: 3795 RVA: 0x000045E6 File Offset: 0x000027E6
		Public Property pStrFromTime As String
			Get
				Return Me.mStrFromTime
			End Get
			Set(value As String)
				Me.mStrFromTime = value
			End Set
		End Property

		' Token: 0x17000554 RID: 1364
		' (get) Token: 0x06000ED4 RID: 3796 RVA: 0x000ADE4C File Offset: 0x000AC04C
		' (set) Token: 0x06000ED5 RID: 3797 RVA: 0x000045F1 File Offset: 0x000027F1
		Public Property pStrToTime As String
			Get
				Return Me.mStrToTime
			End Get
			Set(value As String)
				Me.mStrToTime = value
			End Set
		End Property

		' Token: 0x17000555 RID: 1365
		' (get) Token: 0x06000ED6 RID: 3798 RVA: 0x000ADE64 File Offset: 0x000AC064
		' (set) Token: 0x06000ED7 RID: 3799 RVA: 0x000045FC File Offset: 0x000027FC
		Public Property pStrFilter As String
			Get
				Return Me.mStrFilter
			End Get
			Set(value As String)
				Me.mStrFilter = value
			End Set
		End Property

		' Token: 0x06000ED8 RID: 3800 RVA: 0x000ADE7C File Offset: 0x000AC07C
		Private Sub frmDMDNKM2_Activated(sender As Object, e As EventArgs)
			Try
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM2_Activated ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000ED9 RID: 3801 RVA: 0x000ADF10 File Offset: 0x000AC110
		Private Sub frmDMDNKM2_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Combo()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMKH()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMNHOMDV()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMNC()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_DMKHU()
				End If
				b = Me.fEnableButton()
				flag = b <> 0
				If flag Then
					b = Me.fLockTextBox()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMDNKM2_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EDA RID: 3802 RVA: 0x000AE034 File Offset: 0x000AC234
		Private Sub btnSave_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Strings.Trim(Me.txtOBJID.Text), "", False) = 0
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
					Me.txtOBJID.Focus()
				Else
					flag = Operators.CompareString(Strings.Trim(Me.txtOBJNAME.Text), "", False) = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(26), MsgBoxStyle.Critical, Nothing)
						Me.txtOBJNAME.Focus()
					Else
						Dim text As String = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
						Dim text2 As String = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text, "", 1, -1, CompareMethod.Binary))
						flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(27), MsgBoxStyle.Critical, Nothing)
							Me.mtxFromDate.Focus()
						Else
							text = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
							text2 = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text, "", 1, -1, CompareMethod.Binary))
							flag = Strings.Len(text2) > 0
							If flag Then
								text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 1, 2) })
								flag = Not Information.IsDate(text2)
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(35), MsgBoxStyle.Critical, Nothing)
									Me.mtxFromDate.Focus()
									Return
								End If
							End If
							text = Strings.Mid(Me.mtxToDate.Text, 3, 1)
							text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text, "", 1, -1, CompareMethod.Binary))
							flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
							If flag Then
								Interaction.MsgBox(Me.mArrStrFrmMess(28), MsgBoxStyle.Critical, Nothing)
								Me.mtxToDate.Focus()
							Else
								text = Strings.Mid(Me.mtxToDate.Text, 3, 1)
								text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text, "", 1, -1, CompareMethod.Binary))
								flag = Strings.Len(text2) > 0
								If flag Then
									text2 = String.Concat(New String() { Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 7, 4), "/", Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 4, 2), "/", Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 1, 2) })
									flag = Not Information.IsDate(text2)
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(36), MsgBoxStyle.Critical, Nothing)
										Me.mtxToDate.Focus()
										Return
									End If
								End If
								Dim text3 As String = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text, "", 1, -1, CompareMethod.Binary))
								text3 = Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 4, 2) + Strings.Mid(Strings.Trim(Me.mtxFromDate.Text), 1, 2)
								Dim text4 As String = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text, "", 1, -1, CompareMethod.Binary))
								text4 = Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 4, 2) + Strings.Mid(Strings.Trim(Me.mtxToDate.Text), 1, 2)
								flag = Operators.CompareString(text3, text4, False) > 0
								If flag Then
									Interaction.MsgBox(Me.mArrStrFrmMess(43), MsgBoxStyle.Critical, Nothing)
									Me.mtxToDate.Focus()
								Else
									text = Strings.Mid(Me.mtxFromTime.Text, 3, 1)
									text2 = Strings.Trim(Strings.Replace(Me.mtxFromTime.Text, text, "", 1, -1, CompareMethod.Binary))
									flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
									If flag Then
										Interaction.MsgBox(Me.mArrStrFrmMess(29), MsgBoxStyle.Critical, Nothing)
										Me.mtxFromTime.Focus()
									Else
										text = Strings.Mid(Me.mtxFromTime.Text, 3, 1)
										text2 = Strings.Trim(Strings.Replace(Me.mtxFromTime.Text, text, "", 1, -1, CompareMethod.Binary))
										flag = Strings.Len(text2) > 0
										If flag Then
											Dim text5 As String = Strings.Mid(Me.mtxFromTime.Text, 1, 2)
											Dim text6 As String = Strings.Mid(Me.mtxFromTime.Text, 4, 2)
											flag = (Conversion.Val(text5) < 0.0) Or (Conversion.Val(text5) > 23.0) Or (Conversion.Val(text6) < 0.0) Or (Conversion.Val(text6) > 59.0)
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(37), MsgBoxStyle.Critical, Nothing)
												Me.mtxFromTime.Focus()
												Return
											End If
										End If
										text = Strings.Mid(Me.mtxToTime.Text, 3, 1)
										text2 = Strings.Trim(Strings.Replace(Me.mtxToTime.Text, text, "", 1, -1, CompareMethod.Binary))
										flag = Operators.CompareString(Strings.Trim(text2), "", False) = 0
										If flag Then
											Interaction.MsgBox(Me.mArrStrFrmMess(30), MsgBoxStyle.Critical, Nothing)
											Me.mtxToTime.Focus()
										Else
											text = Strings.Mid(Me.mtxToTime.Text, 3, 1)
											text2 = Strings.Trim(Strings.Replace(Me.mtxToTime.Text, text, "", 1, -1, CompareMethod.Binary))
											flag = Strings.Len(text2) > 0
											If flag Then
												Dim text5 As String = Strings.Mid(Me.mtxToTime.Text, 1, 2)
												Dim text6 As String = Strings.Mid(Me.mtxToTime.Text, 4, 2)
												flag = (Conversion.Val(text5) < 0.0) Or (Conversion.Val(text5) > 23.0) Or (Conversion.Val(text6) < 0.0) Or (Conversion.Val(text6) > 59.0)
												If flag Then
													Interaction.MsgBox(Me.mArrStrFrmMess(38), MsgBoxStyle.Critical, Nothing)
													Me.mtxToTime.Focus()
													Return
												End If
											End If
											Dim text7 As String = Strings.Trim(Strings.Replace(Me.mtxFromTime.Text, text, "", 1, -1, CompareMethod.Binary))
											text7 = Strings.Mid(Strings.Trim(Me.mtxFromTime.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxFromTime.Text), 4, 2) + Strings.Mid(Strings.Trim(Me.mtxFromTime.Text), 1, 2)
											Dim text8 As String = Strings.Trim(Strings.Replace(Me.mtxToTime.Text, text, "", 1, -1, CompareMethod.Binary))
											text8 = Strings.Mid(Strings.Trim(Me.mtxToTime.Text), 7, 4) + Strings.Mid(Strings.Trim(Me.mtxToTime.Text), 4, 2) + Strings.Mid(Strings.Trim(Me.mtxToTime.Text), 1, 2)
											flag = Operators.CompareString(text7, text8, False) > 0
											If flag Then
												Interaction.MsgBox(Me.mArrStrFrmMess(44), MsgBoxStyle.Critical, Nothing)
												Me.mtxToDate.Focus()
											Else
												Dim text9 As String = Me.cmbHTKM.SelectedValue.ToString()
												Dim flag2 As Boolean
												If Operators.CompareString(text9, "04", False) <> 0 AndAlso Operators.CompareString(text9, "05", False) <> 0 Then
													If Operators.CompareString(text9, "07", False) <> 0 Then
														If Operators.CompareString(text9, "06", False) <> 0 Then
															If Operators.CompareString(text9, "09", False) <> 0 Then
																flag2 = False
																GoTo IL_089A
															End If
														End If
													End If
												End If
												flag2 = True
												IL_089A:
												flag = flag2
												Dim flag3 As Boolean
												If flag Then
													flag3 = (Operators.CompareString(Strings.Trim(Me.txtMANDV.Text), "", False) <> 0) And (Operators.CompareString(Strings.Trim(Me.txtTenNDV.Text), "", False) = 0)
													If flag3 Then
														Interaction.MsgBox(RuntimeHelpers.GetObjectValue(Interaction.IIf(Operators.CompareString(Me.cmbHTKM.SelectedValue.ToString(), "08", False) = 0, Me.mArrStrFrmMess(50), Me.mArrStrFrmMess(39))), MsgBoxStyle.Critical, Nothing)
														Me.txtMANDV.Focus()
														Return
													End If
												End If
												flag3 = Conversion.Val(Strings.Trim(Me.txtQty1.Text)) <= 0.0
												If flag3 Then
													Interaction.MsgBox(Me.mArrStrFrmMess(45), MsgBoxStyle.Critical, Nothing)
													Me.txtQty1.Focus()
												Else
													flag3 = Me.txtQty2.Visible
													If flag3 Then
														flag = Conversion.Val(Strings.Trim(Me.txtQty2.Text)) <= 0.0 AndAlso Operators.CompareString(Me.cmbHTKM.SelectedValue.ToString(), "03", False) <> 0 AndAlso Operators.CompareString(Me.cmbHTKM.SelectedValue.ToString(), "08", False) <> 0 AndAlso Operators.CompareString(Me.cmbHTKM.SelectedValue.ToString(), "07", False) <> 0 AndAlso Operators.CompareString(Me.cmbHTKM.SelectedValue.ToString(), "11", False) <> 0
														If flag Then
															Interaction.MsgBox(Me.mArrStrFrmMess(45), MsgBoxStyle.Critical, Nothing)
															Me.txtQty2.Focus()
															Return
														End If
													End If
													Dim text10 As String = Me.cmbHTKM.SelectedValue.ToString()
													Dim flag4 As Boolean
													If Operators.CompareString(text10, "04", False) <> 0 AndAlso Operators.CompareString(text10, "05", False) <> 0 Then
														If Operators.CompareString(text10, "07", False) <> 0 Then
															If Operators.CompareString(text10, "09", False) <> 0 Then
																flag4 = False
																GoTo IL_0AC6
															End If
														End If
													End If
													flag4 = True
													IL_0AC6:
													flag3 = flag4
													If flag3 Then
														flag = Operators.CompareString(Strings.Trim(Me.txtMANDV.Text), "", False) = 0
														If flag Then
															Interaction.MsgBox(Me.mArrStrFrmMess(46), MsgBoxStyle.Critical, Nothing)
															Me.txtMANDV.Focus()
															Return
														End If
														flag3 = Operators.CompareString(Strings.Trim(Me.txtTenNDV.Text), "", False) = 0
														If flag3 Then
															Interaction.MsgBox(Me.mArrStrFrmMess(47), MsgBoxStyle.Critical, Nothing)
															Me.txtMANDV.Focus()
															Return
														End If
													Else
														flag3 = Operators.CompareString(text10, "08", False) = 0
														If flag3 Then
															flag = Operators.CompareString(Strings.Trim(Me.txtMANDV.Text), "", False) = 0
															If flag Then
																Interaction.MsgBox(Me.mArrStrFrmMess(51), MsgBoxStyle.Critical, Nothing)
																Me.txtMANDV.Focus()
																Return
															End If
															flag3 = Operators.CompareString(Strings.Trim(Me.txtTenNDV.Text), "", False) = 0
															If flag3 Then
																Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
																Me.txtMANDV.Focus()
																Return
															End If
															flag3 = Operators.CompareString(Strings.Trim(Me.txtMaKhu.Text), "", False) = 0
															If Not flag3 Then
																flag3 = Operators.CompareString(Strings.Trim(Me.txtTenKhu.Text), "", False) = 0
																If flag3 Then
																	Interaction.MsgBox(Me.mArrStrFrmMess(53), MsgBoxStyle.Critical, Nothing)
																	Me.txtMaKhu.Focus()
																	Return
																End If
															End If
														Else
															flag3 = Operators.CompareString(text10, "10", False) = 0
															If flag3 Then
																flag = Operators.CompareString(Strings.Trim(Me.txtMANDV.Text), "", False) = 0
																If flag Then
																	Interaction.MsgBox(Me.mArrStrFrmMess(46), MsgBoxStyle.Critical, Nothing)
																	Me.txtMANDV.Focus()
																	Return
																End If
																flag3 = Operators.CompareString(Strings.Trim(Me.txtTenNDV.Text), "", False) = 0
																If flag3 Then
																	Interaction.MsgBox(Me.mArrStrFrmMess(47), MsgBoxStyle.Critical, Nothing)
																	Me.txtMANDV.Focus()
																	Return
																End If
																flag3 = Operators.CompareString(Strings.Trim(Me.txtMaKhu.Text), "", False) = 0
																If flag3 Then
																	Interaction.MsgBox(Me.mArrStrFrmMess(51), MsgBoxStyle.Critical, Nothing)
																	Me.txtMaKhu.Focus()
																	Return
																End If
																flag3 = Operators.CompareString(Strings.Trim(Me.txtTenKhu.Text), "", False) = 0
																If flag3 Then
																	Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
																	Me.txtTenKhu.Focus()
																	Return
																End If
															End If
														End If
													End If
													flag3 = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2)
													If flag3 Then
														Me.mbytSuccess = Me.fAddNew()
													Else
														flag3 = Me.mbytFormStatus = 3
														If flag3 Then
															Me.mbytSuccess = Me.fModify()
														End If
													End If
													flag3 = Me.mbytSuccess = 1
													If flag3 Then
														Me.Close()
													End If
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSave_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EDB RID: 3803 RVA: 0x000AEF14 File Offset: 0x000AD114
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Try
				Me.mbytSuccess = Me.fDelete()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EDC RID: 3804 RVA: 0x000AEFB8 File Offset: 0x000AD1B8
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAKH.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMANDV.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MANHOMDV like '"), text2), "%'"))
				End If
				text2 = Conversions.ToString(Me.cmbHTKM.SelectedValue)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKM like '%"), text2), "%'"))
				End If
				Dim text3 As String = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FROMDATE like '%"), text2), "%'"))
				End If
				text3 = Strings.Mid(Me.mtxToDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TODATE like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EDD RID: 3805 RVA: 0x000AF3AC File Offset: 0x000AD5AC
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = ""
				Dim text2 As String = Strings.Replace(Strings.Trim(Me.txtOBJID.Text), "'", "''", 1, -1, CompareMethod.Binary)
				Dim flag As Boolean = Strings.Len(text2) > 0
				If flag Then
					text = " OBJID like '" + text2 + "%'"
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtOBJNAME.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " OBJNAME like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMAKH.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKH like '"), text2), "%'"))
				End If
				text2 = Strings.Replace(Strings.Trim(Me.txtMANDV.Text), "'", "''", 1, -1, CompareMethod.Binary)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MANHOMDV like '"), text2), "%'"))
				End If
				text2 = Conversions.ToString(Me.cmbHTKM.SelectedValue)
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " MAKM like '%"), text2), "%'"))
				End If
				Dim text3 As String = Strings.Mid(Me.mtxFromDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxFromDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " FROMDATE like '%"), text2), "%'"))
				End If
				text3 = Strings.Mid(Me.mtxToDate.Text, 3, 1)
				text2 = Strings.Trim(Strings.Replace(Me.mtxToDate.Text, text3, "", 1, -1, CompareMethod.Binary))
				flag = Strings.Len(text2) > 0
				If flag Then
					text = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(text, Interaction.IIf(Strings.Len(text) > 0, " and ", "")), " TODATE like '%"), text2), "%'"))
				End If
				Me.mStrFilter = text
				flag = Operators.CompareString(Me.mStrFilter, "", False) <> 0
				If flag Then
					Me.mbytSuccess = 1
				End If
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EDE RID: 3806 RVA: 0x000AF7A0 File Offset: 0x000AD9A0
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKH As frmDMKH1 = New frmDMKH1()
				frmDMKH.pBytOpen_From_Menu = 7
				frmDMKH.ShowDialog()
				Me.txtMAKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJID, "", False) = 0, Me.txtMAKH.Text, frmDMKH.pStrOBJID))
				Me.txtTENKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJNAME, "", False) = 0, Me.txtTENKH.Text, frmDMKH.pStrOBJNAME))
				frmDMKH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EDF RID: 3807 RVA: 0x000AF8C4 File Offset: 0x000ADAC4
		Private Sub btnNDV_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Me.cmbHTKM.SelectedValue.ToString(), "08", False) = 0
				If flag Then
					Dim frmDMNCHU As frmDMNCHU1 = New frmDMNCHU1()
					frmDMNCHU.pBytOpen_From_Menu = 7
					frmDMNCHU.ShowDialog()
					Me.txtMANDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNCHU.pStrOBJID, "", False) = 0, Me.txtMANDV.Text, frmDMNCHU.pStrOBJID))
					Me.txtTenNDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNCHU.pStrOBJNAME, "", False) = 0, Me.txtTenNDV.Text, frmDMNCHU.pStrOBJNAME))
					frmDMNCHU.Dispose()
				Else
					Dim frmDMNHOMDV As frmDMNHOMDV1 = New frmDMNHOMDV1()
					frmDMNHOMDV.pBytOpen_From_Menu = 7
					frmDMNHOMDV.ShowDialog()
					Me.txtMANDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNHOMDV.pStrOBJID, "", False) = 0, Me.txtMANDV.Text, frmDMNHOMDV.pStrOBJID))
					Me.txtTenNDV.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNHOMDV.pStrOBJNAME, "", False) = 0, Me.txtTenNDV.Text, frmDMNHOMDV.pStrOBJNAME))
					frmDMNHOMDV.Dispose()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNDV_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EE0 RID: 3808 RVA: 0x000AFAC0 File Offset: 0x000ADCC0
		Private Sub cmbHTKM_TextChanged(sender As Object, e As EventArgs)
			Try
				Me.sDisplayLabel()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbHTKM_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EE1 RID: 3809 RVA: 0x000AFB4C File Offset: 0x000ADD4C
		Private Function fLockTextBox() As Byte
			Dim b As Byte
			Try
				b = 0
				Select Case Me.mbytFormStatus
					Case 3
						Me.txtOBJNAME.Focus()
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtTENKH.BackColor
					Case 4
						Me.txtOBJID.[ReadOnly] = True
						Me.txtOBJID.BackColor = Me.txtTENKH.BackColor
						Me.txtOBJNAME.[ReadOnly] = True
						Me.txtOBJNAME.BackColor = Me.txtTENKH.BackColor
						Me.txtMAKH.[ReadOnly] = True
						Me.txtMAKH.BackColor = Me.txtTENKH.BackColor
						Me.txtMANDV.[ReadOnly] = True
						Me.txtMANDV.BackColor = Me.txtTENKH.BackColor
						Me.txtQty1.[ReadOnly] = True
						Me.txtQty1.BackColor = Me.txtTENKH.BackColor
						Me.txtQty2.[ReadOnly] = True
						Me.txtQty2.BackColor = Me.txtTENKH.BackColor
						Me.mtxFromDate.[ReadOnly] = True
						Me.mtxFromDate.BackColor = Me.txtTENKH.BackColor
						Me.mtxToDate.[ReadOnly] = True
						Me.mtxToDate.BackColor = Me.txtTENKH.BackColor
						Me.mtxFromTime.[ReadOnly] = True
						Me.mtxFromTime.BackColor = Me.txtTENKH.BackColor
						Me.mtxToTime.[ReadOnly] = True
						Me.mtxToTime.BackColor = Me.txtTENKH.BackColor
						Me.chkT2.Enabled = False
						Me.chkT3.Enabled = False
						Me.chkT4.Enabled = False
						Me.chkT5.Enabled = False
						Me.chkT6.Enabled = False
						Me.chkT7.Enabled = False
						Me.chkCN.Enabled = False
						Me.cmbHTKM.Enabled = False
						Me.btnDelete.Focus()
					Case 5, 6
						Me.cmbHTKM.SelectedIndex = Me.cmbHTKM.Items.Count - 1
						Me.txtOBJID.[ReadOnly] = False
				End Select
				Dim flag As Boolean = Operators.CompareString(Me.mStrFromDate, "", False) <> 0
				If flag Then
					Me.mtxFromDate.Text = Me.mStrFromDate
				End If
				flag = Operators.CompareString(Me.mStrToDate, "", False) <> 0
				If flag Then
					Me.mtxToDate.Text = Me.mStrToDate
				End If
				flag = Operators.CompareString(Me.mStrFromTime, "", False) <> 0
				If flag Then
					Me.mtxFromTime.Text = Me.mStrFromTime
				End If
				flag = Operators.CompareString(Me.mStrToTime, "", False) <> 0
				If flag Then
					Me.mtxToTime.Text = Me.mStrToTime
				End If
				flag = Operators.CompareString(Me.mstrOBJID, "", False) <> 0
				If flag Then
					Me.txtOBJID.Text = Me.mstrOBJID
				End If
				flag = Operators.CompareString(Me.mstrKHO, "", False) <> 0
				If flag Then
					Me.txtMAKH.Text = Me.mstrKHO
				End If
				flag = Operators.CompareString(Me.mstrHTKM, "", False) <> 0
				If flag Then
					Me.cmbHTKM.SelectedValue = Me.mstrHTKM
				End If
				flag = Operators.CompareString(Me.mstrKHU, "", False) <> 0
				If flag Then
					Me.txtMaKhu.Text = Me.mstrKHU
				End If
				flag = Operators.ConditionalCompareObjectNotEqual(Me.mstrMaNHOMDV, "", False)
				If flag Then
					Me.txtMANDV.Text = Conversions.ToString(Me.mstrMaNHOMDV)
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fLockTextBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000EE2 RID: 3810 RVA: 0x000B001C File Offset: 0x000AE21C
		Private Function fEnableButton() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnDelete.Enabled = False
				Me.btnSave.Enabled = False
				Me.btnFilter.Enabled = False
				Me.btnFind.Enabled = False
				Me.btnExit.Enabled = True
				Me.txtOBJID.Focus()
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.btnSave.Enabled = True
					Case 3
						Me.btnSave.Enabled = True
						Me.txtOBJNAME.Focus()
					Case 4
						Me.btnDelete.Enabled = True
						Me.btnExit.Focus()
					Case 5
						Me.btnFilter.Enabled = True
					Case 6
						Me.btnFind.Enabled = True
				End Select
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fEnableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000EE3 RID: 3811 RVA: 0x000B01AC File Offset: 0x000AE3AC
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.txtOBJID.MaxLength = 10
				Me.txtOBJNAME.MaxLength = 100
				Me.txtMAKH.MaxLength = 3
				Me.txtTENKH.[ReadOnly] = True
				Me.cmbHTKM.DropDownStyle = ComboBoxStyle.DropDownList
				Me.cmbHTKM.SelectedValue = 0
				Me.mtxFromTime.Text = "00:01"
				Me.mtxToTime.Text = "23:59"
				Dim flag As Boolean = Me.mbytFormStatus = 4
				If flag Then
					Me.cmbHTKM.DropDownStyle = ComboBoxStyle.DropDown
				End If
				Me.txtOBJID.CharacterCasing = CharacterCasing.Upper
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000EE4 RID: 3812 RVA: 0x000B0310 File Offset: 0x000AE510
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean = (Me.mbytFormStatus = 1) Or (Me.mbytFormStatus = 2) Or (Me.mbytFormStatus = 3)
				If flag Then
					Me.lblOBJID.Tag = "CB0014"
					Me.lblOBJNAME.Tag = "CB0015"
					Me.lblHTKM.Tag = "CB0017"
					Me.lblFromDate.Tag = "CB0018"
					Me.lblToDate.Tag = "CB0019"
					Me.lblFromTime.Tag = "CB0021"
					Me.lblToTime.Tag = "CB0022"
				End If
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				Select Case Me.mbytFormStatus
					Case 1, 2
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(8))
					Case 3
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(9))
					Case 4
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(10))
					Case 5
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(12))
					Case 6
						mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(11))
				End Select
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000EE5 RID: 3813 RVA: 0x000B0548 File Offset: 0x000AE748
		Private Sub sClear_Form()
			Try
				Me.mclsTbDMKHO.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EE6 RID: 3814 RVA: 0x000B05F4 File Offset: 0x000AE7F4
		Private Function fAddNew() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(21) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvchOBJNAME"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKH.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchMAKM"
				array(3).Value = Me.cmbHTKM.SelectedValue.ToString()
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvchFROMDATE"
				array(4).Value = Strings.Trim(Me.mtxFromDate.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvchTODATE"
				array(5).Value = Strings.Trim(Me.mtxToDate.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pbitLDAY2"
				array(6).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT2.Checked, 1, 0))
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pbitLDAY3"
				array(7).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT3.Checked, 1, 0))
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pbitLDAY4"
				array(8).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT4.Checked, 1, 0))
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pbitLDAY5"
				array(9).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT5.Checked, 1, 0))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pbitLDAY6"
				array(10).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT6.Checked, 1, 0))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pbitLDAY7"
				array(11).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT7.Checked, 1, 0))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pbitLDAY8"
				array(12).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCN.Checked, 1, 0))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pnvchFROMTIME"
				array(13).Value = Strings.Trim(Me.mtxFromTime.Text)
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pnvchTOTIME"
				array(14).Value = Strings.Trim(Me.mtxToTime.Text)
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@prelPARA1"
				array(15).Value = Conversions.ToDouble(Strings.Replace(Strings.Trim(Me.txtQty1.Text), ",", "", 1, -1, CompareMethod.Binary))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@prelPARA2"
				array(16).Value = Conversions.ToDouble(Strings.Replace(Strings.Trim(Conversions.ToString(Interaction.IIf(Me.txtQty2.Visible, Strings.Trim(Me.txtQty2.Text), 0))), ",", "", 1, -1, CompareMethod.Binary))
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnchMANHOMDV"
				array(17).Value = Strings.Trim(Me.txtMANDV.Text)
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pnchMAKHU"
				array(19).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.panKHU.Visible, Strings.Trim(Me.txtMaKhu.Text), ""))
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@pbitL02PER"
				array(20).Value = Me.chkL02Per.Checked
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@int_Result"
				array(18).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_INSERT", flag)
				Dim num As Integer = Conversions.ToInteger(array(18).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(31), MsgBoxStyle.Critical, Nothing)
						Me.txtMAKH.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(32), MsgBoxStyle.Critical, Nothing)
							Me.cmbHTKM.Focus()
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(34), MsgBoxStyle.Critical, Nothing)
								Me.btnExit.Focus()
							Else
								flag2 = num = 4
								If flag2 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(39), MsgBoxStyle.Critical, Nothing)
									Me.txtMANDV.Focus()
								Else
									flag2 = num = 5
									If flag2 Then
										Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
										Me.txtMANDV.Focus()
									Else
										flag2 = num = 6
										If flag2 Then
											Interaction.MsgBox(Me.mArrStrFrmMess(53), MsgBoxStyle.Critical, Nothing)
											Me.txtMaKhu.Focus()
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAddNew ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000EE7 RID: 3815 RVA: 0x000B0D90 File Offset: 0x000AEF90
		Private Function fModify() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(21) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@pnvchOBJNAME"
				array(1).Value = Strings.Trim(Me.txtOBJNAME.Text)
				array(2) = sqlCommand.CreateParameter()
				array(2).ParameterName = "@pnchMAKH"
				array(2).Value = Strings.Trim(Me.txtMAKH.Text)
				array(3) = sqlCommand.CreateParameter()
				array(3).ParameterName = "@pnchMAKM"
				array(3).Value = Me.cmbHTKM.SelectedValue.ToString()
				array(4) = sqlCommand.CreateParameter()
				array(4).ParameterName = "@pnvchFROMDATE"
				array(4).Value = Strings.Trim(Me.mtxFromDate.Text)
				array(5) = sqlCommand.CreateParameter()
				array(5).ParameterName = "@pnvchTODATE"
				array(5).Value = Strings.Trim(Me.mtxToDate.Text)
				array(6) = sqlCommand.CreateParameter()
				array(6).ParameterName = "@pbitLDAY2"
				array(6).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT2.Checked, 1, 0))
				array(7) = sqlCommand.CreateParameter()
				array(7).ParameterName = "@pbitLDAY3"
				array(7).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT3.Checked, 1, 0))
				array(8) = sqlCommand.CreateParameter()
				array(8).ParameterName = "@pbitLDAY4"
				array(8).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT4.Checked, 1, 0))
				array(9) = sqlCommand.CreateParameter()
				array(9).ParameterName = "@pbitLDAY5"
				array(9).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT5.Checked, 1, 0))
				array(10) = sqlCommand.CreateParameter()
				array(10).ParameterName = "@pbitLDAY6"
				array(10).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT6.Checked, 1, 0))
				array(11) = sqlCommand.CreateParameter()
				array(11).ParameterName = "@pbitLDAY7"
				array(11).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkT7.Checked, 1, 0))
				array(12) = sqlCommand.CreateParameter()
				array(12).ParameterName = "@pbitLDAY8"
				array(12).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.chkCN.Checked, 1, 0))
				array(13) = sqlCommand.CreateParameter()
				array(13).ParameterName = "@pnvchFROMTIME"
				array(13).Value = Strings.Trim(Me.mtxFromTime.Text)
				array(14) = sqlCommand.CreateParameter()
				array(14).ParameterName = "@pnvchTOTIME"
				array(14).Value = Strings.Trim(Me.mtxToTime.Text)
				array(15) = sqlCommand.CreateParameter()
				array(15).ParameterName = "@prelPARA1"
				array(15).Value = Conversion.Val(Strings.Replace(Strings.Trim(Me.txtQty1.Text), ",", "", 1, -1, CompareMethod.Binary))
				array(16) = sqlCommand.CreateParameter()
				array(16).ParameterName = "@prelPARA2"
				array(16).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.txtQty2.Visible, Conversion.Val(Strings.Replace(Strings.Trim(Me.txtQty2.Text), ",", "", 1, -1, CompareMethod.Binary)), 0))
				array(17) = sqlCommand.CreateParameter()
				array(17).ParameterName = "@pnchMANHOMDV"
				array(17).Value = Strings.Trim(Me.txtMANDV.Text)
				array(19) = sqlCommand.CreateParameter()
				array(19).ParameterName = "@pnchMAKHU"
				array(19).Value = RuntimeHelpers.GetObjectValue(Interaction.IIf(Me.panKHU.Visible, Strings.Trim(Me.txtMaKhu.Text), ""))
				array(20) = sqlCommand.CreateParameter()
				array(20).ParameterName = "@pbitL02PER"
				array(20).Value = Me.chkL02Per.Checked
				array(18) = sqlCommand.CreateParameter()
				array(18).ParameterName = "@int_Result"
				array(18).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_UPDATE", flag)
				Dim num As Integer = Conversions.ToInteger(array(18).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					Me.mStrFilter = Strings.Trim(Me.txtOBJID.Text)
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(31), MsgBoxStyle.Critical, Nothing)
						Me.txtMAKH.Focus()
					Else
						flag2 = num = 2
						If flag2 Then
							Interaction.MsgBox(Me.mArrStrFrmMess(32), MsgBoxStyle.Critical, Nothing)
							Me.cmbHTKM.Focus()
						Else
							flag2 = num = 3
							If flag2 Then
								Interaction.MsgBox(Me.mArrStrFrmMess(33), MsgBoxStyle.Critical, Nothing)
								Me.btnExit.Focus()
							Else
								flag2 = num = 4
								If flag2 Then
									Interaction.MsgBox(Me.mArrStrFrmMess(39), MsgBoxStyle.Critical, Nothing)
									Me.txtMANDV.Focus()
								Else
									flag2 = num = 5
									If flag2 Then
										Interaction.MsgBox(Me.mArrStrFrmMess(50), MsgBoxStyle.Critical, Nothing)
										Me.txtMANDV.Focus()
									Else
										flag2 = num = 6
										If flag2 Then
											Interaction.MsgBox(Me.mArrStrFrmMess(53), MsgBoxStyle.Critical, Nothing)
											Me.txtMaKhu.Focus()
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000EE8 RID: 3816 RVA: 0x000B1508 File Offset: 0x000AF708
		Private Function fDelete() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchOBJID"
				array(0).Value = Strings.Trim(Me.txtOBJID.Text)
				array(1) = sqlCommand.CreateParameter()
				array(1).ParameterName = "@int_Result"
				array(1).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMDNKM_DEL", flag)
				Dim num As Integer = Conversions.ToInteger(array(1).Value)
				Dim flag2 As Boolean = num = 0
				If flag2 Then
					b = 1
				Else
					flag2 = num = 1
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(33), MsgBoxStyle.Critical, Nothing)
						Me.btnExit.Focus()
					End If
				End If
			Catch ex As Exception
				b = 0
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06000EE9 RID: 3817 RVA: 0x000B16A4 File Offset: 0x000AF8A4
		Private Function fGetData_4Combo() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKM = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKM")
				Dim flag As Boolean = Me.mclsTbDMKM IsNot Nothing
				If flag Then
					Dim cmbHTKM As ComboBox = Me.cmbHTKM
					cmbHTKM.DataSource = Me.mclsTbDMKM
					cmbHTKM.DisplayMember = "OBJNAME"
					cmbHTKM.ValueMember = "OBJID"
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Combo ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000EEA RID: 3818 RVA: 0x000B1790 File Offset: 0x000AF990
		Private Sub sClearCheckBox()
			Try
				Select Case Me.mbytFormStatus
					Case 1, 2
						Me.chkT2.Checked = False
						Me.chkT3.Checked = False
						Me.chkT4.Checked = False
						Me.chkT5.Checked = False
						Me.chkT6.Checked = False
						Me.chkT7.Checked = False
						Me.chkCN.Checked = False
				End Select
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClearCheckBox ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EEB RID: 3819 RVA: 0x000B18A8 File Offset: 0x000AFAA8
		Private Sub sDisplayLabel()
			Try
				Me.panNHOMCHU.Visible = False
				Me.panKHU.Visible = False
				Me.lblMaNDV.Tag = "CB0013"
				Me.chkL02Per.Visible = False
				Dim text As String = Me.cmbHTKM.SelectedValue.ToString()
				Dim flag As Boolean = Operators.CompareString(text, "00", False) = 0 OrElse Operators.CompareString(text, "01", False) = 0
				If flag Then
					Me.lblQty2.Visible = True
					Me.txtQty2.Visible = True
					Me.lblQty1.Tag = "CR0023"
					Me.lblQty2.Tag = "CR0024"
				Else
					flag = Operators.CompareString(text, "02", False) = 0
					If flag Then
						Me.lblQty2.Visible = True
						Me.txtQty2.Visible = True
						Me.lblQty1.Tag = "CR0042"
						Me.lblQty2.Tag = "CR0041"
						Me.chkL02Per.Visible = True
					Else
						flag = Operators.CompareString(text, "03", False) = 0
						If flag Then
							Me.lblQty2.Visible = True
							Me.txtQty2.Visible = True
							Me.lblQty1.Tag = "CR0042"
							Me.lblQty2.Tag = "CR0057"
							Me.panKHU.Visible = True
						Else
							Dim flag2 As Boolean
							If Operators.CompareString(text, "04", False) <> 0 AndAlso Operators.CompareString(text, "06", False) <> 0 Then
								If Operators.CompareString(text, "09", False) <> 0 Then
									flag2 = False
									GoTo IL_01AC
								End If
							End If
							flag2 = True
							IL_01AC:
							flag = flag2
							If flag Then
								Me.lblQty1.Tag = "CR0040"
								Me.lblQty2.Visible = False
								Me.txtQty2.Visible = False
								Me.panNHOMCHU.Visible = True
							Else
								flag = Operators.CompareString(text, "05", False) = 0
								If flag Then
									Me.lblQty1.Tag = "CR0041"
									Me.lblQty2.Visible = False
									Me.txtQty2.Visible = False
									Me.panNHOMCHU.Visible = True
								Else
									flag = Operators.CompareString(text, "07", False) = 0
									If flag Then
										Me.lblQty1.Tag = "CR0040"
										Me.lblQty2.Tag = "CR0048"
										Me.lblQty2.Visible = True
										Me.txtQty2.Visible = True
										Me.panNHOMCHU.Visible = True
									Else
										flag = Operators.CompareString(text, "08", False) = 0
										If flag Then
											Me.lblQty2.Visible = True
											Me.txtQty2.Visible = True
											Me.lblQty1.Tag = "CR0042"
											Me.lblQty2.Tag = "CR0057"
											Me.panNHOMCHU.Visible = True
											Me.lblMaNDV.Tag = "CB0049"
											Me.panKHU.Visible = True
										Else
											flag = Operators.CompareString(text, "10", False) = 0
											If flag Then
												Me.lblQty1.Tag = "CR0040"
												Me.lblQty2.Visible = False
												Me.txtQty2.Visible = False
												Me.panNHOMCHU.Visible = True
												Me.lblMaNDV.Tag = "CB0013"
												Me.Label1.Tag = "CB0049"
												Me.panKHU.Visible = True
											Else
												flag = Operators.CompareString(text, "11", False) = 0
												If flag Then
													Me.lblQty2.Visible = True
													Me.txtQty2.Visible = True
													Me.lblQty1.Tag = "CR0042"
													Me.lblQty2.Tag = "CR0055"
													Me.panKHU.Visible = True
												Else
													flag = Operators.CompareString(text, "12", False) = 0
													If flag Then
														Me.lblQty2.Visible = False
														Me.txtQty2.Visible = False
														Me.lblQty1.Tag = "CR0056"
														Me.panKHU.Visible = False
														Me.panNHOMCHU.Visible = False
													End If
												End If
											End If
										End If
									End If
								End If
							End If
						End If
					End If
				End If
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2080900000")
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sDisplayLabel ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EEC RID: 3820 RVA: 0x000B1DA4 File Offset: 0x000AFFA4
		Private Sub txtOBJID_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtOBJID.[ReadOnly]
				If [readOnly] Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EED RID: 3821 RVA: 0x000B1E50 File Offset: 0x000B0050
		Private Sub txtTENKH_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENKH.[ReadOnly]
				If [readOnly] Then
					Me.txtMANDV.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENKH_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EEE RID: 3822 RVA: 0x000B1EFC File Offset: 0x000B00FC
		Private Sub txtTenNDV_GotFocus(sender As Object, e As EventArgs)
			Try
				Dim [readOnly] As Boolean = Me.txtTENKH.[ReadOnly]
				If [readOnly] Then
					Me.cmbHTKM.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTenNDV_GotFocus ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000EEF RID: 3823 RVA: 0x000B1FA8 File Offset: 0x000B01A8
		Private Sub txtTenNDV_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbHTKM.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTenNDV_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EF0 RID: 3824 RVA: 0x000B204C File Offset: 0x000B024C
		Private Sub txtOBJID_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtOBJNAME.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJID_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EF1 RID: 3825 RVA: 0x000B20F0 File Offset: 0x000B02F0
		Private Sub txtOBJNAME_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMAKH.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJNAME_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EF2 RID: 3826 RVA: 0x000B2194 File Offset: 0x000B0394
		Private Sub txtMAKH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtTENKH.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EF3 RID: 3827 RVA: 0x000B2238 File Offset: 0x000B0438
		Private Sub txtTENKH_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtMANDV.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtTENKH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EF4 RID: 3828 RVA: 0x000B22DC File Offset: 0x000B04DC
		Private Sub cmbHTKM_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxFromDate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - cmbHTKM_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EF5 RID: 3829 RVA: 0x000B2380 File Offset: 0x000B0580
		Private Sub mtxFromDate_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxToDate.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxFromDate_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EF6 RID: 3830 RVA: 0x000B2424 File Offset: 0x000B0624
		Private Sub mtxToDate_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT2.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxToDate_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EF7 RID: 3831 RVA: 0x000B24C8 File Offset: 0x000B06C8
		Private Sub chkT2_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT3.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT2_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EF8 RID: 3832 RVA: 0x000B256C File Offset: 0x000B076C
		Private Sub chkT3_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT4.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT3_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EF9 RID: 3833 RVA: 0x000B2610 File Offset: 0x000B0810
		Private Sub chkT4_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT5.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT4_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EFA RID: 3834 RVA: 0x000B26B4 File Offset: 0x000B08B4
		Private Sub chkT5_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT6.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT5_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EFB RID: 3835 RVA: 0x000B2758 File Offset: 0x000B0958
		Private Sub chkT6_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkT7.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT6_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EFC RID: 3836 RVA: 0x000B27FC File Offset: 0x000B09FC
		Private Sub chkT7_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.chkCN.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkT7_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EFD RID: 3837 RVA: 0x000B28A0 File Offset: 0x000B0AA0
		Private Sub chkCN_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxFromTime.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - chkCN_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EFE RID: 3838 RVA: 0x000B2944 File Offset: 0x000B0B44
		Private Sub mtxFromTime_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.mtxToTime.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxFromTime_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000EFF RID: 3839 RVA: 0x000B29E8 File Offset: 0x000B0BE8
		Private Sub mtxToTime_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.txtQty1.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mtxToTime_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000F00 RID: 3840 RVA: 0x000B2A8C File Offset: 0x000B0C8C
		Private Sub txtQty1_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.txtQty2.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtQty1_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000F01 RID: 3841 RVA: 0x000B2C28 File Offset: 0x000B0E28
		Private Sub txtQty2_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Select Case Strings.Asc(e.KeyChar)
					Case 8, 42, 43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61
						GoTo IL_010C
					Case 13
						Me.btnSave.Focus()
						GoTo IL_010C
				End Select
				e.Handled = True
				IL_010C:
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtQty2_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000F02 RID: 3842 RVA: 0x000B2DC4 File Offset: 0x000B0FC4
		Private Sub txtMAKH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKHO Is Nothing
				If Not flag Then
					array(0) = Me.mclsTbDMKHO.Columns("OBJID")
					Me.mclsTbDMKHO.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMKHO.Rows.Find(Strings.Trim(Me.txtMAKH.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtTENKH.Text = dataRow("OBJNAME").ToString()
					Else
						Me.txtTENKH.Text = ""
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F03 RID: 3843 RVA: 0x000B2F18 File Offset: 0x000B1118
		Private Sub txtMANDV_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Dim visible As Boolean = Me.txtMaKhu.Visible
					If visible Then
						Me.txtMaKhu.Focus()
					Else
						Me.cmbHTKM.Focus()
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000F04 RID: 3844 RVA: 0x000B2FDC File Offset: 0x000B11DC
		Private Sub txtMANDV_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Operators.CompareString(Me.cmbHTKM.SelectedValue.ToString(), "08", False) = 0
				If flag Then
					Dim flag2 As Boolean = Me.mclsTbDMNC Is Nothing
					If Not flag2 Then
						array(0) = Me.mclsTbDMNC.Columns("OBJID")
						Me.mclsTbDMNC.PrimaryKey = array
						Dim dataRow As DataRow = Me.mclsTbDMNC.Rows.Find(Strings.Trim(Me.txtMANDV.Text))
						flag2 = dataRow IsNot Nothing
						If flag2 Then
							Me.txtTenNDV.Text = dataRow("OBJNAME").ToString()
						Else
							Me.txtTenNDV.Text = ""
						End If
					End If
				Else
					Dim flag2 As Boolean = Me.mclsTbDMNHOMDV Is Nothing
					If Not flag2 Then
						array(0) = Me.mclsTbDMNHOMDV.Columns("OBJID")
						Me.mclsTbDMNHOMDV.PrimaryKey = array
						Dim dataRow As DataRow = Me.mclsTbDMNHOMDV.Rows.Find(Strings.Trim(Me.txtMANDV.Text))
						flag2 = dataRow IsNot Nothing
						If flag2 Then
							Me.txtTenNDV.Text = dataRow("OBJNAME").ToString()
						Else
							Me.txtTenNDV.Text = ""
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMANDV_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F05 RID: 3845 RVA: 0x000B31F8 File Offset: 0x000B13F8
		Private Function fGetData_DMKH() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKHO = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
				Dim flag As Boolean = Me.mclsTbDMKHO IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMKH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000F06 RID: 3846 RVA: 0x000B32B4 File Offset: 0x000B14B4
		Private Function fGetData_DMKHU() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMKHU = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKHU")
				Dim flag As Boolean = Me.mclsTbDMKHU IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMKHU ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000F07 RID: 3847 RVA: 0x000B3370 File Offset: 0x000B1570
		Private Function fGetData_DMNHOMDV() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMNHOMDV = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNHOMDV")
				Dim flag As Boolean = Me.mclsTbDMNHOMDV IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMNHOMDV ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000F08 RID: 3848 RVA: 0x000B342C File Offset: 0x000B162C
		Private Function fGetData_DMNC() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMNC = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNCHU")
				Dim flag As Boolean = Me.mclsTbDMNC IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_DMNC ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000F09 RID: 3849 RVA: 0x000B34E8 File Offset: 0x000B16E8
		Public Sub gsCheckDate()
			Try
				Me.chkT2.Checked = True
				Me.chkT3.Checked = True
				Me.chkT4.Checked = True
				Me.chkT5.Checked = True
				Me.chkT6.Checked = True
				Me.chkT7.Checked = True
				Me.chkCN.Checked = True
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gsCheckDate ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F0A RID: 3850 RVA: 0x000B35D4 File Offset: 0x000B17D4
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				flag = Me.txtOBJID.[ReadOnly]
				If flag Then
					Me.txtOBJNAME.Focus()
					Me.txtOBJNAME.SelectAll()
				Else
					Me.txtOBJID.Focus()
					Me.txtOBJID.SelectAll()
				End If
			End If
		End Sub

		' Token: 0x06000F0B RID: 3851 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x06000F0C RID: 3852 RVA: 0x000B3650 File Offset: 0x000B1850
		Private Sub txtMaKhu_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMKHU Is Nothing
				If Not flag Then
					flag = Operators.CompareString(Me.cmbHTKM.SelectedValue.ToString(), "10", False) = 0
					If flag Then
						Dim flag2 As Boolean = Me.mclsTbDMNC Is Nothing
						If Not flag2 Then
							array(0) = Me.mclsTbDMNC.Columns("OBJID")
							Me.mclsTbDMNC.PrimaryKey = array
							Dim dataRow As DataRow = Me.mclsTbDMNC.Rows.Find(Strings.Trim(Me.txtMaKhu.Text))
							flag2 = dataRow IsNot Nothing
							If flag2 Then
								Me.txtTenKhu.Text = dataRow("OBJNAME").ToString()
							Else
								Me.txtTenKhu.Text = ""
							End If
						End If
					Else
						array(0) = Me.mclsTbDMKHU.Columns("OBJID")
						Me.mclsTbDMKHU.PrimaryKey = array
						Dim dataRow As DataRow = Me.mclsTbDMKHU.Rows.Find(Strings.Trim(Me.txtMaKhu.Text))
						Dim flag2 As Boolean = dataRow IsNot Nothing
						If flag2 Then
							Me.txtTenKhu.Text = dataRow("OBJNAME").ToString()
						Else
							Me.txtTenKhu.Text = ""
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKHU_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06000F0D RID: 3853 RVA: 0x000B386C File Offset: 0x000B1A6C
		Private Sub txtMaKhu_KeyPress(sender As Object, e As KeyPressEventArgs)
			Try
				Dim flag As Boolean = Strings.Asc(e.KeyChar) = 13
				If flag Then
					Me.cmbHTKM.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtMAKH_KeyPress ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000F0E RID: 3854 RVA: 0x000B3910 File Offset: 0x000B1B10
		Private Sub btnMaKhu_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Operators.CompareString(Me.cmbHTKM.SelectedValue.ToString(), "10", False) = 0
				If flag Then
					Dim frmDMNCHU As frmDMNCHU1 = New frmDMNCHU1()
					frmDMNCHU.pBytOpen_From_Menu = 7
					frmDMNCHU.ShowDialog()
					Me.txtMaKhu.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNCHU.pStrOBJID, "", False) = 0, Me.txtMaKhu.Text, frmDMNCHU.pStrOBJID))
					Me.txtTenKhu.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMNCHU.pStrOBJNAME, "", False) = 0, Me.txtTenKhu.Text, frmDMNCHU.pStrOBJNAME))
					frmDMNCHU.Dispose()
				Else
					Dim frmDMKHU As frmDMKHU1 = New frmDMKHU1()
					frmDMKHU.pBytOpen_From_Menu = 7
					frmDMKHU.ShowDialog()
					Me.txtMaKhu.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKHU.pStrOBJID, "", False) = 0, Me.txtMaKhu.Text, frmDMKHU.pStrOBJID))
					Me.txtTenKhu.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKHU.pStrOBJNAME, "", False) = 0, Me.txtTenKhu.Text, frmDMKHU.pStrOBJNAME))
					frmDMKHU.Dispose()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0400061B RID: 1563
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x0400061D RID: 1565
		<AccessedThroughProperty("grpButton")>
		Private _grpButton As GroupBox

		' Token: 0x0400061E RID: 1566
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x0400061F RID: 1567
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000620 RID: 1568
		<AccessedThroughProperty("btnSave")>
		Private _btnSave As Button

		' Token: 0x04000621 RID: 1569
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000622 RID: 1570
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000623 RID: 1571
		<AccessedThroughProperty("lblOBJNAME")>
		Private _lblOBJNAME As Label

		' Token: 0x04000624 RID: 1572
		<AccessedThroughProperty("txtOBJNAME")>
		Private _txtOBJNAME As TextBox

		' Token: 0x04000625 RID: 1573
		<AccessedThroughProperty("txtOBJID")>
		Private _txtOBJID As TextBox

		' Token: 0x04000626 RID: 1574
		<AccessedThroughProperty("lblOBJID")>
		Private _lblOBJID As Label

		' Token: 0x04000627 RID: 1575
		<AccessedThroughProperty("lblFromDate")>
		Private _lblFromDate As Label

		' Token: 0x04000628 RID: 1576
		<AccessedThroughProperty("cmbHTKM")>
		Private _cmbHTKM As ComboBox

		' Token: 0x04000629 RID: 1577
		<AccessedThroughProperty("lblHTKM")>
		Private _lblHTKM As Label

		' Token: 0x0400062A RID: 1578
		<AccessedThroughProperty("txtTENKH")>
		Private _txtTENKH As TextBox

		' Token: 0x0400062B RID: 1579
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x0400062C RID: 1580
		<AccessedThroughProperty("txtMAKH")>
		Private _txtMAKH As TextBox

		' Token: 0x0400062D RID: 1581
		<AccessedThroughProperty("lblkHO")>
		Private _lblkHO As Label

		' Token: 0x0400062E RID: 1582
		<AccessedThroughProperty("lblToDate")>
		Private _lblToDate As Label

		' Token: 0x0400062F RID: 1583
		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		' Token: 0x04000630 RID: 1584
		<AccessedThroughProperty("lblToTime")>
		Private _lblToTime As Label

		' Token: 0x04000631 RID: 1585
		<AccessedThroughProperty("lblFromTime")>
		Private _lblFromTime As Label

		' Token: 0x04000632 RID: 1586
		<AccessedThroughProperty("chkT2")>
		Private _chkT2 As CheckBox

		' Token: 0x04000633 RID: 1587
		<AccessedThroughProperty("chkT3")>
		Private _chkT3 As CheckBox

		' Token: 0x04000634 RID: 1588
		<AccessedThroughProperty("chkT4")>
		Private _chkT4 As CheckBox

		' Token: 0x04000635 RID: 1589
		<AccessedThroughProperty("chkT5")>
		Private _chkT5 As CheckBox

		' Token: 0x04000636 RID: 1590
		<AccessedThroughProperty("chkT6")>
		Private _chkT6 As CheckBox

		' Token: 0x04000637 RID: 1591
		<AccessedThroughProperty("chkT7")>
		Private _chkT7 As CheckBox

		' Token: 0x04000638 RID: 1592
		<AccessedThroughProperty("chkCN")>
		Private _chkCN As CheckBox

		' Token: 0x04000639 RID: 1593
		<AccessedThroughProperty("txtQty1")>
		Private _txtQty1 As TextBox

		' Token: 0x0400063A RID: 1594
		<AccessedThroughProperty("lblQty1")>
		Private _lblQty1 As Label

		' Token: 0x0400063B RID: 1595
		<AccessedThroughProperty("txtQty2")>
		Private _txtQty2 As TextBox

		' Token: 0x0400063C RID: 1596
		<AccessedThroughProperty("lblQty2")>
		Private _lblQty2 As Label

		' Token: 0x0400063D RID: 1597
		<AccessedThroughProperty("mtxFromDate")>
		Private _mtxFromDate As MaskedTextBox

		' Token: 0x0400063E RID: 1598
		<AccessedThroughProperty("mtxToDate")>
		Private _mtxToDate As MaskedTextBox

		' Token: 0x0400063F RID: 1599
		<AccessedThroughProperty("mtxFromTime")>
		Private _mtxFromTime As MaskedTextBox

		' Token: 0x04000640 RID: 1600
		<AccessedThroughProperty("mtxToTime")>
		Private _mtxToTime As MaskedTextBox

		' Token: 0x04000641 RID: 1601
		<AccessedThroughProperty("txtTenNDV")>
		Private _txtTenNDV As TextBox

		' Token: 0x04000642 RID: 1602
		<AccessedThroughProperty("btnNDV")>
		Private _btnNDV As Button

		' Token: 0x04000643 RID: 1603
		<AccessedThroughProperty("txtMANDV")>
		Private _txtMANDV As TextBox

		' Token: 0x04000644 RID: 1604
		<AccessedThroughProperty("lblMaNDV")>
		Private _lblMaNDV As Label

		' Token: 0x04000645 RID: 1605
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000646 RID: 1606
		<AccessedThroughProperty("panNHOMCHU")>
		Private _panNHOMCHU As Panel

		' Token: 0x04000647 RID: 1607
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x04000648 RID: 1608
		<AccessedThroughProperty("panKHU")>
		Private _panKHU As Panel

		' Token: 0x04000649 RID: 1609
		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		' Token: 0x0400064A RID: 1610
		<AccessedThroughProperty("txtMaKhu")>
		Private _txtMaKhu As TextBox

		' Token: 0x0400064B RID: 1611
		<AccessedThroughProperty("btnMaKhu")>
		Private _btnMaKhu As Button

		' Token: 0x0400064C RID: 1612
		<AccessedThroughProperty("txtTenKhu")>
		Private _txtTenKhu As TextBox

		' Token: 0x0400064D RID: 1613
		<AccessedThroughProperty("chkL02Per")>
		Private _chkL02Per As CheckBox

		' Token: 0x0400064E RID: 1614
		Private mArrStrFrmMess As String()

		' Token: 0x0400064F RID: 1615
		Private mbytFormStatus As Byte

		' Token: 0x04000650 RID: 1616
		Private mbytSuccess As Byte

		' Token: 0x04000651 RID: 1617
		Private mstrKHO As String

		' Token: 0x04000652 RID: 1618
		Private mstrKHU As String

		' Token: 0x04000653 RID: 1619
		Private mstrOBJID As String

		' Token: 0x04000654 RID: 1620
		Private mstrHTKM As String

		' Token: 0x04000655 RID: 1621
		Private mstrMaNHOMDV As Object

		' Token: 0x04000656 RID: 1622
		Private mStrFilter As String

		' Token: 0x04000657 RID: 1623
		Private mStrFromDate As String

		' Token: 0x04000658 RID: 1624
		Private mStrToDate As String

		' Token: 0x04000659 RID: 1625
		Private mStrFromTime As String

		' Token: 0x0400065A RID: 1626
		Private mStrToTime As String

		' Token: 0x0400065B RID: 1627
		Private mclsTbDMKHO As clsConnect

		' Token: 0x0400065C RID: 1628
		Private mclsTbDMNHOMDV As clsConnect

		' Token: 0x0400065D RID: 1629
		Private mclsTbDMNC As clsConnect

		' Token: 0x0400065E RID: 1630
		Private mclsTbDMKHU As clsConnect

		' Token: 0x0400065F RID: 1631
		Private mclsTbDMKM As clsConnect
	End Class
End Namespace
