﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x0200034C RID: 844
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptTHUCHIK58
		Inherits Component
		Implements ICachedReport

		' Token: 0x0600735D RID: 29533 RVA: 0x0001498B File Offset: 0x00012B8B
		Public Sub New()
			CachedrptTHUCHIK58.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17003090 RID: 12432
		' (get) Token: 0x0600735E RID: 29534 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x0600735F RID: 29535 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17003091 RID: 12433
		' (get) Token: 0x06007360 RID: 29536 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06007361 RID: 29537 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17003092 RID: 12434
		' (get) Token: 0x06007362 RID: 29538 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06007363 RID: 29539 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06007364 RID: 29540 RVA: 0x004DFBC4 File Offset: 0x004DDDC4
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptTHUCHIK58() With { .Site = Me.Site }
		End Function

		' Token: 0x06007365 RID: 29541 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x04002944 RID: 10564
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
