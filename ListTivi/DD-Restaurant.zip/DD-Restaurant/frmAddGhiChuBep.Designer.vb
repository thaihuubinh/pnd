﻿Namespace prjIS_SalesPOS
	' Token: 0x02000017 RID: 23
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmAddGhiChuBep
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060002DE RID: 734 RVA: 0x000240C8 File Offset: 0x000222C8
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060002DF RID: 735 RVA: 0x00024100 File Offset: 0x00022300
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmAddGhiChuBep))
			Me.txtMa = New Global.System.Windows.Forms.TextBox()
			Me.btnKH = New Global.System.Windows.Forms.Button()
			Me.Label1 = New Global.System.Windows.Forms.Label()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.btnSave = New Global.System.Windows.Forms.Button()
			Me.SuspendLayout()
			Me.txtMa.Font = New Global.System.Drawing.Font("Arial", 20.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtMa As Global.System.Windows.Forms.Control = Me.txtMa
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(116, 7)
			txtMa.Location = point
			Me.txtMa.Name = "txtMa"
			Dim txtMa2 As Global.System.Windows.Forms.Control = Me.txtMa
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(276, 39)
			txtMa2.Size = size
			Me.txtMa.TabIndex = 3
			Me.txtMa.Tag = "N0020R0000"
			Me.btnKH.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.None
			Me.btnKH.Font = New Global.System.Drawing.Font("Arial", 18F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnKH.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnKH.Image = CType(componentResourceManager.GetObject("btnKH.Image"), Global.System.Drawing.Image)
			Dim btnKH As Global.System.Windows.Forms.Control = Me.btnKH
			point = New Global.System.Drawing.Point(398, 5)
			btnKH.Location = point
			Me.btnKH.Name = "btnKH"
			Dim btnKH2 As Global.System.Windows.Forms.Control = Me.btnKH
			size = New Global.System.Drawing.Size(53, 43)
			btnKH2.Size = size
			Me.btnKH.TabIndex = 4
			Me.btnKH.Tag = ""
			Me.btnKH.UseVisualStyleBackColor = True
			Me.Label1.Font = New Global.System.Drawing.Font("Arial", 11.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.Label1.ForeColor = Global.System.Drawing.Color.FromArgb(0, 0, 192)
			Dim label As Global.System.Windows.Forms.Control = Me.Label1
			point = New Global.System.Drawing.Point(12, 9)
			label.Location = point
			Me.Label1.Name = "Label1"
			Dim label2 As Global.System.Windows.Forms.Control = Me.Label1
			size = New Global.System.Drawing.Size(98, 40)
			label2.Size = size
			Me.Label1.TabIndex = 2
			Me.Label1.Tag = "CB0003"
			Me.Label1.Text = "Ghi chú"
			Me.Label1.TextAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Me.btnExit.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnExit.BackgroundImage = CType(componentResourceManager.GetObject("btnExit.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnExit.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnExit.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnExit.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Me.btnExit.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(340, 67)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(111, 41)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 6
			Me.btnExit.Tag = "C00002"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = False
			Me.btnSave.BackColor = Global.System.Drawing.Color.Gainsboro
			Me.btnSave.BackgroundImage = CType(componentResourceManager.GetObject("btnSave.BackgroundImage"), Global.System.Drawing.Image)
			Me.btnSave.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnSave.Font = New Global.System.Drawing.Font("Arial", 14.25F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnSave.ForeColor = Global.System.Drawing.Color.Blue
			Me.btnSave.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Me.btnSave.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim btnSave As Global.System.Windows.Forms.Control = Me.btnSave
			point = New Global.System.Drawing.Point(15, 67)
			btnSave.Location = point
			Me.btnSave.Name = "btnSave"
			Dim btnSave2 As Global.System.Windows.Forms.Control = Me.btnSave
			size = New Global.System.Drawing.Size(111, 41)
			btnSave2.Size = size
			Me.btnSave.TabIndex = 5
			Me.btnSave.Tag = "C00001"
			Me.btnSave.Text = "Chọn"
			Me.btnSave.TextAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Me.btnSave.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSave.UseVisualStyleBackColor = False
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(8F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(458, 111)
			Me.ClientSize = size
			Me.Controls.Add(Me.btnExit)
			Me.Controls.Add(Me.btnSave)
			Me.Controls.Add(Me.txtMa)
			Me.Controls.Add(Me.btnKH)
			Me.Controls.Add(Me.Label1)
			Me.Font = New Global.System.Drawing.Font("Microsoft Sans Serif", 10F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(4)
			Me.Margin = padding
			Me.Name = "frmAddGhiChuBep"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Ghi chú"
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x0400013A RID: 314
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
