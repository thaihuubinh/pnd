﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x02000134 RID: 308
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptBARCODE
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005858 RID: 22616 RVA: 0x0000F3B3 File Offset: 0x0000D5B3
		Public Sub New()
			CachedrptBARCODE.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002003 RID: 8195
		' (get) Token: 0x06005859 RID: 22617 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x0600585A RID: 22618 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002004 RID: 8196
		' (get) Token: 0x0600585B RID: 22619 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x0600585C RID: 22620 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002005 RID: 8197
		' (get) Token: 0x0600585D RID: 22621 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x0600585E RID: 22622 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x0600585F RID: 22623 RVA: 0x004DB1E0 File Offset: 0x004D93E0
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptBARCODE() With { .Site = Me.Site }
		End Function

		' Token: 0x06005860 RID: 22624 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x0400272C RID: 10028
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
