﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x0200003C RID: 60
	<DesignerGenerated()>
	Public Partial Class frmDMChat
		Inherits Form

		' Token: 0x06000DE6 RID: 3558 RVA: 0x000A4174 File Offset: 0x000A2374
		<DebuggerNonUserCode()>
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMChat_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmSelectDepartment_Group_Load
			AddHandler MyBase.Activated, AddressOf Me.frmDMChat_Activated
			frmDMChat.__ENCList.Add(New WeakReference(Me))
			Me.InitializeComponent()
		End Sub

		' Token: 0x170004F6 RID: 1270
		' (get) Token: 0x06000DE9 RID: 3561 RVA: 0x000A4900 File Offset: 0x000A2B00
		' (set) Token: 0x06000DEA RID: 3562 RVA: 0x000A4918 File Offset: 0x000A2B18
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170004F7 RID: 1271
		' (get) Token: 0x06000DEB RID: 3563 RVA: 0x000A4984 File Offset: 0x000A2B84
		' (set) Token: 0x06000DEC RID: 3564 RVA: 0x000043CA File Offset: 0x000025CA
		Friend Overridable Property TableLayoutPanel5 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel5
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel5 = value
			End Set
		End Property

		' Token: 0x170004F8 RID: 1272
		' (get) Token: 0x06000DED RID: 3565 RVA: 0x000A499C File Offset: 0x000A2B9C
		' (set) Token: 0x06000DEE RID: 3566 RVA: 0x000043D4 File Offset: 0x000025D4
		Friend Overridable Property txtMess As RichTextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMess
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RichTextBox)
				Me._txtMess = value
			End Set
		End Property

		' Token: 0x170004F9 RID: 1273
		' (get) Token: 0x06000DEF RID: 3567 RVA: 0x000A49B4 File Offset: 0x000A2BB4
		' (set) Token: 0x06000DF0 RID: 3568 RVA: 0x000043DE File Offset: 0x000025DE
		Friend Overridable Property txtIn As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtIn
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtIn = value
			End Set
		End Property

		' Token: 0x170004FA RID: 1274
		' (get) Token: 0x06000DF1 RID: 3569 RVA: 0x000A49CC File Offset: 0x000A2BCC
		' (set) Token: 0x06000DF2 RID: 3570 RVA: 0x000A49E4 File Offset: 0x000A2BE4
		Friend Overridable Property btnSend As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSend
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSend IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSend.Click, AddressOf Me.btnSend_Click
				End If
				Me._btnSend = value
				flag = Me._btnSend IsNot Nothing
				If flag Then
					AddHandler Me._btnSend.Click, AddressOf Me.btnSend_Click
				End If
			End Set
		End Property

		' Token: 0x170004FB RID: 1275
		' (get) Token: 0x06000DF3 RID: 3571 RVA: 0x000A4A50 File Offset: 0x000A2C50
		' (set) Token: 0x06000DF4 RID: 3572 RVA: 0x000A4A68 File Offset: 0x000A2C68
		Friend Overridable Property Timer1 As Timer
			<DebuggerNonUserCode()>
			Get
				Return Me._Timer1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim flag As Boolean = Me._Timer1 IsNot Nothing
				If flag Then
					RemoveHandler Me._Timer1.Tick, AddressOf Me.Timer1_Tick
				End If
				Me._Timer1 = value
				flag = Me._Timer1 IsNot Nothing
				If flag Then
					AddHandler Me._Timer1.Tick, AddressOf Me.Timer1_Tick
				End If
			End Set
		End Property

		' Token: 0x170004FC RID: 1276
		' (get) Token: 0x06000DF5 RID: 3573 RVA: 0x000A4AD4 File Offset: 0x000A2CD4
		' (set) Token: 0x06000DF6 RID: 3574 RVA: 0x000A4AEC File Offset: 0x000A2CEC
		Friend Overridable Property btnKeyboard As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnKeyboard
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnKeyboard IsNot Nothing
				If flag Then
					RemoveHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
				Me._btnKeyboard = value
				flag = Me._btnKeyboard IsNot Nothing
				If flag Then
					AddHandler Me._btnKeyboard.Click, AddressOf Me.btnKeyboard_Click
				End If
			End Set
		End Property

		' Token: 0x06000DF7 RID: 3575 RVA: 0x000043E8 File Offset: 0x000025E8
		Private Sub frmDMChat_Activated(sender As Object, e As EventArgs)
			Me.txtIn.Focus()
		End Sub

		' Token: 0x06000DF8 RID: 3576 RVA: 0x000A4B58 File Offset: 0x000A2D58
		Private Sub frmSelectDepartment_Group_Load(sender As Object, e As EventArgs)
			Try
				Me.fInitCaption()
				Me.Text = Me.Text + " - " + DateAndTime.Now.ToString("dd/MM/yyyy")
				Me.btnSend.Tag = ""
				Me.sLoadDMChat()
				Me.Timer1.Enabled = True
				Me.txtIn.Focus()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - frmSelectDepartment_Group_Load " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000DF9 RID: 3577 RVA: 0x00002DF4 File Offset: 0x00000FF4
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub

		' Token: 0x06000DFA RID: 3578 RVA: 0x000A4C30 File Offset: 0x000A2E30
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Dim frmKeyBoard As frmKeyBoard = New frmKeyBoard()
			frmKeyBoard.ShowDialog()
			Dim flag As Boolean = frmKeyBoard.pStrEnterText.Trim().Length > 0
			If flag Then
			End If
		End Sub

		' Token: 0x06000DFB RID: 3579 RVA: 0x000A4C64 File Offset: 0x000A2E64
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				Me.Text = Me.mArrStrFrmMess(6)
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06000DFC RID: 3580 RVA: 0x000A4D70 File Offset: 0x000A2F70
		Private Sub sLoadDMChat()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Try
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@nchDOCID"
				array(0).Value = Me.btnSend.Tag.ToString()
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMCHAT_GETDATA", num)
				Dim flag As Boolean = clsConnect IsNot Nothing AndAlso clsConnect.Rows.Count > 0
				If flag Then
					Try
						For Each obj As Object In clsConnect.Rows
							Dim dataRow As DataRow = CType(obj, DataRow)
							Dim text As String = " # " + dataRow("TENMAY").ToString().Trim()
							Dim text2 As String = " [" + dataRow("TENUSER").ToString().Trim() + "]: "
							Dim text3 As String = dataRow("OBJNAME").ToString().Trim()
							Dim txtMess As RichTextBox = Me.txtMess
							txtMess.SelectionColor = Color.Blue
							txtMess.SelectionFont = New Font("Tahoma", 15F, FontStyle.Bold, GraphicsUnit.Pixel, 0)
							txtMess.AppendText(text)
							txtMess.SelectionColor = Color.Brown
							txtMess.SelectionFont = New Font("Verdana", 15F, FontStyle.Bold, GraphicsUnit.Pixel, 0)
							txtMess.AppendText(text2)
							txtMess.SelectionColor = Color.Black
							txtMess.SelectionFont = New Font("Tahoma", 16F, FontStyle.Regular, GraphicsUnit.Pixel, 0)
							txtMess.AppendText(text3 + vbCr)
							Me.btnSend.Tag = RuntimeHelpers.GetObjectValue(dataRow("OBJID"))
						Next
					Finally
						Dim enumerator As IEnumerator
						flag = TypeOf enumerator Is IDisposable
						If flag Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
					Me.txtIn.Focus()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { "Error: " & vbCrLf, Me.Name, " - sLoadDMChat " & vbCrLf, ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06000DFD RID: 3581 RVA: 0x000A501C File Offset: 0x000A321C
		Private Sub btnSend_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.txtIn.Text.Trim().Length = 0
			If Not flag Then
				Dim array As SqlParameter() = New SqlParameter(3) {}
				array(0) = New SqlParameter("@pnvcTENMAY", mdlVariable.gstrMachineName.Trim())
				array(1) = New SqlParameter("@pnvcTENUSER", mdlVariable.gstrUserName.Trim())
				array(2) = New SqlParameter("@pnvcOBJNAME", Me.txtIn.Text.Trim())
				Dim gStrConISDANHMUC As String = mdlVariable.gStrConISDANHMUC
				Dim array2 As SqlParameter() = array
				Dim text As String = "SP_FRMDMCHAT_INSERT"
				Dim flag2 As Boolean = Nothing
				Dim clsConnect As clsConnect = New clsConnect(gStrConISDANHMUC, array2, text, flag2)
				Me.sLoadDMChat()
				Me.txtIn.Text = ""
				Me.txtIn.Focus()
			End If
		End Sub

		' Token: 0x06000DFE RID: 3582 RVA: 0x000043F8 File Offset: 0x000025F8
		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			Me.sLoadDMChat()
			Me.txtIn.Focus()
		End Sub

		' Token: 0x06000DFF RID: 3583 RVA: 0x0000440F File Offset: 0x0000260F
		Private Sub frmDMChat_FormClosing(sender As Object, e As FormClosingEventArgs)
			mdlVariable.gfrmSaleMode.lblAlert.Tag = RuntimeHelpers.GetObjectValue(Me.btnSend.Tag)
			mdlVariable.gfrmSaleMode.tmrAlert.Enabled = True
		End Sub

		' Token: 0x06000E00 RID: 3584 RVA: 0x000A50E8 File Offset: 0x000A32E8
		Private Sub btnKeyboard_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Not Me.CheckIfRunning()
			If flag Then
				Dim process As Process = New Process()
				process = Process.Start(Application.StartupPath + "\MyKey.exe")
				Me.txtIn.Focus()
			End If
		End Sub

		' Token: 0x06000E01 RID: 3585 RVA: 0x0004AE88 File Offset: 0x00049088
		Private Function CheckIfRunning() As Boolean
			Dim processesByName As Process() = Process.GetProcessesByName("MyKey")
			Return processesByName.Length > 0
		End Function

		' Token: 0x040005EF RID: 1519
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x040005F1 RID: 1521
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x040005F2 RID: 1522
		<AccessedThroughProperty("TableLayoutPanel5")>
		Private _TableLayoutPanel5 As TableLayoutPanel

		' Token: 0x040005F3 RID: 1523
		<AccessedThroughProperty("txtMess")>
		Private _txtMess As RichTextBox

		' Token: 0x040005F4 RID: 1524
		<AccessedThroughProperty("txtIn")>
		Private _txtIn As TextBox

		' Token: 0x040005F5 RID: 1525
		<AccessedThroughProperty("btnSend")>
		Private _btnSend As Button

		' Token: 0x040005F6 RID: 1526
		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		' Token: 0x040005F7 RID: 1527
		<AccessedThroughProperty("btnKeyboard")>
		Private _btnKeyboard As Button

		' Token: 0x040005F8 RID: 1528
		Private mArrStrFrmMess As String()
	End Class
End Namespace
