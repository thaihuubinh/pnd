﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports System.Xml
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000069 RID: 105
	<DesignerGenerated()>
	Public Partial Class frmDMNCHU1
		Inherits Form

		' Token: 0x0600212F RID: 8495 RVA: 0x0019B4D4 File Offset: 0x001996D4
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMNCHU1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMNCHU1_Load
			frmDMNCHU1.__ENCList.Add(New WeakReference(Me))
			Me.mstrListOBJID = ""
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd_DMNCHU = False
			Me.mblnIsOK = False
			Me.mblnMultiSelect = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000B5D RID: 2909
		' (get) Token: 0x06002132 RID: 8498 RVA: 0x0019C844 File Offset: 0x0019AA44
		' (set) Token: 0x06002133 RID: 8499 RVA: 0x00006B0B File Offset: 0x00004D0B
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000B5E RID: 2910
		' (get) Token: 0x06002134 RID: 8500 RVA: 0x0019C85C File Offset: 0x0019AA5C
		' (set) Token: 0x06002135 RID: 8501 RVA: 0x0019C874 File Offset: 0x0019AA74
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x17000B5F RID: 2911
		' (get) Token: 0x06002136 RID: 8502 RVA: 0x0019C8E0 File Offset: 0x0019AAE0
		' (set) Token: 0x06002137 RID: 8503 RVA: 0x0019C8F8 File Offset: 0x0019AAF8
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000B60 RID: 2912
		' (get) Token: 0x06002138 RID: 8504 RVA: 0x0019C964 File Offset: 0x0019AB64
		' (set) Token: 0x06002139 RID: 8505 RVA: 0x0019C97C File Offset: 0x0019AB7C
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000B61 RID: 2913
		' (get) Token: 0x0600213A RID: 8506 RVA: 0x0019C9E8 File Offset: 0x0019ABE8
		' (set) Token: 0x0600213B RID: 8507 RVA: 0x0019CA00 File Offset: 0x0019AC00
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000B62 RID: 2914
		' (get) Token: 0x0600213C RID: 8508 RVA: 0x0019CA6C File Offset: 0x0019AC6C
		' (set) Token: 0x0600213D RID: 8509 RVA: 0x0019CA84 File Offset: 0x0019AC84
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000B63 RID: 2915
		' (get) Token: 0x0600213E RID: 8510 RVA: 0x0019CAF0 File Offset: 0x0019ACF0
		' (set) Token: 0x0600213F RID: 8511 RVA: 0x0019CB08 File Offset: 0x0019AD08
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000B64 RID: 2916
		' (get) Token: 0x06002140 RID: 8512 RVA: 0x0019CB74 File Offset: 0x0019AD74
		' (set) Token: 0x06002141 RID: 8513 RVA: 0x0019CB8C File Offset: 0x0019AD8C
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000B65 RID: 2917
		' (get) Token: 0x06002142 RID: 8514 RVA: 0x0019CBF8 File Offset: 0x0019ADF8
		' (set) Token: 0x06002143 RID: 8515 RVA: 0x00006B15 File Offset: 0x00004D15
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x17000B66 RID: 2918
		' (get) Token: 0x06002144 RID: 8516 RVA: 0x0019CC10 File Offset: 0x0019AE10
		' (set) Token: 0x06002145 RID: 8517 RVA: 0x0019CC28 File Offset: 0x0019AE28
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x17000B67 RID: 2919
		' (get) Token: 0x06002146 RID: 8518 RVA: 0x0019CC94 File Offset: 0x0019AE94
		' (set) Token: 0x06002147 RID: 8519 RVA: 0x0019CCAC File Offset: 0x0019AEAC
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x17000B68 RID: 2920
		' (get) Token: 0x06002148 RID: 8520 RVA: 0x0019CD18 File Offset: 0x0019AF18
		' (set) Token: 0x06002149 RID: 8521 RVA: 0x0019CD30 File Offset: 0x0019AF30
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000B69 RID: 2921
		' (get) Token: 0x0600214A RID: 8522 RVA: 0x0019CD9C File Offset: 0x0019AF9C
		' (set) Token: 0x0600214B RID: 8523 RVA: 0x00006B1F File Offset: 0x00004D1F
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x17000B6A RID: 2922
		' (get) Token: 0x0600214C RID: 8524 RVA: 0x0019CDB4 File Offset: 0x0019AFB4
		' (set) Token: 0x0600214D RID: 8525 RVA: 0x0019CDCC File Offset: 0x0019AFCC
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x17000B6B RID: 2923
		' (get) Token: 0x0600214E RID: 8526 RVA: 0x0019CE38 File Offset: 0x0019B038
		' (set) Token: 0x0600214F RID: 8527 RVA: 0x0019CE50 File Offset: 0x0019B050
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x17000B6C RID: 2924
		' (get) Token: 0x06002150 RID: 8528 RVA: 0x0019CEBC File Offset: 0x0019B0BC
		' (set) Token: 0x06002151 RID: 8529 RVA: 0x0019CED4 File Offset: 0x0019B0D4
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000B6D RID: 2925
		' (get) Token: 0x06002152 RID: 8530 RVA: 0x0019CF40 File Offset: 0x0019B140
		' (set) Token: 0x06002153 RID: 8531 RVA: 0x0019CF58 File Offset: 0x0019B158
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000B6E RID: 2926
		' (get) Token: 0x06002154 RID: 8532 RVA: 0x0019CFC4 File Offset: 0x0019B1C4
		' (set) Token: 0x06002155 RID: 8533 RVA: 0x0019CFDC File Offset: 0x0019B1DC
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000B6F RID: 2927
		' (get) Token: 0x06002156 RID: 8534 RVA: 0x0019D048 File Offset: 0x0019B248
		' (set) Token: 0x06002157 RID: 8535 RVA: 0x0019D060 File Offset: 0x0019B260
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x17000B70 RID: 2928
		' (get) Token: 0x06002158 RID: 8536 RVA: 0x0019D0CC File Offset: 0x0019B2CC
		' (set) Token: 0x06002159 RID: 8537 RVA: 0x00006B29 File Offset: 0x00004D29
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000B71 RID: 2929
		' (get) Token: 0x0600215A RID: 8538 RVA: 0x0019D0E4 File Offset: 0x0019B2E4
		' (set) Token: 0x0600215B RID: 8539 RVA: 0x0019D0FC File Offset: 0x0019B2FC
		Friend Overridable Property CheckBox1 As CheckBox
			<DebuggerNonUserCode()>
			Get
				Return Me._CheckBox1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim flag As Boolean = Me._CheckBox1 IsNot Nothing
				If flag Then
					RemoveHandler Me._CheckBox1.CheckedChanged, AddressOf Me.CheckBox1_CheckedChanged
				End If
				Me._CheckBox1 = value
				flag = Me._CheckBox1 IsNot Nothing
				If flag Then
					AddHandler Me._CheckBox1.CheckedChanged, AddressOf Me.CheckBox1_CheckedChanged
				End If
			End Set
		End Property

		' Token: 0x17000B72 RID: 2930
		' (get) Token: 0x0600215C RID: 8540 RVA: 0x0019D168 File Offset: 0x0019B368
		' (set) Token: 0x0600215D RID: 8541 RVA: 0x0019D180 File Offset: 0x0019B380
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000B73 RID: 2931
		' (get) Token: 0x0600215E RID: 8542 RVA: 0x0019D1EC File Offset: 0x0019B3EC
		' (set) Token: 0x0600215F RID: 8543 RVA: 0x00006B33 File Offset: 0x00004D33
		Public Property pblnMultiSelect As Boolean
			Get
				Return Me.mblnMultiSelect
			End Get
			Set(value As Boolean)
				Me.mblnMultiSelect = value
			End Set
		End Property

		' Token: 0x17000B74 RID: 2932
		' (get) Token: 0x06002160 RID: 8544 RVA: 0x0019D204 File Offset: 0x0019B404
		' (set) Token: 0x06002161 RID: 8545 RVA: 0x00006B3E File Offset: 0x00004D3E
		Public Property pblnIsOK As Boolean
			Get
				Return Me.mblnIsOK
			End Get
			Set(value As Boolean)
				Me.mblnIsOK = value
			End Set
		End Property

		' Token: 0x17000B75 RID: 2933
		' (get) Token: 0x06002162 RID: 8546 RVA: 0x0019D21C File Offset: 0x0019B41C
		' (set) Token: 0x06002163 RID: 8547 RVA: 0x00006B49 File Offset: 0x00004D49
		Public Property pstrListOBJID As String
			Get
				Return Me.mstrListOBJID
			End Get
			Set(value As String)
				Me.mstrListOBJID = value
			End Set
		End Property

		' Token: 0x17000B76 RID: 2934
		' (get) Token: 0x06002164 RID: 8548 RVA: 0x0019D234 File Offset: 0x0019B434
		' (set) Token: 0x06002165 RID: 8549 RVA: 0x00006B54 File Offset: 0x00004D54
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x17000B77 RID: 2935
		' (get) Token: 0x06002166 RID: 8550 RVA: 0x0019D24C File Offset: 0x0019B44C
		' (set) Token: 0x06002167 RID: 8551 RVA: 0x00006B5F File Offset: 0x00004D5F
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000B78 RID: 2936
		' (get) Token: 0x06002168 RID: 8552 RVA: 0x0019D264 File Offset: 0x0019B464
		' (set) Token: 0x06002169 RID: 8553 RVA: 0x00006B6A File Offset: 0x00004D6A
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x0600216A RID: 8554 RVA: 0x0019D27C File Offset: 0x0019B47C
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
				Me.mStrOBJNAME = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJNAME").Value)
				Dim flag As Boolean = Me.mblnMultiSelect
				If flag Then
					Try
						For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
							Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
							Dim flag2 As Boolean = Conversions.ToBoolean(dataGridViewRow.Cells("chkSelect").Value)
							If flag2 Then
								Me.mstrListOBJID = Me.mstrListOBJID + dataGridViewRow.Cells("OBJID").Value.ToString().Trim() + ";"
							End If
						Next
					Finally
						Dim enumerator As IEnumerator
						Dim flag2 As Boolean = TypeOf enumerator Is IDisposable
						If flag2 Then
							TryCast(enumerator, IDisposable).Dispose()
						End If
					End Try
				End If
				Me.pblnIsOK = True
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600216B RID: 8555 RVA: 0x0019D458 File Offset: 0x0019B658
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600216C RID: 8556 RVA: 0x0019D528 File Offset: 0x0019B728
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600216D RID: 8557 RVA: 0x0019D618 File Offset: 0x0019B818
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600216E RID: 8558 RVA: 0x0019D6FC File Offset: 0x0019B8FC
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600216F RID: 8559 RVA: 0x0019D7C0 File Offset: 0x0019B9C0
		Private Sub frmDMNCHU1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMNCHU1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002170 RID: 8560 RVA: 0x0019D858 File Offset: 0x0019BA58
		Private Sub frmDMNCHU1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				Me.sGetPara_From_SetparaXML()
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
				Me.CheckBox1.Visible = Me.mblnMultiSelect
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMNCHU1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002171 RID: 8561 RVA: 0x0019D978 File Offset: 0x0019BB78
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002172 RID: 8562 RVA: 0x0019DA80 File Offset: 0x0019BC80
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.pblnIsOK = False
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002173 RID: 8563 RVA: 0x0019DB20 File Offset: 0x0019BD20
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMNCHU As frmDMNCHU2 = New frmDMNCHU2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMNCHU.pbytFromStatus = 1
				Dim flag As Boolean = Me.mblnAutoAdd_DMNCHU
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNCHU_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMNCHU.txtOBJID.Text = Strings.Right("0" + array(0).Value.ToString(), 2)
						frmDMNCHU.txtOBJID.[ReadOnly] = True
						frmDMNCHU.txtOBJID.BackColor = frmDMNCHU.txtColor.BackColor
					End If
				End If
				frmDMNCHU.ShowDialog()
				flag = frmDMNCHU.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMNCHU.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMNCHU.Dispose()
			End Try
		End Sub

		' Token: 0x06002174 RID: 8564 RVA: 0x0019DD58 File Offset: 0x0019BF58
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMNCHU As frmDMNCHU2 = New frmDMNCHU2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMNCHU2 As frmDMNCHU2 = frmDMNCHU
				frmDMNCHU2.pbytFromStatus = 2
				frmDMNCHU2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMNCHU2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMNCHU2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMNCHU2.TxtDISCOUNT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("GIAMGIA").Value, ""))
				Dim flag As Boolean = Me.mblnAutoAdd_DMNCHU
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNCHU_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMNCHU.txtOBJID.Text = Strings.Right("0" + array(0).Value.ToString(), 2)
						frmDMNCHU.txtOBJID.[ReadOnly] = True
						frmDMNCHU.txtOBJID.BackColor = frmDMNCHU.txtColor.BackColor
					End If
				End If
				frmDMNCHU.ShowDialog()
				flag = frmDMNCHU.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMNCHU.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMNCHU.Dispose()
			End Try
		End Sub

		' Token: 0x06002175 RID: 8565 RVA: 0x0019E084 File Offset: 0x0019C284
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMNCHU As frmDMNCHU2 = New frmDMNCHU2()
			Try
				Dim frmDMNCHU2 As frmDMNCHU2 = frmDMNCHU
				frmDMNCHU2.pbytFromStatus = 3
				frmDMNCHU2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMNCHU2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMNCHU2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMNCHU2.TxtDISCOUNT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("GIAMGIA").Value, ""))
				frmDMNCHU.ShowDialog()
				Dim flag As Boolean = frmDMNCHU.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMNCHU.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMNCHU.Dispose()
			End Try
		End Sub

		' Token: 0x06002176 RID: 8566 RVA: 0x0019E2CC File Offset: 0x0019C4CC
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMNCHU As frmDMNCHU2 = New frmDMNCHU2()
			Try
				Dim frmDMNCHU2 As frmDMNCHU2 = frmDMNCHU
				frmDMNCHU2.pbytFromStatus = 4
				frmDMNCHU2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMNCHU2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMNCHU2.txtREMARK.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMNCHU2.TxtDISCOUNT.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("GIAMGIA").Value, ""))
				frmDMNCHU.ShowDialog()
				Dim flag As Boolean = frmDMNCHU.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMNCHU.Dispose()
			End Try
		End Sub

		' Token: 0x06002177 RID: 8567 RVA: 0x0019E4F0 File Offset: 0x0019C6F0
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMNCHU As frmDMNCHU2 = New frmDMNCHU2()
			Try
				frmDMNCHU.pbytFromStatus = 6
				frmDMNCHU.ShowDialog()
				Dim flag As Boolean = frmDMNCHU.pbytSuccess = 0
				If flag Then
					frmDMNCHU.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMNCHU.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMNCHU.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMNCHU.Dispose()
			End Try
		End Sub

		' Token: 0x06002178 RID: 8568 RVA: 0x0019E6E4 File Offset: 0x0019C8E4
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMNCHU As frmDMNCHU2 = New frmDMNCHU2()
			Try
				Me.btnFindNext.Visible = False
				frmDMNCHU.pbytFromStatus = 5
				frmDMNCHU.ShowDialog()
				Dim flag As Boolean = frmDMNCHU.pbytSuccess = 0
				If Not flag Then
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMNCHU.pStrFilter
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMNCHU.Dispose()
			End Try
		End Sub

		' Token: 0x06002179 RID: 8569 RVA: 0x0019E7EC File Offset: 0x0019C9EC
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMNCHU As frmDMNCHU2 = New frmDMNCHU2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMNCHU.Dispose()
			End Try
		End Sub

		' Token: 0x0600217A RID: 8570 RVA: 0x0019E8B4 File Offset: 0x0019CAB4
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x0600217B RID: 8571 RVA: 0x0019EA30 File Offset: 0x0019CC30
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fPrintDMNCHU()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600217C RID: 8572 RVA: 0x0019EAC8 File Offset: 0x0019CCC8
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.btnSelect.Visible AndAlso Not Me.mblnMultiSelect
				If flag Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600217D RID: 8573 RVA: 0x0019EB88 File Offset: 0x0019CD88
		Private Sub sGetPara_From_SetparaXML()
			Dim xmlDocument As XmlDocument = New XmlDocument()
			Try
				xmlDocument.Load(mdlVariable.gStrPathApp + "\CONFIG\SetPara.xml")
				Dim xmlNodeList As XmlNodeList = xmlDocument.SelectNodes("/Setpara/Main/DMNCHU")
				Dim flag As Boolean = xmlNodeList.Count > 0
				If flag Then
					Dim xmlNode As XmlNode = xmlNodeList.Item(0)
					Me.mblnAutoAdd_DMNCHU = xmlNode.InnerText.Trim().ToUpper().Equals("TRUE")
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetPara_From_SetparaXML ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x0600217E RID: 8574 RVA: 0x0019EC84 File Offset: 0x0019CE84
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJID").[ReadOnly] = True
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 150
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").[ReadOnly] = True
				dgvData.Columns("GIAMGIA").HeaderText = Strings.Trim(Me.mArrStrFrmMess(21))
				dgvData.Columns("GIAMGIA").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomRight
				dgvData.Columns("GIAMGIA").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("GIAMGIA").[ReadOnly] = True
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("REMARK").Width = Me.Width - 360 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").[ReadOnly] = True
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x0600217F RID: 8575 RVA: 0x0019EF9C File Offset: 0x0019D19C
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002180 RID: 8576 RVA: 0x0019F11C File Offset: 0x0019D31C
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnintDEC"
				array(0).Value = mdlVariable.gbytDECNUMPER
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMNCHU_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					flag = Me.mblnMultiSelect
					If flag Then
						Dim dataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn = New DataGridViewCheckBoxColumn()
						dataGridViewCheckBoxColumn.[ReadOnly] = False
						dataGridViewCheckBoxColumn.Name = "chkSelect"
						dataGridViewCheckBoxColumn.HeaderText = ""
						Me.dgvData.Columns.Insert(0, dataGridViewCheckBoxColumn)
					End If
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
				sqlCommand.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06002181 RID: 8577 RVA: 0x0019F2A8 File Offset: 0x0019D4A8
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002182 RID: 8578 RVA: 0x0019F3F8 File Offset: 0x0019D5F8
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06002183 RID: 8579 RVA: 0x0019F504 File Offset: 0x0019D704
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06002184 RID: 8580 RVA: 0x0019F5B0 File Offset: 0x0019D7B0
		Private Function fPrintDMNCHU() As Byte
			Dim rptDMNCHU As rptDMNCHU = New rptDMNCHU()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMNCHU, "")
				Dim text As String = "2060100000"
				mdlReport.gsSetOfficeReport(rptDMNCHU, text)
				mdlReport.gsSetFontReport(rptDMNCHU)
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMNCHU")
				rptDMNCHU.SetDataSource(clsConnect)
				rptDMNCHU.DataDefinition.FormulaFields("fOBJID").Text = "{dtReport.OBJID}"
				rptDMNCHU.DataDefinition.FormulaFields("fOBJNAME").Text = "{dtReport.OBJNAME}"
				rptDMNCHU.DataDefinition.FormulaFields("fREMARK").Text = "{dtReport.REMARK}"
				rptDMNCHU.DataDefinition.FormulaFields("fDISCOUNT").Text = "{dtReport.DISCOUNT}"
				mdlReport.gsSetTextReport(rptDMNCHU, "RPTDMNCHU")
				MyProject.Forms.frmReport.pSource = rptDMNCHU
				MyProject.Forms.frmReport.MaximizeBox = True
				MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
				Dim textObject As TextObject = CType(rptDMNCHU.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
				MyProject.Forms.frmReport.Text = textObject.Text
				rptDMNCHU.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
				rptDMNCHU.PrintOptions.PaperSize = PaperSize.PaperA4
				MyProject.Forms.frmReport.ShowDialog()
				MyProject.Forms.frmReport.pSource = Nothing
				clsConnect.Dispose()
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMNCHU " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMNCHU.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06002185 RID: 8581 RVA: 0x0019F7E4 File Offset: 0x0019D9E4
		Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.CheckBox1.Checked
			If flag Then
				Try
					For Each obj As Object In CType(Me.dgvData.Rows, IEnumerable)
						Dim dataGridViewRow As DataGridViewRow = CType(obj, DataGridViewRow)
						dataGridViewRow.Cells("chkSelect").Value = True
					Next
				Finally
					Dim enumerator As IEnumerator
					flag = TypeOf enumerator Is IDisposable
					If flag Then
						TryCast(enumerator, IDisposable).Dispose()
					End If
				End Try
			Else
				Try
					For Each obj2 As Object In CType(Me.dgvData.Rows, IEnumerable)
						Dim dataGridViewRow2 As DataGridViewRow = CType(obj2, DataGridViewRow)
						dataGridViewRow2.Cells("chkSelect").Value = False
					Next
				Finally
					Dim enumerator2 As IEnumerator
					flag = TypeOf enumerator2 Is IDisposable
					If flag Then
						TryCast(enumerator2, IDisposable).Dispose()
					End If
				End Try
			End If
		End Sub

		' Token: 0x04000D8D RID: 3469
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000D8F RID: 3471
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000D90 RID: 3472
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000D91 RID: 3473
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000D92 RID: 3474
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000D93 RID: 3475
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000D94 RID: 3476
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000D95 RID: 3477
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000D96 RID: 3478
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000D97 RID: 3479
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000D98 RID: 3480
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000D99 RID: 3481
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000D9A RID: 3482
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000D9B RID: 3483
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000D9C RID: 3484
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000D9D RID: 3485
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000D9E RID: 3486
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000D9F RID: 3487
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000DA0 RID: 3488
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000DA1 RID: 3489
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000DA2 RID: 3490
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000DA3 RID: 3491
		<AccessedThroughProperty("CheckBox1")>
		Private _CheckBox1 As CheckBox

		' Token: 0x04000DA4 RID: 3492
		Private mArrStrFrmMess As String()

		' Token: 0x04000DA5 RID: 3493
		Private mStrOBJID As String

		' Token: 0x04000DA6 RID: 3494
		Private mStrOBJNAME As String

		' Token: 0x04000DA7 RID: 3495
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000DA8 RID: 3496
		Private mstrListOBJID As String

		' Token: 0x04000DA9 RID: 3497
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000DAA RID: 3498
		Private marrDrFind As DataRow()

		' Token: 0x04000DAB RID: 3499
		Private mintFindLastPos As Integer

		' Token: 0x04000DAC RID: 3500
		Private mblnAutoAdd_DMNCHU As Boolean

		' Token: 0x04000DAD RID: 3501
		Private mblnIsOK As Boolean

		' Token: 0x04000DAE RID: 3502
		Private mblnMultiSelect As Boolean
	End Class
End Namespace
