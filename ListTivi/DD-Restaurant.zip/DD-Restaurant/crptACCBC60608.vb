﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports CrystalDecisions.CrystalReports.Engine

Namespace prjIS_SalesPOS
	' Token: 0x02000119 RID: 281
	Public Class crptACCBC60608
		Inherits ReportClass

		' Token: 0x06005744 RID: 22340 RVA: 0x0000EF60 File Offset: 0x0000D160
		Public Sub New()
			crptACCBC60608.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17001F74 RID: 8052
		' (get) Token: 0x06005745 RID: 22341 RVA: 0x004DAE88 File Offset: 0x004D9088
		' (set) Token: 0x06005746 RID: 22342 RVA: 0x00002A72 File Offset: 0x00000C72
		Public Overrides Property ResourceName As String
			Get
				Return "crptACCBC60608.rpt"
			End Get
			Set(value As String)
			End Set
		End Property

		' Token: 0x17001F75 RID: 8053
		' (get) Token: 0x06005747 RID: 22343 RVA: 0x004DA738 File Offset: 0x004D8938
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section1 As Section
			Get
				Return Me.ReportDefinition.Sections(0)
			End Get
		End Property

		' Token: 0x17001F76 RID: 8054
		' (get) Token: 0x06005748 RID: 22344 RVA: 0x004DA75C File Offset: 0x004D895C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section2 As Section
			Get
				Return Me.ReportDefinition.Sections(1)
			End Get
		End Property

		' Token: 0x17001F77 RID: 8055
		' (get) Token: 0x06005749 RID: 22345 RVA: 0x004DA780 File Offset: 0x004D8980
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupHeaderSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(2)
			End Get
		End Property

		' Token: 0x17001F78 RID: 8056
		' (get) Token: 0x0600574A RID: 22346 RVA: 0x004DA7A4 File Offset: 0x004D89A4
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Sec As Section
			Get
				Return Me.ReportDefinition.Sections(3)
			End Get
		End Property

		' Token: 0x17001F79 RID: 8057
		' (get) Token: 0x0600574B RID: 22347 RVA: 0x004DA7C8 File Offset: 0x004D89C8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(4)
			End Get
		End Property

		' Token: 0x17001F7A RID: 8058
		' (get) Token: 0x0600574C RID: 22348 RVA: 0x004DA7EC File Offset: 0x004D89EC
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(5)
			End Get
		End Property

		' Token: 0x17001F7B RID: 8059
		' (get) Token: 0x0600574D RID: 22349 RVA: 0x004DA810 File Offset: 0x004D8A10
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection3 As Section
			Get
				Return Me.ReportDefinition.Sections(6)
			End Get
		End Property

		' Token: 0x17001F7C RID: 8060
		' (get) Token: 0x0600574E RID: 22350 RVA: 0x004DA834 File Offset: 0x004D8A34
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property GroupFooterSection4 As Section
			Get
				Return Me.ReportDefinition.Sections(7)
			End Get
		End Property

		' Token: 0x17001F7D RID: 8061
		' (get) Token: 0x0600574F RID: 22351 RVA: 0x004DA858 File Offset: 0x004D8A58
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection5 As Section
			Get
				Return Me.ReportDefinition.Sections(8)
			End Get
		End Property

		' Token: 0x17001F7E RID: 8062
		' (get) Token: 0x06005750 RID: 22352 RVA: 0x004DA87C File Offset: 0x004D8A7C
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property GroupFooterSection6 As Section
			Get
				Return Me.ReportDefinition.Sections(9)
			End Get
		End Property

		' Token: 0x17001F7F RID: 8063
		' (get) Token: 0x06005751 RID: 22353 RVA: 0x004DA8A0 File Offset: 0x004D8AA0
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property Section4 As Section
			Get
				Return Me.ReportDefinition.Sections(10)
			End Get
		End Property

		' Token: 0x17001F80 RID: 8064
		' (get) Token: 0x06005752 RID: 22354 RVA: 0x004DA8C4 File Offset: 0x004D8AC4
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportFooterSection1 As Section
			Get
				Return Me.ReportDefinition.Sections(11)
			End Get
		End Property

		' Token: 0x17001F81 RID: 8065
		' (get) Token: 0x06005753 RID: 22355 RVA: 0x004DA8E8 File Offset: 0x004D8AE8
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportFooterSection2 As Section
			Get
				Return Me.ReportDefinition.Sections(12)
			End Get
		End Property

		' Token: 0x17001F82 RID: 8066
		' (get) Token: 0x06005754 RID: 22356 RVA: 0x004DA90C File Offset: 0x004D8B0C
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportFooterSection3 As Section
			Get
				Return Me.ReportDefinition.Sections(13)
			End Get
		End Property

		' Token: 0x17001F83 RID: 8067
		' (get) Token: 0x06005755 RID: 22357 RVA: 0x004DA930 File Offset: 0x004D8B30
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public ReadOnly Property ReportFooterSection4 As Section
			Get
				Return Me.ReportDefinition.Sections(14)
			End Get
		End Property

		' Token: 0x17001F84 RID: 8068
		' (get) Token: 0x06005756 RID: 22358 RVA: 0x004DA954 File Offset: 0x004D8B54
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property ReportFooterSection5 As Section
			Get
				Return Me.ReportDefinition.Sections(15)
			End Get
		End Property

		' Token: 0x17001F85 RID: 8069
		' (get) Token: 0x06005757 RID: 22359 RVA: 0x004DA978 File Offset: 0x004D8B78
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public ReadOnly Property Section5 As Section
			Get
				Return Me.ReportDefinition.Sections(16)
			End Get
		End Property

		' Token: 0x04002711 RID: 10001
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
