﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000059 RID: 89
	<DesignerGenerated()>
	Public Partial Class frmDMLDTHU1
		Inherits Form

		' Token: 0x06001ACB RID: 6859 RVA: 0x0014C224 File Offset: 0x0014A424
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMLDTHU1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMLDTHU1_Load
			frmDMLDTHU1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.mblnAutoAdd = False
			Me.InitializeComponent()
		End Sub

		' Token: 0x17000932 RID: 2354
		' (get) Token: 0x06001ACE RID: 6862 RVA: 0x0014D4B0 File Offset: 0x0014B6B0
		' (set) Token: 0x06001ACF RID: 6863 RVA: 0x00005D91 File Offset: 0x00003F91
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x17000933 RID: 2355
		' (get) Token: 0x06001AD0 RID: 6864 RVA: 0x0014D4C8 File Offset: 0x0014B6C8
		' (set) Token: 0x06001AD1 RID: 6865 RVA: 0x0014D4E0 File Offset: 0x0014B6E0
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x17000934 RID: 2356
		' (get) Token: 0x06001AD2 RID: 6866 RVA: 0x0014D54C File Offset: 0x0014B74C
		' (set) Token: 0x06001AD3 RID: 6867 RVA: 0x0014D564 File Offset: 0x0014B764
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x17000935 RID: 2357
		' (get) Token: 0x06001AD4 RID: 6868 RVA: 0x0014D5D0 File Offset: 0x0014B7D0
		' (set) Token: 0x06001AD5 RID: 6869 RVA: 0x0014D5E8 File Offset: 0x0014B7E8
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000936 RID: 2358
		' (get) Token: 0x06001AD6 RID: 6870 RVA: 0x0014D654 File Offset: 0x0014B854
		' (set) Token: 0x06001AD7 RID: 6871 RVA: 0x0014D66C File Offset: 0x0014B86C
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x17000937 RID: 2359
		' (get) Token: 0x06001AD8 RID: 6872 RVA: 0x0014D6D8 File Offset: 0x0014B8D8
		' (set) Token: 0x06001AD9 RID: 6873 RVA: 0x0014D6F0 File Offset: 0x0014B8F0
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x17000938 RID: 2360
		' (get) Token: 0x06001ADA RID: 6874 RVA: 0x0014D75C File Offset: 0x0014B95C
		' (set) Token: 0x06001ADB RID: 6875 RVA: 0x0014D774 File Offset: 0x0014B974
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x17000939 RID: 2361
		' (get) Token: 0x06001ADC RID: 6876 RVA: 0x0014D7E0 File Offset: 0x0014B9E0
		' (set) Token: 0x06001ADD RID: 6877 RVA: 0x00005D9B File Offset: 0x00003F9B
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x1700093A RID: 2362
		' (get) Token: 0x06001ADE RID: 6878 RVA: 0x0014D7F8 File Offset: 0x0014B9F8
		' (set) Token: 0x06001ADF RID: 6879 RVA: 0x0014D810 File Offset: 0x0014BA10
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x1700093B RID: 2363
		' (get) Token: 0x06001AE0 RID: 6880 RVA: 0x0014D87C File Offset: 0x0014BA7C
		' (set) Token: 0x06001AE1 RID: 6881 RVA: 0x0014D894 File Offset: 0x0014BA94
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x1700093C RID: 2364
		' (get) Token: 0x06001AE2 RID: 6882 RVA: 0x0014D900 File Offset: 0x0014BB00
		' (set) Token: 0x06001AE3 RID: 6883 RVA: 0x0014D918 File Offset: 0x0014BB18
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x1700093D RID: 2365
		' (get) Token: 0x06001AE4 RID: 6884 RVA: 0x0014D984 File Offset: 0x0014BB84
		' (set) Token: 0x06001AE5 RID: 6885 RVA: 0x00005DA5 File Offset: 0x00003FA5
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x1700093E RID: 2366
		' (get) Token: 0x06001AE6 RID: 6886 RVA: 0x0014D99C File Offset: 0x0014BB9C
		' (set) Token: 0x06001AE7 RID: 6887 RVA: 0x0014D9B4 File Offset: 0x0014BBB4
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x1700093F RID: 2367
		' (get) Token: 0x06001AE8 RID: 6888 RVA: 0x0014DA20 File Offset: 0x0014BC20
		' (set) Token: 0x06001AE9 RID: 6889 RVA: 0x0014DA38 File Offset: 0x0014BC38
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x17000940 RID: 2368
		' (get) Token: 0x06001AEA RID: 6890 RVA: 0x0014DAA4 File Offset: 0x0014BCA4
		' (set) Token: 0x06001AEB RID: 6891 RVA: 0x0014DABC File Offset: 0x0014BCBC
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x17000941 RID: 2369
		' (get) Token: 0x06001AEC RID: 6892 RVA: 0x0014DB28 File Offset: 0x0014BD28
		' (set) Token: 0x06001AED RID: 6893 RVA: 0x0014DB40 File Offset: 0x0014BD40
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x17000942 RID: 2370
		' (get) Token: 0x06001AEE RID: 6894 RVA: 0x0014DBAC File Offset: 0x0014BDAC
		' (set) Token: 0x06001AEF RID: 6895 RVA: 0x0014DBC4 File Offset: 0x0014BDC4
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x17000943 RID: 2371
		' (get) Token: 0x06001AF0 RID: 6896 RVA: 0x0014DC30 File Offset: 0x0014BE30
		' (set) Token: 0x06001AF1 RID: 6897 RVA: 0x0014DC48 File Offset: 0x0014BE48
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x17000944 RID: 2372
		' (get) Token: 0x06001AF2 RID: 6898 RVA: 0x0014DCB4 File Offset: 0x0014BEB4
		' (set) Token: 0x06001AF3 RID: 6899 RVA: 0x0014DCCC File Offset: 0x0014BECC
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x17000945 RID: 2373
		' (get) Token: 0x06001AF4 RID: 6900 RVA: 0x0014DD38 File Offset: 0x0014BF38
		' (set) Token: 0x06001AF5 RID: 6901 RVA: 0x00005DAF File Offset: 0x00003FAF
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000946 RID: 2374
		' (get) Token: 0x06001AF6 RID: 6902 RVA: 0x0014DD50 File Offset: 0x0014BF50
		' (set) Token: 0x06001AF7 RID: 6903 RVA: 0x0014DD68 File Offset: 0x0014BF68
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000947 RID: 2375
		' (get) Token: 0x06001AF8 RID: 6904 RVA: 0x0014DDD4 File Offset: 0x0014BFD4
		' (set) Token: 0x06001AF9 RID: 6905 RVA: 0x00005DB9 File Offset: 0x00003FB9
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x17000948 RID: 2376
		' (get) Token: 0x06001AFA RID: 6906 RVA: 0x0014DDEC File Offset: 0x0014BFEC
		' (set) Token: 0x06001AFB RID: 6907 RVA: 0x00005DC4 File Offset: 0x00003FC4
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000949 RID: 2377
		' (get) Token: 0x06001AFC RID: 6908 RVA: 0x0014DE04 File Offset: 0x0014C004
		' (set) Token: 0x06001AFD RID: 6909 RVA: 0x00005DCF File Offset: 0x00003FCF
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06001AFE RID: 6910 RVA: 0x0014DE1C File Offset: 0x0014C01C
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Me.mStrOBJID = Conversions.ToString(Me.dgvData.CurrentRow.Cells("OBJID").Value)
				Me.mStrOBJNAME = Me.dgvData.CurrentRow.Cells("OBJNAME").Value.ToString().Trim() + "  " + Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value.ToString().Trim()
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001AFF RID: 6911 RVA: 0x0014DF40 File Offset: 0x0014C140
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B00 RID: 6912 RVA: 0x0014E010 File Offset: 0x0014C210
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B01 RID: 6913 RVA: 0x0014E100 File Offset: 0x0014C300
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B02 RID: 6914 RVA: 0x0014E1E4 File Offset: 0x0014C3E4
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B03 RID: 6915 RVA: 0x0014E2A8 File Offset: 0x0014C4A8
		Private Sub frmDMLDTHU1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLDTHU1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B04 RID: 6916 RVA: 0x0014E340 File Offset: 0x0014C540
		Private Sub frmDMLDTHU1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMLDTHU1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B05 RID: 6917 RVA: 0x0014E448 File Offset: 0x0014C648
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B06 RID: 6918 RVA: 0x0014E550 File Offset: 0x0014C750
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B07 RID: 6919 RVA: 0x0014E5E8 File Offset: 0x0014C7E8
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMLDTHU As frmDMLDTHU2 = New frmDMLDTHU2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMLDTHU.pbytFromStatus = 1
				Dim flag As Boolean = Me.mblnAutoAdd
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLDTHU_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMLDTHU.txtOBJID.Text = Strings.Right("0" + array(0).Value.ToString(), 2)
						frmDMLDTHU.txtOBJID.[ReadOnly] = True
						frmDMLDTHU.txtOBJID.BackColor = frmDMLDTHU.txtColor.BackColor
					End If
				End If
				frmDMLDTHU.ShowDialog()
				flag = frmDMLDTHU.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMLDTHU.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMLDTHU.Dispose()
			End Try
		End Sub

		' Token: 0x06001B08 RID: 6920 RVA: 0x0014E820 File Offset: 0x0014CA20
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMLDTHU As frmDMLDTHU2 = New frmDMLDTHU2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMLDTHU2 As frmDMLDTHU2 = frmDMLDTHU
				frmDMLDTHU2.pbytFromStatus = 2
				frmDMLDTHU2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMLDTHU2.txtsubOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
				frmDMLDTHU2.txtOBJID.Text = ""
				Dim flag As Boolean = Me.mblnAutoAdd
				If flag Then
					array(0) = sqlCommand.CreateParameter()
					array(0).ParameterName = "@pintResult"
					array(0).Direction = ParameterDirection.ReturnValue
					Dim flag2 As Boolean
					clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLDTHU_GET_MAX_OBJID", flag2)
					flag = flag2
					If flag Then
						frmDMLDTHU.txtOBJID.Text = Strings.Right("0" + array(0).Value.ToString(), 2)
						frmDMLDTHU.txtOBJID.[ReadOnly] = True
						frmDMLDTHU.txtOBJID.BackColor = frmDMLDTHU.txtColor.BackColor
					End If
				End If
				frmDMLDTHU.ShowDialog()
				flag = frmDMLDTHU.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMLDTHU.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMLDTHU.Dispose()
			End Try
		End Sub

		' Token: 0x06001B09 RID: 6921 RVA: 0x0014EAE8 File Offset: 0x0014CCE8
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMLDTHU As frmDMLDTHU2 = New frmDMLDTHU2()
			Dim flag As Boolean = False
			Try
				Dim flag2 As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag2 Then
					flag = True
				End If
				Dim frmDMLDTHU2 As frmDMLDTHU2 = frmDMLDTHU
				frmDMLDTHU2.pbytFromStatus = 3
				frmDMLDTHU2.pblnFix = flag
				frmDMLDTHU2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMLDTHU2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMLDTHU2.txtsubOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
				flag2 = flag
				If flag2 Then
					frmDMLDTHU2.txtOBJNAME.[ReadOnly] = True
					frmDMLDTHU2.txtOBJNAME.BackColor = frmDMLDTHU2.txtColor.BackColor
				End If
				frmDMLDTHU.ShowDialog()
				flag2 = frmDMLDTHU.pbytSuccess = 0
				If Not flag2 Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag2 = b = 0
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag2 = b <> 0
					If flag2 Then
						b = Me.fInitGrid()
					End If
					flag2 = b <> 0
					If flag2 Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMLDTHU.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMLDTHU.Dispose()
			End Try
		End Sub

		' Token: 0x06001B0A RID: 6922 RVA: 0x0014ED64 File Offset: 0x0014CF64
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMLDTHU As frmDMLDTHU2 = New frmDMLDTHU2()
			Try
				Dim flag As Boolean = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("FIXED").Value)
				If flag Then
					Interaction.MsgBox(Me.mArrStrFrmMess(23), MsgBoxStyle.Critical, Nothing)
					frmDMLDTHU.Dispose()
				Else
					Dim frmDMLDTHU2 As frmDMLDTHU2 = frmDMLDTHU
					frmDMLDTHU2.pbytFromStatus = 4
					frmDMLDTHU2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMLDTHU2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMLDTHU2.txtsubOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("SUBOBJNAME").Value, ""))
					frmDMLDTHU.ShowDialog()
					flag = frmDMLDTHU.pbytSuccess = 0
					If Not flag Then
						Dim b As Byte = Me.fGetData_4Grid()
						flag = b = 0
						If flag Then
							Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
						End If
						flag = b <> 0
						If flag Then
							b = Me.fInitGrid()
						End If
						flag = b <> 0
						If flag Then
							Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMLDTHU.Dispose()
			End Try
		End Sub

		' Token: 0x06001B0B RID: 6923 RVA: 0x0014EF98 File Offset: 0x0014D198
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMLDTHU As frmDMLDTHU2 = New frmDMLDTHU2()
			Try
				frmDMLDTHU.pbytFromStatus = 6
				frmDMLDTHU.ShowDialog()
				Dim flag As Boolean = frmDMLDTHU.pbytSuccess = 0
				If flag Then
					frmDMLDTHU.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMLDTHU.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(24), MsgBoxStyle.Critical, Nothing)
						frmDMLDTHU.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMLDTHU.Dispose()
			End Try
		End Sub

		' Token: 0x06001B0C RID: 6924 RVA: 0x0014F18C File Offset: 0x0014D38C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMLDTHU As frmDMLDTHU2 = New frmDMLDTHU2()
			Try
				Me.btnFindNext.Visible = False
				frmDMLDTHU.pbytFromStatus = 5
				frmDMLDTHU.ShowDialog()
				Dim flag As Boolean = frmDMLDTHU.pbytSuccess = 0
				If Not flag Then
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMLDTHU.pStrFilter
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMLDTHU.Dispose()
			End Try
		End Sub

		' Token: 0x06001B0D RID: 6925 RVA: 0x0014F294 File Offset: 0x0014D494
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMDVT As frmDMDVT2 = New frmDMDVT2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMDVT.Dispose()
			End Try
		End Sub

		' Token: 0x06001B0E RID: 6926 RVA: 0x0014F35C File Offset: 0x0014D55C
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x06001B0F RID: 6927 RVA: 0x0014F4D8 File Offset: 0x0014D6D8
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fPrintDMLDTHU()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B10 RID: 6928 RVA: 0x0014F570 File Offset: 0x0014D770
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B11 RID: 6929 RVA: 0x0014F620 File Offset: 0x0014D820
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 160
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = 200
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("SUBOBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("SUBOBJNAME").Width = Me.Width - Me.grpControl.Width - 370
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("SUBOBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("FIXED").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001B12 RID: 6930 RVA: 0x0014F88C File Offset: 0x0014DA8C
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001B13 RID: 6931 RVA: 0x0014FA0C File Offset: 0x0014DC0C
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLDTHU_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001B14 RID: 6932 RVA: 0x0014FAFC File Offset: 0x0014DCFC
		Private Function fInitForm() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pintResult"
				array(0).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMLN_SETPARA_GET_UPDATELIST", flag2)
				flag = flag2
				If flag Then
					Dim b2 As Byte = Conversions.ToByte(array(0).Value)
					Me.mblnAutoAdd = True
					flag = b2 = 3
					If flag Then
						b2 = 1
					Else
						flag = b2 = 2
						If flag Then
							b2 = 0
						Else
							Me.mblnAutoAdd = False
						End If
					End If
					b2 += Me.mBytOpen_FromMenu
					flag = b2 < 8
					If flag Then
						Me.btnAdd.Visible = False
						Me.btnAddDefault.Visible = False
						Me.btnModify.Visible = False
						Me.btnDelete.Visible = False
					End If
					b = 1
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001B15 RID: 6933 RVA: 0x0014FD38 File Offset: 0x0014DF38
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(mdlVariable.gStrPathApp + "\DISPLAY\" + mdlVariable.gStrLanguage + "\FRMDMLDTHU1.TXT")
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "2040300000")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001B16 RID: 6934 RVA: 0x0014FE14 File Offset: 0x0014E014
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001B17 RID: 6935 RVA: 0x0014FEC0 File Offset: 0x0014E0C0
		Private Function fPrintDMLDTHU() As Byte
			Dim rptDMLDTHU As rptDMLDTHU = New rptDMLDTHU()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMLDTHU, "")
				Dim text As String = "2040300000"
				mdlReport.gsSetOfficeReport(rptDMLDTHU, text)
				mdlReport.gsSetFontReport(rptDMLDTHU)
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMLDTHU")
				rptDMLDTHU.SetDataSource(clsConnect)
				rptDMLDTHU.DataDefinition.FormulaFields("fInReasonCode").Text = "{dtReport.OBJID}"
				rptDMLDTHU.DataDefinition.FormulaFields("fInReasonName").Text = "{dtReport.OBJNAME}"
				mdlReport.gsSetTextReport(rptDMLDTHU, "RPTDMLDTHU")
				MyProject.Forms.frmReport.pSource = rptDMLDTHU
				MyProject.Forms.frmReport.MaximizeBox = True
				MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
				Dim textObject As TextObject = CType(rptDMLDTHU.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
				MyProject.Forms.frmReport.Text = textObject.Text
				rptDMLDTHU.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
				rptDMLDTHU.PrintOptions.PaperSize = PaperSize.PaperA4
				MyProject.Forms.frmReport.ShowDialog()
				MyProject.Forms.frmReport.pSource = Nothing
				clsConnect.Dispose()
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMLDTHU " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMLDTHU.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x04000B07 RID: 2823
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000B09 RID: 2825
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000B0A RID: 2826
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000B0B RID: 2827
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000B0C RID: 2828
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000B0D RID: 2829
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000B0E RID: 2830
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000B0F RID: 2831
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000B10 RID: 2832
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000B11 RID: 2833
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000B12 RID: 2834
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000B13 RID: 2835
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000B14 RID: 2836
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000B15 RID: 2837
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000B16 RID: 2838
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000B17 RID: 2839
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000B18 RID: 2840
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000B19 RID: 2841
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000B1A RID: 2842
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000B1B RID: 2843
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000B1C RID: 2844
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000B1D RID: 2845
		Private mArrStrFrmMess As String()

		' Token: 0x04000B1E RID: 2846
		Private mStrOBJID As String

		' Token: 0x04000B1F RID: 2847
		Private mStrOBJNAME As String

		' Token: 0x04000B20 RID: 2848
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000B21 RID: 2849
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000B22 RID: 2850
		Private marrDrFind As DataRow()

		' Token: 0x04000B23 RID: 2851
		Private mintFindLastPos As Integer

		' Token: 0x04000B24 RID: 2852
		Private mblnAutoAdd As Boolean
	End Class
End Namespace
