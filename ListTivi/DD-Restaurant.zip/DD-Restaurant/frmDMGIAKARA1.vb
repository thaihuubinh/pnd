﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000049 RID: 73
	<DesignerGenerated()>
	Public Partial Class frmDMGIAKARA1
		Inherits Form

		' Token: 0x06001381 RID: 4993 RVA: 0x000ECEC0 File Offset: 0x000EB0C0
		Public Sub New()
			AddHandler MyBase.Activated, AddressOf Me.frmDMGIAKARA1_Activated
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMGIAKARA1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMGIAKARA1_Load
			frmDMGIAKARA1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.InitializeComponent()
		End Sub

		' Token: 0x170006CC RID: 1740
		' (get) Token: 0x06001384 RID: 4996 RVA: 0x000EE5AC File Offset: 0x000EC7AC
		' (set) Token: 0x06001385 RID: 4997 RVA: 0x00004F21 File Offset: 0x00003121
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x170006CD RID: 1741
		' (get) Token: 0x06001386 RID: 4998 RVA: 0x000EE5C4 File Offset: 0x000EC7C4
		' (set) Token: 0x06001387 RID: 4999 RVA: 0x000EE5DC File Offset: 0x000EC7DC
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x170006CE RID: 1742
		' (get) Token: 0x06001388 RID: 5000 RVA: 0x000EE648 File Offset: 0x000EC848
		' (set) Token: 0x06001389 RID: 5001 RVA: 0x000EE660 File Offset: 0x000EC860
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170006CF RID: 1743
		' (get) Token: 0x0600138A RID: 5002 RVA: 0x000EE6CC File Offset: 0x000EC8CC
		' (set) Token: 0x0600138B RID: 5003 RVA: 0x000EE6E4 File Offset: 0x000EC8E4
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x170006D0 RID: 1744
		' (get) Token: 0x0600138C RID: 5004 RVA: 0x000EE750 File Offset: 0x000EC950
		' (set) Token: 0x0600138D RID: 5005 RVA: 0x000EE768 File Offset: 0x000EC968
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x170006D1 RID: 1745
		' (get) Token: 0x0600138E RID: 5006 RVA: 0x000EE7D4 File Offset: 0x000EC9D4
		' (set) Token: 0x0600138F RID: 5007 RVA: 0x000EE7EC File Offset: 0x000EC9EC
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170006D2 RID: 1746
		' (get) Token: 0x06001390 RID: 5008 RVA: 0x000EE858 File Offset: 0x000ECA58
		' (set) Token: 0x06001391 RID: 5009 RVA: 0x000EE870 File Offset: 0x000ECA70
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x170006D3 RID: 1747
		' (get) Token: 0x06001392 RID: 5010 RVA: 0x000EE8DC File Offset: 0x000ECADC
		' (set) Token: 0x06001393 RID: 5011 RVA: 0x000EE8F4 File Offset: 0x000ECAF4
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170006D4 RID: 1748
		' (get) Token: 0x06001394 RID: 5012 RVA: 0x000EE960 File Offset: 0x000ECB60
		' (set) Token: 0x06001395 RID: 5013 RVA: 0x00004F2B File Offset: 0x0000312B
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x170006D5 RID: 1749
		' (get) Token: 0x06001396 RID: 5014 RVA: 0x000EE978 File Offset: 0x000ECB78
		' (set) Token: 0x06001397 RID: 5015 RVA: 0x000EE990 File Offset: 0x000ECB90
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x170006D6 RID: 1750
		' (get) Token: 0x06001398 RID: 5016 RVA: 0x000EE9FC File Offset: 0x000ECBFC
		' (set) Token: 0x06001399 RID: 5017 RVA: 0x000EEA14 File Offset: 0x000ECC14
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x170006D7 RID: 1751
		' (get) Token: 0x0600139A RID: 5018 RVA: 0x000EEA80 File Offset: 0x000ECC80
		' (set) Token: 0x0600139B RID: 5019 RVA: 0x000EEA98 File Offset: 0x000ECC98
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170006D8 RID: 1752
		' (get) Token: 0x0600139C RID: 5020 RVA: 0x000EEB04 File Offset: 0x000ECD04
		' (set) Token: 0x0600139D RID: 5021 RVA: 0x00004F35 File Offset: 0x00003135
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170006D9 RID: 1753
		' (get) Token: 0x0600139E RID: 5022 RVA: 0x000EEB1C File Offset: 0x000ECD1C
		' (set) Token: 0x0600139F RID: 5023 RVA: 0x000EEB34 File Offset: 0x000ECD34
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x170006DA RID: 1754
		' (get) Token: 0x060013A0 RID: 5024 RVA: 0x000EEBA0 File Offset: 0x000ECDA0
		' (set) Token: 0x060013A1 RID: 5025 RVA: 0x000EEBB8 File Offset: 0x000ECDB8
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x170006DB RID: 1755
		' (get) Token: 0x060013A2 RID: 5026 RVA: 0x000EEC24 File Offset: 0x000ECE24
		' (set) Token: 0x060013A3 RID: 5027 RVA: 0x000EEC3C File Offset: 0x000ECE3C
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170006DC RID: 1756
		' (get) Token: 0x060013A4 RID: 5028 RVA: 0x000EECA8 File Offset: 0x000ECEA8
		' (set) Token: 0x060013A5 RID: 5029 RVA: 0x000EECC0 File Offset: 0x000ECEC0
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x170006DD RID: 1757
		' (get) Token: 0x060013A6 RID: 5030 RVA: 0x000EED2C File Offset: 0x000ECF2C
		' (set) Token: 0x060013A7 RID: 5031 RVA: 0x00004F3F File Offset: 0x0000313F
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Me._dgvData = value
			End Set
		End Property

		' Token: 0x170006DE RID: 1758
		' (get) Token: 0x060013A8 RID: 5032 RVA: 0x000EED44 File Offset: 0x000ECF44
		' (set) Token: 0x060013A9 RID: 5033 RVA: 0x00004F49 File Offset: 0x00003149
		Friend Overridable Property lblMANH As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblMANH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblMANH = value
			End Set
		End Property

		' Token: 0x170006DF RID: 1759
		' (get) Token: 0x060013AA RID: 5034 RVA: 0x000EED5C File Offset: 0x000ECF5C
		' (set) Token: 0x060013AB RID: 5035 RVA: 0x00004F53 File Offset: 0x00003153
		Friend Overridable Property txtOBJNAMEKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAMEKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAMEKH = value
			End Set
		End Property

		' Token: 0x170006E0 RID: 1760
		' (get) Token: 0x060013AC RID: 5036 RVA: 0x000EED74 File Offset: 0x000ECF74
		' (set) Token: 0x060013AD RID: 5037 RVA: 0x000EED8C File Offset: 0x000ECF8C
		Friend Overridable Property btnSelectKH As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelectKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelectKH IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelectKH.Click, AddressOf Me.btnSelectKH_Click
				End If
				Me._btnSelectKH = value
				flag = Me._btnSelectKH IsNot Nothing
				If flag Then
					AddHandler Me._btnSelectKH.Click, AddressOf Me.btnSelectKH_Click
				End If
			End Set
		End Property

		' Token: 0x170006E1 RID: 1761
		' (get) Token: 0x060013AE RID: 5038 RVA: 0x000EEDF8 File Offset: 0x000ECFF8
		' (set) Token: 0x060013AF RID: 5039 RVA: 0x000EEE10 File Offset: 0x000ED010
		Friend Overridable Property txtMAKH As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtMAKH
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtMAKH IsNot Nothing
				If flag Then
					RemoveHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
				Me._txtMAKH = value
				flag = Me._txtMAKH IsNot Nothing
				If flag Then
					AddHandler Me._txtMAKH.TextChanged, AddressOf Me.txtMAKH_TextChanged
				End If
			End Set
		End Property

		' Token: 0x170006E2 RID: 1762
		' (get) Token: 0x060013B0 RID: 5040 RVA: 0x000EEE7C File Offset: 0x000ED07C
		' (set) Token: 0x060013B1 RID: 5041 RVA: 0x000EEE94 File Offset: 0x000ED094
		Friend Overridable Property btnDetail As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDetail
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDetail IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDetail.Click, AddressOf Me.btnDetail_Click
				End If
				Me._btnDetail = value
				flag = Me._btnDetail IsNot Nothing
				If flag Then
					AddHandler Me._btnDetail.Click, AddressOf Me.btnDetail_Click
				End If
			End Set
		End Property

		' Token: 0x170006E3 RID: 1763
		' (get) Token: 0x060013B2 RID: 5042 RVA: 0x000EEF00 File Offset: 0x000ED100
		' (set) Token: 0x060013B3 RID: 5043 RVA: 0x00004F5D File Offset: 0x0000315D
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x170006E4 RID: 1764
		' (get) Token: 0x060013B4 RID: 5044 RVA: 0x000EEF18 File Offset: 0x000ED118
		' (set) Token: 0x060013B5 RID: 5045 RVA: 0x000EEF30 File Offset: 0x000ED130
		Friend Overridable Property BtnCP As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._BtnCP
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._BtnCP IsNot Nothing
				If flag Then
					RemoveHandler Me._BtnCP.Click, AddressOf Me.BtnCP_Click
				End If
				Me._BtnCP = value
				flag = Me._BtnCP IsNot Nothing
				If flag Then
					AddHandler Me._BtnCP.Click, AddressOf Me.BtnCP_Click
				End If
			End Set
		End Property

		' Token: 0x170006E5 RID: 1765
		' (get) Token: 0x060013B6 RID: 5046 RVA: 0x000EEF9C File Offset: 0x000ED19C
		' (set) Token: 0x060013B7 RID: 5047 RVA: 0x000EEFB4 File Offset: 0x000ED1B4
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x170006E6 RID: 1766
		' (get) Token: 0x060013B8 RID: 5048 RVA: 0x000EF020 File Offset: 0x000ED220
		' (set) Token: 0x060013B9 RID: 5049 RVA: 0x00004F67 File Offset: 0x00003167
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x170006E7 RID: 1767
		' (get) Token: 0x060013BA RID: 5050 RVA: 0x000EF038 File Offset: 0x000ED238
		' (set) Token: 0x060013BB RID: 5051 RVA: 0x00004F72 File Offset: 0x00003172
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x170006E8 RID: 1768
		' (get) Token: 0x060013BC RID: 5052 RVA: 0x000EF050 File Offset: 0x000ED250
		' (set) Token: 0x060013BD RID: 5053 RVA: 0x00004F7D File Offset: 0x0000317D
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x060013BE RID: 5054 RVA: 0x000EF068 File Offset: 0x000ED268
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013BF RID: 5055 RVA: 0x000EF138 File Offset: 0x000ED338
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013C0 RID: 5056 RVA: 0x000EF228 File Offset: 0x000ED428
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013C1 RID: 5057 RVA: 0x000EF30C File Offset: 0x000ED50C
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013C2 RID: 5058 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub frmDMGIAKARA1_Activated(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x060013C3 RID: 5059 RVA: 0x000EF3D0 File Offset: 0x000ED5D0
		Private Sub frmDMGIAKARA1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMGIAKARA1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013C4 RID: 5060 RVA: 0x000EF468 File Offset: 0x000ED668
		Private Sub frmDMGIAKARA1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				Me.sGetDMKH()
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMGIAKARA1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013C5 RID: 5061 RVA: 0x000EF578 File Offset: 0x000ED778
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013C6 RID: 5062 RVA: 0x000EF680 File Offset: 0x000ED880
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013C7 RID: 5063 RVA: 0x000EF718 File Offset: 0x000ED918
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMGIAKARA As frmDMGIAKARA2 = New frmDMGIAKARA2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMGIAKARA.pbytFromStatus = 1
				frmDMGIAKARA.pStrFromDate = String.Concat(New String() { DateAndTime.Today.Day.ToString("00"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Year.ToString("0000") })
				frmDMGIAKARA.pStrToDate = String.Concat(New String() { DateAndTime.Today.Day.ToString("00"), "/", DateAndTime.Today.Month.ToString("00"), "/", DateAndTime.Today.Year.ToString("0000") })
				frmDMGIAKARA.pStrFromTime = "00:00"
				frmDMGIAKARA.pStrToTime = "23:59"
				frmDMGIAKARA.gsCheckDate()
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pintResult"
				array(0).Direction = ParameterDirection.ReturnValue
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMGIAKARA_GET_MAX_OBJID", flag)
				Dim flag2 As Boolean = flag
				If flag2 Then
					Select Case Strings.Len(array(0).Value.ToString())
						Case 1
							frmDMGIAKARA.txtOBJID.Text = "0000" + array(0).Value.ToString()
						Case 2
							frmDMGIAKARA.txtOBJID.Text = "000" + array(0).Value.ToString()
						Case 3
							frmDMGIAKARA.txtOBJID.Text = "00" + array(0).Value.ToString()
						Case 4
							frmDMGIAKARA.txtOBJID.Text = "0" + array(0).Value.ToString()
						Case 10
							frmDMGIAKARA.txtOBJID.Text = array(0).Value.ToString()
					End Select
					frmDMGIAKARA.txtOBJID.Focus()
					frmDMGIAKARA.txtMAKH.Text = mdlVariable.gStrStockCode
				End If
				frmDMGIAKARA.ShowDialog()
				flag2 = frmDMGIAKARA.pbytSuccess = 0
				If Not flag2 Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag2 = b = 0
					If flag2 Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag2 = b <> 0
					If flag2 Then
						b = Me.fInitGrid()
					End If
					flag2 = b <> 0
					If flag2 Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMGIAKARA.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnDetail_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x060013C8 RID: 5064 RVA: 0x000EFB48 File Offset: 0x000EDD48
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMGIAKARA As frmDMGIAKARA2 = New frmDMGIAKARA2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMGIAKARA2 As frmDMGIAKARA2 = frmDMGIAKARA
				frmDMGIAKARA2.pbytFromStatus = 2
				Dim flag As Boolean = Me.dgvData.RowCount > 0
				If flag Then
					frmDMGIAKARA2.pbytFromStatus = 2
					frmDMGIAKARA2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					frmDMGIAKARA2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
					frmDMGIAKARA2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
					frmDMGIAKARA2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENNGAY").Value, ""))
					frmDMGIAKARA2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUNGAY").Value, ""))
					frmDMGIAKARA2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUGIO").Value, ""))
					frmDMGIAKARA2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENGIO").Value, ""))
					frmDMGIAKARA2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
					frmDMGIAKARA2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
					frmDMGIAKARA2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
					frmDMGIAKARA2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
					frmDMGIAKARA2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
					frmDMGIAKARA2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
					frmDMGIAKARA2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
					frmDMGIAKARA2.chkFes.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY9").Value, ""), True, False), True, False))
				End If
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pintResult"
				array(0).Direction = ParameterDirection.ReturnValue
				Dim flag2 As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMGIAKARA_GET_MAX_OBJID", flag2)
				flag = flag2
				If flag Then
					Select Case Strings.Len(array(0).Value.ToString())
						Case 1
							frmDMGIAKARA.txtOBJID.Text = "0000" + array(0).Value.ToString()
						Case 2
							frmDMGIAKARA.txtOBJID.Text = "000" + array(0).Value.ToString()
						Case 3
							frmDMGIAKARA.txtOBJID.Text = "00" + array(0).Value.ToString()
						Case 4
							frmDMGIAKARA.txtOBJID.Text = "0" + array(0).Value.ToString()
						Case 10
							frmDMGIAKARA.txtOBJID.Text = array(0).Value.ToString()
					End Select
					frmDMGIAKARA.txtOBJID.Focus()
					frmDMGIAKARA.txtMAKH.Text = mdlVariable.gStrStockCode
				End If
				frmDMGIAKARA.ShowDialog()
				flag = frmDMGIAKARA.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMGIAKARA.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnDetail_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x060013C9 RID: 5065 RVA: 0x000F02B4 File Offset: 0x000EE4B4
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMGIAKARA As frmDMGIAKARA2 = New frmDMGIAKARA2()
			Try
				Dim frmDMGIAKARA2 As frmDMGIAKARA2 = frmDMGIAKARA
				frmDMGIAKARA2.pbytFromStatus = 3
				frmDMGIAKARA2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMGIAKARA2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMGIAKARA2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMGIAKARA2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMGIAKARA2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMGIAKARA2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMGIAKARA2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMGIAKARA2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY2").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY3").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY4").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY5").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY6").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY7").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY8").Value, ""), True, False), True, False))
				frmDMGIAKARA2.chkFes.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY9").Value, ""), True, False), True, False))
				frmDMGIAKARA.ShowDialog()
				Dim flag As Boolean = frmDMGIAKARA.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMGIAKARA.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x060013CA RID: 5066 RVA: 0x000F0848 File Offset: 0x000EEA48
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMGIAKARA As frmDMGIAKARA2 = New frmDMGIAKARA2()
			Try
				Dim frmDMGIAKARA2 As frmDMGIAKARA2 = frmDMGIAKARA
				frmDMGIAKARA2.pbytFromStatus = 4
				frmDMGIAKARA2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMGIAKARA2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMGIAKARA2.pStrKHO = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAKH").Value, ""))
				frmDMGIAKARA2.pStrToDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENNGAY").Value, ""))
				frmDMGIAKARA2.pStrFromDate = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUNGAY").Value, ""))
				frmDMGIAKARA2.pStrFromTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TUGIO").Value, ""))
				frmDMGIAKARA2.pStrToTime = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DENGIO").Value, ""))
				frmDMGIAKARA2.chkT2.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY2").Value, True, False), True, False))
				frmDMGIAKARA2.chkT3.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY3").Value, True, False), True, False))
				frmDMGIAKARA2.chkT4.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY4").Value, True, False), True, False))
				frmDMGIAKARA2.chkT5.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY5").Value, True, False), True, False))
				frmDMGIAKARA2.chkT6.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY6").Value, True, False), True, False))
				frmDMGIAKARA2.chkT7.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY7").Value, True, False), True, False))
				frmDMGIAKARA2.chkCN.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Me.dgvData.CurrentRow.Cells("LDAY8").Value, True, False), True, False))
				frmDMGIAKARA2.chkFes.Checked = Conversions.ToBoolean(Interaction.IIf(Operators.ConditionalCompareObjectEqual(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LDAY9").Value, ""), True, False), True, False))
				frmDMGIAKARA.ShowDialog()
				Dim flag As Boolean = frmDMGIAKARA.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.gfGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x060013CB RID: 5067 RVA: 0x000F0D74 File Offset: 0x000EEF74
		Private Sub txtMAKH_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Dim flag As Boolean = Me.mclsTbDMKHO Is Nothing
			If Not flag Then
				array(0) = Me.mclsTbDMKHO.Columns("OBJID")
				Me.mclsTbDMKHO.PrimaryKey = array
				Dim dataRow As DataRow = Me.mclsTbDMKHO.Rows.Find(Strings.Trim(Me.txtMAKH.Text))
				flag = dataRow IsNot Nothing
				If flag Then
					Me.txtOBJNAMEKH.Text = dataRow("OBJNAME").ToString()
				Else
					Me.txtOBJNAMEKH.Text = ""
				End If
				flag = Me.mbdsSource Is Nothing
				If Not flag Then
					flag = Strings.Len(Strings.Trim(Me.txtMAKH.Text)) = 0
					If flag Then
						Me.mbdsSource.RemoveFilter()
					Else
						Me.mbdsSource.Filter = "MAKH like '" + Strings.Trim(Me.txtMAKH.Text) + "'"
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			End If
		End Sub

		' Token: 0x060013CC RID: 5068 RVA: 0x000F0E9C File Offset: 0x000EF09C
		Private Sub sGetDMKH()
			Try
				Me.mclsTbDMKHO = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMKH")
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sGetDMKH ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013CD RID: 5069 RVA: 0x000F0F44 File Offset: 0x000EF144
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim frmDMGIAKARA As frmDMGIAKARA2 = New frmDMGIAKARA2()
			Try
				frmDMGIAKARA.pbytFromStatus = 6
				frmDMGIAKARA.ShowDialog()
				Dim flag As Boolean = frmDMGIAKARA.pbytSuccess = 0
				If flag Then
					frmDMGIAKARA.Dispose()
				Else
					Dim dataTable As DataTable = CType(Me.mbdsSource.DataSource, DataTable)
					Me.marrDrFind = dataTable.[Select](Conversions.ToString(Operators.ConcatenateObject(frmDMGIAKARA.pStrFilter, Interaction.IIf(Operators.CompareString(Me.mbdsSource.Filter + "", "", False) = 0, "", " AND " + Me.mbdsSource.Filter))))
					dataTable.Dispose()
					flag = Me.marrDrFind.Length = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(25), MsgBoxStyle.Critical, Nothing)
						frmDMGIAKARA.Dispose()
					Else
						Me.btnFindNext.Visible = True
						Dim num As Integer = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(0)("OBJID")))
						Me.mintFindLastPos = 1
						Me.dgvData.CurrentCell = Me.dgvData(0, num)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x060013CE RID: 5070 RVA: 0x000F1138 File Offset: 0x000EF338
		Private Sub btnSelectKH_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMKH As frmDMKH1 = New frmDMKH1()
				frmDMKH.pBytOpen_From_Menu = 7
				frmDMKH.ShowDialog()
				Me.txtMAKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJID, "", False) = 0, Me.txtMAKH.Text, frmDMKH.pStrOBJID))
				Me.txtOBJNAMEKH.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMKH.pStrOBJNAME, "", False) = 0, Me.txtOBJNAMEKH.Text, frmDMKH.pStrOBJNAME))
				frmDMKH.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013CF RID: 5071 RVA: 0x000F125C File Offset: 0x000EF45C
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMGIAKARA As frmDMGIAKARA2 = New frmDMGIAKARA2()
			Try
				Me.btnFindNext.Visible = False
				frmDMGIAKARA.pbytFromStatus = 5
				frmDMGIAKARA.ShowDialog()
				Dim flag As Boolean = frmDMGIAKARA.pbytSuccess = 0
				If Not flag Then
					Me.mbdsSource.Filter = frmDMGIAKARA.pStrFilter
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x060013D0 RID: 5072 RVA: 0x000F1364 File Offset: 0x000EF564
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMBP As frmDMBP2 = New frmDMBP2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMBP.Dispose()
			End Try
		End Sub

		' Token: 0x060013D1 RID: 5073 RVA: 0x000F142C File Offset: 0x000EF62C
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("KHOACHINH", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("KHOACHINH")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x060013D2 RID: 5074 RVA: 0x000F15A8 File Offset: 0x000EF7A8
		Private Sub btnDetail_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMGIAKARA As frmDMGIAKARA3 = New frmDMGIAKARA3()
				Dim frmDMGIAKARA2 As frmDMGIAKARA3 = frmDMGIAKARA
				frmDMGIAKARA2.pbdsSource = Me.mbdsSource
				frmDMGIAKARA2.pdgvMaster = Me.dgvData
				frmDMGIAKARA.ShowDialog()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDetail_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x060013D3 RID: 5075 RVA: 0x00002A72 File Offset: 0x00000C72
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
		End Sub

		' Token: 0x060013D4 RID: 5076 RVA: 0x000F1664 File Offset: 0x000EF864
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				Dim dataGridViewCellStyle2 As DataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle2.BackColor = mdlVariable.gobjcloOddRowGrid
				dgvData.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(192, 255, 192)
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = Me.Width - 510 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TUNGAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(20))
				dgvData.Columns("TUNGAY").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TUNGAY").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DENNGAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(21))
				dgvData.Columns("DENNGAY").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("DENNGAY").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TUGIO").HeaderText = Strings.Trim(Me.mArrStrFrmMess(22))
				dgvData.Columns("TUGIO").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TUGIO").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DENGIO").HeaderText = Strings.Trim(Me.mArrStrFrmMess(23))
				dgvData.Columns("DENGIO").Width = 100
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("DENGIO").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MAKH").Visible = False
				dgvData.Columns("LDAY2").Visible = False
				dgvData.Columns("LDAY3").Visible = False
				dgvData.Columns("LDAY4").Visible = False
				dgvData.Columns("LDAY5").Visible = False
				dgvData.Columns("LDAY6").Visible = False
				dgvData.Columns("LDAY7").Visible = False
				dgvData.Columns("LDAY8").Visible = False
				dgvData.Columns("LDAY9").Visible = False
				dgvData.Columns("KHOACHINH").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060013D5 RID: 5077 RVA: 0x000F1AF0 File Offset: 0x000EFCF0
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				Me.btnDetail.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060013D6 RID: 5078 RVA: 0x000F1C80 File Offset: 0x000EFE80
		Public Function gfGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(2) {}
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim b As Byte
			Try
				b = 0
				Dim flag As Boolean
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, "GET_DATA_DMGIAKARA1", flag)
				Dim flag2 As Boolean = flag
				If flag2 Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gfGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x060013D7 RID: 5079 RVA: 0x000F1D78 File Offset: 0x000EFF78
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060013D8 RID: 5080 RVA: 0x000F1E54 File Offset: 0x000F0054
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase("frmDMGIAKARA1"), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x060013D9 RID: 5081 RVA: 0x000F1F60 File Offset: 0x000F0160
		Private Sub sClear_Form()
			Try
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x060013DA RID: 5082 RVA: 0x000F2000 File Offset: 0x000F0200
		Private Sub BtnCP_Click(sender As Object, e As EventArgs)
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim frmDMGIAKARA As frmDMGIAKARA4 = New frmDMGIAKARA4()
			Try
				frmDMGIAKARA.pStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMGIAKARA.ShowDialog()
				Dim flag As Boolean = frmDMGIAKARA.pbytSuccess = 0
				If flag Then
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fAdd_frmDOCUMENT4 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMGIAKARA.Dispose()
			End Try
		End Sub

		' Token: 0x0400081E RID: 2078
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000820 RID: 2080
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000821 RID: 2081
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000822 RID: 2082
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000823 RID: 2083
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000824 RID: 2084
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000825 RID: 2085
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000826 RID: 2086
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000827 RID: 2087
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000828 RID: 2088
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000829 RID: 2089
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x0400082A RID: 2090
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x0400082B RID: 2091
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x0400082C RID: 2092
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x0400082D RID: 2093
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x0400082E RID: 2094
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x0400082F RID: 2095
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000830 RID: 2096
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000831 RID: 2097
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000832 RID: 2098
		<AccessedThroughProperty("lblMANH")>
		Private _lblMANH As Label

		' Token: 0x04000833 RID: 2099
		<AccessedThroughProperty("txtOBJNAMEKH")>
		Private _txtOBJNAMEKH As TextBox

		' Token: 0x04000834 RID: 2100
		<AccessedThroughProperty("btnSelectKH")>
		Private _btnSelectKH As Button

		' Token: 0x04000835 RID: 2101
		<AccessedThroughProperty("txtMAKH")>
		Private _txtMAKH As TextBox

		' Token: 0x04000836 RID: 2102
		<AccessedThroughProperty("btnDetail")>
		Private _btnDetail As Button

		' Token: 0x04000837 RID: 2103
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000838 RID: 2104
		<AccessedThroughProperty("BtnCP")>
		Private _BtnCP As Button

		' Token: 0x04000839 RID: 2105
		Private mArrStrFrmMess As String()

		' Token: 0x0400083A RID: 2106
		Private mStrOBJID As String

		' Token: 0x0400083B RID: 2107
		Private mStrOBJNAME As String

		' Token: 0x0400083C RID: 2108
		Private mBytOpen_FromMenu As Byte

		' Token: 0x0400083D RID: 2109
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x0400083E RID: 2110
		Private marrDrFind As DataRow()

		' Token: 0x0400083F RID: 2111
		Private mintFindLastPos As Integer

		' Token: 0x04000840 RID: 2112
		Private mclsTbDMKHO As clsConnect
	End Class
End Namespace
