﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO.Ports
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports prjIS_SalesPOS.My
Imports prjIS_SalesPOS.My.Resources

Namespace prjIS_SalesPOS
	' Token: 0x02000061 RID: 97
	<DesignerGenerated()>
	Public Partial Class frmDMMAYINBEP1
		Inherits Form

		' Token: 0x06001D2B RID: 7467 RVA: 0x00168CE4 File Offset: 0x00166EE4
		Public Sub New()
			AddHandler MyBase.FormClosing, AddressOf Me.frmDMMAYINBEP1_FormClosing
			AddHandler MyBase.Load, AddressOf Me.frmDMMAYINBEP1_Load
			frmDMMAYINBEP1.__ENCList.Add(New WeakReference(Me))
			Me.mbdsSource = New BindingSource()
			Me.srlCOMport = New SerialPort()
			Me.InitializeComponent()
		End Sub

		' Token: 0x170009ED RID: 2541
		' (get) Token: 0x06001D2E RID: 7470 RVA: 0x0016A304 File Offset: 0x00168504
		' (set) Token: 0x06001D2F RID: 7471 RVA: 0x00006136 File Offset: 0x00004336
		Friend Overridable Property lblPosition As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblPosition
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblPosition = value
			End Set
		End Property

		' Token: 0x170009EE RID: 2542
		' (get) Token: 0x06001D30 RID: 7472 RVA: 0x0016A31C File Offset: 0x0016851C
		' (set) Token: 0x06001D31 RID: 7473 RVA: 0x0016A334 File Offset: 0x00168534
		Friend Overridable Property btnAddDefault As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAddDefault
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAddDefault IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
				Me._btnAddDefault = value
				flag = Me._btnAddDefault IsNot Nothing
				If flag Then
					AddHandler Me._btnAddDefault.Click, AddressOf Me.btnAddDefault_Click
				End If
			End Set
		End Property

		' Token: 0x170009EF RID: 2543
		' (get) Token: 0x06001D32 RID: 7474 RVA: 0x0016A3A0 File Offset: 0x001685A0
		' (set) Token: 0x06001D33 RID: 7475 RVA: 0x0016A3B8 File Offset: 0x001685B8
		Friend Overridable Property btnDelete As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnDelete
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnDelete IsNot Nothing
				If flag Then
					RemoveHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
				Me._btnDelete = value
				flag = Me._btnDelete IsNot Nothing
				If flag Then
					AddHandler Me._btnDelete.Click, AddressOf Me.btnDelete_Click
				End If
			End Set
		End Property

		' Token: 0x170009F0 RID: 2544
		' (get) Token: 0x06001D34 RID: 7476 RVA: 0x0016A424 File Offset: 0x00168624
		' (set) Token: 0x06001D35 RID: 7477 RVA: 0x0016A43C File Offset: 0x0016863C
		Friend Overridable Property btnLast As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnLast
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnLast IsNot Nothing
				If flag Then
					RemoveHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
				Me._btnLast = value
				flag = Me._btnLast IsNot Nothing
				If flag Then
					AddHandler Me._btnLast.Click, AddressOf Me.btnLast_Click
				End If
			End Set
		End Property

		' Token: 0x170009F1 RID: 2545
		' (get) Token: 0x06001D36 RID: 7478 RVA: 0x0016A4A8 File Offset: 0x001686A8
		' (set) Token: 0x06001D37 RID: 7479 RVA: 0x0016A4C0 File Offset: 0x001686C0
		Friend Overridable Property btnNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
				Me._btnNext = value
				flag = Me._btnNext IsNot Nothing
				If flag Then
					AddHandler Me._btnNext.Click, AddressOf Me.btnNext_Click
				End If
			End Set
		End Property

		' Token: 0x170009F2 RID: 2546
		' (get) Token: 0x06001D38 RID: 7480 RVA: 0x0016A52C File Offset: 0x0016872C
		' (set) Token: 0x06001D39 RID: 7481 RVA: 0x0016A544 File Offset: 0x00168744
		Friend Overridable Property btnFind As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFind
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFind IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
				Me._btnFind = value
				flag = Me._btnFind IsNot Nothing
				If flag Then
					AddHandler Me._btnFind.Click, AddressOf Me.btnFind_Click
				End If
			End Set
		End Property

		' Token: 0x170009F3 RID: 2547
		' (get) Token: 0x06001D3A RID: 7482 RVA: 0x0016A5B0 File Offset: 0x001687B0
		' (set) Token: 0x06001D3B RID: 7483 RVA: 0x0016A5C8 File Offset: 0x001687C8
		Friend Overridable Property btnPreview As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPreview
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPreview IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
				Me._btnPreview = value
				flag = Me._btnPreview IsNot Nothing
				If flag Then
					AddHandler Me._btnPreview.Click, AddressOf Me.btnPreview_Click
				End If
			End Set
		End Property

		' Token: 0x170009F4 RID: 2548
		' (get) Token: 0x06001D3C RID: 7484 RVA: 0x0016A634 File Offset: 0x00168834
		' (set) Token: 0x06001D3D RID: 7485 RVA: 0x0016A64C File Offset: 0x0016884C
		Friend Overridable Property btnCancelFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnCancelFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnCancelFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
				Me._btnCancelFilter = value
				flag = Me._btnCancelFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnCancelFilter.Click, AddressOf Me.btnCancelFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170009F5 RID: 2549
		' (get) Token: 0x06001D3E RID: 7486 RVA: 0x0016A6B8 File Offset: 0x001688B8
		' (set) Token: 0x06001D3F RID: 7487 RVA: 0x00006140 File Offset: 0x00004340
		Friend Overridable Property grpNavigater As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpNavigater
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpNavigater = value
			End Set
		End Property

		' Token: 0x170009F6 RID: 2550
		' (get) Token: 0x06001D40 RID: 7488 RVA: 0x0016A6D0 File Offset: 0x001688D0
		' (set) Token: 0x06001D41 RID: 7489 RVA: 0x0016A6E8 File Offset: 0x001688E8
		Friend Overridable Property btnFirst As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFirst
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFirst IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
				Me._btnFirst = value
				flag = Me._btnFirst IsNot Nothing
				If flag Then
					AddHandler Me._btnFirst.Click, AddressOf Me.btnFirst_Click
				End If
			End Set
		End Property

		' Token: 0x170009F7 RID: 2551
		' (get) Token: 0x06001D42 RID: 7490 RVA: 0x0016A754 File Offset: 0x00168954
		' (set) Token: 0x06001D43 RID: 7491 RVA: 0x0016A76C File Offset: 0x0016896C
		Friend Overridable Property btnPrevious As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnPrevious
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnPrevious IsNot Nothing
				If flag Then
					RemoveHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
				Me._btnPrevious = value
				flag = Me._btnPrevious IsNot Nothing
				If flag Then
					AddHandler Me._btnPrevious.Click, AddressOf Me.btnPrevious_Click
				End If
			End Set
		End Property

		' Token: 0x170009F8 RID: 2552
		' (get) Token: 0x06001D44 RID: 7492 RVA: 0x0016A7D8 File Offset: 0x001689D8
		' (set) Token: 0x06001D45 RID: 7493 RVA: 0x0016A7F0 File Offset: 0x001689F0
		Friend Overridable Property btnFilter As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFilter
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFilter IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
				Me._btnFilter = value
				flag = Me._btnFilter IsNot Nothing
				If flag Then
					AddHandler Me._btnFilter.Click, AddressOf Me.btnFilter_Click
				End If
			End Set
		End Property

		' Token: 0x170009F9 RID: 2553
		' (get) Token: 0x06001D46 RID: 7494 RVA: 0x0016A85C File Offset: 0x00168A5C
		' (set) Token: 0x06001D47 RID: 7495 RVA: 0x0000614A File Offset: 0x0000434A
		Friend Overridable Property grpControl As GroupBox
			<DebuggerNonUserCode()>
			Get
				Return Me._grpControl
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._grpControl = value
			End Set
		End Property

		' Token: 0x170009FA RID: 2554
		' (get) Token: 0x06001D48 RID: 7496 RVA: 0x0016A874 File Offset: 0x00168A74
		' (set) Token: 0x06001D49 RID: 7497 RVA: 0x0016A88C File Offset: 0x00168A8C
		Friend Overridable Property btnModify As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnModify
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnModify IsNot Nothing
				If flag Then
					RemoveHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
				Me._btnModify = value
				flag = Me._btnModify IsNot Nothing
				If flag Then
					AddHandler Me._btnModify.Click, AddressOf Me.btnModify_Click
				End If
			End Set
		End Property

		' Token: 0x170009FB RID: 2555
		' (get) Token: 0x06001D4A RID: 7498 RVA: 0x0016A8F8 File Offset: 0x00168AF8
		' (set) Token: 0x06001D4B RID: 7499 RVA: 0x0016A910 File Offset: 0x00168B10
		Friend Overridable Property btnAdd As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnAdd
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnAdd IsNot Nothing
				If flag Then
					RemoveHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
				Me._btnAdd = value
				flag = Me._btnAdd IsNot Nothing
				If flag Then
					AddHandler Me._btnAdd.Click, AddressOf Me.btnAdd_Click
				End If
			End Set
		End Property

		' Token: 0x170009FC RID: 2556
		' (get) Token: 0x06001D4C RID: 7500 RVA: 0x0016A97C File Offset: 0x00168B7C
		' (set) Token: 0x06001D4D RID: 7501 RVA: 0x0016A994 File Offset: 0x00168B94
		Friend Overridable Property btnExit As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnExit
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnExit IsNot Nothing
				If flag Then
					RemoveHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
				Me._btnExit = value
				flag = Me._btnExit IsNot Nothing
				If flag Then
					AddHandler Me._btnExit.Click, AddressOf Me.btnExit_Click
				End If
			End Set
		End Property

		' Token: 0x170009FD RID: 2557
		' (get) Token: 0x06001D4E RID: 7502 RVA: 0x0016AA00 File Offset: 0x00168C00
		' (set) Token: 0x06001D4F RID: 7503 RVA: 0x0016AA18 File Offset: 0x00168C18
		Friend Overridable Property btnFindNext As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnFindNext
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnFindNext IsNot Nothing
				If flag Then
					RemoveHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
				Me._btnFindNext = value
				flag = Me._btnFindNext IsNot Nothing
				If flag Then
					AddHandler Me._btnFindNext.Click, AddressOf Me.btnFindNext_Click
				End If
			End Set
		End Property

		' Token: 0x170009FE RID: 2558
		' (get) Token: 0x06001D50 RID: 7504 RVA: 0x0016AA84 File Offset: 0x00168C84
		' (set) Token: 0x06001D51 RID: 7505 RVA: 0x0016AA9C File Offset: 0x00168C9C
		Friend Overridable Property btnSelect As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelect
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelect IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
				Me._btnSelect = value
				flag = Me._btnSelect IsNot Nothing
				If flag Then
					AddHandler Me._btnSelect.Click, AddressOf Me.btnSelect_Click
				End If
			End Set
		End Property

		' Token: 0x170009FF RID: 2559
		' (get) Token: 0x06001D52 RID: 7506 RVA: 0x0016AB08 File Offset: 0x00168D08
		' (set) Token: 0x06001D53 RID: 7507 RVA: 0x0016AB20 File Offset: 0x00168D20
		Friend Overridable Property dgvData As DataGridView
			<DebuggerNonUserCode()>
			Get
				Return Me._dgvData
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DataGridView)
				Dim flag As Boolean = Me._dgvData IsNot Nothing
				If flag Then
					RemoveHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
				Me._dgvData = value
				flag = Me._dgvData IsNot Nothing
				If flag Then
					AddHandler Me._dgvData.DoubleClick, AddressOf Me.dgvData_DoubleClick
				End If
			End Set
		End Property

		' Token: 0x17000A00 RID: 2560
		' (get) Token: 0x06001D54 RID: 7508 RVA: 0x0016AB8C File Offset: 0x00168D8C
		' (set) Token: 0x06001D55 RID: 7509 RVA: 0x00006154 File Offset: 0x00004354
		Friend Overridable Property lblStore As Label
			<DebuggerNonUserCode()>
			Get
				Return Me._lblStore
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._lblStore = value
			End Set
		End Property

		' Token: 0x17000A01 RID: 2561
		' (get) Token: 0x06001D56 RID: 7510 RVA: 0x0016ABA4 File Offset: 0x00168DA4
		' (set) Token: 0x06001D57 RID: 7511 RVA: 0x0000615E File Offset: 0x0000435E
		Friend Overridable Property txtOBJNAMEMAY As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJNAMEMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._txtOBJNAMEMAY = value
			End Set
		End Property

		' Token: 0x17000A02 RID: 2562
		' (get) Token: 0x06001D58 RID: 7512 RVA: 0x0016ABBC File Offset: 0x00168DBC
		' (set) Token: 0x06001D59 RID: 7513 RVA: 0x0016ABD4 File Offset: 0x00168DD4
		Friend Overridable Property btnSelectMAY As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnSelectMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnSelectMAY IsNot Nothing
				If flag Then
					RemoveHandler Me._btnSelectMAY.Click, AddressOf Me.btnSelectMAY_Click
				End If
				Me._btnSelectMAY = value
				flag = Me._btnSelectMAY IsNot Nothing
				If flag Then
					AddHandler Me._btnSelectMAY.Click, AddressOf Me.btnSelectMAY_Click
				End If
			End Set
		End Property

		' Token: 0x17000A03 RID: 2563
		' (get) Token: 0x06001D5A RID: 7514 RVA: 0x0016AC40 File Offset: 0x00168E40
		' (set) Token: 0x06001D5B RID: 7515 RVA: 0x0016AC58 File Offset: 0x00168E58
		Friend Overridable Property txtOBJIDMAY As TextBox
			<DebuggerNonUserCode()>
			Get
				Return Me._txtOBJIDMAY
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim flag As Boolean = Me._txtOBJIDMAY IsNot Nothing
				If flag Then
					RemoveHandler Me._txtOBJIDMAY.TextChanged, AddressOf Me.txtOBJIDMAY_TextChanged
				End If
				Me._txtOBJIDMAY = value
				flag = Me._txtOBJIDMAY IsNot Nothing
				If flag Then
					AddHandler Me._txtOBJIDMAY.TextChanged, AddressOf Me.txtOBJIDMAY_TextChanged
				End If
			End Set
		End Property

		' Token: 0x17000A04 RID: 2564
		' (get) Token: 0x06001D5C RID: 7516 RVA: 0x0016ACC4 File Offset: 0x00168EC4
		' (set) Token: 0x06001D5D RID: 7517 RVA: 0x0016ACDC File Offset: 0x00168EDC
		Friend Overridable Property btnTestPrint As Button
			<DebuggerNonUserCode()>
			Get
				Return Me._btnTestPrint
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim flag As Boolean = Me._btnTestPrint IsNot Nothing
				If flag Then
					RemoveHandler Me._btnTestPrint.Click, AddressOf Me.btnTestPrint_Click
				End If
				Me._btnTestPrint = value
				flag = Me._btnTestPrint IsNot Nothing
				If flag Then
					AddHandler Me._btnTestPrint.Click, AddressOf Me.btnTestPrint_Click
				End If
			End Set
		End Property

		' Token: 0x17000A05 RID: 2565
		' (get) Token: 0x06001D5E RID: 7518 RVA: 0x0016AD48 File Offset: 0x00168F48
		' (set) Token: 0x06001D5F RID: 7519 RVA: 0x00006168 File Offset: 0x00004368
		Friend Overridable Property TableLayoutPanel1 As TableLayoutPanel
			<DebuggerNonUserCode()>
			Get
				Return Me._TableLayoutPanel1
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TableLayoutPanel)
				Me._TableLayoutPanel1 = value
			End Set
		End Property

		' Token: 0x17000A06 RID: 2566
		' (get) Token: 0x06001D60 RID: 7520 RVA: 0x0016AD60 File Offset: 0x00168F60
		' (set) Token: 0x06001D61 RID: 7521 RVA: 0x0016AD78 File Offset: 0x00168F78
		Private Overridable Property mbdsSource As BindingSource
			<DebuggerNonUserCode()>
			Get
				Return Me._mbdsSource
			End Get
			<DebuggerNonUserCode()>
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As BindingSource)
				Dim flag As Boolean = Me._mbdsSource IsNot Nothing
				If flag Then
					RemoveHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
				Me._mbdsSource = value
				flag = Me._mbdsSource IsNot Nothing
				If flag Then
					AddHandler Me._mbdsSource.PositionChanged, AddressOf Me.mbdsSource_PositionChanged
				End If
			End Set
		End Property

		' Token: 0x17000A07 RID: 2567
		' (get) Token: 0x06001D62 RID: 7522 RVA: 0x0016ADE4 File Offset: 0x00168FE4
		' (set) Token: 0x06001D63 RID: 7523 RVA: 0x00006172 File Offset: 0x00004372
		Public Property pblnIsOK As Boolean
			Get
				Return Me.mblnIsOK
			End Get
			Set(value As Boolean)
				Me.mblnIsOK = value
			End Set
		End Property

		' Token: 0x17000A08 RID: 2568
		' (get) Token: 0x06001D64 RID: 7524 RVA: 0x0016ADFC File Offset: 0x00168FFC
		' (set) Token: 0x06001D65 RID: 7525 RVA: 0x0000617D File Offset: 0x0000437D
		Public Property pStrOBJNAME As String
			Get
				Return Me.mStrOBJNAME
			End Get
			Set(value As String)
				Me.mStrOBJNAME = value
			End Set
		End Property

		' Token: 0x17000A09 RID: 2569
		' (get) Token: 0x06001D66 RID: 7526 RVA: 0x0016AE14 File Offset: 0x00169014
		' (set) Token: 0x06001D67 RID: 7527 RVA: 0x00006188 File Offset: 0x00004388
		Public Property pStrOBJID As String
			Get
				Return Me.mStrOBJID
			End Get
			Set(value As String)
				Me.mStrOBJID = value
			End Set
		End Property

		' Token: 0x17000A0A RID: 2570
		' (get) Token: 0x06001D68 RID: 7528 RVA: 0x0016AE2C File Offset: 0x0016902C
		' (set) Token: 0x06001D69 RID: 7529 RVA: 0x00006193 File Offset: 0x00004393
		Public Property pBytOpen_From_Menu As Byte
			Get
				Return Me.mBytOpen_FromMenu
			End Get
			Set(value As Byte)
				Me.mBytOpen_FromMenu = value
			End Set
		End Property

		' Token: 0x06001D6A RID: 7530 RVA: 0x0016AE44 File Offset: 0x00169044
		Private Sub btnSelect_Click(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.dgvData.SelectedRows.Count > 0
				If flag Then
					Me.mStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
					Me.mStrOBJNAME = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				Else
					Me.mStrOBJID = ""
					Me.mStrOBJNAME = ""
				End If
				Me.mblnIsOK = True
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelect_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D6B RID: 7531 RVA: 0x0016AF94 File Offset: 0x00169194
		Private Sub btnLast_Click(sender As Object, e As EventArgs)
			Try
				' The following expression was wrapped in a checked-expression
				Me.mbdsSource.Position = Me.mbdsSource.Count - 1
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnLast_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D6C RID: 7532 RVA: 0x0016B064 File Offset: 0x00169264
		Private Sub btnNext_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position < Me.mbdsSource.Count - 1
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position += 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D6D RID: 7533 RVA: 0x0016B154 File Offset: 0x00169354
		Private Sub btnPrevious_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				Dim position As Integer = Me.mbdsSource.Position
				Dim flag As Boolean = position > 0
				If flag Then
					Dim mbdsSource As BindingSource = Me.mbdsSource
					mbdsSource.Position -= 1
					Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPrevious_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D6E RID: 7534 RVA: 0x0016B238 File Offset: 0x00169438
		Private Sub btnFirst_Click(sender As Object, e As EventArgs)
			Try
				Me.mbdsSource.Position = 0
				Me.dgvData.CurrentCell = Me.dgvData(0, Me.mbdsSource.Position)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFirst_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D6F RID: 7535 RVA: 0x0016B2FC File Offset: 0x001694FC
		Private Sub frmDMMAYINBEP1_FormClosing(sender As Object, e As FormClosingEventArgs)
			Try
				Me.sClear_Form()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAYINBEP1_FormClosing ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D70 RID: 7536 RVA: 0x0016B394 File Offset: 0x00169594
		Private Function fGetData_4Filter() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mclsTbDMMAY = New clsConnect(mdlVariable.gStrConISDANHMUC, "DMMAY")
				Dim flag As Boolean = Me.mclsTbDMMAY IsNot Nothing
				If flag Then
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Filter ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001D71 RID: 7537 RVA: 0x0016B450 File Offset: 0x00169650
		Private Sub frmDMMAYINBEP1_Load(sender As Object, e As EventArgs)
			Try
				Dim b As Byte = Me.fInitCaption()
				Dim flag As Boolean = b <> 0
				If flag Then
					b = Me.fInitForm()
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Filter()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
				End If
				flag = b <> 0
				If flag Then
					b = Me.fInitGrid()
				End If
				flag = b <> 0
				If flag Then
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - frmDMMAYINBEP1_Load ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D72 RID: 7538 RVA: 0x0016B59C File Offset: 0x0016979C
		Private Sub mbdsSource_PositionChanged(sender As Object, e As EventArgs)
			Try
				Dim flag As Boolean = Me.mbdsSource.Count = 0
				If flag Then
					Dim b As Byte = Me.fDisableButton(True)
				Else
					Dim b As Byte = Me.fDisableButton(False)
					Dim mbdsSource As BindingSource = Me.mbdsSource
					Me.lblPosition.Text = (mbdsSource.Position + 1).ToString() + " / " + mbdsSource.Count.ToString()
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - mbdsSource_PositionChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D73 RID: 7539 RVA: 0x0016B6A4 File Offset: 0x001698A4
		Private Sub btnExit_Click(sender As Object, e As EventArgs)
			Try
				Me.mblnIsOK = False
				Me.Close()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnExit_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D74 RID: 7540 RVA: 0x0016B744 File Offset: 0x00169944
		Private Sub btnAdd_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINBEP As frmDMMAYINBEP2 = New frmDMMAYINBEP2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				frmDMMAYINBEP.pbytFromStatus = 1
				frmDMMAYINBEP.pStrLoaiMayin = Conversions.ToString(0)
				Dim flag As Boolean = Me.mbdsSource.Count > 0
				If flag Then
					frmDMMAYINBEP.pStrMAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				End If
				frmDMMAYINBEP.ShowDialog()
				flag = frmDMMAYINBEP.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMMAYINBEP.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAdd_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMMAYINBEP.Dispose()
			End Try
		End Sub

		' Token: 0x06001D75 RID: 7541 RVA: 0x0016B934 File Offset: 0x00169B34
		Private Sub btnAddDefault_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINBEP As frmDMMAYINBEP2 = New frmDMMAYINBEP2()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Try
				Dim frmDMMAYINBEP2 As frmDMMAYINBEP2 = frmDMMAYINBEP
				frmDMMAYINBEP2.pbytFromStatus = 2
				frmDMMAYINBEP2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMMAYINBEP2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMMAYINBEP2.pStrMAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINBEP2.pStrLoaiMayin = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("KIND").Value, ""))
				frmDMMAYINBEP2.pStrCOMNAME = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("COMNAME").Value, ""))
				frmDMMAYINBEP2.pStrBAULDRATE = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BAUDRATE").Value, ""))
				frmDMMAYINBEP2.pStrDATABIT = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DATABITS").Value, ""))
				frmDMMAYINBEP2.pStrPARITYBIT = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PARITYBITS").Value, ""))
				frmDMMAYINBEP2.pStrSTOPBIT = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("STOPBITS").Value, ""))
				frmDMMAYINBEP2.pStrFLOWCONTROL = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FLOWCONTROL").Value, ""))
				frmDMMAYINBEP2.pbytLTENHHFORMAT = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("LTENHHFORMAT").Value)
				frmDMMAYINBEP2.pbytDKSOLUONG = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("DKSOLUONG").Value)
				frmDMMAYINBEP2.txtTimeOut.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TIMEOUT").Value, ""))
				frmDMMAYINBEP2.txtPrintCount.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PRINTCOUNT").Value, ""))
				frmDMMAYINBEP2.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMMAYINBEP2.txtMAMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINBEP2.txtTENMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAY").Value, ""))
				frmDMMAYINBEP2.TxtMAMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAYCALL").Value, ""))
				frmDMMAYINBEP2.txtTENMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAYCALL").Value, ""))
				frmDMMAYINBEP2.chkLSHARE.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LSHARE").Value, ""))
				frmDMMAYINBEP2.ChkLSHOWBILL.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LSHOWBILL").Value, ""))
				frmDMMAYINBEP2.ChkLBOLD.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LBOLD").Value, ""))
				frmDMMAYINBEP2.ChkLSHOWPRICE.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LSHOWPRICE").Value, ""))
				frmDMMAYINBEP2.chkCus.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWCUSTOMER").Value)
				frmDMMAYINBEP2.chkService.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWSERVICE").Value)
				frmDMMAYINBEP2.ckhCashier.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWCASHIER").Value)
				frmDMMAYINBEP2.chkKhu.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWKHU").Value)
				frmDMMAYINBEP2.chkTable.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWTABLE").Value)
				frmDMMAYINBEP2.chkDate.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWDATE").Value)
				frmDMMAYINBEP2.chkOrder.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWORDER").Value)
				frmDMMAYINBEP2.chkSplit.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSPLIT").Value)
				frmDMMAYINBEP2.chkLCALL.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LCALL").Value)
				frmDMMAYINBEP2.chkLSHOWLIEN.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWLIEN").Value)
				frmDMMAYINBEP2.txtPrintWidth.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("PRINTWIDTH").Value)
				frmDMMAYINBEP2.txtTOP.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TOPMARGIN").Value)
				frmDMMAYINBEP2.txtLEFT.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("LEFTMARGIN").Value)
				frmDMMAYINBEP2.txtBottom.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("BOTTOMMARGIN").Value)
				frmDMMAYINBEP2.txtRight.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("RIGHTMARGIN").Value)
				frmDMMAYINBEP2.chkLKITREMARK1LINE.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LKITREMARK1LINE").Value)
				frmDMMAYINBEP2.chkDVT.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWDVT").Value)
				frmDMMAYINBEP2.txtBEPFONT1.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FONT1").Value)
				frmDMMAYINBEP2.txtBEPFONT2.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FONT2").Value)
				frmDMMAYINBEP2.txtBEPFONT3.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FONT3").Value)
				frmDMMAYINBEP2.txtBEPSIZE1.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("SIZE1").Value)
				frmDMMAYINBEP2.txtBEPSIZE2.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("SIZE2").Value)
				frmDMMAYINBEP2.txtBEPSIZE3.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("SIZE3").Value)
				frmDMMAYINBEP2.chkBEPB1.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LBOLD1").Value)
				frmDMMAYINBEP2.chkBEPB2.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LBOLD2").Value)
				frmDMMAYINBEP2.chkBEPB3.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LBOLD3").Value)
				frmDMMAYINBEP2.chkBEPI1.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LITALIC1").Value)
				frmDMMAYINBEP2.chkBEPI2.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LITALIC2").Value)
				frmDMMAYINBEP2.chkBEPI3.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LITALIC3").Value)
				frmDMMAYINBEP2.chkLCach1Dong.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LCACH1DONG").Value)
				frmDMMAYINBEP2.chkSTT.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWSTT").Value)
				frmDMMAYINBEP2.chkLSHOWTITLE.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWTITLE").Value)
				frmDMMAYINBEP2.chkSplitSL1.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSPLITSL1").Value)
				frmDMMAYINBEP2.chkLGachSLAm.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LGACHSLAM").Value)
				frmDMMAYINBEP2.chkLPrice1Line.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRICE1LINE").Value)
				frmDMMAYINBEP2.chkLSHOWMAHH.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRINTMAHH").Value)
				frmDMMAYINBEP2.chkLShowSLCombo.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWSLCOMBO").Value)
				frmDMMAYINBEP2.chkLInChuyenBan.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRINTMOVETBL").Value)
				frmDMMAYINBEP2.chkLSHOWLYDOXOA.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRINTLYDOXOA").Value)
				frmDMMAYINBEP2.chkLInChuyenMon.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LINCHUYENMON").Value)
				frmDMMAYINBEP2.chkTongSL.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWTONGSL").Value)
				frmDMMAYINBEP2.chkLShowLogo.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LShowLogo").Value)
				frmDMMAYINBEP2.chkLSortNH.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSortNH").Value)
				frmDMMAYINBEP2.chkLShowSLMain.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LShowSLMain").Value)
				frmDMMAYINBEP2.chkLShowCus.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LShowCus").Value)
				frmDMMAYINBEP2.chkSTTPerItem.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSTTPERITEM").Value)
				frmDMMAYINBEP2.chkSplitMoveTBL.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSPLITMOVETBL").Value)
				Try
					frmDMMAYINBEP2.picpreview.BackgroundImage = mdlUIForm.gfReadImage(CType(Me.dgvData.CurrentRow.Cells("Logo").Value, Byte()))
				Catch ex As Exception
				End Try
				frmDMMAYINBEP.ShowDialog()
				Dim flag As Boolean = frmDMMAYINBEP.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMMAYINBEP.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
					Me.btnAddDefault_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnAdd_Click ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				sqlCommand.Dispose()
				clsConnect.Dispose()
				frmDMMAYINBEP.Dispose()
			End Try
		End Sub

		' Token: 0x06001D76 RID: 7542 RVA: 0x0016C93C File Offset: 0x0016AB3C
		Private Sub btnModify_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINBEP As frmDMMAYINBEP2 = New frmDMMAYINBEP2()
			Try
				Dim frmDMMAYINBEP2 As frmDMMAYINBEP2 = frmDMMAYINBEP
				frmDMMAYINBEP2.pbytFromStatus = 3
				frmDMMAYINBEP2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMMAYINBEP2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMMAYINBEP2.pStrMAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINBEP2.pStrLoaiMayin = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("KIND").Value, ""))
				frmDMMAYINBEP2.pStrCOMNAME = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("COMNAME").Value, ""))
				frmDMMAYINBEP2.pStrBAULDRATE = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BAUDRATE").Value, ""))
				frmDMMAYINBEP2.pStrDATABIT = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DATABITS").Value, ""))
				frmDMMAYINBEP2.pStrPARITYBIT = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PARITYBITS").Value, ""))
				frmDMMAYINBEP2.pStrSTOPBIT = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("STOPBITS").Value, ""))
				frmDMMAYINBEP2.pStrFLOWCONTROL = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FLOWCONTROL").Value, ""))
				frmDMMAYINBEP2.pbytLTENHHFORMAT = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("LTENHHFORMAT").Value)
				frmDMMAYINBEP2.pbytDKSOLUONG = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("DKSOLUONG").Value)
				frmDMMAYINBEP2.txtTimeOut.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TIMEOUT").Value, ""))
				frmDMMAYINBEP2.txtPrintCount.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PRINTCOUNT").Value, ""))
				frmDMMAYINBEP2.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMMAYINBEP2.txtMAMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINBEP2.txtTENMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAY").Value, ""))
				frmDMMAYINBEP2.TxtMAMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAYCALL").Value, ""))
				frmDMMAYINBEP2.txtTENMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAYCALL").Value, ""))
				frmDMMAYINBEP2.chkLSHARE.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LSHARE").Value, ""))
				frmDMMAYINBEP2.ChkLSHOWBILL.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LSHOWBILL").Value, ""))
				frmDMMAYINBEP2.ChkLBOLD.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LBOLD").Value, ""))
				frmDMMAYINBEP2.ChkLSHOWPRICE.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LSHOWPRICE").Value, ""))
				frmDMMAYINBEP2.chkCus.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWCUSTOMER").Value)
				frmDMMAYINBEP2.chkService.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWSERVICE").Value)
				frmDMMAYINBEP2.ckhCashier.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWCASHIER").Value)
				frmDMMAYINBEP2.chkKhu.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWKHU").Value)
				frmDMMAYINBEP2.chkTable.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWTABLE").Value)
				frmDMMAYINBEP2.chkDate.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWDATE").Value)
				frmDMMAYINBEP2.chkOrder.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWORDER").Value)
				frmDMMAYINBEP2.chkSplit.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSPLIT").Value)
				frmDMMAYINBEP2.chkLCALL.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LCALL").Value)
				frmDMMAYINBEP2.chkLSHOWLIEN.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWLIEN").Value)
				frmDMMAYINBEP2.txtPrintWidth.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("PRINTWIDTH").Value)
				frmDMMAYINBEP2.txtTOP.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TOPMARGIN").Value)
				frmDMMAYINBEP2.txtLEFT.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("LEFTMARGIN").Value)
				frmDMMAYINBEP2.txtBottom.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("BOTTOMMARGIN").Value)
				frmDMMAYINBEP2.txtRight.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("RIGHTMARGIN").Value)
				frmDMMAYINBEP2.chkLKITREMARK1LINE.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LKITREMARK1LINE").Value)
				frmDMMAYINBEP2.chkDVT.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWDVT").Value)
				frmDMMAYINBEP2.txtBEPFONT1.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FONT1").Value)
				frmDMMAYINBEP2.txtBEPFONT2.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FONT2").Value)
				frmDMMAYINBEP2.txtBEPFONT3.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("FONT3").Value)
				frmDMMAYINBEP2.txtBEPSIZE1.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("SIZE1").Value)
				frmDMMAYINBEP2.txtBEPSIZE2.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("SIZE2").Value)
				frmDMMAYINBEP2.txtBEPSIZE3.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("SIZE3").Value)
				frmDMMAYINBEP2.chkBEPB1.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LBOLD1").Value)
				frmDMMAYINBEP2.chkBEPB2.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LBOLD2").Value)
				frmDMMAYINBEP2.chkBEPB3.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LBOLD3").Value)
				frmDMMAYINBEP2.chkBEPI1.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LITALIC1").Value)
				frmDMMAYINBEP2.chkBEPI2.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LITALIC2").Value)
				frmDMMAYINBEP2.chkBEPI3.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LITALIC3").Value)
				frmDMMAYINBEP2.chkLCach1Dong.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LCACH1DONG").Value)
				frmDMMAYINBEP2.chkSTT.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWSTT").Value)
				frmDMMAYINBEP2.chkLSHOWTITLE.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWTITLE").Value)
				frmDMMAYINBEP2.chkSplitSL1.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSPLITSL1").Value)
				frmDMMAYINBEP2.chkLGachSLAm.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LGACHSLAM").Value)
				frmDMMAYINBEP2.chkLPrice1Line.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRICE1LINE").Value)
				frmDMMAYINBEP2.chkLSHOWMAHH.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRINTMAHH").Value)
				frmDMMAYINBEP2.chkLShowSLCombo.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWSLCOMBO").Value)
				frmDMMAYINBEP2.chkLInChuyenBan.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRINTMOVETBL").Value)
				frmDMMAYINBEP2.chkLSHOWLYDOXOA.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRINTLYDOXOA").Value)
				frmDMMAYINBEP2.chkLInChuyenMon.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LINCHUYENMON").Value)
				frmDMMAYINBEP2.chkTongSL.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWTONGSL").Value)
				frmDMMAYINBEP2.chkLShowLogo.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LShowLogo").Value)
				frmDMMAYINBEP2.chkLSortNH.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSortNH").Value)
				frmDMMAYINBEP2.chkLShowSLMain.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LShowSLMain").Value)
				frmDMMAYINBEP2.chkLShowCus.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LShowCus").Value)
				frmDMMAYINBEP2.chkSTTPerItem.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSTTPERITEM").Value)
				frmDMMAYINBEP2.chkSplitMoveTBL.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSPLITMOVETBL").Value)
				Try
					frmDMMAYINBEP2.picpreview.BackgroundImage = mdlUIForm.gfReadImage(CType(Me.dgvData.CurrentRow.Cells("Logo").Value, Byte()))
				Catch ex As Exception
				End Try
				frmDMMAYINBEP.ShowDialog()
				Dim flag As Boolean = frmDMMAYINBEP.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource.Position = Me.mbdsSource.Find("OBJID", frmDMMAYINBEP.pStrFilter)
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnModify_Click ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAYINBEP.Dispose()
			End Try
		End Sub

		' Token: 0x06001D77 RID: 7543 RVA: 0x0016D904 File Offset: 0x0016BB04
		Private Sub btnDelete_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINBEP As frmDMMAYINBEP2 = New frmDMMAYINBEP2()
			Try
				Dim frmDMMAYINBEP2 As frmDMMAYINBEP2 = frmDMMAYINBEP
				frmDMMAYINBEP2.pbytFromStatus = 4
				frmDMMAYINBEP2.txtOBJID.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMMAYINBEP2.txtOBJNAME.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJNAME").Value, ""))
				frmDMMAYINBEP2.pStrMAY = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINBEP2.pStrLoaiMayin = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("KIND").Value, ""))
				frmDMMAYINBEP2.pStrCOMNAME = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("COMNAME").Value, ""))
				frmDMMAYINBEP2.pStrBAULDRATE = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BAUDRATE").Value, ""))
				frmDMMAYINBEP2.pStrDATABIT = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DATABITS").Value, ""))
				frmDMMAYINBEP2.pStrPARITYBIT = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PARITYBITS").Value, ""))
				frmDMMAYINBEP2.pStrSTOPBIT = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("STOPBITS").Value, ""))
				frmDMMAYINBEP2.pStrFLOWCONTROL = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("FLOWCONTROL").Value, ""))
				frmDMMAYINBEP2.pbytLTENHHFORMAT = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("LTENHHFORMAT").Value)
				frmDMMAYINBEP2.pbytDKSOLUONG = Conversions.ToByte(Me.dgvData.CurrentRow.Cells("DKSOLUONG").Value)
				frmDMMAYINBEP2.txtTimeOut.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TIMEOUT").Value, ""))
				frmDMMAYINBEP2.txtPrintCount.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PRINTCOUNT").Value, ""))
				frmDMMAYINBEP2.txtRemark.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("REMARK").Value, ""))
				frmDMMAYINBEP2.txtMAMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAY").Value, ""))
				frmDMMAYINBEP2.txtTENMAY.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAY").Value, ""))
				frmDMMAYINBEP2.TxtMAMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("MAMAYCALL").Value, ""))
				frmDMMAYINBEP2.txtTENMAYCALL.Text = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("TENMAYCALL").Value, ""))
				frmDMMAYINBEP2.chkLSHARE.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LSHARE").Value, ""))
				frmDMMAYINBEP2.ChkLSHOWBILL.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LSHOWBILL").Value, ""))
				frmDMMAYINBEP2.ChkLBOLD.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LBOLD").Value, ""))
				frmDMMAYINBEP2.ChkLSHOWPRICE.Checked = Conversions.ToBoolean(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("LSHOWPRICE").Value, ""))
				frmDMMAYINBEP2.chkCus.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWCUSTOMER").Value)
				frmDMMAYINBEP2.chkService.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWSERVICE").Value)
				frmDMMAYINBEP2.ckhCashier.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWCASHIER").Value)
				frmDMMAYINBEP2.chkKhu.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWKHU").Value)
				frmDMMAYINBEP2.chkTable.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWTABLE").Value)
				frmDMMAYINBEP2.chkDate.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWDATE").Value)
				frmDMMAYINBEP2.chkOrder.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWORDER").Value)
				frmDMMAYINBEP2.chkSplit.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSPLIT").Value)
				frmDMMAYINBEP2.chkLCALL.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LCALL").Value)
				frmDMMAYINBEP2.chkLSHOWLIEN.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWLIEN").Value)
				frmDMMAYINBEP2.txtPrintWidth.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("PRINTWIDTH").Value)
				frmDMMAYINBEP2.txtTOP.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("TOPMARGIN").Value)
				frmDMMAYINBEP2.txtLEFT.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("LEFTMARGIN").Value)
				frmDMMAYINBEP2.txtBottom.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("BOTTOMMARGIN").Value)
				frmDMMAYINBEP2.txtRight.Text = Conversions.ToString(Me.dgvData.CurrentRow.Cells("RIGHTMARGIN").Value)
				frmDMMAYINBEP2.chkLKITREMARK1LINE.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LKITREMARK1LINE").Value)
				frmDMMAYINBEP2.chkLSHOWTITLE.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWTITLE").Value)
				frmDMMAYINBEP2.chkSplitSL1.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSPLITSL1").Value)
				frmDMMAYINBEP2.chkLGachSLAm.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LGACHSLAM").Value)
				frmDMMAYINBEP2.chkLPrice1Line.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRICE1LINE").Value)
				frmDMMAYINBEP2.chkLShowSLCombo.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWSLCOMBO").Value)
				frmDMMAYINBEP2.chkLInChuyenBan.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRINTMOVETBL").Value)
				frmDMMAYINBEP2.chkLSHOWLYDOXOA.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LPRINTLYDOXOA").Value)
				frmDMMAYINBEP2.chkLInChuyenMon.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LINCHUYENMON").Value)
				frmDMMAYINBEP2.chkTongSL.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSHOWTONGSL").Value)
				frmDMMAYINBEP2.chkLShowLogo.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LShowLogo").Value)
				frmDMMAYINBEP2.chkLSortNH.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSortNH").Value)
				frmDMMAYINBEP2.chkLShowSLMain.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LShowSLMain").Value)
				frmDMMAYINBEP2.chkLShowCus.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LShowCus").Value)
				frmDMMAYINBEP2.chkSTTPerItem.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSTTPERITEM").Value)
				frmDMMAYINBEP2.chkSplitMoveTBL.Checked = Conversions.ToBoolean(Me.dgvData.CurrentRow.Cells("LSPLITMOVETBL").Value)
				Try
					frmDMMAYINBEP2.picpreview.BackgroundImage = mdlUIForm.gfReadImage(CType(Me.dgvData.CurrentRow.Cells("Logo").Value, Byte()))
				Catch ex As Exception
				End Try
				frmDMMAYINBEP.ShowDialog()
				Dim flag As Boolean = frmDMMAYINBEP.pbytSuccess = 0
				If Not flag Then
					Dim b As Byte = Me.fGetData_4Grid()
					flag = b = 0
					If flag Then
						Interaction.MsgBox(Me.mArrStrFrmMess(15), MsgBoxStyle.Critical, Nothing)
					End If
					flag = b <> 0
					If flag Then
						b = Me.fInitGrid()
					End If
					flag = b <> 0
					If flag Then
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex2 As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnDelete_Click ", ex2.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAYINBEP.Dispose()
			End Try
		End Sub

		' Token: 0x06001D78 RID: 7544 RVA: 0x0016E59C File Offset: 0x0016C79C
		Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs)
			Try
				Dim visible As Boolean = Me.btnSelect.Visible
				If visible Then
					Me.btnSelect_Click(RuntimeHelpers.GetObjectValue(sender), e)
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - dgvData_DoubleClick ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D79 RID: 7545 RVA: 0x0016E64C File Offset: 0x0016C84C
		Private Sub btnTestPrint_Click(sender As Object, e As EventArgs)
			Dim text As String = Me.mArrStrFrmMess(40)
			Dim text2 As String = Me.mArrStrFrmMess(41)
			Try
				Dim obj As Object = Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("KIND").Value, "")
				Dim flag As Boolean = Operators.ConditionalCompareObjectEqual(obj, "0", False)
				If flag Then
					Me.sTestPrintCOM80(text2, text)
				Else
					flag = Operators.ConditionalCompareObjectEqual(obj, "1", False)
					If flag Then
						Me.sTestPrintCOM80(text2, text)
					Else
						flag = Conversions.ToBoolean(If((Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "2", False)) OrElse Conversions.ToBoolean(Operators.CompareObjectEqual(obj, "8", False))), True, False))
						If flag Then
							Me.sTestPrintCOM80(text2, text)
						Else
							flag = Operators.ConditionalCompareObjectEqual(obj, "3", False)
							If flag Then
								Me.gsTestPrintDiver58(text2, text, "")
							Else
								flag = Operators.ConditionalCompareObjectEqual(obj, "4", False)
								If flag Then
									Me.gsTestPrintDiver58(text2, text, "")
								Else
									flag = Operators.ConditionalCompareObjectEqual(obj, "5", False)
									If flag Then
										Me.gsTestPrintDiver58(text2, text, "")
									Else
										flag = Operators.ConditionalCompareObjectEqual(obj, "6", False)
										If flag Then
											Me.gsTestPrintDiver58(text2, text, "")
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnTestPrint_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			End Try
		End Sub

		' Token: 0x06001D7A RID: 7546 RVA: 0x0016E840 File Offset: 0x0016CA40
		Private Sub btnFind_Click(sender As Object, e As EventArgs)
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim frmDMMAYINBEPKHU As frmDMMAYINBEPKHU = New frmDMMAYINBEPKHU()
			Try
				frmDMMAYINBEPKHU.pStrOBJID = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("OBJID").Value, ""))
				frmDMMAYINBEPKHU.ShowDialog()
				Dim flag As Boolean = frmDMMAYINBEPKHU.pbytSuccess = 0
				If flag Then
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFind_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAYINBEPKHU.Dispose()
			End Try
		End Sub

		' Token: 0x06001D7B RID: 7547 RVA: 0x0016E94C File Offset: 0x0016CB4C
		Private Sub txtOBJIDMAY_TextChanged(sender As Object, e As EventArgs)
			Dim array As DataColumn() = New DataColumn(0) {}
			Try
				Dim flag As Boolean = Me.mclsTbDMMAY Is Nothing
				If Not flag Then
					Me.btnCancelFilter.Visible = False
					array(0) = Me.mclsTbDMMAY.Columns("OBJID")
					Me.mclsTbDMMAY.PrimaryKey = array
					Dim dataRow As DataRow = Me.mclsTbDMMAY.Rows.Find(Strings.Trim(Me.txtOBJIDMAY.Text))
					flag = dataRow IsNot Nothing
					If flag Then
						Me.txtOBJNAMEMAY.Text = dataRow("OBJNAME").ToString()
						Me.mbdsSource.Filter = "MAMAY like '" + Strings.Replace(Strings.Trim(Me.txtOBJIDMAY.Text), "'", "''", 1, -1, CompareMethod.Binary) + "'"
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Else
						Me.txtOBJNAMEMAY.Text = ""
						Me.mbdsSource.RemoveFilter()
						Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					End If
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - txtOBJIDMAY_TextChanged ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D7C RID: 7548 RVA: 0x0016EB10 File Offset: 0x0016CD10
		Private Sub btnFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINBEP As frmDMMAYINBEP2 = New frmDMMAYINBEP2()
			Try
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				frmDMMAYINBEP.pbytFromStatus = 5
				frmDMMAYINBEP.ShowDialog()
				Dim flag As Boolean = frmDMMAYINBEP.pbytSuccess = 0
				If Not flag Then
					Me.btnCancelFilter.Visible = True
					Me.mbdsSource.Filter = frmDMMAYINBEP.pStrFilter
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.btnCancelFilter.Enabled = True
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAYINBEP.Dispose()
			End Try
		End Sub

		' Token: 0x06001D7D RID: 7549 RVA: 0x0016EC28 File Offset: 0x0016CE28
		Private Sub btnCancelFilter_Click(sender As Object, e As EventArgs)
			Dim frmDMMAYINBEP As frmDMMAYINBEP2 = New frmDMMAYINBEP2()
			Try
				Me.mbdsSource.RemoveFilter()
				Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
				Me.btnCancelFilter.Visible = False
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFilter_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				frmDMMAYINBEP.Dispose()
			End Try
		End Sub

		' Token: 0x06001D7E RID: 7550 RVA: 0x0016ECF0 File Offset: 0x0016CEF0
		Private Sub btnFindNext_Click(sender As Object, e As EventArgs)
			Dim flag As Boolean = Me.marrDrFind.Length = 1
			If Not flag Then
				Try
					Dim num As Integer = Me.mintFindLastPos
					Dim num2 As Integer = Me.marrDrFind.Length
					Dim num3 As Integer = num
					Dim num6 As Integer
					While True
						Dim num4 As Integer = num3
						Dim num5 As Integer = num2
						If num4 > num5 Then
							GoTo IL_00CB
						End If
						num6 = Me.mbdsSource.Find("OBJID", RuntimeHelpers.GetObjectValue(Me.marrDrFind(num3)("OBJID")))
						flag = num6 <> -1
						If flag Then
							Exit For
						End If
						num3 += 1
					End While
					Me.dgvData.CurrentCell = Me.dgvData(0, num6)
					Me.mbdsSource_PositionChanged(RuntimeHelpers.GetObjectValue(sender), e)
					Me.mintFindLastPos += 1
					flag = Me.mintFindLastPos = Me.marrDrFind.Length
					If flag Then
						Me.mintFindLastPos = 0
					End If
					IL_00CB:
				Catch ex As Exception
					Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnFindNext_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
				Finally
				End Try
			End If
		End Sub

		' Token: 0x06001D7F RID: 7551 RVA: 0x0016EE6C File Offset: 0x0016D06C
		Private Sub btnPreview_Click(sender As Object, e As EventArgs)
			Try
				Dim text As String = Strings.Trim(Me.txtOBJIDMAY.Text)
				Dim b As Byte = Me.fPrintDMMAYINBEP(text)
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnPreview_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D80 RID: 7552 RVA: 0x0016EF18 File Offset: 0x0016D118
		Private Sub btnSelectMAY_Click(sender As Object, e As EventArgs)
			Try
				Dim frmDMMAY As frmDMMAY1 = New frmDMMAY1()
				frmDMMAY.pBytOpen_From_Menu = 7
				frmDMMAY.btnSelect.Visible = True
				frmDMMAY.ShowDialog()
				Me.txtOBJIDMAY.Text = Conversions.ToString(Interaction.IIf(Operators.CompareString(frmDMMAY.pStrOBJID, "", False) = 0, Me.txtOBJIDMAY.Text, frmDMMAY.pStrOBJID))
				frmDMMAY.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - btnSelectMAY_Click ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D81 RID: 7553 RVA: 0x0016F010 File Offset: 0x0016D210
		Private Function fInitGrid() As Byte
			Dim dataGridViewCellStyle As DataGridViewCellStyle = New DataGridViewCellStyle()
			Dim b As Byte
			Try
				b = 0
				Dim dgvData As DataGridView = Me.dgvData
				dgvData.MultiSelect = False
				dgvData.RowHeadersVisible = False
				dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
				dgvData.AlternatingRowsDefaultCellStyle = New DataGridViewCellStyle() With { .BackColor = mdlVariable.gobjcloOddRowGrid }
				dgvData.Columns("OBJID").HeaderText = Strings.Trim(Me.mArrStrFrmMess(18))
				dgvData.Columns("OBJID").Width = 50
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("OBJID").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("OBJNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(19))
				dgvData.Columns("OBJNAME").Width = Me.Width - 490 - Me.grpControl.Width
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("OBJNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("COMNAME").HeaderText = Strings.Trim(Me.mArrStrFrmMess(26))
				dgvData.Columns("COMNAME").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("COMNAME").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("BAUDRATE").HeaderText = Strings.Trim(Me.mArrStrFrmMess(27))
				dgvData.Columns("BAUDRATE").Width = 80
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("BAUDRATE").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("DATABITS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(28))
				dgvData.Columns("DATABITS").Width = 0
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("DATABITS").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("PARITYBITS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(29))
				dgvData.Columns("PARITYBITS").Width = 0
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("PARITYBITS").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("STOPBITS").HeaderText = Strings.Trim(Me.mArrStrFrmMess(30))
				dgvData.Columns("STOPBITS").Width = 0
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("STOPBITS").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("FLOWCONTROL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(31))
				dgvData.Columns("FLOWCONTROL").Width = 0
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("FLOWCONTROL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TIMEOUT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(32))
				dgvData.Columns("TIMEOUT").Width = 0
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("TIMEOUT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("PRINTCOUNT").HeaderText = Strings.Trim(Me.mArrStrFrmMess(33))
				dgvData.Columns("PRINTCOUNT").Width = 0
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
				dgvData.Columns("PRINTCOUNT").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("REMARK").HeaderText = Strings.Trim(Me.mArrStrFrmMess(34))
				dgvData.Columns("REMARK").Width = 0
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("REMARK").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENMAY").HeaderText = Strings.Trim(Me.mArrStrFrmMess(25))
				dgvData.Columns("TENMAY").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENMAY").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("TENMAYCALL").HeaderText = Strings.Trim(Me.mArrStrFrmMess(23))
				dgvData.Columns("TENMAYCALL").Width = 120
				dataGridViewCellStyle = New DataGridViewCellStyle()
				dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
				dgvData.Columns("TENMAYCALL").DefaultCellStyle = dataGridViewCellStyle
				dgvData.Columns("MAMAY").Visible = False
				dgvData.Columns("KIND").Visible = False
				dgvData.Columns("DATABITS").Visible = False
				dgvData.Columns("PARITYBITS").Visible = False
				dgvData.Columns("STOPBITS").Visible = False
				dgvData.Columns("FLOWCONTROL").Visible = False
				dgvData.Columns("TIMEOUT").Visible = False
				dgvData.Columns("PRINTCOUNT").Visible = False
				dgvData.Columns("REMARK").Visible = False
				dgvData.Columns("LBOLD").Visible = False
				dgvData.Columns("LSHARE").Visible = False
				dgvData.Columns("LSHOWBILL").Visible = False
				dgvData.Columns("LSHOWPRICE").Visible = False
				dgvData.Columns("LSHOWCUSTOMER").Visible = False
				dgvData.Columns("LSHOWSERVICE").Visible = False
				dgvData.Columns("LSHOWCASHIER").Visible = False
				dgvData.Columns("LSHOWKHU").Visible = False
				dgvData.Columns("LSHOWTABLE").Visible = False
				dgvData.Columns("LSHOWDATE").Visible = False
				dgvData.Columns("LSHOWORDER").Visible = False
				dgvData.Columns("LSPLIT").Visible = False
				dgvData.Columns("MAMAYCALL").Visible = False
				dgvData.Columns("PRINTWIDTH").Visible = False
				dgvData.Columns("LCALL").Visible = False
				dgvData.Columns("LTENHHFORMAT").Visible = False
				dgvData.Columns("LSHOWLIEN").Visible = False
				dgvData.Columns("TOPMARGIN").Visible = False
				dgvData.Columns("LEFTMARGIN").Visible = False
				dgvData.Columns("BOTTOMMARGIN").Visible = False
				dgvData.Columns("RIGHTMARGIN").Visible = False
				dgvData.Columns("LKITREMARK1LINE").Visible = False
				dgvData.Columns("DKSOLUONG").Visible = False
				dgvData.Columns("LSHOWDVT").Visible = False
				dgvData.Columns("FONT1").Visible = False
				dgvData.Columns("FONT2").Visible = False
				dgvData.Columns("FONT3").Visible = False
				dgvData.Columns("SIZE1").Visible = False
				dgvData.Columns("SIZE2").Visible = False
				dgvData.Columns("SIZE3").Visible = False
				dgvData.Columns("LBOLD1").Visible = False
				dgvData.Columns("LBOLD2").Visible = False
				dgvData.Columns("LBOLD3").Visible = False
				dgvData.Columns("LITALIC1").Visible = False
				dgvData.Columns("LITALIC2").Visible = False
				dgvData.Columns("LITALIC3").Visible = False
				dgvData.Columns("LCACH1DONG").Visible = False
				dgvData.Columns("LSHOWSTT").Visible = False
				dgvData.Columns("LSHOWTITLE").Visible = False
				dgvData.Columns("LSPLITSL1").Visible = False
				dgvData.Columns("LGACHSLAM").Visible = False
				dgvData.Columns("LPRICE1LINE").Visible = False
				dgvData.Columns("LPRINTMAHH").Visible = False
				dgvData.Columns("LSHOWSLCOMBO").Visible = False
				dgvData.Columns("LPRINTMOVETBL").Visible = False
				dgvData.Columns("LPRINTLYDOXOA").Visible = False
				dgvData.Columns("LINCHUYENMON").Visible = False
				dgvData.Columns("LSHOWTONGSL").Visible = False
				dgvData.Columns("LSHOWLOGO").Visible = False
				dgvData.Columns("LOGO").Visible = False
				dgvData.Columns("LSORTNH").Visible = False
				dgvData.Columns("LSHOWSLMAIN").Visible = False
				dgvData.Columns("LSHOWCUS").Visible = False
				dgvData.Columns("LSTTPERITEM").Visible = False
				dgvData.Columns("LSPLITMOVETBL").Visible = False
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitGrid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001D82 RID: 7554 RVA: 0x0016FC68 File Offset: 0x0016DE68
		Private Function fDisableButton(Optional pblnDisable As Boolean = True) As Byte
			Dim b As Byte
			Try
				b = 0
				Me.btnFirst.Enabled = Not pblnDisable
				Me.btnLast.Enabled = Not pblnDisable
				Me.btnPrevious.Enabled = Not pblnDisable
				Me.btnNext.Enabled = Not pblnDisable
				Me.lblPosition.Text = ""
				Me.btnAddDefault.Enabled = Not pblnDisable
				Me.btnModify.Enabled = Not pblnDisable
				Me.btnDelete.Enabled = Not pblnDisable
				Me.btnFilter.Enabled = Not pblnDisable
				Me.btnCancelFilter.Enabled = Not pblnDisable
				Me.btnFind.Enabled = Not pblnDisable
				Me.btnFindNext.Enabled = Not pblnDisable
				Me.btnPreview.Enabled = Not pblnDisable
				Me.btnTestPrint.Enabled = Not pblnDisable
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fDisableButton ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001D83 RID: 7555 RVA: 0x0016FDF8 File Offset: 0x0016DFF8
		Private Function fGetData_4Grid() As Byte
			Dim clsConnect As clsConnect = New clsConnect()
			Dim array As SqlParameter() = New SqlParameter(0) {}
			Dim b As Byte
			Try
				b = 0
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_FRMDMMAYINBEP_GET_ALL_DATA", num)
				Dim flag As Boolean = num = 1
				If flag Then
					Me.mbdsSource.DataSource = clsConnect
					Me.dgvData.DataSource = Me.mbdsSource
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fGetData_4Grid ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x06001D84 RID: 7556 RVA: 0x0016FEE8 File Offset: 0x0016E0E8
		Private Function fInitForm() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.CancelButton = Me.btnExit
				Me.KeyPreview = True
				Me.Dock = DockStyle.Fill
				Me.btnFindNext.Visible = False
				Me.btnCancelFilter.Visible = False
				Dim flag As Boolean = Me.mBytOpen_FromMenu = 8
				If flag Then
					Me.btnSelect.Visible = False
				End If
				flag = Not mdlVariable.gblnUpdateList And (Me.pBytOpen_From_Menu <> 8)
				If flag Then
					Me.btnAdd.Visible = False
					Me.btnAddDefault.Visible = False
					Me.btnModify.Visible = False
					Me.btnDelete.Visible = False
				End If
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitForm ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001D85 RID: 7557 RVA: 0x00170038 File Offset: 0x0016E238
		Private Function fInitCaption() As Byte
			Dim b As Byte
			Try
				b = 0
				Me.mArrStrFrmMess = mdlFile.gfReadFile_2Array(String.Concat(New String() { mdlVariable.gStrPathApp, "\DISPLAY\", mdlVariable.gStrLanguage, "\", Strings.UCase(Me.Name), ".TXT" }))
				mdlUIForm.gsSetCap_2Form(Me, Me.mArrStrFrmMess(2))
				mdlUIForm.gsSetfont_2Control(Me, Me.mArrStrFrmMess, Nothing, "")
				b = 1
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - fInitCaption ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
			Return b
		End Function

		' Token: 0x06001D86 RID: 7558 RVA: 0x00170144 File Offset: 0x0016E344
		Private Sub sClear_Form()
			Try
				Dim flag As Boolean = Me.mclsTbDMMAY IsNot Nothing
				If flag Then
					Me.mclsTbDMMAY.Dispose()
				End If
				Me.mbdsSource.Dispose()
				Me.mArrStrFrmMess = Nothing
				Me.Dispose()
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sClear_Form ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
			End Try
		End Sub

		' Token: 0x06001D87 RID: 7559 RVA: 0x0017020C File Offset: 0x0016E40C
		Private Sub sTestPrintCOM80(pstrStringHead As String, pstrStringBody As String)
			Dim serialPort As SerialPort = New SerialPort()
			serialPort.PortName = Conversions.ToString(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("COMNAME").Value, ""))
			serialPort.BaudRate = Conversions.ToInteger(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("BAUDRATE").Value, ""))
			serialPort.DataBits = Conversions.ToInteger(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("DATABITS").Value, ""))
			serialPort.Parity = CType(Conversions.ToInteger(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("PARITYBITS").Value, "")), Parity)
			serialPort.StopBits = CType(Conversions.ToInteger(Operators.ConcatenateObject(Me.dgvData.CurrentRow.Cells("STOPBITS").Value, "")), StopBits)
			Dim flag As Boolean = Not serialPort.IsOpen
			If flag Then
				serialPort.Open()
			End If
			Try
				serialPort.Write(ChrW(29) & "\" & vbLf & ChrW(1))
				serialPort.Write(ChrW(27) & "a" & ChrW(1))
				serialPort.Write(ChrW(27) & "!" & vbNullChar)
				serialPort.WriteLine(pstrStringHead)
				serialPort.WriteLine(pstrStringBody)
				serialPort.WriteLine("")
				serialPort.WriteLine("")
				serialPort.WriteLine(ChrW(27) & "d" & vbNullChar)
				serialPort.WriteLine(ChrW(29) & "VB" & ChrW(1))
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - sTestPrintCOM80 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				serialPort.Close()
			End Try
		End Sub

		' Token: 0x06001D88 RID: 7560 RVA: 0x0017042C File Offset: 0x0016E62C
		Public Sub gsTestPrintDiver58(pstrStringHead As String, pstrStringBody As String, Optional pstrPrintername As String = "")
			Dim rptRepBCTestPrintK58Driver As rptRepBCTestPrintK58Driver = New rptRepBCTestPrintK58Driver()
			Try
				Dim textObject As TextObject = CType(rptRepBCTestPrintK58Driver.ReportDefinition.ReportObjects("txtNgay"), TextObject)
				textObject.Text = String.Concat(New String() { mdlVariable.gArrStrMess(127), " ", DateAndTime.Now.Day.ToString("00"), "/", DateAndTime.Now.Month.ToString("00"), "/", DateAndTime.Now.Year.ToString("0000"), " ", mdlVariable.gArrStrMess(128), " ", DateAndTime.Now.Hour.ToString("00"), ":", DateAndTime.Now.Minute.ToString("00") })
				Dim textObject2 As TextObject = CType(rptRepBCTestPrintK58Driver.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
				textObject2.Text = pstrStringHead
				Dim textObject3 As TextObject = CType(rptRepBCTestPrintK58Driver.ReportDefinition.ReportObjects("Text1"), TextObject)
				textObject3.Text = pstrStringBody
				Dim textObject4 As TextObject = CType(rptRepBCTestPrintK58Driver.ReportDefinition.ReportObjects("Text2"), TextObject)
				textObject4.Text = ""
				Dim textObject5 As TextObject = CType(rptRepBCTestPrintK58Driver.ReportDefinition.ReportObjects("Text3"), TextObject)
				textObject5.Text = ""
				MyProject.Forms.frmReport.pSource = rptRepBCTestPrintK58Driver
				Dim flag As Boolean = pstrPrintername.Trim().Length > 0
				If flag Then
					rptRepBCTestPrintK58Driver.PrintOptions.PrinterName = pstrPrintername
				End If
				rptRepBCTestPrintK58Driver.PrintToPrinter(1, False, 0, 0)
				MyProject.Forms.frmReport.pSource = Nothing
			Catch ex As Exception
				Interaction.MsgBox(String.Concat(New String() { Me.mArrStrFrmMess(1), vbCrLf, Me.Name, " - gsTestPrintDiver58 ", ex.Message, vbCrLf }), MsgBoxStyle.Critical, Nothing)
			Finally
				rptRepBCTestPrintK58Driver.Dispose()
			End Try
		End Sub

		' Token: 0x06001D89 RID: 7561 RVA: 0x00170708 File Offset: 0x0016E908
		Private Function fPrintDMMAYINBEP(pstrMAMAY As String) As Byte
			Dim rptDMMAYINBEP As rptDMMAYINBEP = New rptDMMAYINBEP()
			Dim clsConnect As clsConnect = New clsConnect()
			Dim sqlCommand As SqlCommand = New SqlCommand()
			Dim array As SqlParameter() = New SqlParameter(1) {}
			Dim b As Byte
			Try
				b = 0
				mdlVariable.gBytPrinting = 1
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.WaitCursor
				mdlReport.gsSetTopReport(rptDMMAYINBEP, "")
				Dim text As String = "2080400000"
				mdlReport.gsSetOfficeReport(rptDMMAYINBEP, text)
				mdlReport.gsSetFontReport(rptDMMAYINBEP)
				array(0) = sqlCommand.CreateParameter()
				array(0).ParameterName = "@pnchMAMAY"
				array(0).Value = pstrMAMAY
				Dim num As Integer
				clsConnect = New clsConnect(mdlVariable.gStrConISDANHMUC, array, "SP_GET_DMMAYINBEP", num)
				Dim flag As Boolean = num = 1
				If flag Then
					rptDMMAYINBEP.SetDataSource(clsConnect)
					rptDMMAYINBEP.DataDefinition.FormulaFields("fPrintBillCode").Text = "{dtReport.OBJID}"
					rptDMMAYINBEP.DataDefinition.FormulaFields("fPrintBillName").Text = "{dtReport.OBJNAME}"
					rptDMMAYINBEP.DataDefinition.FormulaFields("fCOMName").Text = "{dtReport.COMNAME}"
					rptDMMAYINBEP.DataDefinition.FormulaFields("fBaudRate").Text = "{dtReport.BAUDRATE}"
					rptDMMAYINBEP.DataDefinition.FormulaFields("fComputerName").Text = "{dtReport.TENMAY}"
					mdlReport.gsSetTextReport(rptDMMAYINBEP, "RPTDMMAYINBEP")
					MyProject.Forms.frmReport.pSource = rptDMMAYINBEP
					MyProject.Forms.frmReport.MaximizeBox = True
					MyProject.Forms.frmReport.crvReport.DisplayGroupTree = False
					Dim textObject As TextObject = CType(rptDMMAYINBEP.ReportDefinition.ReportObjects("txtReportTitle"), TextObject)
					MyProject.Forms.frmReport.Text = textObject.Text
					rptDMMAYINBEP.PrintOptions.PrinterName = mdlVariable.gstrPrinterA4
					rptDMMAYINBEP.PrintOptions.PaperSize = PaperSize.PaperA4
					MyProject.Forms.frmReport.ShowDialog()
					MyProject.Forms.frmReport.pSource = Nothing
					clsConnect.Dispose()
					b = 1
				End If
			Catch ex As Exception
				Interaction.MsgBox(Me.Name + " - fPrintDMMAYINBEP " & vbCrLf + ex.Message, MsgBoxStyle.Critical, Nothing)
			Finally
				mdlVariable.gfrmHomeFunc.Cursor = Cursors.[Default]
				rptDMMAYINBEP.Dispose()
				clsConnect.Dispose()
			End Try
			Return b
		End Function

		' Token: 0x04000BE9 RID: 3049
		Private Shared __ENCList As ArrayList = New ArrayList()

		' Token: 0x04000BEB RID: 3051
		<AccessedThroughProperty("lblPosition")>
		Private _lblPosition As Label

		' Token: 0x04000BEC RID: 3052
		<AccessedThroughProperty("btnAddDefault")>
		Private _btnAddDefault As Button

		' Token: 0x04000BED RID: 3053
		<AccessedThroughProperty("btnDelete")>
		Private _btnDelete As Button

		' Token: 0x04000BEE RID: 3054
		<AccessedThroughProperty("btnLast")>
		Private _btnLast As Button

		' Token: 0x04000BEF RID: 3055
		<AccessedThroughProperty("btnNext")>
		Private _btnNext As Button

		' Token: 0x04000BF0 RID: 3056
		<AccessedThroughProperty("btnFind")>
		Private _btnFind As Button

		' Token: 0x04000BF1 RID: 3057
		<AccessedThroughProperty("btnPreview")>
		Private _btnPreview As Button

		' Token: 0x04000BF2 RID: 3058
		<AccessedThroughProperty("btnCancelFilter")>
		Private _btnCancelFilter As Button

		' Token: 0x04000BF3 RID: 3059
		<AccessedThroughProperty("grpNavigater")>
		Private _grpNavigater As GroupBox

		' Token: 0x04000BF4 RID: 3060
		<AccessedThroughProperty("btnFirst")>
		Private _btnFirst As Button

		' Token: 0x04000BF5 RID: 3061
		<AccessedThroughProperty("btnPrevious")>
		Private _btnPrevious As Button

		' Token: 0x04000BF6 RID: 3062
		<AccessedThroughProperty("btnFilter")>
		Private _btnFilter As Button

		' Token: 0x04000BF7 RID: 3063
		<AccessedThroughProperty("grpControl")>
		Private _grpControl As GroupBox

		' Token: 0x04000BF8 RID: 3064
		<AccessedThroughProperty("btnModify")>
		Private _btnModify As Button

		' Token: 0x04000BF9 RID: 3065
		<AccessedThroughProperty("btnAdd")>
		Private _btnAdd As Button

		' Token: 0x04000BFA RID: 3066
		<AccessedThroughProperty("btnExit")>
		Private _btnExit As Button

		' Token: 0x04000BFB RID: 3067
		<AccessedThroughProperty("btnFindNext")>
		Private _btnFindNext As Button

		' Token: 0x04000BFC RID: 3068
		<AccessedThroughProperty("btnSelect")>
		Private _btnSelect As Button

		' Token: 0x04000BFD RID: 3069
		<AccessedThroughProperty("dgvData")>
		Private _dgvData As DataGridView

		' Token: 0x04000BFE RID: 3070
		<AccessedThroughProperty("lblStore")>
		Private _lblStore As Label

		' Token: 0x04000BFF RID: 3071
		<AccessedThroughProperty("txtOBJNAMEMAY")>
		Private _txtOBJNAMEMAY As TextBox

		' Token: 0x04000C00 RID: 3072
		<AccessedThroughProperty("btnSelectMAY")>
		Private _btnSelectMAY As Button

		' Token: 0x04000C01 RID: 3073
		<AccessedThroughProperty("txtOBJIDMAY")>
		Private _txtOBJIDMAY As TextBox

		' Token: 0x04000C02 RID: 3074
		<AccessedThroughProperty("btnTestPrint")>
		Private _btnTestPrint As Button

		' Token: 0x04000C03 RID: 3075
		<AccessedThroughProperty("TableLayoutPanel1")>
		Private _TableLayoutPanel1 As TableLayoutPanel

		' Token: 0x04000C04 RID: 3076
		Private mArrStrFrmMess As String()

		' Token: 0x04000C05 RID: 3077
		Private mStrOBJID As String

		' Token: 0x04000C06 RID: 3078
		Private mStrOBJNAME As String

		' Token: 0x04000C07 RID: 3079
		Private mBytOpen_FromMenu As Byte

		' Token: 0x04000C08 RID: 3080
		<AccessedThroughProperty("mbdsSource")>
		Private _mbdsSource As BindingSource

		' Token: 0x04000C09 RID: 3081
		Private marrDrFind As DataRow()

		' Token: 0x04000C0A RID: 3082
		Private mintFindLastPos As Integer

		' Token: 0x04000C0B RID: 3083
		Private mclsTbDMMAY As clsConnect

		' Token: 0x04000C0C RID: 3084
		Private srlCOMport As SerialPort

		' Token: 0x04000C0D RID: 3085
		Private mblnIsOK As Boolean
	End Class
End Namespace
