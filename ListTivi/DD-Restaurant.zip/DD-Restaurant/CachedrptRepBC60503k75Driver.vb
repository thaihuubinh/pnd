﻿Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.[Shared]

Namespace prjIS_SalesPOS
	' Token: 0x020001D6 RID: 470
	<ToolboxBitmap(GetType(ExportOptions), "report.bmp")>
	Public Class CachedrptRepBC60503k75Driver
		Inherits Component
		Implements ICachedReport

		' Token: 0x06005EF1 RID: 24305 RVA: 0x00010DA5 File Offset: 0x0000EFA5
		Public Sub New()
			CachedrptRepBC60503k75Driver.__ENCList.Add(New WeakReference(Me))
		End Sub

		' Token: 0x17002372 RID: 9074
		' (get) Token: 0x06005EF2 RID: 24306 RVA: 0x004DABDC File Offset: 0x004D8DDC
		' (set) Token: 0x06005EF3 RID: 24307 RVA: 0x00002A72 File Offset: 0x00000C72
		<Browsable(False)>
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		Public Overridable Property IsCacheable As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.IsCacheable
			Get
				Return True
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002373 RID: 9075
		' (get) Token: 0x06005EF4 RID: 24308 RVA: 0x0001D60C File Offset: 0x0001B80C
		' (set) Token: 0x06005EF5 RID: 24309 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property ShareDBLogonInfo As Boolean Implements CrystalDecisions.ReportSource.ICachedReport.ShareDBLogonInfo
			Get
				Return False
			End Get
			Set(value As Boolean)
			End Set
		End Property

		' Token: 0x17002374 RID: 9076
		' (get) Token: 0x06005EF6 RID: 24310 RVA: 0x004DABF0 File Offset: 0x004D8DF0
		' (set) Token: 0x06005EF7 RID: 24311 RVA: 0x00002A72 File Offset: 0x00000C72
		<DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)>
		<Browsable(False)>
		Public Overridable Property CacheTimeOut As TimeSpan Implements CrystalDecisions.ReportSource.ICachedReport.CacheTimeOut
			Get
				Return CachedReportConstants.DEFAULT_TIMEOUT
			End Get
			Set(value As TimeSpan)
			End Set
		End Property

		' Token: 0x06005EF8 RID: 24312 RVA: 0x004DC620 File Offset: 0x004DA820
		Public Overridable Function CreateReport() As ReportDocument Implements CrystalDecisions.ReportSource.ICachedReport.CreateReport
			Return New rptRepBC60503k75Driver() With { .Site = Me.Site }
		End Function

		' Token: 0x06005EF9 RID: 24313 RVA: 0x004DAC30 File Offset: 0x004D8E30
		Public Overridable Function GetCustomizedCacheKey(request As RequestContext) As String Implements CrystalDecisions.ReportSource.ICachedReport.GetCustomizedCacheKey
			Return Nothing
		End Function

		' Token: 0x040027CE RID: 10190
		Private Shared __ENCList As ArrayList = New ArrayList()
	End Class
End Namespace
