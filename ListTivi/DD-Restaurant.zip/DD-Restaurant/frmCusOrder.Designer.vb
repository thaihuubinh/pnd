﻿Namespace prjIS_SalesPOS
	' Token: 0x0200002D RID: 45
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class frmCusOrder
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x060008E6 RID: 2278 RVA: 0x00068E2C File Offset: 0x0006702C
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
			If flag Then
				Me.components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		' Token: 0x060008E7 RID: 2279 RVA: 0x00068E64 File Offset: 0x00067064
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim dataGridViewCellStyle As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim dataGridViewCellStyle2 As Global.System.Windows.Forms.DataGridViewCellStyle = New Global.System.Windows.Forms.DataGridViewCellStyle()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.prjIS_SalesPOS.frmCusOrder))
			Me.lblPosition = New Global.System.Windows.Forms.Label()
			Me.btnLast = New Global.System.Windows.Forms.Button()
			Me.btnNext = New Global.System.Windows.Forms.Button()
			Me.btnSelect = New Global.System.Windows.Forms.Button()
			Me.grpNavigater = New Global.System.Windows.Forms.GroupBox()
			Me.btnFirst = New Global.System.Windows.Forms.Button()
			Me.btnPrevious = New Global.System.Windows.Forms.Button()
			Me.btnExit = New Global.System.Windows.Forms.Button()
			Me.dgvData = New Global.System.Windows.Forms.DataGridView()
			Me.lblFilterDate = New Global.System.Windows.Forms.Label()
			Me.dgvDataDetail = New Global.System.Windows.Forms.DataGridView()
			Me.txtMaDV = New Global.System.Windows.Forms.TextBox()
			Me.btnKH = New Global.System.Windows.Forms.Button()
			Me.txtTENDV = New Global.System.Windows.Forms.TextBox()
			Me.grpNavigater.SuspendLayout()
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.dgvDataDetail, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			Me.lblPosition.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.lblPosition.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.lblPosition.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblPosition As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim point As Global.System.Drawing.Point = New Global.System.Drawing.Point(112, 14)
			lblPosition.Location = point
			Me.lblPosition.Name = "lblPosition"
			Dim lblPosition2 As Global.System.Windows.Forms.Control = Me.lblPosition
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(93, 28)
			lblPosition2.Size = size
			Me.lblPosition.TabIndex = 6
			Me.lblPosition.Tag = "0R0000"
			Me.lblPosition.TextAlign = Global.System.Drawing.ContentAlignment.MiddleCenter
			Me.btnLast.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.Stretch
			Me.btnLast.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi
			Dim btnLast As Global.System.Windows.Forms.Control = Me.btnLast
			point = New Global.System.Drawing.Point(265, 14)
			btnLast.Location = point
			Me.btnLast.Name = "btnLast"
			Dim btnLast2 As Global.System.Windows.Forms.Control = Me.btnLast
			size = New Global.System.Drawing.Size(44, 31)
			btnLast2.Size = size
			Me.btnLast.TabIndex = 5
			Me.btnLast.UseVisualStyleBackColor = True
			Me.btnNext.Image = Global.prjIS_SalesPOS.My.Resources.Resources.toi
			Dim btnNext As Global.System.Windows.Forms.Control = Me.btnNext
			point = New Global.System.Drawing.Point(212, 13)
			btnNext.Location = point
			Me.btnNext.Name = "btnNext"
			Dim btnNext2 As Global.System.Windows.Forms.Control = Me.btnNext
			size = New Global.System.Drawing.Size(47, 31)
			btnNext2.Size = size
			Me.btnNext.TabIndex = 4
			Me.btnNext.UseVisualStyleBackColor = True
			Me.btnSelect.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Select
			Dim btnSelect As Global.System.Windows.Forms.Control = Me.btnSelect
			point = New Global.System.Drawing.Point(576, 471)
			btnSelect.Location = point
			Me.btnSelect.Name = "btnSelect"
			Dim btnSelect2 As Global.System.Windows.Forms.Control = Me.btnSelect
			size = New Global.System.Drawing.Size(80, 42)
			btnSelect2.Size = size
			Me.btnSelect.TabIndex = 3
			Me.btnSelect.Tag = "CR0013"
			Me.btnSelect.Text = "chon"
			Me.btnSelect.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnSelect.UseVisualStyleBackColor = True
			Me.grpNavigater.Anchor = Global.System.Windows.Forms.AnchorStyles.Bottom
			Me.grpNavigater.Controls.Add(Me.lblPosition)
			Me.grpNavigater.Controls.Add(Me.btnFirst)
			Me.grpNavigater.Controls.Add(Me.btnPrevious)
			Me.grpNavigater.Controls.Add(Me.btnLast)
			Me.grpNavigater.Controls.Add(Me.btnNext)
			Dim grpNavigater As Global.System.Windows.Forms.Control = Me.grpNavigater
			point = New Global.System.Drawing.Point(59, 463)
			grpNavigater.Location = point
			Me.grpNavigater.Name = "grpNavigater"
			Dim grpNavigater2 As Global.System.Windows.Forms.Control = Me.grpNavigater
			size = New Global.System.Drawing.Size(315, 51)
			grpNavigater2.Size = size
			Me.grpNavigater.TabIndex = 2
			Me.grpNavigater.TabStop = False
			Me.btnFirst.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui
			Dim btnFirst As Global.System.Windows.Forms.Control = Me.btnFirst
			point = New Global.System.Drawing.Point(6, 14)
			btnFirst.Location = point
			Me.btnFirst.Name = "btnFirst"
			Dim btnFirst2 As Global.System.Windows.Forms.Control = Me.btnFirst
			size = New Global.System.Drawing.Size(45, 30)
			btnFirst2.Size = size
			Me.btnFirst.TabIndex = 2
			Me.btnFirst.UseVisualStyleBackColor = True
			Me.btnPrevious.Image = Global.prjIS_SalesPOS.My.Resources.Resources.lui
			Dim btnPrevious As Global.System.Windows.Forms.Control = Me.btnPrevious
			point = New Global.System.Drawing.Point(57, 14)
			btnPrevious.Location = point
			Me.btnPrevious.Name = "btnPrevious"
			Dim btnPrevious2 As Global.System.Windows.Forms.Control = Me.btnPrevious
			size = New Global.System.Drawing.Size(49, 31)
			btnPrevious2.Size = size
			Me.btnPrevious.TabIndex = 3
			Me.btnPrevious.UseVisualStyleBackColor = True
			Me.btnExit.Image = Global.prjIS_SalesPOS.My.Resources.Resources._Exit
			Dim btnExit As Global.System.Windows.Forms.Control = Me.btnExit
			point = New Global.System.Drawing.Point(702, 470)
			btnExit.Location = point
			Me.btnExit.Name = "btnExit"
			Dim btnExit2 As Global.System.Windows.Forms.Control = Me.btnExit
			size = New Global.System.Drawing.Size(80, 42)
			btnExit2.Size = size
			Me.btnExit.TabIndex = 4
			Me.btnExit.Tag = "CR0003"
			Me.btnExit.Text = "Thoát"
			Me.btnExit.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.btnExit.UseVisualStyleBackColor = True
			Me.dgvData.AllowUserToAddRows = False
			Me.dgvData.AllowUserToDeleteRows = False
			Me.dgvData.AllowUserToResizeRows = False
			Me.dgvData.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Left
			Me.dgvData.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle
			Me.dgvData.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvData As Global.System.Windows.Forms.Control = Me.dgvData
			point = New Global.System.Drawing.Point(0, 37)
			dgvData.Location = point
			Me.dgvData.Name = "dgvData"
			Me.dgvData.[ReadOnly] = True
			Dim dgvData2 As Global.System.Windows.Forms.Control = Me.dgvData
			size = New Global.System.Drawing.Size(395, 428)
			dgvData2.Size = size
			Me.dgvData.TabIndex = 1
			Me.lblFilterDate.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim lblFilterDate As Global.System.Windows.Forms.Control = Me.lblFilterDate
			point = New Global.System.Drawing.Point(12, 9)
			lblFilterDate.Location = point
			Me.lblFilterDate.Name = "lblFilterDate"
			Dim lblFilterDate2 As Global.System.Windows.Forms.Control = Me.lblFilterDate
			size = New Global.System.Drawing.Size(174, 21)
			lblFilterDate2.Size = size
			Me.lblFilterDate.TabIndex = 43
			Me.lblFilterDate.Tag = "CR0017"
			Me.lblFilterDate.Text = "Đang được lọc theo KH:"
			Me.dgvDataDetail.AllowUserToAddRows = False
			Me.dgvDataDetail.AllowUserToDeleteRows = False
			Me.dgvDataDetail.Anchor = Global.System.Windows.Forms.AnchorStyles.Top Or Global.System.Windows.Forms.AnchorStyles.Bottom Or Global.System.Windows.Forms.AnchorStyles.Right
			Me.dgvDataDetail.BackgroundColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			dataGridViewCellStyle2.Alignment = Global.System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
			dataGridViewCellStyle2.BackColor = Global.System.Drawing.SystemColors.Control
			dataGridViewCellStyle2.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			dataGridViewCellStyle2.ForeColor = Global.System.Drawing.SystemColors.WindowText
			dataGridViewCellStyle2.SelectionBackColor = Global.System.Drawing.SystemColors.Highlight
			dataGridViewCellStyle2.SelectionForeColor = Global.System.Drawing.SystemColors.HighlightText
			dataGridViewCellStyle2.WrapMode = Global.System.Windows.Forms.DataGridViewTriState.[True]
			Me.dgvDataDetail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2
			Me.dgvDataDetail.ColumnHeadersHeightSizeMode = Global.System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Dim dgvDataDetail As Global.System.Windows.Forms.Control = Me.dgvDataDetail
			point = New Global.System.Drawing.Point(398, 37)
			dgvDataDetail.Location = point
			Me.dgvDataDetail.Name = "dgvDataDetail"
			Me.dgvDataDetail.[ReadOnly] = True
			Dim dgvDataDetail2 As Global.System.Windows.Forms.Control = Me.dgvDataDetail
			size = New Global.System.Drawing.Size(395, 428)
			dgvDataDetail2.Size = size
			Me.dgvDataDetail.TabIndex = 46
			Me.txtMaDV.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtMaDV As Global.System.Windows.Forms.Control = Me.txtMaDV
			point = New Global.System.Drawing.Point(206, 4)
			txtMaDV.Location = point
			Me.txtMaDV.Name = "txtMaDV"
			Dim txtMaDV2 As Global.System.Windows.Forms.Control = Me.txtMaDV
			size = New Global.System.Drawing.Size(139, 26)
			txtMaDV2.Size = size
			Me.txtMaDV.TabIndex = 0
			Me.txtMaDV.Tag = ""
			Me.btnKH.BackgroundImageLayout = Global.System.Windows.Forms.ImageLayout.None
			Me.btnKH.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.btnKH.ForeColor = Global.System.Drawing.Color.MediumBlue
			Me.btnKH.Image = Global.prjIS_SalesPOS.My.Resources.Resources.ong_nhom
			Dim btnKH As Global.System.Windows.Forms.Control = Me.btnKH
			point = New Global.System.Drawing.Point(351, 1)
			btnKH.Location = point
			Me.btnKH.Name = "btnKH"
			Dim btnKH2 As Global.System.Windows.Forms.Control = Me.btnKH
			size = New Global.System.Drawing.Size(44, 30)
			btnKH2.Size = size
			Me.btnKH.TabIndex = 1
			Me.btnKH.Tag = ""
			Me.btnKH.UseVisualStyleBackColor = True
			Me.txtTENDV.BackColor = Global.System.Drawing.Color.FromArgb(255, 255, 192)
			Me.txtTENDV.Font = New Global.System.Drawing.Font("Arial", 12F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Dim txtTENDV As Global.System.Windows.Forms.Control = Me.txtTENDV
			point = New Global.System.Drawing.Point(398, 4)
			txtTENDV.Location = point
			Me.txtTENDV.Name = "txtTENDV"
			Dim txtTENDV2 As Global.System.Windows.Forms.Control = Me.txtTENDV
			size = New Global.System.Drawing.Size(395, 26)
			txtTENDV2.Size = size
			Me.txtTENDV.TabIndex = 49
			Me.txtTENDV.Tag = ""
			Dim sizeF As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 16F)
			Me.AutoScaleDimensions = sizeF
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			size = New Global.System.Drawing.Size(794, 526)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(Me.txtTENDV)
			Me.Controls.Add(Me.txtMaDV)
			Me.Controls.Add(Me.btnKH)
			Me.Controls.Add(Me.btnExit)
			Me.Controls.Add(Me.dgvDataDetail)
			Me.Controls.Add(Me.btnSelect)
			Me.Controls.Add(Me.lblFilterDate)
			Me.Controls.Add(Me.dgvData)
			Me.Controls.Add(Me.grpNavigater)
			Me.Font = New Global.System.Drawing.Font("Arial", 9.75F, Global.System.Drawing.FontStyle.Regular, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Dim padding As Global.System.Windows.Forms.Padding = New Global.System.Windows.Forms.Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.Name = "frmCusOrder"
			Me.ShowInTaskbar = False
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "reprintbill"
			Me.grpNavigater.ResumeLayout(False)
			CType(Me.dgvData, Global.System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.dgvDataDetail, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		' Token: 0x040003E4 RID: 996
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
